

#ifndef PY_SSIZE_T_CLEAN
#define PY_SSIZE_T_CLEAN
#endif 

#if defined(Py_LIMITED_API) && !defined(CYTHON_LIMITED_API)
  #define CYTHON_LIMITED_API 1
#endif

#include "Python.h"
#ifndef Py_PYTHON_H
    #error Python headers needed to compile C extensions, please install development version of Python.
#elif PY_VERSION_HEX < 0x03080000
    #error Cython requires Python 3.8+.
#else
#define __PYX_ABI_VERSION "3_1_4"
#define CYTHON_HEX_VERSION 0x030104F0
#define CYTHON_FUTURE_DIVISION 1

#include <stddef.h>
#ifndef offsetof
  #define offsetof(type, member) ( (size_t) & ((type*)0) -> member )
#endif
#if !defined(_WIN32) && !defined(WIN32) && !defined(MS_WINDOWS)
  #ifndef __stdcall
    #define __stdcall
  #endif
  #ifndef __cdecl
    #define __cdecl
  #endif
  #ifndef __fastcall
    #define __fastcall
  #endif
#endif
#ifndef DL_IMPORT
  #define DL_IMPORT(t) t
#endif
#ifndef DL_EXPORT
  #define DL_EXPORT(t) t
#endif
#define __PYX_COMMA ,
#ifndef HAVE_LONG_LONG
  #define HAVE_LONG_LONG
#endif
#ifndef PY_LONG_LONG
  #define PY_LONG_LONG LONG_LONG
#endif
#ifndef Py_HUGE_VAL
  #define Py_HUGE_VAL HUGE_VAL
#endif
#define __PYX_LIMITED_VERSION_HEX PY_VERSION_HEX
#if defined(GRAALVM_PYTHON)
  
  #define CYTHON_COMPILING_IN_PYPY 0
  #define CYTHON_COMPILING_IN_CPYTHON 0
  #define CYTHON_COMPILING_IN_LIMITED_API 0
  #define CYTHON_COMPILING_IN_GRAAL 1
  #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #undef CYTHON_USE_TYPE_SLOTS
  #define CYTHON_USE_TYPE_SLOTS 0
  #undef CYTHON_USE_TYPE_SPECS
  #define CYTHON_USE_TYPE_SPECS 0
  #undef CYTHON_USE_PYTYPE_LOOKUP
  #define CYTHON_USE_PYTYPE_LOOKUP 0
  #undef CYTHON_USE_PYLIST_INTERNALS
  #define CYTHON_USE_PYLIST_INTERNALS 0
  #undef CYTHON_USE_UNICODE_INTERNALS
  #define CYTHON_USE_UNICODE_INTERNALS 0
  #undef CYTHON_USE_UNICODE_WRITER
  #define CYTHON_USE_UNICODE_WRITER 0
  #undef CYTHON_USE_PYLONG_INTERNALS
  #define CYTHON_USE_PYLONG_INTERNALS 0
  #undef CYTHON_AVOID_BORROWED_REFS
  #define CYTHON_AVOID_BORROWED_REFS 1
  #undef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
  #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 1
  #undef CYTHON_ASSUME_SAFE_MACROS
  #define CYTHON_ASSUME_SAFE_MACROS 0
  #undef CYTHON_ASSUME_SAFE_SIZE
  #define CYTHON_ASSUME_SAFE_SIZE 0
  #undef CYTHON_UNPACK_METHODS
  #define CYTHON_UNPACK_METHODS 0
  #undef CYTHON_FAST_THREAD_STATE
  #define CYTHON_FAST_THREAD_STATE 0
  #undef CYTHON_FAST_GIL
  #define CYTHON_FAST_GIL 0
  #undef CYTHON_METH_FASTCALL
  #define CYTHON_METH_FASTCALL 0
  #undef CYTHON_FAST_PYCALL
  #define CYTHON_FAST_PYCALL 0
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #undef CYTHON_PEP489_MULTI_PHASE_INIT
  #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #undef CYTHON_USE_MODULE_STATE
  #define CYTHON_USE_MODULE_STATE 0
  #undef CYTHON_USE_SYS_MONITORING
  #define CYTHON_USE_SYS_MONITORING 0
  #undef CYTHON_USE_TP_FINALIZE
  #define CYTHON_USE_TP_FINALIZE 0
  #undef CYTHON_USE_AM_SEND
  #define CYTHON_USE_AM_SEND 0
  #undef CYTHON_USE_DICT_VERSIONS
  #define CYTHON_USE_DICT_VERSIONS 0
  #undef CYTHON_USE_EXC_INFO_STACK
  #define CYTHON_USE_EXC_INFO_STACK 1
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC 0
  #endif
  #undef CYTHON_USE_FREELISTS
  #define CYTHON_USE_FREELISTS 0
#elif defined(PYPY_VERSION)
  #define CYTHON_COMPILING_IN_PYPY 1
  #define CYTHON_COMPILING_IN_CPYTHON 0
  #define CYTHON_COMPILING_IN_LIMITED_API 0
  #define CYTHON_COMPILING_IN_GRAAL 0
  #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #undef CYTHON_USE_TYPE_SLOTS
  #define CYTHON_USE_TYPE_SLOTS 1
  #ifndef CYTHON_USE_TYPE_SPECS
    #define CYTHON_USE_TYPE_SPECS 0
  #endif
  #undef CYTHON_USE_PYTYPE_LOOKUP
  #define CYTHON_USE_PYTYPE_LOOKUP 0
  #undef CYTHON_USE_PYLIST_INTERNALS
  #define CYTHON_USE_PYLIST_INTERNALS 0
  #undef CYTHON_USE_UNICODE_INTERNALS
  #define CYTHON_USE_UNICODE_INTERNALS 0
  #undef CYTHON_USE_UNICODE_WRITER
  #define CYTHON_USE_UNICODE_WRITER 0
  #undef CYTHON_USE_PYLONG_INTERNALS
  #define CYTHON_USE_PYLONG_INTERNALS 0
  #undef CYTHON_AVOID_BORROWED_REFS
  #define CYTHON_AVOID_BORROWED_REFS 1
  #undef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
  #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 1
  #undef CYTHON_ASSUME_SAFE_MACROS
  #define CYTHON_ASSUME_SAFE_MACROS 0
  #ifndef CYTHON_ASSUME_SAFE_SIZE
    #define CYTHON_ASSUME_SAFE_SIZE 1
  #endif
  #undef CYTHON_UNPACK_METHODS
  #define CYTHON_UNPACK_METHODS 0
  #undef CYTHON_FAST_THREAD_STATE
  #define CYTHON_FAST_THREAD_STATE 0
  #undef CYTHON_FAST_GIL
  #define CYTHON_FAST_GIL 0
  #undef CYTHON_METH_FASTCALL
  #define CYTHON_METH_FASTCALL 0
  #undef CYTHON_FAST_PYCALL
  #define CYTHON_FAST_PYCALL 0
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #if PY_VERSION_HEX < 0x03090000
    #undef CYTHON_PEP489_MULTI_PHASE_INIT
    #define CYTHON_PEP489_MULTI_PHASE_INIT 0
  #elif !defined(CYTHON_PEP489_MULTI_PHASE_INIT)
    #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #endif
  #undef CYTHON_USE_MODULE_STATE
  #define CYTHON_USE_MODULE_STATE 0
  #undef CYTHON_USE_SYS_MONITORING
  #define CYTHON_USE_SYS_MONITORING 0
  #ifndef CYTHON_USE_TP_FINALIZE
    #define CYTHON_USE_TP_FINALIZE (PYPY_VERSION_NUM >= 0x07030C00)
  #endif
  #undef CYTHON_USE_AM_SEND
  #define CYTHON_USE_AM_SEND 0
  #undef CYTHON_USE_DICT_VERSIONS
  #define CYTHON_USE_DICT_VERSIONS 0
  #undef CYTHON_USE_EXC_INFO_STACK
  #define CYTHON_USE_EXC_INFO_STACK 0
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC (PYPY_VERSION_NUM >= 0x07031100)
  #endif
  #undef CYTHON_USE_FREELISTS
  #define CYTHON_USE_FREELISTS 0
#elif defined(CYTHON_LIMITED_API)
  #ifdef Py_LIMITED_API
    #undef __PYX_LIMITED_VERSION_HEX
    #define __PYX_LIMITED_VERSION_HEX Py_LIMITED_API
  #endif
  #define CYTHON_COMPILING_IN_PYPY 0
  #define CYTHON_COMPILING_IN_CPYTHON 0
  #define CYTHON_COMPILING_IN_LIMITED_API 1
  #define CYTHON_COMPILING_IN_GRAAL 0
  #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #undef CYTHON_CLINE_IN_TRACEBACK
  #define CYTHON_CLINE_IN_TRACEBACK 0
  #undef CYTHON_USE_TYPE_SLOTS
  #define CYTHON_USE_TYPE_SLOTS 0
  #undef CYTHON_USE_TYPE_SPECS
  #define CYTHON_USE_TYPE_SPECS 1
  #undef CYTHON_USE_PYTYPE_LOOKUP
  #define CYTHON_USE_PYTYPE_LOOKUP 0
  #undef CYTHON_USE_PYLIST_INTERNALS
  #define CYTHON_USE_PYLIST_INTERNALS 0
  #undef CYTHON_USE_UNICODE_INTERNALS
  #define CYTHON_USE_UNICODE_INTERNALS 0
  #ifndef CYTHON_USE_UNICODE_WRITER
    #define CYTHON_USE_UNICODE_WRITER 0
  #endif
  #undef CYTHON_USE_PYLONG_INTERNALS
  #define CYTHON_USE_PYLONG_INTERNALS 0
  #ifndef CYTHON_AVOID_BORROWED_REFS
    #define CYTHON_AVOID_BORROWED_REFS 0
  #endif
  #ifndef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
    #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 0
  #endif
  #undef CYTHON_ASSUME_SAFE_MACROS
  #define CYTHON_ASSUME_SAFE_MACROS 0
  #undef CYTHON_ASSUME_SAFE_SIZE
  #define CYTHON_ASSUME_SAFE_SIZE 0
  #undef CYTHON_UNPACK_METHODS
  #define CYTHON_UNPACK_METHODS 0
  #undef CYTHON_FAST_THREAD_STATE
  #define CYTHON_FAST_THREAD_STATE 0
  #undef CYTHON_FAST_GIL
  #define CYTHON_FAST_GIL 0
  #undef CYTHON_METH_FASTCALL
  #define CYTHON_METH_FASTCALL (__PYX_LIMITED_VERSION_HEX >= 0x030C0000)
  #undef CYTHON_FAST_PYCALL
  #define CYTHON_FAST_PYCALL 0
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #ifndef CYTHON_PEP489_MULTI_PHASE_INIT
    #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #endif
  #ifndef CYTHON_USE_MODULE_STATE
    #define CYTHON_USE_MODULE_STATE 0
  #endif
  #undef CYTHON_USE_SYS_MONITORING
  #define CYTHON_USE_SYS_MONITORING 0
  #ifndef CYTHON_USE_TP_FINALIZE
    #define CYTHON_USE_TP_FINALIZE 0
  #endif
  #ifndef CYTHON_USE_AM_SEND
    #define CYTHON_USE_AM_SEND (__PYX_LIMITED_VERSION_HEX >= 0x030A0000)
  #endif
  #undef CYTHON_USE_DICT_VERSIONS
  #define CYTHON_USE_DICT_VERSIONS 0
  #undef CYTHON_USE_EXC_INFO_STACK
  #define CYTHON_USE_EXC_INFO_STACK 0
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC 0
  #endif
  #undef CYTHON_USE_FREELISTS
  #define CYTHON_USE_FREELISTS 0
#else
  #define CYTHON_COMPILING_IN_PYPY 0
  #define CYTHON_COMPILING_IN_CPYTHON 1
  #define CYTHON_COMPILING_IN_LIMITED_API 0
  #define CYTHON_COMPILING_IN_GRAAL 0
  #ifdef Py_GIL_DISABLED
    #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 1
  #else
    #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #endif
  #if PY_VERSION_HEX < 0x030A0000
    #undef CYTHON_USE_TYPE_SLOTS
    #define CYTHON_USE_TYPE_SLOTS 1
  #elif !defined(CYTHON_USE_TYPE_SLOTS)
    #define CYTHON_USE_TYPE_SLOTS 1
  #endif
  #ifndef CYTHON_USE_TYPE_SPECS
    #define CYTHON_USE_TYPE_SPECS 0
  #endif
  #ifndef CYTHON_USE_PYTYPE_LOOKUP
    #define CYTHON_USE_PYTYPE_LOOKUP 1
  #endif
  #ifndef CYTHON_USE_PYLONG_INTERNALS
    #define CYTHON_USE_PYLONG_INTERNALS 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_USE_PYLIST_INTERNALS
    #define CYTHON_USE_PYLIST_INTERNALS 0
  #elif !defined(CYTHON_USE_PYLIST_INTERNALS)
    #define CYTHON_USE_PYLIST_INTERNALS 1
  #endif
  #ifndef CYTHON_USE_UNICODE_INTERNALS
    #define CYTHON_USE_UNICODE_INTERNALS 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING || PY_VERSION_HEX >= 0x030B00A2
    #undef CYTHON_USE_UNICODE_WRITER
    #define CYTHON_USE_UNICODE_WRITER 0
  #elif !defined(CYTHON_USE_UNICODE_WRITER)
    #define CYTHON_USE_UNICODE_WRITER 1
  #endif
  #ifndef CYTHON_AVOID_BORROWED_REFS
    #define CYTHON_AVOID_BORROWED_REFS 0
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
    #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 1
  #elif !defined(CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS)
    #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 0
  #endif
  #ifndef CYTHON_ASSUME_SAFE_MACROS
    #define CYTHON_ASSUME_SAFE_MACROS 1
  #endif
  #ifndef CYTHON_ASSUME_SAFE_SIZE
    #define CYTHON_ASSUME_SAFE_SIZE 1
  #endif
  #ifndef CYTHON_UNPACK_METHODS
    #define CYTHON_UNPACK_METHODS 1
  #endif
  #ifndef CYTHON_FAST_THREAD_STATE
    #define CYTHON_FAST_THREAD_STATE 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_FAST_GIL
    #define CYTHON_FAST_GIL 0
  #elif !defined(CYTHON_FAST_GIL)
    #define CYTHON_FAST_GIL (PY_VERSION_HEX < 0x030C00A6)
  #endif
  #ifndef CYTHON_METH_FASTCALL
    #define CYTHON_METH_FASTCALL 1
  #endif
  #ifndef CYTHON_FAST_PYCALL
    #define CYTHON_FAST_PYCALL 1
  #endif
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #ifndef CYTHON_PEP489_MULTI_PHASE_INIT
    #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #endif
  #ifndef CYTHON_USE_MODULE_STATE
    #define CYTHON_USE_MODULE_STATE 0
  #endif
  #ifndef CYTHON_USE_SYS_MONITORING
    #define CYTHON_USE_SYS_MONITORING (PY_VERSION_HEX >= 0x030d00B1)
  #endif
  #ifndef CYTHON_USE_TP_FINALIZE
    #define CYTHON_USE_TP_FINALIZE 1
  #endif
  #ifndef CYTHON_USE_AM_SEND
    #define CYTHON_USE_AM_SEND 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_USE_DICT_VERSIONS
    #define CYTHON_USE_DICT_VERSIONS 0
  #elif !defined(CYTHON_USE_DICT_VERSIONS)
    #define CYTHON_USE_DICT_VERSIONS  (PY_VERSION_HEX < 0x030C00A5 && !CYTHON_USE_MODULE_STATE)
  #endif
  #ifndef CYTHON_USE_EXC_INFO_STACK
    #define CYTHON_USE_EXC_INFO_STACK 1
  #endif
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC 1
  #endif
  #ifndef CYTHON_USE_FREELISTS
    #define CYTHON_USE_FREELISTS (!CYTHON_COMPILING_IN_CPYTHON_FREETHREADING)
  #endif
#endif
#ifndef CYTHON_FAST_PYCCALL
#define CYTHON_FAST_PYCCALL  CYTHON_FAST_PYCALL
#endif
#ifndef CYTHON_VECTORCALL
#if CYTHON_COMPILING_IN_LIMITED_API
#define CYTHON_VECTORCALL  (__PYX_LIMITED_VERSION_HEX >= 0x030C0000)
#else
#define CYTHON_VECTORCALL  (CYTHON_FAST_PYCCALL && PY_VERSION_HEX >= 0x030800B1)
#endif
#endif
#define CYTHON_BACKPORT_VECTORCALL (CYTHON_METH_FASTCALL && PY_VERSION_HEX < 0x030800B1)
#if CYTHON_USE_PYLONG_INTERNALS
  #undef SHIFT
  #undef BASE
  #undef MASK
  #ifdef SIZEOF_VOID_P
    enum { __pyx_check_sizeof_voidp = 1 / (int)(SIZEOF_VOID_P == sizeof(void*)) };
  #endif
#endif
#ifndef CYTHON_LOCK_AND_GIL_DEADLOCK_AVOIDANCE_TIME
  #define CYTHON_LOCK_AND_GIL_DEADLOCK_AVOIDANCE_TIME 100
#endif
#ifndef __has_attribute
  #define __has_attribute(x) 0
#endif
#ifndef __has_cpp_attribute
  #define __has_cpp_attribute(x) 0
#endif
#ifndef CYTHON_RESTRICT
  #if defined(__GNUC__)
    #define CYTHON_RESTRICT __restrict__
  #elif defined(_MSC_VER) && _MSC_VER >= 1400
    #define CYTHON_RESTRICT __restrict
  #elif defined (__STDC_VERSION__) && __STDC_VERSION__ >= 199901L
    #define CYTHON_RESTRICT restrict
  #else
    #define CYTHON_RESTRICT
  #endif
#endif
#ifndef CYTHON_UNUSED
  #if defined(__cplusplus)
    
    #if ((defined(_MSVC_LANG) && _MSVC_LANG >= 201703L) || __cplusplus >= 201703L)
      #if __has_cpp_attribute(maybe_unused)
        #define CYTHON_UNUSED [[maybe_unused]]
      #endif
    #endif
  #endif
#endif
#ifndef CYTHON_UNUSED
# if defined(__GNUC__)
#   if !(defined(__cplusplus)) || (__GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 4))
#     define CYTHON_UNUSED __attribute__ ((__unused__))
#   else
#     define CYTHON_UNUSED
#   endif
# elif defined(__ICC) || (defined(__INTEL_COMPILER) && !defined(_MSC_VER))
#   define CYTHON_UNUSED __attribute__ ((__unused__))
# else
#   define CYTHON_UNUSED
# endif
#endif
#ifndef CYTHON_UNUSED_VAR
#  if defined(__cplusplus)
     template<class T> void CYTHON_UNUSED_VAR( const T& ) { }
#  else
#    define CYTHON_UNUSED_VAR(x) (void)(x)
#  endif
#endif
#ifndef CYTHON_MAYBE_UNUSED_VAR
  #define CYTHON_MAYBE_UNUSED_VAR(x) CYTHON_UNUSED_VAR(x)
#endif
#ifndef CYTHON_NCP_UNUSED
# if CYTHON_COMPILING_IN_CPYTHON && !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#  define CYTHON_NCP_UNUSED
# else
#  define CYTHON_NCP_UNUSED CYTHON_UNUSED
# endif
#endif
#ifndef CYTHON_USE_CPP_STD_MOVE
  #if defined(__cplusplus) && (\
    __cplusplus >= 201103L || (defined(_MSC_VER) && _MSC_VER >= 1600))
    #define CYTHON_USE_CPP_STD_MOVE 1
  #else
    #define CYTHON_USE_CPP_STD_MOVE 0
  #endif
#endif
#define __Pyx_void_to_None(void_result) ((void)(void_result), Py_INCREF(Py_None), Py_None)
#ifdef _MSC_VER
    #ifndef _MSC_STDINT_H_
        #if _MSC_VER < 1300
            typedef unsigned char     uint8_t;
            typedef unsigned short    uint16_t;
            typedef unsigned int      uint32_t;
        #else
            typedef unsigned __int8   uint8_t;
            typedef unsigned __int16  uint16_t;
            typedef unsigned __int32  uint32_t;
        #endif
    #endif
    #if _MSC_VER < 1300
        #ifdef _WIN64
            typedef unsigned long long  __pyx_uintptr_t;
        #else
            typedef unsigned int        __pyx_uintptr_t;
        #endif
    #else
        #ifdef _WIN64
            typedef unsigned __int64    __pyx_uintptr_t;
        #else
            typedef unsigned __int32    __pyx_uintptr_t;
        #endif
    #endif
#else
    #include <stdint.h>
    typedef uintptr_t  __pyx_uintptr_t;
#endif
#ifndef CYTHON_FALLTHROUGH
  #if defined(__cplusplus)
    
    #if ((defined(_MSVC_LANG) && _MSVC_LANG >= 201703L) || __cplusplus >= 201703L)
      #if __has_cpp_attribute(fallthrough)
        #define CYTHON_FALLTHROUGH [[fallthrough]]
      #endif
    #endif
    #ifndef CYTHON_FALLTHROUGH
      #if __has_cpp_attribute(clang::fallthrough)
        #define CYTHON_FALLTHROUGH [[clang::fallthrough]]
      #elif __has_cpp_attribute(gnu::fallthrough)
        #define CYTHON_FALLTHROUGH [[gnu::fallthrough]]
      #endif
    #endif
  #endif
  #ifndef CYTHON_FALLTHROUGH
    #if __has_attribute(fallthrough)
      #define CYTHON_FALLTHROUGH __attribute__((fallthrough))
    #else
      #define CYTHON_FALLTHROUGH
    #endif
  #endif
  #if defined(__clang__) && defined(__apple_build_version__)
    #if __apple_build_version__ < 7000000
      #undef  CYTHON_FALLTHROUGH
      #define CYTHON_FALLTHROUGH
    #endif
  #endif
#endif
#ifndef Py_UNREACHABLE
  #define Py_UNREACHABLE()  assert(0); abort()
#endif
#ifdef __cplusplus
  template <typename T>
  struct __PYX_IS_UNSIGNED_IMPL {static const bool value = T(0) < T(-1);};
  #define __PYX_IS_UNSIGNED(type) (__PYX_IS_UNSIGNED_IMPL<type>::value)
#else
  #define __PYX_IS_UNSIGNED(type) (((type)-1) > 0)
#endif
#if CYTHON_COMPILING_IN_PYPY == 1
  #define __PYX_NEED_TP_PRINT_SLOT  (PY_VERSION_HEX >= 0x030800b4 && PY_VERSION_HEX < 0x030A0000)
#else
  #define __PYX_NEED_TP_PRINT_SLOT  (PY_VERSION_HEX >= 0x030800b4 && PY_VERSION_HEX < 0x03090000)
#endif
#define __PYX_REINTERPRET_FUNCION(func_pointer, other_pointer) ((func_pointer)(void(*)(void))(other_pointer))


#ifndef __cplusplus
  #error "Cython files generated with the C++ option must be compiled with a C++ compiler."
#endif
#ifndef CYTHON_INLINE
  #if defined(__clang__)
    #define CYTHON_INLINE __inline__ __attribute__ ((__unused__))
  #else
    #define CYTHON_INLINE inline
  #endif
#endif
template<typename T>
void __Pyx_call_destructor(T& x) {
    x.~T();
}
template<typename T>
class __Pyx_FakeReference {
  public:
    __Pyx_FakeReference() : ptr(NULL) { }
    __Pyx_FakeReference(const T& ref) : ptr(const_cast<T*>(&ref)) { }
    T *operator->() { return ptr; }
    T *operator&() { return ptr; }
    operator T&() { return *ptr; }
    template<typename U> bool operator ==(const U& other) const { return *ptr == other; }
    template<typename U> bool operator !=(const U& other) const { return *ptr != other; }
    template<typename U> bool operator==(const __Pyx_FakeReference<U>& other) const { return *ptr == *other.ptr; }
    template<typename U> bool operator!=(const __Pyx_FakeReference<U>& other) const { return *ptr != *other.ptr; }
  private:
    T *ptr;
};


#define __PYX_BUILD_PY_SSIZE_T "n"
#define CYTHON_FORMAT_SSIZE_T "z"
#define __Pyx_BUILTIN_MODULE_NAME "builtins"
#define __Pyx_DefaultClassType PyType_Type
#if CYTHON_COMPILING_IN_LIMITED_API
    #ifndef CO_OPTIMIZED
    static int CO_OPTIMIZED;
    #endif
    #ifndef CO_NEWLOCALS
    static int CO_NEWLOCALS;
    #endif
    #ifndef CO_VARARGS
    static int CO_VARARGS;
    #endif
    #ifndef CO_VARKEYWORDS
    static int CO_VARKEYWORDS;
    #endif
    #ifndef CO_ASYNC_GENERATOR
    static int CO_ASYNC_GENERATOR;
    #endif
    #ifndef CO_GENERATOR
    static int CO_GENERATOR;
    #endif
    #ifndef CO_COROUTINE
    static int CO_COROUTINE;
    #endif
#else
    #ifndef CO_COROUTINE
      #define CO_COROUTINE 0x80
    #endif
    #ifndef CO_ASYNC_GENERATOR
      #define CO_ASYNC_GENERATOR 0x200
    #endif
#endif
static int __Pyx_init_co_variables(void);
#if PY_VERSION_HEX >= 0x030900A4 || defined(Py_IS_TYPE)
  #define __Pyx_IS_TYPE(ob, type) Py_IS_TYPE(ob, type)
#else
  #define __Pyx_IS_TYPE(ob, type) (((const PyObject*)ob)->ob_type == (type))
#endif
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_Is)
  #define __Pyx_Py_Is(x, y)  Py_Is(x, y)
#else
  #define __Pyx_Py_Is(x, y) ((x) == (y))
#endif
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_IsNone)
  #define __Pyx_Py_IsNone(ob) Py_IsNone(ob)
#else
  #define __Pyx_Py_IsNone(ob) __Pyx_Py_Is((ob), Py_None)
#endif
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_IsTrue)
  #define __Pyx_Py_IsTrue(ob) Py_IsTrue(ob)
#else
  #define __Pyx_Py_IsTrue(ob) __Pyx_Py_Is((ob), Py_True)
#endif
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_IsFalse)
  #define __Pyx_Py_IsFalse(ob) Py_IsFalse(ob)
#else
  #define __Pyx_Py_IsFalse(ob) __Pyx_Py_Is((ob), Py_False)
#endif
#define __Pyx_NoneAsNull(obj)  (__Pyx_Py_IsNone(obj) ? NULL : (obj))
#if PY_VERSION_HEX >= 0x030900F0 && !CYTHON_COMPILING_IN_PYPY
  #define __Pyx_PyObject_GC_IsFinalized(o) PyObject_GC_IsFinalized(o)
#else
  #define __Pyx_PyObject_GC_IsFinalized(o) _PyGC_FINALIZED(o)
#endif
#ifndef Py_TPFLAGS_CHECKTYPES
  #define Py_TPFLAGS_CHECKTYPES 0
#endif
#ifndef Py_TPFLAGS_HAVE_INDEX
  #define Py_TPFLAGS_HAVE_INDEX 0
#endif
#ifndef Py_TPFLAGS_HAVE_NEWBUFFER
  #define Py_TPFLAGS_HAVE_NEWBUFFER 0
#endif
#ifndef Py_TPFLAGS_HAVE_FINALIZE
  #define Py_TPFLAGS_HAVE_FINALIZE 0
#endif
#ifndef Py_TPFLAGS_SEQUENCE
  #define Py_TPFLAGS_SEQUENCE 0
#endif
#ifndef Py_TPFLAGS_MAPPING
  #define Py_TPFLAGS_MAPPING 0
#endif
#ifndef METH_STACKLESS
  #define METH_STACKLESS 0
#endif
#ifndef METH_FASTCALL
  #ifndef METH_FASTCALL
     #define METH_FASTCALL 0x80
  #endif
  typedef PyObject *(*__Pyx_PyCFunctionFast) (PyObject *self, PyObject *const *args, Py_ssize_t nargs);
  typedef PyObject *(*__Pyx_PyCFunctionFastWithKeywords) (PyObject *self, PyObject *const *args,
                                                          Py_ssize_t nargs, PyObject *kwnames);
#else
  #if PY_VERSION_HEX >= 0x030d00A4
  #  define __Pyx_PyCFunctionFast PyCFunctionFast
  #  define __Pyx_PyCFunctionFastWithKeywords PyCFunctionFastWithKeywords
  #else
  #  define __Pyx_PyCFunctionFast _PyCFunctionFast
  #  define __Pyx_PyCFunctionFastWithKeywords _PyCFunctionFastWithKeywords
  #endif
#endif
#if CYTHON_METH_FASTCALL
  #define __Pyx_METH_FASTCALL METH_FASTCALL
  #define __Pyx_PyCFunction_FastCall __Pyx_PyCFunctionFast
  #define __Pyx_PyCFunction_FastCallWithKeywords __Pyx_PyCFunctionFastWithKeywords
#else
  #define __Pyx_METH_FASTCALL METH_VARARGS
  #define __Pyx_PyCFunction_FastCall PyCFunction
  #define __Pyx_PyCFunction_FastCallWithKeywords PyCFunctionWithKeywords
#endif
#if CYTHON_VECTORCALL
  #define __pyx_vectorcallfunc vectorcallfunc
  #define __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET  PY_VECTORCALL_ARGUMENTS_OFFSET
  #define __Pyx_PyVectorcall_NARGS(n)  PyVectorcall_NARGS((size_t)(n))
#elif CYTHON_BACKPORT_VECTORCALL
  typedef PyObject *(*__pyx_vectorcallfunc)(PyObject *callable, PyObject *const *args,
                                            size_t nargsf, PyObject *kwnames);
  #define __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET  ((size_t)1 << (8 * sizeof(size_t) - 1))
  #define __Pyx_PyVectorcall_NARGS(n)  ((Py_ssize_t)(((size_t)(n)) & ~__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET))
#else
  #define __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET  0
  #define __Pyx_PyVectorcall_NARGS(n)  ((Py_ssize_t)(n))
#endif
#if PY_VERSION_HEX >= 0x030900B1
#define __Pyx_PyCFunction_CheckExact(func)  PyCFunction_CheckExact(func)
#else
#define __Pyx_PyCFunction_CheckExact(func)  PyCFunction_Check(func)
#endif
#define __Pyx_CyOrPyCFunction_Check(func)  PyCFunction_Check(func)
#if CYTHON_COMPILING_IN_CPYTHON
#define __Pyx_CyOrPyCFunction_GET_FUNCTION(func)  (((PyCFunctionObject*)(func))->m_ml->ml_meth)
#elif !CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_CyOrPyCFunction_GET_FUNCTION(func)  PyCFunction_GET_FUNCTION(func)
#endif
#if CYTHON_COMPILING_IN_CPYTHON
#define __Pyx_CyOrPyCFunction_GET_FLAGS(func)  (((PyCFunctionObject*)(func))->m_ml->ml_flags)
static CYTHON_INLINE PyObject* __Pyx_CyOrPyCFunction_GET_SELF(PyObject *func) {
    return (__Pyx_CyOrPyCFunction_GET_FLAGS(func) & METH_STATIC) ? NULL : ((PyCFunctionObject*)func)->m_self;
}
#endif
static CYTHON_INLINE int __Pyx__IsSameCFunction(PyObject *func, void (*cfunc)(void)) {
#if CYTHON_COMPILING_IN_LIMITED_API
    return PyCFunction_Check(func) && PyCFunction_GetFunction(func) == (PyCFunction) cfunc;
#else
    return PyCFunction_Check(func) && PyCFunction_GET_FUNCTION(func) == (PyCFunction) cfunc;
#endif
}
#define __Pyx_IsSameCFunction(func, cfunc)   __Pyx__IsSameCFunction(func, cfunc)
#if __PYX_LIMITED_VERSION_HEX < 0x03090000
  #define __Pyx_PyType_FromModuleAndSpec(m, s, b)  ((void)m, PyType_FromSpecWithBases(s, b))
  typedef PyObject *(*__Pyx_PyCMethod)(PyObject *, PyTypeObject *, PyObject *const *, size_t, PyObject *);
#else
  #define __Pyx_PyType_FromModuleAndSpec(m, s, b)  PyType_FromModuleAndSpec(m, s, b)
  #define __Pyx_PyCMethod  PyCMethod
#endif
#ifndef METH_METHOD
  #define METH_METHOD 0x200
#endif
#if CYTHON_COMPILING_IN_PYPY && !defined(PyObject_Malloc)
  #define PyObject_Malloc(s)   PyMem_Malloc(s)
  #define PyObject_Free(p)     PyMem_Free(p)
  #define PyObject_Realloc(p)  PyMem_Realloc(p)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_PyFrame_SetLineNumber(frame, lineno)
#elif CYTHON_COMPILING_IN_GRAAL
  #define __Pyx_PyCode_HasFreeVars(co)  (PyCode_GetNumFree(co) > 0)
  #define __Pyx_PyFrame_SetLineNumber(frame, lineno) _PyFrame_SetLineNumber((frame), (lineno))
#else
  #define __Pyx_PyCode_HasFreeVars(co)  (PyCode_GetNumFree(co) > 0)
  #define __Pyx_PyFrame_SetLineNumber(frame, lineno)  (frame)->f_lineno = (lineno)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_PyThreadState_Current PyThreadState_Get()
#elif !CYTHON_FAST_THREAD_STATE
  #define __Pyx_PyThreadState_Current PyThreadState_GET()
#elif PY_VERSION_HEX >= 0x030d00A1
  #define __Pyx_PyThreadState_Current PyThreadState_GetUnchecked()
#else
  #define __Pyx_PyThreadState_Current _PyThreadState_UncheckedGet()
#endif
#if CYTHON_USE_MODULE_STATE
static CYTHON_INLINE void *__Pyx__PyModule_GetState(PyObject *op)
{
    void *result;
    result = PyModule_GetState(op);
    if (!result)
        Py_FatalError("Couldn't find the module state");
    return result;
}
#define __Pyx_PyModule_GetState(o) (__pyx_mstatetype *)__Pyx__PyModule_GetState(o)
#else
#define __Pyx_PyModule_GetState(op) ((void)op,__pyx_mstate_global)
#endif
#define __Pyx_PyObject_GetSlot(obj, name, func_ctype)  __Pyx_PyType_GetSlot(Py_TYPE((PyObject *) obj), name, func_ctype)
#define __Pyx_PyObject_TryGetSlot(obj, name, func_ctype) __Pyx_PyType_TryGetSlot(Py_TYPE(obj), name, func_ctype)
#define __Pyx_PyObject_GetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_GetSubSlot(Py_TYPE(obj), sub, name, func_ctype)
#define __Pyx_PyObject_TryGetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_TryGetSubSlot(Py_TYPE(obj), sub, name, func_ctype)
#if CYTHON_USE_TYPE_SLOTS
  #define __Pyx_PyType_GetSlot(type, name, func_ctype)  ((type)->name)
  #define __Pyx_PyType_TryGetSlot(type, name, func_ctype) __Pyx_PyType_GetSlot(type, name, func_ctype)
  #define __Pyx_PyType_GetSubSlot(type, sub, name, func_ctype) (((type)->sub) ? ((type)->sub->name) : NULL)
  #define __Pyx_PyType_TryGetSubSlot(type, sub, name, func_ctype) __Pyx_PyType_GetSubSlot(type, sub, name, func_ctype)
#else
  #define __Pyx_PyType_GetSlot(type, name, func_ctype)  ((func_ctype) PyType_GetSlot((type), Py_##name))
  #define __Pyx_PyType_TryGetSlot(type, name, func_ctype)\
    ((__PYX_LIMITED_VERSION_HEX >= 0x030A0000 ||\
     (PyType_GetFlags(type) & Py_TPFLAGS_HEAPTYPE) || __Pyx_get_runtime_version() >= 0x030A0000) ?\
     __Pyx_PyType_GetSlot(type, name, func_ctype) : NULL)
  #define __Pyx_PyType_GetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_GetSlot(obj, name, func_ctype)
  #define __Pyx_PyType_TryGetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_TryGetSlot(obj, name, func_ctype)
#endif
#if CYTHON_COMPILING_IN_CPYTHON || defined(_PyDict_NewPresized)
#define __Pyx_PyDict_NewPresized(n)  ((n <= 8) ? PyDict_New() : _PyDict_NewPresized(n))
#else
#define __Pyx_PyDict_NewPresized(n)  PyDict_New()
#endif
#define __Pyx_PyNumber_Divide(x,y)         PyNumber_TrueDivide(x,y)
#define __Pyx_PyNumber_InPlaceDivide(x,y)  PyNumber_InPlaceTrueDivide(x,y)
#if CYTHON_COMPILING_IN_CPYTHON && CYTHON_USE_UNICODE_INTERNALS
#define __Pyx_PyDict_GetItemStrWithError(dict, name)  _PyDict_GetItem_KnownHash(dict, name, ((PyASCIIObject *) name)->hash)
static CYTHON_INLINE PyObject * __Pyx_PyDict_GetItemStr(PyObject *dict, PyObject *name) {
    PyObject *res = __Pyx_PyDict_GetItemStrWithError(dict, name);
    if (res == NULL) PyErr_Clear();
    return res;
}
#elif !CYTHON_COMPILING_IN_PYPY || PYPY_VERSION_NUM >= 0x07020000
#define __Pyx_PyDict_GetItemStrWithError  PyDict_GetItemWithError
#define __Pyx_PyDict_GetItemStr           PyDict_GetItem
#else
static CYTHON_INLINE PyObject * __Pyx_PyDict_GetItemStrWithError(PyObject *dict, PyObject *name) {
#if CYTHON_COMPILING_IN_PYPY
    return PyDict_GetItem(dict, name);
#else
    PyDictEntry *ep;
    PyDictObject *mp = (PyDictObject*) dict;
    long hash = ((PyStringObject *) name)->ob_shash;
    assert(hash != -1);
    ep = (mp->ma_lookup)(mp, name, hash);
    if (ep == NULL) {
        return NULL;
    }
    return ep->me_value;
#endif
}
#define __Pyx_PyDict_GetItemStr           PyDict_GetItem
#endif
#if CYTHON_USE_TYPE_SLOTS
  #define __Pyx_PyType_GetFlags(tp)   (((PyTypeObject *)tp)->tp_flags)
  #define __Pyx_PyType_HasFeature(type, feature)  ((__Pyx_PyType_GetFlags(type) & (feature)) != 0)
#else
  #define __Pyx_PyType_GetFlags(tp)   (PyType_GetFlags((PyTypeObject *)tp))
  #define __Pyx_PyType_HasFeature(type, feature)  PyType_HasFeature(type, feature)
#endif
#define __Pyx_PyObject_GetIterNextFunc(iterator)  __Pyx_PyObject_GetSlot(iterator, tp_iternext, iternextfunc)
#if CYTHON_USE_TYPE_SPECS && PY_VERSION_HEX >= 0x03080000
#define __Pyx_PyHeapTypeObject_GC_Del(obj)  {\
    PyTypeObject *type = Py_TYPE((PyObject*)obj);\
    assert(__Pyx_PyType_HasFeature(type, Py_TPFLAGS_HEAPTYPE));\
    PyObject_GC_Del(obj);\
    Py_DECREF(type);\
}
#else
#define __Pyx_PyHeapTypeObject_GC_Del(obj)  PyObject_GC_Del(obj)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_PyUnicode_READY(op)       (0)
  #define __Pyx_PyUnicode_READ_CHAR(u, i) PyUnicode_ReadChar(u, i)
  #define __Pyx_PyUnicode_MAX_CHAR_VALUE(u)   ((void)u, 1114111U)
  #define __Pyx_PyUnicode_KIND(u)         ((void)u, (0))
  #define __Pyx_PyUnicode_DATA(u)         ((void*)u)
  #define __Pyx_PyUnicode_READ(k, d, i)   ((void)k, PyUnicode_ReadChar((PyObject*)(d), i))
  #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != PyUnicode_GetLength(u))
#else
  #if PY_VERSION_HEX >= 0x030C0000
    #define __Pyx_PyUnicode_READY(op)       (0)
  #else
    #define __Pyx_PyUnicode_READY(op)       (likely(PyUnicode_IS_READY(op)) ?\
                                                0 : _PyUnicode_Ready((PyObject *)(op)))
  #endif
  #define __Pyx_PyUnicode_READ_CHAR(u, i) PyUnicode_READ_CHAR(u, i)
  #define __Pyx_PyUnicode_MAX_CHAR_VALUE(u)   PyUnicode_MAX_CHAR_VALUE(u)
  #define __Pyx_PyUnicode_KIND(u)         ((int)PyUnicode_KIND(u))
  #define __Pyx_PyUnicode_DATA(u)         PyUnicode_DATA(u)
  #define __Pyx_PyUnicode_READ(k, d, i)   PyUnicode_READ(k, d, i)
  #define __Pyx_PyUnicode_WRITE(k, d, i, ch)  PyUnicode_WRITE(k, d, i, (Py_UCS4) ch)
  #if PY_VERSION_HEX >= 0x030C0000
    #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != PyUnicode_GET_LENGTH(u))
  #else
    #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x03090000
    #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != (likely(PyUnicode_IS_READY(u)) ? PyUnicode_GET_LENGTH(u) : ((PyCompactUnicodeObject *)(u))->wstr_length))
    #else
    #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != (likely(PyUnicode_IS_READY(u)) ? PyUnicode_GET_LENGTH(u) : PyUnicode_GET_SIZE(u)))
    #endif
  #endif
#endif
#if CYTHON_COMPILING_IN_PYPY
  #define __Pyx_PyUnicode_Concat(a, b)      PyNumber_Add(a, b)
  #define __Pyx_PyUnicode_ConcatSafe(a, b)  PyNumber_Add(a, b)
#else
  #define __Pyx_PyUnicode_Concat(a, b)      PyUnicode_Concat(a, b)
  #define __Pyx_PyUnicode_ConcatSafe(a, b)  ((unlikely((a) == Py_None) || unlikely((b) == Py_None)) ?\
      PyNumber_Add(a, b) : __Pyx_PyUnicode_Concat(a, b))
#endif
#if CYTHON_COMPILING_IN_PYPY
  #if !defined(PyUnicode_DecodeUnicodeEscape)
    #define PyUnicode_DecodeUnicodeEscape(s, size, errors)  PyUnicode_Decode(s, size, "unicode_escape", errors)
  #endif
  #if !defined(PyUnicode_Contains)
    #define PyUnicode_Contains(u, s)  PySequence_Contains(u, s)
  #endif
  #if !defined(PyByteArray_Check)
    #define PyByteArray_Check(obj)  PyObject_TypeCheck(obj, &PyByteArray_Type)
  #endif
  #if !defined(PyObject_Format)
    #define PyObject_Format(obj, fmt)  PyObject_CallMethod(obj, "__format__", "O", fmt)
  #endif
#endif
#define __Pyx_PyUnicode_FormatSafe(a, b)  ((unlikely((a) == Py_None || (PyUnicode_Check(b) && !PyUnicode_CheckExact(b)))) ? PyNumber_Remainder(a, b) : PyUnicode_Format(a, b))
#if CYTHON_COMPILING_IN_CPYTHON
  #define __Pyx_PySequence_ListKeepNew(obj)\
    (likely(PyList_CheckExact(obj) && Py_REFCNT(obj) == 1) ? __Pyx_NewRef(obj) : PySequence_List(obj))
#else
  #define __Pyx_PySequence_ListKeepNew(obj)  PySequence_List(obj)
#endif
#ifndef PySet_CheckExact
  #define PySet_CheckExact(obj)        __Pyx_IS_TYPE(obj, &PySet_Type)
#endif
#if PY_VERSION_HEX >= 0x030900A4
  #define __Pyx_SET_REFCNT(obj, refcnt) Py_SET_REFCNT(obj, refcnt)
  #define __Pyx_SET_SIZE(obj, size) Py_SET_SIZE(obj, size)
#else
  #define __Pyx_SET_REFCNT(obj, refcnt) Py_REFCNT(obj) = (refcnt)
  #define __Pyx_SET_SIZE(obj, size) Py_SIZE(obj) = (size)
#endif
#if CYTHON_AVOID_BORROWED_REFS || CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
  #if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
    #define __Pyx_PyList_GetItemRef(o, i) PyList_GetItemRef(o, i)
  #elif CYTHON_COMPILING_IN_LIMITED_API || !CYTHON_ASSUME_SAFE_MACROS
    #define __Pyx_PyList_GetItemRef(o, i) (likely((i) >= 0) ? PySequence_GetItem(o, i) : (PyErr_SetString(PyExc_IndexError, "list index out of range"), (PyObject*)NULL))
  #else
    #define __Pyx_PyList_GetItemRef(o, i) PySequence_ITEM(o, i)
  #endif
#elif CYTHON_COMPILING_IN_LIMITED_API || !CYTHON_ASSUME_SAFE_MACROS
  #if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
    #define __Pyx_PyList_GetItemRef(o, i) PyList_GetItemRef(o, i)
  #else
    #define __Pyx_PyList_GetItemRef(o, i) __Pyx_XNewRef(PyList_GetItem(o, i))
  #endif
#else
  #define __Pyx_PyList_GetItemRef(o, i) __Pyx_NewRef(PyList_GET_ITEM(o, i))
#endif
#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
#define __Pyx_PyDict_GetItemRef(dict, key, result) PyDict_GetItemRef(dict, key, result)
#elif CYTHON_AVOID_BORROWED_REFS || CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
static CYTHON_INLINE int __Pyx_PyDict_GetItemRef(PyObject *dict, PyObject *key, PyObject **result) {
  *result = PyObject_GetItem(dict, key);
  if (*result == NULL) {
    if (PyErr_ExceptionMatches(PyExc_KeyError)) {
      PyErr_Clear();
      return 0;
    }
    return -1;
  }
  return 1;
}
#else
static CYTHON_INLINE int __Pyx_PyDict_GetItemRef(PyObject *dict, PyObject *key, PyObject **result) {
  *result = PyDict_GetItemWithError(dict, key);
  if (*result == NULL) {
    return PyErr_Occurred() ? -1 : 0;
  }
  Py_INCREF(*result);
  return 1;
}
#endif
#if defined(CYTHON_DEBUG_VISIT_CONST) && CYTHON_DEBUG_VISIT_CONST
  #define __Pyx_VISIT_CONST(obj)  Py_VISIT(obj)
#else
  #define __Pyx_VISIT_CONST(obj)
#endif
#if CYTHON_ASSUME_SAFE_MACROS
  #define __Pyx_PySequence_ITEM(o, i) PySequence_ITEM(o, i)
  #define __Pyx_PySequence_SIZE(seq)  Py_SIZE(seq)
  #define __Pyx_PyTuple_SET_ITEM(o, i, v) (PyTuple_SET_ITEM(o, i, v), (0))
  #define __Pyx_PyTuple_GET_ITEM(o, i) PyTuple_GET_ITEM(o, i)
  #define __Pyx_PyList_SET_ITEM(o, i, v) (PyList_SET_ITEM(o, i, v), (0))
  #define __Pyx_PyList_GET_ITEM(o, i) PyList_GET_ITEM(o, i)
#else
  #define __Pyx_PySequence_ITEM(o, i) PySequence_GetItem(o, i)
  #define __Pyx_PySequence_SIZE(seq)  PySequence_Size(seq)
  #define __Pyx_PyTuple_SET_ITEM(o, i, v) PyTuple_SetItem(o, i, v)
  #define __Pyx_PyTuple_GET_ITEM(o, i) PyTuple_GetItem(o, i)
  #define __Pyx_PyList_SET_ITEM(o, i, v) PyList_SetItem(o, i, v)
  #define __Pyx_PyList_GET_ITEM(o, i) PyList_GetItem(o, i)
#endif
#if CYTHON_ASSUME_SAFE_SIZE
  #define __Pyx_PyTuple_GET_SIZE(o) PyTuple_GET_SIZE(o)
  #define __Pyx_PyList_GET_SIZE(o) PyList_GET_SIZE(o)
  #define __Pyx_PySet_GET_SIZE(o) PySet_GET_SIZE(o)
  #define __Pyx_PyBytes_GET_SIZE(o) PyBytes_GET_SIZE(o)
  #define __Pyx_PyByteArray_GET_SIZE(o) PyByteArray_GET_SIZE(o)
  #define __Pyx_PyUnicode_GET_LENGTH(o) PyUnicode_GET_LENGTH(o)
#else
  #define __Pyx_PyTuple_GET_SIZE(o) PyTuple_Size(o)
  #define __Pyx_PyList_GET_SIZE(o) PyList_Size(o)
  #define __Pyx_PySet_GET_SIZE(o) PySet_Size(o)
  #define __Pyx_PyBytes_GET_SIZE(o) PyBytes_Size(o)
  #define __Pyx_PyByteArray_GET_SIZE(o) PyByteArray_Size(o)
  #define __Pyx_PyUnicode_GET_LENGTH(o) PyUnicode_GetLength(o)
#endif
#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
  #define __Pyx_PyImport_AddModuleRef(name) PyImport_AddModuleRef(name)
#else
  static CYTHON_INLINE PyObject *__Pyx_PyImport_AddModuleRef(const char *name) {
      PyObject *module = PyImport_AddModule(name);
      Py_XINCREF(module);
      return module;
  }
#endif
#if CYTHON_COMPILING_IN_PYPY && !defined(PyUnicode_InternFromString)
  #define PyUnicode_InternFromString(s) PyUnicode_FromString(s)
#endif
#define __Pyx_PyLong_FromHash_t PyLong_FromSsize_t
#define __Pyx_PyLong_AsHash_t   __Pyx_PyIndex_AsSsize_t
#if __PYX_LIMITED_VERSION_HEX >= 0x030A0000
    #define __Pyx_PySendResult PySendResult
#else
    typedef enum {
        PYGEN_RETURN = 0,
        PYGEN_ERROR = -1,
        PYGEN_NEXT = 1,
    } __Pyx_PySendResult;
#endif
#if CYTHON_COMPILING_IN_LIMITED_API || PY_VERSION_HEX < 0x030A00A3
  typedef __Pyx_PySendResult (*__Pyx_pyiter_sendfunc)(PyObject *iter, PyObject *value, PyObject **result);
#else
  #define __Pyx_pyiter_sendfunc sendfunc
#endif
#if !CYTHON_USE_AM_SEND
#define __PYX_HAS_PY_AM_SEND 0
#elif __PYX_LIMITED_VERSION_HEX >= 0x030A0000
#define __PYX_HAS_PY_AM_SEND 1
#else
#define __PYX_HAS_PY_AM_SEND 2  // our own backported implementation
#endif
#if __PYX_HAS_PY_AM_SEND < 2
    #define __Pyx_PyAsyncMethodsStruct PyAsyncMethods
#else
    typedef struct {
        unaryfunc am_await;
        unaryfunc am_aiter;
        unaryfunc am_anext;
        __Pyx_pyiter_sendfunc am_send;
    } __Pyx_PyAsyncMethodsStruct;
    #define __Pyx_SlotTpAsAsync(s) ((PyAsyncMethods*)(s))
#endif
#if CYTHON_USE_AM_SEND && PY_VERSION_HEX < 0x030A00F0
    #define __Pyx_TPFLAGS_HAVE_AM_SEND (1UL << 21)
#else
    #define __Pyx_TPFLAGS_HAVE_AM_SEND (0)
#endif
#if PY_VERSION_HEX >= 0x03090000
#define __Pyx_PyInterpreterState_Get() PyInterpreterState_Get()
#else
#define __Pyx_PyInterpreterState_Get() PyThreadState_Get()->interp
#endif
#if CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX < 0x030A0000
#ifdef __cplusplus
extern "C"
#endif
PyAPI_FUNC(void *) PyMem_Calloc(size_t nelem, size_t elsize);
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
static int __Pyx_init_co_variable(PyObject *inspect, const char* name, int *write_to) {
    int value;
    PyObject *py_value = PyObject_GetAttrString(inspect, name);
    if (!py_value) return 0;
    value = (int) PyLong_AsLong(py_value);
    Py_DECREF(py_value);
    *write_to = value;
    return value != -1 || !PyErr_Occurred();
}
static int __Pyx_init_co_variables(void) {
    PyObject *inspect;
    int result;
    inspect = PyImport_ImportModule("inspect");
    result =
#if !defined(CO_OPTIMIZED)
        __Pyx_init_co_variable(inspect, "CO_OPTIMIZED", &CO_OPTIMIZED) &&
#endif
#if !defined(CO_NEWLOCALS)
        __Pyx_init_co_variable(inspect, "CO_NEWLOCALS", &CO_NEWLOCALS) &&
#endif
#if !defined(CO_VARARGS)
        __Pyx_init_co_variable(inspect, "CO_VARARGS", &CO_VARARGS) &&
#endif
#if !defined(CO_VARKEYWORDS)
        __Pyx_init_co_variable(inspect, "CO_VARKEYWORDS", &CO_VARKEYWORDS) &&
#endif
#if !defined(CO_ASYNC_GENERATOR)
        __Pyx_init_co_variable(inspect, "CO_ASYNC_GENERATOR", &CO_ASYNC_GENERATOR) &&
#endif
#if !defined(CO_GENERATOR)
        __Pyx_init_co_variable(inspect, "CO_GENERATOR", &CO_GENERATOR) &&
#endif
#if !defined(CO_COROUTINE)
        __Pyx_init_co_variable(inspect, "CO_COROUTINE", &CO_COROUTINE) &&
#endif
        1;
    Py_DECREF(inspect);
    return result ? 0 : -1;
}
#else
static int __Pyx_init_co_variables(void) {
    return 0;  // It's a limited API-only feature
}
#endif


#if defined(_WIN32) || defined(WIN32) || defined(MS_WINDOWS)
  #ifndef _USE_MATH_DEFINES
    #define _USE_MATH_DEFINES
  #endif
#endif
#include <math.h>
#ifdef NAN
#define __PYX_NAN() ((float) NAN)
#else
static CYTHON_INLINE float __PYX_NAN() {
  float value;
  memset(&value, 0xFF, sizeof(value));
  return value;
}
#endif
#if defined(__CYGWIN__) && defined(_LDBL_EQ_DBL)
#define __Pyx_truncl trunc
#else
#define __Pyx_truncl truncl
#endif

#ifndef CYTHON_CLINE_IN_TRACEBACK_RUNTIME
#define CYTHON_CLINE_IN_TRACEBACK_RUNTIME 0
#endif
#ifndef CYTHON_CLINE_IN_TRACEBACK
#define CYTHON_CLINE_IN_TRACEBACK CYTHON_CLINE_IN_TRACEBACK_RUNTIME
#endif
#if CYTHON_CLINE_IN_TRACEBACK
#define __PYX_MARK_ERR_POS(f_index, lineno)  { __pyx_filename = __pyx_f[f_index]; (void) __pyx_filename; __pyx_lineno = lineno; (void) __pyx_lineno; __pyx_clineno = __LINE__; (void) __pyx_clineno; }
#else
#define __PYX_MARK_ERR_POS(f_index, lineno)  { __pyx_filename = __pyx_f[f_index]; (void) __pyx_filename; __pyx_lineno = lineno; (void) __pyx_lineno; (void) __pyx_clineno; }
#endif
#define __PYX_ERR(f_index, lineno, Ln_error) \
    { __PYX_MARK_ERR_POS(f_index, lineno) goto Ln_error; }

#ifdef CYTHON_EXTERN_C
    #undef __PYX_EXTERN_C
    #define __PYX_EXTERN_C CYTHON_EXTERN_C
#elif defined(__PYX_EXTERN_C)
    #ifdef _MSC_VER
    #pragma message ("Please do not define the '__PYX_EXTERN_C' macro externally. Use 'CYTHON_EXTERN_C' instead.")
    #else
    #warning Please do not define the '__PYX_EXTERN_C' macro externally. Use 'CYTHON_EXTERN_C' instead.
    #endif
#else
    #define __PYX_EXTERN_C extern "C++"
#endif

#define __PYX_HAVE__user_agent
#define __PYX_HAVE_API__user_agent

#ifdef _OPENMP
#include <omp.h>
#endif 

#if defined(PYREX_WITHOUT_ASSERTIONS) && !defined(CYTHON_WITHOUT_ASSERTIONS)
#define CYTHON_WITHOUT_ASSERTIONS
#endif

#define __PYX_DEFAULT_STRING_ENCODING_IS_ASCII 0
#define __PYX_DEFAULT_STRING_ENCODING_IS_UTF8 0
#define __PYX_DEFAULT_STRING_ENCODING ""
#define __Pyx_PyObject_FromString __Pyx_PyBytes_FromString
#define __Pyx_PyObject_FromStringAndSize __Pyx_PyBytes_FromStringAndSize
#define __Pyx_uchar_cast(c) ((unsigned char)c)
#define __Pyx_long_cast(x) ((long)x)
#define __Pyx_fits_Py_ssize_t(v, type, is_signed)  (\
    (sizeof(type) < sizeof(Py_ssize_t))  ||\
    (sizeof(type) > sizeof(Py_ssize_t) &&\
          likely(v < (type)PY_SSIZE_T_MAX ||\
                 v == (type)PY_SSIZE_T_MAX)  &&\
          (!is_signed || likely(v > (type)PY_SSIZE_T_MIN ||\
                                v == (type)PY_SSIZE_T_MIN)))  ||\
    (sizeof(type) == sizeof(Py_ssize_t) &&\
          (is_signed || likely(v < (type)PY_SSIZE_T_MAX ||\
                               v == (type)PY_SSIZE_T_MAX)))  )
static CYTHON_INLINE int __Pyx_is_valid_index(Py_ssize_t i, Py_ssize_t limit) {
    return (size_t) i < (size_t) limit;
}
#if defined (__cplusplus) && __cplusplus >= 201103L
    #include <cstdlib>
    #define __Pyx_sst_abs(value) std::abs(value)
#elif SIZEOF_INT >= SIZEOF_SIZE_T
    #define __Pyx_sst_abs(value) abs(value)
#elif SIZEOF_LONG >= SIZEOF_SIZE_T
    #define __Pyx_sst_abs(value) labs(value)
#elif defined (_MSC_VER)
    #define __Pyx_sst_abs(value) ((Py_ssize_t)_abs64(value))
#elif defined (__STDC_VERSION__) && __STDC_VERSION__ >= 199901L
    #define __Pyx_sst_abs(value) llabs(value)
#elif defined (__GNUC__)
    #define __Pyx_sst_abs(value) __builtin_llabs(value)
#else
    #define __Pyx_sst_abs(value) ((value<0) ? -value : value)
#endif
static CYTHON_INLINE Py_ssize_t __Pyx_ssize_strlen(const char *s);
static CYTHON_INLINE const char* __Pyx_PyObject_AsString(PyObject*);
static CYTHON_INLINE const char* __Pyx_PyObject_AsStringAndSize(PyObject*, Py_ssize_t* length);
static CYTHON_INLINE PyObject* __Pyx_PyByteArray_FromString(const char*);
#define __Pyx_PyByteArray_FromStringAndSize(s, l) PyByteArray_FromStringAndSize((const char*)s, l)
#define __Pyx_PyBytes_FromString        PyBytes_FromString
#define __Pyx_PyBytes_FromStringAndSize PyBytes_FromStringAndSize
static CYTHON_INLINE PyObject* __Pyx_PyUnicode_FromString(const char*);
#if CYTHON_ASSUME_SAFE_MACROS
    #define __Pyx_PyBytes_AsWritableString(s)     ((char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsWritableSString(s)    ((signed char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsWritableUString(s)    ((unsigned char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsString(s)     ((const char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsSString(s)    ((const signed char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsUString(s)    ((const unsigned char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyByteArray_AsString(s) PyByteArray_AS_STRING(s)
#else
    #define __Pyx_PyBytes_AsWritableString(s)     ((char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsWritableSString(s)    ((signed char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsWritableUString(s)    ((unsigned char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsString(s)     ((const char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsSString(s)    ((const signed char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsUString(s)    ((const unsigned char*) PyBytes_AsString(s))
    #define __Pyx_PyByteArray_AsString(s) PyByteArray_AsString(s)
#endif
#define __Pyx_PyObject_AsWritableString(s)    ((char*)(__pyx_uintptr_t) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsWritableSString(s)    ((signed char*)(__pyx_uintptr_t) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsWritableUString(s)    ((unsigned char*)(__pyx_uintptr_t) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsSString(s)    ((const signed char*) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsUString(s)    ((const unsigned char*) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_FromCString(s)  __Pyx_PyObject_FromString((const char*)s)
#define __Pyx_PyBytes_FromCString(s)   __Pyx_PyBytes_FromString((const char*)s)
#define __Pyx_PyByteArray_FromCString(s)   __Pyx_PyByteArray_FromString((const char*)s)
#define __Pyx_PyUnicode_FromCString(s) __Pyx_PyUnicode_FromString((const char*)s)
#define __Pyx_PyUnicode_FromOrdinal(o)       PyUnicode_FromOrdinal((int)o)
#define __Pyx_PyUnicode_AsUnicode            PyUnicode_AsUnicode
static CYTHON_INLINE PyObject *__Pyx_NewRef(PyObject *obj) {
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030a0000 || defined(Py_NewRef)
    return Py_NewRef(obj);
#else
    Py_INCREF(obj);
    return obj;
#endif
}
static CYTHON_INLINE PyObject *__Pyx_XNewRef(PyObject *obj) {
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030a0000 || defined(Py_XNewRef)
    return Py_XNewRef(obj);
#else
    Py_XINCREF(obj);
    return obj;
#endif
}
static CYTHON_INLINE PyObject *__Pyx_Owned_Py_None(int b);
static CYTHON_INLINE PyObject * __Pyx_PyBool_FromLong(long b);
static CYTHON_INLINE int __Pyx_PyObject_IsTrue(PyObject*);
static CYTHON_INLINE int __Pyx_PyObject_IsTrueAndDecref(PyObject*);
static CYTHON_INLINE PyObject* __Pyx_PyNumber_Long(PyObject* x);
#define __Pyx_PySequence_Tuple(obj)\
    (likely(PyTuple_CheckExact(obj)) ? __Pyx_NewRef(obj) : PySequence_Tuple(obj))
static CYTHON_INLINE Py_ssize_t __Pyx_PyIndex_AsSsize_t(PyObject*);
static CYTHON_INLINE PyObject * __Pyx_PyLong_FromSize_t(size_t);
static CYTHON_INLINE Py_hash_t __Pyx_PyIndex_AsHash_t(PyObject*);
#if CYTHON_ASSUME_SAFE_MACROS
#define __Pyx_PyFloat_AsDouble(x) (PyFloat_CheckExact(x) ? PyFloat_AS_DOUBLE(x) : PyFloat_AsDouble(x))
#define __Pyx_PyFloat_AS_DOUBLE(x) PyFloat_AS_DOUBLE(x)
#else
#define __Pyx_PyFloat_AsDouble(x) PyFloat_AsDouble(x)
#define __Pyx_PyFloat_AS_DOUBLE(x) PyFloat_AsDouble(x)
#endif
#define __Pyx_PyFloat_AsFloat(x) ((float) __Pyx_PyFloat_AsDouble(x))
#define __Pyx_PyNumber_Int(x) (PyLong_CheckExact(x) ? __Pyx_NewRef(x) : PyNumber_Long(x))
#if CYTHON_USE_PYLONG_INTERNALS
  #if PY_VERSION_HEX >= 0x030C00A7
  #ifndef _PyLong_SIGN_MASK
    #define _PyLong_SIGN_MASK 3
  #endif
  #ifndef _PyLong_NON_SIZE_BITS
    #define _PyLong_NON_SIZE_BITS 3
  #endif
  #define __Pyx_PyLong_Sign(x)  (((PyLongObject*)x)->long_value.lv_tag & _PyLong_SIGN_MASK)
  #define __Pyx_PyLong_IsNeg(x)  ((__Pyx_PyLong_Sign(x) & 2) != 0)
  #define __Pyx_PyLong_IsNonNeg(x)  (!__Pyx_PyLong_IsNeg(x))
  #define __Pyx_PyLong_IsZero(x)  (__Pyx_PyLong_Sign(x) & 1)
  #define __Pyx_PyLong_IsPos(x)  (__Pyx_PyLong_Sign(x) == 0)
  #define __Pyx_PyLong_CompactValueUnsigned(x)  (__Pyx_PyLong_Digits(x)[0])
  #define __Pyx_PyLong_DigitCount(x)  ((Py_ssize_t) (((PyLongObject*)x)->long_value.lv_tag >> _PyLong_NON_SIZE_BITS))
  #define __Pyx_PyLong_SignedDigitCount(x)\
        ((1 - (Py_ssize_t) __Pyx_PyLong_Sign(x)) * __Pyx_PyLong_DigitCount(x))
  #if defined(PyUnstable_Long_IsCompact) && defined(PyUnstable_Long_CompactValue)
    #define __Pyx_PyLong_IsCompact(x)     PyUnstable_Long_IsCompact((PyLongObject*) x)
    #define __Pyx_PyLong_CompactValue(x)  PyUnstable_Long_CompactValue((PyLongObject*) x)
  #else
    #define __Pyx_PyLong_IsCompact(x)     (((PyLongObject*)x)->long_value.lv_tag < (2 << _PyLong_NON_SIZE_BITS))
    #define __Pyx_PyLong_CompactValue(x)  ((1 - (Py_ssize_t) __Pyx_PyLong_Sign(x)) * (Py_ssize_t) __Pyx_PyLong_Digits(x)[0])
  #endif
  typedef Py_ssize_t  __Pyx_compact_pylong;
  typedef size_t  __Pyx_compact_upylong;
  #else
  #define __Pyx_PyLong_IsNeg(x)  (Py_SIZE(x) < 0)
  #define __Pyx_PyLong_IsNonNeg(x)  (Py_SIZE(x) >= 0)
  #define __Pyx_PyLong_IsZero(x)  (Py_SIZE(x) == 0)
  #define __Pyx_PyLong_IsPos(x)  (Py_SIZE(x) > 0)
  #define __Pyx_PyLong_CompactValueUnsigned(x)  ((Py_SIZE(x) == 0) ? 0 : __Pyx_PyLong_Digits(x)[0])
  #define __Pyx_PyLong_DigitCount(x)  __Pyx_sst_abs(Py_SIZE(x))
  #define __Pyx_PyLong_SignedDigitCount(x)  Py_SIZE(x)
  #define __Pyx_PyLong_IsCompact(x)  (Py_SIZE(x) == 0 || Py_SIZE(x) == 1 || Py_SIZE(x) == -1)
  #define __Pyx_PyLong_CompactValue(x)\
        ((Py_SIZE(x) == 0) ? (sdigit) 0 : ((Py_SIZE(x) < 0) ? -(sdigit)__Pyx_PyLong_Digits(x)[0] : (sdigit)__Pyx_PyLong_Digits(x)[0]))
  typedef sdigit  __Pyx_compact_pylong;
  typedef digit  __Pyx_compact_upylong;
  #endif
  #if PY_VERSION_HEX >= 0x030C00A5
  #define __Pyx_PyLong_Digits(x)  (((PyLongObject*)x)->long_value.ob_digit)
  #else
  #define __Pyx_PyLong_Digits(x)  (((PyLongObject*)x)->ob_digit)
  #endif
#endif
#if __PYX_DEFAULT_STRING_ENCODING_IS_UTF8
  #define __Pyx_PyUnicode_FromStringAndSize(c_str, size) PyUnicode_DecodeUTF8(c_str, size, NULL)
#elif __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
  #define __Pyx_PyUnicode_FromStringAndSize(c_str, size) PyUnicode_DecodeASCII(c_str, size, NULL)
#else
  #define __Pyx_PyUnicode_FromStringAndSize(c_str, size) PyUnicode_Decode(c_str, size, __PYX_DEFAULT_STRING_ENCODING, NULL)
#endif



#if defined(__GNUC__)     && (__GNUC__ > 2 || (__GNUC__ == 2 && (__GNUC_MINOR__ > 95)))
  #define likely(x)   __builtin_expect(!!(x), 1)
  #define unlikely(x) __builtin_expect(!!(x), 0)
#else 
  #define likely(x)   (x)
  #define unlikely(x) (x)
#endif 

#ifdef __cplusplus
#if __cplusplus > 201103L
#include <type_traits>
#endif
template <typename T>
static void __Pyx_pretend_to_initialize(T* ptr) {
#if __cplusplus > 201103L
    if ((std::is_trivially_default_constructible<T>::value))
#endif
        *ptr = T();
    (void)ptr;
}
#else
static CYTHON_INLINE void __Pyx_pretend_to_initialize(void* ptr) { (void)ptr; }
#endif


#if !CYTHON_USE_MODULE_STATE
static PyObject *__pyx_m = NULL;
#endif
static int __pyx_lineno;
static int __pyx_clineno = 0;
static const char * const __pyx_cfilenm = __FILE__;
static const char *__pyx_filename;



static const char* const __pyx_f[] = {
  "user_agent.py",
};


#include <pythread.h>
#ifndef CYTHON_ATOMICS
    #define CYTHON_ATOMICS 1
#endif
#define __PYX_CYTHON_ATOMICS_ENABLED() CYTHON_ATOMICS
#define __PYX_GET_CYTHON_COMPILING_IN_CPYTHON_FREETHREADING() CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#define __pyx_atomic_int_type int
#define __pyx_nonatomic_int_type int
#if CYTHON_ATOMICS && (defined(__STDC_VERSION__) &&\
                        (__STDC_VERSION__ >= 201112L) &&\
                        !defined(__STDC_NO_ATOMICS__))
    #include <stdatomic.h>
#elif CYTHON_ATOMICS && (defined(__cplusplus) && (\
                    (__cplusplus >= 201103L) ||\
                    (defined(_MSC_VER) && _MSC_VER >= 1700)))
    #include <atomic>
#endif
#if CYTHON_ATOMICS && (defined(__STDC_VERSION__) &&\
                        (__STDC_VERSION__ >= 201112L) &&\
                        !defined(__STDC_NO_ATOMICS__) &&\
                       ATOMIC_INT_LOCK_FREE == 2)
    #undef __pyx_atomic_int_type
    #define __pyx_atomic_int_type atomic_int
    #define __pyx_atomic_ptr_type atomic_uintptr_t
    #define __pyx_nonatomic_ptr_type uintptr_t
    #define __pyx_atomic_incr_relaxed(value) atomic_fetch_add_explicit(value, 1, memory_order_relaxed)
    #define __pyx_atomic_incr_acq_rel(value) atomic_fetch_add_explicit(value, 1, memory_order_acq_rel)
    #define __pyx_atomic_decr_acq_rel(value) atomic_fetch_sub_explicit(value, 1, memory_order_acq_rel)
    #define __pyx_atomic_sub(value, arg) atomic_fetch_sub(value, arg)
    #define __pyx_atomic_int_cmp_exchange(value, expected, desired) atomic_compare_exchange_strong(value, expected, desired)
    #define __pyx_atomic_load(value) atomic_load(value)
    #define __pyx_atomic_store(value, new_value) atomic_store(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) atomic_load_explicit(value, memory_order_relaxed)
    #define __pyx_atomic_pointer_load_acquire(value) atomic_load_explicit(value, memory_order_acquire)
    #define __pyx_atomic_pointer_exchange(value, new_value) atomic_exchange(value, (__pyx_nonatomic_ptr_type)new_value)
    #if defined(__PYX_DEBUG_ATOMICS) && defined(_MSC_VER)
        #pragma message ("Using standard C atomics")
    #elif defined(__PYX_DEBUG_ATOMICS)
        #warning "Using standard C atomics"
    #endif
#elif CYTHON_ATOMICS && (defined(__cplusplus) && (\
                    (__cplusplus >= 201103L) ||\
\
                    (defined(_MSC_VER) && _MSC_VER >= 1700)) &&\
                    ATOMIC_INT_LOCK_FREE == 2)
    #undef __pyx_atomic_int_type
    #define __pyx_atomic_int_type std::atomic_int
    #define __pyx_atomic_ptr_type std::atomic_uintptr_t
    #define __pyx_nonatomic_ptr_type uintptr_t
    #define __pyx_atomic_incr_relaxed(value) std::atomic_fetch_add_explicit(value, 1, std::memory_order_relaxed)
    #define __pyx_atomic_incr_acq_rel(value) std::atomic_fetch_add_explicit(value, 1, std::memory_order_acq_rel)
    #define __pyx_atomic_decr_acq_rel(value) std::atomic_fetch_sub_explicit(value, 1, std::memory_order_acq_rel)
    #define __pyx_atomic_sub(value, arg) std::atomic_fetch_sub(value, arg)
    #define __pyx_atomic_int_cmp_exchange(value, expected, desired) std::atomic_compare_exchange_strong(value, expected, desired)
    #define __pyx_atomic_load(value) std::atomic_load(value)
    #define __pyx_atomic_store(value, new_value) std::atomic_store(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) std::atomic_load_explicit(value, std::memory_order_relaxed)
    #define __pyx_atomic_pointer_load_acquire(value) std::atomic_load_explicit(value, std::memory_order_acquire)
    #define __pyx_atomic_pointer_exchange(value, new_value) std::atomic_exchange(value, (__pyx_nonatomic_ptr_type)new_value)
    #if defined(__PYX_DEBUG_ATOMICS) && defined(_MSC_VER)
        #pragma message ("Using standard C++ atomics")
    #elif defined(__PYX_DEBUG_ATOMICS)
        #warning "Using standard C++ atomics"
    #endif
#elif CYTHON_ATOMICS && (__GNUC__ >= 5 || (__GNUC__ == 4 &&\
                    (__GNUC_MINOR__ > 1 ||\
                    (__GNUC_MINOR__ == 1 && __GNUC_PATCHLEVEL__ >= 2))))
    #define __pyx_atomic_ptr_type void*
    #define __pyx_atomic_incr_relaxed(value) __sync_fetch_and_add(value, 1)
    #define __pyx_atomic_incr_acq_rel(value) __sync_fetch_and_add(value, 1)
    #define __pyx_atomic_decr_acq_rel(value) __sync_fetch_and_sub(value, 1)
    #define __pyx_atomic_sub(value, arg) __sync_fetch_and_sub(value, arg)
    static CYTHON_INLINE int __pyx_atomic_int_cmp_exchange(__pyx_atomic_int_type* value, __pyx_nonatomic_int_type* expected, __pyx_nonatomic_int_type desired) {
        __pyx_nonatomic_int_type old = __sync_val_compare_and_swap(value, *expected, desired);
        int result = old == *expected;
        *expected = old;
        return result;
    }
    #define __pyx_atomic_load(value) __sync_fetch_and_add(value, 0)
    #define __pyx_atomic_store(value, new_value) __sync_lock_test_and_set(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) __sync_fetch_and_add(value, 0)
    #define __pyx_atomic_pointer_load_acquire(value) __sync_fetch_and_add(value, 0)
    #define __pyx_atomic_pointer_exchange(value, new_value) __sync_lock_test_and_set(value, (__pyx_atomic_ptr_type)new_value)
    #ifdef __PYX_DEBUG_ATOMICS
        #warning "Using GNU atomics"
    #endif
#elif CYTHON_ATOMICS && defined(_MSC_VER)
    #include <intrin.h>
    #undef __pyx_atomic_int_type
    #define __pyx_atomic_int_type long
    #define __pyx_atomic_ptr_type void*
    #undef __pyx_nonatomic_int_type
    #define __pyx_nonatomic_int_type long
    #pragma intrinsic (_InterlockedExchangeAdd, _InterlockedExchange, _InterlockedCompareExchange, _InterlockedCompareExchangePointer, _InterlockedExchangePointer)
    #define __pyx_atomic_incr_relaxed(value) _InterlockedExchangeAdd(value, 1)
    #define __pyx_atomic_incr_acq_rel(value) _InterlockedExchangeAdd(value, 1)
    #define __pyx_atomic_decr_acq_rel(value) _InterlockedExchangeAdd(value, -1)
    #define __pyx_atomic_sub(value, arg) _InterlockedExchangeAdd(value, -arg)
    static CYTHON_INLINE int __pyx_atomic_int_cmp_exchange(__pyx_atomic_int_type* value, __pyx_nonatomic_int_type* expected, __pyx_nonatomic_int_type desired) {
        __pyx_nonatomic_int_type old = _InterlockedCompareExchange(value, desired, *expected);
        int result = old == *expected;
        *expected = old;
        return result;
    }
    #define __pyx_atomic_load(value) _InterlockedExchangeAdd(value, 0)
    #define __pyx_atomic_store(value, new_value) _InterlockedExchange(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) *(void * volatile *)value
    #define __pyx_atomic_pointer_load_acquire(value) _InterlockedCompareExchangePointer(value, 0, 0)
    #define __pyx_atomic_pointer_exchange(value, new_value) _InterlockedExchangePointer(value, (__pyx_atomic_ptr_type)new_value)
    #ifdef __PYX_DEBUG_ATOMICS
        #pragma message ("Using MSVC atomics")
    #endif
#else
    #undef CYTHON_ATOMICS
    #define CYTHON_ATOMICS 0
    #ifdef __PYX_DEBUG_ATOMICS
        #warning "Not using atomics"
    #endif
#endif
#if CYTHON_ATOMICS
    #define __pyx_add_acquisition_count(memview)\
             __pyx_atomic_incr_relaxed(__pyx_get_slice_count_pointer(memview))
    #define __pyx_sub_acquisition_count(memview)\
            __pyx_atomic_decr_acq_rel(__pyx_get_slice_count_pointer(memview))
#else
    #define __pyx_add_acquisition_count(memview)\
            __pyx_add_acquisition_count_locked(__pyx_get_slice_count_pointer(memview), memview->lock)
    #define __pyx_sub_acquisition_count(memview)\
            __pyx_sub_acquisition_count_locked(__pyx_get_slice_count_pointer(memview), memview->lock)
#endif


#include <structmember.h>


#if !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#define __Pyx_PyCriticalSection void*
#define __Pyx_PyCriticalSection2 void*
#define __Pyx_PyCriticalSection_Begin1(cs, arg) (void)cs
#define __Pyx_PyCriticalSection_Begin2(cs, arg1, arg2) (void)cs
#define __Pyx_PyCriticalSection_End1(cs)
#define __Pyx_PyCriticalSection_End2(cs)
#else
#define __Pyx_PyCriticalSection PyCriticalSection
#define __Pyx_PyCriticalSection2 PyCriticalSection2
#define __Pyx_PyCriticalSection_Begin1 PyCriticalSection_Begin
#define __Pyx_PyCriticalSection_Begin2 PyCriticalSection2_Begin
#define __Pyx_PyCriticalSection_End1 PyCriticalSection_End
#define __Pyx_PyCriticalSection_End2 PyCriticalSection2_End
#endif
#if PY_VERSION_HEX < 0x030d0000 || CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_BEGIN_CRITICAL_SECTION(o) {
#define __Pyx_END_CRITICAL_SECTION() }
#else
#define __Pyx_BEGIN_CRITICAL_SECTION Py_BEGIN_CRITICAL_SECTION
#define __Pyx_END_CRITICAL_SECTION Py_END_CRITICAL_SECTION
#endif










#ifndef CYTHON_REFNANNY
  #define CYTHON_REFNANNY 0
#endif
#if CYTHON_REFNANNY
  typedef struct {
    void (*INCREF)(void*, PyObject*, Py_ssize_t);
    void (*DECREF)(void*, PyObject*, Py_ssize_t);
    void (*GOTREF)(void*, PyObject*, Py_ssize_t);
    void (*GIVEREF)(void*, PyObject*, Py_ssize_t);
    void* (*SetupContext)(const char*, Py_ssize_t, const char*);
    void (*FinishContext)(void**);
  } __Pyx_RefNannyAPIStruct;
  static __Pyx_RefNannyAPIStruct *__Pyx_RefNanny = NULL;
  static __Pyx_RefNannyAPIStruct *__Pyx_RefNannyImportAPI(const char *modname);
  #define __Pyx_RefNannyDeclarations void *__pyx_refnanny = NULL;
  #define __Pyx_RefNannySetupContext(name, acquire_gil)\
          if (acquire_gil) {\
              PyGILState_STATE __pyx_gilstate_save = PyGILState_Ensure();\
              __pyx_refnanny = __Pyx_RefNanny->SetupContext((name), (__LINE__), (__FILE__));\
              PyGILState_Release(__pyx_gilstate_save);\
          } else {\
              __pyx_refnanny = __Pyx_RefNanny->SetupContext((name), (__LINE__), (__FILE__));\
          }
  #define __Pyx_RefNannyFinishContextNogil() {\
              PyGILState_STATE __pyx_gilstate_save = PyGILState_Ensure();\
              __Pyx_RefNannyFinishContext();\
              PyGILState_Release(__pyx_gilstate_save);\
          }
  #define __Pyx_RefNannyFinishContextNogil() {\
              PyGILState_STATE __pyx_gilstate_save = PyGILState_Ensure();\
              __Pyx_RefNannyFinishContext();\
              PyGILState_Release(__pyx_gilstate_save);\
          }
  #define __Pyx_RefNannyFinishContext()\
          __Pyx_RefNanny->FinishContext(&__pyx_refnanny)
  #define __Pyx_INCREF(r)  __Pyx_RefNanny->INCREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_DECREF(r)  __Pyx_RefNanny->DECREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_GOTREF(r)  __Pyx_RefNanny->GOTREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_GIVEREF(r) __Pyx_RefNanny->GIVEREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_XINCREF(r)  do { if((r) == NULL); else {__Pyx_INCREF(r); }} while(0)
  #define __Pyx_XDECREF(r)  do { if((r) == NULL); else {__Pyx_DECREF(r); }} while(0)
  #define __Pyx_XGOTREF(r)  do { if((r) == NULL); else {__Pyx_GOTREF(r); }} while(0)
  #define __Pyx_XGIVEREF(r) do { if((r) == NULL); else {__Pyx_GIVEREF(r);}} while(0)
#else
  #define __Pyx_RefNannyDeclarations
  #define __Pyx_RefNannySetupContext(name, acquire_gil)
  #define __Pyx_RefNannyFinishContextNogil()
  #define __Pyx_RefNannyFinishContext()
  #define __Pyx_INCREF(r) Py_INCREF(r)
  #define __Pyx_DECREF(r) Py_DECREF(r)
  #define __Pyx_GOTREF(r)
  #define __Pyx_GIVEREF(r)
  #define __Pyx_XINCREF(r) Py_XINCREF(r)
  #define __Pyx_XDECREF(r) Py_XDECREF(r)
  #define __Pyx_XGOTREF(r)
  #define __Pyx_XGIVEREF(r)
#endif
#define __Pyx_Py_XDECREF_SET(r, v) do {\
        PyObject *tmp = (PyObject *) r;\
        r = v; Py_XDECREF(tmp);\
    } while (0)
#define __Pyx_XDECREF_SET(r, v) do {\
        PyObject *tmp = (PyObject *) r;\
        r = v; __Pyx_XDECREF(tmp);\
    } while (0)
#define __Pyx_DECREF_SET(r, v) do {\
        PyObject *tmp = (PyObject *) r;\
        r = v; __Pyx_DECREF(tmp);\
    } while (0)
#define __Pyx_CLEAR(r)    do { PyObject* tmp = ((PyObject*)(r)); r = NULL; __Pyx_DECREF(tmp);} while(0)
#define __Pyx_XCLEAR(r)   do { if((r) != NULL) {PyObject* tmp = ((PyObject*)(r)); r = NULL; __Pyx_DECREF(tmp);}} while(0)


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_PyErr_ExceptionMatches(err) __Pyx_PyErr_ExceptionMatchesInState(__pyx_tstate, err)
static CYTHON_INLINE int __Pyx_PyErr_ExceptionMatchesInState(PyThreadState* tstate, PyObject* err);
#else
#define __Pyx_PyErr_ExceptionMatches(err)  PyErr_ExceptionMatches(err)
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_PyThreadState_declare  PyThreadState *__pyx_tstate;
#define __Pyx_PyThreadState_assign  __pyx_tstate = __Pyx_PyThreadState_Current;
#if PY_VERSION_HEX >= 0x030C00A6
#define __Pyx_PyErr_Occurred()  (__pyx_tstate->current_exception != NULL)
#define __Pyx_PyErr_CurrentExceptionType()  (__pyx_tstate->current_exception ? (PyObject*) Py_TYPE(__pyx_tstate->current_exception) : (PyObject*) NULL)
#else
#define __Pyx_PyErr_Occurred()  (__pyx_tstate->curexc_type != NULL)
#define __Pyx_PyErr_CurrentExceptionType()  (__pyx_tstate->curexc_type)
#endif
#else
#define __Pyx_PyThreadState_declare
#define __Pyx_PyThreadState_assign
#define __Pyx_PyErr_Occurred()  (PyErr_Occurred() != NULL)
#define __Pyx_PyErr_CurrentExceptionType()  PyErr_Occurred()
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_PyErr_Clear() __Pyx_ErrRestore(NULL, NULL, NULL)
#define __Pyx_ErrRestoreWithState(type, value, tb)  __Pyx_ErrRestoreInState(PyThreadState_GET(), type, value, tb)
#define __Pyx_ErrFetchWithState(type, value, tb)    __Pyx_ErrFetchInState(PyThreadState_GET(), type, value, tb)
#define __Pyx_ErrRestore(type, value, tb)  __Pyx_ErrRestoreInState(__pyx_tstate, type, value, tb)
#define __Pyx_ErrFetch(type, value, tb)    __Pyx_ErrFetchInState(__pyx_tstate, type, value, tb)
static CYTHON_INLINE void __Pyx_ErrRestoreInState(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb);
static CYTHON_INLINE void __Pyx_ErrFetchInState(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb);
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX < 0x030C00A6
#define __Pyx_PyErr_SetNone(exc) (Py_INCREF(exc), __Pyx_ErrRestore((exc), NULL, NULL))
#else
#define __Pyx_PyErr_SetNone(exc) PyErr_SetNone(exc)
#endif
#else
#define __Pyx_PyErr_Clear() PyErr_Clear()
#define __Pyx_PyErr_SetNone(exc) PyErr_SetNone(exc)
#define __Pyx_ErrRestoreWithState(type, value, tb)  PyErr_Restore(type, value, tb)
#define __Pyx_ErrFetchWithState(type, value, tb)  PyErr_Fetch(type, value, tb)
#define __Pyx_ErrRestoreInState(tstate, type, value, tb)  PyErr_Restore(type, value, tb)
#define __Pyx_ErrFetchInState(tstate, type, value, tb)  PyErr_Fetch(type, value, tb)
#define __Pyx_ErrRestore(type, value, tb)  PyErr_Restore(type, value, tb)
#define __Pyx_ErrFetch(type, value, tb)  PyErr_Fetch(type, value, tb)
#endif


#if CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStr(PyObject* obj, PyObject* attr_name);
#else
#define __Pyx_PyObject_GetAttrStr(o,n) PyObject_GetAttr(o,n)
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStrNoError(PyObject* obj, PyObject* attr_name);


static PyObject *__Pyx_GetBuiltinName(PyObject *name);


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyList_FromArray(PyObject *const *src, Py_ssize_t n);
#endif
#if CYTHON_COMPILING_IN_CPYTHON || CYTHON_METH_FASTCALL
static CYTHON_INLINE PyObject* __Pyx_PyTuple_FromArray(PyObject *const *src, Py_ssize_t n);
#endif


#include <string.h>


static CYTHON_INLINE int __Pyx_PyBytes_Equals(PyObject* s1, PyObject* s2, int equals);


static CYTHON_INLINE int __Pyx_PyUnicode_Equals(PyObject* s1, PyObject* s2, int equals);


#if CYTHON_AVOID_BORROWED_REFS
    #define __Pyx_ArgRef_VARARGS(args, i) __Pyx_PySequence_ITEM(args, i)
#elif CYTHON_ASSUME_SAFE_MACROS
    #define __Pyx_ArgRef_VARARGS(args, i) __Pyx_NewRef(__Pyx_PyTuple_GET_ITEM(args, i))
#else
    #define __Pyx_ArgRef_VARARGS(args, i) __Pyx_XNewRef(PyTuple_GetItem(args, i))
#endif
#define __Pyx_NumKwargs_VARARGS(kwds) PyDict_Size(kwds)
#define __Pyx_KwValues_VARARGS(args, nargs) NULL
#define __Pyx_GetKwValue_VARARGS(kw, kwvalues, s) __Pyx_PyDict_GetItemStrWithError(kw, s)
#define __Pyx_KwargsAsDict_VARARGS(kw, kwvalues) PyDict_Copy(kw)
#if CYTHON_METH_FASTCALL
    #define __Pyx_ArgRef_FASTCALL(args, i) __Pyx_NewRef(args[i])
    #define __Pyx_NumKwargs_FASTCALL(kwds) __Pyx_PyTuple_GET_SIZE(kwds)
    #define __Pyx_KwValues_FASTCALL(args, nargs) ((args) + (nargs))
    static CYTHON_INLINE PyObject * __Pyx_GetKwValue_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues, PyObject *s);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030d0000 || CYTHON_COMPILING_IN_LIMITED_API
    CYTHON_UNUSED static PyObject *__Pyx_KwargsAsDict_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues);
  #else
    #define __Pyx_KwargsAsDict_FASTCALL(kw, kwvalues) _PyStack_AsDict(kwvalues, kw)
  #endif
#else
    #define __Pyx_ArgRef_FASTCALL __Pyx_ArgRef_VARARGS
    #define __Pyx_NumKwargs_FASTCALL __Pyx_NumKwargs_VARARGS
    #define __Pyx_KwValues_FASTCALL __Pyx_KwValues_VARARGS
    #define __Pyx_GetKwValue_FASTCALL __Pyx_GetKwValue_VARARGS
    #define __Pyx_KwargsAsDict_FASTCALL __Pyx_KwargsAsDict_VARARGS
#endif
#define __Pyx_ArgsSlice_VARARGS(args, start, stop) PyTuple_GetSlice(args, start, stop)
#if CYTHON_METH_FASTCALL || (CYTHON_COMPILING_IN_CPYTHON && CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS)
#define __Pyx_ArgsSlice_FASTCALL(args, start, stop) __Pyx_PyTuple_FromArray(args + start, stop - start)
#else
#define __Pyx_ArgsSlice_FASTCALL(args, start, stop) PyTuple_GetSlice(args, start, stop)
#endif


static void __Pyx_RaiseDoubleKeywordsError(const char* func_name, PyObject* kw_name);


static CYTHON_INLINE int __Pyx_ParseKeywords(
    PyObject *kwds, PyObject *const *kwvalues, PyObject ** const argnames[],
    PyObject *kwds2, PyObject *values[],
    Py_ssize_t num_pos_args, Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs
);


#define __Pyx_CallCFunction(cfunc, self, args)\
    ((PyCFunction)(void(*)(void))(cfunc)->func)(self, args)
#define __Pyx_CallCFunctionWithKeywords(cfunc, self, args, kwargs)\
    ((PyCFunctionWithKeywords)(void(*)(void))(cfunc)->func)(self, args, kwargs)
#define __Pyx_CallCFunctionFast(cfunc, self, args, nargs)\
    ((__Pyx_PyCFunctionFast)(void(*)(void))(PyCFunction)(cfunc)->func)(self, args, nargs)
#define __Pyx_CallCFunctionFastWithKeywords(cfunc, self, args, nargs, kwnames)\
    ((__Pyx_PyCFunctionFastWithKeywords)(void(*)(void))(PyCFunction)(cfunc)->func)(self, args, nargs, kwnames)


#if CYTHON_FAST_PYCALL
#if !CYTHON_VECTORCALL
#define __Pyx_PyFunction_FastCall(func, args, nargs)\
    __Pyx_PyFunction_FastCallDict((func), (args), (nargs), NULL)
static PyObject *__Pyx_PyFunction_FastCallDict(PyObject *func, PyObject *const *args, Py_ssize_t nargs, PyObject *kwargs);
#endif
#define __Pyx_BUILD_ASSERT_EXPR(cond)\
    (sizeof(char [1 - 2*!(cond)]) - 1)
#ifndef Py_MEMBER_SIZE
#define Py_MEMBER_SIZE(type, member) sizeof(((type *)0)->member)
#endif
#if !CYTHON_VECTORCALL
#if PY_VERSION_HEX >= 0x03080000
  #include "frameobject.h"
  #define __Pxy_PyFrame_Initialize_Offsets()
  #define __Pyx_PyFrame_GetLocalsplus(frame)  ((frame)->f_localsplus)
#else
  static size_t __pyx_pyframe_localsplus_offset = 0;
  #include "frameobject.h"
  #define __Pxy_PyFrame_Initialize_Offsets()\
    ((void)__Pyx_BUILD_ASSERT_EXPR(sizeof(PyFrameObject) == offsetof(PyFrameObject, f_localsplus) + Py_MEMBER_SIZE(PyFrameObject, f_localsplus)),\
     (void)(__pyx_pyframe_localsplus_offset = ((size_t)PyFrame_Type.tp_basicsize) - Py_MEMBER_SIZE(PyFrameObject, f_localsplus)))
  #define __Pyx_PyFrame_GetLocalsplus(frame)\
    (assert(__pyx_pyframe_localsplus_offset), (PyObject **)(((char *)(frame)) + __pyx_pyframe_localsplus_offset))
#endif
#endif
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_Call(PyObject *func, PyObject *arg, PyObject *kw);
#else
#define __Pyx_PyObject_Call(func, arg, kw) PyObject_Call(func, arg, kw)
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethO(PyObject *func, PyObject *arg);
#endif


#define __Pyx_PyObject_FastCall(func, args, nargs)  __Pyx_PyObject_FastCallDict(func, args, (size_t)(nargs), NULL)
static CYTHON_INLINE PyObject* __Pyx_PyObject_FastCallDict(PyObject *func, PyObject * const*args, size_t nargs, PyObject *kwargs);


typedef struct {
    PyObject *type;
    PyObject **method_name;
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && CYTHON_ATOMICS
    __pyx_atomic_int_type initialized;
#endif
    PyCFunction func;
    PyObject *method;
    int flag;
} __Pyx_CachedCFunction;
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
static CYTHON_INLINE int __Pyx_CachedCFunction_GetAndSetInitializing(__Pyx_CachedCFunction *cfunc) {
#if !CYTHON_ATOMICS
    return 1;
#else
    __pyx_nonatomic_int_type expected = 0;
    if (__pyx_atomic_int_cmp_exchange(&cfunc->initialized, &expected, 1)) {
        return 0;
    }
    return expected;
#endif
}
static CYTHON_INLINE void __Pyx_CachedCFunction_SetFinishedInitializing(__Pyx_CachedCFunction *cfunc) {
#if CYTHON_ATOMICS
    __pyx_atomic_store(&cfunc->initialized, 2);
#endif
}
#else
#define __Pyx_CachedCFunction_GetAndSetInitializing(cfunc) 2
#define __Pyx_CachedCFunction_SetFinishedInitializing(cfunc)
#endif


CYTHON_UNUSED
static PyObject* __Pyx__CallUnboundCMethod2(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg1, PyObject* arg2);
#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject *__Pyx_CallUnboundCMethod2(__Pyx_CachedCFunction *cfunc, PyObject *self, PyObject *arg1, PyObject *arg2);
#else
#define __Pyx_CallUnboundCMethod2(cfunc, self, arg1, arg2)  __Pyx__CallUnboundCMethod2(cfunc, self, arg1, arg2)
#endif


static void __Pyx_RaiseArgtupleInvalid(const char* func_name, int exact,
    Py_ssize_t num_min, Py_ssize_t num_max, Py_ssize_t num_found);


static PyObject* __Pyx_PyDict_GetItemDefault(PyObject* d, PyObject* key, PyObject* default_value);


static CYTHON_INLINE PyObject* __Pyx_PyObject_Call2Args(PyObject* function, PyObject* arg1, PyObject* arg2);


CYTHON_UNUSED
static PyObject* __Pyx__CallUnboundCMethod1(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg);
#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_CallUnboundCMethod1(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg);
#else
#define __Pyx_CallUnboundCMethod1(cfunc, self, arg)  __Pyx__CallUnboundCMethod1(cfunc, self, arg)
#endif


#if CYTHON_VECTORCALL && PY_VERSION_HEX >= 0x03090000
#define __Pyx_PyObject_FastCallMethod(name, args, nargsf) PyObject_VectorcallMethod(name, args, nargsf, NULL)
#else
static PyObject *__Pyx_PyObject_FastCallMethod(PyObject *name, PyObject *const *args, size_t nargsf);
#endif


#if CYTHON_USE_DICT_VERSIONS && CYTHON_USE_TYPE_SLOTS
#define __PYX_DICT_VERSION_INIT  ((PY_UINT64_T) -1)
#define __PYX_GET_DICT_VERSION(dict)  (((PyDictObject*)(dict))->ma_version_tag)
#define __PYX_UPDATE_DICT_CACHE(dict, value, cache_var, version_var)\
    (version_var) = __PYX_GET_DICT_VERSION(dict);\
    (cache_var) = (value);
#define __PYX_PY_DICT_LOOKUP_IF_MODIFIED(VAR, DICT, LOOKUP) {\
    static PY_UINT64_T __pyx_dict_version = 0;\
    static PyObject *__pyx_dict_cached_value = NULL;\
    if (likely(__PYX_GET_DICT_VERSION(DICT) == __pyx_dict_version)) {\
        (VAR) = __pyx_dict_cached_value;\
    } else {\
        (VAR) = __pyx_dict_cached_value = (LOOKUP);\
        __pyx_dict_version = __PYX_GET_DICT_VERSION(DICT);\
    }\
}
static CYTHON_INLINE PY_UINT64_T __Pyx_get_tp_dict_version(PyObject *obj);
static CYTHON_INLINE PY_UINT64_T __Pyx_get_object_dict_version(PyObject *obj);
static CYTHON_INLINE int __Pyx_object_dict_version_matches(PyObject* obj, PY_UINT64_T tp_dict_version, PY_UINT64_T obj_dict_version);
#else
#define __PYX_GET_DICT_VERSION(dict)  (0)
#define __PYX_UPDATE_DICT_CACHE(dict, value, cache_var, version_var)
#define __PYX_PY_DICT_LOOKUP_IF_MODIFIED(VAR, DICT, LOOKUP)  (VAR) = (LOOKUP);
#endif


#if CYTHON_USE_DICT_VERSIONS
#define __Pyx_GetModuleGlobalName(var, name)  do {\
    static PY_UINT64_T __pyx_dict_version = 0;\
    static PyObject *__pyx_dict_cached_value = NULL;\
    (var) = (likely(__pyx_dict_version == __PYX_GET_DICT_VERSION(__pyx_mstate_global->__pyx_d))) ?\
        (likely(__pyx_dict_cached_value) ? __Pyx_NewRef(__pyx_dict_cached_value) : __Pyx_GetBuiltinName(name)) :\
        __Pyx__GetModuleGlobalName(name, &__pyx_dict_version, &__pyx_dict_cached_value);\
} while(0)
#define __Pyx_GetModuleGlobalNameUncached(var, name)  do {\
    PY_UINT64_T __pyx_dict_version;\
    PyObject *__pyx_dict_cached_value;\
    (var) = __Pyx__GetModuleGlobalName(name, &__pyx_dict_version, &__pyx_dict_cached_value);\
} while(0)
static PyObject *__Pyx__GetModuleGlobalName(PyObject *name, PY_UINT64_T *dict_version, PyObject **dict_cached_value);
#else
#define __Pyx_GetModuleGlobalName(var, name)  (var) = __Pyx__GetModuleGlobalName(name)
#define __Pyx_GetModuleGlobalNameUncached(var, name)  (var) = __Pyx__GetModuleGlobalName(name)
static CYTHON_INLINE PyObject *__Pyx__GetModuleGlobalName(PyObject *name);
#endif


#if CYTHON_USE_EXC_INFO_STACK && CYTHON_FAST_THREAD_STATE
static _PyErr_StackItem * __Pyx_PyErr_GetTopmostException(PyThreadState *tstate);
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_ExceptionSave(type, value, tb)  __Pyx__ExceptionSave(__pyx_tstate, type, value, tb)
static CYTHON_INLINE void __Pyx__ExceptionSave(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb);
#define __Pyx_ExceptionReset(type, value, tb)  __Pyx__ExceptionReset(__pyx_tstate, type, value, tb)
static CYTHON_INLINE void __Pyx__ExceptionReset(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb);
#else
#define __Pyx_ExceptionSave(type, value, tb)   PyErr_GetExcInfo(type, value, tb)
#define __Pyx_ExceptionReset(type, value, tb)  PyErr_SetExcInfo(type, value, tb)
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_GetException(type, value, tb)  __Pyx__GetException(__pyx_tstate, type, value, tb)
static int __Pyx__GetException(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb);
#else
static int __Pyx_GetException(PyObject **type, PyObject **value, PyObject **tb);
#endif


#if !CYTHON_COMPILING_IN_PYPY
static CYTHON_INLINE PyObject* __Pyx_PyLong_SubtractObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check);
#else
#define __Pyx_PyLong_SubtractObjC(op1, op2, intval, inplace, zerodivision_check)\
    (inplace ? PyNumber_InPlaceSubtract(op1, op2) : PyNumber_Subtract(op1, op2))
#endif


CYTHON_UNUSED static int __Pyx_VectorcallBuilder_AddArg_Check(PyObject *key, PyObject *value, PyObject *builder, PyObject **args, int n);
#if CYTHON_VECTORCALL
#if PY_VERSION_HEX >= 0x03090000
#define __Pyx_Object_Vectorcall_CallFromBuilder PyObject_Vectorcall
#else
#define __Pyx_Object_Vectorcall_CallFromBuilder _PyObject_Vectorcall
#endif
#define __Pyx_MakeVectorcallBuilderKwds(n) PyTuple_New(n)
static int __Pyx_VectorcallBuilder_AddArg(PyObject *key, PyObject *value, PyObject *builder, PyObject **args, int n);
static int __Pyx_VectorcallBuilder_AddArgStr(const char *key, PyObject *value, PyObject *builder, PyObject **args, int n);
#else
#define __Pyx_Object_Vectorcall_CallFromBuilder __Pyx_PyObject_FastCallDict
#define __Pyx_MakeVectorcallBuilderKwds(n) __Pyx_PyDict_NewPresized(n)
#define __Pyx_VectorcallBuilder_AddArg(key, value, builder, args, n) PyDict_SetItem(builder, key, value)
#define __Pyx_VectorcallBuilder_AddArgStr(key, value, builder, args, n) PyDict_SetItemString(builder, key, value)
#endif


#if CYTHON_COMPILING_IN_PYPY
    #define __Pyx_PyObject_FormatSimple(s, f) (\
        likely(PyUnicode_CheckExact(s)) ? (Py_INCREF(s), s) :\
        PyObject_Format(s, f))
#elif CYTHON_USE_TYPE_SLOTS
    #define __Pyx_PyObject_FormatSimple(s, f) (\
        likely(PyUnicode_CheckExact(s)) ? (Py_INCREF(s), s) :\
        likely(PyLong_CheckExact(s)) ? PyLong_Type.tp_repr(s) :\
        likely(PyFloat_CheckExact(s)) ? PyFloat_Type.tp_repr(s) :\
        PyObject_Format(s, f))
#else
    #define __Pyx_PyObject_FormatSimple(s, f) (\
        likely(PyUnicode_CheckExact(s)) ? (Py_INCREF(s), s) :\
        PyObject_Format(s, f))
#endif


static PyObject* __Pyx_PyUnicode_Join(PyObject** values, Py_ssize_t value_count, Py_ssize_t result_ulength,
                                      Py_UCS4 max_char);


#if CYTHON_USE_PYTYPE_LOOKUP && CYTHON_USE_TYPE_SLOTS
#define __Pyx_PyObject_LookupSpecialNoError(obj, attr_name)  __Pyx__PyObject_LookupSpecial(obj, attr_name, 0)
#define __Pyx_PyObject_LookupSpecial(obj, attr_name)  __Pyx__PyObject_LookupSpecial(obj, attr_name, 1)
static CYTHON_INLINE PyObject* __Pyx__PyObject_LookupSpecial(PyObject* obj, PyObject* attr_name, int with_error);
#else
#define __Pyx_PyObject_LookupSpecialNoError(o,n) __Pyx_PyObject_GetAttrStrNoError(o,n)
#define __Pyx_PyObject_LookupSpecial(o,n) __Pyx_PyObject_GetAttrStr(o,n)
#endif


#if CYTHON_USE_PYLIST_INTERNALS && CYTHON_ASSUME_SAFE_MACROS
static CYTHON_INLINE int __Pyx_ListComp_Append(PyObject* list, PyObject* x) {
    PyListObject* L = (PyListObject*) list;
    Py_ssize_t len = Py_SIZE(list);
    if (likely(L->allocated > len)) {
        Py_INCREF(x);
        #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030d0000
        L->ob_item[len] = x;
        #else
        PyList_SET_ITEM(list, len, x);
        #endif
        __Pyx_SET_SIZE(list, len + 1);
        return 0;
    }
    return PyList_Append(list, x);
}
#else
#define __Pyx_ListComp_Append(L,x) PyList_Append(L,x)
#endif


static void __Pyx_RaiseUnboundLocalError(const char *varname);


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_ExceptionSwap(type, value, tb)  __Pyx__ExceptionSwap(__pyx_tstate, type, value, tb)
static CYTHON_INLINE void __Pyx__ExceptionSwap(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb);
#else
static CYTHON_INLINE void __Pyx_ExceptionSwap(PyObject **type, PyObject **value, PyObject **tb);
#endif


static CYTHON_INLINE int __Pyx_PyDict_ContainsTF(PyObject* item, PyObject* dict, int eq) {
    int result = PyDict_Contains(dict, item);
    return unlikely(result < 0) ? result : (result == (eq == Py_EQ));
}


#if CYTHON_USE_PYLIST_INTERNALS && CYTHON_ASSUME_SAFE_MACROS
static CYTHON_INLINE int __Pyx_PyList_Append(PyObject* list, PyObject* x) {
    PyListObject* L = (PyListObject*) list;
    Py_ssize_t len = Py_SIZE(list);
    if (likely(L->allocated > len) & likely(len > (L->allocated >> 1))) {
        Py_INCREF(x);
        #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030d0000
        L->ob_item[len] = x;
        #else
        PyList_SET_ITEM(list, len, x);
        #endif
        __Pyx_SET_SIZE(list, len + 1);
        return 0;
    }
    return PyList_Append(list, x);
}
#else
#define __Pyx_PyList_Append(L,x) PyList_Append(L,x)
#endif


static CYTHON_INLINE PyObject* __Pyx_PyDict_Keys(PyObject* d);


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallOneArg(PyObject *func, PyObject *arg);


CYTHON_UNUSED
static PyObject* __Pyx__CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self);
#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self);
#else
#define __Pyx_CallUnboundCMethod0(cfunc, self)  __Pyx__CallUnboundCMethod0(cfunc, self)
#endif


static CYTHON_INLINE PyObject* __Pyx_PyUnicode_Unicode(PyObject *obj);


static int __Pyx_RaiseUnexpectedTypeError(const char *expected, PyObject *obj);


#if !CYTHON_COMPILING_IN_PYPY
static PyObject *__Pyx_PyDict_GetItem(PyObject *d, PyObject* key);
#define __Pyx_PyObject_Dict_GetItem(obj, name)\
    (likely(PyDict_CheckExact(obj)) ?\
     __Pyx_PyDict_GetItem(obj, name) : PyObject_GetItem(obj, name))
#else
#define __Pyx_PyDict_GetItem(d, key) PyObject_GetItem(d, key)
#define __Pyx_PyObject_Dict_GetItem(obj, name)  PyObject_GetItem(obj, name)
#endif


static CYTHON_INLINE int __Pyx_PySequence_ContainsTF(PyObject* item, PyObject* seq, int eq) {
    int result = PySequence_Contains(seq, item);
    return unlikely(result < 0) ? result : (result == (eq == Py_EQ));
}


#if CYTHON_VECTORCALL && PY_VERSION_HEX >= 0x03090000
#define __Pyx_Object_VectorcallMethod_CallFromBuilder PyObject_VectorcallMethod
#else
static PyObject *__Pyx_Object_VectorcallMethod_CallFromBuilder(PyObject *name, PyObject *const *args, size_t nargsf, PyObject *kwnames);
#endif


#if !CYTHON_COMPILING_IN_PYPY
static CYTHON_INLINE PyObject* __Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check);
#else
#define __Pyx_PyLong_AddObjC(op1, op2, intval, inplace, zerodivision_check)\
    (inplace ? PyNumber_InPlaceAdd(op1, op2) : PyNumber_Add(op1, op2))
#endif


# if CYTHON_COMPILING_IN_CPYTHON
    #if CYTHON_REFNANNY
        #define __Pyx_PyUnicode_ConcatInPlace(left, right) __Pyx_PyUnicode_ConcatInPlaceImpl(&left, right, __pyx_refnanny)
    #else
        #define __Pyx_PyUnicode_ConcatInPlace(left, right) __Pyx_PyUnicode_ConcatInPlaceImpl(&left, right)
    #endif
    static CYTHON_INLINE PyObject *__Pyx_PyUnicode_ConcatInPlaceImpl(PyObject **p_left, PyObject *right
        #if CYTHON_REFNANNY
        , void* __pyx_refnanny
        #endif
    );
#else
#define __Pyx_PyUnicode_ConcatInPlace __Pyx_PyUnicode_Concat
#endif
#define __Pyx_PyUnicode_ConcatInPlaceSafe(left, right) ((unlikely((left) == Py_None) || unlikely((right) == Py_None)) ?\
    PyNumber_InPlaceAdd(left, right) : __Pyx_PyUnicode_ConcatInPlace(left, right))


#if CYTHON_COMPILING_IN_CPYTHON
#define __Pyx_TypeCheck(obj, type) __Pyx_IsSubtype(Py_TYPE(obj), (PyTypeObject *)type)
#define __Pyx_TypeCheck2(obj, type1, type2) __Pyx_IsAnySubtype2(Py_TYPE(obj), (PyTypeObject *)type1, (PyTypeObject *)type2)
static CYTHON_INLINE int __Pyx_IsSubtype(PyTypeObject *a, PyTypeObject *b);
static CYTHON_INLINE int __Pyx_IsAnySubtype2(PyTypeObject *cls, PyTypeObject *a, PyTypeObject *b);
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches(PyObject *err, PyObject *type);
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches2(PyObject *err, PyObject *type1, PyObject *type2);
#else
#define __Pyx_TypeCheck(obj, type) PyObject_TypeCheck(obj, (PyTypeObject *)type)
#define __Pyx_TypeCheck2(obj, type1, type2) (PyObject_TypeCheck(obj, (PyTypeObject *)type1) || PyObject_TypeCheck(obj, (PyTypeObject *)type2))
#define __Pyx_PyErr_GivenExceptionMatches(err, type) PyErr_GivenExceptionMatches(err, type)
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches2(PyObject *err, PyObject *type1, PyObject *type2) {
    return PyErr_GivenExceptionMatches(err, type1) || PyErr_GivenExceptionMatches(err, type2);
}
#endif
#define __Pyx_PyErr_ExceptionMatches2(err1, err2)  __Pyx_PyErr_GivenExceptionMatches2(__Pyx_PyErr_CurrentExceptionType(), err1, err2)
#define __Pyx_PyException_Check(obj) __Pyx_TypeCheck(obj, PyExc_Exception)
#ifdef PyExceptionInstance_Check
  #define __Pyx_PyBaseException_Check(obj) PyExceptionInstance_Check(obj)
#else
  #define __Pyx_PyBaseException_Check(obj) __Pyx_TypeCheck(obj, PyExc_BaseException)
#endif


#define __Pyx_GetItemInt(o, i, type, is_signed, to_py_func, is_list, wraparound, boundscheck, has_gil)\
    (__Pyx_fits_Py_ssize_t(i, type, is_signed) ?\
    __Pyx_GetItemInt_Fast(o, (Py_ssize_t)i, is_list, wraparound, boundscheck) :\
    (is_list ? (PyErr_SetString(PyExc_IndexError, "list index out of range"), (PyObject*)NULL) :\
               __Pyx_GetItemInt_Generic(o, to_py_func(i))))
#define __Pyx_GetItemInt_List(o, i, type, is_signed, to_py_func, is_list, wraparound, boundscheck, has_gil)\
    (__Pyx_fits_Py_ssize_t(i, type, is_signed) ?\
    __Pyx_GetItemInt_List_Fast(o, (Py_ssize_t)i, wraparound, boundscheck) :\
    (PyErr_SetString(PyExc_IndexError, "list index out of range"), (PyObject*)NULL))
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_List_Fast(PyObject *o, Py_ssize_t i,
                                                              int wraparound, int boundscheck);
#define __Pyx_GetItemInt_Tuple(o, i, type, is_signed, to_py_func, is_list, wraparound, boundscheck, has_gil)\
    (__Pyx_fits_Py_ssize_t(i, type, is_signed) ?\
    __Pyx_GetItemInt_Tuple_Fast(o, (Py_ssize_t)i, wraparound, boundscheck) :\
    (PyErr_SetString(PyExc_IndexError, "tuple index out of range"), (PyObject*)NULL))
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Tuple_Fast(PyObject *o, Py_ssize_t i,
                                                              int wraparound, int boundscheck);
static PyObject *__Pyx_GetItemInt_Generic(PyObject *o, PyObject* j);
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Fast(PyObject *o, Py_ssize_t i,
                                                     int is_list, int wraparound, int boundscheck);


static CYTHON_INLINE PyObject* __Pyx_PyDict_Values(PyObject* d);


#if !CYTHON_PEP489_MULTI_PHASE_INIT
static int __Pyx_SetPackagePathFromImportLib(PyObject *module_name);
#else
#define __Pyx_SetPackagePathFromImportLib(a) 0
#endif


static PyObject *__Pyx_Import(PyObject *name, PyObject *from_list, int level);


static PyObject *__Pyx_ImportDottedModule(PyObject *name, PyObject *parts_tuple);
static PyObject *__Pyx_ImportDottedModule_WalkParts(PyObject *module, PyObject *name, PyObject *parts_tuple);


static PyObject *__Pyx_PyList_Pack(Py_ssize_t n, ...);


static PyObject* __Pyx_ImportFrom(PyObject* module, PyObject* name);


#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject *__Pyx_GetTypeDict(PyTypeObject *tp);
#endif


static int __Pyx__SetItemOnTypeDict(PyTypeObject *tp, PyObject *k, PyObject *v);
#define __Pyx_SetItemOnTypeDict(tp, k, v) __Pyx__SetItemOnTypeDict((PyTypeObject*)tp, k, v)


static CYTHON_INLINE int __Pyx_fix_up_extension_type_from_spec(PyType_Spec *spec, PyTypeObject *type);


static PyObject *__Pyx_FetchSharedCythonABIModule(void);


static CYTHON_INLINE PyObject *__Pyx_PyDict_SetDefault(PyObject *d, PyObject *key, PyObject *default_value, int is_safe_type);


static PyTypeObject* __Pyx_FetchCommonTypeFromSpec(PyTypeObject *metaclass, PyObject *module, PyType_Spec *spec, PyObject *bases);


static int __pyx_CommonTypesMetaclass_init(PyObject *module);
#define __Pyx_CommonTypesMetaclass_USED


#if !CYTHON_USE_TYPE_SPECS || (!CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX < 0x03090000)
#define __Pyx_call_type_traverse(o, always_call, visit, arg) 0
#else
static int __Pyx_call_type_traverse(PyObject *o, int always_call, visitproc visit, void *arg);
#endif


static PyObject *__Pyx_PyMethod_New(PyObject *func, PyObject *self, PyObject *typ);


#if CYTHON_METH_FASTCALL && (CYTHON_VECTORCALL || CYTHON_BACKPORT_VECTORCALL)
static CYTHON_INLINE PyObject *__Pyx_PyVectorcall_FastCallDict(PyObject *func, __pyx_vectorcallfunc vc, PyObject *const *args, size_t nargs, PyObject *kw);
#endif


#define __Pyx_CyFunction_USED
#define __Pyx_CYFUNCTION_STATICMETHOD  0x01
#define __Pyx_CYFUNCTION_CLASSMETHOD   0x02
#define __Pyx_CYFUNCTION_CCLASS        0x04
#define __Pyx_CYFUNCTION_COROUTINE     0x08
#define __Pyx_CyFunction_GetClosure(f)\
    (((__pyx_CyFunctionObject *) (f))->func_closure)
#if PY_VERSION_HEX < 0x030900B1 || CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_CyFunction_GetClassObj(f)\
      (((__pyx_CyFunctionObject *) (f))->func_classobj)
#else
  #define __Pyx_CyFunction_GetClassObj(f)\
      ((PyObject*) ((PyCMethodObject *) (f))->mm_class)
#endif
#define __Pyx_CyFunction_SetClassObj(f, classobj)\
    __Pyx__CyFunction_SetClassObj((__pyx_CyFunctionObject *) (f), (classobj))
#define __Pyx_CyFunction_Defaults(type, f)\
    ((type *)(((__pyx_CyFunctionObject *) (f))->defaults))
#define __Pyx_CyFunction_SetDefaultsGetter(f, g)\
    ((__pyx_CyFunctionObject *) (f))->defaults_getter = (g)
typedef struct {
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject_HEAD
    PyObject *func;
#elif PY_VERSION_HEX < 0x030900B1
    PyCFunctionObject func;
#else
    PyCMethodObject func;
#endif
#if CYTHON_BACKPORT_VECTORCALL ||\
        (CYTHON_COMPILING_IN_LIMITED_API && CYTHON_METH_FASTCALL)
    __pyx_vectorcallfunc func_vectorcall;
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *func_weakreflist;
#endif
    PyObject *func_dict;
    PyObject *func_name;
    PyObject *func_qualname;
    PyObject *func_doc;
    PyObject *func_globals;
    PyObject *func_code;
    PyObject *func_closure;
#if PY_VERSION_HEX < 0x030900B1 || CYTHON_COMPILING_IN_LIMITED_API
    PyObject *func_classobj;
#endif
    PyObject *defaults;
    int flags;
    PyObject *defaults_tuple;
    PyObject *defaults_kwdict;
    PyObject *(*defaults_getter)(PyObject *);
    PyObject *func_annotations;
    PyObject *func_is_coroutine;
} __pyx_CyFunctionObject;
#undef __Pyx_CyOrPyCFunction_Check
#define __Pyx_CyFunction_Check(obj)  __Pyx_TypeCheck(obj, __pyx_mstate_global->__pyx_CyFunctionType)
#define __Pyx_CyOrPyCFunction_Check(obj)  __Pyx_TypeCheck2(obj, __pyx_mstate_global->__pyx_CyFunctionType, &PyCFunction_Type)
#define __Pyx_CyFunction_CheckExact(obj)  __Pyx_IS_TYPE(obj, __pyx_mstate_global->__pyx_CyFunctionType)
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunction(PyObject *func, void (*cfunc)(void));
#undef __Pyx_IsSameCFunction
#define __Pyx_IsSameCFunction(func, cfunc)   __Pyx__IsSameCyOrCFunction(func, cfunc)
static PyObject *__Pyx_CyFunction_Init(__pyx_CyFunctionObject* op, PyMethodDef *ml,
                                      int flags, PyObject* qualname,
                                      PyObject *closure,
                                      PyObject *module, PyObject *globals,
                                      PyObject* code);
static CYTHON_INLINE void __Pyx__CyFunction_SetClassObj(__pyx_CyFunctionObject* f, PyObject* classobj);
static CYTHON_INLINE PyObject *__Pyx_CyFunction_InitDefaults(PyObject *func,
                                                         PyTypeObject *defaults_type);
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsTuple(PyObject *m,
                                                            PyObject *tuple);
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsKwDict(PyObject *m,
                                                             PyObject *dict);
static CYTHON_INLINE void __Pyx_CyFunction_SetAnnotationsDict(PyObject *m,
                                                              PyObject *dict);
static int __pyx_CyFunction_init(PyObject *module);
#if CYTHON_METH_FASTCALL
static PyObject * __Pyx_CyFunction_Vectorcall_NOARGS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
static PyObject * __Pyx_CyFunction_Vectorcall_O(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS_METHOD(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
#if CYTHON_BACKPORT_VECTORCALL || CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_CyFunction_func_vectorcall(f) (((__pyx_CyFunctionObject*)f)->func_vectorcall)
#else
#define __Pyx_CyFunction_func_vectorcall(f) (((PyCFunctionObject*)f)->vectorcall)
#endif
#endif


static PyObject *__Pyx_CyFunction_New(PyMethodDef *ml,
                                      int flags, PyObject* qualname,
                                      PyObject *closure,
                                      PyObject *module, PyObject *globals,
                                      PyObject* code);


#if CYTHON_CLINE_IN_TRACEBACK && CYTHON_CLINE_IN_TRACEBACK_RUNTIME
static int __Pyx_CLineForTraceback(PyThreadState *tstate, int c_line);
#else
#define __Pyx_CLineForTraceback(tstate, c_line)  (((CYTHON_CLINE_IN_TRACEBACK)) ? c_line : 0)
#endif


#if CYTHON_COMPILING_IN_LIMITED_API
typedef PyObject __Pyx_CachedCodeObjectType;
#else
typedef PyCodeObject __Pyx_CachedCodeObjectType;
#endif
typedef struct {
    __Pyx_CachedCodeObjectType* code_object;
    int code_line;
} __Pyx_CodeObjectCacheEntry;
struct __Pyx_CodeObjectCache {
    int count;
    int max_count;
    __Pyx_CodeObjectCacheEntry* entries;
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_atomic_int_type accessor_count;
  #endif
};
static int __pyx_bisect_code_objects(__Pyx_CodeObjectCacheEntry* entries, int count, int code_line);
static __Pyx_CachedCodeObjectType *__pyx_find_code_object(int code_line);
static void __pyx_insert_code_object(int code_line, __Pyx_CachedCodeObjectType* code_object);


static void __Pyx_AddTraceback(const char *funcname, int c_line,
                               int py_line, const char *filename);


#if !defined(__INTEL_COMPILER) && defined(__GNUC__) && (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 6))
#define __Pyx_HAS_GCC_DIAGNOSTIC
#endif


static CYTHON_INLINE PyObject* __Pyx_PyLong_From_long(long value);


#if CYTHON_COMPILING_IN_LIMITED_API
typedef PyObject *__Pyx_TypeName;
#define __Pyx_FMT_TYPENAME "%U"
#define __Pyx_DECREF_TypeName(obj) Py_XDECREF(obj)
#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
#define __Pyx_PyType_GetFullyQualifiedName PyType_GetFullyQualifiedName
#else
static __Pyx_TypeName __Pyx_PyType_GetFullyQualifiedName(PyTypeObject* tp);
#endif
#else  // !LIMITED_API
typedef const char *__Pyx_TypeName;
#define __Pyx_FMT_TYPENAME "%.200s"
#define __Pyx_PyType_GetFullyQualifiedName(tp) ((tp)->tp_name)
#define __Pyx_DECREF_TypeName(obj)
#endif


static CYTHON_INLINE long __Pyx_PyLong_As_long(PyObject *);


static CYTHON_INLINE int __Pyx_PyLong_As_int(PyObject *);


static unsigned long __Pyx_get_runtime_version(void);


static int __Pyx_check_binary_version(unsigned long ct_version, unsigned long rt_version, int allow_newer);


#if CYTHON_PEP489_MULTI_PHASE_INIT && CYTHON_USE_MODULE_STATE
static PyObject *__Pyx_State_FindModule(void*);
static int __Pyx_State_AddModule(PyObject* module, void*);
static int __Pyx_State_RemoveModule(void*);
#elif CYTHON_USE_MODULE_STATE
#define __Pyx_State_FindModule PyState_FindModule
#define __Pyx_State_AddModule PyState_AddModule
#define __Pyx_State_RemoveModule PyState_RemoveModule
#endif



#if CYTHON_COMPILING_IN_LIMITED_API
    #if CYTHON_METH_FASTCALL
        #define __PYX_FASTCALL_ABI_SUFFIX  "_fastcall"
    #else
        #define __PYX_FASTCALL_ABI_SUFFIX
    #endif
    #define __PYX_LIMITED_ABI_SUFFIX "limited" __PYX_FASTCALL_ABI_SUFFIX __PYX_AM_SEND_ABI_SUFFIX
#else
    #define __PYX_LIMITED_ABI_SUFFIX
#endif
#if __PYX_HAS_PY_AM_SEND == 1
    #define __PYX_AM_SEND_ABI_SUFFIX
#elif __PYX_HAS_PY_AM_SEND == 2
    #define __PYX_AM_SEND_ABI_SUFFIX "amsendbackport"
#else
    #define __PYX_AM_SEND_ABI_SUFFIX "noamsend"
#endif
#ifndef __PYX_MONITORING_ABI_SUFFIX
    #define __PYX_MONITORING_ABI_SUFFIX
#endif
#if CYTHON_USE_TP_FINALIZE
    #define __PYX_TP_FINALIZE_ABI_SUFFIX
#else
    #define __PYX_TP_FINALIZE_ABI_SUFFIX "nofinalize"
#endif
#if CYTHON_USE_FREELISTS || !defined(__Pyx_AsyncGen_USED)
    #define __PYX_FREELISTS_ABI_SUFFIX
#else
    #define __PYX_FREELISTS_ABI_SUFFIX "nofreelists"
#endif
#define CYTHON_ABI  __PYX_ABI_VERSION __PYX_LIMITED_ABI_SUFFIX __PYX_MONITORING_ABI_SUFFIX __PYX_TP_FINALIZE_ABI_SUFFIX __PYX_FREELISTS_ABI_SUFFIX __PYX_AM_SEND_ABI_SUFFIX
#define __PYX_ABI_MODULE_NAME "_cython_" CYTHON_ABI
#define __PYX_TYPE_MODULE_PREFIX __PYX_ABI_MODULE_NAME "."





#define __Pyx_MODULE_NAME "user_agent"
extern int __pyx_module_is_main_user_agent;
int __pyx_module_is_main_user_agent = 0;



static PyObject *__pyx_builtin_open;
static PyObject *__pyx_builtin_print;
static PyObject *__pyx_builtin_range;
static PyObject *__pyx_builtin_reversed;
static PyObject *__pyx_builtin_FileNotFoundError;

static const char __pyx_k_[] = "\342\227\217 ";
static const char __pyx_k_9[] = "9";
static const char __pyx_k_I[] = "I";
static const char __pyx_k_a[] = "a";
static const char __pyx_k_b[] = "b";
static const char __pyx_k_c[] = "c";
static const char __pyx_k_e[] = "e";
static const char __pyx_k_f[] = "f";
static const char __pyx_k_g[] = "g";
static const char __pyx_k_k[] = "k";
static const char __pyx_k_m[] = "m";
static const char __pyx_k_p[] = "p";
static const char __pyx_k_r[] = "r";
static const char __pyx_k_s[] = "\\s+";
static const char __pyx_k_w[] = "w";
static const char __pyx_k_y[] = "y";
static const char __pyx_k_0m[] = "\033[0m";
static const char __pyx_k_10[] = "10";
static const char __pyx_k_11[] = "11";
static const char __pyx_k_12[] = "12";
static const char __pyx_k_13[] = "13";
static const char __pyx_k_14[] = "14";
static const char __pyx_k_15[] = "15";
static const char __pyx_k_GT[] = "GT-";
static const char __pyx_k_MI[] = "MI";
static const char __pyx_k_Mi[] = "Mi";
static const char __pyx_k_SM[] = "SM-";
static const char __pyx_k__2[] = "\342\227\217";
static const char __pyx_k__3[] = " ";
static const char __pyx_k__4[] = "|";
static const char __pyx_k__5[] = ", ";
static const char __pyx_k__6[] = " '";
static const char __pyx_k__7[] = "";
static const char __pyx_k__8[] = "\n";
static const char __pyx_k__9[] = ";";
static const char __pyx_k_b2[] = "b2";
static const char __pyx_k_br[] = "br";
static const char __pyx_k_c2[] = "c2";
static const char __pyx_k_g2[] = "g2";
static const char __pyx_k_gr[] = "gr";
static const char __pyx_k_os[] = "os";
static const char __pyx_k_p2[] = "p2";
static const char __pyx_k_r2[] = "r2";
static const char __pyx_k_re[] = "re";
static const char __pyx_k_st[] = "st";
static const char __pyx_k_td[] = "td";
static const char __pyx_k_ua[] = "ua";
static const char __pyx_k_up[] = "up";
static const char __pyx_k_w2[] = "w2";
static const char __pyx_k_wv[] = "wv";
static const char __pyx_k_y2[] = "y2";
static const char __pyx_k_1_5[] = "1.5";
static const char __pyx_k_287[] = "287";
static const char __pyx_k_290[] = "290";
static const char __pyx_k_2_0[] = "2.0";
static const char __pyx_k_304[] = "304";
static const char __pyx_k_33m[] = "\033[33m";
static const char __pyx_k_393[] = "393";
static const char __pyx_k_3_0[] = "3.0";
static const char __pyx_k_4_0[] = "4.0";
static const char __pyx_k_720[] = "720";
static const char __pyx_k_AIS[] = "AIS";
static const char __pyx_k_MTN[] = "MTN";
static const char __pyx_k_RMX[] = "RMX";
static const char __pyx_k__10[] = "\\(([^)]*)\\)";
static const char __pyx_k__11[] = " ,/";
static const char __pyx_k__12[] = ":";
static const char __pyx_k__13[] = "; ";
static const char __pyx_k__14[] = "]";
static const char __pyx_k__15[] = ")";
static const char __pyx_k__16[] = ".";
static const char __pyx_k__17[] = " \342\225\260\342\224\200>";
static const char __pyx_k__18[] = "[/]";
static const char __pyx_k__19[] = " |\342\224\200>";
static const char __pyx_k__20[] = "?";
static const char __pyx_k__21[] = "_";
static const char __pyx_k_bs4[] = "bs4";
static const char __pyx_k_cik[] = "cik";
static const char __pyx_k_d_d[] = "\\d+(\\.\\d+)*";
static const char __pyx_k_get[] = "get";
static const char __pyx_k_isi[] = "isi";
static const char __pyx_k_key[] = "key";
static const char __pyx_k_pan[] = "pan";
static const char __pyx_k_pop[] = "pop";
static const char __pyx_k_red[] = "red";
static const char __pyx_k_s_2[] = "[\\s,/]+";
static const char __pyx_k_sub[] = "sub";
static const char __pyx_k_uas[] = "uas";
static const char __pyx_k_1080[] = "1080";
static const char __pyx_k_1184[] = "1184";
static const char __pyx_k_1280[] = "1280";
static const char __pyx_k_1424[] = "1424";
static const char __pyx_k_1440[] = "1440";
static const char __pyx_k_1920[] = "1920";
static const char __pyx_k_2768[] = "2768";
static const char __pyx_k_2_87[] = "2.87";
static const char __pyx_k_2_90[] = "2.90";
static const char __pyx_k_3_04[] = "3.04";
static const char __pyx_k_6200[] = "6200";
static const char __pyx_k_6205[] = "6205";
static const char __pyx_k_6206[] = "6206";
static const char __pyx_k_6208[] = "6208";
static const char __pyx_k_9_79[] = "9.79";
static const char __pyx_k_9_85[] = "9.85";
static const char __pyx_k_FBAB[] = ";FBAB/";
static const char __pyx_k_FBAV[] = ";FBAV/";
static const char __pyx_k_FBBD[] = ";FBBD/";
static const char __pyx_k_FBBV[] = ";FBBV/";
static const char __pyx_k_FBCA[] = ";FBCA/";
static const char __pyx_k_FBCR[] = ";FBCR/";
static const char __pyx_k_FBDV[] = ";FBDV/";
static const char __pyx_k_FBLC[] = ";FBLC/";
static const char __pyx_k_FBMF[] = ";FBMF/";
static const char __pyx_k_FBSV[] = ";FBSV/";
static const char __pyx_k_FBVS[] = ";FBVS/";
static const char __pyx_k_None[] = "None";
static const char __pyx_k_PLAY[] = "PLAY";
static const char __pyx_k_T_fD[] = "\200\001\330\004\005\330\010\022\220!\330\010\021\220\021\330\010\021\220\021\330\010\020\220\001\330\010\020\220\001\330\010\020\220\001\330\010\021\220\021\340\004\013\210:\220T\230\021\230$\230f\240D\250\001";
static const char __pyx_k_agen[] = "agen";
static const char __pyx_k_biru[] = "biru";
static const char __pyx_k_blue[] = "blue";
static const char __pyx_k_cari[] = "cari";
static const char __pyx_k_ceri[] = "ceri";
static const char __pyx_k_cyan[] = "cyan";
static const char __pyx_k_exit[] = "__exit__";
static const char __pyx_k_fbab[] = "fbab";
static const char __pyx_k_fbav[] = "fbav";
static const char __pyx_k_fbbv[] = "fbbv";
static const char __pyx_k_fbvs[] = "fbvs";
static const char __pyx_k_func[] = "__func__";
static const char __pyx_k_href[] = "href";
static const char __pyx_k_info[] = "info";
static const char __pyx_k_item[] = "item";
static const char __pyx_k_kata[] = "kata";
static const char __pyx_k_keys[] = "keys";
static const char __pyx_k_line[] = "line";
static const char __pyx_k_link[] = "link";
static const char __pyx_k_main[] = "__main__";
static const char __pyx_k_nama[] = "nama";
static const char __pyx_k_name[] = "__name__";
static const char __pyx_k_null[] = "null";
static const char __pyx_k_open[] = "open";
static const char __pyx_k_oppo[] = "oppo";
static const char __pyx_k_oren[] = "oren";
static const char __pyx_k_part[] = "part";
static const char __pyx_k_path[] = "path";
static const char __pyx_k_piro[] = "piro";
static const char __pyx_k_soup[] = "soup";
static const char __pyx_k_spec[] = "__spec__";
static const char __pyx_k_test[] = "__test__";
static const char __pyx_k_text[] = "text";
static const char __pyx_k_u_wv[] = "(u|wv)";
static const char __pyx_k_ungu[] = "ungu";
static const char __pyx_k_uniq[] = "uniq";
static const char __pyx_k_vivo[] = "vivo";
static const char __pyx_k_wv_2[] = "; wv";
static const char __pyx_k_10_03[] = "10.03";
static const char __pyx_k_1_31m[] = "\033[1;31m";
static const char __pyx_k_1_32m[] = "\033[1;32m";
static const char __pyx_k_1_33m[] = "\033[1;33m";
static const char __pyx_k_1_34m[] = "\033[1;34m";
static const char __pyx_k_1_35m[] = "\033[1;35m";
static const char __pyx_k_1_36m[] = "\033[1;36m";
static const char __pyx_k_1_37m[] = "\033[1;37m";
static const char __pyx_k_55042[] = "55042";
static const char __pyx_k_6_2_0[] = "6.2.0";
static const char __pyx_k_6_2_4[] = "6.2.4";
static const char __pyx_k_6_2_6[] = "6.2.6";
static const char __pyx_k_6_2_8[] = "6.2.8";
static const char __pyx_k_77979[] = "77979";
static const char __pyx_k_77985[] = "77985";
static const char __pyx_k_7_1_2[] = "7.1.2";
static const char __pyx_k_81003[] = "81003";
static const char __pyx_k_8_1_0[] = "8.1.0";
static const char __pyx_k_Build[] = " Build/";
static const char __pyx_k_Panel[] = "Panel";
static const char __pyx_k_Redmi[] = "Redmi";
static const char __pyx_k_TECNO[] = "TECNO";
static const char __pyx_k_advan[] = "advan";
static const char __pyx_k_alias[] = "alias";
static const char __pyx_k_brand[] = "/brand/";
static const char __pyx_k_build[] = "build";
static const char __pyx_k_bwv_b[] = "\\bwv\\b";
static const char __pyx_k_class[] = "class_";
static const char __pyx_k_en_GB[] = "en_GB";
static const char __pyx_k_en_US[] = "en_US";
static const char __pyx_k_enter[] = "__enter__";
static const char __pyx_k_fbav2[] = "fbav2";
static const char __pyx_k_fbbv2[] = "fbbv2";
static const char __pyx_k_fbs_v[] = "fbs_v";
static const char __pyx_k_flags[] = "flags";
static const char __pyx_k_group[] = "group";
static const char __pyx_k_hasil[] = "hasil";
static const char __pyx_k_hijau[] = "hijau";
static const char __pyx_k_id_ID[] = "id_ID";
static const char __pyx_k_label[] = "label";
static const char __pyx_k_lebar[] = "lebar";
static const char __pyx_k_lines[] = "lines";
static const char __pyx_k_lower[] = "lower";
static const char __pyx_k_merah[] = "merah";
static const char __pyx_k_merek[] = "merek";
static const char __pyx_k_model[] = "model";
static const char __pyx_k_panel[] = "panel";
static const char __pyx_k_parts[] = "parts";
static const char __pyx_k_print[] = "print";
static const char __pyx_k_putih[] = "putih";
static const char __pyx_k_range[] = "range";
static const char __pyx_k_reset[] = "reset";
static const char __pyx_k_split[] = "split";
static const char __pyx_k_strip[] = "strip";
static const char __pyx_k_tanda[] = "tanda";
static const char __pyx_k_tecno[] = "tecno";
static const char __pyx_k_title[] = "title";
static const char __pyx_k_upper[] = "upper";
static const char __pyx_k_utf_8[] = "utf-8";
static const char __pyx_k_warna[] = "warna";
static const char __pyx_k_werno[] = "werno";
static const char __pyx_k_white[] = "white";
static const char __pyx_k_width[] = "width";
static const char __pyx_k_write[] = "write";
static const char __pyx_k_249010[] = "249010";
static const char __pyx_k_2_5_38[] = "2.5.38";
static const char __pyx_k_2_5_49[] = "2.5.49";
static const char __pyx_k_6_15_0[] = "6.15.0";
static const char __pyx_k_6_16_0[] = "6.16.0";
static const char __pyx_k_6_17_0[] = "6.17.0";
static const char __pyx_k_6_18_0[] = "6.18.0";
static const char __pyx_k_9_0_10[] = "9.0.10";
static const char __pyx_k_Xiaomi[] = "Xiaomi";
static const char __pyx_k_center[] = "center";
static const char __pyx_k_choice[] = "choice";
static const char __pyx_k_create[] = "create";
static const char __pyx_k_device[] = "/device/";
static const char __pyx_k_errors[] = "errors";
static const char __pyx_k_has_wv[] = "has_wv";
static const char __pyx_k_height[] = "height";
static const char __pyx_k_hitung[] = "hitung";
static const char __pyx_k_huawei[] = "huawei";
static const char __pyx_k_ignore[] = "ignore";
static const char __pyx_k_inside[] = "inside";
static const char __pyx_k_kuning[] = "kuning";
static const char __pyx_k_merek1[] = "merek1";
static const char __pyx_k_models[] = "models";
static const char __pyx_k_module[] = "__module__";
static const char __pyx_k_random[] = "random";
static const char __pyx_k_realme[] = "realme";
static const char __pyx_k_reset2[] = "reset2";
static const char __pyx_k_rstrip[] = "rstrip";
static const char __pyx_k_search[] = "search";
static const char __pyx_k_shutil[] = "shutil";
static const char __pyx_k_tinggi[] = "tinggi";
static const char __pyx_k_tokens[] = "tokens";
static const char __pyx_k_values[] = "values";
static const char __pyx_k_widths[] = "widths";
static const char __pyx_k_xiaomi[] = "xiaomi";
static const char __pyx_k_1061021[] = "1061021";
static const char __pyx_k_10_6_1a[] = "10.6.1a";
static const char __pyx_k_1_92_12[] = "1.92.12";
static const char __pyx_k_2184025[] = "2184025";
static const char __pyx_k_Build_s[] = "Build/([^;)\\s]+)";
static const char __pyx_k_Console[] = "Console";
static const char __pyx_k_FB_FW_1[] = "};FB_FW/1;]";
static const char __pyx_k_INFINIX[] = "INFINIX";
static const char __pyx_k_Infinix[] = "Infinix";
static const char __pyx_k_Session[] = "Session";
static const char __pyx_k_android[] = "android";
static const char __pyx_k_bFlow_b[] = "\\bFlow\\b";
static const char __pyx_k_columns[] = "columns";
static const char __pyx_k_console[] = "console";
static const char __pyx_k_heights[] = "heights";
static const char __pyx_k_infinix[] = "infinix";
static const char __pyx_k_locales[] = "locales";
static const char __pyx_k_m_paren[] = "m_paren";
static const char __pyx_k_op_oppo[] = "op/oppo";
static const char __pyx_k_panelku[] = "panelku";
static const char __pyx_k_replace[] = "replace";
static const char __pyx_k_res_dev[] = "res_dev";
static const char __pyx_k_samsung[] = "samsung";
static const char __pyx_k_session[] = "session";
static const char __pyx_k_vv_vivo[] = "vv/vivo";
static const char __pyx_k_width_2[] = ",width=";
static const char __pyx_k_16048044[] = "16048044";
static const char __pyx_k_1_32_41m[] = "\033[1;32;41m";
static const char __pyx_k_23550891[] = "23550891";
static const char __pyx_k_67467545[] = "67467545";
static const char __pyx_k_BASE_URL[] = "BASE_URL";
static const char __pyx_k_a9_advan[] = "a9/advan";
static const char __pyx_k_bold_red[] = "[bold red]";
static const char __pyx_k_encoding[] = "encoding";
static const char __pyx_k_fallback[] = "fallback";
static const char __pyx_k_find_all[] = "find_all";
static const char __pyx_k_get_text[] = "get_text";
static const char __pyx_k_height_2[] = ",height=";
static const char __pyx_k_mode_dua[] = "mode_dua";
static const char __pyx_k_motorola[] = "motorola";
static const char __pyx_k_qualname[] = "__qualname__";
static const char __pyx_k_requests[] = "requests";
static const char __pyx_k_reversed[] = "reversed";
static const char __pyx_k_set_name[] = "__set_name__";
static const char __pyx_k_soup_dev[] = "soup_dev";
static const char __pyx_k_user_txt[] = "user.txt";
static const char __pyx_k_135374479[] = "135374479";
static const char __pyx_k_159507224[] = "159507224";
static const char __pyx_k_159507260[] = "159507260";
static const char __pyx_k_169378254[] = "169378254";
static const char __pyx_k_182747440[] = "182747440";
static const char __pyx_k_1_51_5103[] = "1.51.5103";
static const char __pyx_k_1_78_7800[] = "1.78.7800";
static const char __pyx_k_38_5_214m[] = "\033[38;5;214m";
static const char __pyx_k_588686349[] = "588686349";
static const char __pyx_k_BRAND_MAP[] = "BRAND_MAP";
static const char __pyx_k_arm64_v8a[] = "arm64-v8a";
static const char __pyx_k_bold_blue[] = "[bold blue]";
static const char __pyx_k_bold_cyan[] = "[bold cyan]";
static const char __pyx_k_brand_key[] = "brand_key";
static const char __pyx_k_brand_url[] = "brand_url";
static const char __pyx_k_densities[] = "densities";
static const char __pyx_k_fullmatch[] = "fullmatch";
static const char __pyx_k_hu_huawei[] = "hu/huawei";
static const char __pyx_k_mode_satu[] = "mode_satu";
static const char __pyx_k_mode_tiga[] = "mode_tiga";
static const char __pyx_k_pilihanku[] = "pilihanku";
static const char __pyx_k_re_realme[] = "re/realme";
static const char __pyx_k_res_brand[] = "res_brand";
static const char __pyx_k_s_Build_b[] = "\\s*Build\\b";
static const char __pyx_k_useragent[] = "useragent";
static const char __pyx_k_xi_xiaomi[] = "xi/xiaomi";
static const char __pyx_k_2T_V6_e7_a[] = "\200\001\330\004\013\2102\210T\220\024\220V\2306\240\025\240e\2507\260&\270\006\270a";
static const char __pyx_k_9_6_7_0214[] = "9.6.7_0214";
static const char __pyx_k_IGNORECASE[] = "IGNORECASE";
static const char __pyx_k_USER_AGENT[] = "USER AGENT ";
static const char __pyx_k_bold_green[] = "bold green";
static const char __pyx_k_bold_white[] = "[bold white]";
static const char __pyx_k_brand_path[] = "brand_path";
static const char __pyx_k_brand_text[] = "brand_text";
static const char __pyx_k_device_url[] = "device_url";
static const char __pyx_k_if_infinix[] = "if/infinix";
static const char __pyx_k_mode_empat[] = "mode_empat";
static const char __pyx_k_rich_panel[] = "rich.panel";
static const char __pyx_k_sa_samsung[] = "sa/samsung";
static const char __pyx_k_user_agent[] = "user_agent";
static const char __pyx_k_warna_dict[] = "warna_dict";
static const char __pyx_k_44_0_0_8_52[] = "44.0.0.8.52";
static const char __pyx_k_63_0_0_4382[] = "63.0.0.4382";
static const char __pyx_k_a_z_2_a_z_2[] = "[a-z]{2}(?:-[a-z]{2})?";
static const char __pyx_k_bold_yellow[] = "bold yellow";
static const char __pyx_k_build_match[] = "build_match";
static const char __pyx_k_html_parser[] = "html.parser";
static const char __pyx_k_mr_motorola[] = "mr/motorola";
static const char __pyx_k_pake_dalvik[] = "pake_dalvik";
static const char __pyx_k_text_inside[] = "text_inside";
static const char __pyx_k_title_align[] = "title_align";
static const char __pyx_k_FBDM_density[] = ";FBDM/{density=";
static const char __pyx_k_bold_green_2[] = "[bold green]";
static const char __pyx_k_bold_magenta[] = "bold magenta";
static const char __pyx_k_border_style[] = "border_style";
static const char __pyx_k_device_links[] = "device_links";
static const char __pyx_k_initializing[] = "_initializing";
static const char __pyx_k_is_coroutine[] = "_is_coroutine";
static const char __pyx_k_rich_console[] = "rich.console";
static const char __pyx_k_130_0_0_15_89[] = "130.0.0.15.89";
static const char __pyx_k_196_0_0_29_99[] = "196.0.0.29.99";
static const char __pyx_k_BeautifulSoup[] = "BeautifulSoup";
static const char __pyx_k_architectures[] = "architectures";
static const char __pyx_k_bold_yellow_2[] = "[bold yellow]";
static const char __pyx_k_pake_original[] = "pake_original";
static const char __pyx_k_user_agent_py[] = "user_agent.py";
static const char __pyx_k_220_0_0_20_121[] = "220.0.0.20.121";
static const char __pyx_k_230_0_0_12_117[] = "230.0.0.12.117";
static const char __pyx_k_241_0_0_17_116[] = "241.0.0.17.116";
static const char __pyx_k_454_0_0_37_109[] = "454.0.0.37.109";
static const char __pyx_k_bold_magenta_2[] = "[bold magenta]";
static const char __pyx_k_lebar_terminal[] = "lebar_terminal";
static const char __pyx_k_model_in_build[] = "model_in_build";
static const char __pyx_k_model_in_build2[] = "model_in_build2";
static const char __pyx_k_selected_brands[] = "selected_brands";
static const char __pyx_k_tb_tecno_mobile[] = "tb/tecno-mobile";
static const char __pyx_k_RequestException[] = "RequestException";
static const char __pyx_k_raise_for_status[] = "raise_for_status";
static const char __pyx_k_user_agents_list[] = "user_agents_list";
static const char __pyx_k_FileNotFoundError[] = "FileNotFoundError";
static const char __pyx_k_com_ludia_dragons[] = "com.ludia.dragons";
static const char __pyx_k_get_terminal_size[] = "get_terminal_size";
static const char __pyx_k_Gagal_membaca_file[] = "Gagal membaca file:";
static const char __pyx_k_Stay_Home_Teletalk[] = "Stay Home-Teletalk";
static const char __pyx_k_asyncio_coroutines[] = "asyncio.coroutines";
static const char __pyx_k_cline_in_traceback[] = "cline_in_traceback";
static const char __pyx_k_com_tongitsgo_play[] = "com.tongitsgo.play";
static const char __pyx_k_armeabi_v7a_armeabi[] = "armeabi-v7a:armeabi";
static const char __pyx_k_com_ea_gp_nbamobile[] = "com.ea.gp.nbamobile";
static const char __pyx_k_Gagal_memuat_halaman[] = "Gagal memuat halaman:";
static const char __pyx_k_com_teenpatti_hd_gold[] = "com.teenpatti.hd.gold";
static const char __pyx_k_FBAN_Orca_Android_FBAV[] = "[FBAN/Orca-Android;FBAV/";
static const char __pyx_k_com_moonfrog_ludo_club[] = "com.moonfrog.ludo.club";
static const char __pyx_k_Gunakan_salah_satu_dari[] = " Gunakan salah satu dari: ";
static const char __pyx_k_FBAN_Orca_Android_FBAV_2[] = ") [FBAN/Orca-Android;FBAV/";
static const char __pyx_k_com_g5e_sherlock_android[] = "com.g5e.sherlock.android";
static const char __pyx_k_https_whatmyuseragent_com[] = "https://whatmyuseragent.com";
static const char __pyx_k_com_g5e_hiddencity_android[] = "com.g5e.hiddencity.android";
static const char __pyx_k_determine_merek_from_model[] = "determine_merek_from_model";
static const char __pyx_k_load_models_from_user_file[] = "load_models_from_user_file";
static const char __pyx_k_FBPN_com_facebook_orca_FBLC[] = ";FBPN/com.facebook.orca;FBLC/";
static const char __pyx_k_Dalvik_2_1_0_Linux_U_Android[] = "Dalvik/2.1.0 (Linux; U; Android ";
static const char __pyx_k_applewebkit_khtml_like_gecko[] = "applewebkit|khtml|like gecko";
static const char __pyx_k_tidak_ada_dalam_daftar_device[] = "' tidak ada dalam daftar device.";
static const char __pyx_k_AQfCt5_6_s_6_A_BfA_CvRs_2V1_4q[] = "\200\001\330\004\014\210A\210Q\210f\220C\220t\2305\240\013\2506\260\021\260%\260s\270!\2706\300\021\330\004\010\210\010\220\010\230\001\230\021\330\010\014\210A\330\010\014\210B\210f\220A\220_\240C\240v\250R\250s\260!\2602\260V\2701\330\010\013\2104\210q\330\014\r\330\010\013\2102\210Z\220q\230\013\2403\240b\250\001\330\014\r\330\010\013\2102\210Z\220q\320\030(\250\001\330\014\r\330\010\013\2102\210Z\220q\320\0303\2603\260b\270\001\330\014\r\330\010\013\2102\210W\220A\220\\\240\023\240B\240a\330\014\r\330\010\013\2102\210W\220A\320\0256\260c\270\022\2701\330\014\r\330\010\017\210q\330\004\013\2101";
static const char __pyx_k_FBAN_AudienceNetworkForAndroid[] = ") [FBAN/AudienceNetworkForAndroid;FBSN/Android;FBSV/";
static const char __pyx_k_M_vS_V_5Rq_Q_r_E_a_A_U_1_a_q_6[] = "\320\000\030\230\014\240M\260\021\340\004\007\200v\210S\220\001\330\010\t\330\014\035\230V\320#5\260R\260q\340\014\035\230Q\340\010\020\220\017\230r\240\021\340\004\014\210E\220\021\330\010\t\330\010\016\210a\330\010\024\220A\330\010\025\220U\230!\2301\330\010\016\210a\330\010\017\210q\340\004\013\2106\220\021\220!";
static const char __pyx_k_ay_A_A_wa_QhgXQ_axxxxq_q_6_6_0[] = "\200\001\330\004\016\210a\210y\230\t\240\021\330\004\024\220A\320\025,\250A\330\004\020\220\001\220\027\230\007\230w\240a\330\004\r\210Q\210h\220g\230X\240Q\330\004\016\210a\210x\220x\230x\240x\250q\330\004\r\320\r'\240q\330\004\013\2106\220\027\230\001\230\021\330\004\013\2106\220\027\230\001\230\021\320\0320\260\010\270\007\270w\300a\330\004\014\210F\220'\230\021\230!\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\340\004\013\2106\220\027\230\001\230\021\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\340\004\013\2106\220\027\230\001\230\021\230*\240J\250j\270\001\330\004\013\2106\220\027\230\001\230\021\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\330\004\005\340\004\014\210D\220\001\220\021\330\004\014\210D\220\004\220A\220X\230Q\330\004\r\210T\220\024\220Q\220f\230A\330\004\014\320\014&\240a\240q\330\004\013\2106\220\027\230\001\230\021\230/\320):\320:K\310?\320Zl\320l~\360\000\000\177\001P\002\360\000\000P\002a\002\360\000\000a\002s\002\360\000\000s\002t\002\330\004\013\2106\220\027\230\001\230\021\230-\240|\260=\300\014\310M\320Ye\320er\320r\177\360\000\000@\002M\002\360\000\000M\002N\002\330\004\014\210F\220'\230\021\230!\2308\2408\2504\250u\260E\270\025\270e\3005\310\001\330\004\r\210U\220(\230!\230:\240Z\250x\260q\270\t\300\021\330\004\014\210F\220(\230!\230:\240V\2508\2601\260I\270W\300H\310A\310Z\320W]\320]e\320ef\320fo\320op\330\004\013\2109\220F\230#\230\\\250\021\330\004\007\200q\330\010\031\230\022\2304\230~\250Q\330\010\013\2107\220$\220e\2307\240.\260\006\260a\330\014\035\230R\230t\2401\340\010\031\230\021\330\010\013\2101\330\014\035\230R\230t\2401\330\004\026\220n\240H\250A""\250W\260A\330\004\007\200z\220\023\220A\330\010\t\330\014\016\320\016*\250!\330\016\027\220v\230W\240A\320%5\260\\\300\021\330\016\027\220~\240]\260-\270q\330\016\027\220v\230W\240A\240Q\330\016!\240\026\240w\250a\320/B\300&\310\007\310q\320Pa\320ag\320gn\320no\320op\340\010\017\210q\330\004\007\200z\220\023\220A\330\010\t\330\014\016\320\0162\260)\2701\330\016*\250!\330\016\027\220v\230W\240A\320%5\260\\\300\021\330\016\027\220~\240]\260-\270q\330\016\027\220v\230W\240A\240Q\330\016!\240\026\240w\250a\320/B\300&\310\007\310q\320Pa\320ag\320gn\320no\320op\340\010\017\210q\330\004\007\200z\220\023\220A\330\010\t\330\014\016\320\0162\260)\360\000\000<A\002\360\000\000A\002N\002\360\000\000N\002Z\002\360\000\000Z\002g\002\360\000\000g\002t\002\360\000\000t\002@\003\360\000\000@\003F\003\360\000\000F\003M\003\360\000\000M\003N\003\360\000\000N\003O\003\340\010\017\210q\330\004\007\200z\220\023\220A\330\010\t\330\014\016\320\0162\260)\2701\340\010\017\210q";
static const char __pyx_k_extract_model_from_parentheses[] = "_extract_model_from_parentheses";
static const char __pyx_k_File_kosong_atau_tidak_ada_User[] = "File kosong atau tidak ada User-Agent.";
static const char __pyx_k_Tidak_ditemukan_device_untuk_br[] = " Tidak ditemukan device untuk brand ";
static const char __pyx_k_e9L_AT_s_hb_4vQ_4q_1_vWAQ_Q_Q_q[] = "\200\001\330\004\005\330\r\021\220\021\220,\230e\2409\250L\270\001\330\014\024\220A\220T\230\026\230s\240$\240h\250b\260\003\2604\260v\270Q\340\010\013\2104\210q\330\014\021\220\021\220!\330\014\023\2201\340\010\017\210v\220W\230A\230Q\340\004\013\210=\230\001\330\010\r\210Q\320\016%\240Q\330\010\017\210q";
static const char __pyx_k_q_Q_Yiwm1_G1_4A_4q_aq_7q_4q_axu[] = "\320\000\037\230q\330\004\r\210Q\330\004\005\330\r\021\220\021\220&\230\005\230Y\240i\250w\260m\3001\330\014\020\220\010\230\001\330\020\032\230\"\230G\2401\320$4\260A\330\020\023\2204\220q\330\024\025\330\020\031\230\027\240\006\240a\240q\330\020\030\320\0307\260q\270\001\330\020\023\2204\220q\330\024\025\330\020\030\230\002\230$\230a\230x\240u\250F\260&\270\002\270'\300\021\300!\330\020\023\2204\220s\230&\240\003\2402\240W\250A\250]\270'\300\022\3001\330\024\025\330\020\036\230b\240\007\240q\320(=\270X\300R\300q\330\020\030\230\013\2406\250\021\250\"\250F\260&\3208I\310\021\330\020\031\230\024\230Q\230b\240\007\240q\250\013\2608\2702\270Q\340\020\026\220g\230R\230y\250\007\250y\270\007\270v\300Q\330\013\014\330\010\017\210q\330\004\013\2101\330\004\010\210\010\220\001\330\010\017\210t\2201\220J\230d\240!\2401\330\010\013\2104\210w\220a\330\014\020\220\001\220\027\230\001\330\004\013\2104\210q\220\004\220G\2301";
static const char __pyx_k_q_q_A_1_1_a_q_V2V1A_F_6_s_Q_waq[] = "\200\013\210<\220q\330\004\017\210q\340\004\005\330\010\024\220A\330\010\021\220\021\330\010\022\220!\330\010\020\220\001\330\010\022\220!\330\010\023\2201\330\010\022\220!\330\010\020\220\001\330\010\023\2201\330\010\021\220\021\360\014\000\005\027\220a\340\004\007\200q\340\010\020\220\005\220V\2302\230V\2401\240A\330\010\014\210F\220!\330\014\021\220\022\2206\230\021\330\014\017\210s\220#\220Q\330\020\037\230w\240a\240q\360\006\000\021\036\230T\240\025\240a\240y\260\005\260Q\330\020\025\220Q\220b\230\004\230I\240S\250\004\250A\330\020\025\220Q\220b\230\004\320\034=\270Q\330\020\021\340\010\032\230!\360\006\000\005\030\220q\330\004\013\2103\210a\210q\330\004\r\210Q\340\004\005\330\r\025\220X\230V\2401\330\014\020\220\005\220U\230!\2301\360\n\000\021\024\2201\340\024 \240\006\240g\250Q\250a\360\006\000\025!\240\006\240g\250Q\250d\260!\2609\270E\300\021\340\020\035\230Y\240a\240q\360\n\000\021\035\230B\230d\320\"3\2601\330\020\034\230G\2404\240q\250\001\330\020\031\320\031*\250!\340\020\027\220}\240A\240Y\250g\260Q\340\020\037\230q\330\024\030\230\004\230A\230Q\330\024\030\230\010\240\004\240I\250Q\250a\330\024\027\220{\240#\240T\250\024\250Q\250h\260a\360\006\000\021\024\2204\220q\330\024\031\230\021\230\"\230D\320 K\3101\330\024\025\340\020\035\230Y\240b\250\006\250g\260Q\260a\330\020\032\230'\240\024\240Q\240a\330\020\027\320\027(\250\001\340\020\033\230=\250\001\250\027\260\007\260q\330\020\026\220a\220r\230\031\240!\2406\250\026\250t\2606\270\030\300\031\310!\3106\320QX\320XY\340\020\023\2201\330\024\036\230a\330\024\031\230\026\230w\240a\240q\330\024\033\2303\230d\240\"\240A\240R\240\177\260g\270R\270t\3004\300s\310&\320PV\320V\\\320\\]\330\024$\240G\2501\250A\340\024\036\230a\330\024\037\230q\330\024\033\2303\230d\240\"\240A\240R\240\177\260g\270R\270t\3004\300y\320PV\320V\\\320\\b\320bc\330\024$\240G\2501\250A\340\r\021\220\021\220,\230e\2409\250L\270\001\330\014\r\210V\2201\220D\230\005\230Q\230a\340\004\013\2108\320\023(\250\001\330\010\r\210Q\320\016'\240q";
static const char __pyx_k_t1_q_V1_vS_3fCq_q_z_A_q_xs_q_uC[] = "\200\001\330\004\007\200t\2101\330\010\017\210q\330\004\010\210\005\210V\2201\330\004\t\210\021\210&\220\001\330\004\007\200v\210S\220\003\2203\220f\230C\230q\330\010\017\210q\330\004\007\200z\220\023\220A\330\010\017\210q\330\004\007\200x\210s\220!\330\010\017\210q\330\004\007\200u\210C\210q\330\010\017\210q\330\004\007\200u\210C\210q\330\010\017\210q\330\004\007\200v\210S\220\001\330\010\017\210q\330\004\007\200x\210s\220!\330\010\017\210q\330\004\r\210R\210v\220Q\220l\240!\330\004\007\200s\210!\2108\2202\220R\220t\2306\240\021\240!\330\010\020\220\006\220a\220q\330\010\017\210q\330\004\013\2101";
static const char __pyx_k_Mozilla_5_0_Linux_Android_13_Inf[] = "Mozilla/5.0 (Linux; Android 13; Infinix X6831 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/137.0.7151.89 Mobile Safari/537.36";
static const char __pyx_k_com_gameloft_android_ANMP_GloftD[] = "com.gameloft.android.ANMP.GloftDYHM";
static const char __pyx_k_com_grandegames_slots_dafu_casin[] = "com.grandegames.slots.dafu.casino";
static const char __pyx_k_com_ikeyboard_theme_pink_rgb_hea[] = "com.ikeyboard.theme.pink.rgb.heart";

static PyObject *__pyx_pf_10user_agent_warna(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_nama); 
static PyObject *__pyx_pf_10user_agent_2panelku(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_label, PyObject *__pyx_v_isi, PyObject *__pyx_v_lebar, PyObject *__pyx_v_tinggi, PyObject *__pyx_v_werno); 
static PyObject *__pyx_pf_10user_agent_4st(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_kata); 
static PyObject *__pyx_pf_10user_agent_6pake_original(CYTHON_UNUSED PyObject *__pyx_self); 
static PyObject *__pyx_pf_10user_agent_8create(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_alias, PyObject *__pyx_v_cik); 
static PyObject *__pyx_pf_10user_agent_10_extract_model_from_parentheses(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_text_inside); 
static PyObject *__pyx_pf_10user_agent_12load_models_from_user_file(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_path); 
static PyObject *__pyx_pf_10user_agent_14determine_merek_from_model(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_model); 
static PyObject *__pyx_pf_10user_agent_16pake_dalvik(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_pilihanku); 



#ifndef CYTHON_SMALL_CODE
#if defined(__clang__)
    #define CYTHON_SMALL_CODE
#elif defined(__GNUC__) && (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 3))
    #define CYTHON_SMALL_CODE __attribute__((cold))
#else
    #define CYTHON_SMALL_CODE
#endif
#endif

typedef struct {
  PyObject *__pyx_d;
  PyObject *__pyx_b;
  PyObject *__pyx_cython_runtime;
  PyObject *__pyx_empty_tuple;
  PyObject *__pyx_empty_bytes;
  PyObject *__pyx_empty_unicode;
  #ifdef __Pyx_CyFunction_USED
  PyTypeObject *__pyx_CyFunctionType;
  #endif
  #ifdef __Pyx_FusedFunction_USED
  PyTypeObject *__pyx_FusedFunctionType;
  #endif
  #ifdef __Pyx_Generator_USED
  PyTypeObject *__pyx_GeneratorType;
  #endif
  #ifdef __Pyx_IterableCoroutine_USED
  PyTypeObject *__pyx_IterableCoroutineType;
  #endif
  #ifdef __Pyx_Coroutine_USED
  PyTypeObject *__pyx_CoroutineAwaitType;
  #endif
  #ifdef __Pyx_Coroutine_USED
  PyTypeObject *__pyx_CoroutineType;
  #endif
  __Pyx_CachedCFunction __pyx_umethod_PyDict_Type_get;
  __Pyx_CachedCFunction __pyx_umethod_PyDict_Type_keys;
  __Pyx_CachedCFunction __pyx_umethod_PyDict_Type_pop;
  __Pyx_CachedCFunction __pyx_umethod_PyDict_Type_values;
  PyObject *__pyx_tuple[16];
  PyObject *__pyx_codeobj_tab[9];
  PyObject *__pyx_string_tab[411];
  PyObject *__pyx_int_0;
  PyObject *__pyx_int_1;
  PyObject *__pyx_int_4;
  PyObject *__pyx_int_80;


PyTypeObject *__pyx_CommonTypesMetaclassType;


#if CYTHON_COMPILING_IN_LIMITED_API
PyObject *__Pyx_CachedMethodType;
#endif


struct __Pyx_CodeObjectCache __pyx_code_cache;


} __pyx_mstatetype;

#if CYTHON_USE_MODULE_STATE
#ifdef __cplusplus
namespace {
extern struct PyModuleDef __pyx_moduledef;
} 
#else
static struct PyModuleDef __pyx_moduledef;
#endif

#define __pyx_mstate_global (__Pyx_PyModule_GetState(__Pyx_State_FindModule(&__pyx_moduledef)))

#define __pyx_m (__Pyx_State_FindModule(&__pyx_moduledef))
#else
static __pyx_mstatetype __pyx_mstate_global_static =
#ifdef __cplusplus
    {};
#else
    {0};
#endif
static __pyx_mstatetype * const __pyx_mstate_global = &__pyx_mstate_global_static;
#endif

#define __pyx_kp_u_ __pyx_string_tab[0]
#define __pyx_kp_u_0m __pyx_string_tab[1]
#define __pyx_kp_u_10 __pyx_string_tab[2]
#define __pyx_kp_u_1061021 __pyx_string_tab[3]
#define __pyx_kp_u_1080 __pyx_string_tab[4]
#define __pyx_kp_u_10_03 __pyx_string_tab[5]
#define __pyx_kp_u_10_6_1a __pyx_string_tab[6]
#define __pyx_kp_u_11 __pyx_string_tab[7]
#define __pyx_kp_u_1184 __pyx_string_tab[8]
#define __pyx_kp_u_12 __pyx_string_tab[9]
#define __pyx_kp_u_1280 __pyx_string_tab[10]
#define __pyx_kp_u_13 __pyx_string_tab[11]
#define __pyx_kp_u_130_0_0_15_89 __pyx_string_tab[12]
#define __pyx_kp_u_135374479 __pyx_string_tab[13]
#define __pyx_kp_u_14 __pyx_string_tab[14]
#define __pyx_kp_u_1424 __pyx_string_tab[15]
#define __pyx_kp_u_1440 __pyx_string_tab[16]
#define __pyx_kp_u_15 __pyx_string_tab[17]
#define __pyx_kp_u_159507224 __pyx_string_tab[18]
#define __pyx_kp_u_159507260 __pyx_string_tab[19]
#define __pyx_kp_u_16048044 __pyx_string_tab[20]
#define __pyx_kp_u_169378254 __pyx_string_tab[21]
#define __pyx_kp_u_182747440 __pyx_string_tab[22]
#define __pyx_kp_u_1920 __pyx_string_tab[23]
#define __pyx_kp_u_196_0_0_29_99 __pyx_string_tab[24]
#define __pyx_kp_u_1_31m __pyx_string_tab[25]
#define __pyx_kp_u_1_32_41m __pyx_string_tab[26]
#define __pyx_kp_u_1_32m __pyx_string_tab[27]
#define __pyx_kp_u_1_33m __pyx_string_tab[28]
#define __pyx_kp_u_1_34m __pyx_string_tab[29]
#define __pyx_kp_u_1_35m __pyx_string_tab[30]
#define __pyx_kp_u_1_36m __pyx_string_tab[31]
#define __pyx_kp_u_1_37m __pyx_string_tab[32]
#define __pyx_kp_u_1_5 __pyx_string_tab[33]
#define __pyx_kp_u_1_51_5103 __pyx_string_tab[34]
#define __pyx_kp_u_1_78_7800 __pyx_string_tab[35]
#define __pyx_kp_u_1_92_12 __pyx_string_tab[36]
#define __pyx_kp_u_2184025 __pyx_string_tab[37]
#define __pyx_kp_u_220_0_0_20_121 __pyx_string_tab[38]
#define __pyx_kp_u_230_0_0_12_117 __pyx_string_tab[39]
#define __pyx_kp_u_23550891 __pyx_string_tab[40]
#define __pyx_kp_u_241_0_0_17_116 __pyx_string_tab[41]
#define __pyx_kp_u_249010 __pyx_string_tab[42]
#define __pyx_kp_u_2768 __pyx_string_tab[43]
#define __pyx_kp_u_287 __pyx_string_tab[44]
#define __pyx_kp_u_290 __pyx_string_tab[45]
#define __pyx_kp_u_2_0 __pyx_string_tab[46]
#define __pyx_kp_u_2_5_38 __pyx_string_tab[47]
#define __pyx_kp_u_2_5_49 __pyx_string_tab[48]
#define __pyx_kp_u_2_87 __pyx_string_tab[49]
#define __pyx_kp_u_2_90 __pyx_string_tab[50]
#define __pyx_kp_u_304 __pyx_string_tab[51]
#define __pyx_kp_u_33m __pyx_string_tab[52]
#define __pyx_kp_u_38_5_214m __pyx_string_tab[53]
#define __pyx_kp_u_393 __pyx_string_tab[54]
#define __pyx_kp_u_3_0 __pyx_string_tab[55]
#define __pyx_kp_u_3_04 __pyx_string_tab[56]
#define __pyx_kp_u_44_0_0_8_52 __pyx_string_tab[57]
#define __pyx_kp_u_454_0_0_37_109 __pyx_string_tab[58]
#define __pyx_kp_u_4_0 __pyx_string_tab[59]
#define __pyx_kp_u_55042 __pyx_string_tab[60]
#define __pyx_kp_u_588686349 __pyx_string_tab[61]
#define __pyx_kp_u_6200 __pyx_string_tab[62]
#define __pyx_kp_u_6205 __pyx_string_tab[63]
#define __pyx_kp_u_6206 __pyx_string_tab[64]
#define __pyx_kp_u_6208 __pyx_string_tab[65]
#define __pyx_kp_u_63_0_0_4382 __pyx_string_tab[66]
#define __pyx_kp_u_67467545 __pyx_string_tab[67]
#define __pyx_kp_u_6_15_0 __pyx_string_tab[68]
#define __pyx_kp_u_6_16_0 __pyx_string_tab[69]
#define __pyx_kp_u_6_17_0 __pyx_string_tab[70]
#define __pyx_kp_u_6_18_0 __pyx_string_tab[71]
#define __pyx_kp_u_6_2_0 __pyx_string_tab[72]
#define __pyx_kp_u_6_2_4 __pyx_string_tab[73]
#define __pyx_kp_u_6_2_6 __pyx_string_tab[74]
#define __pyx_kp_u_6_2_8 __pyx_string_tab[75]
#define __pyx_kp_u_720 __pyx_string_tab[76]
#define __pyx_kp_u_77979 __pyx_string_tab[77]
#define __pyx_kp_u_77985 __pyx_string_tab[78]
#define __pyx_kp_u_7_1_2 __pyx_string_tab[79]
#define __pyx_kp_u_81003 __pyx_string_tab[80]
#define __pyx_kp_u_8_1_0 __pyx_string_tab[81]
#define __pyx_kp_u_9 __pyx_string_tab[82]
#define __pyx_kp_u_9_0_10 __pyx_string_tab[83]
#define __pyx_kp_u_9_6_7_0214 __pyx_string_tab[84]
#define __pyx_kp_u_9_79 __pyx_string_tab[85]
#define __pyx_kp_u_9_85 __pyx_string_tab[86]
#define __pyx_n_u_AIS __pyx_string_tab[87]
#define __pyx_n_u_BASE_URL __pyx_string_tab[88]
#define __pyx_n_u_BRAND_MAP __pyx_string_tab[89]
#define __pyx_n_u_BeautifulSoup __pyx_string_tab[90]
#define __pyx_kp_u_Build __pyx_string_tab[91]
#define __pyx_kp_u_Build_s __pyx_string_tab[92]
#define __pyx_n_u_Console __pyx_string_tab[93]
#define __pyx_kp_u_Dalvik_2_1_0_Linux_U_Android __pyx_string_tab[94]
#define __pyx_kp_u_FBAB __pyx_string_tab[95]
#define __pyx_kp_u_FBAN_AudienceNetworkForAndroid __pyx_string_tab[96]
#define __pyx_kp_u_FBAN_Orca_Android_FBAV __pyx_string_tab[97]
#define __pyx_kp_u_FBAN_Orca_Android_FBAV_2 __pyx_string_tab[98]
#define __pyx_kp_u_FBAV __pyx_string_tab[99]
#define __pyx_kp_u_FBBD __pyx_string_tab[100]
#define __pyx_kp_u_FBBV __pyx_string_tab[101]
#define __pyx_kp_u_FBCA __pyx_string_tab[102]
#define __pyx_kp_u_FBCR __pyx_string_tab[103]
#define __pyx_kp_u_FBDM_density __pyx_string_tab[104]
#define __pyx_kp_u_FBDV __pyx_string_tab[105]
#define __pyx_kp_u_FBLC __pyx_string_tab[106]
#define __pyx_kp_u_FBMF __pyx_string_tab[107]
#define __pyx_kp_u_FBPN_com_facebook_orca_FBLC __pyx_string_tab[108]
#define __pyx_kp_u_FBSV __pyx_string_tab[109]
#define __pyx_kp_u_FBVS __pyx_string_tab[110]
#define __pyx_kp_u_FB_FW_1 __pyx_string_tab[111]
#define __pyx_n_u_FileNotFoundError __pyx_string_tab[112]
#define __pyx_kp_u_File_kosong_atau_tidak_ada_User __pyx_string_tab[113]
#define __pyx_kp_u_GT __pyx_string_tab[114]
#define __pyx_kp_u_Gagal_membaca_file __pyx_string_tab[115]
#define __pyx_kp_u_Gagal_memuat_halaman __pyx_string_tab[116]
#define __pyx_kp_u_Gunakan_salah_satu_dari __pyx_string_tab[117]
#define __pyx_n_u_I __pyx_string_tab[118]
#define __pyx_n_u_IGNORECASE __pyx_string_tab[119]
#define __pyx_n_u_INFINIX __pyx_string_tab[120]
#define __pyx_n_u_Infinix __pyx_string_tab[121]
#define __pyx_n_u_MI __pyx_string_tab[122]
#define __pyx_n_u_MTN __pyx_string_tab[123]
#define __pyx_n_u_Mi __pyx_string_tab[124]
#define __pyx_kp_u_Mozilla_5_0_Linux_Android_13_Inf __pyx_string_tab[125]
#define __pyx_kp_u_None __pyx_string_tab[126]
#define __pyx_n_u_PLAY __pyx_string_tab[127]
#define __pyx_n_u_Panel __pyx_string_tab[128]
#define __pyx_n_u_RMX __pyx_string_tab[129]
#define __pyx_n_u_Redmi __pyx_string_tab[130]
#define __pyx_n_u_RequestException __pyx_string_tab[131]
#define __pyx_kp_u_SM __pyx_string_tab[132]
#define __pyx_n_u_Session __pyx_string_tab[133]
#define __pyx_kp_u_Stay_Home_Teletalk __pyx_string_tab[134]
#define __pyx_n_u_TECNO __pyx_string_tab[135]
#define __pyx_kp_u_Tidak_ditemukan_device_untuk_br __pyx_string_tab[136]
#define __pyx_kp_u_USER_AGENT __pyx_string_tab[137]
#define __pyx_n_u_Xiaomi __pyx_string_tab[138]
#define __pyx_kp_u__10 __pyx_string_tab[139]
#define __pyx_kp_u__11 __pyx_string_tab[140]
#define __pyx_kp_u__12 __pyx_string_tab[141]
#define __pyx_kp_u__13 __pyx_string_tab[142]
#define __pyx_kp_u__14 __pyx_string_tab[143]
#define __pyx_kp_u__15 __pyx_string_tab[144]
#define __pyx_kp_u__16 __pyx_string_tab[145]
#define __pyx_kp_u__17 __pyx_string_tab[146]
#define __pyx_kp_u__18 __pyx_string_tab[147]
#define __pyx_kp_u__19 __pyx_string_tab[148]
#define __pyx_kp_u__2 __pyx_string_tab[149]
#define __pyx_kp_u__20 __pyx_string_tab[150]
#define __pyx_n_u__21 __pyx_string_tab[151]
#define __pyx_kp_u__3 __pyx_string_tab[152]
#define __pyx_kp_u__4 __pyx_string_tab[153]
#define __pyx_kp_u__5 __pyx_string_tab[154]
#define __pyx_kp_u__6 __pyx_string_tab[155]
#define __pyx_kp_u__7 __pyx_string_tab[156]
#define __pyx_kp_u__8 __pyx_string_tab[157]
#define __pyx_kp_u__9 __pyx_string_tab[158]
#define __pyx_n_u_a __pyx_string_tab[159]
#define __pyx_kp_u_a9_advan __pyx_string_tab[160]
#define __pyx_kp_u_a_z_2_a_z_2 __pyx_string_tab[161]
#define __pyx_n_u_advan __pyx_string_tab[162]
#define __pyx_n_u_agen __pyx_string_tab[163]
#define __pyx_n_u_alias __pyx_string_tab[164]
#define __pyx_n_u_android __pyx_string_tab[165]
#define __pyx_kp_u_applewebkit_khtml_like_gecko __pyx_string_tab[166]
#define __pyx_n_u_architectures __pyx_string_tab[167]
#define __pyx_kp_u_arm64_v8a __pyx_string_tab[168]
#define __pyx_kp_u_armeabi_v7a_armeabi __pyx_string_tab[169]
#define __pyx_n_u_asyncio_coroutines __pyx_string_tab[170]
#define __pyx_n_u_b __pyx_string_tab[171]
#define __pyx_n_u_b2 __pyx_string_tab[172]
#define __pyx_kp_u_bFlow_b __pyx_string_tab[173]
#define __pyx_n_u_biru __pyx_string_tab[174]
#define __pyx_n_u_blue __pyx_string_tab[175]
#define __pyx_kp_u_bold_blue __pyx_string_tab[176]
#define __pyx_kp_u_bold_cyan __pyx_string_tab[177]
#define __pyx_kp_u_bold_green __pyx_string_tab[178]
#define __pyx_kp_u_bold_green_2 __pyx_string_tab[179]
#define __pyx_kp_u_bold_magenta __pyx_string_tab[180]
#define __pyx_kp_u_bold_magenta_2 __pyx_string_tab[181]
#define __pyx_kp_u_bold_red __pyx_string_tab[182]
#define __pyx_kp_u_bold_white __pyx_string_tab[183]
#define __pyx_kp_u_bold_yellow __pyx_string_tab[184]
#define __pyx_kp_u_bold_yellow_2 __pyx_string_tab[185]
#define __pyx_n_u_border_style __pyx_string_tab[186]
#define __pyx_n_u_br __pyx_string_tab[187]
#define __pyx_kp_u_brand __pyx_string_tab[188]
#define __pyx_n_u_brand_key __pyx_string_tab[189]
#define __pyx_n_u_brand_path __pyx_string_tab[190]
#define __pyx_n_u_brand_text __pyx_string_tab[191]
#define __pyx_n_u_brand_url __pyx_string_tab[192]
#define __pyx_n_u_bs4 __pyx_string_tab[193]
#define __pyx_n_u_build __pyx_string_tab[194]
#define __pyx_n_u_build_match __pyx_string_tab[195]
#define __pyx_kp_u_bwv_b __pyx_string_tab[196]
#define __pyx_n_u_c __pyx_string_tab[197]
#define __pyx_n_u_c2 __pyx_string_tab[198]
#define __pyx_n_u_cari __pyx_string_tab[199]
#define __pyx_n_u_center __pyx_string_tab[200]
#define __pyx_n_u_ceri __pyx_string_tab[201]
#define __pyx_n_u_choice __pyx_string_tab[202]
#define __pyx_n_u_cik __pyx_string_tab[203]
#define __pyx_n_u_class __pyx_string_tab[204]
#define __pyx_n_u_cline_in_traceback __pyx_string_tab[205]
#define __pyx_n_u_columns __pyx_string_tab[206]
#define __pyx_kp_u_com_ea_gp_nbamobile __pyx_string_tab[207]
#define __pyx_kp_u_com_g5e_hiddencity_android __pyx_string_tab[208]
#define __pyx_kp_u_com_g5e_sherlock_android __pyx_string_tab[209]
#define __pyx_kp_u_com_gameloft_android_ANMP_GloftD __pyx_string_tab[210]
#define __pyx_kp_u_com_grandegames_slots_dafu_casin __pyx_string_tab[211]
#define __pyx_kp_u_com_ikeyboard_theme_pink_rgb_hea __pyx_string_tab[212]
#define __pyx_kp_u_com_ludia_dragons __pyx_string_tab[213]
#define __pyx_kp_u_com_moonfrog_ludo_club __pyx_string_tab[214]
#define __pyx_kp_u_com_teenpatti_hd_gold __pyx_string_tab[215]
#define __pyx_kp_u_com_tongitsgo_play __pyx_string_tab[216]
#define __pyx_n_u_console __pyx_string_tab[217]
#define __pyx_n_u_create __pyx_string_tab[218]
#define __pyx_n_u_cyan __pyx_string_tab[219]
#define __pyx_kp_u_d_d __pyx_string_tab[220]
#define __pyx_n_u_densities __pyx_string_tab[221]
#define __pyx_n_u_determine_merek_from_model __pyx_string_tab[222]
#define __pyx_kp_u_device __pyx_string_tab[223]
#define __pyx_n_u_device_links __pyx_string_tab[224]
#define __pyx_n_u_device_url __pyx_string_tab[225]
#define __pyx_n_u_e __pyx_string_tab[226]
#define __pyx_n_u_en_GB __pyx_string_tab[227]
#define __pyx_n_u_en_US __pyx_string_tab[228]
#define __pyx_n_u_encoding __pyx_string_tab[229]
#define __pyx_n_u_enter __pyx_string_tab[230]
#define __pyx_n_u_errors __pyx_string_tab[231]
#define __pyx_n_u_exit __pyx_string_tab[232]
#define __pyx_n_u_extract_model_from_parentheses __pyx_string_tab[233]
#define __pyx_n_u_f __pyx_string_tab[234]
#define __pyx_n_u_fallback __pyx_string_tab[235]
#define __pyx_n_u_fbab __pyx_string_tab[236]
#define __pyx_n_u_fbav __pyx_string_tab[237]
#define __pyx_n_u_fbav2 __pyx_string_tab[238]
#define __pyx_n_u_fbbv __pyx_string_tab[239]
#define __pyx_n_u_fbbv2 __pyx_string_tab[240]
#define __pyx_n_u_fbs_v __pyx_string_tab[241]
#define __pyx_n_u_fbvs __pyx_string_tab[242]
#define __pyx_n_u_find_all __pyx_string_tab[243]
#define __pyx_n_u_flags __pyx_string_tab[244]
#define __pyx_n_u_fullmatch __pyx_string_tab[245]
#define __pyx_n_u_func __pyx_string_tab[246]
#define __pyx_n_u_g __pyx_string_tab[247]
#define __pyx_n_u_g2 __pyx_string_tab[248]
#define __pyx_n_u_get __pyx_string_tab[249]
#define __pyx_n_u_get_terminal_size __pyx_string_tab[250]
#define __pyx_n_u_get_text __pyx_string_tab[251]
#define __pyx_n_u_gr __pyx_string_tab[252]
#define __pyx_n_u_group __pyx_string_tab[253]
#define __pyx_n_u_has_wv __pyx_string_tab[254]
#define __pyx_n_u_hasil __pyx_string_tab[255]
#define __pyx_n_u_height __pyx_string_tab[256]
#define __pyx_kp_u_height_2 __pyx_string_tab[257]
#define __pyx_n_u_heights __pyx_string_tab[258]
#define __pyx_n_u_hijau __pyx_string_tab[259]
#define __pyx_n_u_hitung __pyx_string_tab[260]
#define __pyx_n_u_href __pyx_string_tab[261]
#define __pyx_kp_u_html_parser __pyx_string_tab[262]
#define __pyx_kp_u_https_whatmyuseragent_com __pyx_string_tab[263]
#define __pyx_kp_u_hu_huawei __pyx_string_tab[264]
#define __pyx_n_u_huawei __pyx_string_tab[265]
#define __pyx_n_u_id_ID __pyx_string_tab[266]
#define __pyx_kp_u_if_infinix __pyx_string_tab[267]
#define __pyx_n_u_ignore __pyx_string_tab[268]
#define __pyx_n_u_infinix __pyx_string_tab[269]
#define __pyx_n_u_info __pyx_string_tab[270]
#define __pyx_n_u_initializing __pyx_string_tab[271]
#define __pyx_n_u_inside __pyx_string_tab[272]
#define __pyx_n_u_is_coroutine __pyx_string_tab[273]
#define __pyx_n_u_isi __pyx_string_tab[274]
#define __pyx_n_u_item __pyx_string_tab[275]
#define __pyx_n_u_k __pyx_string_tab[276]
#define __pyx_n_u_kata __pyx_string_tab[277]
#define __pyx_n_u_key __pyx_string_tab[278]
#define __pyx_n_u_keys __pyx_string_tab[279]
#define __pyx_n_u_kuning __pyx_string_tab[280]
#define __pyx_n_u_label __pyx_string_tab[281]
#define __pyx_n_u_lebar __pyx_string_tab[282]
#define __pyx_n_u_lebar_terminal __pyx_string_tab[283]
#define __pyx_n_u_line __pyx_string_tab[284]
#define __pyx_n_u_lines __pyx_string_tab[285]
#define __pyx_n_u_link __pyx_string_tab[286]
#define __pyx_n_u_load_models_from_user_file __pyx_string_tab[287]
#define __pyx_n_u_locales __pyx_string_tab[288]
#define __pyx_n_u_lower __pyx_string_tab[289]
#define __pyx_n_u_m __pyx_string_tab[290]
#define __pyx_n_u_m_paren __pyx_string_tab[291]
#define __pyx_n_u_main __pyx_string_tab[292]
#define __pyx_n_u_merah __pyx_string_tab[293]
#define __pyx_n_u_merek __pyx_string_tab[294]
#define __pyx_n_u_merek1 __pyx_string_tab[295]
#define __pyx_n_u_mode_dua __pyx_string_tab[296]
#define __pyx_n_u_mode_empat __pyx_string_tab[297]
#define __pyx_n_u_mode_satu __pyx_string_tab[298]
#define __pyx_n_u_mode_tiga __pyx_string_tab[299]
#define __pyx_n_u_model __pyx_string_tab[300]
#define __pyx_n_u_model_in_build __pyx_string_tab[301]
#define __pyx_n_u_model_in_build2 __pyx_string_tab[302]
#define __pyx_n_u_models __pyx_string_tab[303]
#define __pyx_n_u_module __pyx_string_tab[304]
#define __pyx_n_u_motorola __pyx_string_tab[305]
#define __pyx_kp_u_mr_motorola __pyx_string_tab[306]
#define __pyx_n_u_nama __pyx_string_tab[307]
#define __pyx_n_u_name __pyx_string_tab[308]
#define __pyx_n_u_null __pyx_string_tab[309]
#define __pyx_kp_u_op_oppo __pyx_string_tab[310]
#define __pyx_n_u_open __pyx_string_tab[311]
#define __pyx_n_u_oppo __pyx_string_tab[312]
#define __pyx_n_u_oren __pyx_string_tab[313]
#define __pyx_n_u_os __pyx_string_tab[314]
#define __pyx_n_u_p __pyx_string_tab[315]
#define __pyx_n_u_p2 __pyx_string_tab[316]
#define __pyx_n_u_pake_dalvik __pyx_string_tab[317]
#define __pyx_n_u_pake_original __pyx_string_tab[318]
#define __pyx_n_u_pan __pyx_string_tab[319]
#define __pyx_n_u_panel __pyx_string_tab[320]
#define __pyx_n_u_panelku __pyx_string_tab[321]
#define __pyx_n_u_part __pyx_string_tab[322]
#define __pyx_n_u_parts __pyx_string_tab[323]
#define __pyx_n_u_path __pyx_string_tab[324]
#define __pyx_n_u_pilihanku __pyx_string_tab[325]
#define __pyx_n_u_piro __pyx_string_tab[326]
#define __pyx_n_u_pop __pyx_string_tab[327]
#define __pyx_n_u_print __pyx_string_tab[328]
#define __pyx_n_u_putih __pyx_string_tab[329]
#define __pyx_n_u_qualname __pyx_string_tab[330]
#define __pyx_n_u_r __pyx_string_tab[331]
#define __pyx_n_u_r2 __pyx_string_tab[332]
#define __pyx_n_u_raise_for_status __pyx_string_tab[333]
#define __pyx_n_u_random __pyx_string_tab[334]
#define __pyx_n_u_range __pyx_string_tab[335]
#define __pyx_n_u_re __pyx_string_tab[336]
#define __pyx_kp_u_re_realme __pyx_string_tab[337]
#define __pyx_n_u_realme __pyx_string_tab[338]
#define __pyx_n_u_red __pyx_string_tab[339]
#define __pyx_n_u_replace __pyx_string_tab[340]
#define __pyx_n_u_requests __pyx_string_tab[341]
#define __pyx_n_u_res_brand __pyx_string_tab[342]
#define __pyx_n_u_res_dev __pyx_string_tab[343]
#define __pyx_n_u_reset __pyx_string_tab[344]
#define __pyx_n_u_reset2 __pyx_string_tab[345]
#define __pyx_n_u_reversed __pyx_string_tab[346]
#define __pyx_n_u_rich_console __pyx_string_tab[347]
#define __pyx_n_u_rich_panel __pyx_string_tab[348]
#define __pyx_n_u_rstrip __pyx_string_tab[349]
#define __pyx_kp_u_s __pyx_string_tab[350]
#define __pyx_kp_u_s_2 __pyx_string_tab[351]
#define __pyx_kp_u_s_Build_b __pyx_string_tab[352]
#define __pyx_kp_u_sa_samsung __pyx_string_tab[353]
#define __pyx_n_u_samsung __pyx_string_tab[354]
#define __pyx_n_u_search __pyx_string_tab[355]
#define __pyx_n_u_selected_brands __pyx_string_tab[356]
#define __pyx_n_u_session __pyx_string_tab[357]
#define __pyx_n_u_set_name __pyx_string_tab[358]
#define __pyx_n_u_shutil __pyx_string_tab[359]
#define __pyx_n_u_soup __pyx_string_tab[360]
#define __pyx_n_u_soup_dev __pyx_string_tab[361]
#define __pyx_n_u_spec __pyx_string_tab[362]
#define __pyx_n_u_split __pyx_string_tab[363]
#define __pyx_n_u_st __pyx_string_tab[364]
#define __pyx_n_u_strip __pyx_string_tab[365]
#define __pyx_n_u_sub __pyx_string_tab[366]
#define __pyx_n_u_tanda __pyx_string_tab[367]
#define __pyx_kp_u_tb_tecno_mobile __pyx_string_tab[368]
#define __pyx_n_u_td __pyx_string_tab[369]
#define __pyx_n_u_tecno __pyx_string_tab[370]
#define __pyx_n_u_test __pyx_string_tab[371]
#define __pyx_n_u_text __pyx_string_tab[372]
#define __pyx_n_u_text_inside __pyx_string_tab[373]
#define __pyx_kp_u_tidak_ada_dalam_daftar_device __pyx_string_tab[374]
#define __pyx_n_u_tinggi __pyx_string_tab[375]
#define __pyx_n_u_title __pyx_string_tab[376]
#define __pyx_n_u_title_align __pyx_string_tab[377]
#define __pyx_n_u_tokens __pyx_string_tab[378]
#define __pyx_kp_u_u_wv __pyx_string_tab[379]
#define __pyx_n_u_ua __pyx_string_tab[380]
#define __pyx_n_u_uas __pyx_string_tab[381]
#define __pyx_n_u_ungu __pyx_string_tab[382]
#define __pyx_n_u_uniq __pyx_string_tab[383]
#define __pyx_n_u_up __pyx_string_tab[384]
#define __pyx_n_u_upper __pyx_string_tab[385]
#define __pyx_n_u_user_agent __pyx_string_tab[386]
#define __pyx_kp_u_user_agent_py __pyx_string_tab[387]
#define __pyx_n_u_user_agents_list __pyx_string_tab[388]
#define __pyx_kp_u_user_txt __pyx_string_tab[389]
#define __pyx_n_u_useragent __pyx_string_tab[390]
#define __pyx_kp_u_utf_8 __pyx_string_tab[391]
#define __pyx_n_u_values __pyx_string_tab[392]
#define __pyx_n_u_vivo __pyx_string_tab[393]
#define __pyx_kp_u_vv_vivo __pyx_string_tab[394]
#define __pyx_n_u_w __pyx_string_tab[395]
#define __pyx_n_u_w2 __pyx_string_tab[396]
#define __pyx_n_u_warna __pyx_string_tab[397]
#define __pyx_n_u_warna_dict __pyx_string_tab[398]
#define __pyx_n_u_werno __pyx_string_tab[399]
#define __pyx_n_u_white __pyx_string_tab[400]
#define __pyx_n_u_width __pyx_string_tab[401]
#define __pyx_kp_u_width_2 __pyx_string_tab[402]
#define __pyx_n_u_widths __pyx_string_tab[403]
#define __pyx_n_u_write __pyx_string_tab[404]
#define __pyx_n_u_wv __pyx_string_tab[405]
#define __pyx_kp_u_wv_2 __pyx_string_tab[406]
#define __pyx_kp_u_xi_xiaomi __pyx_string_tab[407]
#define __pyx_n_u_xiaomi __pyx_string_tab[408]
#define __pyx_n_u_y __pyx_string_tab[409]
#define __pyx_n_u_y2 __pyx_string_tab[410]

#if CYTHON_USE_MODULE_STATE
static CYTHON_SMALL_CODE int __pyx_m_clear(PyObject *m) {
  __pyx_mstatetype *clear_module_state = __Pyx_PyModule_GetState(m);
  if (!clear_module_state) return 0;
  Py_CLEAR(clear_module_state->__pyx_d);
  Py_CLEAR(clear_module_state->__pyx_b);
  Py_CLEAR(clear_module_state->__pyx_cython_runtime);
  Py_CLEAR(clear_module_state->__pyx_empty_tuple);
  Py_CLEAR(clear_module_state->__pyx_empty_bytes);
  Py_CLEAR(clear_module_state->__pyx_empty_unicode);
  #ifdef __Pyx_CyFunction_USED
  Py_CLEAR(clear_module_state->__pyx_CyFunctionType);
  #endif
  #ifdef __Pyx_FusedFunction_USED
  Py_CLEAR(clear_module_state->__pyx_FusedFunctionType);
  #endif
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  __Pyx_State_RemoveModule(NULL);
  #endif
  for (int i=0; i<16; ++i) { Py_CLEAR(clear_module_state->__pyx_tuple[i]); }
  for (int i=0; i<9; ++i) { Py_CLEAR(clear_module_state->__pyx_codeobj_tab[i]); }
  for (int i=0; i<411; ++i) { Py_CLEAR(clear_module_state->__pyx_string_tab[i]); }
  Py_CLEAR(clear_module_state->__pyx_int_0);
  Py_CLEAR(clear_module_state->__pyx_int_1);
  Py_CLEAR(clear_module_state->__pyx_int_4);
  Py_CLEAR(clear_module_state->__pyx_int_80);
  return 0;
}
#endif

#if CYTHON_USE_MODULE_STATE
static CYTHON_SMALL_CODE int __pyx_m_traverse(PyObject *m, visitproc visit, void *arg) {
  __pyx_mstatetype *traverse_module_state = __Pyx_PyModule_GetState(m);
  if (!traverse_module_state) return 0;
  Py_VISIT(traverse_module_state->__pyx_d);
  Py_VISIT(traverse_module_state->__pyx_b);
  Py_VISIT(traverse_module_state->__pyx_cython_runtime);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_empty_tuple);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_empty_bytes);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_empty_unicode);
  #ifdef __Pyx_CyFunction_USED
  Py_VISIT(traverse_module_state->__pyx_CyFunctionType);
  #endif
  #ifdef __Pyx_FusedFunction_USED
  Py_VISIT(traverse_module_state->__pyx_FusedFunctionType);
  #endif
  for (int i=0; i<16; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_tuple[i]); }
  for (int i=0; i<9; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_codeobj_tab[i]); }
  for (int i=0; i<411; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_string_tab[i]); }
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_int_0);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_int_1);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_int_4);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_int_80);
  return 0;
}
#endif





static PyObject *__pyx_pw_10user_agent_1warna(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_1warna = {"warna", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_1warna, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_1warna(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_nama = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[1] = {0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("warna (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_nama,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 30, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 30, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "warna", 0) < 0) __PYX_ERR(0, 30, __pyx_L3_error)
      for (Py_ssize_t i = __pyx_nargs; i < 1; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("warna", 1, 1, 1, i); __PYX_ERR(0, 30, __pyx_L3_error) }
      }
    } else if (unlikely(__pyx_nargs != 1)) {
      goto __pyx_L5_argtuple_error;
    } else {
      values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 30, __pyx_L3_error)
    }
    __pyx_v_nama = values[0];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("warna", 1, 1, 1, __pyx_nargs); __PYX_ERR(0, 30, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent.warna", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_warna(__pyx_self, __pyx_v_nama);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_warna(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_nama) {
  PyObject *__pyx_v_warna_dict = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  size_t __pyx_t_3;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("warna", 0);

  
  __pyx_t_1 = __Pyx_PyDict_NewPresized(7); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 32, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_kuning, __pyx_mstate_global->__pyx_kp_u_bold_yellow) < 0) __PYX_ERR(0, 32, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_merah, __pyx_mstate_global->__pyx_n_u_red) < 0) __PYX_ERR(0, 32, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_hijau, __pyx_mstate_global->__pyx_kp_u_bold_green) < 0) __PYX_ERR(0, 32, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_biru, __pyx_mstate_global->__pyx_n_u_blue) < 0) __PYX_ERR(0, 32, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_ungu, __pyx_mstate_global->__pyx_kp_u_bold_magenta) < 0) __PYX_ERR(0, 32, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_cyan, __pyx_mstate_global->__pyx_n_u_cyan) < 0) __PYX_ERR(0, 32, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_putih, __pyx_mstate_global->__pyx_n_u_white) < 0) __PYX_ERR(0, 32, __pyx_L1_error)
  __pyx_v_warna_dict = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __Pyx_XDECREF(__pyx_r);
  __pyx_t_2 = __pyx_v_nama;
  __Pyx_INCREF(__pyx_t_2);
  __pyx_t_3 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, NULL};
    __pyx_t_1 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_lower, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 40, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_t_2 = __Pyx_PyDict_GetItemDefault(__pyx_v_warna_dict, __pyx_t_1, __pyx_mstate_global->__pyx_n_u_white); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 40, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_r = __pyx_t_2;
  __pyx_t_2 = 0;
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_AddTraceback("user_agent.warna", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_warna_dict);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_3panelku(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_3panelku = {"panelku", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_3panelku, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_3panelku(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_label = 0;
  PyObject *__pyx_v_isi = 0;
  PyObject *__pyx_v_lebar = 0;
  PyObject *__pyx_v_tinggi = 0;
  PyObject *__pyx_v_werno = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[5] = {0,0,0,0,0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("panelku (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_label,&__pyx_mstate_global->__pyx_n_u_isi,&__pyx_mstate_global->__pyx_n_u_lebar,&__pyx_mstate_global->__pyx_n_u_tinggi,&__pyx_mstate_global->__pyx_n_u_werno,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 42, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  5:
        values[4] = __Pyx_ArgRef_FASTCALL(__pyx_args, 4);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[4])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  4:
        values[3] = __Pyx_ArgRef_FASTCALL(__pyx_args, 3);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[3])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "panelku", 0) < 0) __PYX_ERR(0, 42, __pyx_L3_error)
      if (!values[2]) values[2] = __Pyx_NewRef(((PyObject *)Py_None));
      if (!values[3]) values[3] = __Pyx_NewRef(((PyObject *)Py_None));
      if (!values[4]) values[4] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_n_u_cyan)));
      for (Py_ssize_t i = __pyx_nargs; i < 2; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("panelku", 0, 2, 5, i); __PYX_ERR(0, 42, __pyx_L3_error) }
      }
    } else {
      switch (__pyx_nargs) {
        case  5:
        values[4] = __Pyx_ArgRef_FASTCALL(__pyx_args, 4);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[4])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  4:
        values[3] = __Pyx_ArgRef_FASTCALL(__pyx_args, 3);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[3])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 42, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 42, __pyx_L3_error)
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 42, __pyx_L3_error)
        break;
        default: goto __pyx_L5_argtuple_error;
      }
      if (!values[2]) values[2] = __Pyx_NewRef(((PyObject *)Py_None));
      if (!values[3]) values[3] = __Pyx_NewRef(((PyObject *)Py_None));
      if (!values[4]) values[4] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_n_u_cyan)));
    }
    __pyx_v_label = values[0];
    __pyx_v_isi = values[1];
    __pyx_v_lebar = values[2];
    __pyx_v_tinggi = values[3];
    __pyx_v_werno = values[4];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("panelku", 0, 2, 5, __pyx_nargs); __PYX_ERR(0, 42, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent.panelku", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_2panelku(__pyx_self, __pyx_v_label, __pyx_v_isi, __pyx_v_lebar, __pyx_v_tinggi, __pyx_v_werno);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_2panelku(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_label, PyObject *__pyx_v_isi, PyObject *__pyx_v_lebar, PyObject *__pyx_v_tinggi, PyObject *__pyx_v_werno) {
  PyObject *__pyx_v_lebar_terminal = NULL;
  PyObject *__pyx_v_panel = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  int __pyx_t_1;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  PyObject *__pyx_t_6 = NULL;
  PyObject *__pyx_t_7 = NULL;
  PyObject *__pyx_t_8 = NULL;
  size_t __pyx_t_9;
  PyObject *__pyx_t_10 = NULL;
  PyObject *__pyx_t_11 = NULL;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("panelku", 0);
  __Pyx_INCREF(__pyx_v_lebar);

  
  __pyx_t_1 = (__pyx_v_lebar == Py_None);
  if (__pyx_t_1) {

    
    {
      __Pyx_PyThreadState_declare
      __Pyx_PyThreadState_assign
      __Pyx_ExceptionSave(&__pyx_t_2, &__pyx_t_3, &__pyx_t_4);
      __Pyx_XGOTREF(__pyx_t_2);
      __Pyx_XGOTREF(__pyx_t_3);
      __Pyx_XGOTREF(__pyx_t_4);
       {

        
        __pyx_t_6 = NULL;
        __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_shutil); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 46, __pyx_L4_error)
        __Pyx_GOTREF(__pyx_t_7);
        __pyx_t_8 = __Pyx_PyObject_GetAttrStr(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_get_terminal_size); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 46, __pyx_L4_error)
        __Pyx_GOTREF(__pyx_t_8);
        __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
        __pyx_t_9 = 1;
        #if CYTHON_UNPACK_METHODS
        if (unlikely(PyMethod_Check(__pyx_t_8))) {
          __pyx_t_6 = PyMethod_GET_SELF(__pyx_t_8);
          assert(__pyx_t_6);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_8);
          __Pyx_INCREF(__pyx_t_6);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_8, __pyx__function);
          __pyx_t_9 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_6, NULL};
          __pyx_t_5 = __Pyx_PyObject_FastCall(__pyx_t_8, __pyx_callargs+__pyx_t_9, (1-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
          __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
          if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 46, __pyx_L4_error)
          __Pyx_GOTREF(__pyx_t_5);
        }
        __pyx_t_8 = __Pyx_PyObject_GetAttrStr(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_columns); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 46, __pyx_L4_error)
        __Pyx_GOTREF(__pyx_t_8);
        __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
        __pyx_v_lebar_terminal = __pyx_t_8;
        __pyx_t_8 = 0;

        
      }
      __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
      __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
      __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
      goto __pyx_L9_try_end;
      __pyx_L4_error:;
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
      __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
      __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;

      
       {
        __Pyx_AddTraceback("user_agent.panelku", __pyx_clineno, __pyx_lineno, __pyx_filename);
        if (__Pyx_GetException(&__pyx_t_8, &__pyx_t_5, &__pyx_t_6) < 0) __PYX_ERR(0, 47, __pyx_L6_except_error)
        __Pyx_XGOTREF(__pyx_t_8);
        __Pyx_XGOTREF(__pyx_t_5);
        __Pyx_XGOTREF(__pyx_t_6);

        
        __Pyx_INCREF(__pyx_mstate_global->__pyx_int_80);
        __Pyx_XDECREF_SET(__pyx_v_lebar_terminal, __pyx_mstate_global->__pyx_int_80);
        __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
        __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
        __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
        goto __pyx_L5_exception_handled;
      }

      
      __pyx_L6_except_error:;
      __Pyx_XGIVEREF(__pyx_t_2);
      __Pyx_XGIVEREF(__pyx_t_3);
      __Pyx_XGIVEREF(__pyx_t_4);
      __Pyx_ExceptionReset(__pyx_t_2, __pyx_t_3, __pyx_t_4);
      goto __pyx_L1_error;
      __pyx_L5_exception_handled:;
      __Pyx_XGIVEREF(__pyx_t_2);
      __Pyx_XGIVEREF(__pyx_t_3);
      __Pyx_XGIVEREF(__pyx_t_4);
      __Pyx_ExceptionReset(__pyx_t_2, __pyx_t_3, __pyx_t_4);
      __pyx_L9_try_end:;
    }

    
    __pyx_t_6 = __Pyx_PyLong_SubtractObjC(__pyx_v_lebar_terminal, __pyx_mstate_global->__pyx_int_4, 4, 0, 0); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 50, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_6);
    __Pyx_DECREF_SET(__pyx_v_lebar, __pyx_t_6);
    __pyx_t_6 = 0;

    
  }

  
  __pyx_t_5 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_8, __pyx_mstate_global->__pyx_n_u_Panel); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 52, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_8);

  
  __pyx_t_10 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_11, __pyx_mstate_global->__pyx_n_u_warna); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 56, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_11);
  __pyx_t_9 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_11))) {
    __pyx_t_10 = PyMethod_GET_SELF(__pyx_t_11);
    assert(__pyx_t_10);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_11);
    __Pyx_INCREF(__pyx_t_10);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_11, __pyx__function);
    __pyx_t_9 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_10, __pyx_v_werno};
    __pyx_t_7 = __Pyx_PyObject_FastCall(__pyx_t_11, __pyx_callargs+__pyx_t_9, (2-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 56, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
  }

  
  __pyx_t_9 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_8))) {
    __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_8);
    assert(__pyx_t_5);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_8);
    __Pyx_INCREF(__pyx_t_5);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_8, __pyx__function);
    __pyx_t_9 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2 + ((CYTHON_VECTORCALL) ? 5 : 0)] = {__pyx_t_5, __pyx_v_isi};
    __pyx_t_11 = __Pyx_MakeVectorcallBuilderKwds(5); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 52, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_title, __pyx_v_label, __pyx_t_11, __pyx_callargs+2, 0) < 0) __PYX_ERR(0, 52, __pyx_L1_error)
    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_title_align, __pyx_mstate_global->__pyx_n_u_center, __pyx_t_11, __pyx_callargs+2, 1) < 0) __PYX_ERR(0, 52, __pyx_L1_error)
    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_border_style, __pyx_t_7, __pyx_t_11, __pyx_callargs+2, 2) < 0) __PYX_ERR(0, 52, __pyx_L1_error)
    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_width, __pyx_v_lebar, __pyx_t_11, __pyx_callargs+2, 3) < 0) __PYX_ERR(0, 52, __pyx_L1_error)
    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_height, __pyx_v_tinggi, __pyx_t_11, __pyx_callargs+2, 4) < 0) __PYX_ERR(0, 52, __pyx_L1_error)
    __pyx_t_6 = __Pyx_Object_Vectorcall_CallFromBuilder(__pyx_t_8, __pyx_callargs+__pyx_t_9, (2-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_11);
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
    if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 52, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_6);
  }
  __pyx_v_panel = __pyx_t_6;
  __pyx_t_6 = 0;

  
  __pyx_t_8 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_11, __pyx_mstate_global->__pyx_n_u_console); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 60, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_11);
  __pyx_t_7 = __Pyx_PyObject_GetAttrStr(__pyx_t_11, __pyx_mstate_global->__pyx_n_u_print); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 60, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_7);
  __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
  __pyx_t_9 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_7))) {
    __pyx_t_8 = PyMethod_GET_SELF(__pyx_t_7);
    assert(__pyx_t_8);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_7);
    __Pyx_INCREF(__pyx_t_8);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_7, __pyx__function);
    __pyx_t_9 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_8, __pyx_v_panel};
    __pyx_t_6 = __Pyx_PyObject_FastCall(__pyx_t_7, __pyx_callargs+__pyx_t_9, (2-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 60, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_6);
  }
  __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;

  

  
  __pyx_r = Py_None; __Pyx_INCREF(Py_None);
  goto __pyx_L0;
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_6);
  __Pyx_XDECREF(__pyx_t_7);
  __Pyx_XDECREF(__pyx_t_8);
  __Pyx_XDECREF(__pyx_t_10);
  __Pyx_XDECREF(__pyx_t_11);
  __Pyx_AddTraceback("user_agent.panelku", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_lebar_terminal);
  __Pyx_XDECREF(__pyx_v_panel);
  __Pyx_XDECREF(__pyx_v_lebar);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_5st(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_5st = {"st", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_5st, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_5st(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_kata = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[1] = {0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("st (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_kata,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 62, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 62, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "st", 0) < 0) __PYX_ERR(0, 62, __pyx_L3_error)
      for (Py_ssize_t i = __pyx_nargs; i < 1; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("st", 1, 1, 1, i); __PYX_ERR(0, 62, __pyx_L3_error) }
      }
    } else if (unlikely(__pyx_nargs != 1)) {
      goto __pyx_L5_argtuple_error;
    } else {
      values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 62, __pyx_L3_error)
    }
    __pyx_v_kata = values[0];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("st", 1, 1, 1, __pyx_nargs); __PYX_ERR(0, 62, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent.st", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_4st(__pyx_self, __pyx_v_kata);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_4st(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_kata) {
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  PyObject *__pyx_t_6 = NULL;
  PyObject *__pyx_t_7 = NULL;
  PyObject *__pyx_t_8 = NULL;
  PyObject *__pyx_t_9 = NULL;
  PyObject *__pyx_t_10 = NULL;
  PyObject *__pyx_t_11[17];
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("st", 0);

  
  __Pyx_XDECREF(__pyx_r);
  __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_w2); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_2 = __Pyx_PyObject_FormatSimple(__pyx_t_1, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_r2); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_3 = __Pyx_PyObject_FormatSimple(__pyx_t_1, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_y2); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_4 = __Pyx_PyObject_FormatSimple(__pyx_t_1, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_g2); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_5 = __Pyx_PyObject_FormatSimple(__pyx_t_1, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_w2); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_6 = __Pyx_PyObject_FormatSimple(__pyx_t_1, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_6);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_t_1 = __Pyx_PyObject_FormatSimple(__pyx_v_kata, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_g2); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_7);
  __pyx_t_8 = __Pyx_PyObject_FormatSimple(__pyx_t_7, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_8);
  __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_y2); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_7);
  __pyx_t_9 = __Pyx_PyObject_FormatSimple(__pyx_t_7, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_9)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_9);
  __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_r2); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_7);
  __pyx_t_10 = __Pyx_PyObject_FormatSimple(__pyx_t_7, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_10);
  __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
  __pyx_t_11[0] = __pyx_t_2;
  __pyx_t_11[1] = __pyx_t_3;
  __pyx_t_11[2] = __pyx_mstate_global->__pyx_kp_u_;
  __pyx_t_11[3] = __pyx_t_4;
  __pyx_t_11[4] = __pyx_mstate_global->__pyx_kp_u_;
  __pyx_t_11[5] = __pyx_t_5;
  __pyx_t_11[6] = __pyx_mstate_global->__pyx_kp_u__2;
  __pyx_t_11[7] = __pyx_t_6;
  __pyx_t_11[8] = __pyx_mstate_global->__pyx_kp_u__3;
  __pyx_t_11[9] = __pyx_t_1;
  __pyx_t_11[10] = __pyx_mstate_global->__pyx_kp_u__3;
  __pyx_t_11[11] = __pyx_t_8;
  __pyx_t_11[12] = __pyx_mstate_global->__pyx_kp_u_;
  __pyx_t_11[13] = __pyx_t_9;
  __pyx_t_11[14] = __pyx_mstate_global->__pyx_kp_u_;
  __pyx_t_11[15] = __pyx_t_10;
  __pyx_t_11[16] = __pyx_mstate_global->__pyx_kp_u__2;
  __pyx_t_7 = __Pyx_PyUnicode_Join(__pyx_t_11, 17, __Pyx_PyUnicode_GET_LENGTH(__pyx_t_2) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_3) + 2 * 4 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_4) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_5) + 1 * 4 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_6) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_1) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_8) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_9) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_10), 65535 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_2) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_3) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_4) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_5) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_6) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_1) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_8) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_9) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_10));
  if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 63, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_7);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
  __Pyx_DECREF(__pyx_t_9); __pyx_t_9 = 0;
  __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
  __pyx_r = __pyx_t_7;
  __pyx_t_7 = 0;
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_XDECREF(__pyx_t_4);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_6);
  __Pyx_XDECREF(__pyx_t_7);
  __Pyx_XDECREF(__pyx_t_8);
  __Pyx_XDECREF(__pyx_t_9);
  __Pyx_XDECREF(__pyx_t_10);
  __Pyx_AddTraceback("user_agent.st", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_7pake_original(PyObject *__pyx_self, CYTHON_UNUSED PyObject *unused); 
static PyMethodDef __pyx_mdef_10user_agent_7pake_original = {"pake_original", (PyCFunction)__pyx_pw_10user_agent_7pake_original, METH_NOARGS, 0};
static PyObject *__pyx_pw_10user_agent_7pake_original(PyObject *__pyx_self, CYTHON_UNUSED PyObject *unused) {
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("pake_original (wrapper)", 0);
  __pyx_kwvalues = __Pyx_KwValues_VARARGS(__pyx_args, __pyx_nargs);
  __pyx_r = __pyx_pf_10user_agent_6pake_original(__pyx_self);

  
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_6pake_original(CYTHON_UNUSED PyObject *__pyx_self) {
  PyObject *__pyx_v_f = NULL;
  PyObject *__pyx_v_lines = NULL;
  PyObject *__pyx_v_e = NULL;
  PyObject *__pyx_7genexpr__pyx_v_line = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  PyObject *__pyx_t_6 = NULL;
  PyObject *__pyx_t_7 = NULL;
  PyObject *__pyx_t_8 = NULL;
  size_t __pyx_t_9;
  PyObject *__pyx_t_10 = NULL;
  PyObject *__pyx_t_11 = NULL;
  PyObject *__pyx_t_12 = NULL;
  Py_ssize_t __pyx_t_13;
  PyObject *(*__pyx_t_14)(PyObject *);
  int __pyx_t_15;
  PyObject *__pyx_t_16 = NULL;
  int __pyx_t_17;
  int __pyx_t_18;
  PyObject *__pyx_t_19 = NULL;
  PyObject *__pyx_t_20 = NULL;
  int __pyx_t_21;
  char const *__pyx_t_22;
  PyObject *__pyx_t_23 = NULL;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("pake_original", 0);

  
  {
    __Pyx_PyThreadState_declare
    __Pyx_PyThreadState_assign
    __Pyx_ExceptionSave(&__pyx_t_1, &__pyx_t_2, &__pyx_t_3);
    __Pyx_XGOTREF(__pyx_t_1);
    __Pyx_XGOTREF(__pyx_t_2);
    __Pyx_XGOTREF(__pyx_t_3);
     {

      
       {
        __pyx_t_4 = __Pyx_PyDict_NewPresized(1); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 68, __pyx_L3_error)
        __Pyx_GOTREF(__pyx_t_4);
        if (PyDict_SetItem(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_encoding, __pyx_mstate_global->__pyx_kp_u_utf_8) < 0) __PYX_ERR(0, 68, __pyx_L3_error)
        __pyx_t_5 = __Pyx_PyObject_Call(__pyx_builtin_open, __pyx_mstate_global->__pyx_tuple[0], __pyx_t_4); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 68, __pyx_L3_error)
        __Pyx_GOTREF(__pyx_t_5);
        __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
        __pyx_t_6 = __Pyx_PyObject_LookupSpecial(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_exit); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 68, __pyx_L3_error)
        __Pyx_GOTREF(__pyx_t_6);
        __pyx_t_7 = NULL;
        __pyx_t_8 = __Pyx_PyObject_LookupSpecial(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_enter); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 68, __pyx_L9_error)
        __Pyx_GOTREF(__pyx_t_8);
        __pyx_t_9 = 1;
        #if CYTHON_UNPACK_METHODS
        if (likely(PyMethod_Check(__pyx_t_8))) {
          __pyx_t_7 = PyMethod_GET_SELF(__pyx_t_8);
          assert(__pyx_t_7);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_8);
          __Pyx_INCREF(__pyx_t_7);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_8, __pyx__function);
          __pyx_t_9 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_7, NULL};
          __pyx_t_4 = __Pyx_PyObject_FastCall(__pyx_t_8, __pyx_callargs+__pyx_t_9, (1-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
          __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
          if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 68, __pyx_L9_error)
          __Pyx_GOTREF(__pyx_t_4);
        }
        __pyx_t_8 = __pyx_t_4;
        __pyx_t_4 = 0;
        __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
         {
          {
            __Pyx_PyThreadState_declare
            __Pyx_PyThreadState_assign
            __Pyx_ExceptionSave(&__pyx_t_10, &__pyx_t_11, &__pyx_t_12);
            __Pyx_XGOTREF(__pyx_t_10);
            __Pyx_XGOTREF(__pyx_t_11);
            __Pyx_XGOTREF(__pyx_t_12);
             {
              __pyx_v_f = __pyx_t_8;
              __pyx_t_8 = 0;

              
              { 
                __pyx_t_8 = PyList_New(0); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 69, __pyx_L21_error)
                __Pyx_GOTREF(__pyx_t_8);
                if (likely(PyList_CheckExact(__pyx_v_f)) || PyTuple_CheckExact(__pyx_v_f)) {
                  __pyx_t_5 = __pyx_v_f; __Pyx_INCREF(__pyx_t_5);
                  __pyx_t_13 = 0;
                  __pyx_t_14 = NULL;
                } else {
                  __pyx_t_13 = -1; __pyx_t_5 = PyObject_GetIter(__pyx_v_f); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 69, __pyx_L21_error)
                  __Pyx_GOTREF(__pyx_t_5);
                  __pyx_t_14 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_5); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 69, __pyx_L21_error)
                }
                for (;;) {
                  if (likely(!__pyx_t_14)) {
                    if (likely(PyList_CheckExact(__pyx_t_5))) {
                      {
                        Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_5);
                        #if !CYTHON_ASSUME_SAFE_SIZE
                        if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 69, __pyx_L21_error)
                        #endif
                        if (__pyx_t_13 >= __pyx_temp) break;
                      }
                      __pyx_t_4 = __Pyx_PyList_GetItemRef(__pyx_t_5, __pyx_t_13);
                      ++__pyx_t_13;
                    } else {
                      {
                        Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_5);
                        #if !CYTHON_ASSUME_SAFE_SIZE
                        if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 69, __pyx_L21_error)
                        #endif
                        if (__pyx_t_13 >= __pyx_temp) break;
                      }
                      #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                      __pyx_t_4 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_5, __pyx_t_13));
                      #else
                      __pyx_t_4 = __Pyx_PySequence_ITEM(__pyx_t_5, __pyx_t_13);
                      #endif
                      ++__pyx_t_13;
                    }
                    if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 69, __pyx_L21_error)
                  } else {
                    __pyx_t_4 = __pyx_t_14(__pyx_t_5);
                    if (unlikely(!__pyx_t_4)) {
                      PyObject* exc_type = PyErr_Occurred();
                      if (exc_type) {
                        if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 69, __pyx_L21_error)
                        PyErr_Clear();
                      }
                      break;
                    }
                  }
                  __Pyx_GOTREF(__pyx_t_4);
                  __Pyx_XDECREF_SET(__pyx_7genexpr__pyx_v_line, __pyx_t_4);
                  __pyx_t_4 = 0;
                  __pyx_t_7 = __pyx_7genexpr__pyx_v_line;
                  __Pyx_INCREF(__pyx_t_7);
                  __pyx_t_9 = 0;
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_7, NULL};
                    __pyx_t_4 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_9, (1-__pyx_t_9) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
                    if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 69, __pyx_L21_error)
                    __Pyx_GOTREF(__pyx_t_4);
                  }
                  __pyx_t_15 = __Pyx_PyObject_IsTrue(__pyx_t_4); if (unlikely((__pyx_t_15 < 0))) __PYX_ERR(0, 69, __pyx_L21_error)
                  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                  if (__pyx_t_15) {
                    __pyx_t_7 = __pyx_7genexpr__pyx_v_line;
                    __Pyx_INCREF(__pyx_t_7);
                    __pyx_t_9 = 0;
                    {
                      PyObject *__pyx_callargs[2] = {__pyx_t_7, NULL};
                      __pyx_t_4 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_9, (1-__pyx_t_9) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                      __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
                      if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 69, __pyx_L21_error)
                      __Pyx_GOTREF(__pyx_t_4);
                    }
                    if (unlikely(__Pyx_ListComp_Append(__pyx_t_8, (PyObject*)__pyx_t_4))) __PYX_ERR(0, 69, __pyx_L21_error)
                    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                  }
                }
                __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
                __Pyx_XDECREF(__pyx_7genexpr__pyx_v_line); __pyx_7genexpr__pyx_v_line = 0;
                goto __pyx_L26_exit_scope;
                __pyx_L21_error:;
                __Pyx_XDECREF(__pyx_7genexpr__pyx_v_line); __pyx_7genexpr__pyx_v_line = 0;
                goto __pyx_L13_error;
                __pyx_L26_exit_scope:;
              } 
              __pyx_v_lines = ((PyObject*)__pyx_t_8);
              __pyx_t_8 = 0;

              
            }
            __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
            __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
            __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
            goto __pyx_L18_try_end;
            __pyx_L13_error:;
            __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
            __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
            __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
            __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
             {
              __Pyx_AddTraceback("user_agent.pake_original", __pyx_clineno, __pyx_lineno, __pyx_filename);
              if (__Pyx_GetException(&__pyx_t_8, &__pyx_t_5, &__pyx_t_4) < 0) __PYX_ERR(0, 68, __pyx_L15_except_error)
              __Pyx_XGOTREF(__pyx_t_8);
              __Pyx_XGOTREF(__pyx_t_5);
              __Pyx_XGOTREF(__pyx_t_4);
              __pyx_t_7 = PyTuple_Pack(3, __pyx_t_8, __pyx_t_5, __pyx_t_4); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 68, __pyx_L15_except_error)
              __Pyx_GOTREF(__pyx_t_7);
              __pyx_t_16 = __Pyx_PyObject_Call(__pyx_t_6, __pyx_t_7, NULL);
              __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
              __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
              if (unlikely(!__pyx_t_16)) __PYX_ERR(0, 68, __pyx_L15_except_error)
              __Pyx_GOTREF(__pyx_t_16);
              __pyx_t_15 = __Pyx_PyObject_IsTrue(__pyx_t_16);
              __Pyx_DECREF(__pyx_t_16); __pyx_t_16 = 0;
              if (__pyx_t_15 < 0) __PYX_ERR(0, 68, __pyx_L15_except_error)
              __pyx_t_17 = (!__pyx_t_15);
              if (unlikely(__pyx_t_17)) {
                __Pyx_GIVEREF(__pyx_t_8);
                __Pyx_GIVEREF(__pyx_t_5);
                __Pyx_XGIVEREF(__pyx_t_4);
                __Pyx_ErrRestoreWithState(__pyx_t_8, __pyx_t_5, __pyx_t_4);
                __pyx_t_8 = 0;  __pyx_t_5 = 0;  __pyx_t_4 = 0; 
                __PYX_ERR(0, 68, __pyx_L15_except_error)
              }
              __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
              __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
              __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
              goto __pyx_L14_exception_handled;
            }
            __pyx_L15_except_error:;
            __Pyx_XGIVEREF(__pyx_t_10);
            __Pyx_XGIVEREF(__pyx_t_11);
            __Pyx_XGIVEREF(__pyx_t_12);
            __Pyx_ExceptionReset(__pyx_t_10, __pyx_t_11, __pyx_t_12);
            goto __pyx_L3_error;
            __pyx_L14_exception_handled:;
            __Pyx_XGIVEREF(__pyx_t_10);
            __Pyx_XGIVEREF(__pyx_t_11);
            __Pyx_XGIVEREF(__pyx_t_12);
            __Pyx_ExceptionReset(__pyx_t_10, __pyx_t_11, __pyx_t_12);
            __pyx_L18_try_end:;
          }
        }
         {
          {
            if (__pyx_t_6) {
              __pyx_t_12 = __Pyx_PyObject_Call(__pyx_t_6, __pyx_mstate_global->__pyx_tuple[1], NULL);
              __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
              if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 68, __pyx_L3_error)
              __Pyx_GOTREF(__pyx_t_12);
              __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
            }
            goto __pyx_L12;
          }
          __pyx_L12:;
        }
        goto __pyx_L30;
        __pyx_L9_error:;
        __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
        goto __pyx_L3_error;
        __pyx_L30:;
      }

      
      if (unlikely(!__pyx_v_lines)) { __Pyx_RaiseUnboundLocalError("lines"); __PYX_ERR(0, 71, __pyx_L3_error) }
      {
        Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_v_lines);
        if (unlikely(((!CYTHON_ASSUME_SAFE_SIZE) && __pyx_temp < 0))) __PYX_ERR(0, 71, __pyx_L3_error)
        __pyx_t_17 = (__pyx_temp != 0);
      }

      __pyx_t_15 = (!__pyx_t_17);
      if (__pyx_t_15) {

        
        __pyx_t_5 = NULL;
        __Pyx_INCREF(__pyx_builtin_print);
        __pyx_t_8 = __pyx_builtin_print; 
        __pyx_t_9 = 1;
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_mstate_global->__pyx_kp_u_File_kosong_atau_tidak_ada_User};
          __pyx_t_4 = __Pyx_PyObject_FastCall(__pyx_t_8, __pyx_callargs+__pyx_t_9, (2-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
          __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
          if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 72, __pyx_L3_error)
          __Pyx_GOTREF(__pyx_t_4);
        }
        __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

        
        __Pyx_XDECREF(__pyx_r);
        __pyx_r = Py_None; __Pyx_INCREF(Py_None);
        goto __pyx_L7_try_return;

        
      }

      
      __Pyx_XDECREF(__pyx_r);
      __pyx_t_8 = NULL;
      __Pyx_GetModuleGlobalName(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 75, __pyx_L3_error)
      __Pyx_GOTREF(__pyx_t_5);
      __pyx_t_7 = __Pyx_PyObject_GetAttrStr(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 75, __pyx_L3_error)
      __Pyx_GOTREF(__pyx_t_7);
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      if (unlikely(!__pyx_v_lines)) { __Pyx_RaiseUnboundLocalError("lines"); __PYX_ERR(0, 75, __pyx_L3_error) }
      __pyx_t_9 = 1;
      #if CYTHON_UNPACK_METHODS
      if (unlikely(PyMethod_Check(__pyx_t_7))) {
        __pyx_t_8 = PyMethod_GET_SELF(__pyx_t_7);
        assert(__pyx_t_8);
        PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_7);
        __Pyx_INCREF(__pyx_t_8);
        __Pyx_INCREF(__pyx__function);
        __Pyx_DECREF_SET(__pyx_t_7, __pyx__function);
        __pyx_t_9 = 0;
      }
      #endif
      {
        PyObject *__pyx_callargs[2] = {__pyx_t_8, __pyx_v_lines};
        __pyx_t_4 = __Pyx_PyObject_FastCall(__pyx_t_7, __pyx_callargs+__pyx_t_9, (2-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
        __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
        if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 75, __pyx_L3_error)
        __Pyx_GOTREF(__pyx_t_4);
      }
      __pyx_r = __pyx_t_4;
      __pyx_t_4 = 0;
      goto __pyx_L7_try_return;

      
    }
    __pyx_L3_error:;
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
    __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;

    
    __pyx_t_18 = __Pyx_PyErr_ExceptionMatches(((PyObject *)(((PyTypeObject*)PyExc_Exception))));
    if (__pyx_t_18) {
      __Pyx_AddTraceback("user_agent.pake_original", __pyx_clineno, __pyx_lineno, __pyx_filename);
      if (__Pyx_GetException(&__pyx_t_4, &__pyx_t_7, &__pyx_t_8) < 0) __PYX_ERR(0, 77, __pyx_L5_except_error)
      __Pyx_XGOTREF(__pyx_t_4);
      __Pyx_XGOTREF(__pyx_t_7);
      __Pyx_XGOTREF(__pyx_t_8);
      __Pyx_INCREF(__pyx_t_7);
      __pyx_v_e = __pyx_t_7;
       {

        
        __pyx_t_19 = NULL;
        __Pyx_INCREF(__pyx_builtin_print);
        __pyx_t_20 = __pyx_builtin_print; 
        __pyx_t_9 = 1;
        {
          PyObject *__pyx_callargs[3] = {__pyx_t_19, __pyx_mstate_global->__pyx_kp_u_Gagal_membaca_file, __pyx_v_e};
          __pyx_t_5 = __Pyx_PyObject_FastCall(__pyx_t_20, __pyx_callargs+__pyx_t_9, (3-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
          __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
          if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 78, __pyx_L37_error)
          __Pyx_GOTREF(__pyx_t_5);
        }
        __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

        
        __Pyx_XDECREF(__pyx_r);
        __pyx_r = Py_None; __Pyx_INCREF(Py_None);
        __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
        __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
        __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
        goto __pyx_L36_return;
      }

      
       {
        __pyx_L37_error:;
        {
          __Pyx_PyThreadState_declare
          __Pyx_PyThreadState_assign
          __pyx_t_6 = 0; __pyx_t_12 = 0; __pyx_t_11 = 0; __pyx_t_10 = 0; __pyx_t_16 = 0; __pyx_t_23 = 0;
          __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
          __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;
          __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
           __Pyx_ExceptionSwap(&__pyx_t_10, &__pyx_t_16, &__pyx_t_23);
          if ( unlikely(__Pyx_GetException(&__pyx_t_6, &__pyx_t_12, &__pyx_t_11) < 0)) __Pyx_ErrFetch(&__pyx_t_6, &__pyx_t_12, &__pyx_t_11);
          __Pyx_XGOTREF(__pyx_t_6);
          __Pyx_XGOTREF(__pyx_t_12);
          __Pyx_XGOTREF(__pyx_t_11);
          __Pyx_XGOTREF(__pyx_t_10);
          __Pyx_XGOTREF(__pyx_t_16);
          __Pyx_XGOTREF(__pyx_t_23);
          __pyx_t_18 = __pyx_lineno; __pyx_t_21 = __pyx_clineno; __pyx_t_22 = __pyx_filename;
          {
            __Pyx_DECREF(__pyx_v_e); __pyx_v_e = 0;
          }
          __Pyx_XGIVEREF(__pyx_t_10);
          __Pyx_XGIVEREF(__pyx_t_16);
          __Pyx_XGIVEREF(__pyx_t_23);
          __Pyx_ExceptionReset(__pyx_t_10, __pyx_t_16, __pyx_t_23);
          __Pyx_XGIVEREF(__pyx_t_6);
          __Pyx_XGIVEREF(__pyx_t_12);
          __Pyx_XGIVEREF(__pyx_t_11);
          __Pyx_ErrRestore(__pyx_t_6, __pyx_t_12, __pyx_t_11);
          __pyx_t_6 = 0; __pyx_t_12 = 0; __pyx_t_11 = 0; __pyx_t_10 = 0; __pyx_t_16 = 0; __pyx_t_23 = 0;
          __pyx_lineno = __pyx_t_18; __pyx_clineno = __pyx_t_21; __pyx_filename = __pyx_t_22;
          goto __pyx_L5_except_error;
        }
        __pyx_L36_return: {
          __pyx_t_23 = __pyx_r;
          __pyx_r = 0;
          __Pyx_DECREF(__pyx_v_e); __pyx_v_e = 0;
          __pyx_r = __pyx_t_23;
          __pyx_t_23 = 0;
          goto __pyx_L6_except_return;
        }
      }
    }
    goto __pyx_L5_except_error;

    
    __pyx_L5_except_error:;
    __Pyx_XGIVEREF(__pyx_t_1);
    __Pyx_XGIVEREF(__pyx_t_2);
    __Pyx_XGIVEREF(__pyx_t_3);
    __Pyx_ExceptionReset(__pyx_t_1, __pyx_t_2, __pyx_t_3);
    goto __pyx_L1_error;
    __pyx_L7_try_return:;
    __Pyx_XGIVEREF(__pyx_t_1);
    __Pyx_XGIVEREF(__pyx_t_2);
    __Pyx_XGIVEREF(__pyx_t_3);
    __Pyx_ExceptionReset(__pyx_t_1, __pyx_t_2, __pyx_t_3);
    goto __pyx_L0;
    __pyx_L6_except_return:;
    __Pyx_XGIVEREF(__pyx_t_1);
    __Pyx_XGIVEREF(__pyx_t_2);
    __Pyx_XGIVEREF(__pyx_t_3);
    __Pyx_ExceptionReset(__pyx_t_1, __pyx_t_2, __pyx_t_3);
    goto __pyx_L0;
  }

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_4);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_7);
  __Pyx_XDECREF(__pyx_t_8);
  __Pyx_XDECREF(__pyx_t_19);
  __Pyx_XDECREF(__pyx_t_20);
  __Pyx_AddTraceback("user_agent.pake_original", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_f);
  __Pyx_XDECREF(__pyx_v_lines);
  __Pyx_XDECREF(__pyx_v_e);
  __Pyx_XDECREF(__pyx_7genexpr__pyx_v_line);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_9create(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_9create = {"create", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_9create, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_9create(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_alias = 0;
  PyObject *__pyx_v_cik = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[2] = {0,0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("create (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_alias,&__pyx_mstate_global->__pyx_n_u_cik,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 80, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 80, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 80, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "create", 0) < 0) __PYX_ERR(0, 80, __pyx_L3_error)
      if (!values[0]) values[0] = __Pyx_NewRef(((PyObject *)Py_None));
      if (!values[1]) values[1] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_kp_u_10)));
    } else {
      switch (__pyx_nargs) {
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 80, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 80, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      if (!values[0]) values[0] = __Pyx_NewRef(((PyObject *)Py_None));
      if (!values[1]) values[1] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_kp_u_10)));
    }
    __pyx_v_alias = values[0];
    __pyx_v_cik = values[1];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("create", 0, 0, 2, __pyx_nargs); __PYX_ERR(0, 80, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent.create", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_8create(__pyx_self, __pyx_v_alias, __pyx_v_cik);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_8create(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_alias, PyObject *__pyx_v_cik) {
  PyObject *__pyx_v_BASE_URL = NULL;
  PyObject *__pyx_v_BRAND_MAP = NULL;
  PyObject *__pyx_v_selected_brands = NULL;
  PyObject *__pyx_v_parts = NULL;
  PyObject *__pyx_v_br = NULL;
  PyObject *__pyx_v_brand_text = NULL;
  PyObject *__pyx_v_user_agents_list = NULL;
  PyObject *__pyx_v_piro = NULL;
  PyObject *__pyx_v_hitung = NULL;
  PyObject *__pyx_v_session = NULL;
  CYTHON_UNUSED PyObject *__pyx_v__ = NULL;
  PyObject *__pyx_v_brand_key = NULL;
  PyObject *__pyx_v_brand_path = NULL;
  PyObject *__pyx_v_brand_url = NULL;
  PyObject *__pyx_v_res_brand = NULL;
  PyObject *__pyx_v_soup = NULL;
  PyObject *__pyx_v_device_links = NULL;
  PyObject *__pyx_v_device_url = NULL;
  PyObject *__pyx_v_res_dev = NULL;
  PyObject *__pyx_v_soup_dev = NULL;
  PyObject *__pyx_v_uas = NULL;
  PyObject *__pyx_v_ua = NULL;
  PyObject *__pyx_v_fallback = NULL;
  PyObject *__pyx_v_f = NULL;
  PyObject *__pyx_v_e = NULL;
  PyObject *__pyx_8genexpr1__pyx_v_link = NULL;
  PyObject *__pyx_8genexpr2__pyx_v_td = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  int __pyx_t_2;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  size_t __pyx_t_6;
  Py_ssize_t __pyx_t_7;
  PyObject *(*__pyx_t_8)(PyObject *);
  int __pyx_t_9;
  PyObject *__pyx_t_10 = NULL;
  PyObject *__pyx_t_11 = NULL;
  PyObject *__pyx_t_12 = NULL;
  PyObject *__pyx_t_13 = NULL;
  PyObject *__pyx_t_14 = NULL;
  PyObject *__pyx_t_15[6];
  PyObject *__pyx_t_16[3];
  PyObject *__pyx_t_17 = NULL;
  PyObject *__pyx_t_18 = NULL;
  PyObject *__pyx_t_19 = NULL;
  PyObject *__pyx_t_20 = NULL;
  PyObject *__pyx_t_21 = NULL;
  PyObject *__pyx_t_22 = NULL;
  PyObject *__pyx_t_23 = NULL;
  Py_ssize_t __pyx_t_24;
  PyObject *(*__pyx_t_25)(PyObject *);
  int __pyx_t_26;
  PyObject *__pyx_t_27 = NULL;
  int __pyx_t_28;
  int __pyx_t_29;
  char const *__pyx_t_30;
  PyObject *__pyx_t_31 = NULL;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("create", 0);

  
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_https_whatmyuseragent_com);
  __pyx_v_BASE_URL = __pyx_mstate_global->__pyx_kp_u_https_whatmyuseragent_com;

  
  __pyx_t_1 = __Pyx_PyDict_NewPresized(10); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 84, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_motorola, __pyx_mstate_global->__pyx_kp_u_mr_motorola) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_advan, __pyx_mstate_global->__pyx_kp_u_a9_advan) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_huawei, __pyx_mstate_global->__pyx_kp_u_hu_huawei) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_vivo, __pyx_mstate_global->__pyx_kp_u_vv_vivo) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_realme, __pyx_mstate_global->__pyx_kp_u_re_realme) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_samsung, __pyx_mstate_global->__pyx_kp_u_sa_samsung) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_xiaomi, __pyx_mstate_global->__pyx_kp_u_xi_xiaomi) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_oppo, __pyx_mstate_global->__pyx_kp_u_op_oppo) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_infinix, __pyx_mstate_global->__pyx_kp_u_if_infinix) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_tecno, __pyx_mstate_global->__pyx_kp_u_tb_tecno_mobile) < 0) __PYX_ERR(0, 84, __pyx_L1_error)
  __pyx_v_BRAND_MAP = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 99, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_selected_brands = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_2 = __Pyx_PyObject_IsTrue(__pyx_v_alias); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 101, __pyx_L1_error)
  if (__pyx_t_2) {

    
    __pyx_t_5 = __pyx_v_alias;
    __Pyx_INCREF(__pyx_t_5);
    __pyx_t_6 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_5, NULL};
      __pyx_t_4 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_lower, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 103, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
    }
    __pyx_t_3 = __pyx_t_4;
    __Pyx_INCREF(__pyx_t_3);
    __pyx_t_6 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_mstate_global->__pyx_kp_u__4};
      __pyx_t_1 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_split, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 103, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __pyx_v_parts = __pyx_t_1;
    __pyx_t_1 = 0;

    
    if (likely(PyList_CheckExact(__pyx_v_parts)) || PyTuple_CheckExact(__pyx_v_parts)) {
      __pyx_t_1 = __pyx_v_parts; __Pyx_INCREF(__pyx_t_1);
      __pyx_t_7 = 0;
      __pyx_t_8 = NULL;
    } else {
      __pyx_t_7 = -1; __pyx_t_1 = PyObject_GetIter(__pyx_v_parts); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 104, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __pyx_t_8 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_1); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 104, __pyx_L1_error)
    }
    for (;;) {
      if (likely(!__pyx_t_8)) {
        if (likely(PyList_CheckExact(__pyx_t_1))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_1);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 104, __pyx_L1_error)
            #endif
            if (__pyx_t_7 >= __pyx_temp) break;
          }
          __pyx_t_4 = __Pyx_PyList_GetItemRef(__pyx_t_1, __pyx_t_7);
          ++__pyx_t_7;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_1);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 104, __pyx_L1_error)
            #endif
            if (__pyx_t_7 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_4 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_1, __pyx_t_7));
          #else
          __pyx_t_4 = __Pyx_PySequence_ITEM(__pyx_t_1, __pyx_t_7);
          #endif
          ++__pyx_t_7;
        }
        if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 104, __pyx_L1_error)
      } else {
        __pyx_t_4 = __pyx_t_8(__pyx_t_1);
        if (unlikely(!__pyx_t_4)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 104, __pyx_L1_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_4);
      __Pyx_XDECREF_SET(__pyx_v_br, __pyx_t_4);
      __pyx_t_4 = 0;

      
      __pyx_t_3 = __pyx_v_br;
      __Pyx_INCREF(__pyx_t_3);
      __pyx_t_6 = 0;
      {
        PyObject *__pyx_callargs[2] = {__pyx_t_3, NULL};
        __pyx_t_4 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
        if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 105, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_4);
      }
      __Pyx_DECREF_SET(__pyx_v_br, __pyx_t_4);
      __pyx_t_4 = 0;

      
      __pyx_t_2 = (__Pyx_PyDict_ContainsTF(__pyx_v_br, __pyx_v_BRAND_MAP, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 106, __pyx_L1_error)
      if (__pyx_t_2) {

        
        __pyx_t_9 = __Pyx_PyList_Append(__pyx_v_selected_brands, __pyx_v_br); if (unlikely(__pyx_t_9 == ((int)-1))) __PYX_ERR(0, 107, __pyx_L1_error)

        
        goto __pyx_L6;
      }

      
       {
        __pyx_t_4 = __Pyx_PyDict_Keys(__pyx_v_BRAND_MAP); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 110, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_4);
        __pyx_t_3 = PyUnicode_Join(__pyx_mstate_global->__pyx_kp_u__5, __pyx_t_4); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 110, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_3);
        __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
        __pyx_v_brand_text = ((PyObject*)__pyx_t_3);
        __pyx_t_3 = 0;

        
        __pyx_t_4 = NULL;
        __Pyx_INCREF(__pyx_builtin_print);
        __pyx_t_5 = __pyx_builtin_print; 
        __Pyx_GetModuleGlobalName(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_tanda); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_10);
        __pyx_t_11 = __Pyx_PyObject_FormatSimple(__pyx_t_10, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_11);
        __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
        __Pyx_GetModuleGlobalName(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_g); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_10);
        __pyx_t_12 = __Pyx_PyObject_FormatSimple(__pyx_t_10, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_12);
        __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
        __pyx_t_10 = __Pyx_PyObject_FormatSimple(__pyx_v_br, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_10);
        __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_w); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_13);
        __pyx_t_14 = __Pyx_PyObject_FormatSimple(__pyx_t_13, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_14);
        __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
        __pyx_t_15[0] = __pyx_t_11;
        __pyx_t_15[1] = __pyx_mstate_global->__pyx_kp_u__6;
        __pyx_t_15[2] = __pyx_t_12;
        __pyx_t_15[3] = __pyx_t_10;
        __pyx_t_15[4] = __pyx_t_14;
        __pyx_t_15[5] = __pyx_mstate_global->__pyx_kp_u_tidak_ada_dalam_daftar_device;
        __pyx_t_13 = __Pyx_PyUnicode_Join(__pyx_t_15, 6, __Pyx_PyUnicode_GET_LENGTH(__pyx_t_11) + 2 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_12) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_10) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_14) + 32, 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_11) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_12) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_10) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_14));
        if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 111, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_13);
        __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
        __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
        __pyx_t_6 = 1;
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_4, __pyx_t_13};
          __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
          __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
          __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
          if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 111, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_3);
        }
        __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

        
        __pyx_t_5 = NULL;
        __Pyx_INCREF(__pyx_builtin_print);
        __pyx_t_13 = __pyx_builtin_print; 
        __Pyx_GetModuleGlobalName(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_tanda); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 112, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_4);
        __pyx_t_14 = __Pyx_PyObject_FormatSimple(__pyx_t_4, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 112, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_14);
        __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
        __pyx_t_4 = __Pyx_PyUnicode_Unicode(__pyx_v_brand_text); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 112, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_4);
        __pyx_t_16[0] = __pyx_t_14;
        __pyx_t_16[1] = __pyx_mstate_global->__pyx_kp_u_Gunakan_salah_satu_dari;
        __pyx_t_16[2] = __pyx_t_4;
        __pyx_t_10 = __Pyx_PyUnicode_Join(__pyx_t_16, 3, __Pyx_PyUnicode_GET_LENGTH(__pyx_t_14) + 26 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_4), 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_14) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_4));
        if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 112, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_10);
        __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
        __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
        __pyx_t_6 = 1;
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_10};
          __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_13, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
          __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
          __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
          if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 112, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_3);
        }
        __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

        
        __Pyx_XDECREF(__pyx_r);
        __pyx_r = Py_None; __Pyx_INCREF(Py_None);
        __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
        goto __pyx_L0;
      }
      __pyx_L6:;

      
    }
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

    
    goto __pyx_L3;
  }

  
   {
    __Pyx_INCREF(Py_None);
    __Pyx_DECREF_SET(__pyx_v_selected_brands, ((PyObject*)Py_None));
  }
  __pyx_L3:;

  
  __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 118, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_user_agents_list = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_PyNumber_Int(__pyx_v_cik); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 119, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_piro = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __Pyx_INCREF(__pyx_mstate_global->__pyx_int_0);
  __pyx_v_hitung = __pyx_mstate_global->__pyx_int_0;

  
  {
    __Pyx_PyThreadState_declare
    __Pyx_PyThreadState_assign
    __Pyx_ExceptionSave(&__pyx_t_17, &__pyx_t_18, &__pyx_t_19);
    __Pyx_XGOTREF(__pyx_t_17);
    __Pyx_XGOTREF(__pyx_t_18);
    __Pyx_XGOTREF(__pyx_t_19);
     {

      
       {
        __pyx_t_3 = NULL;
        __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_requests); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 123, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_13);
        __pyx_t_10 = __Pyx_PyObject_GetAttrStr(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_Session); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 123, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_10);
        __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
        __pyx_t_6 = 1;
        #if CYTHON_UNPACK_METHODS
        if (unlikely(PyMethod_Check(__pyx_t_10))) {
          __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_10);
          assert(__pyx_t_3);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_10);
          __Pyx_INCREF(__pyx_t_3);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_10, __pyx__function);
          __pyx_t_6 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_3, NULL};
          __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_10, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
          __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
          if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 123, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_1);
        }
        __pyx_t_20 = __Pyx_PyObject_LookupSpecial(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_exit); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 123, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_20);
        __pyx_t_3 = NULL;
        __pyx_t_13 = __Pyx_PyObject_LookupSpecial(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_enter); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 123, __pyx_L14_error)
        __Pyx_GOTREF(__pyx_t_13);
        __pyx_t_6 = 1;
        #if CYTHON_UNPACK_METHODS
        if (likely(PyMethod_Check(__pyx_t_13))) {
          __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_13);
          assert(__pyx_t_3);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_13);
          __Pyx_INCREF(__pyx_t_3);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_13, __pyx__function);
          __pyx_t_6 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_3, NULL};
          __pyx_t_10 = __Pyx_PyObject_FastCall(__pyx_t_13, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
          __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
          if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 123, __pyx_L14_error)
          __Pyx_GOTREF(__pyx_t_10);
        }
        __pyx_t_13 = __pyx_t_10;
        __pyx_t_10 = 0;
        __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
         {
          {
            __Pyx_PyThreadState_declare
            __Pyx_PyThreadState_assign
            __Pyx_ExceptionSave(&__pyx_t_21, &__pyx_t_22, &__pyx_t_23);
            __Pyx_XGOTREF(__pyx_t_21);
            __Pyx_XGOTREF(__pyx_t_22);
            __Pyx_XGOTREF(__pyx_t_23);
             {
              __pyx_v_session = __pyx_t_13;
              __pyx_t_13 = 0;

              
              __pyx_t_1 = NULL;
              __Pyx_INCREF(__pyx_builtin_range);
              __pyx_t_10 = __pyx_builtin_range; 
              __pyx_t_6 = 1;
              {
                PyObject *__pyx_callargs[2] = {__pyx_t_1, __pyx_v_piro};
                __pyx_t_13 = __Pyx_PyObject_FastCall(__pyx_t_10, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
                __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
                if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 124, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_13);
              }
              if (likely(PyList_CheckExact(__pyx_t_13)) || PyTuple_CheckExact(__pyx_t_13)) {
                __pyx_t_10 = __pyx_t_13; __Pyx_INCREF(__pyx_t_10);
                __pyx_t_7 = 0;
                __pyx_t_8 = NULL;
              } else {
                __pyx_t_7 = -1; __pyx_t_10 = PyObject_GetIter(__pyx_t_13); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 124, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_10);
                __pyx_t_8 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_10); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 124, __pyx_L18_error)
              }
              __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
              for (;;) {
                if (likely(!__pyx_t_8)) {
                  if (likely(PyList_CheckExact(__pyx_t_10))) {
                    {
                      Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_10);
                      #if !CYTHON_ASSUME_SAFE_SIZE
                      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 124, __pyx_L18_error)
                      #endif
                      if (__pyx_t_7 >= __pyx_temp) break;
                    }
                    __pyx_t_13 = __Pyx_PyList_GetItemRef(__pyx_t_10, __pyx_t_7);
                    ++__pyx_t_7;
                  } else {
                    {
                      Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_10);
                      #if !CYTHON_ASSUME_SAFE_SIZE
                      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 124, __pyx_L18_error)
                      #endif
                      if (__pyx_t_7 >= __pyx_temp) break;
                    }
                    #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                    __pyx_t_13 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_10, __pyx_t_7));
                    #else
                    __pyx_t_13 = __Pyx_PySequence_ITEM(__pyx_t_10, __pyx_t_7);
                    #endif
                    ++__pyx_t_7;
                  }
                  if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 124, __pyx_L18_error)
                } else {
                  __pyx_t_13 = __pyx_t_8(__pyx_t_10);
                  if (unlikely(!__pyx_t_13)) {
                    PyObject* exc_type = PyErr_Occurred();
                    if (exc_type) {
                      if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 124, __pyx_L18_error)
                      PyErr_Clear();
                    }
                    break;
                  }
                }
                __Pyx_GOTREF(__pyx_t_13);
                if (!(likely(PyLong_CheckExact(__pyx_t_13))||((__pyx_t_13) == Py_None) || __Pyx_RaiseUnexpectedTypeError("int", __pyx_t_13))) __PYX_ERR(0, 124, __pyx_L18_error)
                __Pyx_XDECREF_SET(__pyx_v__, ((PyObject*)__pyx_t_13));
                __pyx_t_13 = 0;

                
                if (__pyx_v_selected_brands == Py_None) __pyx_t_2 = 0;
                else
                {
                  Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_v_selected_brands);
                  if (unlikely(((!CYTHON_ASSUME_SAFE_SIZE) && __pyx_temp < 0))) __PYX_ERR(0, 129, __pyx_L18_error)
                  __pyx_t_2 = (__pyx_temp != 0);
                }

                if (__pyx_t_2) {

                  
                  __pyx_t_1 = NULL;
                  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 131, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_3);
                  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 131, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_5);
                  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
                  __pyx_t_6 = 1;
                  #if CYTHON_UNPACK_METHODS
                  if (unlikely(PyMethod_Check(__pyx_t_5))) {
                    __pyx_t_1 = PyMethod_GET_SELF(__pyx_t_5);
                    assert(__pyx_t_1);
                    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
                    __Pyx_INCREF(__pyx_t_1);
                    __Pyx_INCREF(__pyx__function);
                    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
                    __pyx_t_6 = 0;
                  }
                  #endif
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_1, __pyx_v_selected_brands};
                    __pyx_t_13 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
                    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
                    if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 131, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_13);
                  }
                  __Pyx_XDECREF_SET(__pyx_v_brand_key, __pyx_t_13);
                  __pyx_t_13 = 0;

                  
                  goto __pyx_L26;
                }

                
                 {
                  __pyx_t_5 = NULL;
                  __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 134, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_1);
                  __pyx_t_3 = __Pyx_PyObject_GetAttrStr(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 134, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_3);
                  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
                  __pyx_t_1 = __Pyx_PyDict_Keys(__pyx_v_BRAND_MAP); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 134, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_1);
                  __pyx_t_4 = __Pyx_PySequence_ListKeepNew(__pyx_t_1); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 134, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_4);
                  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
                  __pyx_t_6 = 1;
                  #if CYTHON_UNPACK_METHODS
                  if (unlikely(PyMethod_Check(__pyx_t_3))) {
                    __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_3);
                    assert(__pyx_t_5);
                    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_3);
                    __Pyx_INCREF(__pyx_t_5);
                    __Pyx_INCREF(__pyx__function);
                    __Pyx_DECREF_SET(__pyx_t_3, __pyx__function);
                    __pyx_t_6 = 0;
                  }
                  #endif
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_4};
                    __pyx_t_13 = __Pyx_PyObject_FastCall(__pyx_t_3, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
                    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
                    if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 134, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_13);
                  }
                  __Pyx_XDECREF_SET(__pyx_v_brand_key, __pyx_t_13);
                  __pyx_t_13 = 0;
                }
                __pyx_L26:;

                
                __pyx_t_13 = __Pyx_PyDict_GetItem(__pyx_v_BRAND_MAP, __pyx_v_brand_key); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 136, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_13);
                __Pyx_XDECREF_SET(__pyx_v_brand_path, __pyx_t_13);
                __pyx_t_13 = 0;

                
                __pyx_t_13 = __Pyx_PyObject_FormatSimple(__pyx_v_brand_path, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 141, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_13);
                __pyx_t_16[0] = __pyx_v_BASE_URL;
                __pyx_t_16[1] = __pyx_mstate_global->__pyx_kp_u_brand;
                __pyx_t_16[2] = __pyx_t_13;
                __pyx_t_3 = __Pyx_PyUnicode_Join(__pyx_t_16, 3, __Pyx_PyUnicode_GET_LENGTH(__pyx_v_BASE_URL) + 7 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_13), 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_v_BASE_URL) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_13));
                if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 141, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_3);
                __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                __Pyx_XDECREF_SET(__pyx_v_brand_url, ((PyObject*)__pyx_t_3));
                __pyx_t_3 = 0;

                
                __pyx_t_13 = __pyx_v_session;
                __Pyx_INCREF(__pyx_t_13);
                __pyx_t_6 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_13, __pyx_v_brand_url};
                  __pyx_t_3 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_get, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
                  if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 142, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_3);
                }
                __Pyx_XDECREF_SET(__pyx_v_res_brand, __pyx_t_3);
                __pyx_t_3 = 0;

                
                __pyx_t_13 = __pyx_v_res_brand;
                __Pyx_INCREF(__pyx_t_13);
                __pyx_t_6 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_13, NULL};
                  __pyx_t_3 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_raise_for_status, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
                  if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 143, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_3);
                }
                __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

                
                __pyx_t_13 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_BeautifulSoup); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 145, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_4);
                __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_v_res_brand, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 145, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_5);
                __pyx_t_6 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_4))) {
                  __pyx_t_13 = PyMethod_GET_SELF(__pyx_t_4);
                  assert(__pyx_t_13);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_4);
                  __Pyx_INCREF(__pyx_t_13);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_4, __pyx__function);
                  __pyx_t_6 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[3] = {__pyx_t_13, __pyx_t_5, __pyx_mstate_global->__pyx_kp_u_html_parser};
                  __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_4, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
                  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
                  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                  if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 145, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_3);
                }
                __Pyx_XDECREF_SET(__pyx_v_soup, __pyx_t_3);
                __pyx_t_3 = 0;

                
                { 
                  __pyx_t_3 = PyList_New(0); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 147, __pyx_L29_error)
                  __Pyx_GOTREF(__pyx_t_3);

                  
                  __pyx_t_5 = __pyx_v_soup;
                  __Pyx_INCREF(__pyx_t_5);
                  __pyx_t_6 = 0;
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_mstate_global->__pyx_n_u_a};
                    __pyx_t_4 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_find_all, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
                    if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 149, __pyx_L29_error)
                    __Pyx_GOTREF(__pyx_t_4);
                  }
                  if (likely(PyList_CheckExact(__pyx_t_4)) || PyTuple_CheckExact(__pyx_t_4)) {
                    __pyx_t_5 = __pyx_t_4; __Pyx_INCREF(__pyx_t_5);
                    __pyx_t_24 = 0;
                    __pyx_t_25 = NULL;
                  } else {
                    __pyx_t_24 = -1; __pyx_t_5 = PyObject_GetIter(__pyx_t_4); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 149, __pyx_L29_error)
                    __Pyx_GOTREF(__pyx_t_5);
                    __pyx_t_25 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_5); if (unlikely(!__pyx_t_25)) __PYX_ERR(0, 149, __pyx_L29_error)
                  }
                  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                  for (;;) {
                    if (likely(!__pyx_t_25)) {
                      if (likely(PyList_CheckExact(__pyx_t_5))) {
                        {
                          Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_5);
                          #if !CYTHON_ASSUME_SAFE_SIZE
                          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 149, __pyx_L29_error)
                          #endif
                          if (__pyx_t_24 >= __pyx_temp) break;
                        }
                        __pyx_t_4 = __Pyx_PyList_GetItemRef(__pyx_t_5, __pyx_t_24);
                        ++__pyx_t_24;
                      } else {
                        {
                          Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_5);
                          #if !CYTHON_ASSUME_SAFE_SIZE
                          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 149, __pyx_L29_error)
                          #endif
                          if (__pyx_t_24 >= __pyx_temp) break;
                        }
                        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                        __pyx_t_4 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_5, __pyx_t_24));
                        #else
                        __pyx_t_4 = __Pyx_PySequence_ITEM(__pyx_t_5, __pyx_t_24);
                        #endif
                        ++__pyx_t_24;
                      }
                      if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 149, __pyx_L29_error)
                    } else {
                      __pyx_t_4 = __pyx_t_25(__pyx_t_5);
                      if (unlikely(!__pyx_t_4)) {
                        PyObject* exc_type = PyErr_Occurred();
                        if (exc_type) {
                          if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 149, __pyx_L29_error)
                          PyErr_Clear();
                        }
                        break;
                      }
                    }
                    __Pyx_GOTREF(__pyx_t_4);
                    __Pyx_XDECREF_SET(__pyx_8genexpr1__pyx_v_link, __pyx_t_4);
                    __pyx_t_4 = 0;

                    
                    __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_8genexpr1__pyx_v_link, __pyx_mstate_global->__pyx_n_u_get); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 150, __pyx_L29_error)
                    __Pyx_GOTREF(__pyx_t_4);
                    __pyx_t_13 = __Pyx_PyObject_Call(__pyx_t_4, __pyx_mstate_global->__pyx_tuple[2], NULL); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 150, __pyx_L29_error)
                    __Pyx_GOTREF(__pyx_t_13);
                    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                    __pyx_t_2 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_kp_u_device, __pyx_t_13, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 150, __pyx_L29_error)
                    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                    if (__pyx_t_2) {

                      
                      __pyx_t_4 = __pyx_8genexpr1__pyx_v_link;
                      __Pyx_INCREF(__pyx_t_4);
                      __pyx_t_6 = 0;
                      {
                        PyObject *__pyx_callargs[2] = {__pyx_t_4, __pyx_mstate_global->__pyx_n_u_href};
                        __pyx_t_13 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_get, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                        __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
                        if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 148, __pyx_L29_error)
                        __Pyx_GOTREF(__pyx_t_13);
                      }
                      if (unlikely(__Pyx_ListComp_Append(__pyx_t_3, (PyObject*)__pyx_t_13))) __PYX_ERR(0, 147, __pyx_L29_error)
                      __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;

                      
                    }

                    
                  }
                  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
                  __Pyx_XDECREF(__pyx_8genexpr1__pyx_v_link); __pyx_8genexpr1__pyx_v_link = 0;
                  goto __pyx_L34_exit_scope;
                  __pyx_L29_error:;
                  __Pyx_XDECREF(__pyx_8genexpr1__pyx_v_link); __pyx_8genexpr1__pyx_v_link = 0;
                  goto __pyx_L18_error;
                  __pyx_L34_exit_scope:;
                } 
                __Pyx_XDECREF_SET(__pyx_v_device_links, ((PyObject*)__pyx_t_3));
                __pyx_t_3 = 0;

                
                {
                  Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_v_device_links);
                  if (unlikely(((!CYTHON_ASSUME_SAFE_SIZE) && __pyx_temp < 0))) __PYX_ERR(0, 153, __pyx_L18_error)
                  __pyx_t_2 = (__pyx_temp != 0);
                }

                __pyx_t_26 = (!__pyx_t_2);
                if (__pyx_t_26) {

                  
                  __pyx_t_5 = NULL;
                  __Pyx_INCREF(__pyx_builtin_print);
                  __pyx_t_13 = __pyx_builtin_print; 
                  __Pyx_GetModuleGlobalName(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_tanda); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 154, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_4);
                  __pyx_t_1 = __Pyx_PyObject_FormatSimple(__pyx_t_4, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 154, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_1);
                  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                  __pyx_t_4 = __Pyx_PyObject_FormatSimple(__pyx_v_brand_key, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 154, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_4);
                  __pyx_t_16[0] = __pyx_t_1;
                  __pyx_t_16[1] = __pyx_mstate_global->__pyx_kp_u_Tidak_ditemukan_device_untuk_br;
                  __pyx_t_16[2] = __pyx_t_4;
                  __pyx_t_14 = __Pyx_PyUnicode_Join(__pyx_t_16, 3, __Pyx_PyUnicode_GET_LENGTH(__pyx_t_1) + 36 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_4), 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_1) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_4));
                  if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 154, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_14);
                  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
                  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                  __pyx_t_6 = 1;
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_14};
                    __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_13, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
                    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
                    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                    if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 154, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_3);
                  }
                  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

                  
                  goto __pyx_L24_continue;

                  
                }

                
                __pyx_t_13 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_14, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 157, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_14);
                __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_14, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 157, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_5);
                __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
                __pyx_t_6 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_5))) {
                  __pyx_t_13 = PyMethod_GET_SELF(__pyx_t_5);
                  assert(__pyx_t_13);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
                  __Pyx_INCREF(__pyx_t_13);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
                  __pyx_t_6 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_13, __pyx_v_device_links};
                  __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
                  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
                  if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 157, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_3);
                }
                __pyx_t_5 = PyNumber_Add(__pyx_v_BASE_URL, __pyx_t_3); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 157, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_5);
                __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
                __Pyx_XDECREF_SET(__pyx_v_device_url, __pyx_t_5);
                __pyx_t_5 = 0;

                
                __pyx_t_3 = __pyx_v_session;
                __Pyx_INCREF(__pyx_t_3);
                __pyx_t_6 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_v_device_url};
                  __pyx_t_5 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_get, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
                  if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 158, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_5);
                }
                __Pyx_XDECREF_SET(__pyx_v_res_dev, __pyx_t_5);
                __pyx_t_5 = 0;

                
                __pyx_t_3 = __pyx_v_res_dev;
                __Pyx_INCREF(__pyx_t_3);
                __pyx_t_6 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_3, NULL};
                  __pyx_t_5 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_raise_for_status, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
                  if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 159, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_5);
                }
                __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

                
                __pyx_t_3 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_BeautifulSoup); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 161, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_13);
                __pyx_t_14 = __Pyx_PyObject_GetAttrStr(__pyx_v_res_dev, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 161, __pyx_L18_error)
                __Pyx_GOTREF(__pyx_t_14);
                __pyx_t_6 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_13))) {
                  __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_13);
                  assert(__pyx_t_3);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_13);
                  __Pyx_INCREF(__pyx_t_3);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_13, __pyx__function);
                  __pyx_t_6 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[3] = {__pyx_t_3, __pyx_t_14, __pyx_mstate_global->__pyx_kp_u_html_parser};
                  __pyx_t_5 = __Pyx_PyObject_FastCall(__pyx_t_13, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
                  __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
                  __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                  if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 161, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_5);
                }
                __Pyx_XDECREF_SET(__pyx_v_soup_dev, __pyx_t_5);
                __pyx_t_5 = 0;

                
                { 
                  __pyx_t_5 = PyList_New(0); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 162, __pyx_L38_error)
                  __Pyx_GOTREF(__pyx_t_5);
                  __pyx_t_14 = __pyx_v_soup_dev;
                  __Pyx_INCREF(__pyx_t_14);
                  __pyx_t_6 = 0;
                  {
                    PyObject *__pyx_callargs[2 + ((CYTHON_VECTORCALL) ? 1 : 0)] = {__pyx_t_14, __pyx_mstate_global->__pyx_n_u_td};
                    __pyx_t_3 = __Pyx_MakeVectorcallBuilderKwds(1); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 162, __pyx_L38_error)
                    __Pyx_GOTREF(__pyx_t_3);
                    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_class, __pyx_mstate_global->__pyx_n_u_useragent, __pyx_t_3, __pyx_callargs+2, 0) < 0) __PYX_ERR(0, 162, __pyx_L38_error)
                    __pyx_t_13 = __Pyx_Object_VectorcallMethod_CallFromBuilder(__pyx_mstate_global->__pyx_n_u_find_all, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_3);
                    __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
                    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
                    if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 162, __pyx_L38_error)
                    __Pyx_GOTREF(__pyx_t_13);
                  }
                  if (likely(PyList_CheckExact(__pyx_t_13)) || PyTuple_CheckExact(__pyx_t_13)) {
                    __pyx_t_3 = __pyx_t_13; __Pyx_INCREF(__pyx_t_3);
                    __pyx_t_24 = 0;
                    __pyx_t_25 = NULL;
                  } else {
                    __pyx_t_24 = -1; __pyx_t_3 = PyObject_GetIter(__pyx_t_13); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 162, __pyx_L38_error)
                    __Pyx_GOTREF(__pyx_t_3);
                    __pyx_t_25 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_3); if (unlikely(!__pyx_t_25)) __PYX_ERR(0, 162, __pyx_L38_error)
                  }
                  __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                  for (;;) {
                    if (likely(!__pyx_t_25)) {
                      if (likely(PyList_CheckExact(__pyx_t_3))) {
                        {
                          Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_3);
                          #if !CYTHON_ASSUME_SAFE_SIZE
                          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 162, __pyx_L38_error)
                          #endif
                          if (__pyx_t_24 >= __pyx_temp) break;
                        }
                        __pyx_t_13 = __Pyx_PyList_GetItemRef(__pyx_t_3, __pyx_t_24);
                        ++__pyx_t_24;
                      } else {
                        {
                          Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_3);
                          #if !CYTHON_ASSUME_SAFE_SIZE
                          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 162, __pyx_L38_error)
                          #endif
                          if (__pyx_t_24 >= __pyx_temp) break;
                        }
                        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                        __pyx_t_13 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_3, __pyx_t_24));
                        #else
                        __pyx_t_13 = __Pyx_PySequence_ITEM(__pyx_t_3, __pyx_t_24);
                        #endif
                        ++__pyx_t_24;
                      }
                      if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 162, __pyx_L38_error)
                    } else {
                      __pyx_t_13 = __pyx_t_25(__pyx_t_3);
                      if (unlikely(!__pyx_t_13)) {
                        PyObject* exc_type = PyErr_Occurred();
                        if (exc_type) {
                          if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 162, __pyx_L38_error)
                          PyErr_Clear();
                        }
                        break;
                      }
                    }
                    __Pyx_GOTREF(__pyx_t_13);
                    __Pyx_XDECREF_SET(__pyx_8genexpr2__pyx_v_td, __pyx_t_13);
                    __pyx_t_13 = 0;
                    __pyx_t_14 = __pyx_8genexpr2__pyx_v_td;
                    __Pyx_INCREF(__pyx_t_14);
                    __pyx_t_6 = 0;
                    {
                      PyObject *__pyx_callargs[2 + ((CYTHON_VECTORCALL) ? 1 : 0)] = {__pyx_t_14, NULL};
                      __pyx_t_4 = __Pyx_MakeVectorcallBuilderKwds(1); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 162, __pyx_L38_error)
                      __Pyx_GOTREF(__pyx_t_4);
                      if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_strip, Py_True, __pyx_t_4, __pyx_callargs+1, 0) < 0) __PYX_ERR(0, 162, __pyx_L38_error)
                      __pyx_t_13 = __Pyx_Object_VectorcallMethod_CallFromBuilder(__pyx_mstate_global->__pyx_n_u_get_text, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_4);
                      __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
                      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                      if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 162, __pyx_L38_error)
                      __Pyx_GOTREF(__pyx_t_13);
                    }
                    if (unlikely(__Pyx_ListComp_Append(__pyx_t_5, (PyObject*)__pyx_t_13))) __PYX_ERR(0, 162, __pyx_L38_error)
                    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                  }
                  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
                  __Pyx_XDECREF(__pyx_8genexpr2__pyx_v_td); __pyx_8genexpr2__pyx_v_td = 0;
                  goto __pyx_L42_exit_scope;
                  __pyx_L38_error:;
                  __Pyx_XDECREF(__pyx_8genexpr2__pyx_v_td); __pyx_8genexpr2__pyx_v_td = 0;
                  goto __pyx_L18_error;
                  __pyx_L42_exit_scope:;
                } 
                __Pyx_XDECREF_SET(__pyx_v_uas, ((PyObject*)__pyx_t_5));
                __pyx_t_5 = 0;

                
                {
                  Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_v_uas);
                  if (unlikely(((!CYTHON_ASSUME_SAFE_SIZE) && __pyx_temp < 0))) __PYX_ERR(0, 164, __pyx_L18_error)
                  __pyx_t_26 = (__pyx_temp != 0);
                }

                if (__pyx_t_26) {

                  
                  __pyx_t_5 = __Pyx_PyLong_AddObjC(__pyx_v_hitung, __pyx_mstate_global->__pyx_int_1, 1, 1, 0); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 165, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_5);
                  __Pyx_DECREF_SET(__pyx_v_hitung, __pyx_t_5);
                  __pyx_t_5 = 0;

                  
                  __pyx_t_3 = NULL;
                  __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 166, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_13);
                  __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 166, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_4);
                  __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                  __pyx_t_6 = 1;
                  #if CYTHON_UNPACK_METHODS
                  if (unlikely(PyMethod_Check(__pyx_t_4))) {
                    __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_4);
                    assert(__pyx_t_3);
                    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_4);
                    __Pyx_INCREF(__pyx_t_3);
                    __Pyx_INCREF(__pyx__function);
                    __Pyx_DECREF_SET(__pyx_t_4, __pyx__function);
                    __pyx_t_6 = 0;
                  }
                  #endif
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_v_uas};
                    __pyx_t_5 = __Pyx_PyObject_FastCall(__pyx_t_4, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
                    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                    if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 166, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_5);
                  }
                  __Pyx_XDECREF_SET(__pyx_v_ua, __pyx_t_5);
                  __pyx_t_5 = 0;

                  
                  __pyx_t_4 = NULL;
                  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_panelku); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_3);
                  __pyx_t_14 = NULL;
                  __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_st); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_1);
                  __pyx_t_12 = __Pyx_PyObject_FormatSimple(__pyx_v_hitung, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_12);
                  __pyx_t_11 = __Pyx_PyUnicode_Concat(__pyx_mstate_global->__pyx_kp_u_USER_AGENT, __pyx_t_12); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_11);
                  __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
                  __pyx_t_6 = 1;
                  #if CYTHON_UNPACK_METHODS
                  if (unlikely(PyMethod_Check(__pyx_t_1))) {
                    __pyx_t_14 = PyMethod_GET_SELF(__pyx_t_1);
                    assert(__pyx_t_14);
                    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_1);
                    __Pyx_INCREF(__pyx_t_14);
                    __Pyx_INCREF(__pyx__function);
                    __Pyx_DECREF_SET(__pyx_t_1, __pyx__function);
                    __pyx_t_6 = 0;
                  }
                  #endif
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_14, __pyx_t_11};
                    __pyx_t_13 = __Pyx_PyObject_FastCall(__pyx_t_1, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
                    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
                    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
                    if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 167, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_13);
                  }
                  __pyx_t_1 = __Pyx_PyObject_FormatSimple(__pyx_t_13, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_1);
                  __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                  __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_p2); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_13);
                  __pyx_t_11 = __Pyx_PyObject_FormatSimple(__pyx_t_13, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_11);
                  __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                  __pyx_t_13 = __Pyx_PyObject_FormatSimple(__pyx_v_ua, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_13);
                  __pyx_t_14 = __Pyx_PyUnicode_ConcatInPlace(__pyx_t_11, __pyx_t_13); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 167, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_14);
                  __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
                  __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                  __pyx_t_6 = 1;
                  #if CYTHON_UNPACK_METHODS
                  if (unlikely(PyMethod_Check(__pyx_t_3))) {
                    __pyx_t_4 = PyMethod_GET_SELF(__pyx_t_3);
                    assert(__pyx_t_4);
                    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_3);
                    __Pyx_INCREF(__pyx_t_4);
                    __Pyx_INCREF(__pyx__function);
                    __Pyx_DECREF_SET(__pyx_t_3, __pyx__function);
                    __pyx_t_6 = 0;
                  }
                  #endif
                  {
                    PyObject *__pyx_callargs[5 + ((CYTHON_VECTORCALL) ? 1 : 0)] = {__pyx_t_4, __pyx_t_1, __pyx_t_14, Py_None, Py_None};
                    __pyx_t_13 = __Pyx_MakeVectorcallBuilderKwds(1); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 167, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_13);
                    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_werno, __pyx_mstate_global->__pyx_n_u_hijau, __pyx_t_13, __pyx_callargs+5, 0) < 0) __PYX_ERR(0, 167, __pyx_L18_error)
                    __pyx_t_5 = __Pyx_Object_Vectorcall_CallFromBuilder(__pyx_t_3, __pyx_callargs+__pyx_t_6, (5-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_13);
                    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
                    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
                    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
                    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
                    if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 167, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_5);
                  }
                  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

                  
                  __pyx_t_9 = __Pyx_PyList_Append(__pyx_v_user_agents_list, __pyx_v_ua); if (unlikely(__pyx_t_9 == ((int)-1))) __PYX_ERR(0, 168, __pyx_L18_error)

                  
                  goto __pyx_L43;
                }

                
                 {
                  __pyx_t_5 = __Pyx_PyLong_AddObjC(__pyx_v_hitung, __pyx_mstate_global->__pyx_int_1, 1, 1, 0); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 170, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_5);
                  __Pyx_DECREF_SET(__pyx_v_hitung, __pyx_t_5);
                  __pyx_t_5 = 0;

                  
                  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_Mozilla_5_0_Linux_Android_13_Inf);
                  __Pyx_XDECREF_SET(__pyx_v_fallback, __pyx_mstate_global->__pyx_kp_u_Mozilla_5_0_Linux_Android_13_Inf);

                  
                  __pyx_t_3 = NULL;
                  __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_panelku); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_13);
                  __pyx_t_1 = NULL;
                  __Pyx_GetModuleGlobalName(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_st); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_4);
                  __pyx_t_11 = __Pyx_PyObject_FormatSimple(__pyx_v_hitung, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_11);
                  __pyx_t_12 = __Pyx_PyUnicode_Concat(__pyx_mstate_global->__pyx_kp_u_USER_AGENT, __pyx_t_11); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_12);
                  __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
                  __pyx_t_6 = 1;
                  #if CYTHON_UNPACK_METHODS
                  if (unlikely(PyMethod_Check(__pyx_t_4))) {
                    __pyx_t_1 = PyMethod_GET_SELF(__pyx_t_4);
                    assert(__pyx_t_1);
                    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_4);
                    __Pyx_INCREF(__pyx_t_1);
                    __Pyx_INCREF(__pyx__function);
                    __Pyx_DECREF_SET(__pyx_t_4, __pyx__function);
                    __pyx_t_6 = 0;
                  }
                  #endif
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_1, __pyx_t_12};
                    __pyx_t_14 = __Pyx_PyObject_FastCall(__pyx_t_4, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
                    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
                    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                    if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 172, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_14);
                  }
                  __pyx_t_4 = __Pyx_PyObject_FormatSimple(__pyx_t_14, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_4);
                  __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
                  __Pyx_GetModuleGlobalName(__pyx_t_14, __pyx_mstate_global->__pyx_n_u_p2); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_14);
                  __pyx_t_12 = __Pyx_PyObject_FormatSimple(__pyx_t_14, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_12);
                  __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
                  __pyx_t_14 = __Pyx_PyUnicode_ConcatInPlace(__pyx_t_12, __pyx_v_fallback); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 172, __pyx_L18_error)
                  __Pyx_GOTREF(__pyx_t_14);
                  __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
                  __pyx_t_6 = 1;
                  #if CYTHON_UNPACK_METHODS
                  if (unlikely(PyMethod_Check(__pyx_t_13))) {
                    __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_13);
                    assert(__pyx_t_3);
                    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_13);
                    __Pyx_INCREF(__pyx_t_3);
                    __Pyx_INCREF(__pyx__function);
                    __Pyx_DECREF_SET(__pyx_t_13, __pyx__function);
                    __pyx_t_6 = 0;
                  }
                  #endif
                  {
                    PyObject *__pyx_callargs[5 + ((CYTHON_VECTORCALL) ? 1 : 0)] = {__pyx_t_3, __pyx_t_4, __pyx_t_14, Py_None, Py_None};
                    __pyx_t_12 = __Pyx_MakeVectorcallBuilderKwds(1); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 172, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_12);
                    if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_werno, __pyx_mstate_global->__pyx_n_u_hijau, __pyx_t_12, __pyx_callargs+5, 0) < 0) __PYX_ERR(0, 172, __pyx_L18_error)
                    __pyx_t_5 = __Pyx_Object_Vectorcall_CallFromBuilder(__pyx_t_13, __pyx_callargs+__pyx_t_6, (5-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_12);
                    __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
                    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
                    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
                    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
                    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                    if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 172, __pyx_L18_error)
                    __Pyx_GOTREF(__pyx_t_5);
                  }
                  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

                  
                  __pyx_t_9 = __Pyx_PyList_Append(__pyx_v_user_agents_list, __pyx_v_fallback); if (unlikely(__pyx_t_9 == ((int)-1))) __PYX_ERR(0, 173, __pyx_L18_error)
                }
                __pyx_L43:;

                
                __pyx_L24_continue:;
              }
              __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;

              
            }
            __Pyx_XDECREF(__pyx_t_21); __pyx_t_21 = 0;
            __Pyx_XDECREF(__pyx_t_22); __pyx_t_22 = 0;
            __Pyx_XDECREF(__pyx_t_23); __pyx_t_23 = 0;
            goto __pyx_L23_try_end;
            __pyx_L18_error:;
            __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
            __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
            __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
            __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
            __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
            __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
            __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
            __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
            __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
             {
              __Pyx_AddTraceback("user_agent.create", __pyx_clineno, __pyx_lineno, __pyx_filename);
              if (__Pyx_GetException(&__pyx_t_10, &__pyx_t_5, &__pyx_t_13) < 0) __PYX_ERR(0, 123, __pyx_L20_except_error)
              __Pyx_XGOTREF(__pyx_t_10);
              __Pyx_XGOTREF(__pyx_t_5);
              __Pyx_XGOTREF(__pyx_t_13);
              __pyx_t_12 = PyTuple_Pack(3, __pyx_t_10, __pyx_t_5, __pyx_t_13); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 123, __pyx_L20_except_error)
              __Pyx_GOTREF(__pyx_t_12);
              __pyx_t_27 = __Pyx_PyObject_Call(__pyx_t_20, __pyx_t_12, NULL);
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
              __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
              if (unlikely(!__pyx_t_27)) __PYX_ERR(0, 123, __pyx_L20_except_error)
              __Pyx_GOTREF(__pyx_t_27);
              __pyx_t_26 = __Pyx_PyObject_IsTrue(__pyx_t_27);
              __Pyx_DECREF(__pyx_t_27); __pyx_t_27 = 0;
              if (__pyx_t_26 < 0) __PYX_ERR(0, 123, __pyx_L20_except_error)
              __pyx_t_2 = (!__pyx_t_26);
              if (unlikely(__pyx_t_2)) {
                __Pyx_GIVEREF(__pyx_t_10);
                __Pyx_GIVEREF(__pyx_t_5);
                __Pyx_XGIVEREF(__pyx_t_13);
                __Pyx_ErrRestoreWithState(__pyx_t_10, __pyx_t_5, __pyx_t_13);
                __pyx_t_10 = 0;  __pyx_t_5 = 0;  __pyx_t_13 = 0; 
                __PYX_ERR(0, 123, __pyx_L20_except_error)
              }
              __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
              __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
              __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
              goto __pyx_L19_exception_handled;
            }
            __pyx_L20_except_error:;
            __Pyx_XGIVEREF(__pyx_t_21);
            __Pyx_XGIVEREF(__pyx_t_22);
            __Pyx_XGIVEREF(__pyx_t_23);
            __Pyx_ExceptionReset(__pyx_t_21, __pyx_t_22, __pyx_t_23);
            goto __pyx_L8_error;
            __pyx_L19_exception_handled:;
            __Pyx_XGIVEREF(__pyx_t_21);
            __Pyx_XGIVEREF(__pyx_t_22);
            __Pyx_XGIVEREF(__pyx_t_23);
            __Pyx_ExceptionReset(__pyx_t_21, __pyx_t_22, __pyx_t_23);
            __pyx_L23_try_end:;
          }
        }
         {
          {
            if (__pyx_t_20) {
              __pyx_t_23 = __Pyx_PyObject_Call(__pyx_t_20, __pyx_mstate_global->__pyx_tuple[1], NULL);
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
              if (unlikely(!__pyx_t_23)) __PYX_ERR(0, 123, __pyx_L8_error)
              __Pyx_GOTREF(__pyx_t_23);
              __Pyx_DECREF(__pyx_t_23); __pyx_t_23 = 0;
            }
            goto __pyx_L17;
          }
          __pyx_L17:;
        }
        goto __pyx_L48;
        __pyx_L14_error:;
        __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
        goto __pyx_L8_error;
        __pyx_L48:;
      }

      
       {
        __pyx_t_13 = __Pyx_PyDict_NewPresized(1); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 175, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_13);
        if (PyDict_SetItem(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_encoding, __pyx_mstate_global->__pyx_kp_u_utf_8) < 0) __PYX_ERR(0, 175, __pyx_L8_error)
        __pyx_t_5 = __Pyx_PyObject_Call(__pyx_builtin_open, __pyx_mstate_global->__pyx_tuple[3], __pyx_t_13); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 175, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_5);
        __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
        __pyx_t_20 = __Pyx_PyObject_LookupSpecial(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_exit); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 175, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_20);
        __pyx_t_10 = NULL;
        __pyx_t_12 = __Pyx_PyObject_LookupSpecial(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_enter); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 175, __pyx_L49_error)
        __Pyx_GOTREF(__pyx_t_12);
        __pyx_t_6 = 1;
        #if CYTHON_UNPACK_METHODS
        if (likely(PyMethod_Check(__pyx_t_12))) {
          __pyx_t_10 = PyMethod_GET_SELF(__pyx_t_12);
          assert(__pyx_t_10);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_12);
          __Pyx_INCREF(__pyx_t_10);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_12, __pyx__function);
          __pyx_t_6 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_10, NULL};
          __pyx_t_13 = __Pyx_PyObject_FastCall(__pyx_t_12, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
          __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
          if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 175, __pyx_L49_error)
          __Pyx_GOTREF(__pyx_t_13);
        }
        __pyx_t_12 = __pyx_t_13;
        __pyx_t_13 = 0;
        __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
         {
          {
            __Pyx_PyThreadState_declare
            __Pyx_PyThreadState_assign
            __Pyx_ExceptionSave(&__pyx_t_23, &__pyx_t_22, &__pyx_t_21);
            __Pyx_XGOTREF(__pyx_t_23);
            __Pyx_XGOTREF(__pyx_t_22);
            __Pyx_XGOTREF(__pyx_t_21);
             {
              __pyx_v_f = __pyx_t_12;
              __pyx_t_12 = 0;

              
              __pyx_t_5 = __pyx_v_f;
              __Pyx_INCREF(__pyx_t_5);
              __pyx_t_13 = PyUnicode_Join(__pyx_mstate_global->__pyx_kp_u__8, __pyx_v_user_agents_list); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 176, __pyx_L53_error)
              __Pyx_GOTREF(__pyx_t_13);
              __pyx_t_6 = 0;
              {
                PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_13};
                __pyx_t_12 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_write, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
                __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
                if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 176, __pyx_L53_error)
                __Pyx_GOTREF(__pyx_t_12);
              }
              __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;

              
            }
            __Pyx_XDECREF(__pyx_t_23); __pyx_t_23 = 0;
            __Pyx_XDECREF(__pyx_t_22); __pyx_t_22 = 0;
            __Pyx_XDECREF(__pyx_t_21); __pyx_t_21 = 0;
            goto __pyx_L58_try_end;
            __pyx_L53_error:;
            __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
            __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
            __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
            __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
            __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
            __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
            __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
            __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
            __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
             {
              __Pyx_AddTraceback("user_agent.create", __pyx_clineno, __pyx_lineno, __pyx_filename);
              if (__Pyx_GetException(&__pyx_t_12, &__pyx_t_13, &__pyx_t_5) < 0) __PYX_ERR(0, 175, __pyx_L55_except_error)
              __Pyx_XGOTREF(__pyx_t_12);
              __Pyx_XGOTREF(__pyx_t_13);
              __Pyx_XGOTREF(__pyx_t_5);
              __pyx_t_10 = PyTuple_Pack(3, __pyx_t_12, __pyx_t_13, __pyx_t_5); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 175, __pyx_L55_except_error)
              __Pyx_GOTREF(__pyx_t_10);
              __pyx_t_27 = __Pyx_PyObject_Call(__pyx_t_20, __pyx_t_10, NULL);
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
              __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
              if (unlikely(!__pyx_t_27)) __PYX_ERR(0, 175, __pyx_L55_except_error)
              __Pyx_GOTREF(__pyx_t_27);
              __pyx_t_2 = __Pyx_PyObject_IsTrue(__pyx_t_27);
              __Pyx_DECREF(__pyx_t_27); __pyx_t_27 = 0;
              if (__pyx_t_2 < 0) __PYX_ERR(0, 175, __pyx_L55_except_error)
              __pyx_t_26 = (!__pyx_t_2);
              if (unlikely(__pyx_t_26)) {
                __Pyx_GIVEREF(__pyx_t_12);
                __Pyx_GIVEREF(__pyx_t_13);
                __Pyx_XGIVEREF(__pyx_t_5);
                __Pyx_ErrRestoreWithState(__pyx_t_12, __pyx_t_13, __pyx_t_5);
                __pyx_t_12 = 0;  __pyx_t_13 = 0;  __pyx_t_5 = 0; 
                __PYX_ERR(0, 175, __pyx_L55_except_error)
              }
              __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
              __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
              __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
              goto __pyx_L54_exception_handled;
            }
            __pyx_L55_except_error:;
            __Pyx_XGIVEREF(__pyx_t_23);
            __Pyx_XGIVEREF(__pyx_t_22);
            __Pyx_XGIVEREF(__pyx_t_21);
            __Pyx_ExceptionReset(__pyx_t_23, __pyx_t_22, __pyx_t_21);
            goto __pyx_L8_error;
            __pyx_L54_exception_handled:;
            __Pyx_XGIVEREF(__pyx_t_23);
            __Pyx_XGIVEREF(__pyx_t_22);
            __Pyx_XGIVEREF(__pyx_t_21);
            __Pyx_ExceptionReset(__pyx_t_23, __pyx_t_22, __pyx_t_21);
            __pyx_L58_try_end:;
          }
        }
         {
          {
            if (__pyx_t_20) {
              __pyx_t_21 = __Pyx_PyObject_Call(__pyx_t_20, __pyx_mstate_global->__pyx_tuple[1], NULL);
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
              if (unlikely(!__pyx_t_21)) __PYX_ERR(0, 175, __pyx_L8_error)
              __Pyx_GOTREF(__pyx_t_21);
              __Pyx_DECREF(__pyx_t_21); __pyx_t_21 = 0;
            }
            goto __pyx_L52;
          }
          __pyx_L52:;
        }
        goto __pyx_L62;
        __pyx_L49_error:;
        __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
        goto __pyx_L8_error;
        __pyx_L62:;
      }

      
    }
    __Pyx_XDECREF(__pyx_t_17); __pyx_t_17 = 0;
    __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
    __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
    goto __pyx_L13_try_end;
    __pyx_L8_error:;
    __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
    __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
    __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
    __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
    __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
    __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
    __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;

    
    __Pyx_ErrFetch(&__pyx_t_5, &__pyx_t_13, &__pyx_t_12);
    __Pyx_GetModuleGlobalName(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_requests); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 178, __pyx_L10_except_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_14 = __Pyx_PyObject_GetAttrStr(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_RequestException); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 178, __pyx_L10_except_error)
    __Pyx_GOTREF(__pyx_t_14);
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __pyx_t_28 = __Pyx_PyErr_GivenExceptionMatches(__pyx_t_5, __pyx_t_14);
    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
    __Pyx_ErrRestore(__pyx_t_5, __pyx_t_13, __pyx_t_12);
    __pyx_t_5 = 0; __pyx_t_13 = 0; __pyx_t_12 = 0;
    if (__pyx_t_28) {
      __Pyx_AddTraceback("user_agent.create", __pyx_clineno, __pyx_lineno, __pyx_filename);
      if (__Pyx_GetException(&__pyx_t_12, &__pyx_t_13, &__pyx_t_5) < 0) __PYX_ERR(0, 178, __pyx_L10_except_error)
      __Pyx_XGOTREF(__pyx_t_12);
      __Pyx_XGOTREF(__pyx_t_13);
      __Pyx_XGOTREF(__pyx_t_5);
      __Pyx_INCREF(__pyx_t_13);
      __pyx_v_e = __pyx_t_13;
       {

        
        __pyx_t_10 = NULL;
        __Pyx_INCREF(__pyx_builtin_print);
        __pyx_t_4 = __pyx_builtin_print; 
        __pyx_t_6 = 1;
        {
          PyObject *__pyx_callargs[3] = {__pyx_t_10, __pyx_mstate_global->__pyx_kp_u_Gagal_memuat_halaman, __pyx_v_e};
          __pyx_t_14 = __Pyx_PyObject_FastCall(__pyx_t_4, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
          __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
          if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 179, __pyx_L68_error)
          __Pyx_GOTREF(__pyx_t_14);
        }
        __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
      }

      
       {
        {
          __Pyx_DECREF(__pyx_v_e); __pyx_v_e = 0;
          goto __pyx_L69;
        }
        __pyx_L68_error:;
        {
          __Pyx_PyThreadState_declare
          __Pyx_PyThreadState_assign
          __pyx_t_20 = 0; __pyx_t_21 = 0; __pyx_t_22 = 0; __pyx_t_23 = 0; __pyx_t_27 = 0; __pyx_t_31 = 0;
          __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
          __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
          __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
          __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
          __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
          __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
           __Pyx_ExceptionSwap(&__pyx_t_23, &__pyx_t_27, &__pyx_t_31);
          if ( unlikely(__Pyx_GetException(&__pyx_t_20, &__pyx_t_21, &__pyx_t_22) < 0)) __Pyx_ErrFetch(&__pyx_t_20, &__pyx_t_21, &__pyx_t_22);
          __Pyx_XGOTREF(__pyx_t_20);
          __Pyx_XGOTREF(__pyx_t_21);
          __Pyx_XGOTREF(__pyx_t_22);
          __Pyx_XGOTREF(__pyx_t_23);
          __Pyx_XGOTREF(__pyx_t_27);
          __Pyx_XGOTREF(__pyx_t_31);
          __pyx_t_28 = __pyx_lineno; __pyx_t_29 = __pyx_clineno; __pyx_t_30 = __pyx_filename;
          {
            __Pyx_DECREF(__pyx_v_e); __pyx_v_e = 0;
          }
          __Pyx_XGIVEREF(__pyx_t_23);
          __Pyx_XGIVEREF(__pyx_t_27);
          __Pyx_XGIVEREF(__pyx_t_31);
          __Pyx_ExceptionReset(__pyx_t_23, __pyx_t_27, __pyx_t_31);
          __Pyx_XGIVEREF(__pyx_t_20);
          __Pyx_XGIVEREF(__pyx_t_21);
          __Pyx_XGIVEREF(__pyx_t_22);
          __Pyx_ErrRestore(__pyx_t_20, __pyx_t_21, __pyx_t_22);
          __pyx_t_20 = 0; __pyx_t_21 = 0; __pyx_t_22 = 0; __pyx_t_23 = 0; __pyx_t_27 = 0; __pyx_t_31 = 0;
          __pyx_lineno = __pyx_t_28; __pyx_clineno = __pyx_t_29; __pyx_filename = __pyx_t_30;
          goto __pyx_L10_except_error;
        }
        __pyx_L69:;
      }
      __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      goto __pyx_L9_exception_handled;
    }
    goto __pyx_L10_except_error;

    
    __pyx_L10_except_error:;
    __Pyx_XGIVEREF(__pyx_t_17);
    __Pyx_XGIVEREF(__pyx_t_18);
    __Pyx_XGIVEREF(__pyx_t_19);
    __Pyx_ExceptionReset(__pyx_t_17, __pyx_t_18, __pyx_t_19);
    goto __pyx_L1_error;
    __pyx_L9_exception_handled:;
    __Pyx_XGIVEREF(__pyx_t_17);
    __Pyx_XGIVEREF(__pyx_t_18);
    __Pyx_XGIVEREF(__pyx_t_19);
    __Pyx_ExceptionReset(__pyx_t_17, __pyx_t_18, __pyx_t_19);
    __pyx_L13_try_end:;
  }

  

  
  __pyx_r = Py_None; __Pyx_INCREF(Py_None);
  goto __pyx_L0;
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_XDECREF(__pyx_t_4);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_10);
  __Pyx_XDECREF(__pyx_t_11);
  __Pyx_XDECREF(__pyx_t_12);
  __Pyx_XDECREF(__pyx_t_13);
  __Pyx_XDECREF(__pyx_t_14);
  __Pyx_AddTraceback("user_agent.create", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_BASE_URL);
  __Pyx_XDECREF(__pyx_v_BRAND_MAP);
  __Pyx_XDECREF(__pyx_v_selected_brands);
  __Pyx_XDECREF(__pyx_v_parts);
  __Pyx_XDECREF(__pyx_v_br);
  __Pyx_XDECREF(__pyx_v_brand_text);
  __Pyx_XDECREF(__pyx_v_user_agents_list);
  __Pyx_XDECREF(__pyx_v_piro);
  __Pyx_XDECREF(__pyx_v_hitung);
  __Pyx_XDECREF(__pyx_v_session);
  __Pyx_XDECREF(__pyx_v__);
  __Pyx_XDECREF(__pyx_v_brand_key);
  __Pyx_XDECREF(__pyx_v_brand_path);
  __Pyx_XDECREF(__pyx_v_brand_url);
  __Pyx_XDECREF(__pyx_v_res_brand);
  __Pyx_XDECREF(__pyx_v_soup);
  __Pyx_XDECREF(__pyx_v_device_links);
  __Pyx_XDECREF(__pyx_v_device_url);
  __Pyx_XDECREF(__pyx_v_res_dev);
  __Pyx_XDECREF(__pyx_v_soup_dev);
  __Pyx_XDECREF(__pyx_v_uas);
  __Pyx_XDECREF(__pyx_v_ua);
  __Pyx_XDECREF(__pyx_v_fallback);
  __Pyx_XDECREF(__pyx_v_f);
  __Pyx_XDECREF(__pyx_v_e);
  __Pyx_XDECREF(__pyx_8genexpr1__pyx_v_link);
  __Pyx_XDECREF(__pyx_8genexpr2__pyx_v_td);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_11_extract_model_from_parentheses(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_11_extract_model_from_parentheses = {"_extract_model_from_parentheses", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_11_extract_model_from_parentheses, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_11_extract_model_from_parentheses(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_text_inside = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[1] = {0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("_extract_model_from_parentheses (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_text_inside,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 182, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 182, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "_extract_model_from_parentheses", 0) < 0) __PYX_ERR(0, 182, __pyx_L3_error)
      for (Py_ssize_t i = __pyx_nargs; i < 1; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("_extract_model_from_parentheses", 1, 1, 1, i); __PYX_ERR(0, 182, __pyx_L3_error) }
      }
    } else if (unlikely(__pyx_nargs != 1)) {
      goto __pyx_L5_argtuple_error;
    } else {
      values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 182, __pyx_L3_error)
    }
    __pyx_v_text_inside = values[0];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("_extract_model_from_parentheses", 1, 1, 1, __pyx_nargs); __PYX_ERR(0, 182, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent._extract_model_from_parentheses", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_10_extract_model_from_parentheses(__pyx_self, __pyx_v_text_inside);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_10_extract_model_from_parentheses(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_text_inside) {
  PyObject *__pyx_v_parts = NULL;
  PyObject *__pyx_v_part = NULL;
  PyObject *__pyx_v_p = NULL;
  PyObject *__pyx_8genexpr3__pyx_v_p = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  size_t __pyx_t_4;
  Py_ssize_t __pyx_t_5;
  PyObject *(*__pyx_t_6)(PyObject *);
  PyObject *__pyx_t_7 = NULL;
  int __pyx_t_8;
  PyObject *__pyx_t_9 = NULL;
  PyObject *__pyx_t_10 = NULL;
  PyObject *__pyx_t_11 = NULL;
  PyObject *__pyx_t_12 = NULL;
  int __pyx_t_13;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("_extract_model_from_parentheses", 0);

  
  { 
    __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 183, __pyx_L5_error)
    __Pyx_GOTREF(__pyx_t_1);
    __pyx_t_3 = __pyx_v_text_inside;
    __Pyx_INCREF(__pyx_t_3);
    __pyx_t_4 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_mstate_global->__pyx_kp_u__9};
      __pyx_t_2 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_split, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
      if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 183, __pyx_L5_error)
      __Pyx_GOTREF(__pyx_t_2);
    }
    if (likely(PyList_CheckExact(__pyx_t_2)) || PyTuple_CheckExact(__pyx_t_2)) {
      __pyx_t_3 = __pyx_t_2; __Pyx_INCREF(__pyx_t_3);
      __pyx_t_5 = 0;
      __pyx_t_6 = NULL;
    } else {
      __pyx_t_5 = -1; __pyx_t_3 = PyObject_GetIter(__pyx_t_2); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 183, __pyx_L5_error)
      __Pyx_GOTREF(__pyx_t_3);
      __pyx_t_6 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_3); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 183, __pyx_L5_error)
    }
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    for (;;) {
      if (likely(!__pyx_t_6)) {
        if (likely(PyList_CheckExact(__pyx_t_3))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_3);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 183, __pyx_L5_error)
            #endif
            if (__pyx_t_5 >= __pyx_temp) break;
          }
          __pyx_t_2 = __Pyx_PyList_GetItemRef(__pyx_t_3, __pyx_t_5);
          ++__pyx_t_5;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_3);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 183, __pyx_L5_error)
            #endif
            if (__pyx_t_5 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_2 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_3, __pyx_t_5));
          #else
          __pyx_t_2 = __Pyx_PySequence_ITEM(__pyx_t_3, __pyx_t_5);
          #endif
          ++__pyx_t_5;
        }
        if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 183, __pyx_L5_error)
      } else {
        __pyx_t_2 = __pyx_t_6(__pyx_t_3);
        if (unlikely(!__pyx_t_2)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 183, __pyx_L5_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_2);
      __Pyx_XDECREF_SET(__pyx_8genexpr3__pyx_v_p, __pyx_t_2);
      __pyx_t_2 = 0;
      __pyx_t_7 = __pyx_8genexpr3__pyx_v_p;
      __Pyx_INCREF(__pyx_t_7);
      __pyx_t_4 = 0;
      {
        PyObject *__pyx_callargs[2] = {__pyx_t_7, NULL};
        __pyx_t_2 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_4, (1-__pyx_t_4) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
        if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 183, __pyx_L5_error)
        __Pyx_GOTREF(__pyx_t_2);
      }
      __pyx_t_8 = __Pyx_PyObject_IsTrue(__pyx_t_2); if (unlikely((__pyx_t_8 < 0))) __PYX_ERR(0, 183, __pyx_L5_error)
      __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
      if (__pyx_t_8) {
        __pyx_t_7 = __pyx_8genexpr3__pyx_v_p;
        __Pyx_INCREF(__pyx_t_7);
        __pyx_t_4 = 0;
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_7, NULL};
          __pyx_t_2 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_4, (1-__pyx_t_4) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
          if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 183, __pyx_L5_error)
          __Pyx_GOTREF(__pyx_t_2);
        }
        if (unlikely(__Pyx_ListComp_Append(__pyx_t_1, (PyObject*)__pyx_t_2))) __PYX_ERR(0, 183, __pyx_L5_error)
        __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
      }
    }
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_XDECREF(__pyx_8genexpr3__pyx_v_p); __pyx_8genexpr3__pyx_v_p = 0;
    goto __pyx_L10_exit_scope;
    __pyx_L5_error:;
    __Pyx_XDECREF(__pyx_8genexpr3__pyx_v_p); __pyx_8genexpr3__pyx_v_p = 0;
    goto __pyx_L1_error;
    __pyx_L10_exit_scope:;
  } 
  __pyx_v_parts = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __pyx_v_parts; __Pyx_INCREF(__pyx_t_1);
  __pyx_t_5 = __Pyx_PyList_GET_SIZE(__pyx_t_1);
  #if !CYTHON_ASSUME_SAFE_SIZE
  if (unlikely((__pyx_t_5 < 0))) __PYX_ERR(0, 184, __pyx_L1_error)
  #endif
  --__pyx_t_5;
  for (;;) {
    if (__pyx_t_5 < 0) break;
    {
      Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_1);
      #if !CYTHON_ASSUME_SAFE_SIZE
      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 184, __pyx_L1_error)
      #endif
      if (__pyx_t_5 >= __pyx_temp) break;
    }
    __pyx_t_3 = __Pyx_PyList_GetItemRef(__pyx_t_1, __pyx_t_5);
    --__pyx_t_5;
    if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 184, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);
    __Pyx_XDECREF_SET(__pyx_v_part, __pyx_t_3);
    __pyx_t_3 = 0;

    
    __Pyx_INCREF(__pyx_v_part);
    __Pyx_XDECREF_SET(__pyx_v_p, __pyx_v_part);

    
    __pyx_t_9 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 186, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_11 = __Pyx_PyObject_GetAttrStr(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_split); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 186, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 186, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_I); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 186, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __pyx_t_4 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_11))) {
      __pyx_t_9 = PyMethod_GET_SELF(__pyx_t_11);
      assert(__pyx_t_9);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_11);
      __Pyx_INCREF(__pyx_t_9);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_11, __pyx__function);
      __pyx_t_4 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[3 + ((CYTHON_VECTORCALL) ? 1 : 0)] = {__pyx_t_9, __pyx_mstate_global->__pyx_kp_u_s_Build_b, __pyx_v_p};
      __pyx_t_10 = __Pyx_MakeVectorcallBuilderKwds(1); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 186, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_10);
      if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_flags, __pyx_t_12, __pyx_t_10, __pyx_callargs+3, 0) < 0) __PYX_ERR(0, 186, __pyx_L1_error)
      __pyx_t_7 = __Pyx_Object_Vectorcall_CallFromBuilder(__pyx_t_11, __pyx_callargs+__pyx_t_4, (3-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_10);
      __Pyx_XDECREF(__pyx_t_9); __pyx_t_9 = 0;
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
      __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
      if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 186, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_7);
    }
    __pyx_t_11 = __Pyx_GetItemInt(__pyx_t_7, 0, long, 1, __Pyx_PyLong_From_long, 0, 0, 1, 1); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 186, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    __pyx_t_2 = __pyx_t_11;
    __Pyx_INCREF(__pyx_t_2);
    __pyx_t_4 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_2, NULL};
      __pyx_t_3 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_4, (1-__pyx_t_4) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
      __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 186, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    __Pyx_DECREF_SET(__pyx_v_p, __pyx_t_3);
    __pyx_t_3 = 0;

    
    __pyx_t_8 = __Pyx_PyObject_IsTrue(__pyx_v_p); if (unlikely((__pyx_t_8 < 0))) __PYX_ERR(0, 187, __pyx_L1_error)
    __pyx_t_13 = (!__pyx_t_8);
    if (__pyx_t_13) {

      
      goto __pyx_L11_continue;

      
    }

    
    __pyx_t_11 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 189, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_7 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_fullmatch); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 189, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 189, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_10 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_I); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 189, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_4 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_7))) {
      __pyx_t_11 = PyMethod_GET_SELF(__pyx_t_7);
      assert(__pyx_t_11);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_7);
      __Pyx_INCREF(__pyx_t_11);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_7, __pyx__function);
      __pyx_t_4 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[4] = {__pyx_t_11, __pyx_mstate_global->__pyx_kp_u_u_wv, __pyx_v_p, __pyx_t_10};
      __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_7, __pyx_callargs+__pyx_t_4, (4-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
      __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
      __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 189, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    __pyx_t_13 = __Pyx_PyObject_IsTrue(__pyx_t_3); if (unlikely((__pyx_t_13 < 0))) __PYX_ERR(0, 189, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (__pyx_t_13) {

      
      goto __pyx_L11_continue;

      
    }

    
    __pyx_t_7 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 191, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_11 = __Pyx_PyObject_GetAttrStr(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_fullmatch); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 191, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __pyx_t_4 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_11))) {
      __pyx_t_7 = PyMethod_GET_SELF(__pyx_t_11);
      assert(__pyx_t_7);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_11);
      __Pyx_INCREF(__pyx_t_7);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_11, __pyx__function);
      __pyx_t_4 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[3] = {__pyx_t_7, __pyx_mstate_global->__pyx_kp_u_d_d, __pyx_v_p};
      __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_11, __pyx_callargs+__pyx_t_4, (3-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
      __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 191, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    __pyx_t_13 = __Pyx_PyObject_IsTrue(__pyx_t_3); if (unlikely((__pyx_t_13 < 0))) __PYX_ERR(0, 191, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (__pyx_t_13) {

      
      goto __pyx_L11_continue;

      
    }

    
    __pyx_t_11 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 193, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
    __pyx_t_10 = __Pyx_PyObject_GetAttrStr(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_fullmatch); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 193, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 193, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
    __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_I); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 193, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    __pyx_t_4 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_10))) {
      __pyx_t_11 = PyMethod_GET_SELF(__pyx_t_10);
      assert(__pyx_t_11);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_10);
      __Pyx_INCREF(__pyx_t_11);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_10, __pyx__function);
      __pyx_t_4 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[4] = {__pyx_t_11, __pyx_mstate_global->__pyx_kp_u_a_z_2_a_z_2, __pyx_v_p, __pyx_t_2};
      __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_10, __pyx_callargs+__pyx_t_4, (4-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
      __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
      __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 193, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    __pyx_t_13 = __Pyx_PyObject_IsTrue(__pyx_t_3); if (unlikely((__pyx_t_13 < 0))) __PYX_ERR(0, 193, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (__pyx_t_13) {

      
      goto __pyx_L11_continue;

      
    }

    
    __pyx_t_10 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 195, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_11 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_search); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 195, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 195, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_7 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_I); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 195, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_4 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_11))) {
      __pyx_t_10 = PyMethod_GET_SELF(__pyx_t_11);
      assert(__pyx_t_10);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_11);
      __Pyx_INCREF(__pyx_t_10);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_11, __pyx__function);
      __pyx_t_4 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[4] = {__pyx_t_10, __pyx_mstate_global->__pyx_n_u_android, __pyx_v_p, __pyx_t_7};
      __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_11, __pyx_callargs+__pyx_t_4, (4-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
      __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
      __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 195, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    __pyx_t_13 = __Pyx_PyObject_IsTrue(__pyx_t_3); if (unlikely((__pyx_t_13 < 0))) __PYX_ERR(0, 195, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (__pyx_t_13) {

      
      goto __pyx_L11_continue;

      
    }

    
    __pyx_t_11 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 197, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
    __pyx_t_10 = __Pyx_PyObject_GetAttrStr(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_search); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 197, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 197, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
    __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_I); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 197, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    __pyx_t_4 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_10))) {
      __pyx_t_11 = PyMethod_GET_SELF(__pyx_t_10);
      assert(__pyx_t_11);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_10);
      __Pyx_INCREF(__pyx_t_11);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_10, __pyx__function);
      __pyx_t_4 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[4] = {__pyx_t_11, __pyx_mstate_global->__pyx_kp_u_applewebkit_khtml_like_gecko, __pyx_v_p, __pyx_t_2};
      __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_10, __pyx_callargs+__pyx_t_4, (4-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
      __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
      __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 197, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    __pyx_t_13 = __Pyx_PyObject_IsTrue(__pyx_t_3); if (unlikely((__pyx_t_13 < 0))) __PYX_ERR(0, 197, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (__pyx_t_13) {

      
      goto __pyx_L11_continue;

      
    }

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_v_p);
    __pyx_r = __pyx_v_p;
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    goto __pyx_L0;

    
    __pyx_L11_continue:;
  }
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

  
  __Pyx_XDECREF(__pyx_r);
  __pyx_r = Py_None; __Pyx_INCREF(Py_None);
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_XDECREF(__pyx_t_7);
  __Pyx_XDECREF(__pyx_t_9);
  __Pyx_XDECREF(__pyx_t_10);
  __Pyx_XDECREF(__pyx_t_11);
  __Pyx_XDECREF(__pyx_t_12);
  __Pyx_AddTraceback("user_agent._extract_model_from_parentheses", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_parts);
  __Pyx_XDECREF(__pyx_v_part);
  __Pyx_XDECREF(__pyx_v_p);
  __Pyx_XDECREF(__pyx_8genexpr3__pyx_v_p);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_13load_models_from_user_file(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_13load_models_from_user_file = {"load_models_from_user_file", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_13load_models_from_user_file, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_13load_models_from_user_file(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_path = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[1] = {0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("load_models_from_user_file (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_path,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 202, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 202, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "load_models_from_user_file", 0) < 0) __PYX_ERR(0, 202, __pyx_L3_error)
      if (!values[0]) values[0] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_kp_u_user_txt)));
    } else {
      switch (__pyx_nargs) {
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 202, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      if (!values[0]) values[0] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_kp_u_user_txt)));
    }
    __pyx_v_path = values[0];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("load_models_from_user_file", 0, 0, 1, __pyx_nargs); __PYX_ERR(0, 202, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent.load_models_from_user_file", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_12load_models_from_user_file(__pyx_self, __pyx_v_path);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_12load_models_from_user_file(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_path) {
  PyObject *__pyx_v_models = NULL;
  PyObject *__pyx_v_f = NULL;
  PyObject *__pyx_v_line = NULL;
  PyObject *__pyx_v_m_paren = NULL;
  PyObject *__pyx_v_inside = NULL;
  PyObject *__pyx_v_model = NULL;
  PyObject *__pyx_v_build_match = NULL;
  PyObject *__pyx_v_build = NULL;
  int __pyx_v_has_wv;
  PyObject *__pyx_v_uniq = NULL;
  PyObject *__pyx_v_item = NULL;
  PyObject *__pyx_v_key = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  PyObject *__pyx_t_6 = NULL;
  size_t __pyx_t_7;
  PyObject *__pyx_t_8 = NULL;
  PyObject *__pyx_t_9 = NULL;
  PyObject *__pyx_t_10 = NULL;
  PyObject *__pyx_t_11 = NULL;
  PyObject *__pyx_t_12 = NULL;
  Py_ssize_t __pyx_t_13;
  PyObject *(*__pyx_t_14)(PyObject *);
  PyObject *__pyx_t_15 = NULL;
  int __pyx_t_16;
  int __pyx_t_17;
  PyObject *__pyx_t_18 = NULL;
  PyObject *__pyx_t_19 = NULL;
  PyObject *__pyx_t_20 = NULL;
  PyObject *__pyx_t_21 = NULL;
  int __pyx_t_22;
  PyObject *__pyx_t_23 = NULL;
  int __pyx_t_24;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("load_models_from_user_file", 0);

  
  __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 203, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_models = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  {
    __Pyx_PyThreadState_declare
    __Pyx_PyThreadState_assign
    __Pyx_ExceptionSave(&__pyx_t_2, &__pyx_t_3, &__pyx_t_4);
    __Pyx_XGOTREF(__pyx_t_2);
    __Pyx_XGOTREF(__pyx_t_3);
    __Pyx_XGOTREF(__pyx_t_4);
     {

      
       {
        __pyx_t_5 = NULL;
        __Pyx_INCREF(__pyx_builtin_open);
        __pyx_t_6 = __pyx_builtin_open; 
        __pyx_t_7 = 1;
        {
          PyObject *__pyx_callargs[3 + ((CYTHON_VECTORCALL) ? 2 : 0)] = {__pyx_t_5, __pyx_v_path, __pyx_mstate_global->__pyx_n_u_r};
          __pyx_t_8 = __Pyx_MakeVectorcallBuilderKwds(2); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 205, __pyx_L3_error)
          __Pyx_GOTREF(__pyx_t_8);
          if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_encoding, __pyx_mstate_global->__pyx_kp_u_utf_8, __pyx_t_8, __pyx_callargs+3, 0) < 0) __PYX_ERR(0, 205, __pyx_L3_error)
          if (__Pyx_VectorcallBuilder_AddArg(__pyx_mstate_global->__pyx_n_u_errors, __pyx_mstate_global->__pyx_n_u_ignore, __pyx_t_8, __pyx_callargs+3, 1) < 0) __PYX_ERR(0, 205, __pyx_L3_error)
          __pyx_t_1 = __Pyx_Object_Vectorcall_CallFromBuilder(__pyx_t_6, __pyx_callargs+__pyx_t_7, (3-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_8);
          __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
          __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
          __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
          if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 205, __pyx_L3_error)
          __Pyx_GOTREF(__pyx_t_1);
        }
        __pyx_t_9 = __Pyx_PyObject_LookupSpecial(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_exit); if (unlikely(!__pyx_t_9)) __PYX_ERR(0, 205, __pyx_L3_error)
        __Pyx_GOTREF(__pyx_t_9);
        __pyx_t_8 = NULL;
        __pyx_t_5 = __Pyx_PyObject_LookupSpecial(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_enter); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 205, __pyx_L9_error)
        __Pyx_GOTREF(__pyx_t_5);
        __pyx_t_7 = 1;
        #if CYTHON_UNPACK_METHODS
        if (likely(PyMethod_Check(__pyx_t_5))) {
          __pyx_t_8 = PyMethod_GET_SELF(__pyx_t_5);
          assert(__pyx_t_8);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
          __Pyx_INCREF(__pyx_t_8);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
          __pyx_t_7 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_8, NULL};
          __pyx_t_6 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_7, (1-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
          __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
          if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 205, __pyx_L9_error)
          __Pyx_GOTREF(__pyx_t_6);
        }
        __pyx_t_5 = __pyx_t_6;
        __pyx_t_6 = 0;
        __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
         {
          {
            __Pyx_PyThreadState_declare
            __Pyx_PyThreadState_assign
            __Pyx_ExceptionSave(&__pyx_t_10, &__pyx_t_11, &__pyx_t_12);
            __Pyx_XGOTREF(__pyx_t_10);
            __Pyx_XGOTREF(__pyx_t_11);
            __Pyx_XGOTREF(__pyx_t_12);
             {
              __pyx_v_f = __pyx_t_5;
              __pyx_t_5 = 0;

              
              if (likely(PyList_CheckExact(__pyx_v_f)) || PyTuple_CheckExact(__pyx_v_f)) {
                __pyx_t_5 = __pyx_v_f; __Pyx_INCREF(__pyx_t_5);
                __pyx_t_13 = 0;
                __pyx_t_14 = NULL;
              } else {
                __pyx_t_13 = -1; __pyx_t_5 = PyObject_GetIter(__pyx_v_f); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 206, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_5);
                __pyx_t_14 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_5); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 206, __pyx_L13_error)
              }
              for (;;) {
                if (likely(!__pyx_t_14)) {
                  if (likely(PyList_CheckExact(__pyx_t_5))) {
                    {
                      Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_5);
                      #if !CYTHON_ASSUME_SAFE_SIZE
                      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 206, __pyx_L13_error)
                      #endif
                      if (__pyx_t_13 >= __pyx_temp) break;
                    }
                    __pyx_t_1 = __Pyx_PyList_GetItemRef(__pyx_t_5, __pyx_t_13);
                    ++__pyx_t_13;
                  } else {
                    {
                      Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_5);
                      #if !CYTHON_ASSUME_SAFE_SIZE
                      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 206, __pyx_L13_error)
                      #endif
                      if (__pyx_t_13 >= __pyx_temp) break;
                    }
                    #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                    __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_5, __pyx_t_13));
                    #else
                    __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_5, __pyx_t_13);
                    #endif
                    ++__pyx_t_13;
                  }
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 206, __pyx_L13_error)
                } else {
                  __pyx_t_1 = __pyx_t_14(__pyx_t_5);
                  if (unlikely(!__pyx_t_1)) {
                    PyObject* exc_type = PyErr_Occurred();
                    if (exc_type) {
                      if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 206, __pyx_L13_error)
                      PyErr_Clear();
                    }
                    break;
                  }
                }
                __Pyx_GOTREF(__pyx_t_1);
                __Pyx_XDECREF_SET(__pyx_v_line, __pyx_t_1);
                __pyx_t_1 = 0;

                
                __pyx_t_6 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_8, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 207, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_8);
                __pyx_t_15 = __Pyx_PyObject_GetAttrStr(__pyx_t_8, __pyx_mstate_global->__pyx_n_u_search); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 207, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_15);
                __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
                __pyx_t_7 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_15))) {
                  __pyx_t_6 = PyMethod_GET_SELF(__pyx_t_15);
                  assert(__pyx_t_6);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_15);
                  __Pyx_INCREF(__pyx_t_6);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_15, __pyx__function);
                  __pyx_t_7 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[3] = {__pyx_t_6, __pyx_mstate_global->__pyx_kp_u__10, __pyx_v_line};
                  __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_15, __pyx_callargs+__pyx_t_7, (3-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
                  __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 207, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_1);
                }
                __Pyx_XDECREF_SET(__pyx_v_m_paren, __pyx_t_1);
                __pyx_t_1 = 0;

                
                __pyx_t_16 = __Pyx_PyObject_IsTrue(__pyx_v_m_paren); if (unlikely((__pyx_t_16 < 0))) __PYX_ERR(0, 208, __pyx_L13_error)
                __pyx_t_17 = (!__pyx_t_16);
                if (__pyx_t_17) {

                  
                  goto __pyx_L19_continue;

                  
                }

                
                __pyx_t_15 = __pyx_v_m_paren;
                __Pyx_INCREF(__pyx_t_15);
                __pyx_t_7 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_15, __pyx_mstate_global->__pyx_int_1};
                  __pyx_t_1 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_group, __pyx_callargs+__pyx_t_7, (2-__pyx_t_7) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_15); __pyx_t_15 = 0;
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 210, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_1);
                }
                __Pyx_XDECREF_SET(__pyx_v_inside, __pyx_t_1);
                __pyx_t_1 = 0;

                
                __pyx_t_15 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_extract_model_from_parentheses); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 211, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_6);
                __pyx_t_7 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_6))) {
                  __pyx_t_15 = PyMethod_GET_SELF(__pyx_t_6);
                  assert(__pyx_t_15);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_6);
                  __Pyx_INCREF(__pyx_t_15);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_6, __pyx__function);
                  __pyx_t_7 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_15, __pyx_v_inside};
                  __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_6, __pyx_callargs+__pyx_t_7, (2-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_15); __pyx_t_15 = 0;
                  __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 211, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_1);
                }
                __Pyx_XDECREF_SET(__pyx_v_model, __pyx_t_1);
                __pyx_t_1 = 0;

                
                __pyx_t_17 = __Pyx_PyObject_IsTrue(__pyx_v_model); if (unlikely((__pyx_t_17 < 0))) __PYX_ERR(0, 212, __pyx_L13_error)
                __pyx_t_16 = (!__pyx_t_17);
                if (__pyx_t_16) {

                  
                  goto __pyx_L19_continue;

                  
                }

                
                __pyx_t_19 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_20, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 214, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_20);
                __pyx_t_21 = __Pyx_PyObject_GetAttrStr(__pyx_t_20, __pyx_mstate_global->__pyx_n_u_sub); if (unlikely(!__pyx_t_21)) __PYX_ERR(0, 214, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_21);
                __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
                __pyx_t_7 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_21))) {
                  __pyx_t_19 = PyMethod_GET_SELF(__pyx_t_21);
                  assert(__pyx_t_19);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_21);
                  __Pyx_INCREF(__pyx_t_19);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_21, __pyx__function);
                  __pyx_t_7 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[4] = {__pyx_t_19, __pyx_mstate_global->__pyx_kp_u_s, __pyx_mstate_global->__pyx_kp_u__3, __pyx_v_model};
                  __pyx_t_18 = __Pyx_PyObject_FastCall(__pyx_t_21, __pyx_callargs+__pyx_t_7, (4-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
                  __Pyx_DECREF(__pyx_t_21); __pyx_t_21 = 0;
                  if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 214, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_18);
                }
                __pyx_t_8 = __pyx_t_18;
                __Pyx_INCREF(__pyx_t_8);
                __pyx_t_7 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_8, NULL};
                  __pyx_t_15 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_7, (1-__pyx_t_7) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 214, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_15);
                }
                __pyx_t_6 = __pyx_t_15;
                __Pyx_INCREF(__pyx_t_6);
                __pyx_t_7 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_6, __pyx_mstate_global->__pyx_kp_u__11};
                  __pyx_t_1 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_rstrip, __pyx_callargs+__pyx_t_7, (2-__pyx_t_7) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
                  __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 214, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_1);
                }
                __Pyx_DECREF_SET(__pyx_v_model, __pyx_t_1);
                __pyx_t_1 = 0;

                
                __pyx_t_17 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_kp_u__12, __pyx_v_model, Py_EQ)); if (unlikely((__pyx_t_17 < 0))) __PYX_ERR(0, 215, __pyx_L13_error)
                if (!__pyx_t_17) {
                } else {
                  __pyx_t_16 = __pyx_t_17;
                  goto __pyx_L24_bool_binop_done;
                }
                __pyx_t_15 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 215, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_6);
                __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_search); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 215, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_18);
                __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
                __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 215, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_6);
                __pyx_t_8 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_IGNORECASE); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 215, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_8);
                __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
                __pyx_t_7 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_18))) {
                  __pyx_t_15 = PyMethod_GET_SELF(__pyx_t_18);
                  assert(__pyx_t_15);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_18);
                  __Pyx_INCREF(__pyx_t_15);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_18, __pyx__function);
                  __pyx_t_7 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[4] = {__pyx_t_15, __pyx_mstate_global->__pyx_kp_u_bFlow_b, __pyx_v_model, __pyx_t_8};
                  __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_18, __pyx_callargs+__pyx_t_7, (4-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_15); __pyx_t_15 = 0;
                  __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 215, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_1);
                }
                __pyx_t_17 = __Pyx_PyObject_IsTrue(__pyx_t_1); if (unlikely((__pyx_t_17 < 0))) __PYX_ERR(0, 215, __pyx_L13_error)
                __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
                __pyx_t_16 = __pyx_t_17;
                __pyx_L24_bool_binop_done:;
                if (__pyx_t_16) {

                  
                  goto __pyx_L19_continue;

                  
                }

                
                __pyx_t_18 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_8, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 217, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_8);
                __pyx_t_15 = __Pyx_PyObject_GetAttrStr(__pyx_t_8, __pyx_mstate_global->__pyx_n_u_search); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 217, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_15);
                __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
                __Pyx_GetModuleGlobalName(__pyx_t_8, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 217, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_8);
                __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_t_8, __pyx_mstate_global->__pyx_n_u_IGNORECASE); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 217, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_6);
                __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
                __pyx_t_7 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_15))) {
                  __pyx_t_18 = PyMethod_GET_SELF(__pyx_t_15);
                  assert(__pyx_t_18);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_15);
                  __Pyx_INCREF(__pyx_t_18);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_15, __pyx__function);
                  __pyx_t_7 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[4] = {__pyx_t_18, __pyx_mstate_global->__pyx_kp_u_Build_s, __pyx_v_inside, __pyx_t_6};
                  __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_15, __pyx_callargs+__pyx_t_7, (4-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
                  __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
                  __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 217, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_1);
                }
                __Pyx_XDECREF_SET(__pyx_v_build_match, __pyx_t_1);
                __pyx_t_1 = 0;

                
                __pyx_t_16 = __Pyx_PyObject_IsTrue(__pyx_v_build_match); if (unlikely((__pyx_t_16 < 0))) __PYX_ERR(0, 218, __pyx_L13_error)
                if (__pyx_t_16) {
                  __pyx_t_8 = __pyx_v_build_match;
                  __Pyx_INCREF(__pyx_t_8);
                  __pyx_t_7 = 0;
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_8, __pyx_mstate_global->__pyx_int_1};
                    __pyx_t_18 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_group, __pyx_callargs+__pyx_t_7, (2-__pyx_t_7) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
                    if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 218, __pyx_L13_error)
                    __Pyx_GOTREF(__pyx_t_18);
                  }
                  __pyx_t_6 = __pyx_t_18;
                  __Pyx_INCREF(__pyx_t_6);
                  __pyx_t_7 = 0;
                  {
                    PyObject *__pyx_callargs[2] = {__pyx_t_6, NULL};
                    __pyx_t_15 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_7, (1-__pyx_t_7) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                    __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
                    __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                    if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 218, __pyx_L13_error)
                    __Pyx_GOTREF(__pyx_t_15);
                  }
                  __pyx_t_1 = __pyx_t_15;
                  __pyx_t_15 = 0;
                } else {
                  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u__7);
                  __pyx_t_1 = __pyx_mstate_global->__pyx_kp_u__7;
                }
                __Pyx_XDECREF_SET(__pyx_v_build, __pyx_t_1);
                __pyx_t_1 = 0;

                
                __pyx_t_15 = NULL;
                __Pyx_GetModuleGlobalName(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 219, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_18);
                __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_search); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 219, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_6);
                __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                __Pyx_GetModuleGlobalName(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 219, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_18);
                __pyx_t_8 = __Pyx_PyObject_GetAttrStr(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_IGNORECASE); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 219, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_8);
                __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                __pyx_t_7 = 1;
                #if CYTHON_UNPACK_METHODS
                if (unlikely(PyMethod_Check(__pyx_t_6))) {
                  __pyx_t_15 = PyMethod_GET_SELF(__pyx_t_6);
                  assert(__pyx_t_15);
                  PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_6);
                  __Pyx_INCREF(__pyx_t_15);
                  __Pyx_INCREF(__pyx__function);
                  __Pyx_DECREF_SET(__pyx_t_6, __pyx__function);
                  __pyx_t_7 = 0;
                }
                #endif
                {
                  PyObject *__pyx_callargs[4] = {__pyx_t_15, __pyx_mstate_global->__pyx_kp_u_bwv_b, __pyx_v_inside, __pyx_t_8};
                  __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_6, __pyx_callargs+__pyx_t_7, (4-__pyx_t_7) | (__pyx_t_7*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_15); __pyx_t_15 = 0;
                  __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
                  __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
                  if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 219, __pyx_L13_error)
                  __Pyx_GOTREF(__pyx_t_1);
                }
                __pyx_t_16 = __Pyx_PyObject_IsTrue(__pyx_t_1); if (unlikely((__pyx_t_16 < 0))) __PYX_ERR(0, 219, __pyx_L13_error)
                __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
                __pyx_v_has_wv = (!(!__pyx_t_16));

                
                __pyx_t_1 = __Pyx_PyDict_NewPresized(3); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 221, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_1);
                if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_model, __pyx_v_model) < 0) __PYX_ERR(0, 221, __pyx_L13_error)
                if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_build, __pyx_v_build) < 0) __PYX_ERR(0, 221, __pyx_L13_error)
                __pyx_t_6 = __Pyx_PyBool_FromLong(__pyx_v_has_wv); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 221, __pyx_L13_error)
                __Pyx_GOTREF(__pyx_t_6);
                if (PyDict_SetItem(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_wv, __pyx_t_6) < 0) __PYX_ERR(0, 221, __pyx_L13_error)
                __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
                __pyx_t_22 = __Pyx_PyList_Append(__pyx_v_models, __pyx_t_1); if (unlikely(__pyx_t_22 == ((int)-1))) __PYX_ERR(0, 221, __pyx_L13_error)
                __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

                
                __pyx_L19_continue:;
              }
              __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

              
            }
            __Pyx_XDECREF(__pyx_t_10); __pyx_t_10 = 0;
            __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
            __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
            goto __pyx_L18_try_end;
            __pyx_L13_error:;
            __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
            __Pyx_XDECREF(__pyx_t_15); __pyx_t_15 = 0;
            __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
            __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
            __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;
            __Pyx_XDECREF(__pyx_t_21); __pyx_t_21 = 0;
            __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
            __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
            __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
             {
              __Pyx_AddTraceback("user_agent.load_models_from_user_file", __pyx_clineno, __pyx_lineno, __pyx_filename);
              if (__Pyx_GetException(&__pyx_t_5, &__pyx_t_1, &__pyx_t_6) < 0) __PYX_ERR(0, 205, __pyx_L15_except_error)
              __Pyx_XGOTREF(__pyx_t_5);
              __Pyx_XGOTREF(__pyx_t_1);
              __Pyx_XGOTREF(__pyx_t_6);
              __pyx_t_8 = PyTuple_Pack(3, __pyx_t_5, __pyx_t_1, __pyx_t_6); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 205, __pyx_L15_except_error)
              __Pyx_GOTREF(__pyx_t_8);
              __pyx_t_23 = __Pyx_PyObject_Call(__pyx_t_9, __pyx_t_8, NULL);
              __Pyx_DECREF(__pyx_t_9); __pyx_t_9 = 0;
              __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
              if (unlikely(!__pyx_t_23)) __PYX_ERR(0, 205, __pyx_L15_except_error)
              __Pyx_GOTREF(__pyx_t_23);
              __pyx_t_16 = __Pyx_PyObject_IsTrue(__pyx_t_23);
              __Pyx_DECREF(__pyx_t_23); __pyx_t_23 = 0;
              if (__pyx_t_16 < 0) __PYX_ERR(0, 205, __pyx_L15_except_error)
              __pyx_t_17 = (!__pyx_t_16);
              if (unlikely(__pyx_t_17)) {
                __Pyx_GIVEREF(__pyx_t_5);
                __Pyx_GIVEREF(__pyx_t_1);
                __Pyx_XGIVEREF(__pyx_t_6);
                __Pyx_ErrRestoreWithState(__pyx_t_5, __pyx_t_1, __pyx_t_6);
                __pyx_t_5 = 0;  __pyx_t_1 = 0;  __pyx_t_6 = 0; 
                __PYX_ERR(0, 205, __pyx_L15_except_error)
              }
              __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
              __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
              __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
              goto __pyx_L14_exception_handled;
            }
            __pyx_L15_except_error:;
            __Pyx_XGIVEREF(__pyx_t_10);
            __Pyx_XGIVEREF(__pyx_t_11);
            __Pyx_XGIVEREF(__pyx_t_12);
            __Pyx_ExceptionReset(__pyx_t_10, __pyx_t_11, __pyx_t_12);
            goto __pyx_L3_error;
            __pyx_L14_exception_handled:;
            __Pyx_XGIVEREF(__pyx_t_10);
            __Pyx_XGIVEREF(__pyx_t_11);
            __Pyx_XGIVEREF(__pyx_t_12);
            __Pyx_ExceptionReset(__pyx_t_10, __pyx_t_11, __pyx_t_12);
            __pyx_L18_try_end:;
          }
        }
         {
          {
            if (__pyx_t_9) {
              __pyx_t_12 = __Pyx_PyObject_Call(__pyx_t_9, __pyx_mstate_global->__pyx_tuple[1], NULL);
              __Pyx_DECREF(__pyx_t_9); __pyx_t_9 = 0;
              if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 205, __pyx_L3_error)
              __Pyx_GOTREF(__pyx_t_12);
              __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
            }
            goto __pyx_L12;
          }
          __pyx_L12:;
        }
        goto __pyx_L30;
        __pyx_L9_error:;
        __Pyx_DECREF(__pyx_t_9); __pyx_t_9 = 0;
        goto __pyx_L3_error;
        __pyx_L30:;
      }

      
    }
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    goto __pyx_L8_try_end;
    __pyx_L3_error:;
    __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
    __Pyx_XDECREF(__pyx_t_15); __pyx_t_15 = 0;
    __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
    __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
    __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;
    __Pyx_XDECREF(__pyx_t_21); __pyx_t_21 = 0;
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
    __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;

    
    __pyx_t_24 = __Pyx_PyErr_ExceptionMatches(__pyx_builtin_FileNotFoundError);
    if (__pyx_t_24) {
      __Pyx_AddTraceback("user_agent.load_models_from_user_file", __pyx_clineno, __pyx_lineno, __pyx_filename);
      if (__Pyx_GetException(&__pyx_t_6, &__pyx_t_1, &__pyx_t_5) < 0) __PYX_ERR(0, 222, __pyx_L5_except_error)
      __Pyx_XGOTREF(__pyx_t_6);
      __Pyx_XGOTREF(__pyx_t_1);
      __Pyx_XGOTREF(__pyx_t_5);

      
      __Pyx_XDECREF(__pyx_r);
      __pyx_t_8 = PyList_New(0); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 223, __pyx_L5_except_error)
      __Pyx_GOTREF(__pyx_t_8);
      __pyx_r = __pyx_t_8;
      __pyx_t_8 = 0;
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      goto __pyx_L6_except_return;
    }
    goto __pyx_L5_except_error;

    
    __pyx_L5_except_error:;
    __Pyx_XGIVEREF(__pyx_t_2);
    __Pyx_XGIVEREF(__pyx_t_3);
    __Pyx_XGIVEREF(__pyx_t_4);
    __Pyx_ExceptionReset(__pyx_t_2, __pyx_t_3, __pyx_t_4);
    goto __pyx_L1_error;
    __pyx_L6_except_return:;
    __Pyx_XGIVEREF(__pyx_t_2);
    __Pyx_XGIVEREF(__pyx_t_3);
    __Pyx_XGIVEREF(__pyx_t_4);
    __Pyx_ExceptionReset(__pyx_t_2, __pyx_t_3, __pyx_t_4);
    goto __pyx_L0;
    __pyx_L8_try_end:;
  }

  
  __pyx_t_5 = __Pyx_PyDict_NewPresized(0); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 224, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __pyx_v_uniq = ((PyObject*)__pyx_t_5);
  __pyx_t_5 = 0;

  
  __pyx_t_5 = __pyx_v_models; __Pyx_INCREF(__pyx_t_5);
  __pyx_t_13 = 0;
  for (;;) {
    {
      Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_5);
      #if !CYTHON_ASSUME_SAFE_SIZE
      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 225, __pyx_L1_error)
      #endif
      if (__pyx_t_13 >= __pyx_temp) break;
    }
    __pyx_t_1 = __Pyx_PyList_GetItemRef(__pyx_t_5, __pyx_t_13);
    ++__pyx_t_13;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 225, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_XDECREF_SET(__pyx_v_item, __pyx_t_1);
    __pyx_t_1 = 0;

    
    __pyx_t_1 = __Pyx_PyObject_Dict_GetItem(__pyx_v_item, __pyx_mstate_global->__pyx_n_u_model); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 226, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __pyx_t_6 = __Pyx_PyObject_Dict_GetItem(__pyx_v_item, __pyx_mstate_global->__pyx_n_u_build); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 226, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_6);
    __pyx_t_8 = PyTuple_New(2); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 226, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_8);
    __Pyx_GIVEREF(__pyx_t_1);
    if (__Pyx_PyTuple_SET_ITEM(__pyx_t_8, 0, __pyx_t_1) != (0)) __PYX_ERR(0, 226, __pyx_L1_error);
    __Pyx_GIVEREF(__pyx_t_6);
    if (__Pyx_PyTuple_SET_ITEM(__pyx_t_8, 1, __pyx_t_6) != (0)) __PYX_ERR(0, 226, __pyx_L1_error);
    __pyx_t_1 = 0;
    __pyx_t_6 = 0;
    __Pyx_XDECREF_SET(__pyx_v_key, ((PyObject*)__pyx_t_8));
    __pyx_t_8 = 0;

    
    __pyx_t_17 = (__Pyx_PyDict_ContainsTF(__pyx_v_key, __pyx_v_uniq, Py_NE)); if (unlikely((__pyx_t_17 < 0))) __PYX_ERR(0, 227, __pyx_L1_error)
    if (__pyx_t_17) {

      
      if (unlikely((PyDict_SetItem(__pyx_v_uniq, __pyx_v_key, __pyx_v_item) < 0))) __PYX_ERR(0, 228, __pyx_L1_error)

      
    }

    
  }
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

  
  __Pyx_XDECREF(__pyx_r);
  __pyx_t_5 = __Pyx_PyDict_Values(__pyx_v_uniq); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 229, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __pyx_t_8 = __Pyx_PySequence_ListKeepNew(__pyx_t_5); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 229, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_8);
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  __pyx_r = __pyx_t_8;
  __pyx_t_8 = 0;
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_6);
  __Pyx_XDECREF(__pyx_t_8);
  __Pyx_XDECREF(__pyx_t_15);
  __Pyx_XDECREF(__pyx_t_18);
  __Pyx_XDECREF(__pyx_t_19);
  __Pyx_XDECREF(__pyx_t_20);
  __Pyx_XDECREF(__pyx_t_21);
  __Pyx_AddTraceback("user_agent.load_models_from_user_file", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_models);
  __Pyx_XDECREF(__pyx_v_f);
  __Pyx_XDECREF(__pyx_v_line);
  __Pyx_XDECREF(__pyx_v_m_paren);
  __Pyx_XDECREF(__pyx_v_inside);
  __Pyx_XDECREF(__pyx_v_model);
  __Pyx_XDECREF(__pyx_v_build_match);
  __Pyx_XDECREF(__pyx_v_build);
  __Pyx_XDECREF(__pyx_v_uniq);
  __Pyx_XDECREF(__pyx_v_item);
  __Pyx_XDECREF(__pyx_v_key);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_15determine_merek_from_model(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_15determine_merek_from_model = {"determine_merek_from_model", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_15determine_merek_from_model, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_15determine_merek_from_model(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_model = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[1] = {0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("determine_merek_from_model (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_model,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 230, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 230, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "determine_merek_from_model", 0) < 0) __PYX_ERR(0, 230, __pyx_L3_error)
      for (Py_ssize_t i = __pyx_nargs; i < 1; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("determine_merek_from_model", 1, 1, 1, i); __PYX_ERR(0, 230, __pyx_L3_error) }
      }
    } else if (unlikely(__pyx_nargs != 1)) {
      goto __pyx_L5_argtuple_error;
    } else {
      values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 230, __pyx_L3_error)
    }
    __pyx_v_model = values[0];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("determine_merek_from_model", 1, 1, 1, __pyx_nargs); __PYX_ERR(0, 230, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent.determine_merek_from_model", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_14determine_merek_from_model(__pyx_self, __pyx_v_model);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_14determine_merek_from_model(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_model) {
  PyObject *__pyx_v_m = NULL;
  PyObject *__pyx_v_up = NULL;
  PyObject *__pyx_v_tokens = NULL;
  PyObject *__pyx_v_merek = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  int __pyx_t_1;
  int __pyx_t_2;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  size_t __pyx_t_5;
  PyObject *__pyx_t_6 = NULL;
  PyObject *__pyx_t_7 = NULL;
  Py_ssize_t __pyx_t_8;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("determine_merek_from_model", 0);

  
  __pyx_t_1 = __Pyx_PyObject_IsTrue(__pyx_v_model); if (unlikely((__pyx_t_1 < 0))) __PYX_ERR(0, 231, __pyx_L1_error)
  __pyx_t_2 = (!__pyx_t_1);
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_xiaomi);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_xiaomi;
    goto __pyx_L0;

    
  }

  
  __pyx_t_4 = __pyx_v_model;
  __Pyx_INCREF(__pyx_t_4);
  __pyx_t_5 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_4, NULL};
    __pyx_t_3 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_strip, __pyx_callargs+__pyx_t_5, (1-__pyx_t_5) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 233, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);
  }
  __pyx_v_m = __pyx_t_3;
  __pyx_t_3 = 0;

  
  __pyx_t_4 = __pyx_v_m;
  __Pyx_INCREF(__pyx_t_4);
  __pyx_t_5 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_4, NULL};
    __pyx_t_3 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_upper, __pyx_callargs+__pyx_t_5, (1-__pyx_t_5) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 234, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);
  }
  __pyx_v_up = __pyx_t_3;
  __pyx_t_3 = 0;

  
  __pyx_t_1 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_kp_u_SM, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_1 < 0))) __PYX_ERR(0, 235, __pyx_L1_error)
  if (!__pyx_t_1) {
  } else {
    __pyx_t_2 = __pyx_t_1;
    goto __pyx_L5_bool_binop_done;
  }
  __pyx_t_1 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_kp_u_GT, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_1 < 0))) __PYX_ERR(0, 235, __pyx_L1_error)
  __pyx_t_2 = __pyx_t_1;
  __pyx_L5_bool_binop_done:;
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_samsung);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_samsung;
    goto __pyx_L0;

    
  }

  
  __pyx_t_2 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_n_u_INFINIX, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 237, __pyx_L1_error)
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_Infinix);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_Infinix;
    goto __pyx_L0;

    
  }

  
  __pyx_t_2 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_n_u_Redmi, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 239, __pyx_L1_error)
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_xiaomi);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_xiaomi;
    goto __pyx_L0;

    
  }

  
  __pyx_t_2 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_n_u_MI, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 241, __pyx_L1_error)
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_xiaomi);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_xiaomi;
    goto __pyx_L0;

    
  }

  
  __pyx_t_2 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_n_u_Mi, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 243, __pyx_L1_error)
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_xiaomi);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_xiaomi;
    goto __pyx_L0;

    
  }

  
  __pyx_t_2 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_n_u_RMX, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 245, __pyx_L1_error)
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_realme);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_realme;
    goto __pyx_L0;

    
  }

  
  __pyx_t_2 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_n_u_TECNO, __pyx_v_up, Py_EQ)); if (unlikely((__pyx_t_2 < 0))) __PYX_ERR(0, 247, __pyx_L1_error)
  if (__pyx_t_2) {

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_TECNO);
    __pyx_r = __pyx_mstate_global->__pyx_n_u_TECNO;
    goto __pyx_L0;

    
  }

  
  __pyx_t_4 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 249, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_6);
  __pyx_t_7 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_split); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 249, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_7);
  __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
  __pyx_t_5 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_7))) {
    __pyx_t_4 = PyMethod_GET_SELF(__pyx_t_7);
    assert(__pyx_t_4);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_7);
    __Pyx_INCREF(__pyx_t_4);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_7, __pyx__function);
    __pyx_t_5 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[3] = {__pyx_t_4, __pyx_mstate_global->__pyx_kp_u_s_2, __pyx_v_m};
    __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_7, __pyx_callargs+__pyx_t_5, (3-__pyx_t_5) | (__pyx_t_5*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
    if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 249, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);
  }
  __pyx_v_tokens = __pyx_t_3;
  __pyx_t_3 = 0;

  
  __pyx_t_8 = PyObject_Length(__pyx_v_tokens); if (unlikely(__pyx_t_8 == ((Py_ssize_t)-1))) __PYX_ERR(0, 250, __pyx_L1_error)
  __pyx_t_1 = (__pyx_t_8 > 1);
  if (__pyx_t_1) {
  } else {
    __pyx_t_2 = __pyx_t_1;
    goto __pyx_L14_bool_binop_done;
  }
  __pyx_t_3 = __Pyx_GetItemInt(__pyx_v_tokens, 0, long, 1, __Pyx_PyLong_From_long, 0, 0, 1, 1); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 250, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_1 = __Pyx_PyObject_IsTrue(__pyx_t_3); if (unlikely((__pyx_t_1 < 0))) __PYX_ERR(0, 250, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_2 = __pyx_t_1;
  __pyx_L14_bool_binop_done:;
  if (__pyx_t_2) {

    
    __pyx_t_3 = __Pyx_GetItemInt(__pyx_v_tokens, 0, long, 1, __Pyx_PyLong_From_long, 0, 0, 1, 1); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 251, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);
    __pyx_v_merek = __pyx_t_3;
    __pyx_t_3 = 0;

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_v_merek);
    __pyx_r = __pyx_v_merek;
    goto __pyx_L0;

    
  }

  
  __Pyx_XDECREF(__pyx_r);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_xiaomi);
  __pyx_r = __pyx_mstate_global->__pyx_n_u_xiaomi;
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_XDECREF(__pyx_t_4);
  __Pyx_XDECREF(__pyx_t_6);
  __Pyx_XDECREF(__pyx_t_7);
  __Pyx_AddTraceback("user_agent.determine_merek_from_model", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_m);
  __Pyx_XDECREF(__pyx_v_up);
  __Pyx_XDECREF(__pyx_v_tokens);
  __Pyx_XDECREF(__pyx_v_merek);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_10user_agent_17pake_dalvik(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_10user_agent_17pake_dalvik = {"pake_dalvik", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_10user_agent_17pake_dalvik, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_10user_agent_17pake_dalvik(PyObject *__pyx_self, 
#if CYTHON_METH_FASTCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_pilihanku = 0;
  #if !CYTHON_METH_FASTCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[1] = {0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("pake_dalvik (wrapper)", 0);
  #if !CYTHON_METH_FASTCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_pilihanku,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len) < 0) __PYX_ERR(0, 255, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 255, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "pake_dalvik", 0) < 0) __PYX_ERR(0, 255, __pyx_L3_error)
      for (Py_ssize_t i = __pyx_nargs; i < 1; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("pake_dalvik", 1, 1, 1, i); __PYX_ERR(0, 255, __pyx_L3_error) }
      }
    } else if (unlikely(__pyx_nargs != 1)) {
      goto __pyx_L5_argtuple_error;
    } else {
      values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 255, __pyx_L3_error)
    }
    __pyx_v_pilihanku = values[0];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("pake_dalvik", 1, 1, 1, __pyx_nargs); __PYX_ERR(0, 255, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("user_agent.pake_dalvik", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_10user_agent_16pake_dalvik(__pyx_self, __pyx_v_pilihanku);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_10user_agent_16pake_dalvik(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_pilihanku) {
  PyObject *__pyx_v_locales = NULL;
  PyObject *__pyx_v_architectures = NULL;
  PyObject *__pyx_v_densities = NULL;
  PyObject *__pyx_v_widths = NULL;
  PyObject *__pyx_v_heights = NULL;
  PyObject *__pyx_v_models = NULL;
  PyObject *__pyx_v_info = NULL;
  PyObject *__pyx_v_ceri = NULL;
  PyObject *__pyx_v_fbav2 = NULL;
  PyObject *__pyx_v_fbbv2 = NULL;
  PyObject *__pyx_v_fbvs = NULL;
  PyObject *__pyx_v_fbab = NULL;
  PyObject *__pyx_v_model = NULL;
  PyObject *__pyx_v_build = NULL;
  PyObject *__pyx_v_has_wv = NULL;
  PyObject *__pyx_v_merek = NULL;
  PyObject *__pyx_v_fbav = NULL;
  PyObject *__pyx_v_fbbv = NULL;
  PyObject *__pyx_v_fbs_v = NULL;
  PyObject *__pyx_v_merek1 = NULL;
  PyObject *__pyx_v_hasil = NULL;
  PyObject *__pyx_v_cari = NULL;
  PyObject *__pyx_v_model_in_build = NULL;
  PyObject *__pyx_v_model_in_build2 = NULL;
  PyObject *__pyx_v_agen = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  size_t __pyx_t_4;
  PyObject *__pyx_t_5 = NULL;
  int __pyx_t_6;
  PyObject *__pyx_t_7[3];
  int __pyx_t_8;
  PyObject *__pyx_t_9 = NULL;
  PyObject *__pyx_t_10 = NULL;
  PyObject *__pyx_t_11 = NULL;
  PyObject *__pyx_t_12 = NULL;
  PyObject *__pyx_t_13 = NULL;
  PyObject *__pyx_t_14 = NULL;
  PyObject *__pyx_t_15 = NULL;
  PyObject *__pyx_t_16 = NULL;
  PyObject *__pyx_t_17 = NULL;
  PyObject *__pyx_t_18[25];
  PyObject *__pyx_t_19 = NULL;
  PyObject *__pyx_t_20 = NULL;
  PyObject *__pyx_t_21[29];
  PyObject *__pyx_t_22[17];
  PyObject *__pyx_t_23[5];
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("pake_dalvik", 0);

  
  __pyx_t_1 = PyList_New(3); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 256, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_id_ID);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_n_u_id_ID);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 0, __pyx_mstate_global->__pyx_n_u_id_ID) != (0)) __PYX_ERR(0, 256, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_en_US);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_n_u_en_US);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 1, __pyx_mstate_global->__pyx_n_u_en_US) != (0)) __PYX_ERR(0, 256, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_en_GB);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_n_u_en_GB);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 2, __pyx_mstate_global->__pyx_n_u_en_GB) != (0)) __PYX_ERR(0, 256, __pyx_L1_error);
  __pyx_v_locales = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = PyList_New(2); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 257, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_armeabi_v7a_armeabi);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_armeabi_v7a_armeabi);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 0, __pyx_mstate_global->__pyx_kp_u_armeabi_v7a_armeabi) != (0)) __PYX_ERR(0, 257, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_arm64_v8a);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_arm64_v8a);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 1, __pyx_mstate_global->__pyx_kp_u_arm64_v8a) != (0)) __PYX_ERR(0, 257, __pyx_L1_error);
  __pyx_v_architectures = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = PyList_New(4); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 258, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_3_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_3_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 0, __pyx_mstate_global->__pyx_kp_u_3_0) != (0)) __PYX_ERR(0, 258, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_2_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_2_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 1, __pyx_mstate_global->__pyx_kp_u_2_0) != (0)) __PYX_ERR(0, 258, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_4_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_4_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 2, __pyx_mstate_global->__pyx_kp_u_4_0) != (0)) __PYX_ERR(0, 258, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1_5);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1_5);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 3, __pyx_mstate_global->__pyx_kp_u_1_5) != (0)) __PYX_ERR(0, 258, __pyx_L1_error);
  __pyx_v_densities = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = PyList_New(4); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 259, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1080);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1080);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 0, __pyx_mstate_global->__pyx_kp_u_1080) != (0)) __PYX_ERR(0, 259, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_720);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_720);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 1, __pyx_mstate_global->__pyx_kp_u_720) != (0)) __PYX_ERR(0, 259, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1440);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1440);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 2, __pyx_mstate_global->__pyx_kp_u_1440) != (0)) __PYX_ERR(0, 259, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1424);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1424);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 3, __pyx_mstate_global->__pyx_kp_u_1424) != (0)) __PYX_ERR(0, 259, __pyx_L1_error);
  __pyx_v_widths = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = PyList_New(5); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 260, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1920);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1920);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 0, __pyx_mstate_global->__pyx_kp_u_1920) != (0)) __PYX_ERR(0, 260, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1184);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1184);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 1, __pyx_mstate_global->__pyx_kp_u_1184) != (0)) __PYX_ERR(0, 260, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_2768);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_2768);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 2, __pyx_mstate_global->__pyx_kp_u_2768) != (0)) __PYX_ERR(0, 260, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1280);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1280);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 3, __pyx_mstate_global->__pyx_kp_u_1280) != (0)) __PYX_ERR(0, 260, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_720);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_720);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 4, __pyx_mstate_global->__pyx_kp_u_720) != (0)) __PYX_ERR(0, 260, __pyx_L1_error);
  __pyx_v_heights = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_2 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_load_models_from_user_file); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 261, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_3))) {
    __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_3);
    assert(__pyx_t_2);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_3);
    __Pyx_INCREF(__pyx_t_2);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_3, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, NULL};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_3, __pyx_callargs+__pyx_t_4, (1-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 261, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_models = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_3 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 262, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 262, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_5))) {
    __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_5);
    assert(__pyx_t_3);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
    __Pyx_INCREF(__pyx_t_3);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_v_models};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 262, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_info = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_5 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 263, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 263, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = PyList_New(5); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 263, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_Stay_Home_Teletalk);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_Stay_Home_Teletalk);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 0, __pyx_mstate_global->__pyx_kp_u_Stay_Home_Teletalk) != (0)) __PYX_ERR(0, 263, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_null);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_n_u_null);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 1, __pyx_mstate_global->__pyx_n_u_null) != (0)) __PYX_ERR(0, 263, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_AIS);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_n_u_AIS);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 2, __pyx_mstate_global->__pyx_n_u_AIS) != (0)) __PYX_ERR(0, 263, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_MTN);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_n_u_MTN);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 3, __pyx_mstate_global->__pyx_n_u_MTN) != (0)) __PYX_ERR(0, 263, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_n_u_PLAY);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_n_u_PLAY);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 4, __pyx_mstate_global->__pyx_n_u_PLAY) != (0)) __PYX_ERR(0, 263, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_2))) {
    __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_2);
    assert(__pyx_t_5);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_2);
    __Pyx_INCREF(__pyx_t_5);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_2, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_3};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_2, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 263, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_ceri = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_2 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 264, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 264, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = PyList_New(18); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 264, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_10_6_1a);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_10_6_1a);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 0, __pyx_mstate_global->__pyx_kp_u_10_6_1a) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_2_8);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_2_8);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 1, __pyx_mstate_global->__pyx_kp_u_6_2_8) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_3_04);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_3_04);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 2, __pyx_mstate_global->__pyx_kp_u_3_04) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_2_6);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_2_6);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 3, __pyx_mstate_global->__pyx_kp_u_6_2_6) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_2_4);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_2_4);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 4, __pyx_mstate_global->__pyx_kp_u_6_2_4) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_10_03);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_10_03);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 5, __pyx_mstate_global->__pyx_kp_u_10_03) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_2_5_49);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_2_5_49);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 6, __pyx_mstate_global->__pyx_kp_u_2_5_49) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_2_90);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_2_90);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 7, __pyx_mstate_global->__pyx_kp_u_2_90) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_2_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_2_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 8, __pyx_mstate_global->__pyx_kp_u_6_2_0) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_9_6_7_0214);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_9_6_7_0214);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 9, __pyx_mstate_global->__pyx_kp_u_9_6_7_0214) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_9_85);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_9_85);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 10, __pyx_mstate_global->__pyx_kp_u_9_85) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_2_87);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_2_87);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 11, __pyx_mstate_global->__pyx_kp_u_2_87) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_9_0_10);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_9_0_10);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 12, __pyx_mstate_global->__pyx_kp_u_9_0_10) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1_92_12);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1_92_12);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 13, __pyx_mstate_global->__pyx_kp_u_1_92_12) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_9_79);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_9_79);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 14, __pyx_mstate_global->__pyx_kp_u_9_79) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_2_5_38);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_2_5_38);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 15, __pyx_mstate_global->__pyx_kp_u_2_5_38) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1_78_7800);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1_78_7800);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 16, __pyx_mstate_global->__pyx_kp_u_1_78_7800) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1_51_5103);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1_51_5103);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 17, __pyx_mstate_global->__pyx_kp_u_1_51_5103) != (0)) __PYX_ERR(0, 264, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_5))) {
    __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_5);
    assert(__pyx_t_2);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
    __Pyx_INCREF(__pyx_t_2);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_t_3};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 264, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_fbav2 = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_5 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 284, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 284, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = PyList_New(15); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 284, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_1061021);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_1061021);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 0, __pyx_mstate_global->__pyx_kp_u_1061021) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6208);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6208);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 1, __pyx_mstate_global->__pyx_kp_u_6208) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_304);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_304);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 2, __pyx_mstate_global->__pyx_kp_u_304) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6206);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6206);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 3, __pyx_mstate_global->__pyx_kp_u_6206) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6205);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6205);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 4, __pyx_mstate_global->__pyx_kp_u_6205) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_81003);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_81003);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 5, __pyx_mstate_global->__pyx_kp_u_81003) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_55042);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_55042);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 6, __pyx_mstate_global->__pyx_kp_u_55042) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_290);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_290);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 7, __pyx_mstate_global->__pyx_kp_u_290) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6200);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6200);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 8, __pyx_mstate_global->__pyx_kp_u_6200) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_393);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_393);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 9, __pyx_mstate_global->__pyx_kp_u_393) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_77985);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_77985);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 10, __pyx_mstate_global->__pyx_kp_u_77985) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_287);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_287);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 11, __pyx_mstate_global->__pyx_kp_u_287) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_249010);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_249010);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 12, __pyx_mstate_global->__pyx_kp_u_249010) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_2184025);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_2184025);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 13, __pyx_mstate_global->__pyx_kp_u_2184025) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_77979);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_77979);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 14, __pyx_mstate_global->__pyx_kp_u_77979) != (0)) __PYX_ERR(0, 284, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_2))) {
    __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_2);
    assert(__pyx_t_5);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_2);
    __Pyx_INCREF(__pyx_t_5);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_2, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_3};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_2, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 284, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_fbbv2 = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_2 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 301, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 301, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = PyList_New(4); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 301, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_18_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_18_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 0, __pyx_mstate_global->__pyx_kp_u_6_18_0) != (0)) __PYX_ERR(0, 301, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_17_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_17_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 1, __pyx_mstate_global->__pyx_kp_u_6_17_0) != (0)) __PYX_ERR(0, 301, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_16_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_16_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 2, __pyx_mstate_global->__pyx_kp_u_6_16_0) != (0)) __PYX_ERR(0, 301, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_6_15_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_6_15_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 3, __pyx_mstate_global->__pyx_kp_u_6_15_0) != (0)) __PYX_ERR(0, 301, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_5))) {
    __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_5);
    assert(__pyx_t_2);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
    __Pyx_INCREF(__pyx_t_2);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_t_3};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 301, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_fbvs = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_5 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 302, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 302, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = PyList_New(11); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 302, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_gameloft_android_ANMP_GloftD);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_gameloft_android_ANMP_GloftD);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 0, __pyx_mstate_global->__pyx_kp_u_com_gameloft_android_ANMP_GloftD) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_tongitsgo_play);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_tongitsgo_play);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 1, __pyx_mstate_global->__pyx_kp_u_com_tongitsgo_play) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_grandegames_slots_dafu_casin);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_grandegames_slots_dafu_casin);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 2, __pyx_mstate_global->__pyx_kp_u_com_grandegames_slots_dafu_casin) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_teenpatti_hd_gold);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_teenpatti_hd_gold);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 3, __pyx_mstate_global->__pyx_kp_u_com_teenpatti_hd_gold) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_moonfrog_ludo_club);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_moonfrog_ludo_club);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 4, __pyx_mstate_global->__pyx_kp_u_com_moonfrog_ludo_club) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_grandegames_slots_dafu_casin);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_grandegames_slots_dafu_casin);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 5, __pyx_mstate_global->__pyx_kp_u_com_grandegames_slots_dafu_casin) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_ikeyboard_theme_pink_rgb_hea);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_ikeyboard_theme_pink_rgb_hea);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 6, __pyx_mstate_global->__pyx_kp_u_com_ikeyboard_theme_pink_rgb_hea) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_ludia_dragons);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_ludia_dragons);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 7, __pyx_mstate_global->__pyx_kp_u_com_ludia_dragons) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_ea_gp_nbamobile);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_ea_gp_nbamobile);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 8, __pyx_mstate_global->__pyx_kp_u_com_ea_gp_nbamobile) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_g5e_hiddencity_android);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_g5e_hiddencity_android);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 9, __pyx_mstate_global->__pyx_kp_u_com_g5e_hiddencity_android) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_com_g5e_sherlock_android);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_com_g5e_sherlock_android);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_3, 10, __pyx_mstate_global->__pyx_kp_u_com_g5e_sherlock_android) != (0)) __PYX_ERR(0, 302, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_2))) {
    __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_2);
    assert(__pyx_t_5);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_2);
    __Pyx_INCREF(__pyx_t_5);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_2, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_3};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_2, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 302, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_fbab = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_PyObject_Dict_GetItem(__pyx_v_info, __pyx_mstate_global->__pyx_n_u_model); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 315, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_model = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_info, __pyx_mstate_global->__pyx_n_u_get); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 316, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_2 = __Pyx_PyObject_Call(__pyx_t_1, __pyx_mstate_global->__pyx_tuple[4], NULL); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 316, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_v_build = __pyx_t_2;
  __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_v_info, __pyx_mstate_global->__pyx_n_u_get); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 317, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_1 = __Pyx_PyObject_Call(__pyx_t_2, __pyx_mstate_global->__pyx_tuple[5], NULL); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 317, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_v_has_wv = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_2 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_determine_merek_from_model); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 318, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_3))) {
    __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_3);
    assert(__pyx_t_2);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_3);
    __Pyx_INCREF(__pyx_t_2);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_3, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_v_model};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_3, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 318, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_merek = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_3 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 319, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 319, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_t_2 = PyList_New(10); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 319, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_63_0_0_4382);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_63_0_0_4382);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 0, __pyx_mstate_global->__pyx_kp_u_63_0_0_4382) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_130_0_0_15_89);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_130_0_0_15_89);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 1, __pyx_mstate_global->__pyx_kp_u_130_0_0_15_89) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_196_0_0_29_99);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_196_0_0_29_99);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 2, __pyx_mstate_global->__pyx_kp_u_196_0_0_29_99) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_44_0_0_8_52);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_44_0_0_8_52);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 3, __pyx_mstate_global->__pyx_kp_u_44_0_0_8_52) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_220_0_0_20_121);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_220_0_0_20_121);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 4, __pyx_mstate_global->__pyx_kp_u_220_0_0_20_121) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_230_0_0_12_117);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_230_0_0_12_117);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 5, __pyx_mstate_global->__pyx_kp_u_230_0_0_12_117) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_241_0_0_17_116);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_241_0_0_17_116);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 6, __pyx_mstate_global->__pyx_kp_u_241_0_0_17_116) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_196_0_0_29_99);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_196_0_0_29_99);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 7, __pyx_mstate_global->__pyx_kp_u_196_0_0_29_99) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_454_0_0_37_109);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_454_0_0_37_109);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 8, __pyx_mstate_global->__pyx_kp_u_454_0_0_37_109) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_220_0_0_20_121);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_220_0_0_20_121);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 9, __pyx_mstate_global->__pyx_kp_u_220_0_0_20_121) != (0)) __PYX_ERR(0, 319, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_5))) {
    __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_5);
    assert(__pyx_t_3);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
    __Pyx_INCREF(__pyx_t_3);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_t_2};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 319, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_fbav = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_5 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 320, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_3 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 320, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_t_2 = PyList_New(10); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 320, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_135374479);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_135374479);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 0, __pyx_mstate_global->__pyx_kp_u_135374479) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_23550891);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_23550891);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 1, __pyx_mstate_global->__pyx_kp_u_23550891) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_159507224);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_159507224);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 2, __pyx_mstate_global->__pyx_kp_u_159507224) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_67467545);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_67467545);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 3, __pyx_mstate_global->__pyx_kp_u_67467545) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_135374479);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_135374479);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 4, __pyx_mstate_global->__pyx_kp_u_135374479) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_16048044);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_16048044);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 5, __pyx_mstate_global->__pyx_kp_u_16048044) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_159507260);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_159507260);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 6, __pyx_mstate_global->__pyx_kp_u_159507260) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_169378254);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_169378254);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 7, __pyx_mstate_global->__pyx_kp_u_169378254) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_182747440);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_182747440);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 8, __pyx_mstate_global->__pyx_kp_u_182747440) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_588686349);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_588686349);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 9, __pyx_mstate_global->__pyx_kp_u_588686349) != (0)) __PYX_ERR(0, 320, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_3))) {
    __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_3);
    assert(__pyx_t_5);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_3);
    __Pyx_INCREF(__pyx_t_5);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_3, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_t_2};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_3, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 320, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_fbbv = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_3 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 321, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 321, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_t_2 = PyList_New(9); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 321, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_7_1_2);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_7_1_2);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 0, __pyx_mstate_global->__pyx_kp_u_7_1_2) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_8_1_0);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_8_1_0);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 1, __pyx_mstate_global->__pyx_kp_u_8_1_0) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_9);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_9);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 2, __pyx_mstate_global->__pyx_kp_u_9) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_10);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_10);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 3, __pyx_mstate_global->__pyx_kp_u_10) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_11);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_11);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 4, __pyx_mstate_global->__pyx_kp_u_11) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_12);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_12);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 5, __pyx_mstate_global->__pyx_kp_u_12) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_13);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_13);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 6, __pyx_mstate_global->__pyx_kp_u_13) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_14);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_14);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 7, __pyx_mstate_global->__pyx_kp_u_14) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __Pyx_INCREF(__pyx_mstate_global->__pyx_kp_u_15);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_kp_u_15);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_2, 8, __pyx_mstate_global->__pyx_kp_u_15) != (0)) __PYX_ERR(0, 321, __pyx_L1_error);
  __pyx_t_4 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_5))) {
    __pyx_t_3 = PyMethod_GET_SELF(__pyx_t_5);
    assert(__pyx_t_3);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
    __Pyx_INCREF(__pyx_t_3);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
    __pyx_t_4 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_t_2};
    __pyx_t_1 = __Pyx_PyObject_FastCall(__pyx_t_5, __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 321, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_fbs_v = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_merek, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 322, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_5 = __Pyx_PyObject_Call(__pyx_t_1, __pyx_mstate_global->__pyx_tuple[6], NULL); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 322, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 322, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  __pyx_t_5 = __Pyx_PyObject_Call(__pyx_t_1, __pyx_mstate_global->__pyx_tuple[7], NULL); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 322, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_v_merek1 = __pyx_t_5;
  __pyx_t_5 = 0;

  
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_v_merek1, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __pyx_t_1 = __Pyx_PyObject_Call(__pyx_t_5, __pyx_mstate_global->__pyx_tuple[8], NULL); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_t_1 = __Pyx_PyObject_Call(__pyx_t_5, __pyx_mstate_global->__pyx_tuple[9], NULL); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_t_1 = __Pyx_PyObject_Call(__pyx_t_5, __pyx_mstate_global->__pyx_tuple[10], NULL); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_t_1 = __Pyx_PyObject_Call(__pyx_t_5, __pyx_mstate_global->__pyx_tuple[11], NULL); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  __pyx_v_hasil = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_5 = PyObject_RichCompare(__pyx_v_hasil, __pyx_v_merek1, Py_NE); __Pyx_XGOTREF(__pyx_t_5); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 324, __pyx_L1_error)
  __pyx_t_6 = __Pyx_PyObject_IsTrue(__pyx_t_5); if (unlikely((__pyx_t_6 < 0))) __PYX_ERR(0, 324, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
  if (__pyx_t_6) {
    __Pyx_INCREF(__pyx_v_hasil);
    __pyx_t_1 = __pyx_v_hasil;
  } else {
    __Pyx_INCREF(__pyx_v_ceri);
    __pyx_t_1 = __pyx_v_ceri;
  }
  __pyx_v_cari = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_6 = __Pyx_PyObject_IsTrue(__pyx_v_build); if (unlikely((__pyx_t_6 < 0))) __PYX_ERR(0, 325, __pyx_L1_error)
  if (__pyx_t_6) {

    
    __pyx_t_1 = __Pyx_PyObject_FormatSimple(__pyx_v_model, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 326, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __pyx_t_5 = __Pyx_PyObject_FormatSimple(__pyx_v_build, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 326, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
    __pyx_t_7[0] = __pyx_t_1;
    __pyx_t_7[1] = __pyx_mstate_global->__pyx_kp_u_Build;
    __pyx_t_7[2] = __pyx_t_5;
    __pyx_t_2 = __Pyx_PyUnicode_Join(__pyx_t_7, 3, __Pyx_PyUnicode_GET_LENGTH(__pyx_t_1) + 7 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_5), 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_1) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_5));
    if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 326, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    __pyx_v_model_in_build = __pyx_t_2;
    __pyx_t_2 = 0;

    
    __pyx_t_8 = __Pyx_PyObject_IsTrue(__pyx_v_has_wv); if (unlikely((__pyx_t_8 < 0))) __PYX_ERR(0, 327, __pyx_L1_error)
    if (__pyx_t_8) {
    } else {
      __pyx_t_6 = __pyx_t_8;
      goto __pyx_L5_bool_binop_done;
    }
    __pyx_t_5 = __pyx_v_model_in_build;
    __Pyx_INCREF(__pyx_t_5);
    __pyx_t_4 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_5, NULL};
      __pyx_t_2 = __Pyx_PyObject_FastCallMethod(__pyx_mstate_global->__pyx_n_u_lower, __pyx_callargs+__pyx_t_4, (1-__pyx_t_4) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 327, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_2);
    }
    __pyx_t_8 = (__Pyx_PySequence_ContainsTF(__pyx_mstate_global->__pyx_n_u_wv, __pyx_t_2, Py_NE)); if (unlikely((__pyx_t_8 < 0))) __PYX_ERR(0, 327, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_6 = __pyx_t_8;
    __pyx_L5_bool_binop_done:;
    if (__pyx_t_6) {

      
      __pyx_t_2 = __Pyx_PyObject_FormatSimple(__pyx_v_model_in_build, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 328, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_2);
      __pyx_t_5 = __Pyx_PyUnicode_ConcatInPlace(__pyx_t_2, __pyx_mstate_global->__pyx_kp_u_wv_2); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 328, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
      __Pyx_DECREF_SET(__pyx_v_model_in_build, __pyx_t_5);
      __pyx_t_5 = 0;

      
    }

    
    goto __pyx_L3;
  }

  
   {
    __Pyx_INCREF(__pyx_v_model);
    __pyx_v_model_in_build = __pyx_v_model;

    
    __pyx_t_6 = __Pyx_PyObject_IsTrue(__pyx_v_has_wv); if (unlikely((__pyx_t_6 < 0))) __PYX_ERR(0, 331, __pyx_L1_error)
    if (__pyx_t_6) {

      
      __pyx_t_5 = __Pyx_PyObject_FormatSimple(__pyx_v_model_in_build, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 332, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __pyx_t_2 = __Pyx_PyUnicode_ConcatInPlace(__pyx_t_5, __pyx_mstate_global->__pyx_kp_u_wv_2); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 332, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_2);
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __Pyx_DECREF_SET(__pyx_v_model_in_build, __pyx_t_2);
      __pyx_t_2 = 0;

      
    }
  }
  __pyx_L3:;

  
  __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_v_model_in_build, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 333, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_5 = __Pyx_PyObject_Call(__pyx_t_2, __pyx_mstate_global->__pyx_tuple[12], NULL); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 333, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_v_model_in_build2 = __pyx_t_5;
  __pyx_t_5 = 0;

  
  __pyx_t_6 = (__Pyx_PyUnicode_Equals(__pyx_v_pilihanku, __pyx_mstate_global->__pyx_n_u_mode_satu, Py_EQ)); if (unlikely((__pyx_t_6 < 0))) __PYX_ERR(0, 334, __pyx_L1_error)
  if (__pyx_t_6) {

    
    __pyx_t_5 = __Pyx_PyObject_FormatSimple(__pyx_v_fbav, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 336, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);

    
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 337, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 337, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_2 = __Pyx_PyObject_CallOneArg(__pyx_t_1, __pyx_v_locales); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 337, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __pyx_t_1 = __Pyx_PyObject_FormatSimple(__pyx_t_2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 337, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_2 = __Pyx_PyObject_FormatSimple(__pyx_v_fbbv, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 337, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_3 = __Pyx_PyObject_FormatSimple(__pyx_v_cari, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 337, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);

    
    __pyx_t_9 = __Pyx_PyObject_FormatSimple(__pyx_v_merek1, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_9)) __PYX_ERR(0, 338, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_9);
    __pyx_t_10 = __Pyx_PyObject_FormatSimple(__pyx_v_merek, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 338, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_11 = __Pyx_PyObject_FormatSimple(__pyx_v_model, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 338, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __pyx_t_12 = __Pyx_PyObject_FormatSimple(__pyx_v_fbs_v, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 338, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);

    
    __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 339, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __pyx_t_14 = __Pyx_PyObject_GetAttrStr(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 339, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_14);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __pyx_t_13 = __Pyx_PyObject_CallOneArg(__pyx_t_14, __pyx_v_architectures); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 339, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
    __pyx_t_14 = __Pyx_PyObject_FormatSimple(__pyx_t_13, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 339, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_14);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;

    
    __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __pyx_t_15 = __Pyx_PyObject_GetAttrStr(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_15);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __pyx_t_13 = __Pyx_PyObject_CallOneArg(__pyx_t_15, __pyx_v_densities); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
    __pyx_t_15 = __Pyx_PyObject_FormatSimple(__pyx_t_13, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_15);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __pyx_t_16 = __Pyx_PyObject_GetAttrStr(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_16)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_16);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __pyx_t_13 = __Pyx_PyObject_CallOneArg(__pyx_t_16, __pyx_v_widths); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __Pyx_DECREF(__pyx_t_16); __pyx_t_16 = 0;
    __pyx_t_16 = __Pyx_PyObject_FormatSimple(__pyx_t_13, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_16)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_16);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_t_13, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_17);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __pyx_t_13 = __Pyx_PyObject_CallOneArg(__pyx_t_17, __pyx_v_heights); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
    __pyx_t_17 = __Pyx_PyObject_FormatSimple(__pyx_t_13, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 340, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_17);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __pyx_t_18[0] = __pyx_mstate_global->__pyx_kp_u_FBAN_Orca_Android_FBAV;
    __pyx_t_18[1] = __pyx_t_5;
    __pyx_t_18[2] = __pyx_mstate_global->__pyx_kp_u_FBPN_com_facebook_orca_FBLC;
    __pyx_t_18[3] = __pyx_t_1;
    __pyx_t_18[4] = __pyx_mstate_global->__pyx_kp_u_FBBV;
    __pyx_t_18[5] = __pyx_t_2;
    __pyx_t_18[6] = __pyx_mstate_global->__pyx_kp_u_FBCR;
    __pyx_t_18[7] = __pyx_t_3;
    __pyx_t_18[8] = __pyx_mstate_global->__pyx_kp_u_FBMF;
    __pyx_t_18[9] = __pyx_t_9;
    __pyx_t_18[10] = __pyx_mstate_global->__pyx_kp_u_FBBD;
    __pyx_t_18[11] = __pyx_t_10;
    __pyx_t_18[12] = __pyx_mstate_global->__pyx_kp_u_FBDV;
    __pyx_t_18[13] = __pyx_t_11;
    __pyx_t_18[14] = __pyx_mstate_global->__pyx_kp_u_FBSV;
    __pyx_t_18[15] = __pyx_t_12;
    __pyx_t_18[16] = __pyx_mstate_global->__pyx_kp_u_FBCA;
    __pyx_t_18[17] = __pyx_t_14;
    __pyx_t_18[18] = __pyx_mstate_global->__pyx_kp_u_FBDM_density;
    __pyx_t_18[19] = __pyx_t_15;
    __pyx_t_18[20] = __pyx_mstate_global->__pyx_kp_u_width_2;
    __pyx_t_18[21] = __pyx_t_16;
    __pyx_t_18[22] = __pyx_mstate_global->__pyx_kp_u_height_2;
    __pyx_t_18[23] = __pyx_t_17;
    __pyx_t_18[24] = __pyx_mstate_global->__pyx_kp_u_FB_FW_1;

    
    __pyx_t_13 = __Pyx_PyUnicode_Join(__pyx_t_18, 25, 24 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_5) + 29 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_1) + 6 * 7 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_2) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_3) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_9) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_10) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_11) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_12) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_14) + 15 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_15) + 7 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_16) + 8 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_17) + 11, 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_5) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_1) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_2) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_3) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_9) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_10) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_11) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_12) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_14) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_15) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_16) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_17));
    if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 336, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_9); __pyx_t_9 = 0;
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
    __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
    __Pyx_DECREF(__pyx_t_16); __pyx_t_16 = 0;
    __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
    __pyx_v_agen = ((PyObject*)__pyx_t_13);
    __pyx_t_13 = 0;

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_v_agen);
    __pyx_r = __pyx_v_agen;
    goto __pyx_L0;

    
  }

  
  __pyx_t_6 = (__Pyx_PyUnicode_Equals(__pyx_v_pilihanku, __pyx_mstate_global->__pyx_n_u_mode_dua, Py_EQ)); if (unlikely((__pyx_t_6 < 0))) __PYX_ERR(0, 343, __pyx_L1_error)
  if (__pyx_t_6) {

    
    __pyx_t_13 = __Pyx_PyObject_FormatSimple(__pyx_v_fbs_v, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 345, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_13);
    __pyx_t_17 = __Pyx_PyObject_FormatSimple(__pyx_v_model_in_build, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 345, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_17);

    
    __pyx_t_16 = __Pyx_PyObject_FormatSimple(__pyx_v_fbav, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_16)) __PYX_ERR(0, 346, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_16);

    
    __Pyx_GetModuleGlobalName(__pyx_t_15, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 347, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_15);
    __pyx_t_14 = __Pyx_PyObject_GetAttrStr(__pyx_t_15, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 347, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_14);
    __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
    __pyx_t_15 = __Pyx_PyObject_CallOneArg(__pyx_t_14, __pyx_v_locales); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 347, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_15);
    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
    __pyx_t_14 = __Pyx_PyObject_FormatSimple(__pyx_t_15, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 347, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_14);
    __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
    __pyx_t_15 = __Pyx_PyObject_FormatSimple(__pyx_v_fbbv, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 347, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_15);
    __pyx_t_12 = __Pyx_PyObject_FormatSimple(__pyx_v_cari, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 347, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);

    
    __pyx_t_11 = __Pyx_PyObject_FormatSimple(__pyx_v_merek1, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 348, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __pyx_t_10 = __Pyx_PyObject_FormatSimple(__pyx_v_merek, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 348, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_9 = __Pyx_PyObject_FormatSimple(__pyx_v_model, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_9)) __PYX_ERR(0, 348, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_9);
    __pyx_t_3 = __Pyx_PyObject_FormatSimple(__pyx_v_fbs_v, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 348, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);

    
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 349, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 349, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_2 = __Pyx_PyObject_CallOneArg(__pyx_t_1, __pyx_v_architectures); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 349, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __pyx_t_1 = __Pyx_PyObject_FormatSimple(__pyx_t_2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 349, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

    
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_2 = __Pyx_PyObject_CallOneArg(__pyx_t_5, __pyx_v_densities); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    __pyx_t_5 = __Pyx_PyObject_FormatSimple(__pyx_t_2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_19 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_19);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_2 = __Pyx_PyObject_CallOneArg(__pyx_t_19, __pyx_v_widths); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
    __pyx_t_19 = __Pyx_PyObject_FormatSimple(__pyx_t_2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_19);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_20);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_2 = __Pyx_PyObject_CallOneArg(__pyx_t_20, __pyx_v_heights); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
    __pyx_t_20 = __Pyx_PyObject_FormatSimple(__pyx_t_2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 350, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_20);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __pyx_t_21[0] = __pyx_mstate_global->__pyx_kp_u_Dalvik_2_1_0_Linux_U_Android;
    __pyx_t_21[1] = __pyx_t_13;
    __pyx_t_21[2] = __pyx_mstate_global->__pyx_kp_u__13;
    __pyx_t_21[3] = __pyx_t_17;
    __pyx_t_21[4] = __pyx_mstate_global->__pyx_kp_u_FBAN_Orca_Android_FBAV_2;
    __pyx_t_21[5] = __pyx_t_16;
    __pyx_t_21[6] = __pyx_mstate_global->__pyx_kp_u_FBPN_com_facebook_orca_FBLC;
    __pyx_t_21[7] = __pyx_t_14;
    __pyx_t_21[8] = __pyx_mstate_global->__pyx_kp_u_FBBV;
    __pyx_t_21[9] = __pyx_t_15;
    __pyx_t_21[10] = __pyx_mstate_global->__pyx_kp_u_FBCR;
    __pyx_t_21[11] = __pyx_t_12;
    __pyx_t_21[12] = __pyx_mstate_global->__pyx_kp_u_FBMF;
    __pyx_t_21[13] = __pyx_t_11;
    __pyx_t_21[14] = __pyx_mstate_global->__pyx_kp_u_FBBD;
    __pyx_t_21[15] = __pyx_t_10;
    __pyx_t_21[16] = __pyx_mstate_global->__pyx_kp_u_FBDV;
    __pyx_t_21[17] = __pyx_t_9;
    __pyx_t_21[18] = __pyx_mstate_global->__pyx_kp_u_FBSV;
    __pyx_t_21[19] = __pyx_t_3;
    __pyx_t_21[20] = __pyx_mstate_global->__pyx_kp_u_FBCA;
    __pyx_t_21[21] = __pyx_t_1;
    __pyx_t_21[22] = __pyx_mstate_global->__pyx_kp_u_FBDM_density;
    __pyx_t_21[23] = __pyx_t_5;
    __pyx_t_21[24] = __pyx_mstate_global->__pyx_kp_u_width_2;
    __pyx_t_21[25] = __pyx_t_19;
    __pyx_t_21[26] = __pyx_mstate_global->__pyx_kp_u_height_2;
    __pyx_t_21[27] = __pyx_t_20;
    __pyx_t_21[28] = __pyx_mstate_global->__pyx_kp_u_FB_FW_1;

    
    __pyx_t_2 = __Pyx_PyUnicode_Join(__pyx_t_21, 29, 32 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_13) + 2 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_17) + 26 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_16) + 29 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_14) + 6 * 7 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_15) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_12) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_11) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_10) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_9) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_3) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_1) + 15 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_5) + 7 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_19) + 8 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_20) + 11, 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_13) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_17) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_16) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_14) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_15) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_12) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_11) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_10) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_9) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_3) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_1) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_5) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_19) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_20));
    if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 345, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
    __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
    __Pyx_DECREF(__pyx_t_16); __pyx_t_16 = 0;
    __Pyx_DECREF(__pyx_t_14); __pyx_t_14 = 0;
    __Pyx_DECREF(__pyx_t_15); __pyx_t_15 = 0;
    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __Pyx_DECREF(__pyx_t_9); __pyx_t_9 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
    __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
    __pyx_v_agen = ((PyObject*)__pyx_t_2);
    __pyx_t_2 = 0;

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_v_agen);
    __pyx_r = __pyx_v_agen;
    goto __pyx_L0;

    
  }

  
  __pyx_t_6 = (__Pyx_PyUnicode_Equals(__pyx_v_pilihanku, __pyx_mstate_global->__pyx_n_u_mode_tiga, Py_EQ)); if (unlikely((__pyx_t_6 < 0))) __PYX_ERR(0, 353, __pyx_L1_error)
  if (__pyx_t_6) {

    
    __pyx_t_2 = __Pyx_PyObject_FormatSimple(__pyx_v_fbs_v, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_20 = __Pyx_PyObject_FormatSimple(__pyx_v_model_in_build2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_20);
    __pyx_t_19 = __Pyx_PyObject_FormatSimple(__pyx_v_fbs_v, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_19);
    __pyx_t_5 = __Pyx_PyObject_FormatSimple(__pyx_v_fbab, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
    __pyx_t_1 = __Pyx_PyObject_FormatSimple(__pyx_v_fbav2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __pyx_t_3 = __Pyx_PyObject_FormatSimple(__pyx_v_fbbv2, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);
    __pyx_t_9 = __Pyx_PyObject_FormatSimple(__pyx_v_fbvs, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_9)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_9);
    __Pyx_GetModuleGlobalName(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_random); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_11 = __Pyx_PyObject_GetAttrStr(__pyx_t_10, __pyx_mstate_global->__pyx_n_u_choice); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __pyx_t_10 = __Pyx_PyObject_CallOneArg(__pyx_t_11, __pyx_v_locales); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    __pyx_t_11 = __Pyx_PyObject_FormatSimple(__pyx_t_10, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __pyx_t_22[0] = __pyx_mstate_global->__pyx_kp_u_Dalvik_2_1_0_Linux_U_Android;
    __pyx_t_22[1] = __pyx_t_2;
    __pyx_t_22[2] = __pyx_mstate_global->__pyx_kp_u__13;
    __pyx_t_22[3] = __pyx_t_20;
    __pyx_t_22[4] = __pyx_mstate_global->__pyx_kp_u_FBAN_AudienceNetworkForAndroid;
    __pyx_t_22[5] = __pyx_t_19;
    __pyx_t_22[6] = __pyx_mstate_global->__pyx_kp_u_FBAB;
    __pyx_t_22[7] = __pyx_t_5;
    __pyx_t_22[8] = __pyx_mstate_global->__pyx_kp_u_FBAV;
    __pyx_t_22[9] = __pyx_t_1;
    __pyx_t_22[10] = __pyx_mstate_global->__pyx_kp_u_FBBV;
    __pyx_t_22[11] = __pyx_t_3;
    __pyx_t_22[12] = __pyx_mstate_global->__pyx_kp_u_FBVS;
    __pyx_t_22[13] = __pyx_t_9;
    __pyx_t_22[14] = __pyx_mstate_global->__pyx_kp_u_FBLC;
    __pyx_t_22[15] = __pyx_t_11;
    __pyx_t_22[16] = __pyx_mstate_global->__pyx_kp_u__14;
    __pyx_t_10 = __Pyx_PyUnicode_Join(__pyx_t_22, 17, 32 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_2) + 2 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_20) + 52 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_19) + 6 * 5 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_5) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_1) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_3) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_9) + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_11) + 1, 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_2) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_20) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_19) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_5) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_1) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_3) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_9) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_11));
    if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 355, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
    __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_9); __pyx_t_9 = 0;
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    __pyx_v_agen = ((PyObject*)__pyx_t_10);
    __pyx_t_10 = 0;

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_v_agen);
    __pyx_r = __pyx_v_agen;
    goto __pyx_L0;

    
  }

  
  __pyx_t_6 = (__Pyx_PyUnicode_Equals(__pyx_v_pilihanku, __pyx_mstate_global->__pyx_n_u_mode_empat, Py_EQ)); if (unlikely((__pyx_t_6 < 0))) __PYX_ERR(0, 358, __pyx_L1_error)
  if (__pyx_t_6) {

    
    __pyx_t_10 = __Pyx_PyObject_FormatSimple(__pyx_v_fbs_v, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 360, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_10);
    __pyx_t_11 = __Pyx_PyObject_FormatSimple(__pyx_v_model_in_build, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 360, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __pyx_t_23[0] = __pyx_mstate_global->__pyx_kp_u_Dalvik_2_1_0_Linux_U_Android;
    __pyx_t_23[1] = __pyx_t_10;
    __pyx_t_23[2] = __pyx_mstate_global->__pyx_kp_u__13;
    __pyx_t_23[3] = __pyx_t_11;
    __pyx_t_23[4] = __pyx_mstate_global->__pyx_kp_u__15;
    __pyx_t_9 = __Pyx_PyUnicode_Join(__pyx_t_23, 5, 32 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_10) + 2 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_11) + 1, 127 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_10) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_11));
    if (unlikely(!__pyx_t_9)) __PYX_ERR(0, 360, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_9);
    __Pyx_DECREF(__pyx_t_10); __pyx_t_10 = 0;
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    __pyx_v_agen = ((PyObject*)__pyx_t_9);
    __pyx_t_9 = 0;

    
    __Pyx_XDECREF(__pyx_r);
    __Pyx_INCREF(__pyx_v_agen);
    __pyx_r = __pyx_v_agen;
    goto __pyx_L0;

    
  }

  

  
  __pyx_r = Py_None; __Pyx_INCREF(Py_None);
  goto __pyx_L0;
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_9);
  __Pyx_XDECREF(__pyx_t_10);
  __Pyx_XDECREF(__pyx_t_11);
  __Pyx_XDECREF(__pyx_t_12);
  __Pyx_XDECREF(__pyx_t_13);
  __Pyx_XDECREF(__pyx_t_14);
  __Pyx_XDECREF(__pyx_t_15);
  __Pyx_XDECREF(__pyx_t_16);
  __Pyx_XDECREF(__pyx_t_17);
  __Pyx_XDECREF(__pyx_t_19);
  __Pyx_XDECREF(__pyx_t_20);
  __Pyx_AddTraceback("user_agent.pake_dalvik", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_locales);
  __Pyx_XDECREF(__pyx_v_architectures);
  __Pyx_XDECREF(__pyx_v_densities);
  __Pyx_XDECREF(__pyx_v_widths);
  __Pyx_XDECREF(__pyx_v_heights);
  __Pyx_XDECREF(__pyx_v_models);
  __Pyx_XDECREF(__pyx_v_info);
  __Pyx_XDECREF(__pyx_v_ceri);
  __Pyx_XDECREF(__pyx_v_fbav2);
  __Pyx_XDECREF(__pyx_v_fbbv2);
  __Pyx_XDECREF(__pyx_v_fbvs);
  __Pyx_XDECREF(__pyx_v_fbab);
  __Pyx_XDECREF(__pyx_v_model);
  __Pyx_XDECREF(__pyx_v_build);
  __Pyx_XDECREF(__pyx_v_has_wv);
  __Pyx_XDECREF(__pyx_v_merek);
  __Pyx_XDECREF(__pyx_v_fbav);
  __Pyx_XDECREF(__pyx_v_fbbv);
  __Pyx_XDECREF(__pyx_v_fbs_v);
  __Pyx_XDECREF(__pyx_v_merek1);
  __Pyx_XDECREF(__pyx_v_hasil);
  __Pyx_XDECREF(__pyx_v_cari);
  __Pyx_XDECREF(__pyx_v_model_in_build);
  __Pyx_XDECREF(__pyx_v_model_in_build2);
  __Pyx_XDECREF(__pyx_v_agen);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}


static PyMethodDef __pyx_methods[] = {
  {0, 0, 0, 0}
};

static CYTHON_SMALL_CODE int __Pyx_InitCachedBuiltins(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_InitCachedConstants(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_InitGlobals(void); 
static CYTHON_SMALL_CODE int __Pyx_InitConstants(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_global_init_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_variable_export_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_function_export_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_type_init_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_type_import_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_variable_import_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_function_import_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_CreateCodeObjects(__pyx_mstatetype *__pyx_mstate); 


static int __Pyx_modinit_global_init_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_global_init_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_variable_export_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_variable_export_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_function_export_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_function_export_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_type_init_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_type_init_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_type_import_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_type_import_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_variable_import_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_variable_import_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_function_import_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_function_import_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

#if CYTHON_PEP489_MULTI_PHASE_INIT
static PyObject* __pyx_pymod_create(PyObject *spec, PyModuleDef *def); 
static int __pyx_pymod_exec_user_agent(PyObject* module); 
static PyModuleDef_Slot __pyx_moduledef_slots[] = {
  {Py_mod_create, (void*)__pyx_pymod_create},
  {Py_mod_exec, (void*)__pyx_pymod_exec_user_agent},
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
  {Py_mod_gil, Py_MOD_GIL_USED},
  #endif
  #if PY_VERSION_HEX >= 0x030C0000 && CYTHON_USE_MODULE_STATE
  {Py_mod_multiple_interpreters, Py_MOD_MULTIPLE_INTERPRETERS_NOT_SUPPORTED},
  #endif
  {0, NULL}
};
#endif

#ifdef __cplusplus
namespace {
  struct PyModuleDef __pyx_moduledef =
  #else
  static struct PyModuleDef __pyx_moduledef =
  #endif
  {
      PyModuleDef_HEAD_INIT,
      "user_agent",
      0, 
    #if CYTHON_USE_MODULE_STATE
      sizeof(__pyx_mstatetype), 
    #else
      (CYTHON_PEP489_MULTI_PHASE_INIT) ? 0 : -1, 
    #endif
      __pyx_methods ,
    #if CYTHON_PEP489_MULTI_PHASE_INIT
      __pyx_moduledef_slots, 
    #else
      NULL, 
    #endif
    #if CYTHON_USE_MODULE_STATE
      __pyx_m_traverse, 
      __pyx_m_clear, 
      NULL 
    #else
      NULL, 
      NULL, 
      NULL 
    #endif
  };
  #ifdef __cplusplus
} 
#endif


#ifndef CYTHON_NO_PYINIT_EXPORT
  #define __Pyx_PyMODINIT_FUNC PyMODINIT_FUNC
#else
  #ifdef __cplusplus
  #define __Pyx_PyMODINIT_FUNC extern "C" PyObject *
  #else
  #define __Pyx_PyMODINIT_FUNC PyObject *
  #endif
#endif

__Pyx_PyMODINIT_FUNC PyInit_user_agent(void) CYTHON_SMALL_CODE; 
#if !defined(CYTHON_NO_PYINIT_EXPORT) && (defined(_WIN32) || defined(WIN32) || defined(MS_WINDOWS))
__Pyx_PyMODINIT_FUNC PyInit___init__(void) { return PyInit_user_agent(); }
#endif
__Pyx_PyMODINIT_FUNC PyInit_user_agent(void)
#if CYTHON_PEP489_MULTI_PHASE_INIT
{
  return PyModuleDef_Init(&__pyx_moduledef);
}

#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x03090000
static PY_INT64_T __Pyx_GetCurrentInterpreterId(void) {
    {
        PyObject *module = PyImport_ImportModule("_interpreters"); // 3.13+ I think
        if (!module) {
            PyErr_Clear(); // just try the 3.8-3.12 version
            module = PyImport_ImportModule("_xxsubinterpreters");
            if (!module) goto bad;
        }
        PyObject *current = PyObject_CallMethod(module, "get_current", NULL);
        Py_DECREF(module);
        if (!current) goto bad;
        if (PyTuple_Check(current)) {
            PyObject *new_current = PySequence_GetItem(current, 0);
            Py_DECREF(current);
            current = new_current;
            if (!new_current) goto bad;
        }
        long long as_c_int = PyLong_AsLongLong(current);
        Py_DECREF(current);
        return as_c_int;
    }
  bad:
    PySys_WriteStderr("__Pyx_GetCurrentInterpreterId failed. Try setting the C define CYTHON_PEP489_MULTI_PHASE_INIT=0\n");
    return -1;
}
#endif
#if !CYTHON_USE_MODULE_STATE
static CYTHON_SMALL_CODE int __Pyx_check_single_interpreter(void) {
    static PY_INT64_T main_interpreter_id = -1;
#if CYTHON_COMPILING_IN_GRAAL
    PY_INT64_T current_id = PyInterpreterState_GetIDFromThreadState(PyThreadState_Get());
#elif CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX >= 0x03090000
    PY_INT64_T current_id = PyInterpreterState_GetID(PyInterpreterState_Get());
#elif CYTHON_COMPILING_IN_LIMITED_API
    PY_INT64_T current_id = __Pyx_GetCurrentInterpreterId();
#else
    PY_INT64_T current_id = PyInterpreterState_GetID(PyThreadState_Get()->interp);
#endif
    if (unlikely(current_id == -1)) {
        return -1;
    }
    if (main_interpreter_id == -1) {
        main_interpreter_id = current_id;
        return 0;
    } else if (unlikely(main_interpreter_id != current_id)) {
        PyErr_SetString(
            PyExc_ImportError,
            "Interpreter change detected - this module can only be loaded into one interpreter per process.");
        return -1;
    }
    return 0;
}
#endif
static CYTHON_SMALL_CODE int __Pyx_copy_spec_to_module(PyObject *spec, PyObject *moddict, const char* from_name, const char* to_name, int allow_none)
{
    PyObject *value = PyObject_GetAttrString(spec, from_name);
    int result = 0;
    if (likely(value)) {
        if (allow_none || value != Py_None) {
            result = PyDict_SetItemString(moddict, to_name, value);
        }
        Py_DECREF(value);
    } else if (PyErr_ExceptionMatches(PyExc_AttributeError)) {
        PyErr_Clear();
    } else {
        result = -1;
    }
    return result;
}
static CYTHON_SMALL_CODE PyObject* __pyx_pymod_create(PyObject *spec, PyModuleDef *def) {
    PyObject *module = NULL, *moddict, *modname;
    CYTHON_UNUSED_VAR(def);
    #if !CYTHON_USE_MODULE_STATE
    if (__Pyx_check_single_interpreter())
        return NULL;
    #endif
    if (__pyx_m)
        return __Pyx_NewRef(__pyx_m);
    modname = PyObject_GetAttrString(spec, "name");
    if (unlikely(!modname)) goto bad;
    module = PyModule_NewObject(modname);
    Py_DECREF(modname);
    if (unlikely(!module)) goto bad;
    moddict = PyModule_GetDict(module);
    if (unlikely(!moddict)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "loader", "__loader__", 1) < 0)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "origin", "__file__", 1) < 0)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "parent", "__package__", 1) < 0)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "submodule_search_locations", "__path__", 0) < 0)) goto bad;
    return module;
bad:
    Py_XDECREF(module);
    return NULL;
}


static CYTHON_SMALL_CODE int __pyx_pymod_exec_user_agent(PyObject *__pyx_pyinit_module)
#endif
{
  int stringtab_initialized = 0;
  #if CYTHON_USE_MODULE_STATE
  int pystate_addmodule_run = 0;
  #endif
  __pyx_mstatetype *__pyx_mstate = NULL;
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  size_t __pyx_t_5;
  PyObject *__pyx_t_6[4];
  PyObject *__pyx_t_7[3];
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannyDeclarations
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  if (__pyx_m) {
    if (__pyx_m == __pyx_pyinit_module) return 0;
    PyErr_SetString(PyExc_RuntimeError, "Module 'user_agent' has already been imported. Re-initialisation is not supported.");
    return -1;
  }
  #else
  if (__pyx_m) return __Pyx_NewRef(__pyx_m);
  #endif
  
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  __pyx_t_1 = __pyx_pyinit_module;
  Py_INCREF(__pyx_t_1);
  #else
  __pyx_t_1 = PyModule_Create(&__pyx_moduledef); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  #if CYTHON_USE_MODULE_STATE
  {
    int add_module_result = __Pyx_State_AddModule(__pyx_t_1, &__pyx_moduledef);
    __pyx_t_1 = 0; 
    if (unlikely((add_module_result < 0))) __PYX_ERR(0, 1, __pyx_L1_error)
    pystate_addmodule_run = 1;
  }
  #else
  __pyx_m = __pyx_t_1;
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
  PyUnstable_Module_SetGIL(__pyx_m, Py_MOD_GIL_USED);
  #endif
  __pyx_mstate = __pyx_mstate_global;
  CYTHON_UNUSED_VAR(__pyx_t_1);
  __pyx_mstate->__pyx_d = PyModule_GetDict(__pyx_m); if (unlikely(!__pyx_mstate->__pyx_d)) __PYX_ERR(0, 1, __pyx_L1_error)
  Py_INCREF(__pyx_mstate->__pyx_d);
  __pyx_mstate->__pyx_b = __Pyx_PyImport_AddModuleRef(__Pyx_BUILTIN_MODULE_NAME); if (unlikely(!__pyx_mstate->__pyx_b)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_cython_runtime = __Pyx_PyImport_AddModuleRef("cython_runtime"); if (unlikely(!__pyx_mstate->__pyx_cython_runtime)) __PYX_ERR(0, 1, __pyx_L1_error)
  if (PyObject_SetAttrString(__pyx_m, "__builtins__", __pyx_mstate->__pyx_b) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  
  #if CYTHON_REFNANNY
__Pyx_RefNanny = __Pyx_RefNannyImportAPI("refnanny");
if (!__Pyx_RefNanny) {
  PyErr_Clear();
  __Pyx_RefNanny = __Pyx_RefNannyImportAPI("Cython.Runtime.refnanny");
  if (!__Pyx_RefNanny)
      Py_FatalError("failed to import 'refnanny' module");
}
#endif

__Pyx_RefNannySetupContext("PyInit_user_agent", 0);
  if (__Pyx_check_binary_version(__PYX_LIMITED_VERSION_HEX, __Pyx_get_runtime_version(), CYTHON_COMPILING_IN_LIMITED_API) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #ifdef __Pxy_PyFrame_Initialize_Offsets
  __Pxy_PyFrame_Initialize_Offsets();
  #endif
  __pyx_mstate->__pyx_empty_tuple = PyTuple_New(0); if (unlikely(!__pyx_mstate->__pyx_empty_tuple)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_empty_bytes = PyBytes_FromStringAndSize("", 0); if (unlikely(!__pyx_mstate->__pyx_empty_bytes)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_empty_unicode = PyUnicode_FromStringAndSize("", 0); if (unlikely(!__pyx_mstate->__pyx_empty_unicode)) __PYX_ERR(0, 1, __pyx_L1_error)
  
  if (__Pyx_InitConstants(__pyx_mstate) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  stringtab_initialized = 1;
  if (__Pyx_InitGlobals() < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #if 0 || defined(__Pyx_CyFunction_USED) || defined(__Pyx_FusedFunction_USED) || defined(__Pyx_Coroutine_USED) || defined(__Pyx_Generator_USED) || defined(__Pyx_AsyncGen_USED)
  if (__pyx_CommonTypesMetaclass_init(__pyx_m) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  #ifdef __Pyx_CyFunction_USED
  if (__pyx_CyFunction_init(__pyx_m) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  #ifdef __Pyx_FusedFunction_USED
  if (__pyx_FusedFunction_init(__pyx_m) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  #ifdef __Pyx_Coroutine_USED
  if (__pyx_Coroutine_init(__pyx_m) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  #ifdef __Pyx_Generator_USED
  if (__pyx_Generator_init(__pyx_m) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  #ifdef __Pyx_AsyncGen_USED
  if (__pyx_AsyncGen_init(__pyx_m) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  
  if (__pyx_module_is_main_user_agent) {
    if (PyObject_SetAttr(__pyx_m, __pyx_mstate_global->__pyx_n_u_name, __pyx_mstate_global->__pyx_n_u_main) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  }
  if (!CYTHON_PEP489_MULTI_PHASE_INIT) {
    if (unlikely((__Pyx_SetPackagePathFromImportLib(__pyx_mstate_global->__pyx_n_u_user_agent) < 0))) __PYX_ERR(0, 1, __pyx_L1_error)
  }
  {
    PyObject *modules = PyImport_GetModuleDict(); if (unlikely(!modules)) __PYX_ERR(0, 1, __pyx_L1_error)
    if (!PyDict_GetItemString(modules, "user_agent")) {
      if (unlikely((PyDict_SetItemString(modules, "user_agent", __pyx_m) < 0))) __PYX_ERR(0, 1, __pyx_L1_error)
    }
  }
  
  if (__Pyx_InitCachedBuiltins(__pyx_mstate) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  
  if (__Pyx_InitCachedConstants(__pyx_mstate) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  if (__Pyx_CreateCodeObjects(__pyx_mstate) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  
  (void)__Pyx_modinit_global_init_code(__pyx_mstate);
  (void)__Pyx_modinit_variable_export_code(__pyx_mstate);
  (void)__Pyx_modinit_function_export_code(__pyx_mstate);
  (void)__Pyx_modinit_type_init_code(__pyx_mstate);
  (void)__Pyx_modinit_type_import_code(__pyx_mstate);
  (void)__Pyx_modinit_variable_import_code(__pyx_mstate);
  (void)__Pyx_modinit_function_import_code(__pyx_mstate);
  

  
  __pyx_t_2 = __Pyx_ImportDottedModule(__pyx_mstate_global->__pyx_n_u_os, NULL); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 1, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_os, __pyx_t_2) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_ImportDottedModule(__pyx_mstate_global->__pyx_n_u_random, NULL); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 2, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_random, __pyx_t_2) < 0) __PYX_ERR(0, 2, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_ImportDottedModule(__pyx_mstate_global->__pyx_n_u_requests, NULL); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 3, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_requests, __pyx_t_2) < 0) __PYX_ERR(0, 3, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_ImportDottedModule(__pyx_mstate_global->__pyx_n_u_shutil, NULL); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 4, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_shutil, __pyx_t_2) < 0) __PYX_ERR(0, 4, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_PyList_Pack(1, __pyx_mstate_global->__pyx_n_u_BeautifulSoup); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 5, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_3 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_bs4, __pyx_t_2, 0); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 5, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_t_2 = __Pyx_ImportFrom(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_BeautifulSoup); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 5, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_BeautifulSoup, __pyx_t_2) < 0) __PYX_ERR(0, 5, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_PyList_Pack(1, __pyx_mstate_global->__pyx_n_u_Console); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 6, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_2 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_rich_console, __pyx_t_3, 0); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 6, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = __Pyx_ImportFrom(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_Console); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 6, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_Console, __pyx_t_3) < 0) __PYX_ERR(0, 6, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_PyList_Pack(1, __pyx_mstate_global->__pyx_n_u_Panel); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 7, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_3 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_rich_panel, __pyx_t_2, 0); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 7, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __pyx_t_2 = __Pyx_ImportFrom(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_Panel); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 7, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_Panel, __pyx_t_2) < 0) __PYX_ERR(0, 7, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_2 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_Console); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 9, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  __pyx_t_5 = 1;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, NULL};
    __pyx_t_3 = __Pyx_PyObject_FastCall(__pyx_t_4, __pyx_callargs+__pyx_t_5, (1-__pyx_t_5) | (__pyx_t_5*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 9, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_3);
  }
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_console, __pyx_t_3) < 0) __PYX_ERR(0, 9, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_gr, __pyx_mstate_global->__pyx_kp_u_1_32_41m) < 0) __PYX_ERR(0, 10, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_k, __pyx_mstate_global->__pyx_kp_u_33m) < 0) __PYX_ERR(0, 11, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_w, __pyx_mstate_global->__pyx_kp_u_1_37m) < 0) __PYX_ERR(0, 12, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_g, __pyx_mstate_global->__pyx_kp_u_1_32m) < 0) __PYX_ERR(0, 13, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_r, __pyx_mstate_global->__pyx_kp_u_1_31m) < 0) __PYX_ERR(0, 14, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_b, __pyx_mstate_global->__pyx_kp_u_1_34m) < 0) __PYX_ERR(0, 15, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_p, __pyx_mstate_global->__pyx_kp_u_1_35m) < 0) __PYX_ERR(0, 16, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_c, __pyx_mstate_global->__pyx_kp_u_1_36m) < 0) __PYX_ERR(0, 17, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_y, __pyx_mstate_global->__pyx_kp_u_1_33m) < 0) __PYX_ERR(0, 18, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_oren, __pyx_mstate_global->__pyx_kp_u_38_5_214m) < 0) __PYX_ERR(0, 19, __pyx_L1_error)

  
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_g); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 20, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_4 = __Pyx_PyObject_FormatSimple(__pyx_t_3, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 20, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_w); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 20, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_2 = __Pyx_PyObject_FormatSimple(__pyx_t_3, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 20, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_6[0] = __pyx_t_4;
  __pyx_t_6[1] = __pyx_mstate_global->__pyx_kp_u__17;
  __pyx_t_6[2] = __pyx_t_2;
  __pyx_t_6[3] = __pyx_mstate_global->__pyx_kp_u__3;
  __pyx_t_3 = __Pyx_PyUnicode_Join(__pyx_t_6, 4, __Pyx_PyUnicode_GET_LENGTH(__pyx_t_4) + 4 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_2) + 1, 65535 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_4) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_2));
  if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 20, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_pan, __pyx_t_3) < 0) __PYX_ERR(0, 20, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_reset, __pyx_mstate_global->__pyx_kp_u_0m) < 0) __PYX_ERR(0, 21, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_y2, __pyx_mstate_global->__pyx_kp_u_bold_yellow_2) < 0) __PYX_ERR(0, 22, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_w2, __pyx_mstate_global->__pyx_kp_u_bold_white) < 0) __PYX_ERR(0, 23, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_g2, __pyx_mstate_global->__pyx_kp_u_bold_green_2) < 0) __PYX_ERR(0, 24, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_r2, __pyx_mstate_global->__pyx_kp_u_bold_red) < 0) __PYX_ERR(0, 25, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_b2, __pyx_mstate_global->__pyx_kp_u_bold_blue) < 0) __PYX_ERR(0, 26, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_p2, __pyx_mstate_global->__pyx_kp_u_bold_magenta_2) < 0) __PYX_ERR(0, 27, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_c2, __pyx_mstate_global->__pyx_kp_u_bold_cyan) < 0) __PYX_ERR(0, 28, __pyx_L1_error)

  
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_reset2, __pyx_mstate_global->__pyx_kp_u__18) < 0) __PYX_ERR(0, 29, __pyx_L1_error)

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_1warna, 0, __pyx_mstate_global->__pyx_n_u_warna, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[0])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 30, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_warna, __pyx_t_3) < 0) __PYX_ERR(0, 30, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_3panelku, 0, __pyx_mstate_global->__pyx_n_u_panelku, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[1])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 42, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_CyFunction_SetDefaultsTuple(__pyx_t_3, __pyx_mstate_global->__pyx_tuple[13]);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_panelku, __pyx_t_3) < 0) __PYX_ERR(0, 42, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_5st, 0, __pyx_mstate_global->__pyx_n_u_st, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[2])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 62, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_st, __pyx_t_3) < 0) __PYX_ERR(0, 62, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_g); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 64, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_2 = __Pyx_PyObject_FormatSimple(__pyx_t_3, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 64, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_w); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 64, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_4 = __Pyx_PyObject_FormatSimple(__pyx_t_3, __pyx_mstate_global->__pyx_empty_unicode); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 64, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_7[0] = __pyx_t_2;
  __pyx_t_7[1] = __pyx_mstate_global->__pyx_kp_u__19;
  __pyx_t_7[2] = __pyx_t_4;
  __pyx_t_3 = __Pyx_PyUnicode_Join(__pyx_t_7, 3, __Pyx_PyUnicode_GET_LENGTH(__pyx_t_2) + 4 + __Pyx_PyUnicode_GET_LENGTH(__pyx_t_4), 65535 | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_2) | __Pyx_PyUnicode_MAX_CHAR_VALUE(__pyx_t_4));
  if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 64, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_tanda, __pyx_t_3) < 0) __PYX_ERR(0, 64, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_7pake_original, 0, __pyx_mstate_global->__pyx_n_u_pake_original, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[3])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 66, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_pake_original, __pyx_t_3) < 0) __PYX_ERR(0, 66, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_9create, 0, __pyx_mstate_global->__pyx_n_u_create, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[4])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 80, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_CyFunction_SetDefaultsTuple(__pyx_t_3, __pyx_mstate_global->__pyx_tuple[14]);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_create, __pyx_t_3) < 0) __PYX_ERR(0, 80, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_ImportDottedModule(__pyx_mstate_global->__pyx_n_u_re, NULL); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 181, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_re, __pyx_t_3) < 0) __PYX_ERR(0, 181, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = __Pyx_ImportDottedModule(__pyx_mstate_global->__pyx_n_u_random, NULL); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 181, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_random, __pyx_t_3) < 0) __PYX_ERR(0, 181, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_11_extract_model_from_parentheses, 0, __pyx_mstate_global->__pyx_n_u_extract_model_from_parentheses, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[5])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 182, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_extract_model_from_parentheses, __pyx_t_3) < 0) __PYX_ERR(0, 182, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_13load_models_from_user_file, 0, __pyx_mstate_global->__pyx_n_u_load_models_from_user_file, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[6])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 202, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __Pyx_CyFunction_SetDefaultsTuple(__pyx_t_3, __pyx_mstate_global->__pyx_tuple[15]);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_load_models_from_user_file, __pyx_t_3) < 0) __PYX_ERR(0, 202, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_15determine_merek_from_model, 0, __pyx_mstate_global->__pyx_n_u_determine_merek_from_model, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[7])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 230, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_determine_merek_from_model, __pyx_t_3) < 0) __PYX_ERR(0, 230, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_CyFunction_New(&__pyx_mdef_10user_agent_17pake_dalvik, 0, __pyx_mstate_global->__pyx_n_u_pake_dalvik, NULL, __pyx_mstate_global->__pyx_n_u_user_agent, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[8])); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 255, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_pake_dalvik, __pyx_t_3) < 0) __PYX_ERR(0, 255, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  
  __pyx_t_3 = __Pyx_PyDict_NewPresized(0); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 1, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_test, __pyx_t_3) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;

  

  goto __pyx_L0;
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_XDECREF(__pyx_t_4);
  if (__pyx_m) {
    if (__pyx_mstate->__pyx_d && stringtab_initialized) {
      __Pyx_AddTraceback("init user_agent", __pyx_clineno, __pyx_lineno, __pyx_filename);
    }
    #if !CYTHON_USE_MODULE_STATE
    Py_CLEAR(__pyx_m);
    #else
    Py_DECREF(__pyx_m);
    if (pystate_addmodule_run) {
      PyObject *tp, *value, *tb;
      PyErr_Fetch(&tp, &value, &tb);
      PyState_RemoveModule(&__pyx_moduledef);
      PyErr_Restore(tp, value, tb);
    }
    #endif
  } else if (!PyErr_Occurred()) {
    PyErr_SetString(PyExc_ImportError, "init user_agent");
  }
  __pyx_L0:;
  __Pyx_RefNannyFinishContext();
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  return (__pyx_m != NULL) ? 0 : -1;
  #else
  return __pyx_m;
  #endif
}


typedef struct {
    const char *s;
#if 165 <= 65535
    const unsigned short n;
#elif 165 / 2 < INT_MAX
    const unsigned int n;
#elif 165 / 2 < LONG_MAX
    const unsigned long n;
#else
    const Py_ssize_t n;
#endif
#if 1 <= 31
    const unsigned int encoding : 5;
#elif 1 <= 255
    const unsigned char encoding;
#elif 1 <= 65535
    const unsigned short encoding;
#else
    const Py_ssize_t encoding;
#endif
    const unsigned int is_unicode : 1;
    const unsigned int intern : 1;
} __Pyx_StringTabEntry;
static const char * const __pyx_string_tab_encodings[] = { 0 };
static const __Pyx_StringTabEntry __pyx_string_tab[] = {
  {__pyx_k_, sizeof(__pyx_k_), 0, 1, 0}, 
  {__pyx_k_0m, sizeof(__pyx_k_0m), 0, 1, 0}, 
  {__pyx_k_10, sizeof(__pyx_k_10), 0, 1, 0}, 
  {__pyx_k_1061021, sizeof(__pyx_k_1061021), 0, 1, 0}, 
  {__pyx_k_1080, sizeof(__pyx_k_1080), 0, 1, 0}, 
  {__pyx_k_10_03, sizeof(__pyx_k_10_03), 0, 1, 0}, 
  {__pyx_k_10_6_1a, sizeof(__pyx_k_10_6_1a), 0, 1, 0}, 
  {__pyx_k_11, sizeof(__pyx_k_11), 0, 1, 0}, 
  {__pyx_k_1184, sizeof(__pyx_k_1184), 0, 1, 0}, 
  {__pyx_k_12, sizeof(__pyx_k_12), 0, 1, 0}, 
  {__pyx_k_1280, sizeof(__pyx_k_1280), 0, 1, 0}, 
  {__pyx_k_13, sizeof(__pyx_k_13), 0, 1, 0}, 
  {__pyx_k_130_0_0_15_89, sizeof(__pyx_k_130_0_0_15_89), 0, 1, 0}, 
  {__pyx_k_135374479, sizeof(__pyx_k_135374479), 0, 1, 0}, 
  {__pyx_k_14, sizeof(__pyx_k_14), 0, 1, 0}, 
  {__pyx_k_1424, sizeof(__pyx_k_1424), 0, 1, 0}, 
  {__pyx_k_1440, sizeof(__pyx_k_1440), 0, 1, 0}, 
  {__pyx_k_15, sizeof(__pyx_k_15), 0, 1, 0}, 
  {__pyx_k_159507224, sizeof(__pyx_k_159507224), 0, 1, 0}, 
  {__pyx_k_159507260, sizeof(__pyx_k_159507260), 0, 1, 0}, 
  {__pyx_k_16048044, sizeof(__pyx_k_16048044), 0, 1, 0}, 
  {__pyx_k_169378254, sizeof(__pyx_k_169378254), 0, 1, 0}, 
  {__pyx_k_182747440, sizeof(__pyx_k_182747440), 0, 1, 0}, 
  {__pyx_k_1920, sizeof(__pyx_k_1920), 0, 1, 0}, 
  {__pyx_k_196_0_0_29_99, sizeof(__pyx_k_196_0_0_29_99), 0, 1, 0}, 
  {__pyx_k_1_31m, sizeof(__pyx_k_1_31m), 0, 1, 0}, 
  {__pyx_k_1_32_41m, sizeof(__pyx_k_1_32_41m), 0, 1, 0}, 
  {__pyx_k_1_32m, sizeof(__pyx_k_1_32m), 0, 1, 0}, 
  {__pyx_k_1_33m, sizeof(__pyx_k_1_33m), 0, 1, 0}, 
  {__pyx_k_1_34m, sizeof(__pyx_k_1_34m), 0, 1, 0}, 
  {__pyx_k_1_35m, sizeof(__pyx_k_1_35m), 0, 1, 0}, 
  {__pyx_k_1_36m, sizeof(__pyx_k_1_36m), 0, 1, 0}, 
  {__pyx_k_1_37m, sizeof(__pyx_k_1_37m), 0, 1, 0}, 
  {__pyx_k_1_5, sizeof(__pyx_k_1_5), 0, 1, 0}, 
  {__pyx_k_1_51_5103, sizeof(__pyx_k_1_51_5103), 0, 1, 0}, 
  {__pyx_k_1_78_7800, sizeof(__pyx_k_1_78_7800), 0, 1, 0}, 
  {__pyx_k_1_92_12, sizeof(__pyx_k_1_92_12), 0, 1, 0}, 
  {__pyx_k_2184025, sizeof(__pyx_k_2184025), 0, 1, 0}, 
  {__pyx_k_220_0_0_20_121, sizeof(__pyx_k_220_0_0_20_121), 0, 1, 0}, 
  {__pyx_k_230_0_0_12_117, sizeof(__pyx_k_230_0_0_12_117), 0, 1, 0}, 
  {__pyx_k_23550891, sizeof(__pyx_k_23550891), 0, 1, 0}, 
  {__pyx_k_241_0_0_17_116, sizeof(__pyx_k_241_0_0_17_116), 0, 1, 0}, 
  {__pyx_k_249010, sizeof(__pyx_k_249010), 0, 1, 0}, 
  {__pyx_k_2768, sizeof(__pyx_k_2768), 0, 1, 0}, 
  {__pyx_k_287, sizeof(__pyx_k_287), 0, 1, 0}, 
  {__pyx_k_290, sizeof(__pyx_k_290), 0, 1, 0}, 
  {__pyx_k_2_0, sizeof(__pyx_k_2_0), 0, 1, 0}, 
  {__pyx_k_2_5_38, sizeof(__pyx_k_2_5_38), 0, 1, 0}, 
  {__pyx_k_2_5_49, sizeof(__pyx_k_2_5_49), 0, 1, 0}, 
  {__pyx_k_2_87, sizeof(__pyx_k_2_87), 0, 1, 0}, 
  {__pyx_k_2_90, sizeof(__pyx_k_2_90), 0, 1, 0}, 
  {__pyx_k_304, sizeof(__pyx_k_304), 0, 1, 0}, 
  {__pyx_k_33m, sizeof(__pyx_k_33m), 0, 1, 0}, 
  {__pyx_k_38_5_214m, sizeof(__pyx_k_38_5_214m), 0, 1, 0}, 
  {__pyx_k_393, sizeof(__pyx_k_393), 0, 1, 0}, 
  {__pyx_k_3_0, sizeof(__pyx_k_3_0), 0, 1, 0}, 
  {__pyx_k_3_04, sizeof(__pyx_k_3_04), 0, 1, 0}, 
  {__pyx_k_44_0_0_8_52, sizeof(__pyx_k_44_0_0_8_52), 0, 1, 0}, 
  {__pyx_k_454_0_0_37_109, sizeof(__pyx_k_454_0_0_37_109), 0, 1, 0}, 
  {__pyx_k_4_0, sizeof(__pyx_k_4_0), 0, 1, 0}, 
  {__pyx_k_55042, sizeof(__pyx_k_55042), 0, 1, 0}, 
  {__pyx_k_588686349, sizeof(__pyx_k_588686349), 0, 1, 0}, 
  {__pyx_k_6200, sizeof(__pyx_k_6200), 0, 1, 0}, 
  {__pyx_k_6205, sizeof(__pyx_k_6205), 0, 1, 0}, 
  {__pyx_k_6206, sizeof(__pyx_k_6206), 0, 1, 0}, 
  {__pyx_k_6208, sizeof(__pyx_k_6208), 0, 1, 0}, 
  {__pyx_k_63_0_0_4382, sizeof(__pyx_k_63_0_0_4382), 0, 1, 0}, 
  {__pyx_k_67467545, sizeof(__pyx_k_67467545), 0, 1, 0}, 
  {__pyx_k_6_15_0, sizeof(__pyx_k_6_15_0), 0, 1, 0}, 
  {__pyx_k_6_16_0, sizeof(__pyx_k_6_16_0), 0, 1, 0}, 
  {__pyx_k_6_17_0, sizeof(__pyx_k_6_17_0), 0, 1, 0}, 
  {__pyx_k_6_18_0, sizeof(__pyx_k_6_18_0), 0, 1, 0}, 
  {__pyx_k_6_2_0, sizeof(__pyx_k_6_2_0), 0, 1, 0}, 
  {__pyx_k_6_2_4, sizeof(__pyx_k_6_2_4), 0, 1, 0}, 
  {__pyx_k_6_2_6, sizeof(__pyx_k_6_2_6), 0, 1, 0}, 
  {__pyx_k_6_2_8, sizeof(__pyx_k_6_2_8), 0, 1, 0}, 
  {__pyx_k_720, sizeof(__pyx_k_720), 0, 1, 0}, 
  {__pyx_k_77979, sizeof(__pyx_k_77979), 0, 1, 0}, 
  {__pyx_k_77985, sizeof(__pyx_k_77985), 0, 1, 0}, 
  {__pyx_k_7_1_2, sizeof(__pyx_k_7_1_2), 0, 1, 0}, 
  {__pyx_k_81003, sizeof(__pyx_k_81003), 0, 1, 0}, 
  {__pyx_k_8_1_0, sizeof(__pyx_k_8_1_0), 0, 1, 0}, 
  {__pyx_k_9, sizeof(__pyx_k_9), 0, 1, 0}, 
  {__pyx_k_9_0_10, sizeof(__pyx_k_9_0_10), 0, 1, 0}, 
  {__pyx_k_9_6_7_0214, sizeof(__pyx_k_9_6_7_0214), 0, 1, 0}, 
  {__pyx_k_9_79, sizeof(__pyx_k_9_79), 0, 1, 0}, 
  {__pyx_k_9_85, sizeof(__pyx_k_9_85), 0, 1, 0}, 
  {__pyx_k_AIS, sizeof(__pyx_k_AIS), 0, 1, 1}, 
  {__pyx_k_BASE_URL, sizeof(__pyx_k_BASE_URL), 0, 1, 1}, 
  {__pyx_k_BRAND_MAP, sizeof(__pyx_k_BRAND_MAP), 0, 1, 1}, 
  {__pyx_k_BeautifulSoup, sizeof(__pyx_k_BeautifulSoup), 0, 1, 1}, 
  {__pyx_k_Build, sizeof(__pyx_k_Build), 0, 1, 0}, 
  {__pyx_k_Build_s, sizeof(__pyx_k_Build_s), 0, 1, 0}, 
  {__pyx_k_Console, sizeof(__pyx_k_Console), 0, 1, 1}, 
  {__pyx_k_Dalvik_2_1_0_Linux_U_Android, sizeof(__pyx_k_Dalvik_2_1_0_Linux_U_Android), 0, 1, 0}, 
  {__pyx_k_FBAB, sizeof(__pyx_k_FBAB), 0, 1, 0}, 
  {__pyx_k_FBAN_AudienceNetworkForAndroid, sizeof(__pyx_k_FBAN_AudienceNetworkForAndroid), 0, 1, 0}, 
  {__pyx_k_FBAN_Orca_Android_FBAV, sizeof(__pyx_k_FBAN_Orca_Android_FBAV), 0, 1, 0}, 
  {__pyx_k_FBAN_Orca_Android_FBAV_2, sizeof(__pyx_k_FBAN_Orca_Android_FBAV_2), 0, 1, 0}, 
  {__pyx_k_FBAV, sizeof(__pyx_k_FBAV), 0, 1, 0}, 
  {__pyx_k_FBBD, sizeof(__pyx_k_FBBD), 0, 1, 0}, 
  {__pyx_k_FBBV, sizeof(__pyx_k_FBBV), 0, 1, 0}, 
  {__pyx_k_FBCA, sizeof(__pyx_k_FBCA), 0, 1, 0}, 
  {__pyx_k_FBCR, sizeof(__pyx_k_FBCR), 0, 1, 0}, 
  {__pyx_k_FBDM_density, sizeof(__pyx_k_FBDM_density), 0, 1, 0}, 
  {__pyx_k_FBDV, sizeof(__pyx_k_FBDV), 0, 1, 0}, 
  {__pyx_k_FBLC, sizeof(__pyx_k_FBLC), 0, 1, 0}, 
  {__pyx_k_FBMF, sizeof(__pyx_k_FBMF), 0, 1, 0}, 
  {__pyx_k_FBPN_com_facebook_orca_FBLC, sizeof(__pyx_k_FBPN_com_facebook_orca_FBLC), 0, 1, 0}, 
  {__pyx_k_FBSV, sizeof(__pyx_k_FBSV), 0, 1, 0}, 
  {__pyx_k_FBVS, sizeof(__pyx_k_FBVS), 0, 1, 0}, 
  {__pyx_k_FB_FW_1, sizeof(__pyx_k_FB_FW_1), 0, 1, 0}, 
  {__pyx_k_FileNotFoundError, sizeof(__pyx_k_FileNotFoundError), 0, 1, 1}, 
  {__pyx_k_File_kosong_atau_tidak_ada_User, sizeof(__pyx_k_File_kosong_atau_tidak_ada_User), 0, 1, 0}, 
  {__pyx_k_GT, sizeof(__pyx_k_GT), 0, 1, 0}, 
  {__pyx_k_Gagal_membaca_file, sizeof(__pyx_k_Gagal_membaca_file), 0, 1, 0}, 
  {__pyx_k_Gagal_memuat_halaman, sizeof(__pyx_k_Gagal_memuat_halaman), 0, 1, 0}, 
  {__pyx_k_Gunakan_salah_satu_dari, sizeof(__pyx_k_Gunakan_salah_satu_dari), 0, 1, 0}, 
  {__pyx_k_I, sizeof(__pyx_k_I), 0, 1, 1}, 
  {__pyx_k_IGNORECASE, sizeof(__pyx_k_IGNORECASE), 0, 1, 1}, 
  {__pyx_k_INFINIX, sizeof(__pyx_k_INFINIX), 0, 1, 1}, 
  {__pyx_k_Infinix, sizeof(__pyx_k_Infinix), 0, 1, 1}, 
  {__pyx_k_MI, sizeof(__pyx_k_MI), 0, 1, 1}, 
  {__pyx_k_MTN, sizeof(__pyx_k_MTN), 0, 1, 1}, 
  {__pyx_k_Mi, sizeof(__pyx_k_Mi), 0, 1, 1}, 
  {__pyx_k_Mozilla_5_0_Linux_Android_13_Inf, sizeof(__pyx_k_Mozilla_5_0_Linux_Android_13_Inf), 0, 1, 0}, 
  {__pyx_k_None, sizeof(__pyx_k_None), 0, 1, 0}, 
  {__pyx_k_PLAY, sizeof(__pyx_k_PLAY), 0, 1, 1}, 
  {__pyx_k_Panel, sizeof(__pyx_k_Panel), 0, 1, 1}, 
  {__pyx_k_RMX, sizeof(__pyx_k_RMX), 0, 1, 1}, 
  {__pyx_k_Redmi, sizeof(__pyx_k_Redmi), 0, 1, 1}, 
  {__pyx_k_RequestException, sizeof(__pyx_k_RequestException), 0, 1, 1}, 
  {__pyx_k_SM, sizeof(__pyx_k_SM), 0, 1, 0}, 
  {__pyx_k_Session, sizeof(__pyx_k_Session), 0, 1, 1}, 
  {__pyx_k_Stay_Home_Teletalk, sizeof(__pyx_k_Stay_Home_Teletalk), 0, 1, 0}, 
  {__pyx_k_TECNO, sizeof(__pyx_k_TECNO), 0, 1, 1}, 
  {__pyx_k_Tidak_ditemukan_device_untuk_br, sizeof(__pyx_k_Tidak_ditemukan_device_untuk_br), 0, 1, 0}, 
  {__pyx_k_USER_AGENT, sizeof(__pyx_k_USER_AGENT), 0, 1, 0}, 
  {__pyx_k_Xiaomi, sizeof(__pyx_k_Xiaomi), 0, 1, 1}, 
  {__pyx_k__10, sizeof(__pyx_k__10), 0, 1, 0}, 
  {__pyx_k__11, sizeof(__pyx_k__11), 0, 1, 0}, 
  {__pyx_k__12, sizeof(__pyx_k__12), 0, 1, 0}, 
  {__pyx_k__13, sizeof(__pyx_k__13), 0, 1, 0}, 
  {__pyx_k__14, sizeof(__pyx_k__14), 0, 1, 0}, 
  {__pyx_k__15, sizeof(__pyx_k__15), 0, 1, 0}, 
  {__pyx_k__16, sizeof(__pyx_k__16), 0, 1, 0}, 
  {__pyx_k__17, sizeof(__pyx_k__17), 0, 1, 0}, 
  {__pyx_k__18, sizeof(__pyx_k__18), 0, 1, 0}, 
  {__pyx_k__19, sizeof(__pyx_k__19), 0, 1, 0}, 
  {__pyx_k__2, sizeof(__pyx_k__2), 0, 1, 0}, 
  {__pyx_k__20, sizeof(__pyx_k__20), 0, 1, 0}, 
  {__pyx_k__21, sizeof(__pyx_k__21), 0, 1, 1}, 
  {__pyx_k__3, sizeof(__pyx_k__3), 0, 1, 0}, 
  {__pyx_k__4, sizeof(__pyx_k__4), 0, 1, 0}, 
  {__pyx_k__5, sizeof(__pyx_k__5), 0, 1, 0}, 
  {__pyx_k__6, sizeof(__pyx_k__6), 0, 1, 0}, 
  {__pyx_k__7, sizeof(__pyx_k__7), 0, 1, 0}, 
  {__pyx_k__8, sizeof(__pyx_k__8), 0, 1, 0}, 
  {__pyx_k__9, sizeof(__pyx_k__9), 0, 1, 0}, 
  {__pyx_k_a, sizeof(__pyx_k_a), 0, 1, 1}, 
  {__pyx_k_a9_advan, sizeof(__pyx_k_a9_advan), 0, 1, 0}, 
  {__pyx_k_a_z_2_a_z_2, sizeof(__pyx_k_a_z_2_a_z_2), 0, 1, 0}, 
  {__pyx_k_advan, sizeof(__pyx_k_advan), 0, 1, 1}, 
  {__pyx_k_agen, sizeof(__pyx_k_agen), 0, 1, 1}, 
  {__pyx_k_alias, sizeof(__pyx_k_alias), 0, 1, 1}, 
  {__pyx_k_android, sizeof(__pyx_k_android), 0, 1, 1}, 
  {__pyx_k_applewebkit_khtml_like_gecko, sizeof(__pyx_k_applewebkit_khtml_like_gecko), 0, 1, 0}, 
  {__pyx_k_architectures, sizeof(__pyx_k_architectures), 0, 1, 1}, 
  {__pyx_k_arm64_v8a, sizeof(__pyx_k_arm64_v8a), 0, 1, 0}, 
  {__pyx_k_armeabi_v7a_armeabi, sizeof(__pyx_k_armeabi_v7a_armeabi), 0, 1, 0}, 
  {__pyx_k_asyncio_coroutines, sizeof(__pyx_k_asyncio_coroutines), 0, 1, 1}, 
  {__pyx_k_b, sizeof(__pyx_k_b), 0, 1, 1}, 
  {__pyx_k_b2, sizeof(__pyx_k_b2), 0, 1, 1}, 
  {__pyx_k_bFlow_b, sizeof(__pyx_k_bFlow_b), 0, 1, 0}, 
  {__pyx_k_biru, sizeof(__pyx_k_biru), 0, 1, 1}, 
  {__pyx_k_blue, sizeof(__pyx_k_blue), 0, 1, 1}, 
  {__pyx_k_bold_blue, sizeof(__pyx_k_bold_blue), 0, 1, 0}, 
  {__pyx_k_bold_cyan, sizeof(__pyx_k_bold_cyan), 0, 1, 0}, 
  {__pyx_k_bold_green, sizeof(__pyx_k_bold_green), 0, 1, 0}, 
  {__pyx_k_bold_green_2, sizeof(__pyx_k_bold_green_2), 0, 1, 0}, 
  {__pyx_k_bold_magenta, sizeof(__pyx_k_bold_magenta), 0, 1, 0}, 
  {__pyx_k_bold_magenta_2, sizeof(__pyx_k_bold_magenta_2), 0, 1, 0}, 
  {__pyx_k_bold_red, sizeof(__pyx_k_bold_red), 0, 1, 0}, 
  {__pyx_k_bold_white, sizeof(__pyx_k_bold_white), 0, 1, 0}, 
  {__pyx_k_bold_yellow, sizeof(__pyx_k_bold_yellow), 0, 1, 0}, 
  {__pyx_k_bold_yellow_2, sizeof(__pyx_k_bold_yellow_2), 0, 1, 0}, 
  {__pyx_k_border_style, sizeof(__pyx_k_border_style), 0, 1, 1}, 
  {__pyx_k_br, sizeof(__pyx_k_br), 0, 1, 1}, 
  {__pyx_k_brand, sizeof(__pyx_k_brand), 0, 1, 0}, 
  {__pyx_k_brand_key, sizeof(__pyx_k_brand_key), 0, 1, 1}, 
  {__pyx_k_brand_path, sizeof(__pyx_k_brand_path), 0, 1, 1}, 
  {__pyx_k_brand_text, sizeof(__pyx_k_brand_text), 0, 1, 1}, 
  {__pyx_k_brand_url, sizeof(__pyx_k_brand_url), 0, 1, 1}, 
  {__pyx_k_bs4, sizeof(__pyx_k_bs4), 0, 1, 1}, 
  {__pyx_k_build, sizeof(__pyx_k_build), 0, 1, 1}, 
  {__pyx_k_build_match, sizeof(__pyx_k_build_match), 0, 1, 1}, 
  {__pyx_k_bwv_b, sizeof(__pyx_k_bwv_b), 0, 1, 0}, 
  {__pyx_k_c, sizeof(__pyx_k_c), 0, 1, 1}, 
  {__pyx_k_c2, sizeof(__pyx_k_c2), 0, 1, 1}, 
  {__pyx_k_cari, sizeof(__pyx_k_cari), 0, 1, 1}, 
  {__pyx_k_center, sizeof(__pyx_k_center), 0, 1, 1}, 
  {__pyx_k_ceri, sizeof(__pyx_k_ceri), 0, 1, 1}, 
  {__pyx_k_choice, sizeof(__pyx_k_choice), 0, 1, 1}, 
  {__pyx_k_cik, sizeof(__pyx_k_cik), 0, 1, 1}, 
  {__pyx_k_class, sizeof(__pyx_k_class), 0, 1, 1}, 
  {__pyx_k_cline_in_traceback, sizeof(__pyx_k_cline_in_traceback), 0, 1, 1}, 
  {__pyx_k_columns, sizeof(__pyx_k_columns), 0, 1, 1}, 
  {__pyx_k_com_ea_gp_nbamobile, sizeof(__pyx_k_com_ea_gp_nbamobile), 0, 1, 0}, 
  {__pyx_k_com_g5e_hiddencity_android, sizeof(__pyx_k_com_g5e_hiddencity_android), 0, 1, 0}, 
  {__pyx_k_com_g5e_sherlock_android, sizeof(__pyx_k_com_g5e_sherlock_android), 0, 1, 0}, 
  {__pyx_k_com_gameloft_android_ANMP_GloftD, sizeof(__pyx_k_com_gameloft_android_ANMP_GloftD), 0, 1, 0}, 
  {__pyx_k_com_grandegames_slots_dafu_casin, sizeof(__pyx_k_com_grandegames_slots_dafu_casin), 0, 1, 0}, 
  {__pyx_k_com_ikeyboard_theme_pink_rgb_hea, sizeof(__pyx_k_com_ikeyboard_theme_pink_rgb_hea), 0, 1, 0}, 
  {__pyx_k_com_ludia_dragons, sizeof(__pyx_k_com_ludia_dragons), 0, 1, 0}, 
  {__pyx_k_com_moonfrog_ludo_club, sizeof(__pyx_k_com_moonfrog_ludo_club), 0, 1, 0}, 
  {__pyx_k_com_teenpatti_hd_gold, sizeof(__pyx_k_com_teenpatti_hd_gold), 0, 1, 0}, 
  {__pyx_k_com_tongitsgo_play, sizeof(__pyx_k_com_tongitsgo_play), 0, 1, 0}, 
  {__pyx_k_console, sizeof(__pyx_k_console), 0, 1, 1}, 
  {__pyx_k_create, sizeof(__pyx_k_create), 0, 1, 1}, 
  {__pyx_k_cyan, sizeof(__pyx_k_cyan), 0, 1, 1}, 
  {__pyx_k_d_d, sizeof(__pyx_k_d_d), 0, 1, 0}, 
  {__pyx_k_densities, sizeof(__pyx_k_densities), 0, 1, 1}, 
  {__pyx_k_determine_merek_from_model, sizeof(__pyx_k_determine_merek_from_model), 0, 1, 1}, 
  {__pyx_k_device, sizeof(__pyx_k_device), 0, 1, 0}, 
  {__pyx_k_device_links, sizeof(__pyx_k_device_links), 0, 1, 1}, 
  {__pyx_k_device_url, sizeof(__pyx_k_device_url), 0, 1, 1}, 
  {__pyx_k_e, sizeof(__pyx_k_e), 0, 1, 1}, 
  {__pyx_k_en_GB, sizeof(__pyx_k_en_GB), 0, 1, 1}, 
  {__pyx_k_en_US, sizeof(__pyx_k_en_US), 0, 1, 1}, 
  {__pyx_k_encoding, sizeof(__pyx_k_encoding), 0, 1, 1}, 
  {__pyx_k_enter, sizeof(__pyx_k_enter), 0, 1, 1}, 
  {__pyx_k_errors, sizeof(__pyx_k_errors), 0, 1, 1}, 
  {__pyx_k_exit, sizeof(__pyx_k_exit), 0, 1, 1}, 
  {__pyx_k_extract_model_from_parentheses, sizeof(__pyx_k_extract_model_from_parentheses), 0, 1, 1}, 
  {__pyx_k_f, sizeof(__pyx_k_f), 0, 1, 1}, 
  {__pyx_k_fallback, sizeof(__pyx_k_fallback), 0, 1, 1}, 
  {__pyx_k_fbab, sizeof(__pyx_k_fbab), 0, 1, 1}, 
  {__pyx_k_fbav, sizeof(__pyx_k_fbav), 0, 1, 1}, 
  {__pyx_k_fbav2, sizeof(__pyx_k_fbav2), 0, 1, 1}, 
  {__pyx_k_fbbv, sizeof(__pyx_k_fbbv), 0, 1, 1}, 
  {__pyx_k_fbbv2, sizeof(__pyx_k_fbbv2), 0, 1, 1}, 
  {__pyx_k_fbs_v, sizeof(__pyx_k_fbs_v), 0, 1, 1}, 
  {__pyx_k_fbvs, sizeof(__pyx_k_fbvs), 0, 1, 1}, 
  {__pyx_k_find_all, sizeof(__pyx_k_find_all), 0, 1, 1}, 
  {__pyx_k_flags, sizeof(__pyx_k_flags), 0, 1, 1}, 
  {__pyx_k_fullmatch, sizeof(__pyx_k_fullmatch), 0, 1, 1}, 
  {__pyx_k_func, sizeof(__pyx_k_func), 0, 1, 1}, 
  {__pyx_k_g, sizeof(__pyx_k_g), 0, 1, 1}, 
  {__pyx_k_g2, sizeof(__pyx_k_g2), 0, 1, 1}, 
  {__pyx_k_get, sizeof(__pyx_k_get), 0, 1, 1}, 
  {__pyx_k_get_terminal_size, sizeof(__pyx_k_get_terminal_size), 0, 1, 1}, 
  {__pyx_k_get_text, sizeof(__pyx_k_get_text), 0, 1, 1}, 
  {__pyx_k_gr, sizeof(__pyx_k_gr), 0, 1, 1}, 
  {__pyx_k_group, sizeof(__pyx_k_group), 0, 1, 1}, 
  {__pyx_k_has_wv, sizeof(__pyx_k_has_wv), 0, 1, 1}, 
  {__pyx_k_hasil, sizeof(__pyx_k_hasil), 0, 1, 1}, 
  {__pyx_k_height, sizeof(__pyx_k_height), 0, 1, 1}, 
  {__pyx_k_height_2, sizeof(__pyx_k_height_2), 0, 1, 0}, 
  {__pyx_k_heights, sizeof(__pyx_k_heights), 0, 1, 1}, 
  {__pyx_k_hijau, sizeof(__pyx_k_hijau), 0, 1, 1}, 
  {__pyx_k_hitung, sizeof(__pyx_k_hitung), 0, 1, 1}, 
  {__pyx_k_href, sizeof(__pyx_k_href), 0, 1, 1}, 
  {__pyx_k_html_parser, sizeof(__pyx_k_html_parser), 0, 1, 0}, 
  {__pyx_k_https_whatmyuseragent_com, sizeof(__pyx_k_https_whatmyuseragent_com), 0, 1, 0}, 
  {__pyx_k_hu_huawei, sizeof(__pyx_k_hu_huawei), 0, 1, 0}, 
  {__pyx_k_huawei, sizeof(__pyx_k_huawei), 0, 1, 1}, 
  {__pyx_k_id_ID, sizeof(__pyx_k_id_ID), 0, 1, 1}, 
  {__pyx_k_if_infinix, sizeof(__pyx_k_if_infinix), 0, 1, 0}, 
  {__pyx_k_ignore, sizeof(__pyx_k_ignore), 0, 1, 1}, 
  {__pyx_k_infinix, sizeof(__pyx_k_infinix), 0, 1, 1}, 
  {__pyx_k_info, sizeof(__pyx_k_info), 0, 1, 1}, 
  {__pyx_k_initializing, sizeof(__pyx_k_initializing), 0, 1, 1}, 
  {__pyx_k_inside, sizeof(__pyx_k_inside), 0, 1, 1}, 
  {__pyx_k_is_coroutine, sizeof(__pyx_k_is_coroutine), 0, 1, 1}, 
  {__pyx_k_isi, sizeof(__pyx_k_isi), 0, 1, 1}, 
  {__pyx_k_item, sizeof(__pyx_k_item), 0, 1, 1}, 
  {__pyx_k_k, sizeof(__pyx_k_k), 0, 1, 1}, 
  {__pyx_k_kata, sizeof(__pyx_k_kata), 0, 1, 1}, 
  {__pyx_k_key, sizeof(__pyx_k_key), 0, 1, 1}, 
  {__pyx_k_keys, sizeof(__pyx_k_keys), 0, 1, 1}, 
  {__pyx_k_kuning, sizeof(__pyx_k_kuning), 0, 1, 1}, 
  {__pyx_k_label, sizeof(__pyx_k_label), 0, 1, 1}, 
  {__pyx_k_lebar, sizeof(__pyx_k_lebar), 0, 1, 1}, 
  {__pyx_k_lebar_terminal, sizeof(__pyx_k_lebar_terminal), 0, 1, 1}, 
  {__pyx_k_line, sizeof(__pyx_k_line), 0, 1, 1}, 
  {__pyx_k_lines, sizeof(__pyx_k_lines), 0, 1, 1}, 
  {__pyx_k_link, sizeof(__pyx_k_link), 0, 1, 1}, 
  {__pyx_k_load_models_from_user_file, sizeof(__pyx_k_load_models_from_user_file), 0, 1, 1}, 
  {__pyx_k_locales, sizeof(__pyx_k_locales), 0, 1, 1}, 
  {__pyx_k_lower, sizeof(__pyx_k_lower), 0, 1, 1}, 
  {__pyx_k_m, sizeof(__pyx_k_m), 0, 1, 1}, 
  {__pyx_k_m_paren, sizeof(__pyx_k_m_paren), 0, 1, 1}, 
  {__pyx_k_main, sizeof(__pyx_k_main), 0, 1, 1}, 
  {__pyx_k_merah, sizeof(__pyx_k_merah), 0, 1, 1}, 
  {__pyx_k_merek, sizeof(__pyx_k_merek), 0, 1, 1}, 
  {__pyx_k_merek1, sizeof(__pyx_k_merek1), 0, 1, 1}, 
  {__pyx_k_mode_dua, sizeof(__pyx_k_mode_dua), 0, 1, 1}, 
  {__pyx_k_mode_empat, sizeof(__pyx_k_mode_empat), 0, 1, 1}, 
  {__pyx_k_mode_satu, sizeof(__pyx_k_mode_satu), 0, 1, 1}, 
  {__pyx_k_mode_tiga, sizeof(__pyx_k_mode_tiga), 0, 1, 1}, 
  {__pyx_k_model, sizeof(__pyx_k_model), 0, 1, 1}, 
  {__pyx_k_model_in_build, sizeof(__pyx_k_model_in_build), 0, 1, 1}, 
  {__pyx_k_model_in_build2, sizeof(__pyx_k_model_in_build2), 0, 1, 1}, 
  {__pyx_k_models, sizeof(__pyx_k_models), 0, 1, 1}, 
  {__pyx_k_module, sizeof(__pyx_k_module), 0, 1, 1}, 
  {__pyx_k_motorola, sizeof(__pyx_k_motorola), 0, 1, 1}, 
  {__pyx_k_mr_motorola, sizeof(__pyx_k_mr_motorola), 0, 1, 0}, 
  {__pyx_k_nama, sizeof(__pyx_k_nama), 0, 1, 1}, 
  {__pyx_k_name, sizeof(__pyx_k_name), 0, 1, 1}, 
  {__pyx_k_null, sizeof(__pyx_k_null), 0, 1, 1}, 
  {__pyx_k_op_oppo, sizeof(__pyx_k_op_oppo), 0, 1, 0}, 
  {__pyx_k_open, sizeof(__pyx_k_open), 0, 1, 1}, 
  {__pyx_k_oppo, sizeof(__pyx_k_oppo), 0, 1, 1}, 
  {__pyx_k_oren, sizeof(__pyx_k_oren), 0, 1, 1}, 
  {__pyx_k_os, sizeof(__pyx_k_os), 0, 1, 1}, 
  {__pyx_k_p, sizeof(__pyx_k_p), 0, 1, 1}, 
  {__pyx_k_p2, sizeof(__pyx_k_p2), 0, 1, 1}, 
  {__pyx_k_pake_dalvik, sizeof(__pyx_k_pake_dalvik), 0, 1, 1}, 
  {__pyx_k_pake_original, sizeof(__pyx_k_pake_original), 0, 1, 1}, 
  {__pyx_k_pan, sizeof(__pyx_k_pan), 0, 1, 1}, 
  {__pyx_k_panel, sizeof(__pyx_k_panel), 0, 1, 1}, 
  {__pyx_k_panelku, sizeof(__pyx_k_panelku), 0, 1, 1}, 
  {__pyx_k_part, sizeof(__pyx_k_part), 0, 1, 1}, 
  {__pyx_k_parts, sizeof(__pyx_k_parts), 0, 1, 1}, 
  {__pyx_k_path, sizeof(__pyx_k_path), 0, 1, 1}, 
  {__pyx_k_pilihanku, sizeof(__pyx_k_pilihanku), 0, 1, 1}, 
  {__pyx_k_piro, sizeof(__pyx_k_piro), 0, 1, 1}, 
  {__pyx_k_pop, sizeof(__pyx_k_pop), 0, 1, 1}, 
  {__pyx_k_print, sizeof(__pyx_k_print), 0, 1, 1}, 
  {__pyx_k_putih, sizeof(__pyx_k_putih), 0, 1, 1}, 
  {__pyx_k_qualname, sizeof(__pyx_k_qualname), 0, 1, 1}, 
  {__pyx_k_r, sizeof(__pyx_k_r), 0, 1, 1}, 
  {__pyx_k_r2, sizeof(__pyx_k_r2), 0, 1, 1}, 
  {__pyx_k_raise_for_status, sizeof(__pyx_k_raise_for_status), 0, 1, 1}, 
  {__pyx_k_random, sizeof(__pyx_k_random), 0, 1, 1}, 
  {__pyx_k_range, sizeof(__pyx_k_range), 0, 1, 1}, 
  {__pyx_k_re, sizeof(__pyx_k_re), 0, 1, 1}, 
  {__pyx_k_re_realme, sizeof(__pyx_k_re_realme), 0, 1, 0}, 
  {__pyx_k_realme, sizeof(__pyx_k_realme), 0, 1, 1}, 
  {__pyx_k_red, sizeof(__pyx_k_red), 0, 1, 1}, 
  {__pyx_k_replace, sizeof(__pyx_k_replace), 0, 1, 1}, 
  {__pyx_k_requests, sizeof(__pyx_k_requests), 0, 1, 1}, 
  {__pyx_k_res_brand, sizeof(__pyx_k_res_brand), 0, 1, 1}, 
  {__pyx_k_res_dev, sizeof(__pyx_k_res_dev), 0, 1, 1}, 
  {__pyx_k_reset, sizeof(__pyx_k_reset), 0, 1, 1}, 
  {__pyx_k_reset2, sizeof(__pyx_k_reset2), 0, 1, 1}, 
  {__pyx_k_reversed, sizeof(__pyx_k_reversed), 0, 1, 1}, 
  {__pyx_k_rich_console, sizeof(__pyx_k_rich_console), 0, 1, 1}, 
  {__pyx_k_rich_panel, sizeof(__pyx_k_rich_panel), 0, 1, 1}, 
  {__pyx_k_rstrip, sizeof(__pyx_k_rstrip), 0, 1, 1}, 
  {__pyx_k_s, sizeof(__pyx_k_s), 0, 1, 0}, 
  {__pyx_k_s_2, sizeof(__pyx_k_s_2), 0, 1, 0}, 
  {__pyx_k_s_Build_b, sizeof(__pyx_k_s_Build_b), 0, 1, 0}, 
  {__pyx_k_sa_samsung, sizeof(__pyx_k_sa_samsung), 0, 1, 0}, 
  {__pyx_k_samsung, sizeof(__pyx_k_samsung), 0, 1, 1}, 
  {__pyx_k_search, sizeof(__pyx_k_search), 0, 1, 1}, 
  {__pyx_k_selected_brands, sizeof(__pyx_k_selected_brands), 0, 1, 1}, 
  {__pyx_k_session, sizeof(__pyx_k_session), 0, 1, 1}, 
  {__pyx_k_set_name, sizeof(__pyx_k_set_name), 0, 1, 1}, 
  {__pyx_k_shutil, sizeof(__pyx_k_shutil), 0, 1, 1}, 
  {__pyx_k_soup, sizeof(__pyx_k_soup), 0, 1, 1}, 
  {__pyx_k_soup_dev, sizeof(__pyx_k_soup_dev), 0, 1, 1}, 
  {__pyx_k_spec, sizeof(__pyx_k_spec), 0, 1, 1}, 
  {__pyx_k_split, sizeof(__pyx_k_split), 0, 1, 1}, 
  {__pyx_k_st, sizeof(__pyx_k_st), 0, 1, 1}, 
  {__pyx_k_strip, sizeof(__pyx_k_strip), 0, 1, 1}, 
  {__pyx_k_sub, sizeof(__pyx_k_sub), 0, 1, 1}, 
  {__pyx_k_tanda, sizeof(__pyx_k_tanda), 0, 1, 1}, 
  {__pyx_k_tb_tecno_mobile, sizeof(__pyx_k_tb_tecno_mobile), 0, 1, 0}, 
  {__pyx_k_td, sizeof(__pyx_k_td), 0, 1, 1}, 
  {__pyx_k_tecno, sizeof(__pyx_k_tecno), 0, 1, 1}, 
  {__pyx_k_test, sizeof(__pyx_k_test), 0, 1, 1}, 
  {__pyx_k_text, sizeof(__pyx_k_text), 0, 1, 1}, 
  {__pyx_k_text_inside, sizeof(__pyx_k_text_inside), 0, 1, 1}, 
  {__pyx_k_tidak_ada_dalam_daftar_device, sizeof(__pyx_k_tidak_ada_dalam_daftar_device), 0, 1, 0}, 
  {__pyx_k_tinggi, sizeof(__pyx_k_tinggi), 0, 1, 1}, 
  {__pyx_k_title, sizeof(__pyx_k_title), 0, 1, 1}, 
  {__pyx_k_title_align, sizeof(__pyx_k_title_align), 0, 1, 1}, 
  {__pyx_k_tokens, sizeof(__pyx_k_tokens), 0, 1, 1}, 
  {__pyx_k_u_wv, sizeof(__pyx_k_u_wv), 0, 1, 0}, 
  {__pyx_k_ua, sizeof(__pyx_k_ua), 0, 1, 1}, 
  {__pyx_k_uas, sizeof(__pyx_k_uas), 0, 1, 1}, 
  {__pyx_k_ungu, sizeof(__pyx_k_ungu), 0, 1, 1}, 
  {__pyx_k_uniq, sizeof(__pyx_k_uniq), 0, 1, 1}, 
  {__pyx_k_up, sizeof(__pyx_k_up), 0, 1, 1}, 
  {__pyx_k_upper, sizeof(__pyx_k_upper), 0, 1, 1}, 
  {__pyx_k_user_agent, sizeof(__pyx_k_user_agent), 0, 1, 1}, 
  {__pyx_k_user_agent_py, sizeof(__pyx_k_user_agent_py), 0, 1, 0}, 
  {__pyx_k_user_agents_list, sizeof(__pyx_k_user_agents_list), 0, 1, 1}, 
  {__pyx_k_user_txt, sizeof(__pyx_k_user_txt), 0, 1, 0}, 
  {__pyx_k_useragent, sizeof(__pyx_k_useragent), 0, 1, 1}, 
  {__pyx_k_utf_8, sizeof(__pyx_k_utf_8), 0, 1, 0}, 
  {__pyx_k_values, sizeof(__pyx_k_values), 0, 1, 1}, 
  {__pyx_k_vivo, sizeof(__pyx_k_vivo), 0, 1, 1}, 
  {__pyx_k_vv_vivo, sizeof(__pyx_k_vv_vivo), 0, 1, 0}, 
  {__pyx_k_w, sizeof(__pyx_k_w), 0, 1, 1}, 
  {__pyx_k_w2, sizeof(__pyx_k_w2), 0, 1, 1}, 
  {__pyx_k_warna, sizeof(__pyx_k_warna), 0, 1, 1}, 
  {__pyx_k_warna_dict, sizeof(__pyx_k_warna_dict), 0, 1, 1}, 
  {__pyx_k_werno, sizeof(__pyx_k_werno), 0, 1, 1}, 
  {__pyx_k_white, sizeof(__pyx_k_white), 0, 1, 1}, 
  {__pyx_k_width, sizeof(__pyx_k_width), 0, 1, 1}, 
  {__pyx_k_width_2, sizeof(__pyx_k_width_2), 0, 1, 0}, 
  {__pyx_k_widths, sizeof(__pyx_k_widths), 0, 1, 1}, 
  {__pyx_k_write, sizeof(__pyx_k_write), 0, 1, 1}, 
  {__pyx_k_wv, sizeof(__pyx_k_wv), 0, 1, 1}, 
  {__pyx_k_wv_2, sizeof(__pyx_k_wv_2), 0, 1, 0}, 
  {__pyx_k_xi_xiaomi, sizeof(__pyx_k_xi_xiaomi), 0, 1, 0}, 
  {__pyx_k_xiaomi, sizeof(__pyx_k_xiaomi), 0, 1, 1}, 
  {__pyx_k_y, sizeof(__pyx_k_y), 0, 1, 1}, 
  {__pyx_k_y2, sizeof(__pyx_k_y2), 0, 1, 1}, 
  {0, 0, 0, 0, 0}
};

static int __Pyx_InitStrings(__Pyx_StringTabEntry const *t, PyObject **target, const char* const* encoding_names);



static int __Pyx_InitCachedBuiltins(__pyx_mstatetype *__pyx_mstate) {
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __pyx_builtin_open = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_open); if (!__pyx_builtin_open) __PYX_ERR(0, 68, __pyx_L1_error)
  __pyx_builtin_print = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_print); if (!__pyx_builtin_print) __PYX_ERR(0, 72, __pyx_L1_error)
  __pyx_builtin_range = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_range); if (!__pyx_builtin_range) __PYX_ERR(0, 124, __pyx_L1_error)
  __pyx_builtin_reversed = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_reversed); if (!__pyx_builtin_reversed) __PYX_ERR(0, 184, __pyx_L1_error)
  __pyx_builtin_FileNotFoundError = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_FileNotFoundError); if (!__pyx_builtin_FileNotFoundError) __PYX_ERR(0, 222, __pyx_L1_error)
  return 0;
  __pyx_L1_error:;
  return -1;
}


static int __Pyx_InitCachedConstants(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_InitCachedConstants", 0);

  
  __pyx_mstate_global->__pyx_tuple[0] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_kp_u_user_txt, __pyx_mstate_global->__pyx_n_u_r); if (unlikely(!__pyx_mstate_global->__pyx_tuple[0])) __PYX_ERR(0, 68, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[0]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[0]);
  __pyx_mstate_global->__pyx_tuple[1] = PyTuple_Pack(3, Py_None, Py_None, Py_None); if (unlikely(!__pyx_mstate_global->__pyx_tuple[1])) __PYX_ERR(0, 68, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[1]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[1]);

  
  __pyx_mstate_global->__pyx_tuple[2] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_href, __pyx_mstate_global->__pyx_kp_u__7); if (unlikely(!__pyx_mstate_global->__pyx_tuple[2])) __PYX_ERR(0, 150, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[2]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[2]);

  
  __pyx_mstate_global->__pyx_tuple[3] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_kp_u_user_txt, __pyx_mstate_global->__pyx_n_u_w); if (unlikely(!__pyx_mstate_global->__pyx_tuple[3])) __PYX_ERR(0, 175, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[3]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[3]);

  
  __pyx_mstate_global->__pyx_tuple[4] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_build, __pyx_mstate_global->__pyx_kp_u__7); if (unlikely(!__pyx_mstate_global->__pyx_tuple[4])) __PYX_ERR(0, 316, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[4]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[4]);

  
  __pyx_mstate_global->__pyx_tuple[5] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_wv, Py_False); if (unlikely(!__pyx_mstate_global->__pyx_tuple[5])) __PYX_ERR(0, 317, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[5]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[5]);

  
  __pyx_mstate_global->__pyx_tuple[6] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_Infinix, __pyx_mstate_global->__pyx_n_u_INFINIX); if (unlikely(!__pyx_mstate_global->__pyx_tuple[6])) __PYX_ERR(0, 322, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[6]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[6]);
  __pyx_mstate_global->__pyx_tuple[7] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_xiaomi, __pyx_mstate_global->__pyx_n_u_Xiaomi); if (unlikely(!__pyx_mstate_global->__pyx_tuple[7])) __PYX_ERR(0, 322, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[7]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[7]);

  
  __pyx_mstate_global->__pyx_tuple[8] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_INFINIX, __pyx_mstate_global->__pyx_n_u_MTN); if (unlikely(!__pyx_mstate_global->__pyx_tuple[8])) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[8]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[8]);
  __pyx_mstate_global->__pyx_tuple[9] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_Xiaomi, __pyx_mstate_global->__pyx_n_u_PLAY); if (unlikely(!__pyx_mstate_global->__pyx_tuple[9])) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[9]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[9]);
  __pyx_mstate_global->__pyx_tuple[10] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_samsung, __pyx_mstate_global->__pyx_n_u_AIS); if (unlikely(!__pyx_mstate_global->__pyx_tuple[10])) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[10]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[10]);
  __pyx_mstate_global->__pyx_tuple[11] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_n_u_realme, __pyx_mstate_global->__pyx_n_u_null); if (unlikely(!__pyx_mstate_global->__pyx_tuple[11])) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[11]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[11]);

  
  __pyx_mstate_global->__pyx_tuple[12] = PyTuple_Pack(2, __pyx_mstate_global->__pyx_kp_u_wv_2, __pyx_mstate_global->__pyx_kp_u__7); if (unlikely(!__pyx_mstate_global->__pyx_tuple[12])) __PYX_ERR(0, 333, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[12]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[12]);

  
  __pyx_mstate_global->__pyx_tuple[13] = PyTuple_Pack(3, Py_None, Py_None, ((PyObject*)__pyx_mstate_global->__pyx_n_u_cyan)); if (unlikely(!__pyx_mstate_global->__pyx_tuple[13])) __PYX_ERR(0, 42, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[13]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[13]);

  
  __pyx_mstate_global->__pyx_tuple[14] = PyTuple_Pack(2, Py_None, ((PyObject*)__pyx_mstate_global->__pyx_kp_u_10)); if (unlikely(!__pyx_mstate_global->__pyx_tuple[14])) __PYX_ERR(0, 80, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[14]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[14]);

  
  __pyx_mstate_global->__pyx_tuple[15] = PyTuple_Pack(1, ((PyObject*)__pyx_mstate_global->__pyx_kp_u_user_txt)); if (unlikely(!__pyx_mstate_global->__pyx_tuple[15])) __PYX_ERR(0, 202, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[15]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[15]);
  __Pyx_RefNannyFinishContext();
  return 0;
  __pyx_L1_error:;
  __Pyx_RefNannyFinishContext();
  return -1;
}


static int __Pyx_InitConstants(__pyx_mstatetype *__pyx_mstate) {
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __pyx_mstate->__pyx_umethod_PyDict_Type_get.type = (PyObject*)&PyDict_Type;
  __pyx_mstate->__pyx_umethod_PyDict_Type_get.method_name = &__pyx_mstate->__pyx_n_u_get;
  __pyx_mstate->__pyx_umethod_PyDict_Type_keys.type = (PyObject*)&PyDict_Type;
  __pyx_mstate->__pyx_umethod_PyDict_Type_keys.method_name = &__pyx_mstate->__pyx_n_u_keys;
  __pyx_mstate->__pyx_umethod_PyDict_Type_pop.type = (PyObject*)&PyDict_Type;
  __pyx_mstate->__pyx_umethod_PyDict_Type_pop.method_name = &__pyx_mstate->__pyx_n_u_pop;
  __pyx_mstate->__pyx_umethod_PyDict_Type_values.type = (PyObject*)&PyDict_Type;
  __pyx_mstate->__pyx_umethod_PyDict_Type_values.method_name = &__pyx_mstate->__pyx_n_u_values;
  if (__Pyx_InitStrings(__pyx_string_tab, __pyx_mstate->__pyx_string_tab, __pyx_string_tab_encodings) < 0) __PYX_ERR(0, 1, __pyx_L1_error);
  __pyx_mstate->__pyx_int_0 = PyLong_FromLong(0); if (unlikely(!__pyx_mstate->__pyx_int_0)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_int_1 = PyLong_FromLong(1); if (unlikely(!__pyx_mstate->__pyx_int_1)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_int_4 = PyLong_FromLong(4); if (unlikely(!__pyx_mstate->__pyx_int_4)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_int_80 = PyLong_FromLong(80); if (unlikely(!__pyx_mstate->__pyx_int_80)) __PYX_ERR(0, 1, __pyx_L1_error)
  return 0;
  __pyx_L1_error:;
  return -1;
}

typedef struct {
    unsigned int argcount : 3;
    unsigned int num_posonly_args : 1;
    unsigned int num_kwonly_args : 1;
    unsigned int nlocals : 5;
    unsigned int flags : 10;
    unsigned int first_line : 8;
    unsigned int line_table_length : 15;
} __Pyx_PyCode_New_function_description;

static PyObject* __Pyx_PyCode_New(
        const __Pyx_PyCode_New_function_description descr,
        PyObject * const *varnames,
        PyObject *filename,
        PyObject *funcname,
        const char *line_table,
        PyObject *tuple_dedup_map
);


static int __Pyx_CreateCodeObjects(__pyx_mstatetype *__pyx_mstate) {
  PyObject* tuple_dedup_map = PyDict_New();
  if (unlikely(!tuple_dedup_map)) return -1;
  {
    const __Pyx_PyCode_New_function_description descr = {1, 0, 0, 2, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 30, 57};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_nama, __pyx_mstate->__pyx_n_u_warna_dict};
    __pyx_mstate_global->__pyx_codeobj_tab[0] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_warna, __pyx_k_T_fD, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[0])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {5, 0, 0, 7, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 42, 95};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_label, __pyx_mstate->__pyx_n_u_isi, __pyx_mstate->__pyx_n_u_lebar, __pyx_mstate->__pyx_n_u_tinggi, __pyx_mstate->__pyx_n_u_werno, __pyx_mstate->__pyx_n_u_lebar_terminal, __pyx_mstate->__pyx_n_u_panel};
    __pyx_mstate_global->__pyx_codeobj_tab[1] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_panelku, __pyx_k_M_vS_V_5Rq_Q_r_E_a_A_U_1_a_q_6, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[1])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {1, 0, 0, 1, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 62, 27};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_kata};
    __pyx_mstate_global->__pyx_codeobj_tab[2] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_st, __pyx_k_2T_V6_e7_a, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[2])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {0, 0, 0, 4, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 66, 97};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_f, __pyx_mstate->__pyx_n_u_lines, __pyx_mstate->__pyx_n_u_e, __pyx_mstate->__pyx_n_u_line};
    __pyx_mstate_global->__pyx_codeobj_tab[3] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_pake_original, __pyx_k_e9L_AT_s_hb_4vQ_4q_1_vWAQ_Q_Q_q, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[3])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {2, 0, 0, 29, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 80, 641};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_alias, __pyx_mstate->__pyx_n_u_cik, __pyx_mstate->__pyx_n_u_BASE_URL, __pyx_mstate->__pyx_n_u_BRAND_MAP, __pyx_mstate->__pyx_n_u_selected_brands, __pyx_mstate->__pyx_n_u_parts, __pyx_mstate->__pyx_n_u_br, __pyx_mstate->__pyx_n_u_brand_text, __pyx_mstate->__pyx_n_u_user_agents_list, __pyx_mstate->__pyx_n_u_piro, __pyx_mstate->__pyx_n_u_hitung, __pyx_mstate->__pyx_n_u_session, __pyx_mstate->__pyx_n_u__21, __pyx_mstate->__pyx_n_u_brand_key, __pyx_mstate->__pyx_n_u_brand_path, __pyx_mstate->__pyx_n_u_brand_url, __pyx_mstate->__pyx_n_u_res_brand, __pyx_mstate->__pyx_n_u_soup, __pyx_mstate->__pyx_n_u_device_links, __pyx_mstate->__pyx_n_u_device_url, __pyx_mstate->__pyx_n_u_res_dev, __pyx_mstate->__pyx_n_u_soup_dev, __pyx_mstate->__pyx_n_u_uas, __pyx_mstate->__pyx_n_u_ua, __pyx_mstate->__pyx_n_u_fallback, __pyx_mstate->__pyx_n_u_f, __pyx_mstate->__pyx_n_u_e, __pyx_mstate->__pyx_n_u_link, __pyx_mstate->__pyx_n_u_td};
    __pyx_mstate_global->__pyx_codeobj_tab[4] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_create, __pyx_k_q_q_A_1_1_a_q_V2V1A_F_6_s_Q_waq, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[4])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {1, 0, 0, 5, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 182, 195};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_text_inside, __pyx_mstate->__pyx_n_u_parts, __pyx_mstate->__pyx_n_u_part, __pyx_mstate->__pyx_n_u_p, __pyx_mstate->__pyx_n_u_p};
    __pyx_mstate_global->__pyx_codeobj_tab[5] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_extract_model_from_parentheses, __pyx_k_AQfCt5_6_s_6_A_BfA_CvRs_2V1_4q, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[5])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {1, 0, 0, 13, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 202, 291};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_path, __pyx_mstate->__pyx_n_u_models, __pyx_mstate->__pyx_n_u_f, __pyx_mstate->__pyx_n_u_line, __pyx_mstate->__pyx_n_u_m_paren, __pyx_mstate->__pyx_n_u_inside, __pyx_mstate->__pyx_n_u_model, __pyx_mstate->__pyx_n_u_build_match, __pyx_mstate->__pyx_n_u_build, __pyx_mstate->__pyx_n_u_has_wv, __pyx_mstate->__pyx_n_u_uniq, __pyx_mstate->__pyx_n_u_item, __pyx_mstate->__pyx_n_u_key};
    __pyx_mstate_global->__pyx_codeobj_tab[6] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_load_models_from_user_file, __pyx_k_q_Q_Yiwm1_G1_4A_4q_aq_7q_4q_axu, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[6])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {1, 0, 0, 5, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 230, 191};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_model, __pyx_mstate->__pyx_n_u_m, __pyx_mstate->__pyx_n_u_up, __pyx_mstate->__pyx_n_u_tokens, __pyx_mstate->__pyx_n_u_merek};
    __pyx_mstate_global->__pyx_codeobj_tab[7] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_determine_merek_from_model, __pyx_k_t1_q_V1_vS_3fCq_q_z_A_q_xs_q_uC, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[7])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {1, 0, 0, 26, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 255, 932};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_pilihanku, __pyx_mstate->__pyx_n_u_locales, __pyx_mstate->__pyx_n_u_architectures, __pyx_mstate->__pyx_n_u_densities, __pyx_mstate->__pyx_n_u_widths, __pyx_mstate->__pyx_n_u_heights, __pyx_mstate->__pyx_n_u_models, __pyx_mstate->__pyx_n_u_info, __pyx_mstate->__pyx_n_u_ceri, __pyx_mstate->__pyx_n_u_fbav2, __pyx_mstate->__pyx_n_u_fbbv2, __pyx_mstate->__pyx_n_u_fbvs, __pyx_mstate->__pyx_n_u_fbab, __pyx_mstate->__pyx_n_u_model, __pyx_mstate->__pyx_n_u_build, __pyx_mstate->__pyx_n_u_has_wv, __pyx_mstate->__pyx_n_u_merek, __pyx_mstate->__pyx_n_u_fbav, __pyx_mstate->__pyx_n_u_fbbv, __pyx_mstate->__pyx_n_u_fbs_v, __pyx_mstate->__pyx_n_u_merek1, __pyx_mstate->__pyx_n_u_hasil, __pyx_mstate->__pyx_n_u_cari, __pyx_mstate->__pyx_n_u_model_in_build, __pyx_mstate->__pyx_n_u_model_in_build2, __pyx_mstate->__pyx_n_u_agen};
    __pyx_mstate_global->__pyx_codeobj_tab[8] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_user_agent_py, __pyx_mstate->__pyx_n_u_pake_dalvik, __pyx_k_ay_A_A_wa_QhgXQ_axxxxq_q_6_6_0, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[8])) goto bad;
  }
  Py_DECREF(tuple_dedup_map);
  return 0;
  bad:
  Py_DECREF(tuple_dedup_map);
  return -1;
}


static int __Pyx_InitGlobals(void) {
  
  if (likely(__Pyx_init_co_variables() == 0)); else

if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  
  #if CYTHON_COMPILING_IN_LIMITED_API
{
    PyObject *typesModule=NULL;
    typesModule = PyImport_ImportModule("types");
    if (typesModule) {
        __pyx_mstate_global->__Pyx_CachedMethodType = PyObject_GetAttrString(typesModule, "MethodType");
        Py_DECREF(typesModule);
    }
} // error handling follows
#endif

if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  return 0;
  __pyx_L1_error:;
  return -1;
}




#ifdef _MSC_VER
#pragma warning( push )

#pragma warning( disable : 4127 )
#endif







#if CYTHON_REFNANNY
static __Pyx_RefNannyAPIStruct *__Pyx_RefNannyImportAPI(const char *modname) {
    PyObject *m = NULL, *p = NULL;
    void *r = NULL;
    m = PyImport_ImportModule(modname);
    if (!m) goto end;
    p = PyObject_GetAttrString(m, "RefNannyAPI");
    if (!p) goto end;
    r = PyLong_AsVoidPtr(p);
end:
    Py_XDECREF(p);
    Py_XDECREF(m);
    return (__Pyx_RefNannyAPIStruct *)r;
}
#endif


#if CYTHON_FAST_THREAD_STATE
static int __Pyx_PyErr_ExceptionMatchesTuple(PyObject *exc_type, PyObject *tuple) {
    Py_ssize_t i, n;
    n = PyTuple_GET_SIZE(tuple);
    for (i=0; i<n; i++) {
        if (exc_type == PyTuple_GET_ITEM(tuple, i)) return 1;
    }
    for (i=0; i<n; i++) {
        if (__Pyx_PyErr_GivenExceptionMatches(exc_type, PyTuple_GET_ITEM(tuple, i))) return 1;
    }
    return 0;
}
static CYTHON_INLINE int __Pyx_PyErr_ExceptionMatchesInState(PyThreadState* tstate, PyObject* err) {
    int result;
    PyObject *exc_type;
#if PY_VERSION_HEX >= 0x030C00A6
    PyObject *current_exception = tstate->current_exception;
    if (unlikely(!current_exception)) return 0;
    exc_type = (PyObject*) Py_TYPE(current_exception);
    if (exc_type == err) return 1;
#else
    exc_type = tstate->curexc_type;
    if (exc_type == err) return 1;
    if (unlikely(!exc_type)) return 0;
#endif
    #if CYTHON_AVOID_BORROWED_REFS
    Py_INCREF(exc_type);
    #endif
    if (unlikely(PyTuple_Check(err))) {
        result = __Pyx_PyErr_ExceptionMatchesTuple(exc_type, err);
    } else {
        result = __Pyx_PyErr_GivenExceptionMatches(exc_type, err);
    }
    #if CYTHON_AVOID_BORROWED_REFS
    Py_DECREF(exc_type);
    #endif
    return result;
}
#endif


#if CYTHON_FAST_THREAD_STATE
static CYTHON_INLINE void __Pyx_ErrRestoreInState(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb) {
#if PY_VERSION_HEX >= 0x030C00A6
    PyObject *tmp_value;
    assert(type == NULL || (value != NULL && type == (PyObject*) Py_TYPE(value)));
    if (value) {
        #if CYTHON_COMPILING_IN_CPYTHON
        if (unlikely(((PyBaseExceptionObject*) value)->traceback != tb))
        #endif
            PyException_SetTraceback(value, tb);
    }
    tmp_value = tstate->current_exception;
    tstate->current_exception = value;
    Py_XDECREF(tmp_value);
    Py_XDECREF(type);
    Py_XDECREF(tb);
#else
    PyObject *tmp_type, *tmp_value, *tmp_tb;
    tmp_type = tstate->curexc_type;
    tmp_value = tstate->curexc_value;
    tmp_tb = tstate->curexc_traceback;
    tstate->curexc_type = type;
    tstate->curexc_value = value;
    tstate->curexc_traceback = tb;
    Py_XDECREF(tmp_type);
    Py_XDECREF(tmp_value);
    Py_XDECREF(tmp_tb);
#endif
}
static CYTHON_INLINE void __Pyx_ErrFetchInState(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb) {
#if PY_VERSION_HEX >= 0x030C00A6
    PyObject* exc_value;
    exc_value = tstate->current_exception;
    tstate->current_exception = 0;
    *value = exc_value;
    *type = NULL;
    *tb = NULL;
    if (exc_value) {
        *type = (PyObject*) Py_TYPE(exc_value);
        Py_INCREF(*type);
        #if CYTHON_COMPILING_IN_CPYTHON
        *tb = ((PyBaseExceptionObject*) exc_value)->traceback;
        Py_XINCREF(*tb);
        #else
        *tb = PyException_GetTraceback(exc_value);
        #endif
    }
#else
    *type = tstate->curexc_type;
    *value = tstate->curexc_value;
    *tb = tstate->curexc_traceback;
    tstate->curexc_type = 0;
    tstate->curexc_value = 0;
    tstate->curexc_traceback = 0;
#endif
}
#endif


#if CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStr(PyObject* obj, PyObject* attr_name) {
    PyTypeObject* tp = Py_TYPE(obj);
    if (likely(tp->tp_getattro))
        return tp->tp_getattro(obj, attr_name);
    return PyObject_GetAttr(obj, attr_name);
}
#endif


#if __PYX_LIMITED_VERSION_HEX < 0x030d0000
static void __Pyx_PyObject_GetAttrStr_ClearAttributeError(void) {
    __Pyx_PyThreadState_declare
    __Pyx_PyThreadState_assign
    if (likely(__Pyx_PyErr_ExceptionMatches(PyExc_AttributeError)))
        __Pyx_PyErr_Clear();
}
#endif
static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStrNoError(PyObject* obj, PyObject* attr_name) {
    PyObject *result;
#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
    (void) PyObject_GetOptionalAttr(obj, attr_name, &result);
    return result;
#else
#if CYTHON_COMPILING_IN_CPYTHON && CYTHON_USE_TYPE_SLOTS
    PyTypeObject* tp = Py_TYPE(obj);
    if (likely(tp->tp_getattro == PyObject_GenericGetAttr)) {
        return _PyObject_GenericGetAttrWithDict(obj, attr_name, NULL, 1);
    }
#endif
    result = __Pyx_PyObject_GetAttrStr(obj, attr_name);
    if (unlikely(!result)) {
        __Pyx_PyObject_GetAttrStr_ClearAttributeError();
    }
    return result;
#endif
}


static PyObject *__Pyx_GetBuiltinName(PyObject *name) {
    PyObject* result = __Pyx_PyObject_GetAttrStrNoError(__pyx_mstate_global->__pyx_b, name);
    if (unlikely(!result) && !PyErr_Occurred()) {
        PyErr_Format(PyExc_NameError,
            "name '%U' is not defined", name);
    }
    return result;
}


#if !CYTHON_COMPILING_IN_CPYTHON && CYTHON_METH_FASTCALL
static CYTHON_INLINE PyObject *
__Pyx_PyTuple_FromArray(PyObject *const *src, Py_ssize_t n)
{
    PyObject *res;
    Py_ssize_t i;
    if (n <= 0) {
        return __Pyx_NewRef(__pyx_mstate_global->__pyx_empty_tuple);
    }
    res = PyTuple_New(n);
    if (unlikely(res == NULL)) return NULL;
    for (i = 0; i < n; i++) {
        if (unlikely(__Pyx_PyTuple_SET_ITEM(res, i, src[i]) < 0)) {
            Py_DECREF(res);
            return NULL;
        }
        Py_INCREF(src[i]);
    }
    return res;
}
#elif CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE void __Pyx_copy_object_array(PyObject *const *CYTHON_RESTRICT src, PyObject** CYTHON_RESTRICT dest, Py_ssize_t length) {
    PyObject *v;
    Py_ssize_t i;
    for (i = 0; i < length; i++) {
        v = dest[i] = src[i];
        Py_INCREF(v);
    }
}
static CYTHON_INLINE PyObject *
__Pyx_PyTuple_FromArray(PyObject *const *src, Py_ssize_t n)
{
    PyObject *res;
    if (n <= 0) {
        return __Pyx_NewRef(__pyx_mstate_global->__pyx_empty_tuple);
    }
    res = PyTuple_New(n);
    if (unlikely(res == NULL)) return NULL;
    __Pyx_copy_object_array(src, ((PyTupleObject*)res)->ob_item, n);
    return res;
}
static CYTHON_INLINE PyObject *
__Pyx_PyList_FromArray(PyObject *const *src, Py_ssize_t n)
{
    PyObject *res;
    if (n <= 0) {
        return PyList_New(0);
    }
    res = PyList_New(n);
    if (unlikely(res == NULL)) return NULL;
    __Pyx_copy_object_array(src, ((PyListObject*)res)->ob_item, n);
    return res;
}
#endif


static CYTHON_INLINE int __Pyx_PyBytes_Equals(PyObject* s1, PyObject* s2, int equals) {
#if CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_GRAAL ||\
        !(CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS)
    return PyObject_RichCompareBool(s1, s2, equals);
#else
    if (s1 == s2) {
        return (equals == Py_EQ);
    } else if (PyBytes_CheckExact(s1) & PyBytes_CheckExact(s2)) {
        const char *ps1, *ps2;
        Py_ssize_t length = PyBytes_GET_SIZE(s1);
        if (length != PyBytes_GET_SIZE(s2))
            return (equals == Py_NE);
        ps1 = PyBytes_AS_STRING(s1);
        ps2 = PyBytes_AS_STRING(s2);
        if (ps1[0] != ps2[0]) {
            return (equals == Py_NE);
        } else if (length == 1) {
            return (equals == Py_EQ);
        } else {
            int result;
#if CYTHON_USE_UNICODE_INTERNALS && (PY_VERSION_HEX < 0x030B0000)
            Py_hash_t hash1, hash2;
            hash1 = ((PyBytesObject*)s1)->ob_shash;
            hash2 = ((PyBytesObject*)s2)->ob_shash;
            if (hash1 != hash2 && hash1 != -1 && hash2 != -1) {
                return (equals == Py_NE);
            }
#endif
            result = memcmp(ps1, ps2, (size_t)length);
            return (equals == Py_EQ) ? (result == 0) : (result != 0);
        }
    } else if ((s1 == Py_None) & PyBytes_CheckExact(s2)) {
        return (equals == Py_NE);
    } else if ((s2 == Py_None) & PyBytes_CheckExact(s1)) {
        return (equals == Py_NE);
    } else {
        int result;
        PyObject* py_result = PyObject_RichCompare(s1, s2, equals);
        if (!py_result)
            return -1;
        result = __Pyx_PyObject_IsTrue(py_result);
        Py_DECREF(py_result);
        return result;
    }
#endif
}


static CYTHON_INLINE int __Pyx_PyUnicode_Equals(PyObject* s1, PyObject* s2, int equals) {
#if CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_GRAAL
    return PyObject_RichCompareBool(s1, s2, equals);
#else
    int s1_is_unicode, s2_is_unicode;
    if (s1 == s2) {
        goto return_eq;
    }
    s1_is_unicode = PyUnicode_CheckExact(s1);
    s2_is_unicode = PyUnicode_CheckExact(s2);
    if (s1_is_unicode & s2_is_unicode) {
        Py_ssize_t length, length2;
        int kind;
        void *data1, *data2;
        #if !CYTHON_COMPILING_IN_LIMITED_API
        if (unlikely(__Pyx_PyUnicode_READY(s1) < 0) || unlikely(__Pyx_PyUnicode_READY(s2) < 0))
            return -1;
        #endif
        length = __Pyx_PyUnicode_GET_LENGTH(s1);
        #if !CYTHON_ASSUME_SAFE_SIZE
        if (unlikely(length < 0)) return -1;
        #endif
        length2 = __Pyx_PyUnicode_GET_LENGTH(s2);
        #if !CYTHON_ASSUME_SAFE_SIZE
        if (unlikely(length2 < 0)) return -1;
        #endif
        if (length != length2) {
            goto return_ne;
        }
#if CYTHON_USE_UNICODE_INTERNALS
        {
            Py_hash_t hash1, hash2;
            hash1 = ((PyASCIIObject*)s1)->hash;
            hash2 = ((PyASCIIObject*)s2)->hash;
            if (hash1 != hash2 && hash1 != -1 && hash2 != -1) {
                goto return_ne;
            }
        }
#endif
        kind = __Pyx_PyUnicode_KIND(s1);
        if (kind != __Pyx_PyUnicode_KIND(s2)) {
            goto return_ne;
        }
        data1 = __Pyx_PyUnicode_DATA(s1);
        data2 = __Pyx_PyUnicode_DATA(s2);
        if (__Pyx_PyUnicode_READ(kind, data1, 0) != __Pyx_PyUnicode_READ(kind, data2, 0)) {
            goto return_ne;
        } else if (length == 1) {
            goto return_eq;
        } else {
            int result = memcmp(data1, data2, (size_t)(length * kind));
            return (equals == Py_EQ) ? (result == 0) : (result != 0);
        }
    } else if ((s1 == Py_None) & s2_is_unicode) {
        goto return_ne;
    } else if ((s2 == Py_None) & s1_is_unicode) {
        goto return_ne;
    } else {
        int result;
        PyObject* py_result = PyObject_RichCompare(s1, s2, equals);
        if (!py_result)
            return -1;
        result = __Pyx_PyObject_IsTrue(py_result);
        Py_DECREF(py_result);
        return result;
    }
return_eq:
    return (equals == Py_EQ);
return_ne:
    return (equals == Py_NE);
#endif
}


#if CYTHON_METH_FASTCALL
static CYTHON_INLINE PyObject * __Pyx_GetKwValue_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues, PyObject *s)
{
    Py_ssize_t i, n = __Pyx_PyTuple_GET_SIZE(kwnames);
    #if !CYTHON_ASSUME_SAFE_SIZE
    if (unlikely(n == -1)) return NULL;
    #endif
    for (i = 0; i < n; i++)
    {
        PyObject *namei = __Pyx_PyTuple_GET_ITEM(kwnames, i);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(!namei)) return NULL;
        #endif
        if (s == namei) return kwvalues[i];
    }
    for (i = 0; i < n; i++)
    {
        PyObject *namei = __Pyx_PyTuple_GET_ITEM(kwnames, i);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(!namei)) return NULL;
        #endif
        int eq = __Pyx_PyUnicode_Equals(s, namei, Py_EQ);
        if (unlikely(eq != 0)) {
            if (unlikely(eq < 0)) return NULL;
            return kwvalues[i];
        }
    }
    return NULL;
}
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030d0000 || CYTHON_COMPILING_IN_LIMITED_API
CYTHON_UNUSED static PyObject *__Pyx_KwargsAsDict_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues) {
    Py_ssize_t i, nkwargs;
    PyObject *dict;
#if !CYTHON_ASSUME_SAFE_SIZE
    nkwargs = PyTuple_Size(kwnames);
    if (unlikely(nkwargs < 0)) return NULL;
#else
    nkwargs = PyTuple_GET_SIZE(kwnames);
#endif
    dict = PyDict_New();
    if (unlikely(!dict))
        return NULL;
    for (i=0; i<nkwargs; i++) {
#if !CYTHON_ASSUME_SAFE_MACROS
        PyObject *key = PyTuple_GetItem(kwnames, i);
        if (!key) goto bad;
#else
        PyObject *key = PyTuple_GET_ITEM(kwnames, i);
#endif
        if (unlikely(PyDict_SetItem(dict, key, kwvalues[i]) < 0))
            goto bad;
    }
    return dict;
bad:
    Py_DECREF(dict);
    return NULL;
}
#endif
#endif


static void __Pyx_RaiseDoubleKeywordsError(
    const char* func_name,
    PyObject* kw_name)
{
    PyErr_Format(PyExc_TypeError,
        "%s() got multiple values for keyword argument '%U'", func_name, kw_name);
}


#if CYTHON_FAST_PYCALL && !CYTHON_VECTORCALL
static PyObject* __Pyx_PyFunction_FastCallNoKw(PyCodeObject *co, PyObject *const *args, Py_ssize_t na,
                                               PyObject *globals) {
    PyFrameObject *f;
    PyThreadState *tstate = __Pyx_PyThreadState_Current;
    PyObject **fastlocals;
    Py_ssize_t i;
    PyObject *result;
    assert(globals != NULL);
    
    assert(tstate != NULL);
    f = PyFrame_New(tstate, co, globals, NULL);
    if (f == NULL) {
        return NULL;
    }
    fastlocals = __Pyx_PyFrame_GetLocalsplus(f);
    for (i = 0; i < na; i++) {
        Py_INCREF(*args);
        fastlocals[i] = *args++;
    }
    result = PyEval_EvalFrameEx(f,0);
    ++tstate->recursion_depth;
    Py_DECREF(f);
    --tstate->recursion_depth;
    return result;
}
static PyObject *__Pyx_PyFunction_FastCallDict(PyObject *func, PyObject *const *args, Py_ssize_t nargs, PyObject *kwargs) {
    PyCodeObject *co = (PyCodeObject *)PyFunction_GET_CODE(func);
    PyObject *globals = PyFunction_GET_GLOBALS(func);
    PyObject *argdefs = PyFunction_GET_DEFAULTS(func);
    PyObject *closure;
    PyObject *kwdefs;
    PyObject *kwtuple, **k;
    PyObject **d;
    Py_ssize_t nd;
    Py_ssize_t nk;
    PyObject *result;
    assert(kwargs == NULL || PyDict_Check(kwargs));
    nk = kwargs ? PyDict_Size(kwargs) : 0;
    if (unlikely(Py_EnterRecursiveCall(" while calling a Python object"))) {
        return NULL;
    }
    if (
            co->co_kwonlyargcount == 0 &&
            likely(kwargs == NULL || nk == 0) &&
            co->co_flags == (CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE)) {
        if (argdefs == NULL && co->co_argcount == nargs) {
            result = __Pyx_PyFunction_FastCallNoKw(co, args, nargs, globals);
            goto done;
        }
        else if (nargs == 0 && argdefs != NULL
                 && co->co_argcount == Py_SIZE(argdefs)) {
            
            args = &PyTuple_GET_ITEM(argdefs, 0);
            result =__Pyx_PyFunction_FastCallNoKw(co, args, Py_SIZE(argdefs), globals);
            goto done;
        }
    }
    if (kwargs != NULL) {
        Py_ssize_t pos, i;
        kwtuple = PyTuple_New(2 * nk);
        if (kwtuple == NULL) {
            result = NULL;
            goto done;
        }
        k = &PyTuple_GET_ITEM(kwtuple, 0);
        pos = i = 0;
        while (PyDict_Next(kwargs, &pos, &k[i], &k[i+1])) {
            Py_INCREF(k[i]);
            Py_INCREF(k[i+1]);
            i += 2;
        }
        nk = i / 2;
    }
    else {
        kwtuple = NULL;
        k = NULL;
    }
    closure = PyFunction_GET_CLOSURE(func);
    kwdefs = PyFunction_GET_KW_DEFAULTS(func);
    if (argdefs != NULL) {
        d = &PyTuple_GET_ITEM(argdefs, 0);
        nd = Py_SIZE(argdefs);
    }
    else {
        d = NULL;
        nd = 0;
    }
    result = PyEval_EvalCodeEx((PyObject*)co, globals, (PyObject *)NULL,
                               args, (int)nargs,
                               k, (int)nk,
                               d, (int)nd, kwdefs, closure);
    Py_XDECREF(kwtuple);
done:
    Py_LeaveRecursiveCall();
    return result;
}
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_Call(PyObject *func, PyObject *arg, PyObject *kw) {
    PyObject *result;
    ternaryfunc call = Py_TYPE(func)->tp_call;
    if (unlikely(!call))
        return PyObject_Call(func, arg, kw);
    if (unlikely(Py_EnterRecursiveCall(" while calling a Python object")))
        return NULL;
    result = (*call)(func, arg, kw);
    Py_LeaveRecursiveCall();
    if (unlikely(!result) && unlikely(!PyErr_Occurred())) {
        PyErr_SetString(
            PyExc_SystemError,
            "NULL result without error in PyObject_Call");
    }
    return result;
}
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethO(PyObject *func, PyObject *arg) {
    PyObject *self, *result;
    PyCFunction cfunc;
    cfunc = __Pyx_CyOrPyCFunction_GET_FUNCTION(func);
    self = __Pyx_CyOrPyCFunction_GET_SELF(func);
    if (unlikely(Py_EnterRecursiveCall(" while calling a Python object")))
        return NULL;
    result = cfunc(self, arg);
    Py_LeaveRecursiveCall();
    if (unlikely(!result) && unlikely(!PyErr_Occurred())) {
        PyErr_SetString(
            PyExc_SystemError,
            "NULL result without error in PyObject_Call");
    }
    return result;
}
#endif


#if PY_VERSION_HEX < 0x03090000 || CYTHON_COMPILING_IN_LIMITED_API
static PyObject* __Pyx_PyObject_FastCall_fallback(PyObject *func, PyObject * const*args, size_t nargs, PyObject *kwargs) {
    PyObject *argstuple;
    PyObject *result = 0;
    size_t i;
    argstuple = PyTuple_New((Py_ssize_t)nargs);
    if (unlikely(!argstuple)) return NULL;
    for (i = 0; i < nargs; i++) {
        Py_INCREF(args[i]);
        if (__Pyx_PyTuple_SET_ITEM(argstuple, (Py_ssize_t)i, args[i]) != (0)) goto bad;
    }
    result = __Pyx_PyObject_Call(func, argstuple, kwargs);
  bad:
    Py_DECREF(argstuple);
    return result;
}
#endif
#if CYTHON_VECTORCALL && !CYTHON_COMPILING_IN_LIMITED_API
  #if PY_VERSION_HEX < 0x03090000
    #define __Pyx_PyVectorcall_Function(callable) _PyVectorcall_Function(callable)
  #elif CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE vectorcallfunc __Pyx_PyVectorcall_Function(PyObject *callable) {
    PyTypeObject *tp = Py_TYPE(callable);
    #if defined(__Pyx_CyFunction_USED)
    if (__Pyx_CyFunction_CheckExact(callable)) {
        return __Pyx_CyFunction_func_vectorcall(callable);
    }
    #endif
    if (!PyType_HasFeature(tp, Py_TPFLAGS_HAVE_VECTORCALL)) {
        return NULL;
    }
    assert(PyCallable_Check(callable));
    Py_ssize_t offset = tp->tp_vectorcall_offset;
    assert(offset > 0);
    vectorcallfunc ptr;
    memcpy(&ptr, (char *) callable + offset, sizeof(ptr));
    return ptr;
}
  #else
    #define __Pyx_PyVectorcall_Function(callable) PyVectorcall_Function(callable)
  #endif
#endif
static CYTHON_INLINE PyObject* __Pyx_PyObject_FastCallDict(PyObject *func, PyObject *const *args, size_t _nargs, PyObject *kwargs) {
    Py_ssize_t nargs = __Pyx_PyVectorcall_NARGS(_nargs);
#if CYTHON_COMPILING_IN_CPYTHON
    if (nargs == 0 && kwargs == NULL) {
        if (__Pyx_CyOrPyCFunction_Check(func) && likely( __Pyx_CyOrPyCFunction_GET_FLAGS(func) & METH_NOARGS))
            return __Pyx_PyObject_CallMethO(func, NULL);
    }
    else if (nargs == 1 && kwargs == NULL) {
        if (__Pyx_CyOrPyCFunction_Check(func) && likely( __Pyx_CyOrPyCFunction_GET_FLAGS(func) & METH_O))
            return __Pyx_PyObject_CallMethO(func, args[0]);
    }
#endif
    #if PY_VERSION_HEX < 0x030800B1
    #if CYTHON_FAST_PYCCALL
    if (PyCFunction_Check(func)) {
        if (kwargs) {
            return _PyCFunction_FastCallDict(func, args, nargs, kwargs);
        } else {
            return _PyCFunction_FastCallKeywords(func, args, nargs, NULL);
        }
    }
    if (!kwargs && __Pyx_IS_TYPE(func, &PyMethodDescr_Type)) {
        return _PyMethodDescr_FastCallKeywords(func, args, nargs, NULL);
    }
    #endif
    #if CYTHON_FAST_PYCALL
    if (PyFunction_Check(func)) {
        return __Pyx_PyFunction_FastCallDict(func, args, nargs, kwargs);
    }
    #endif
    #endif
    if (kwargs == NULL) {
        #if CYTHON_VECTORCALL && !CYTHON_COMPILING_IN_LIMITED_API
        vectorcallfunc f = __Pyx_PyVectorcall_Function(func);
        if (f) {
            return f(func, args, _nargs, NULL);
        }
        #elif defined(__Pyx_CyFunction_USED) && CYTHON_BACKPORT_VECTORCALL
        if (__Pyx_CyFunction_CheckExact(func)) {
            __pyx_vectorcallfunc f = __Pyx_CyFunction_func_vectorcall(func);
            if (f) return f(func, args, _nargs, NULL);
        }
        #elif CYTHON_COMPILING_IN_LIMITED_API && CYTHON_VECTORCALL
        return PyObject_Vectorcall(func, args, _nargs, NULL);
        #endif
    }
    if (nargs == 0) {
        return __Pyx_PyObject_Call(func, __pyx_mstate_global->__pyx_empty_tuple, kwargs);
    }
    #if PY_VERSION_HEX >= 0x03090000 && !CYTHON_COMPILING_IN_LIMITED_API
    return PyObject_VectorcallDict(func, args, (size_t)nargs, kwargs);
    #else
    return __Pyx_PyObject_FastCall_fallback(func, args, (size_t)nargs, kwargs);
    #endif
}


#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030C0000
static PyObject *__Pyx_SelflessCall(PyObject *method, PyObject *args, PyObject *kwargs) {
    PyObject *result;
    PyObject *selfless_args = PyTuple_GetSlice(args, 1, PyTuple_Size(args));
    if (unlikely(!selfless_args)) return NULL;
    result = PyObject_Call(method, selfless_args, kwargs);
    Py_DECREF(selfless_args);
    return result;
}
#elif CYTHON_COMPILING_IN_PYPY && PY_VERSION_HEX < 0x03090000
static PyObject *__Pyx_SelflessCall(PyObject *method, PyObject **args, Py_ssize_t nargs, PyObject *kwnames) {
        return _PyObject_Vectorcall
            (method, args ? args+1 : NULL, nargs ? nargs-1 : 0, kwnames);
}
#else
static PyObject *__Pyx_SelflessCall(PyObject *method, PyObject *const *args, Py_ssize_t nargs, PyObject *kwnames) {
    return
#if PY_VERSION_HEX < 0x03090000
    _PyObject_Vectorcall
#else
    PyObject_Vectorcall
#endif
        (method, args ? args+1 : NULL, nargs ? (size_t) nargs-1 : 0, kwnames);
}
#endif
static PyMethodDef __Pyx_UnboundCMethod_Def = {
     "CythonUnboundCMethod",
     __PYX_REINTERPRET_FUNCION(PyCFunction, __Pyx_SelflessCall),
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030C0000
     METH_VARARGS | METH_KEYWORDS,
#else
     METH_FASTCALL | METH_KEYWORDS,
#endif
     NULL
};
static int __Pyx_TryUnpackUnboundCMethod(__Pyx_CachedCFunction* target) {
    PyObject *method, *result=NULL;
    method = __Pyx_PyObject_GetAttrStr(target->type, *target->method_name);
    if (unlikely(!method))
        return -1;
    result = method;
#if CYTHON_COMPILING_IN_CPYTHON
    if (likely(__Pyx_TypeCheck(method, &PyMethodDescr_Type)))
    {
        PyMethodDescrObject *descr = (PyMethodDescrObject*) method;
        target->func = descr->d_method->ml_meth;
        target->flag = descr->d_method->ml_flags & ~(METH_CLASS | METH_STATIC | METH_COEXIST | METH_STACKLESS);
    } else
#endif
#if CYTHON_COMPILING_IN_PYPY
#else
    if (PyCFunction_Check(method))
#endif
    {
        PyObject *self;
        int self_found;
#if CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY
        self = PyObject_GetAttrString(method, "__self__");
        if (!self) {
            PyErr_Clear();
        }
#else
        self = PyCFunction_GET_SELF(method);
#endif
        self_found = (self && self != Py_None);
#if CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY
        Py_XDECREF(self);
#endif
        if (self_found) {
            PyObject *unbound_method = PyCFunction_New(&__Pyx_UnboundCMethod_Def, method);
            if (unlikely(!unbound_method)) return -1;
            Py_DECREF(method);
            result = unbound_method;
        }
    }
#if !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    if (unlikely(target->method)) {
        Py_DECREF(result);
    } else
#endif
    target->method = result;
    return 0;
}


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject *__Pyx_CallUnboundCMethod2(__Pyx_CachedCFunction *cfunc, PyObject *self, PyObject *arg1, PyObject *arg2) {
    int was_initialized = __Pyx_CachedCFunction_GetAndSetInitializing(cfunc);
    if (likely(was_initialized == 2 && cfunc->func)) {
        PyObject *args[2] = {arg1, arg2};
        if (cfunc->flag == METH_FASTCALL) {
            return __Pyx_CallCFunctionFast(cfunc, self, args, 2);
        }
        if (cfunc->flag == (METH_FASTCALL | METH_KEYWORDS))
            return __Pyx_CallCFunctionFastWithKeywords(cfunc, self, args, 2, NULL);
    }
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    else if (unlikely(was_initialized == 1)) {
        __Pyx_CachedCFunction tmp_cfunc = {
#ifndef __cplusplus
            0
#endif
        };
        tmp_cfunc.type = cfunc->type;
        tmp_cfunc.method_name = cfunc->method_name;
        return __Pyx__CallUnboundCMethod2(&tmp_cfunc, self, arg1, arg2);
    }
#endif
    PyObject *result = __Pyx__CallUnboundCMethod2(cfunc, self, arg1, arg2);
    __Pyx_CachedCFunction_SetFinishedInitializing(cfunc);
    return result;
}
#endif
static PyObject* __Pyx__CallUnboundCMethod2(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg1, PyObject* arg2){
    if (unlikely(!cfunc->func && !cfunc->method) && unlikely(__Pyx_TryUnpackUnboundCMethod(cfunc) < 0)) return NULL;
#if CYTHON_COMPILING_IN_CPYTHON
    if (cfunc->func && (cfunc->flag & METH_VARARGS)) {
        PyObject *result = NULL;
        PyObject *args = PyTuple_New(2);
        if (unlikely(!args)) return NULL;
        Py_INCREF(arg1);
        PyTuple_SET_ITEM(args, 0, arg1);
        Py_INCREF(arg2);
        PyTuple_SET_ITEM(args, 1, arg2);
        if (cfunc->flag & METH_KEYWORDS)
            result = __Pyx_CallCFunctionWithKeywords(cfunc, self, args, NULL);
        else
            result = __Pyx_CallCFunction(cfunc, self, args);
        Py_DECREF(args);
        return result;
    }
#endif
    {
        PyObject *args[4] = {NULL, self, arg1, arg2};
        return __Pyx_PyObject_FastCall(cfunc->method, args+1, 3 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET);
    }
}


static int __Pyx_ValidateDuplicatePosArgs(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    const char* function_name)
{
    PyObject ** const *name = argnames;
    while (name != first_kw_arg) {
        PyObject *key = **name;
        int found = PyDict_Contains(kwds, key);
        if (unlikely(found)) {
            if (found == 1) __Pyx_RaiseDoubleKeywordsError(function_name, key);
            goto bad;
        }
        name++;
    }
    return 0;
bad:
    return -1;
}
#if CYTHON_USE_UNICODE_INTERNALS
static CYTHON_INLINE int __Pyx_UnicodeKeywordsEqual(PyObject *s1, PyObject *s2) {
    int kind;
    Py_ssize_t len = PyUnicode_GET_LENGTH(s1);
    if (len != PyUnicode_GET_LENGTH(s2)) return 0;
    kind = PyUnicode_KIND(s1);
    if (kind != PyUnicode_KIND(s2)) return 0;
    const void *data1 = PyUnicode_DATA(s1);
    const void *data2 = PyUnicode_DATA(s2);
    return (memcmp(data1, data2, (size_t) len * (size_t) kind) == 0);
}
#endif
static int __Pyx_MatchKeywordArg_str(
    PyObject *key,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    size_t *index_found,
    const char *function_name)
{
    PyObject ** const *name;
    #if CYTHON_USE_UNICODE_INTERNALS
    Py_hash_t key_hash = ((PyASCIIObject*)key)->hash;
    if (unlikely(key_hash == -1)) {
        key_hash = PyObject_Hash(key);
        if (unlikely(key_hash == -1))
            goto bad;
    }
    #endif
    name = first_kw_arg;
    while (*name) {
        PyObject *name_str = **name;
        #if CYTHON_USE_UNICODE_INTERNALS
        if (key_hash == ((PyASCIIObject*)name_str)->hash && __Pyx_UnicodeKeywordsEqual(name_str, key)) {
            *index_found = (size_t) (name - argnames);
            return 1;
        }
        #else
        #if CYTHON_ASSUME_SAFE_SIZE
        if (PyUnicode_GET_LENGTH(name_str) == PyUnicode_GET_LENGTH(key))
        #endif
        {
            int cmp = PyUnicode_Compare(name_str, key);
            if (cmp < 0 && unlikely(PyErr_Occurred())) goto bad;
            if (cmp == 0) {
                *index_found = (size_t) (name - argnames);
                return 1;
            }
        }
        #endif
        name++;
    }
    name = argnames;
    while (name != first_kw_arg) {
        PyObject *name_str = **name;
        #if CYTHON_USE_UNICODE_INTERNALS
        if (unlikely(key_hash == ((PyASCIIObject*)name_str)->hash)) {
            if (__Pyx_UnicodeKeywordsEqual(name_str, key))
                goto arg_passed_twice;
        }
        #else
        #if CYTHON_ASSUME_SAFE_SIZE
        if (PyUnicode_GET_LENGTH(name_str) == PyUnicode_GET_LENGTH(key))
        #endif
        {
            if (unlikely(name_str == key)) goto arg_passed_twice;
            int cmp = PyUnicode_Compare(name_str, key);
            if (cmp < 0 && unlikely(PyErr_Occurred())) goto bad;
            if (cmp == 0) goto arg_passed_twice;
        }
        #endif
        name++;
    }
    return 0;
arg_passed_twice:
    __Pyx_RaiseDoubleKeywordsError(function_name, key);
    goto bad;
bad:
    return -1;
}
static int __Pyx_MatchKeywordArg_nostr(
    PyObject *key,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    size_t *index_found,
    const char *function_name)
{
    PyObject ** const *name;
    if (unlikely(!PyUnicode_Check(key))) goto invalid_keyword_type;
    name = first_kw_arg;
    while (*name) {
        int cmp = PyObject_RichCompareBool(**name, key, Py_EQ);
        if (cmp == 1) {
            *index_found = (size_t) (name - argnames);
            return 1;
        }
        if (unlikely(cmp == -1)) goto bad;
        name++;
    }
    name = argnames;
    while (name != first_kw_arg) {
        int cmp = PyObject_RichCompareBool(**name, key, Py_EQ);
        if (unlikely(cmp != 0)) {
            if (cmp == 1) goto arg_passed_twice;
            else goto bad;
        }
        name++;
    }
    return 0;
arg_passed_twice:
    __Pyx_RaiseDoubleKeywordsError(function_name, key);
    goto bad;
invalid_keyword_type:
    PyErr_Format(PyExc_TypeError,
        "%.200s() keywords must be strings", function_name);
    goto bad;
bad:
    return -1;
}
static CYTHON_INLINE int __Pyx_MatchKeywordArg(
    PyObject *key,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    size_t *index_found,
    const char *function_name)
{
    return likely(PyUnicode_CheckExact(key)) ?
        __Pyx_MatchKeywordArg_str(key, argnames, first_kw_arg, index_found, function_name) :
        __Pyx_MatchKeywordArg_nostr(key, argnames, first_kw_arg, index_found, function_name);
}
static void __Pyx_RejectUnknownKeyword(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    const char *function_name)
{
    Py_ssize_t pos = 0;
    PyObject *key = NULL;
    __Pyx_BEGIN_CRITICAL_SECTION(kwds);
    while (PyDict_Next(kwds, &pos, &key, NULL)) {
        PyObject** const *name = first_kw_arg;
        while (*name && (**name != key)) name++;
        if (!*name) {
            #if CYTHON_AVOID_BORROWED_REFS
            Py_INCREF(key);
            #endif
            size_t index_found = 0;
            int cmp = __Pyx_MatchKeywordArg(key, argnames, first_kw_arg, &index_found, function_name);
            if (cmp != 1) {
                if (cmp == 0) {
                    PyErr_Format(PyExc_TypeError,
                        "%s() got an unexpected keyword argument '%U'",
                        function_name, key);
                }
                #if CYTHON_AVOID_BORROWED_REFS
                Py_DECREF(key);
                #endif
                break;
            }
            #if CYTHON_AVOID_BORROWED_REFS
            Py_DECREF(key);
            #endif
        }
    }
    __Pyx_END_CRITICAL_SECTION();
    assert(PyErr_Occurred());
}
static int __Pyx_ParseKeywordDict(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs)
{
    PyObject** const *name;
    PyObject** const *first_kw_arg = argnames + num_pos_args;
    Py_ssize_t extracted = 0;
#if !CYTHON_COMPILING_IN_PYPY || defined(PyArg_ValidateKeywordArguments)
    if (unlikely(!PyArg_ValidateKeywordArguments(kwds))) return -1;
#endif
    name = first_kw_arg;
    while (*name && num_kwargs > extracted) {
        PyObject * key = **name;
        PyObject *value;
        int found = 0;
        #if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
        found = PyDict_GetItemRef(kwds, key, &value);
        #else
        value = PyDict_GetItemWithError(kwds, key);
        if (value) {
            Py_INCREF(value);
            found = 1;
        } else {
            if (unlikely(PyErr_Occurred())) goto bad;
        }
        #endif
        if (found) {
            if (unlikely(found < 0)) goto bad;
            values[name-argnames] = value;
            extracted++;
        }
        name++;
    }
    if (num_kwargs > extracted) {
        if (ignore_unknown_kwargs) {
            if (unlikely(__Pyx_ValidateDuplicatePosArgs(kwds, argnames, first_kw_arg, function_name) == -1))
                goto bad;
        } else {
            __Pyx_RejectUnknownKeyword(kwds, argnames, first_kw_arg, function_name);
            goto bad;
        }
    }
    return 0;
bad:
    return -1;
}
static int __Pyx_ParseKeywordDictToDict(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    const char* function_name)
{
    PyObject** const *name;
    PyObject** const *first_kw_arg = argnames + num_pos_args;
    Py_ssize_t len;
#if !CYTHON_COMPILING_IN_PYPY || defined(PyArg_ValidateKeywordArguments)
    if (unlikely(!PyArg_ValidateKeywordArguments(kwds))) return -1;
#endif
    if (PyDict_Update(kwds2, kwds) < 0) goto bad;
    name = first_kw_arg;
    while (*name) {
        PyObject *key = **name;
        PyObject *value;
#if !CYTHON_COMPILING_IN_LIMITED_API && (PY_VERSION_HEX >= 0x030d00A2 || defined(PyDict_Pop))
        int found = PyDict_Pop(kwds2, key, &value);
        if (found) {
            if (unlikely(found < 0)) goto bad;
            values[name-argnames] = value;
        }
#elif __PYX_LIMITED_VERSION_HEX >= 0x030d0000
        int found = PyDict_GetItemRef(kwds2, key, &value);
        if (found) {
            if (unlikely(found < 0)) goto bad;
            values[name-argnames] = value;
            if (unlikely(PyDict_DelItem(kwds2, key) < 0)) goto bad;
        }
#else
    #if CYTHON_COMPILING_IN_CPYTHON
        value = _PyDict_Pop(kwds2, key, kwds2);
    #else
        value = __Pyx_CallUnboundCMethod2(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_pop, kwds2, key, kwds2);
    #endif
        if (value == kwds2) {
            Py_DECREF(value);
        } else {
            if (unlikely(!value)) goto bad;
            values[name-argnames] = value;
        }
#endif
        name++;
    }
    len = PyDict_Size(kwds2);
    if (len > 0) {
        return __Pyx_ValidateDuplicatePosArgs(kwds, argnames, first_kw_arg, function_name);
    } else if (unlikely(len == -1)) {
        goto bad;
    }
    return 0;
bad:
    return -1;
}
static int __Pyx_ParseKeywordsTuple(
    PyObject *kwds,
    PyObject * const *kwvalues,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs)
{
    PyObject *key = NULL;
    PyObject** const * name;
    PyObject** const *first_kw_arg = argnames + num_pos_args;
    for (Py_ssize_t pos = 0; pos < num_kwargs; pos++) {
#if CYTHON_AVOID_BORROWED_REFS
        key = __Pyx_PySequence_ITEM(kwds, pos);
#else
        key = __Pyx_PyTuple_GET_ITEM(kwds, pos);
#endif
#if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(!key)) goto bad;
#endif
        name = first_kw_arg;
        while (*name && (**name != key)) name++;
        if (*name) {
            PyObject *value = kwvalues[pos];
            values[name-argnames] = __Pyx_NewRef(value);
        } else {
            size_t index_found = 0;
            int cmp = __Pyx_MatchKeywordArg(key, argnames, first_kw_arg, &index_found, function_name);
            if (cmp == 1) {
                PyObject *value = kwvalues[pos];
                values[index_found] = __Pyx_NewRef(value);
            } else {
                if (unlikely(cmp == -1)) goto bad;
                if (kwds2) {
                    PyObject *value = kwvalues[pos];
                    if (unlikely(PyDict_SetItem(kwds2, key, value))) goto bad;
                } else if (!ignore_unknown_kwargs) {
                    goto invalid_keyword;
                }
            }
        }
        #if CYTHON_AVOID_BORROWED_REFS
        Py_DECREF(key);
        key = NULL;
        #endif
    }
    return 0;
invalid_keyword:
    PyErr_Format(PyExc_TypeError,
        "%s() got an unexpected keyword argument '%U'",
        function_name, key);
    goto bad;
bad:
    #if CYTHON_AVOID_BORROWED_REFS
    Py_XDECREF(key);
    #endif
    return -1;
}
static int __Pyx_ParseKeywords(
    PyObject *kwds,
    PyObject * const *kwvalues,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs)
{
    if (CYTHON_METH_FASTCALL && likely(PyTuple_Check(kwds)))
        return __Pyx_ParseKeywordsTuple(kwds, kwvalues, argnames, kwds2, values, num_pos_args, num_kwargs, function_name, ignore_unknown_kwargs);
    else if (kwds2)
        return __Pyx_ParseKeywordDictToDict(kwds, argnames, kwds2, values, num_pos_args, function_name);
    else
        return __Pyx_ParseKeywordDict(kwds, argnames, values, num_pos_args, num_kwargs, function_name, ignore_unknown_kwargs);
}


static void __Pyx_RaiseArgtupleInvalid(
    const char* func_name,
    int exact,
    Py_ssize_t num_min,
    Py_ssize_t num_max,
    Py_ssize_t num_found)
{
    Py_ssize_t num_expected;
    const char *more_or_less;
    if (num_found < num_min) {
        num_expected = num_min;
        more_or_less = "at least";
    } else {
        num_expected = num_max;
        more_or_less = "at most";
    }
    if (exact) {
        more_or_less = "exactly";
    }
    PyErr_Format(PyExc_TypeError,
                 "%.200s() takes %.8s %" CYTHON_FORMAT_SSIZE_T "d positional argument%.1s (%" CYTHON_FORMAT_SSIZE_T "d given)",
                 func_name, more_or_less, num_expected,
                 (num_expected == 1) ? "" : "s", num_found);
}


static CYTHON_INLINE PyObject* __Pyx_PyObject_Call2Args(PyObject* function, PyObject* arg1, PyObject* arg2) {
    PyObject *args[3] = {NULL, arg1, arg2};
    return __Pyx_PyObject_FastCall(function, args+1, 2 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET);
}


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_CallUnboundCMethod1(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg) {
    int was_initialized =  __Pyx_CachedCFunction_GetAndSetInitializing(cfunc);
    if (likely(was_initialized == 2 && cfunc->func)) {
        int flag = cfunc->flag;
        if (flag == METH_O) {
            return __Pyx_CallCFunction(cfunc, self, arg);
        } else if (flag == METH_FASTCALL) {
            return __Pyx_CallCFunctionFast(cfunc, self, &arg, 1);
        } else if (flag == (METH_FASTCALL | METH_KEYWORDS)) {
            return __Pyx_CallCFunctionFastWithKeywords(cfunc, self, &arg, 1, NULL);
        }
    }
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    else if (unlikely(was_initialized == 1)) {
        __Pyx_CachedCFunction tmp_cfunc = {
#ifndef __cplusplus
            0
#endif
        };
        tmp_cfunc.type = cfunc->type;
        tmp_cfunc.method_name = cfunc->method_name;
        return __Pyx__CallUnboundCMethod1(&tmp_cfunc, self, arg);
    }
#endif
    PyObject* result = __Pyx__CallUnboundCMethod1(cfunc, self, arg);
    __Pyx_CachedCFunction_SetFinishedInitializing(cfunc);
    return result;
}
#endif
static PyObject* __Pyx__CallUnboundCMethod1(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg){
    PyObject *result = NULL;
    if (unlikely(!cfunc->func && !cfunc->method) && unlikely(__Pyx_TryUnpackUnboundCMethod(cfunc) < 0)) return NULL;
#if CYTHON_COMPILING_IN_CPYTHON
    if (cfunc->func && (cfunc->flag & METH_VARARGS)) {
        PyObject *args = PyTuple_New(1);
        if (unlikely(!args)) return NULL;
        Py_INCREF(arg);
        PyTuple_SET_ITEM(args, 0, arg);
        if (cfunc->flag & METH_KEYWORDS)
            result = __Pyx_CallCFunctionWithKeywords(cfunc, self, args, NULL);
        else
            result = __Pyx_CallCFunction(cfunc, self, args);
        Py_DECREF(args);
    } else
#endif
    {
        result = __Pyx_PyObject_Call2Args(cfunc->method, self, arg);
    }
    return result;
}


static PyObject* __Pyx_PyDict_GetItemDefault(PyObject* d, PyObject* key, PyObject* default_value) {
    PyObject* value;
#if !CYTHON_COMPILING_IN_PYPY || PYPY_VERSION_NUM >= 0x07020000
    value = PyDict_GetItemWithError(d, key);
    if (unlikely(!value)) {
        if (unlikely(PyErr_Occurred()))
            return NULL;
        value = default_value;
    }
    Py_INCREF(value);
    if ((1));
#else
    if (PyBytes_CheckExact(key) || PyUnicode_CheckExact(key) || PyLong_CheckExact(key)) {
        value = PyDict_GetItem(d, key);
        if (unlikely(!value)) {
            value = default_value;
        }
        Py_INCREF(value);
    }
#endif
    else {
        if (default_value == Py_None)
            value = __Pyx_CallUnboundCMethod1(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_get, d, key);
        else
            value = __Pyx_CallUnboundCMethod2(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_get, d, key, default_value);
    }
    return value;
}


#if !CYTHON_VECTORCALL || PY_VERSION_HEX < 0x03090000
static PyObject *__Pyx_PyObject_FastCallMethod(PyObject *name, PyObject *const *args, size_t nargsf) {
    PyObject *result;
    PyObject *attr = PyObject_GetAttr(args[0], name);
    if (unlikely(!attr))
        return NULL;
    result = __Pyx_PyObject_FastCall(attr, args+1, nargsf - 1);
    Py_DECREF(attr);
    return result;
}
#endif


#if CYTHON_USE_DICT_VERSIONS && CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PY_UINT64_T __Pyx_get_tp_dict_version(PyObject *obj) {
    PyObject *dict = Py_TYPE(obj)->tp_dict;
    return likely(dict) ? __PYX_GET_DICT_VERSION(dict) : 0;
}
static CYTHON_INLINE PY_UINT64_T __Pyx_get_object_dict_version(PyObject *obj) {
    PyObject **dictptr = NULL;
    Py_ssize_t offset = Py_TYPE(obj)->tp_dictoffset;
    if (offset) {
#if CYTHON_COMPILING_IN_CPYTHON
        dictptr = (likely(offset > 0)) ? (PyObject **) ((char *)obj + offset) : _PyObject_GetDictPtr(obj);
#else
        dictptr = _PyObject_GetDictPtr(obj);
#endif
    }
    return (dictptr && *dictptr) ? __PYX_GET_DICT_VERSION(*dictptr) : 0;
}
static CYTHON_INLINE int __Pyx_object_dict_version_matches(PyObject* obj, PY_UINT64_T tp_dict_version, PY_UINT64_T obj_dict_version) {
    PyObject *dict = Py_TYPE(obj)->tp_dict;
    if (unlikely(!dict) || unlikely(tp_dict_version != __PYX_GET_DICT_VERSION(dict)))
        return 0;
    return obj_dict_version == __Pyx_get_object_dict_version(obj);
}
#endif


#if CYTHON_USE_DICT_VERSIONS
static PyObject *__Pyx__GetModuleGlobalName(PyObject *name, PY_UINT64_T *dict_version, PyObject **dict_cached_value)
#else
static CYTHON_INLINE PyObject *__Pyx__GetModuleGlobalName(PyObject *name)
#endif
{
    PyObject *result;
#if CYTHON_COMPILING_IN_LIMITED_API
    if (unlikely(!__pyx_m)) {
        if (!PyErr_Occurred())
            PyErr_SetNone(PyExc_NameError);
        return NULL;
    }
    result = PyObject_GetAttr(__pyx_m, name);
    if (likely(result)) {
        return result;
    }
    PyErr_Clear();
#elif CYTHON_AVOID_BORROWED_REFS || CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
    if (unlikely(__Pyx_PyDict_GetItemRef(__pyx_mstate_global->__pyx_d, name, &result) == -1)) PyErr_Clear();
    __PYX_UPDATE_DICT_CACHE(__pyx_mstate_global->__pyx_d, result, *dict_cached_value, *dict_version)
    if (likely(result)) {
        return result;
    }
#else
    result = _PyDict_GetItem_KnownHash(__pyx_mstate_global->__pyx_d, name, ((PyASCIIObject *) name)->hash);
    __PYX_UPDATE_DICT_CACHE(__pyx_mstate_global->__pyx_d, result, *dict_cached_value, *dict_version)
    if (likely(result)) {
        return __Pyx_NewRef(result);
    }
    PyErr_Clear();
#endif
    return __Pyx_GetBuiltinName(name);
}


#if CYTHON_USE_EXC_INFO_STACK && CYTHON_FAST_THREAD_STATE
static _PyErr_StackItem *
__Pyx_PyErr_GetTopmostException(PyThreadState *tstate)
{
    _PyErr_StackItem *exc_info = tstate->exc_info;
    while ((exc_info->exc_value == NULL || exc_info->exc_value == Py_None) &&
           exc_info->previous_item != NULL)
    {
        exc_info = exc_info->previous_item;
    }
    return exc_info;
}
#endif


#if CYTHON_FAST_THREAD_STATE
static CYTHON_INLINE void __Pyx__ExceptionSave(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb) {
  #if CYTHON_USE_EXC_INFO_STACK && PY_VERSION_HEX >= 0x030B00a4
    _PyErr_StackItem *exc_info = __Pyx_PyErr_GetTopmostException(tstate);
    PyObject *exc_value = exc_info->exc_value;
    if (exc_value == NULL || exc_value == Py_None) {
        *value = NULL;
        *type = NULL;
        *tb = NULL;
    } else {
        *value = exc_value;
        Py_INCREF(*value);
        *type = (PyObject*) Py_TYPE(exc_value);
        Py_INCREF(*type);
        *tb = PyException_GetTraceback(exc_value);
    }
  #elif CYTHON_USE_EXC_INFO_STACK
    _PyErr_StackItem *exc_info = __Pyx_PyErr_GetTopmostException(tstate);
    *type = exc_info->exc_type;
    *value = exc_info->exc_value;
    *tb = exc_info->exc_traceback;
    Py_XINCREF(*type);
    Py_XINCREF(*value);
    Py_XINCREF(*tb);
  #else
    *type = tstate->exc_type;
    *value = tstate->exc_value;
    *tb = tstate->exc_traceback;
    Py_XINCREF(*type);
    Py_XINCREF(*value);
    Py_XINCREF(*tb);
  #endif
}
static CYTHON_INLINE void __Pyx__ExceptionReset(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb) {
  #if CYTHON_USE_EXC_INFO_STACK && PY_VERSION_HEX >= 0x030B00a4
    _PyErr_StackItem *exc_info = tstate->exc_info;
    PyObject *tmp_value = exc_info->exc_value;
    exc_info->exc_value = value;
    Py_XDECREF(tmp_value);
    Py_XDECREF(type);
    Py_XDECREF(tb);
  #else
    PyObject *tmp_type, *tmp_value, *tmp_tb;
    #if CYTHON_USE_EXC_INFO_STACK
    _PyErr_StackItem *exc_info = tstate->exc_info;
    tmp_type = exc_info->exc_type;
    tmp_value = exc_info->exc_value;
    tmp_tb = exc_info->exc_traceback;
    exc_info->exc_type = type;
    exc_info->exc_value = value;
    exc_info->exc_traceback = tb;
    #else
    tmp_type = tstate->exc_type;
    tmp_value = tstate->exc_value;
    tmp_tb = tstate->exc_traceback;
    tstate->exc_type = type;
    tstate->exc_value = value;
    tstate->exc_traceback = tb;
    #endif
    Py_XDECREF(tmp_type);
    Py_XDECREF(tmp_value);
    Py_XDECREF(tmp_tb);
  #endif
}
#endif


#if CYTHON_FAST_THREAD_STATE
static int __Pyx__GetException(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb)
#else
static int __Pyx_GetException(PyObject **type, PyObject **value, PyObject **tb)
#endif
{
    PyObject *local_type = NULL, *local_value, *local_tb = NULL;
#if CYTHON_FAST_THREAD_STATE
    PyObject *tmp_type, *tmp_value, *tmp_tb;
  #if PY_VERSION_HEX >= 0x030C0000
    local_value = tstate->current_exception;
    tstate->current_exception = 0;
  #else
    local_type = tstate->curexc_type;
    local_value = tstate->curexc_value;
    local_tb = tstate->curexc_traceback;
    tstate->curexc_type = 0;
    tstate->curexc_value = 0;
    tstate->curexc_traceback = 0;
  #endif
#elif __PYX_LIMITED_VERSION_HEX > 0x030C0000
    local_value = PyErr_GetRaisedException();
#else
    PyErr_Fetch(&local_type, &local_value, &local_tb);
#endif
#if __PYX_LIMITED_VERSION_HEX > 0x030C0000
    if (likely(local_value)) {
        local_type = (PyObject*) Py_TYPE(local_value);
        Py_INCREF(local_type);
        local_tb = PyException_GetTraceback(local_value);
    }
#else
    PyErr_NormalizeException(&local_type, &local_value, &local_tb);
#if CYTHON_FAST_THREAD_STATE
    if (unlikely(tstate->curexc_type))
#else
    if (unlikely(PyErr_Occurred()))
#endif
        goto bad;
    if (local_tb) {
        if (unlikely(PyException_SetTraceback(local_value, local_tb) < 0))
            goto bad;
    }
#endif // __PYX_LIMITED_VERSION_HEX > 0x030C0000
    Py_XINCREF(local_tb);
    Py_XINCREF(local_type);
    Py_XINCREF(local_value);
    *type = local_type;
    *value = local_value;
    *tb = local_tb;
#if CYTHON_FAST_THREAD_STATE
    #if CYTHON_USE_EXC_INFO_STACK
    {
        _PyErr_StackItem *exc_info = tstate->exc_info;
      #if PY_VERSION_HEX >= 0x030B00a4
        tmp_value = exc_info->exc_value;
        exc_info->exc_value = local_value;
        tmp_type = NULL;
        tmp_tb = NULL;
        Py_XDECREF(local_type);
        Py_XDECREF(local_tb);
      #else
        tmp_type = exc_info->exc_type;
        tmp_value = exc_info->exc_value;
        tmp_tb = exc_info->exc_traceback;
        exc_info->exc_type = local_type;
        exc_info->exc_value = local_value;
        exc_info->exc_traceback = local_tb;
      #endif
    }
    #else
    tmp_type = tstate->exc_type;
    tmp_value = tstate->exc_value;
    tmp_tb = tstate->exc_traceback;
    tstate->exc_type = local_type;
    tstate->exc_value = local_value;
    tstate->exc_traceback = local_tb;
    #endif
    Py_XDECREF(tmp_type);
    Py_XDECREF(tmp_value);
    Py_XDECREF(tmp_tb);
#elif __PYX_LIMITED_VERSION_HEX >= 0x030b0000
    PyErr_SetHandledException(local_value);
    Py_XDECREF(local_value);
    Py_XDECREF(local_type);
    Py_XDECREF(local_tb);
#else
    PyErr_SetExcInfo(local_type, local_value, local_tb);
#endif
    return 0;
#if __PYX_LIMITED_VERSION_HEX <= 0x030C0000
bad:
    *type = 0;
    *value = 0;
    *tb = 0;
    Py_XDECREF(local_type);
    Py_XDECREF(local_value);
    Py_XDECREF(local_tb);
    return -1;
#endif
}


#if !CYTHON_COMPILING_IN_PYPY
static PyObject* __Pyx_Fallback___Pyx_PyLong_SubtractObjC(PyObject *op1, PyObject *op2, int inplace) {
    return (inplace ? PyNumber_InPlaceSubtract : PyNumber_Subtract)(op1, op2);
}
#if CYTHON_USE_PYLONG_INTERNALS
static PyObject* __Pyx_Unpacked___Pyx_PyLong_SubtractObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check) {
    CYTHON_MAYBE_UNUSED_VAR(inplace);
    CYTHON_UNUSED_VAR(zerodivision_check);
    const long b = intval;
    long a, x;
#ifdef HAVE_LONG_LONG
    const PY_LONG_LONG llb = intval;
    PY_LONG_LONG lla, llx;
#endif
    if (unlikely(__Pyx_PyLong_IsZero(op1))) {
        return PyLong_FromLong(-intval);
    }
    if (likely(__Pyx_PyLong_IsCompact(op1))) {
        a = __Pyx_PyLong_CompactValue(op1);
    } else {
        const digit* digits = __Pyx_PyLong_Digits(op1);
        const Py_ssize_t size = __Pyx_PyLong_SignedDigitCount(op1);
        switch (size) {
            case -2:
                if (8 * sizeof(long) - 1 > 2 * PyLong_SHIFT) {
                    a = -(long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 2 * PyLong_SHIFT) {
                    lla = -(PY_LONG_LONG) (((((unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case 2:
                if (8 * sizeof(long) - 1 > 2 * PyLong_SHIFT) {
                    a = (long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 2 * PyLong_SHIFT) {
                    lla = (PY_LONG_LONG) (((((unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case -3:
                if (8 * sizeof(long) - 1 > 3 * PyLong_SHIFT) {
                    a = -(long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 3 * PyLong_SHIFT) {
                    lla = -(PY_LONG_LONG) (((((((unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case 3:
                if (8 * sizeof(long) - 1 > 3 * PyLong_SHIFT) {
                    a = (long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 3 * PyLong_SHIFT) {
                    lla = (PY_LONG_LONG) (((((((unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case -4:
                if (8 * sizeof(long) - 1 > 4 * PyLong_SHIFT) {
                    a = -(long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 4 * PyLong_SHIFT) {
                    lla = -(PY_LONG_LONG) (((((((((unsigned PY_LONG_LONG)digits[3]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case 4:
                if (8 * sizeof(long) - 1 > 4 * PyLong_SHIFT) {
                    a = (long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 4 * PyLong_SHIFT) {
                    lla = (PY_LONG_LONG) (((((((((unsigned PY_LONG_LONG)digits[3]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            default: return PyLong_Type.tp_as_number->nb_subtract(op1, op2);
        }
    }
            x = a - b;
        return PyLong_FromLong(x);
#ifdef HAVE_LONG_LONG
    long_long:
            llx = lla - llb;
        return PyLong_FromLongLong(llx);
#endif
    return __Pyx_Fallback___Pyx_PyLong_SubtractObjC(op1, op2, inplace);
    
    
}
#endif
static PyObject* __Pyx_Float___Pyx_PyLong_SubtractObjC(PyObject *float_val, long intval, int zerodivision_check) {
    CYTHON_UNUSED_VAR(zerodivision_check);
    const long b = intval;
    double a = __Pyx_PyFloat_AS_DOUBLE(float_val);
        double result;
        
        result = ((double)a) - (double)b;
        return PyFloat_FromDouble(result);
}
static CYTHON_INLINE PyObject* __Pyx_PyLong_SubtractObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check) {
    CYTHON_MAYBE_UNUSED_VAR(intval);
    CYTHON_UNUSED_VAR(zerodivision_check);
    #if CYTHON_USE_PYLONG_INTERNALS
    if (likely(PyLong_CheckExact(op1))) {
        return __Pyx_Unpacked___Pyx_PyLong_SubtractObjC(op1, op2, intval, inplace, zerodivision_check);
    }
    #endif
    if (PyFloat_CheckExact(op1)) {
        return __Pyx_Float___Pyx_PyLong_SubtractObjC(op1, intval, zerodivision_check);
    }
    return __Pyx_Fallback___Pyx_PyLong_SubtractObjC(op1, op2, inplace);
}
#endif


#if CYTHON_VECTORCALL
static int __Pyx_VectorcallBuilder_AddArg(PyObject *key, PyObject *value, PyObject *builder, PyObject **args, int n) {
    (void)__Pyx_PyObject_FastCallDict;
    if (__Pyx_PyTuple_SET_ITEM(builder, n, key) != (0)) return -1;
    Py_INCREF(key);
    args[n] = value;
    return 0;
}
CYTHON_UNUSED static int __Pyx_VectorcallBuilder_AddArg_Check(PyObject *key, PyObject *value, PyObject *builder, PyObject **args, int n) {
    (void)__Pyx_VectorcallBuilder_AddArgStr;
    if (unlikely(!PyUnicode_Check(key))) {
        PyErr_SetString(PyExc_TypeError, "keywords must be strings");
        return -1;
    }
    return __Pyx_VectorcallBuilder_AddArg(key, value, builder, args, n);
}
static int __Pyx_VectorcallBuilder_AddArgStr(const char *key, PyObject *value, PyObject *builder, PyObject **args, int n) {
    PyObject *pyKey = PyUnicode_FromString(key);
    if (!pyKey) return -1;
    return __Pyx_VectorcallBuilder_AddArg(pyKey, value, builder, args, n);
}
#else // CYTHON_VECTORCALL
CYTHON_UNUSED static int __Pyx_VectorcallBuilder_AddArg_Check(PyObject *key, PyObject *value, PyObject *builder, CYTHON_UNUSED PyObject **args, CYTHON_UNUSED int n) {
    if (unlikely(!PyUnicode_Check(key))) {
        PyErr_SetString(PyExc_TypeError, "keywords must be strings");
        return -1;
    }
    return PyDict_SetItem(builder, key, value);
}
#endif


static PyObject* __Pyx_PyUnicode_Join(PyObject** values, Py_ssize_t value_count, Py_ssize_t result_ulength,
                                      Py_UCS4 max_char) {
#if CYTHON_USE_UNICODE_INTERNALS && CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
    PyObject *result_uval;
    int result_ukind, kind_shift;
    Py_ssize_t i, char_pos;
    void *result_udata;
    if (max_char > 1114111) max_char = 1114111;
    result_uval = PyUnicode_New(result_ulength, max_char);
    if (unlikely(!result_uval)) return NULL;
    result_ukind = (max_char <= 255) ? PyUnicode_1BYTE_KIND : (max_char <= 65535) ? PyUnicode_2BYTE_KIND : PyUnicode_4BYTE_KIND;
    kind_shift = (result_ukind == PyUnicode_4BYTE_KIND) ? 2 : result_ukind - 1;
    result_udata = PyUnicode_DATA(result_uval);
    assert(kind_shift == 2 || kind_shift == 1 || kind_shift == 0);
    if (unlikely((PY_SSIZE_T_MAX >> kind_shift) - result_ulength < 0))
        goto overflow;
    char_pos = 0;
    for (i=0; i < value_count; i++) {
        int ukind;
        Py_ssize_t ulength;
        void *udata;
        PyObject *uval = values[i];
        #if !CYTHON_COMPILING_IN_LIMITED_API
        if (__Pyx_PyUnicode_READY(uval) == (-1))
            goto bad;
        #endif
        ulength = __Pyx_PyUnicode_GET_LENGTH(uval);
        #if !CYTHON_ASSUME_SAFE_SIZE
        if (unlikely(ulength < 0)) goto bad;
        #endif
        if (unlikely(!ulength))
            continue;
        if (unlikely((PY_SSIZE_T_MAX >> kind_shift) - ulength < char_pos))
            goto overflow;
        ukind = __Pyx_PyUnicode_KIND(uval);
        udata = __Pyx_PyUnicode_DATA(uval);
        if (ukind == result_ukind) {
            memcpy((char *)result_udata + (char_pos << kind_shift), udata, (size_t) (ulength << kind_shift));
        } else {
            #if PY_VERSION_HEX >= 0x030d0000
            if (unlikely(PyUnicode_CopyCharacters(result_uval, char_pos, uval, 0, ulength) < 0)) goto bad;
            #elif CYTHON_COMPILING_IN_CPYTHON || defined(_PyUnicode_FastCopyCharacters)
            _PyUnicode_FastCopyCharacters(result_uval, char_pos, uval, 0, ulength);
            #else
            Py_ssize_t j;
            for (j=0; j < ulength; j++) {
                Py_UCS4 uchar = __Pyx_PyUnicode_READ(ukind, udata, j);
                __Pyx_PyUnicode_WRITE(result_ukind, result_udata, char_pos+j, uchar);
            }
            #endif
        }
        char_pos += ulength;
    }
    return result_uval;
overflow:
    PyErr_SetString(PyExc_OverflowError, "join() result is too long for a Python string");
bad:
    Py_DECREF(result_uval);
    return NULL;
#else
    Py_ssize_t i;
    PyObject *result = NULL;
    PyObject *value_tuple = PyTuple_New(value_count);
    if (unlikely(!value_tuple)) return NULL;
    CYTHON_UNUSED_VAR(max_char);
    CYTHON_UNUSED_VAR(result_ulength);
    for (i=0; i<value_count; i++) {
        if (__Pyx_PyTuple_SET_ITEM(value_tuple, i, values[i]) != (0)) goto bad;
        Py_INCREF(values[i]);
    }
    result = PyUnicode_Join(__pyx_mstate_global->__pyx_empty_unicode, value_tuple);
bad:
    Py_DECREF(value_tuple);
    return result;
#endif
}


#if CYTHON_USE_PYTYPE_LOOKUP && CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PyObject* __Pyx__PyObject_LookupSpecial(PyObject* obj, PyObject* attr_name, int with_error) {
    PyObject *res;
    PyTypeObject *tp = Py_TYPE(obj);
    res = _PyType_Lookup(tp, attr_name);
    if (likely(res)) {
        descrgetfunc f = Py_TYPE(res)->tp_descr_get;
        if (!f) {
            Py_INCREF(res);
        } else {
            res = f(res, obj, (PyObject *)tp);
        }
    } else if (with_error) {
        PyErr_SetObject(PyExc_AttributeError, attr_name);
    }
    return res;
}
#endif


static void __Pyx_RaiseUnboundLocalError(const char *varname) {
    PyErr_Format(PyExc_UnboundLocalError, "local variable '%s' referenced before assignment", varname);
}


#if CYTHON_FAST_THREAD_STATE
static CYTHON_INLINE void __Pyx__ExceptionSwap(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb) {
    PyObject *tmp_type, *tmp_value, *tmp_tb;
  #if CYTHON_USE_EXC_INFO_STACK && PY_VERSION_HEX >= 0x030B00a4
    _PyErr_StackItem *exc_info = tstate->exc_info;
    tmp_value = exc_info->exc_value;
    exc_info->exc_value = *value;
    if (tmp_value == NULL || tmp_value == Py_None) {
        Py_XDECREF(tmp_value);
        tmp_value = NULL;
        tmp_type = NULL;
        tmp_tb = NULL;
    } else {
        tmp_type = (PyObject*) Py_TYPE(tmp_value);
        Py_INCREF(tmp_type);
        #if CYTHON_COMPILING_IN_CPYTHON
        tmp_tb = ((PyBaseExceptionObject*) tmp_value)->traceback;
        Py_XINCREF(tmp_tb);
        #else
        tmp_tb = PyException_GetTraceback(tmp_value);
        #endif
    }
  #elif CYTHON_USE_EXC_INFO_STACK
    _PyErr_StackItem *exc_info = tstate->exc_info;
    tmp_type = exc_info->exc_type;
    tmp_value = exc_info->exc_value;
    tmp_tb = exc_info->exc_traceback;
    exc_info->exc_type = *type;
    exc_info->exc_value = *value;
    exc_info->exc_traceback = *tb;
  #else
    tmp_type = tstate->exc_type;
    tmp_value = tstate->exc_value;
    tmp_tb = tstate->exc_traceback;
    tstate->exc_type = *type;
    tstate->exc_value = *value;
    tstate->exc_traceback = *tb;
  #endif
    *type = tmp_type;
    *value = tmp_value;
    *tb = tmp_tb;
}
#else
static CYTHON_INLINE void __Pyx_ExceptionSwap(PyObject **type, PyObject **value, PyObject **tb) {
    PyObject *tmp_type, *tmp_value, *tmp_tb;
    PyErr_GetExcInfo(&tmp_type, &tmp_value, &tmp_tb);
    PyErr_SetExcInfo(*type, *value, *tb);
    *type = tmp_type;
    *value = tmp_value;
    *tb = tmp_tb;
}
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallOneArg(PyObject *func, PyObject *arg) {
    PyObject *args[2] = {NULL, arg};
    return __Pyx_PyObject_FastCall(func, args+1, 1 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET);
}


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self) {
    int was_initialized = __Pyx_CachedCFunction_GetAndSetInitializing(cfunc);
    if (likely(was_initialized == 2 && cfunc->func)) {
        if (likely(cfunc->flag == METH_NOARGS))
            return __Pyx_CallCFunction(cfunc, self, NULL);
        if (likely(cfunc->flag == METH_FASTCALL))
            return __Pyx_CallCFunctionFast(cfunc, self, NULL, 0);
        if (cfunc->flag == (METH_FASTCALL | METH_KEYWORDS))
            return __Pyx_CallCFunctionFastWithKeywords(cfunc, self, NULL, 0, NULL);
        if (likely(cfunc->flag == (METH_VARARGS | METH_KEYWORDS)))
            return __Pyx_CallCFunctionWithKeywords(cfunc, self, __pyx_mstate_global->__pyx_empty_tuple, NULL);
        if (cfunc->flag == METH_VARARGS)
            return __Pyx_CallCFunction(cfunc, self, __pyx_mstate_global->__pyx_empty_tuple);
        return __Pyx__CallUnboundCMethod0(cfunc, self);
    }
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    else if (unlikely(was_initialized == 1)) {
        __Pyx_CachedCFunction tmp_cfunc = {
#ifndef __cplusplus
            0
#endif
        };
        tmp_cfunc.type = cfunc->type;
        tmp_cfunc.method_name = cfunc->method_name;
        return __Pyx__CallUnboundCMethod0(&tmp_cfunc, self);
    }
#endif
    PyObject *result = __Pyx__CallUnboundCMethod0(cfunc, self);
    __Pyx_CachedCFunction_SetFinishedInitializing(cfunc);
    return result;
}
#endif
static PyObject* __Pyx__CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self) {
    PyObject *result;
    if (unlikely(!cfunc->method) && unlikely(__Pyx_TryUnpackUnboundCMethod(cfunc) < 0)) return NULL;
    result = __Pyx_PyObject_CallOneArg(cfunc->method, self);
    return result;
}


static CYTHON_INLINE PyObject* __Pyx_PyDict_Keys(PyObject* d) {
    return __Pyx_CallUnboundCMethod0(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_keys, d);
}


static CYTHON_INLINE PyObject* __Pyx_PyUnicode_Unicode(PyObject *obj) {
    if (unlikely(obj == Py_None))
        obj = __pyx_mstate_global->__pyx_kp_u_None;
    return __Pyx_NewRef(obj);
}


static int
__Pyx_RaiseUnexpectedTypeError(const char *expected, PyObject *obj)
{
    __Pyx_TypeName obj_type_name = __Pyx_PyType_GetFullyQualifiedName(Py_TYPE(obj));
    PyErr_Format(PyExc_TypeError, "Expected %s, got " __Pyx_FMT_TYPENAME,
                 expected, obj_type_name);
    __Pyx_DECREF_TypeName(obj_type_name);
    return 0;
}


#if !CYTHON_COMPILING_IN_PYPY
static PyObject *__Pyx_PyDict_GetItem(PyObject *d, PyObject* key) {
    PyObject *value;
    if (unlikely(__Pyx_PyDict_GetItemRef(d, key, &value) == 0)) { // no value, no error
        if (unlikely(PyTuple_Check(key))) {
            PyObject* args = PyTuple_Pack(1, key);
            if (likely(args)) {
                PyErr_SetObject(PyExc_KeyError, args);
                Py_DECREF(args);
            }
        } else {
            PyErr_SetObject(PyExc_KeyError, key);
        }
    }
    return value;
}
#endif


#if !CYTHON_VECTORCALL || PY_VERSION_HEX < 0x03090000
static PyObject *__Pyx_Object_VectorcallMethod_CallFromBuilder(PyObject *name, PyObject *const *args, size_t nargsf, PyObject *kwnames) {
    PyObject *result;
    PyObject *obj = PyObject_GetAttr(args[0], name);
    if (unlikely(!obj))
        return NULL;
    result = __Pyx_Object_Vectorcall_CallFromBuilder(obj, args+1, nargsf-1, kwnames);
    Py_DECREF(obj);
    return result;
}
#endif


#if !CYTHON_COMPILING_IN_PYPY
static PyObject* __Pyx_Fallback___Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, int inplace) {
    return (inplace ? PyNumber_InPlaceAdd : PyNumber_Add)(op1, op2);
}
#if CYTHON_USE_PYLONG_INTERNALS
static PyObject* __Pyx_Unpacked___Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check) {
    CYTHON_MAYBE_UNUSED_VAR(inplace);
    CYTHON_UNUSED_VAR(zerodivision_check);
    const long b = intval;
    long a, x;
#ifdef HAVE_LONG_LONG
    const PY_LONG_LONG llb = intval;
    PY_LONG_LONG lla, llx;
#endif
    if (unlikely(__Pyx_PyLong_IsZero(op1))) {
        return __Pyx_NewRef(op2);
    }
    if (likely(__Pyx_PyLong_IsCompact(op1))) {
        a = __Pyx_PyLong_CompactValue(op1);
    } else {
        const digit* digits = __Pyx_PyLong_Digits(op1);
        const Py_ssize_t size = __Pyx_PyLong_SignedDigitCount(op1);
        switch (size) {
            case -2:
                if (8 * sizeof(long) - 1 > 2 * PyLong_SHIFT) {
                    a = -(long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 2 * PyLong_SHIFT) {
                    lla = -(PY_LONG_LONG) (((((unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case 2:
                if (8 * sizeof(long) - 1 > 2 * PyLong_SHIFT) {
                    a = (long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 2 * PyLong_SHIFT) {
                    lla = (PY_LONG_LONG) (((((unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case -3:
                if (8 * sizeof(long) - 1 > 3 * PyLong_SHIFT) {
                    a = -(long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 3 * PyLong_SHIFT) {
                    lla = -(PY_LONG_LONG) (((((((unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case 3:
                if (8 * sizeof(long) - 1 > 3 * PyLong_SHIFT) {
                    a = (long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 3 * PyLong_SHIFT) {
                    lla = (PY_LONG_LONG) (((((((unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case -4:
                if (8 * sizeof(long) - 1 > 4 * PyLong_SHIFT) {
                    a = -(long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 4 * PyLong_SHIFT) {
                    lla = -(PY_LONG_LONG) (((((((((unsigned PY_LONG_LONG)digits[3]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            case 4:
                if (8 * sizeof(long) - 1 > 4 * PyLong_SHIFT) {
                    a = (long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                    break;
                #ifdef HAVE_LONG_LONG
                } else if (8 * sizeof(PY_LONG_LONG) - 1 > 4 * PyLong_SHIFT) {
                    lla = (PY_LONG_LONG) (((((((((unsigned PY_LONG_LONG)digits[3]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
                    goto long_long;
                #endif
                }
                CYTHON_FALLTHROUGH;
            default: return PyLong_Type.tp_as_number->nb_add(op1, op2);
        }
    }
            x = a + b;
        return PyLong_FromLong(x);
#ifdef HAVE_LONG_LONG
    long_long:
            llx = lla + llb;
        return PyLong_FromLongLong(llx);
#endif
    return __Pyx_Fallback___Pyx_PyLong_AddObjC(op1, op2, inplace);
    
    
}
#endif
static PyObject* __Pyx_Float___Pyx_PyLong_AddObjC(PyObject *float_val, long intval, int zerodivision_check) {
    CYTHON_UNUSED_VAR(zerodivision_check);
    const long b = intval;
    double a = __Pyx_PyFloat_AS_DOUBLE(float_val);
        double result;
        
        result = ((double)a) + (double)b;
        return PyFloat_FromDouble(result);
}
static CYTHON_INLINE PyObject* __Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check) {
    CYTHON_MAYBE_UNUSED_VAR(intval);
    CYTHON_UNUSED_VAR(zerodivision_check);
    #if CYTHON_USE_PYLONG_INTERNALS
    if (likely(PyLong_CheckExact(op1))) {
        return __Pyx_Unpacked___Pyx_PyLong_AddObjC(op1, op2, intval, inplace, zerodivision_check);
    }
    #endif
    if (PyFloat_CheckExact(op1)) {
        return __Pyx_Float___Pyx_PyLong_AddObjC(op1, intval, zerodivision_check);
    }
    return __Pyx_Fallback___Pyx_PyLong_AddObjC(op1, op2, inplace);
}
#endif


# if CYTHON_COMPILING_IN_CPYTHON
static int
__Pyx_unicode_modifiable(PyObject *unicode)
{
    if (Py_REFCNT(unicode) != 1)
        return 0;
    if (!PyUnicode_CheckExact(unicode))
        return 0;
    if (PyUnicode_CHECK_INTERNED(unicode))
        return 0;
    return 1;
}
static CYTHON_INLINE PyObject *__Pyx_PyUnicode_ConcatInPlaceImpl(PyObject **p_left, PyObject *right
        #if CYTHON_REFNANNY
        , void* __pyx_refnanny
        #endif
    ) {
    PyObject *left = *p_left;
    Py_ssize_t left_len, right_len, new_len;
    if (unlikely(__Pyx_PyUnicode_READY(left) == -1))
        return NULL;
    if (unlikely(__Pyx_PyUnicode_READY(right) == -1))
        return NULL;
    left_len = PyUnicode_GET_LENGTH(left);
    if (left_len == 0) {
        Py_INCREF(right);
        return right;
    }
    right_len = PyUnicode_GET_LENGTH(right);
    if (right_len == 0) {
        Py_INCREF(left);
        return left;
    }
    if (unlikely(left_len > PY_SSIZE_T_MAX - right_len)) {
        PyErr_SetString(PyExc_OverflowError,
                        "strings are too large to concat");
        return NULL;
    }
    new_len = left_len + right_len;
    if (__Pyx_unicode_modifiable(left)
            && PyUnicode_CheckExact(right)
            && PyUnicode_KIND(right) <= PyUnicode_KIND(left)
            && !(PyUnicode_IS_ASCII(left) && !PyUnicode_IS_ASCII(right))) {
        int ret;
        __Pyx_GIVEREF(*p_left);
        ret = PyUnicode_Resize(p_left, new_len);
        __Pyx_GOTREF(*p_left);
        if (unlikely(ret != 0))
            return NULL;
        #if PY_VERSION_HEX >= 0x030d0000
        if (unlikely(PyUnicode_CopyCharacters(*p_left, left_len, right, 0, right_len) < 0)) return NULL;
        #else
        _PyUnicode_FastCopyCharacters(*p_left, left_len, right, 0, right_len);
        #endif
        __Pyx_INCREF(*p_left);
        __Pyx_GIVEREF(*p_left);
        return *p_left;
    } else {
        return __Pyx_PyUnicode_Concat(left, right);
    }
  }
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static int __Pyx_InBases(PyTypeObject *a, PyTypeObject *b) {
    while (a) {
        a = __Pyx_PyType_GetSlot(a, tp_base, PyTypeObject*);
        if (a == b)
            return 1;
    }
    return b == &PyBaseObject_Type;
}
static CYTHON_INLINE int __Pyx_IsSubtype(PyTypeObject *a, PyTypeObject *b) {
    PyObject *mro;
    if (a == b) return 1;
    mro = a->tp_mro;
    if (likely(mro)) {
        Py_ssize_t i, n;
        n = PyTuple_GET_SIZE(mro);
        for (i = 0; i < n; i++) {
            if (PyTuple_GET_ITEM(mro, i) == (PyObject *)b)
                return 1;
        }
        return 0;
    }
    return __Pyx_InBases(a, b);
}
static CYTHON_INLINE int __Pyx_IsAnySubtype2(PyTypeObject *cls, PyTypeObject *a, PyTypeObject *b) {
    PyObject *mro;
    if (cls == a || cls == b) return 1;
    mro = cls->tp_mro;
    if (likely(mro)) {
        Py_ssize_t i, n;
        n = PyTuple_GET_SIZE(mro);
        for (i = 0; i < n; i++) {
            PyObject *base = PyTuple_GET_ITEM(mro, i);
            if (base == (PyObject *)a || base == (PyObject *)b)
                return 1;
        }
        return 0;
    }
    return __Pyx_InBases(cls, a) || __Pyx_InBases(cls, b);
}
static CYTHON_INLINE int __Pyx_inner_PyErr_GivenExceptionMatches2(PyObject *err, PyObject* exc_type1, PyObject *exc_type2) {
    if (exc_type1) {
        return __Pyx_IsAnySubtype2((PyTypeObject*)err, (PyTypeObject*)exc_type1, (PyTypeObject*)exc_type2);
    } else {
        return __Pyx_IsSubtype((PyTypeObject*)err, (PyTypeObject*)exc_type2);
    }
}
static int __Pyx_PyErr_GivenExceptionMatchesTuple(PyObject *exc_type, PyObject *tuple) {
    Py_ssize_t i, n;
    assert(PyExceptionClass_Check(exc_type));
    n = PyTuple_GET_SIZE(tuple);
    for (i=0; i<n; i++) {
        if (exc_type == PyTuple_GET_ITEM(tuple, i)) return 1;
    }
    for (i=0; i<n; i++) {
        PyObject *t = PyTuple_GET_ITEM(tuple, i);
        if (likely(PyExceptionClass_Check(t))) {
            if (__Pyx_inner_PyErr_GivenExceptionMatches2(exc_type, NULL, t)) return 1;
        } else {
        }
    }
    return 0;
}
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches(PyObject *err, PyObject* exc_type) {
    if (likely(err == exc_type)) return 1;
    if (likely(PyExceptionClass_Check(err))) {
        if (likely(PyExceptionClass_Check(exc_type))) {
            return __Pyx_inner_PyErr_GivenExceptionMatches2(err, NULL, exc_type);
        } else if (likely(PyTuple_Check(exc_type))) {
            return __Pyx_PyErr_GivenExceptionMatchesTuple(err, exc_type);
        } else {
        }
    }
    return PyErr_GivenExceptionMatches(err, exc_type);
}
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches2(PyObject *err, PyObject *exc_type1, PyObject *exc_type2) {
    assert(PyExceptionClass_Check(exc_type1));
    assert(PyExceptionClass_Check(exc_type2));
    if (likely(err == exc_type1 || err == exc_type2)) return 1;
    if (likely(PyExceptionClass_Check(err))) {
        return __Pyx_inner_PyErr_GivenExceptionMatches2(err, exc_type1, exc_type2);
    }
    return (PyErr_GivenExceptionMatches(err, exc_type1) || PyErr_GivenExceptionMatches(err, exc_type2));
}
#endif


static PyObject *__Pyx_GetItemInt_Generic(PyObject *o, PyObject* j) {
    PyObject *r;
    if (unlikely(!j)) return NULL;
    r = PyObject_GetItem(o, j);
    Py_DECREF(j);
    return r;
}
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_List_Fast(PyObject *o, Py_ssize_t i,
                                                              CYTHON_NCP_UNUSED int wraparound,
                                                              CYTHON_NCP_UNUSED int boundscheck) {
#if CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE && !CYTHON_AVOID_BORROWED_REFS && !CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
    Py_ssize_t wrapped_i = i;
    if (wraparound & unlikely(i < 0)) {
        wrapped_i += PyList_GET_SIZE(o);
    }
    if ((!boundscheck) || likely(__Pyx_is_valid_index(wrapped_i, PyList_GET_SIZE(o)))) {
        PyObject *r = PyList_GET_ITEM(o, wrapped_i);
        Py_INCREF(r);
        return r;
    }
    return __Pyx_GetItemInt_Generic(o, PyLong_FromSsize_t(i));
#else
    return PySequence_GetItem(o, i);
#endif
}
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Tuple_Fast(PyObject *o, Py_ssize_t i,
                                                              CYTHON_NCP_UNUSED int wraparound,
                                                              CYTHON_NCP_UNUSED int boundscheck) {
#if CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE && !CYTHON_AVOID_BORROWED_REFS
    Py_ssize_t wrapped_i = i;
    if (wraparound & unlikely(i < 0)) {
        wrapped_i += PyTuple_GET_SIZE(o);
    }
    if ((!boundscheck) || likely(__Pyx_is_valid_index(wrapped_i, PyTuple_GET_SIZE(o)))) {
        PyObject *r = PyTuple_GET_ITEM(o, wrapped_i);
        Py_INCREF(r);
        return r;
    }
    return __Pyx_GetItemInt_Generic(o, PyLong_FromSsize_t(i));
#else
    return PySequence_GetItem(o, i);
#endif
}
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Fast(PyObject *o, Py_ssize_t i, int is_list,
                                                     CYTHON_NCP_UNUSED int wraparound,
                                                     CYTHON_NCP_UNUSED int boundscheck) {
#if CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE && !CYTHON_AVOID_BORROWED_REFS && CYTHON_USE_TYPE_SLOTS
    if (is_list || PyList_CheckExact(o)) {
        Py_ssize_t n = ((!wraparound) | likely(i >= 0)) ? i : i + PyList_GET_SIZE(o);
        if ((!boundscheck) || (likely(__Pyx_is_valid_index(n, PyList_GET_SIZE(o))))) {
            return __Pyx_PyList_GetItemRef(o, n);
        }
    }
    else if (PyTuple_CheckExact(o)) {
        Py_ssize_t n = ((!wraparound) | likely(i >= 0)) ? i : i + PyTuple_GET_SIZE(o);
        if ((!boundscheck) || likely(__Pyx_is_valid_index(n, PyTuple_GET_SIZE(o)))) {
            PyObject *r = PyTuple_GET_ITEM(o, n);
            Py_INCREF(r);
            return r;
        }
    } else {
        PyMappingMethods *mm = Py_TYPE(o)->tp_as_mapping;
        PySequenceMethods *sm = Py_TYPE(o)->tp_as_sequence;
        if (mm && mm->mp_subscript) {
            PyObject *r, *key = PyLong_FromSsize_t(i);
            if (unlikely(!key)) return NULL;
            r = mm->mp_subscript(o, key);
            Py_DECREF(key);
            return r;
        }
        if (likely(sm && sm->sq_item)) {
            if (wraparound && unlikely(i < 0) && likely(sm->sq_length)) {
                Py_ssize_t l = sm->sq_length(o);
                if (likely(l >= 0)) {
                    i += l;
                } else {
                    if (!PyErr_ExceptionMatches(PyExc_OverflowError))
                        return NULL;
                    PyErr_Clear();
                }
            }
            return sm->sq_item(o, i);
        }
    }
#else
    if (is_list || !PyMapping_Check(o)) {
        return PySequence_GetItem(o, i);
    }
#endif
    return __Pyx_GetItemInt_Generic(o, PyLong_FromSsize_t(i));
}


static CYTHON_INLINE PyObject* __Pyx_PyDict_Values(PyObject* d) {
    return __Pyx_CallUnboundCMethod0(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_values, d);
}


#if !CYTHON_PEP489_MULTI_PHASE_INIT
static int __Pyx_SetPackagePathFromImportLib(PyObject *module_name) {
    PyObject *importlib, *osmod, *ossep, *parts, *package_path;
    PyObject *file_path = NULL;
    PyObject *item;
    int result;
    PyObject *spec;
    importlib = PyImport_ImportModule("importlib.util");
    if (unlikely(!importlib))
        goto bad;
    spec = PyObject_CallMethod(importlib, "find_spec", "(O)", module_name);
    Py_DECREF(importlib);
    if (unlikely(!spec))
        goto bad;
    file_path = PyObject_GetAttrString(spec, "origin");
    Py_DECREF(spec);
    if (unlikely(!file_path))
        goto bad;
    if (unlikely(PyObject_SetAttrString(__pyx_m, "__file__", file_path) < 0))
        goto bad;
    osmod = PyImport_ImportModule("os");
    if (unlikely(!osmod))
        goto bad;
    ossep = PyObject_GetAttrString(osmod, "sep");
    Py_DECREF(osmod);
    if (unlikely(!ossep))
        goto bad;
    parts = PyObject_CallMethod(file_path, "rsplit", "(Oi)", ossep, 1);
    Py_DECREF(file_path); file_path = NULL;
    Py_DECREF(ossep);
    if (unlikely(!parts))
        goto bad;
#if CYTHON_ASSUME_SAFE_MACROS
    package_path = Py_BuildValue("[O]", PyList_GET_ITEM(parts, 0));
#else
    item = PyList_GetItem(parts, 0);
    if (unlikely(!item))
        goto bad;
    package_path = Py_BuildValue("[O]", item);
#endif
    Py_DECREF(parts);
    if (unlikely(!package_path))
        goto bad;
    goto set_path;
bad:
    PyErr_WriteUnraisable(module_name);
    Py_XDECREF(file_path);
    PyErr_Clear();
    package_path = PyList_New(0);
    if (unlikely(!package_path))
        return -1;
set_path:
    result = PyObject_SetAttrString(__pyx_m, "__path__", package_path);
    Py_DECREF(package_path);
    return result;
}
#endif


static PyObject *__Pyx_Import(PyObject *name, PyObject *from_list, int level) {
    PyObject *module = 0;
    PyObject *empty_dict = 0;
    PyObject *empty_list = 0;
    empty_dict = PyDict_New();
    if (unlikely(!empty_dict))
        goto bad;
    if (level == -1) {
        const char* package_sep = strchr(__Pyx_MODULE_NAME, '.');
        if (package_sep != (0)) {
            module = PyImport_ImportModuleLevelObject(
                name, __pyx_mstate_global->__pyx_d, empty_dict, from_list, 1);
            if (unlikely(!module)) {
                if (unlikely(!PyErr_ExceptionMatches(PyExc_ImportError)))
                    goto bad;
                PyErr_Clear();
            }
        }
        level = 0;
    }
    if (!module) {
        module = PyImport_ImportModuleLevelObject(
            name, __pyx_mstate_global->__pyx_d, empty_dict, from_list, level);
    }
bad:
    Py_XDECREF(empty_dict);
    Py_XDECREF(empty_list);
    return module;
}


static PyObject *__Pyx__ImportDottedModule_Error(PyObject *name, PyObject *parts_tuple, Py_ssize_t count) {
    PyObject *partial_name = NULL, *slice = NULL, *sep = NULL;
    Py_ssize_t size;
    if (unlikely(PyErr_Occurred())) {
        PyErr_Clear();
    }
#if CYTHON_ASSUME_SAFE_SIZE
    size = PyTuple_GET_SIZE(parts_tuple);
#else
    size = PyTuple_Size(parts_tuple);
    if (size < 0) goto bad;
#endif
    if (likely(size == count)) {
        partial_name = name;
    } else {
        slice = PySequence_GetSlice(parts_tuple, 0, count);
        if (unlikely(!slice))
            goto bad;
        sep = PyUnicode_FromStringAndSize(".", 1);
        if (unlikely(!sep))
            goto bad;
        partial_name = PyUnicode_Join(sep, slice);
    }
    PyErr_Format(
        PyExc_ModuleNotFoundError,
        "No module named '%U'", partial_name);
bad:
    Py_XDECREF(sep);
    Py_XDECREF(slice);
    Py_XDECREF(partial_name);
    return NULL;
}
static PyObject *__Pyx__ImportDottedModule_Lookup(PyObject *name) {
    PyObject *imported_module;
#if (CYTHON_COMPILING_IN_PYPY && PYPY_VERSION_NUM  < 0x07030400) ||\
        CYTHON_COMPILING_IN_GRAAL
    PyObject *modules = PyImport_GetModuleDict();
    if (unlikely(!modules))
        return NULL;
    imported_module = __Pyx_PyDict_GetItemStr(modules, name);
    Py_XINCREF(imported_module);
#else
    imported_module = PyImport_GetModule(name);
#endif
    return imported_module;
}
static PyObject *__Pyx_ImportDottedModule_WalkParts(PyObject *module, PyObject *name, PyObject *parts_tuple) {
    Py_ssize_t i, nparts;
#if CYTHON_ASSUME_SAFE_SIZE
    nparts = PyTuple_GET_SIZE(parts_tuple);
#else
    nparts = PyTuple_Size(parts_tuple);
    if (nparts < 0) return NULL;
#endif
    for (i=1; i < nparts && module; i++) {
        PyObject *part, *submodule;
#if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
        part = PyTuple_GET_ITEM(parts_tuple, i);
#else
        part = __Pyx_PySequence_ITEM(parts_tuple, i);
        if (!part) return NULL;
#endif
        submodule = __Pyx_PyObject_GetAttrStrNoError(module, part);
#if !(CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS)
        Py_DECREF(part);
#endif
        Py_DECREF(module);
        module = submodule;
    }
    if (unlikely(!module)) {
        return __Pyx__ImportDottedModule_Error(name, parts_tuple, i);
    }
    return module;
}
static PyObject *__Pyx__ImportDottedModule(PyObject *name, PyObject *parts_tuple) {
    PyObject *imported_module;
    PyObject *module = __Pyx_Import(name, NULL, 0);
    if (!parts_tuple || unlikely(!module))
        return module;
    imported_module = __Pyx__ImportDottedModule_Lookup(name);
    if (likely(imported_module)) {
        Py_DECREF(module);
        return imported_module;
    }
    PyErr_Clear();
    return __Pyx_ImportDottedModule_WalkParts(module, name, parts_tuple);
}
static PyObject *__Pyx_ImportDottedModule(PyObject *name, PyObject *parts_tuple) {
#if CYTHON_COMPILING_IN_CPYTHON
    PyObject *module = __Pyx__ImportDottedModule_Lookup(name);
    if (likely(module)) {
        PyObject *spec = __Pyx_PyObject_GetAttrStrNoError(module, __pyx_mstate_global->__pyx_n_u_spec);
        if (likely(spec)) {
            PyObject *unsafe = __Pyx_PyObject_GetAttrStrNoError(spec, __pyx_mstate_global->__pyx_n_u_initializing);
            if (likely(!unsafe || !__Pyx_PyObject_IsTrue(unsafe))) {
                Py_DECREF(spec);
                spec = NULL;
            }
            Py_XDECREF(unsafe);
        }
        if (likely(!spec)) {
            PyErr_Clear();
            return module;
        }
        Py_DECREF(spec);
        Py_DECREF(module);
    } else if (PyErr_Occurred()) {
        PyErr_Clear();
    }
#endif
    return __Pyx__ImportDottedModule(name, parts_tuple);
}


static PyObject *__Pyx_PyList_Pack(Py_ssize_t n, ...) {
    va_list va;
    PyObject *l = PyList_New(n);
    va_start(va, n);
    if (unlikely(!l)) goto end;
    for (Py_ssize_t i=0; i<n; ++i) {
        PyObject *arg = va_arg(va, PyObject*);
        Py_INCREF(arg);
        if (__Pyx_PyList_SET_ITEM(l, i, arg) != (0)) {
            Py_CLEAR(l);
            goto end;
        }
    }
    end:
    va_end(va);
    return l;
}


static PyObject* __Pyx_ImportFrom(PyObject* module, PyObject* name) {
    PyObject* value = __Pyx_PyObject_GetAttrStr(module, name);
    if (unlikely(!value) && PyErr_ExceptionMatches(PyExc_AttributeError)) {
        const char* module_name_str = 0;
        PyObject* module_name = 0;
        PyObject* module_dot = 0;
        PyObject* full_name = 0;
        PyErr_Clear();
        module_name_str = PyModule_GetName(module);
        if (unlikely(!module_name_str)) { goto modbad; }
        module_name = PyUnicode_FromString(module_name_str);
        if (unlikely(!module_name)) { goto modbad; }
        module_dot = PyUnicode_Concat(module_name, __pyx_mstate_global->__pyx_kp_u__16);
        if (unlikely(!module_dot)) { goto modbad; }
        full_name = PyUnicode_Concat(module_dot, name);
        if (unlikely(!full_name)) { goto modbad; }
        #if (CYTHON_COMPILING_IN_PYPY && PYPY_VERSION_NUM  < 0x07030400) ||\
                CYTHON_COMPILING_IN_GRAAL
        {
            PyObject *modules = PyImport_GetModuleDict();
            if (unlikely(!modules))
                goto modbad;
            value = PyObject_GetItem(modules, full_name);
        }
        #else
        value = PyImport_GetModule(full_name);
        #endif
      modbad:
        Py_XDECREF(full_name);
        Py_XDECREF(module_dot);
        Py_XDECREF(module_name);
    }
    if (unlikely(!value)) {
        PyErr_Format(PyExc_ImportError, "cannot import name %S", name);
    }
    return value;
}


#if CYTHON_COMPILING_IN_LIMITED_API
static Py_ssize_t __Pyx_GetTypeDictOffset(void) {
    PyObject *tp_dictoffset_o;
    Py_ssize_t tp_dictoffset;
    tp_dictoffset_o = PyObject_GetAttrString((PyObject*)(&PyType_Type), "__dictoffset__");
    if (unlikely(!tp_dictoffset_o)) return -1;
    tp_dictoffset = PyLong_AsSsize_t(tp_dictoffset_o);
    Py_DECREF(tp_dictoffset_o);
    if (unlikely(tp_dictoffset == 0)) {
        PyErr_SetString(
            PyExc_TypeError,
            "'type' doesn't have a dictoffset");
        return -1;
    } else if (unlikely(tp_dictoffset < 0)) {
        PyErr_SetString(
            PyExc_TypeError,
            "'type' has an unexpected negative dictoffset. "
            "Please report this as Cython bug");
        return -1;
    }
    return tp_dictoffset;
}
static PyObject *__Pyx_GetTypeDict(PyTypeObject *tp) {
    static Py_ssize_t tp_dictoffset = 0;
    if (unlikely(tp_dictoffset == 0)) {
        tp_dictoffset = __Pyx_GetTypeDictOffset();
        if (unlikely(tp_dictoffset == -1 && PyErr_Occurred())) {
            tp_dictoffset = 0; // try again next time?
            return NULL;
        }
    }
    return *(PyObject**)((char*)tp + tp_dictoffset);
}
#endif


static int __Pyx__SetItemOnTypeDict(PyTypeObject *tp, PyObject *k, PyObject *v) {
    int result;
    PyObject *tp_dict;
#if CYTHON_COMPILING_IN_LIMITED_API
    tp_dict = __Pyx_GetTypeDict(tp);
    if (unlikely(!tp_dict)) return -1;
#else
    tp_dict = tp->tp_dict;
#endif
    result = PyDict_SetItem(tp_dict, k, v);
    if (likely(!result)) {
        PyType_Modified(tp);
        if (unlikely(PyObject_HasAttr(v, __pyx_mstate_global->__pyx_n_u_set_name))) {
            PyObject *setNameResult = PyObject_CallMethodObjArgs(v, __pyx_mstate_global->__pyx_n_u_set_name,  (PyObject *) tp, k, NULL);
            if (!setNameResult) return -1;
            Py_DECREF(setNameResult);
        }
    }
    return result;
}


static int __Pyx_fix_up_extension_type_from_spec(PyType_Spec *spec, PyTypeObject *type) {
#if __PYX_LIMITED_VERSION_HEX > 0x030900B1
    CYTHON_UNUSED_VAR(spec);
    CYTHON_UNUSED_VAR(type);
    CYTHON_UNUSED_VAR(__Pyx__SetItemOnTypeDict);
#else
    const PyType_Slot *slot = spec->slots;
    int changed = 0;
#if !CYTHON_COMPILING_IN_LIMITED_API
    while (slot && slot->slot && slot->slot != Py_tp_members)
        slot++;
    if (slot && slot->slot == Py_tp_members) {
#if !CYTHON_COMPILING_IN_CPYTHON
        const
#endif  // !CYTHON_COMPILING_IN_CPYTHON)
            PyMemberDef *memb = (PyMemberDef*) slot->pfunc;
        while (memb && memb->name) {
            if (memb->name[0] == '_' && memb->name[1] == '_') {
                if (strcmp(memb->name, "__weaklistoffset__") == 0) {
                    assert(memb->type == T_PYSSIZET);
                    assert(memb->flags == READONLY);
                    type->tp_weaklistoffset = memb->offset;
                    changed = 1;
                }
                else if (strcmp(memb->name, "__dictoffset__") == 0) {
                    assert(memb->type == T_PYSSIZET);
                    assert(memb->flags == READONLY);
                    type->tp_dictoffset = memb->offset;
                    changed = 1;
                }
#if CYTHON_METH_FASTCALL
                else if (strcmp(memb->name, "__vectorcalloffset__") == 0) {
                    assert(memb->type == T_PYSSIZET);
                    assert(memb->flags == READONLY);
#if PY_VERSION_HEX >= 0x030800b4
                    type->tp_vectorcall_offset = memb->offset;
#else
                    type->tp_print = (printfunc) memb->offset;
#endif
                    changed = 1;
                }
#endif  // CYTHON_METH_FASTCALL
#if !CYTHON_COMPILING_IN_PYPY
                else if (strcmp(memb->name, "__module__") == 0) {
                    PyObject *descr;
                    assert(memb->type == T_OBJECT);
                    assert(memb->flags == 0 || memb->flags == READONLY);
                    descr = PyDescr_NewMember(type, memb);
                    if (unlikely(!descr))
                        return -1;
                    int set_item_result = PyDict_SetItem(type->tp_dict, PyDescr_NAME(descr), descr);
                    Py_DECREF(descr);
                    if (unlikely(set_item_result < 0)) {
                        return -1;
                    }
                    changed = 1;
                }
#endif  // !CYTHON_COMPILING_IN_PYPY
            }
            memb++;
        }
    }
#endif  // !CYTHON_COMPILING_IN_LIMITED_API
#if !CYTHON_COMPILING_IN_PYPY
    slot = spec->slots;
    while (slot && slot->slot && slot->slot != Py_tp_getset)
        slot++;
    if (slot && slot->slot == Py_tp_getset) {
        PyGetSetDef *getset = (PyGetSetDef*) slot->pfunc;
        while (getset && getset->name) {
            if (getset->name[0] == '_' && getset->name[1] == '_' && strcmp(getset->name, "__module__") == 0) {
                PyObject *descr = PyDescr_NewGetSet(type, getset);
                if (unlikely(!descr))
                    return -1;
                #if CYTHON_COMPILING_IN_LIMITED_API
                PyObject *pyname = PyUnicode_FromString(getset->name);
                if (unlikely(!pyname)) {
                    Py_DECREF(descr);
                    return -1;
                }
                int set_item_result = __Pyx_SetItemOnTypeDict(type, pyname, descr);
                Py_DECREF(pyname);
                #else
                CYTHON_UNUSED_VAR(__Pyx__SetItemOnTypeDict);
                int set_item_result = PyDict_SetItem(type->tp_dict, PyDescr_NAME(descr), descr);
                #endif
                Py_DECREF(descr);
                if (unlikely(set_item_result < 0)) {
                    return -1;
                }
                changed = 1;
            }
            ++getset;
        }
    }
#endif  // !CYTHON_COMPILING_IN_PYPY
    if (changed)
        PyType_Modified(type);
#endif  // PY_VERSION_HEX > 0x030900B1
    return 0;
}


static PyObject *__Pyx_FetchSharedCythonABIModule(void) {
    return __Pyx_PyImport_AddModuleRef(__PYX_ABI_MODULE_NAME);
}


static CYTHON_INLINE PyObject *__Pyx_PyDict_SetDefault(PyObject *d, PyObject *key, PyObject *default_value,
                                                       int is_safe_type) {
    PyObject* value;
    CYTHON_MAYBE_UNUSED_VAR(is_safe_type);
#if CYTHON_COMPILING_IN_LIMITED_API
    value = PyObject_CallMethod(d, "setdefault", "OO", key, default_value);
#elif PY_VERSION_HEX >= 0x030d0000
    PyDict_SetDefaultRef(d, key, default_value, &value);
#else
    value = PyDict_SetDefault(d, key, default_value);
    if (unlikely(!value)) return NULL;
    Py_INCREF(value);
#endif
    return value;
}


#if __PYX_LIMITED_VERSION_HEX < 0x030C0000
static PyObject* __Pyx_PyType_FromMetaclass(PyTypeObject *metaclass, PyObject *module, PyType_Spec *spec, PyObject *bases) {
    PyObject *result = __Pyx_PyType_FromModuleAndSpec(module, spec, bases);
    if (result && metaclass) {
        PyObject *old_tp = (PyObject*)Py_TYPE(result);
    Py_INCREF((PyObject*)metaclass);
#if __PYX_LIMITED_VERSION_HEX >= 0x03090000
        Py_SET_TYPE(result, metaclass);
#else
        result->ob_type = metaclass;
#endif
        Py_DECREF(old_tp);
    }
    return result;
}
#else
#define __Pyx_PyType_FromMetaclass(me, mo, s, b) PyType_FromMetaclass(me, mo, s, b)
#endif
static int __Pyx_VerifyCachedType(PyObject *cached_type,
                               const char *name,
                               Py_ssize_t expected_basicsize) {
    Py_ssize_t basicsize;
    if (!PyType_Check(cached_type)) {
        PyErr_Format(PyExc_TypeError,
            "Shared Cython type %.200s is not a type object", name);
        return -1;
    }
    if (expected_basicsize == 0) {
        return 0; // size is inherited, nothing useful to check
    }
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *py_basicsize;
    py_basicsize = PyObject_GetAttrString(cached_type, "__basicsize__");
    if (unlikely(!py_basicsize)) return -1;
    basicsize = PyLong_AsSsize_t(py_basicsize);
    Py_DECREF(py_basicsize);
    py_basicsize = NULL;
    if (unlikely(basicsize == (Py_ssize_t)-1) && PyErr_Occurred()) return -1;
#else
    basicsize = ((PyTypeObject*) cached_type)->tp_basicsize;
#endif
    if (basicsize != expected_basicsize) {
        PyErr_Format(PyExc_TypeError,
            "Shared Cython type %.200s has the wrong size, try recompiling",
            name);
        return -1;
    }
    return 0;
}
static PyTypeObject *__Pyx_FetchCommonTypeFromSpec(PyTypeObject *metaclass, PyObject *module, PyType_Spec *spec, PyObject *bases) {
    PyObject *abi_module = NULL, *cached_type = NULL, *abi_module_dict, *new_cached_type, *py_object_name;
    int get_item_ref_result;
    const char* object_name = strrchr(spec->name, '.');
    object_name = object_name ? object_name+1 : spec->name;
    py_object_name = PyUnicode_FromString(object_name);
    if (!py_object_name) return NULL;
    abi_module = __Pyx_FetchSharedCythonABIModule();
    if (!abi_module) goto done;
    abi_module_dict = PyModule_GetDict(abi_module);
    if (!abi_module_dict) goto done;
    get_item_ref_result = __Pyx_PyDict_GetItemRef(abi_module_dict, py_object_name, &cached_type);
    if (get_item_ref_result == 1) {
        if (__Pyx_VerifyCachedType(
              cached_type,
              object_name,
              spec->basicsize) < 0) {
            goto bad;
        }
        goto done;
    } else if (unlikely(get_item_ref_result == -1)) {
        goto bad;
    }
    CYTHON_UNUSED_VAR(module);
    cached_type = __Pyx_PyType_FromMetaclass(metaclass, abi_module, spec, bases);
    if (unlikely(!cached_type)) goto bad;
    if (unlikely(__Pyx_fix_up_extension_type_from_spec(spec, (PyTypeObject *) cached_type) < 0)) goto bad;
    new_cached_type = __Pyx_PyDict_SetDefault(abi_module_dict, py_object_name, cached_type, 1);
    if (unlikely(new_cached_type != cached_type)) {
        if (unlikely(!new_cached_type)) goto bad;
        Py_DECREF(cached_type);
        cached_type = new_cached_type;
        if (__Pyx_VerifyCachedType(
                cached_type,
                object_name,
                spec->basicsize) < 0) {
            goto bad;
        }
        goto done;
    } else {
        Py_DECREF(new_cached_type);
    }
done:
    Py_XDECREF(abi_module);
    Py_DECREF(py_object_name);
    assert(cached_type == NULL || PyType_Check(cached_type));
    return (PyTypeObject *) cached_type;
bad:
    Py_XDECREF(cached_type);
    cached_type = NULL;
    goto done;
}


static PyObject* __pyx_CommonTypesMetaclass_get_module(CYTHON_UNUSED PyObject *self, CYTHON_UNUSED void* context) {
    return PyUnicode_FromString(__PYX_ABI_MODULE_NAME);
}
static PyGetSetDef __pyx_CommonTypesMetaclass_getset[] = {
    {"__module__", __pyx_CommonTypesMetaclass_get_module, NULL, NULL, NULL},
    {0, 0, 0, 0, 0}
};
static PyType_Slot __pyx_CommonTypesMetaclass_slots[] = {
    {Py_tp_getset, (void *)__pyx_CommonTypesMetaclass_getset},
    {0, 0}
};
static PyType_Spec __pyx_CommonTypesMetaclass_spec = {
    __PYX_TYPE_MODULE_PREFIX "_common_types_metatype",
    0,
    0,
#if PY_VERSION_HEX >= 0x030A0000
    Py_TPFLAGS_IMMUTABLETYPE |
    Py_TPFLAGS_DISALLOW_INSTANTIATION |
#endif
    Py_TPFLAGS_DEFAULT,
    __pyx_CommonTypesMetaclass_slots
};
static int __pyx_CommonTypesMetaclass_init(PyObject *module) {
    __pyx_mstatetype *mstate = __Pyx_PyModule_GetState(module);
    PyObject *bases = PyTuple_Pack(1, &PyType_Type);
    if (unlikely(!bases)) {
        return -1;
    }
    mstate->__pyx_CommonTypesMetaclassType = __Pyx_FetchCommonTypeFromSpec(NULL, module, &__pyx_CommonTypesMetaclass_spec, bases);
    Py_DECREF(bases);
    if (unlikely(mstate->__pyx_CommonTypesMetaclassType == NULL)) {
        return -1;
    }
    return 0;
}


#if !CYTHON_USE_TYPE_SPECS || (!CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX < 0x03090000)
#else
static int __Pyx_call_type_traverse(PyObject *o, int always_call, visitproc visit, void *arg) {
    #if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x03090000
    if (__Pyx_get_runtime_version() < 0x03090000) return 0;
    #endif
    if (!always_call) {
        PyTypeObject *base = __Pyx_PyObject_GetSlot(o, tp_base, PyTypeObject*);
        unsigned long flags = PyType_GetFlags(base);
        if (flags & Py_TPFLAGS_HEAPTYPE) {
            return 0;
        }
    }
    Py_VISIT((PyObject*)Py_TYPE(o));
    return 0;
}
#endif


#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject *__Pyx_PyMethod_New(PyObject *func, PyObject *self, PyObject *typ) {
    PyObject *result;
    CYTHON_UNUSED_VAR(typ);
    if (!self)
        return __Pyx_NewRef(func);
    #if __PYX_LIMITED_VERSION_HEX >= 0x030C0000
    {
        PyObject *args[] = {func, self};
        result = PyObject_Vectorcall(__pyx_mstate_global->__Pyx_CachedMethodType, args, 2, NULL);
    }
    #else
    result = PyObject_CallFunctionObjArgs(__pyx_mstate_global->__Pyx_CachedMethodType, func, self, NULL);
    #endif
    return result;
}
#else
static PyObject *__Pyx_PyMethod_New(PyObject *func, PyObject *self, PyObject *typ) {
    CYTHON_UNUSED_VAR(typ);
    if (!self)
        return __Pyx_NewRef(func);
    return PyMethod_New(func, self);
}
#endif


#if CYTHON_METH_FASTCALL && (CYTHON_VECTORCALL || CYTHON_BACKPORT_VECTORCALL)
static PyObject *__Pyx_PyVectorcall_FastCallDict_kw(PyObject *func, __pyx_vectorcallfunc vc, PyObject *const *args, size_t nargs, PyObject *kw)
{
    PyObject *res = NULL;
    PyObject *kwnames;
    PyObject **newargs;
    PyObject **kwvalues;
    Py_ssize_t i, pos;
    size_t j;
    PyObject *key, *value;
    unsigned long keys_are_strings;
    #if !CYTHON_ASSUME_SAFE_SIZE
    Py_ssize_t nkw = PyDict_Size(kw);
    if (unlikely(nkw == -1)) return NULL;
    #else
    Py_ssize_t nkw = PyDict_GET_SIZE(kw);
    #endif
    newargs = (PyObject **)PyMem_Malloc((nargs + (size_t)nkw) * sizeof(args[0]));
    if (unlikely(newargs == NULL)) {
        PyErr_NoMemory();
        return NULL;
    }
    for (j = 0; j < nargs; j++) newargs[j] = args[j];
    kwnames = PyTuple_New(nkw);
    if (unlikely(kwnames == NULL)) {
        PyMem_Free(newargs);
        return NULL;
    }
    kwvalues = newargs + nargs;
    pos = i = 0;
    keys_are_strings = Py_TPFLAGS_UNICODE_SUBCLASS;
    while (PyDict_Next(kw, &pos, &key, &value)) {
        keys_are_strings &=
        #if CYTHON_COMPILING_IN_LIMITED_API
            PyType_GetFlags(Py_TYPE(key));
        #else
            Py_TYPE(key)->tp_flags;
        #endif
        Py_INCREF(key);
        Py_INCREF(value);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(PyTuple_SetItem(kwnames, i, key) < 0)) goto cleanup;
        #else
        PyTuple_SET_ITEM(kwnames, i, key);
        #endif
        kwvalues[i] = value;
        i++;
    }
    if (unlikely(!keys_are_strings)) {
        PyErr_SetString(PyExc_TypeError, "keywords must be strings");
        goto cleanup;
    }
    res = vc(func, newargs, nargs, kwnames);
cleanup:
    Py_DECREF(kwnames);
    for (i = 0; i < nkw; i++)
        Py_DECREF(kwvalues[i]);
    PyMem_Free(newargs);
    return res;
}
static CYTHON_INLINE PyObject *__Pyx_PyVectorcall_FastCallDict(PyObject *func, __pyx_vectorcallfunc vc, PyObject *const *args, size_t nargs, PyObject *kw)
{
    Py_ssize_t kw_size =
        likely(kw == NULL) ?
        0 :
#if !CYTHON_ASSUME_SAFE_SIZE
        PyDict_Size(kw);
#else
        PyDict_GET_SIZE(kw);
#endif
    if (kw_size == 0) {
        return vc(func, args, nargs, NULL);
    }
#if !CYTHON_ASSUME_SAFE_SIZE
    else if (unlikely(kw_size == -1)) {
        return NULL;
    }
#endif
    return __Pyx_PyVectorcall_FastCallDict_kw(func, vc, args, nargs, kw);
}
#endif


#if CYTHON_COMPILING_IN_LIMITED_API
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunctionNoMethod(PyObject *func, void (*cfunc)(void)) {
    if (__Pyx_CyFunction_Check(func)) {
        return PyCFunction_GetFunction(((__pyx_CyFunctionObject*)func)->func) == (PyCFunction) cfunc;
    } else if (PyCFunction_Check(func)) {
        return PyCFunction_GetFunction(func) == (PyCFunction) cfunc;
    }
    return 0;
}
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunction(PyObject *func, void (*cfunc)(void)) {
    if ((PyObject*)Py_TYPE(func) == __pyx_mstate_global->__Pyx_CachedMethodType) {
        int result;
        PyObject *newFunc = PyObject_GetAttr(func, __pyx_mstate_global->__pyx_n_u_func);
        if (unlikely(!newFunc)) {
            PyErr_Clear(); // It's only an optimization, so don't throw an error
            return 0;
        }
        result = __Pyx__IsSameCyOrCFunctionNoMethod(newFunc, cfunc);
        Py_DECREF(newFunc);
        return result;
    }
    return __Pyx__IsSameCyOrCFunctionNoMethod(func, cfunc);
}
#else
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunction(PyObject *func, void (*cfunc)(void)) {
    if (PyMethod_Check(func)) {
        func = PyMethod_GET_FUNCTION(func);
    }
    return __Pyx_CyOrPyCFunction_Check(func) && __Pyx_CyOrPyCFunction_GET_FUNCTION(func) == (PyCFunction) cfunc;
}
#endif
static CYTHON_INLINE void __Pyx__CyFunction_SetClassObj(__pyx_CyFunctionObject* f, PyObject* classobj) {
#if PY_VERSION_HEX < 0x030900B1 || CYTHON_COMPILING_IN_LIMITED_API
    __Pyx_Py_XDECREF_SET(
        __Pyx_CyFunction_GetClassObj(f),
            ((classobj) ? __Pyx_NewRef(classobj) : NULL));
#else
    __Pyx_Py_XDECREF_SET(
        ((PyCMethodObject *) (f))->mm_class,
        (PyTypeObject*)((classobj) ? __Pyx_NewRef(classobj) : NULL));
#endif
}
static PyObject *
__Pyx_CyFunction_get_doc_locked(__pyx_CyFunctionObject *op)
{
    if (unlikely(op->func_doc == NULL)) {
#if CYTHON_COMPILING_IN_LIMITED_API
        op->func_doc = PyObject_GetAttrString(op->func, "__doc__");
        if (unlikely(!op->func_doc)) return NULL;
#else
        if (((PyCFunctionObject*)op)->m_ml->ml_doc) {
            op->func_doc = PyUnicode_FromString(((PyCFunctionObject*)op)->m_ml->ml_doc);
            if (unlikely(op->func_doc == NULL))
                return NULL;
        } else {
            Py_INCREF(Py_None);
            return Py_None;
        }
#endif
    }
    Py_INCREF(op->func_doc);
    return op->func_doc;
}
static PyObject *
__Pyx_CyFunction_get_doc(__pyx_CyFunctionObject *op, void *closure) {
    PyObject *result;
    CYTHON_UNUSED_VAR(closure);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_doc_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_doc(__pyx_CyFunctionObject *op, PyObject *value, void *context)
{
    CYTHON_UNUSED_VAR(context);
    if (value == NULL) {
        value = Py_None;
    }
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    __Pyx_Py_XDECREF_SET(op->func_doc, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_name_locked(__pyx_CyFunctionObject *op)
{
    if (unlikely(op->func_name == NULL)) {
#if CYTHON_COMPILING_IN_LIMITED_API
        op->func_name = PyObject_GetAttrString(op->func, "__name__");
#else
        op->func_name = PyUnicode_InternFromString(((PyCFunctionObject*)op)->m_ml->ml_name);
#endif
        if (unlikely(op->func_name == NULL))
            return NULL;
    }
    Py_INCREF(op->func_name);
    return op->func_name;
}
static PyObject *
__Pyx_CyFunction_get_name(__pyx_CyFunctionObject *op, void *context)
{
    PyObject *result = NULL;
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_name_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_name(__pyx_CyFunctionObject *op, PyObject *value, void *context)
{
    CYTHON_UNUSED_VAR(context);
    if (unlikely(value == NULL || !PyUnicode_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__name__ must be set to a string object");
        return -1;
    }
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    __Pyx_Py_XDECREF_SET(op->func_name, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_qualname(__pyx_CyFunctionObject *op, void *context)
{
    CYTHON_UNUSED_VAR(context);
    PyObject *result;
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    Py_INCREF(op->func_qualname);
    result = op->func_qualname;
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_qualname(__pyx_CyFunctionObject *op, PyObject *value, void *context)
{
    CYTHON_UNUSED_VAR(context);
    if (unlikely(value == NULL || !PyUnicode_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__qualname__ must be set to a string object");
        return -1;
    }
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    __Pyx_Py_XDECREF_SET(op->func_qualname, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_dict_locked(__pyx_CyFunctionObject *op)
{
    if (unlikely(op->func_dict == NULL)) {
        op->func_dict = PyDict_New();
        if (unlikely(op->func_dict == NULL))
            return NULL;
    }
    Py_INCREF(op->func_dict);
    return op->func_dict;
}
static PyObject *
__Pyx_CyFunction_get_dict(__pyx_CyFunctionObject *op, void *context)
{
    CYTHON_UNUSED_VAR(context);
    PyObject *result;
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_dict_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_dict(__pyx_CyFunctionObject *op, PyObject *value, void *context)
{
    CYTHON_UNUSED_VAR(context);
    if (unlikely(value == NULL)) {
        PyErr_SetString(PyExc_TypeError,
               "function's dictionary may not be deleted");
        return -1;
    }
    if (unlikely(!PyDict_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
               "setting function's dictionary to a non-dict");
        return -1;
    }
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    __Pyx_Py_XDECREF_SET(op->func_dict, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_globals(__pyx_CyFunctionObject *op, void *context)
{
    CYTHON_UNUSED_VAR(context);
    Py_INCREF(op->func_globals);
    return op->func_globals;
}
static PyObject *
__Pyx_CyFunction_get_closure(__pyx_CyFunctionObject *op, void *context)
{
    CYTHON_UNUSED_VAR(op);
    CYTHON_UNUSED_VAR(context);
    Py_INCREF(Py_None);
    return Py_None;
}
static PyObject *
__Pyx_CyFunction_get_code(__pyx_CyFunctionObject *op, void *context)
{
    PyObject* result = (op->func_code) ? op->func_code : Py_None;
    CYTHON_UNUSED_VAR(context);
    Py_INCREF(result);
    return result;
}
static int
__Pyx_CyFunction_init_defaults(__pyx_CyFunctionObject *op) {
    int result = 0;
    PyObject *res = op->defaults_getter((PyObject *) op);
    if (unlikely(!res))
        return -1;
    #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
    op->defaults_tuple = PyTuple_GET_ITEM(res, 0);
    Py_INCREF(op->defaults_tuple);
    op->defaults_kwdict = PyTuple_GET_ITEM(res, 1);
    Py_INCREF(op->defaults_kwdict);
    #else
    op->defaults_tuple = __Pyx_PySequence_ITEM(res, 0);
    if (unlikely(!op->defaults_tuple)) result = -1;
    else {
        op->defaults_kwdict = __Pyx_PySequence_ITEM(res, 1);
        if (unlikely(!op->defaults_kwdict)) result = -1;
    }
    #endif
    Py_DECREF(res);
    return result;
}
static int
__Pyx_CyFunction_set_defaults(__pyx_CyFunctionObject *op, PyObject* value, void *context) {
    CYTHON_UNUSED_VAR(context);
    if (!value) {
        value = Py_None;
    } else if (unlikely(value != Py_None && !PyTuple_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__defaults__ must be set to a tuple object");
        return -1;
    }
    PyErr_WarnEx(PyExc_RuntimeWarning, "changes to cyfunction.__defaults__ will not "
                 "currently affect the values used in function calls", 1);
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    __Pyx_Py_XDECREF_SET(op->defaults_tuple, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_defaults_locked(__pyx_CyFunctionObject *op) {
    PyObject* result = op->defaults_tuple;
    if (unlikely(!result)) {
        if (op->defaults_getter) {
            if (unlikely(__Pyx_CyFunction_init_defaults(op) < 0)) return NULL;
            result = op->defaults_tuple;
        } else {
            result = Py_None;
        }
    }
    Py_INCREF(result);
    return result;
}
static PyObject *
__Pyx_CyFunction_get_defaults(__pyx_CyFunctionObject *op, void *context) {
    PyObject* result = NULL;
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_defaults_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_kwdefaults(__pyx_CyFunctionObject *op, PyObject* value, void *context) {
    CYTHON_UNUSED_VAR(context);
    if (!value) {
        value = Py_None;
    } else if (unlikely(value != Py_None && !PyDict_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__kwdefaults__ must be set to a dict object");
        return -1;
    }
    PyErr_WarnEx(PyExc_RuntimeWarning, "changes to cyfunction.__kwdefaults__ will not "
                 "currently affect the values used in function calls", 1);
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    __Pyx_Py_XDECREF_SET(op->defaults_kwdict, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_kwdefaults_locked(__pyx_CyFunctionObject *op) {
    PyObject* result = op->defaults_kwdict;
    if (unlikely(!result)) {
        if (op->defaults_getter) {
            if (unlikely(__Pyx_CyFunction_init_defaults(op) < 0)) return NULL;
            result = op->defaults_kwdict;
        } else {
            result = Py_None;
        }
    }
    Py_INCREF(result);
    return result;
}
static PyObject *
__Pyx_CyFunction_get_kwdefaults(__pyx_CyFunctionObject *op, void *context) {
    PyObject* result;
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_kwdefaults_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_annotations(__pyx_CyFunctionObject *op, PyObject* value, void *context) {
    CYTHON_UNUSED_VAR(context);
    if (!value || value == Py_None) {
        value = NULL;
    } else if (unlikely(!PyDict_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__annotations__ must be set to a dict object");
        return -1;
    }
    Py_XINCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    __Pyx_Py_XDECREF_SET(op->func_annotations, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_annotations_locked(__pyx_CyFunctionObject *op) {
    PyObject* result = op->func_annotations;
    if (unlikely(!result)) {
        result = PyDict_New();
        if (unlikely(!result)) return NULL;
        op->func_annotations = result;
    }
    Py_INCREF(result);
    return result;
}
static PyObject *
__Pyx_CyFunction_get_annotations(__pyx_CyFunctionObject *op, void *context) {
    PyObject *result;
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_annotations_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static PyObject *
__Pyx_CyFunction_get_is_coroutine_value(__pyx_CyFunctionObject *op) {
    int is_coroutine = op->flags & __Pyx_CYFUNCTION_COROUTINE;
    if (is_coroutine) {
        PyObject *is_coroutine_value, *module, *fromlist, *marker = __pyx_mstate_global->__pyx_n_u_is_coroutine;
        fromlist = PyList_New(1);
        if (unlikely(!fromlist)) return NULL;
        Py_INCREF(marker);
#if CYTHON_ASSUME_SAFE_MACROS
        PyList_SET_ITEM(fromlist, 0, marker);
#else
        if (unlikely(PyList_SetItem(fromlist, 0, marker) < 0)) {
            Py_DECREF(marker);
            Py_DECREF(fromlist);
            return NULL;
        }
#endif
        module = PyImport_ImportModuleLevelObject(__pyx_mstate_global->__pyx_n_u_asyncio_coroutines, NULL, NULL, fromlist, 0);
        Py_DECREF(fromlist);
        if (unlikely(!module)) goto ignore;
        is_coroutine_value = __Pyx_PyObject_GetAttrStr(module, marker);
        Py_DECREF(module);
        if (likely(is_coroutine_value)) {
            return is_coroutine_value;
        }
ignore:
        PyErr_Clear();
    }
    return __Pyx_PyBool_FromLong(is_coroutine);
}
static PyObject *
__Pyx_CyFunction_get_is_coroutine(__pyx_CyFunctionObject *op, void *context) {
    PyObject *result;
    CYTHON_UNUSED_VAR(context);
    if (op->func_is_coroutine) {
        return __Pyx_NewRef(op->func_is_coroutine);
    }
    result = __Pyx_CyFunction_get_is_coroutine_value(op);
    if (unlikely(!result))
        return NULL;
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    if (op->func_is_coroutine) {
        Py_DECREF(result);
        result = __Pyx_NewRef(op->func_is_coroutine);
    } else {
        op->func_is_coroutine = __Pyx_NewRef(result);
    }
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static void __Pyx_CyFunction_raise_argument_count_error(__pyx_CyFunctionObject *func, const char* message, Py_ssize_t size) {
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *py_name = __Pyx_CyFunction_get_name(func, NULL);
    if (!py_name) return;
    PyErr_Format(PyExc_TypeError,
        "%.200S() %s (%" CYTHON_FORMAT_SSIZE_T "d given)",
        py_name, message, size);
    Py_DECREF(py_name);
#else
    const char* name = ((PyCFunctionObject*)func)->m_ml->ml_name;
    PyErr_Format(PyExc_TypeError,
        "%.200s() %s (%" CYTHON_FORMAT_SSIZE_T "d given)",
        name, message, size);
#endif
}
static void __Pyx_CyFunction_raise_type_error(__pyx_CyFunctionObject *func, const char* message) {
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *py_name = __Pyx_CyFunction_get_name(func, NULL);
    if (!py_name) return;
    PyErr_Format(PyExc_TypeError,
        "%.200S() %s",
        py_name, message);
    Py_DECREF(py_name);
#else
    const char* name = ((PyCFunctionObject*)func)->m_ml->ml_name;
    PyErr_Format(PyExc_TypeError,
        "%.200s() %s",
        name, message);
#endif
}
#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject *
__Pyx_CyFunction_get_module(__pyx_CyFunctionObject *op, void *context) {
    CYTHON_UNUSED_VAR(context);
    return PyObject_GetAttrString(op->func, "__module__");
}
static int
__Pyx_CyFunction_set_module(__pyx_CyFunctionObject *op, PyObject* value, void *context) {
    CYTHON_UNUSED_VAR(context);
    return PyObject_SetAttrString(op->func, "__module__", value);
}
#endif
static PyGetSetDef __pyx_CyFunction_getsets[] = {
    {"func_doc", (getter)__Pyx_CyFunction_get_doc, (setter)__Pyx_CyFunction_set_doc, 0, 0},
    {"__doc__",  (getter)__Pyx_CyFunction_get_doc, (setter)__Pyx_CyFunction_set_doc, 0, 0},
    {"func_name", (getter)__Pyx_CyFunction_get_name, (setter)__Pyx_CyFunction_set_name, 0, 0},
    {"__name__", (getter)__Pyx_CyFunction_get_name, (setter)__Pyx_CyFunction_set_name, 0, 0},
    {"__qualname__", (getter)__Pyx_CyFunction_get_qualname, (setter)__Pyx_CyFunction_set_qualname, 0, 0},
    {"func_dict", (getter)__Pyx_CyFunction_get_dict, (setter)__Pyx_CyFunction_set_dict, 0, 0},
    {"__dict__", (getter)__Pyx_CyFunction_get_dict, (setter)__Pyx_CyFunction_set_dict, 0, 0},
    {"func_globals", (getter)__Pyx_CyFunction_get_globals, 0, 0, 0},
    {"__globals__", (getter)__Pyx_CyFunction_get_globals, 0, 0, 0},
    {"func_closure", (getter)__Pyx_CyFunction_get_closure, 0, 0, 0},
    {"__closure__", (getter)__Pyx_CyFunction_get_closure, 0, 0, 0},
    {"func_code", (getter)__Pyx_CyFunction_get_code, 0, 0, 0},
    {"__code__", (getter)__Pyx_CyFunction_get_code, 0, 0, 0},
    {"func_defaults", (getter)__Pyx_CyFunction_get_defaults, (setter)__Pyx_CyFunction_set_defaults, 0, 0},
    {"__defaults__", (getter)__Pyx_CyFunction_get_defaults, (setter)__Pyx_CyFunction_set_defaults, 0, 0},
    {"__kwdefaults__", (getter)__Pyx_CyFunction_get_kwdefaults, (setter)__Pyx_CyFunction_set_kwdefaults, 0, 0},
    {"__annotations__", (getter)__Pyx_CyFunction_get_annotations, (setter)__Pyx_CyFunction_set_annotations, 0, 0},
    {"_is_coroutine", (getter)__Pyx_CyFunction_get_is_coroutine, 0, 0, 0},
#if CYTHON_COMPILING_IN_LIMITED_API
    {"__module__", (getter)__Pyx_CyFunction_get_module, (setter)__Pyx_CyFunction_set_module, 0, 0},
#endif
    {0, 0, 0, 0, 0}
};
static PyMemberDef __pyx_CyFunction_members[] = {
#if !CYTHON_COMPILING_IN_LIMITED_API
    {"__module__", T_OBJECT, offsetof(PyCFunctionObject, m_module), 0, 0},
#endif
    {"__dictoffset__", T_PYSSIZET, offsetof(__pyx_CyFunctionObject, func_dict), READONLY, 0},
#if CYTHON_METH_FASTCALL
#if CYTHON_BACKPORT_VECTORCALL || CYTHON_COMPILING_IN_LIMITED_API
    {"__vectorcalloffset__", T_PYSSIZET, offsetof(__pyx_CyFunctionObject, func_vectorcall), READONLY, 0},
#else
    {"__vectorcalloffset__", T_PYSSIZET, offsetof(PyCFunctionObject, vectorcall), READONLY, 0},
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
    {"__weaklistoffset__", T_PYSSIZET, offsetof(__pyx_CyFunctionObject, func_weakreflist), READONLY, 0},
#else
    {"__weaklistoffset__", T_PYSSIZET, offsetof(PyCFunctionObject, m_weakreflist), READONLY, 0},
#endif
#endif
    {0, 0, 0,  0, 0}
};
static PyObject *
__Pyx_CyFunction_reduce(__pyx_CyFunctionObject *m, PyObject *args)
{
    PyObject *result = NULL;
    CYTHON_UNUSED_VAR(args);
    __Pyx_BEGIN_CRITICAL_SECTION(m);
    Py_INCREF(m->func_qualname);
    result = m->func_qualname;
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static PyMethodDef __pyx_CyFunction_methods[] = {
    {"__reduce__", (PyCFunction)__Pyx_CyFunction_reduce, METH_VARARGS, 0},
    {0, 0, 0, 0}
};
#if CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_CyFunction_weakreflist(cyfunc) ((cyfunc)->func_weakreflist)
#else
#define __Pyx_CyFunction_weakreflist(cyfunc) (((PyCFunctionObject*)cyfunc)->m_weakreflist)
#endif
static PyObject *__Pyx_CyFunction_Init(__pyx_CyFunctionObject *op, PyMethodDef *ml, int flags, PyObject* qualname,
                                       PyObject *closure, PyObject *module, PyObject* globals, PyObject* code) {
#if !CYTHON_COMPILING_IN_LIMITED_API
    PyCFunctionObject *cf = (PyCFunctionObject*) op;
#endif
    if (unlikely(op == NULL))
        return NULL;
#if CYTHON_COMPILING_IN_LIMITED_API
    op->func = PyCFunction_NewEx(ml, (PyObject*)op, module);
    if (unlikely(!op->func)) return NULL;
#endif
    op->flags = flags;
    __Pyx_CyFunction_weakreflist(op) = NULL;
#if !CYTHON_COMPILING_IN_LIMITED_API
    cf->m_ml = ml;
    cf->m_self = (PyObject *) op;
#endif
    Py_XINCREF(closure);
    op->func_closure = closure;
#if !CYTHON_COMPILING_IN_LIMITED_API
    Py_XINCREF(module);
    cf->m_module = module;
#endif
    op->func_dict = NULL;
    op->func_name = NULL;
    Py_INCREF(qualname);
    op->func_qualname = qualname;
    op->func_doc = NULL;
#if PY_VERSION_HEX < 0x030900B1 || CYTHON_COMPILING_IN_LIMITED_API
    op->func_classobj = NULL;
#else
    ((PyCMethodObject*)op)->mm_class = NULL;
#endif
    op->func_globals = globals;
    Py_INCREF(op->func_globals);
    Py_XINCREF(code);
    op->func_code = code;
    op->defaults = NULL;
    op->defaults_tuple = NULL;
    op->defaults_kwdict = NULL;
    op->defaults_getter = NULL;
    op->func_annotations = NULL;
    op->func_is_coroutine = NULL;
#if CYTHON_METH_FASTCALL
    switch (ml->ml_flags & (METH_VARARGS | METH_FASTCALL | METH_NOARGS | METH_O | METH_KEYWORDS | METH_METHOD)) {
    case METH_NOARGS:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_NOARGS;
        break;
    case METH_O:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_O;
        break;
    case METH_METHOD | METH_FASTCALL | METH_KEYWORDS:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS_METHOD;
        break;
    case METH_FASTCALL | METH_KEYWORDS:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS;
        break;
    case METH_VARARGS | METH_KEYWORDS:
        __Pyx_CyFunction_func_vectorcall(op) = NULL;
        break;
    default:
        PyErr_SetString(PyExc_SystemError, "Bad call flags for CyFunction");
        Py_DECREF(op);
        return NULL;
    }
#endif
    return (PyObject *) op;
}
static int
__Pyx_CyFunction_clear(__pyx_CyFunctionObject *m)
{
    Py_CLEAR(m->func_closure);
#if CYTHON_COMPILING_IN_LIMITED_API
    Py_CLEAR(m->func);
#else
    Py_CLEAR(((PyCFunctionObject*)m)->m_module);
#endif
    Py_CLEAR(m->func_dict);
    Py_CLEAR(m->func_name);
    Py_CLEAR(m->func_qualname);
    Py_CLEAR(m->func_doc);
    Py_CLEAR(m->func_globals);
    Py_CLEAR(m->func_code);
#if !CYTHON_COMPILING_IN_LIMITED_API
#if PY_VERSION_HEX < 0x030900B1
    Py_CLEAR(__Pyx_CyFunction_GetClassObj(m));
#else
    {
        PyObject *cls = (PyObject*) ((PyCMethodObject *) (m))->mm_class;
        ((PyCMethodObject *) (m))->mm_class = NULL;
        Py_XDECREF(cls);
    }
#endif
#endif
    Py_CLEAR(m->defaults_tuple);
    Py_CLEAR(m->defaults_kwdict);
    Py_CLEAR(m->func_annotations);
    Py_CLEAR(m->func_is_coroutine);
    Py_CLEAR(m->defaults);
    return 0;
}
static void __Pyx__CyFunction_dealloc(__pyx_CyFunctionObject *m)
{
    if (__Pyx_CyFunction_weakreflist(m) != NULL)
        PyObject_ClearWeakRefs((PyObject *) m);
    __Pyx_CyFunction_clear(m);
    __Pyx_PyHeapTypeObject_GC_Del(m);
}
static void __Pyx_CyFunction_dealloc(__pyx_CyFunctionObject *m)
{
    PyObject_GC_UnTrack(m);
    __Pyx__CyFunction_dealloc(m);
}
static int __Pyx_CyFunction_traverse(__pyx_CyFunctionObject *m, visitproc visit, void *arg)
{
    {
        int e = __Pyx_call_type_traverse((PyObject*)m, 1, visit, arg);
        if (e) return e;
    }
    Py_VISIT(m->func_closure);
#if CYTHON_COMPILING_IN_LIMITED_API
    Py_VISIT(m->func);
#else
    Py_VISIT(((PyCFunctionObject*)m)->m_module);
#endif
    Py_VISIT(m->func_dict);
    __Pyx_VISIT_CONST(m->func_name);
    __Pyx_VISIT_CONST(m->func_qualname);
    Py_VISIT(m->func_doc);
    Py_VISIT(m->func_globals);
    __Pyx_VISIT_CONST(m->func_code);
#if !CYTHON_COMPILING_IN_LIMITED_API
    Py_VISIT(__Pyx_CyFunction_GetClassObj(m));
#endif
    Py_VISIT(m->defaults_tuple);
    Py_VISIT(m->defaults_kwdict);
    Py_VISIT(m->func_is_coroutine);
    Py_VISIT(m->defaults);
    return 0;
}
static PyObject*
__Pyx_CyFunction_repr(__pyx_CyFunctionObject *op)
{
    PyObject *repr;
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    repr = PyUnicode_FromFormat("<cyfunction %U at %p>",
                                op->func_qualname, (void *)op);
    __Pyx_END_CRITICAL_SECTION();
    return repr;
}
static PyObject * __Pyx_CyFunction_CallMethod(PyObject *func, PyObject *self, PyObject *arg, PyObject *kw) {
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *f = ((__pyx_CyFunctionObject*)func)->func;
    PyCFunction meth;
    int flags;
    meth = PyCFunction_GetFunction(f);
    if (unlikely(!meth)) return NULL;
    flags = PyCFunction_GetFlags(f);
    if (unlikely(flags < 0)) return NULL;
#else
    PyCFunctionObject* f = (PyCFunctionObject*)func;
    PyCFunction meth = f->m_ml->ml_meth;
    int flags = f->m_ml->ml_flags;
#endif
    Py_ssize_t size;
    switch (flags & (METH_VARARGS | METH_KEYWORDS | METH_NOARGS | METH_O)) {
    case METH_VARARGS:
        if (likely(kw == NULL || PyDict_Size(kw) == 0))
            return (*meth)(self, arg);
        break;
    case METH_VARARGS | METH_KEYWORDS:
        return (*(PyCFunctionWithKeywords)(void(*)(void))meth)(self, arg, kw);
    case METH_NOARGS:
        if (likely(kw == NULL || PyDict_Size(kw) == 0)) {
#if CYTHON_ASSUME_SAFE_SIZE
            size = PyTuple_GET_SIZE(arg);
#else
            size = PyTuple_Size(arg);
            if (unlikely(size < 0)) return NULL;
#endif
            if (likely(size == 0))
                return (*meth)(self, NULL);
            __Pyx_CyFunction_raise_argument_count_error(
                (__pyx_CyFunctionObject*)func,
                "takes no arguments", size);
            return NULL;
        }
        break;
    case METH_O:
        if (likely(kw == NULL || PyDict_Size(kw) == 0)) {
#if CYTHON_ASSUME_SAFE_SIZE
            size = PyTuple_GET_SIZE(arg);
#else
            size = PyTuple_Size(arg);
            if (unlikely(size < 0)) return NULL;
#endif
            if (likely(size == 1)) {
                PyObject *result, *arg0;
                #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                arg0 = PyTuple_GET_ITEM(arg, 0);
                #else
                arg0 = __Pyx_PySequence_ITEM(arg, 0); if (unlikely(!arg0)) return NULL;
                #endif
                result = (*meth)(self, arg0);
                #if !(CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS)
                Py_DECREF(arg0);
                #endif
                return result;
            }
            __Pyx_CyFunction_raise_argument_count_error(
                (__pyx_CyFunctionObject*)func,
                "takes exactly one argument", size);
            return NULL;
        }
        break;
    default:
        PyErr_SetString(PyExc_SystemError, "Bad call flags for CyFunction");
        return NULL;
    }
    __Pyx_CyFunction_raise_type_error(
        (__pyx_CyFunctionObject*)func, "takes no keyword arguments");
    return NULL;
}
static CYTHON_INLINE PyObject *__Pyx_CyFunction_Call(PyObject *func, PyObject *arg, PyObject *kw) {
    PyObject *self, *result;
#if CYTHON_COMPILING_IN_LIMITED_API
    self = PyCFunction_GetSelf(((__pyx_CyFunctionObject*)func)->func);
    if (unlikely(!self) && PyErr_Occurred()) return NULL;
#else
    self = ((PyCFunctionObject*)func)->m_self;
#endif
    result = __Pyx_CyFunction_CallMethod(func, self, arg, kw);
    return result;
}
static PyObject *__Pyx_CyFunction_CallAsMethod(PyObject *func, PyObject *args, PyObject *kw) {
    PyObject *result;
    __pyx_CyFunctionObject *cyfunc = (__pyx_CyFunctionObject *) func;
#if CYTHON_METH_FASTCALL && (CYTHON_VECTORCALL || CYTHON_BACKPORT_VECTORCALL)
     __pyx_vectorcallfunc vc = __Pyx_CyFunction_func_vectorcall(cyfunc);
    if (vc) {
#if CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE
        return __Pyx_PyVectorcall_FastCallDict(func, vc, &PyTuple_GET_ITEM(args, 0), (size_t)PyTuple_GET_SIZE(args), kw);
#else
        (void) &__Pyx_PyVectorcall_FastCallDict;
        return PyVectorcall_Call(func, args, kw);
#endif
    }
#endif
    if ((cyfunc->flags & __Pyx_CYFUNCTION_CCLASS) && !(cyfunc->flags & __Pyx_CYFUNCTION_STATICMETHOD)) {
        Py_ssize_t argc;
        PyObject *new_args;
        PyObject *self;
#if CYTHON_ASSUME_SAFE_SIZE
        argc = PyTuple_GET_SIZE(args);
#else
        argc = PyTuple_Size(args);
        if (unlikely(argc < 0)) return NULL;
#endif
        new_args = PyTuple_GetSlice(args, 1, argc);
        if (unlikely(!new_args))
            return NULL;
        self = PyTuple_GetItem(args, 0);
        if (unlikely(!self)) {
            Py_DECREF(new_args);
            PyErr_Format(PyExc_TypeError,
                         "unbound method %.200S() needs an argument",
                         cyfunc->func_qualname);
            return NULL;
        }
        result = __Pyx_CyFunction_CallMethod(func, self, new_args, kw);
        Py_DECREF(new_args);
    } else {
        result = __Pyx_CyFunction_Call(func, args, kw);
    }
    return result;
}
#if CYTHON_METH_FASTCALL && (CYTHON_VECTORCALL || CYTHON_BACKPORT_VECTORCALL)
static CYTHON_INLINE int __Pyx_CyFunction_Vectorcall_CheckArgs(__pyx_CyFunctionObject *cyfunc, Py_ssize_t nargs, PyObject *kwnames)
{
    int ret = 0;
    if ((cyfunc->flags & __Pyx_CYFUNCTION_CCLASS) && !(cyfunc->flags & __Pyx_CYFUNCTION_STATICMETHOD)) {
        if (unlikely(nargs < 1)) {
            __Pyx_CyFunction_raise_type_error(
                cyfunc, "needs an argument");
            return -1;
        }
        ret = 1;
    }
    if (unlikely(kwnames) && unlikely(__Pyx_PyTuple_GET_SIZE(kwnames))) {
        __Pyx_CyFunction_raise_type_error(
            cyfunc, "takes no keyword arguments");
        return -1;
    }
    return ret;
}
static PyObject * __Pyx_CyFunction_Vectorcall_NOARGS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = (__pyx_CyFunctionObject *)func;
#if CYTHON_BACKPORT_VECTORCALL
    Py_ssize_t nargs = (Py_ssize_t)nargsf;
#else
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
#endif
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = PyCFunction_GetFunction(cyfunc->func);
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(cyfunc, nargs, kwnames)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
#if CYTHON_COMPILING_IN_LIMITED_API
        self = PyCFunction_GetSelf(((__pyx_CyFunctionObject*)cyfunc)->func);
        if (unlikely(!self) && PyErr_Occurred()) return NULL;
#else
        self = ((PyCFunctionObject*)cyfunc)->m_self;
#endif
        break;
    default:
        return NULL;
    }
    if (unlikely(nargs != 0)) {
        __Pyx_CyFunction_raise_argument_count_error(
            cyfunc, "takes no arguments", nargs);
        return NULL;
    }
    return meth(self, NULL);
}
static PyObject * __Pyx_CyFunction_Vectorcall_O(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = (__pyx_CyFunctionObject *)func;
#if CYTHON_BACKPORT_VECTORCALL
    Py_ssize_t nargs = (Py_ssize_t)nargsf;
#else
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
#endif
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = PyCFunction_GetFunction(cyfunc->func);
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(cyfunc, nargs, kwnames)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
#if CYTHON_COMPILING_IN_LIMITED_API
        self = PyCFunction_GetSelf(((__pyx_CyFunctionObject*)cyfunc)->func);
        if (unlikely(!self) && PyErr_Occurred()) return NULL;
#else
        self = ((PyCFunctionObject*)cyfunc)->m_self;
#endif
        break;
    default:
        return NULL;
    }
    if (unlikely(nargs != 1)) {
        __Pyx_CyFunction_raise_argument_count_error(
            cyfunc, "takes exactly one argument", nargs);
        return NULL;
    }
    return meth(self, args[0]);
}
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = (__pyx_CyFunctionObject *)func;
#if CYTHON_BACKPORT_VECTORCALL
    Py_ssize_t nargs = (Py_ssize_t)nargsf;
#else
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
#endif
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = PyCFunction_GetFunction(cyfunc->func);
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(cyfunc, nargs, NULL)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
#if CYTHON_COMPILING_IN_LIMITED_API
        self = PyCFunction_GetSelf(((__pyx_CyFunctionObject*)cyfunc)->func);
        if (unlikely(!self) && PyErr_Occurred()) return NULL;
#else
        self = ((PyCFunctionObject*)cyfunc)->m_self;
#endif
        break;
    default:
        return NULL;
    }
    return ((__Pyx_PyCFunctionFastWithKeywords)(void(*)(void))meth)(self, args, nargs, kwnames);
}
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS_METHOD(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = (__pyx_CyFunctionObject *)func;
    PyTypeObject *cls = (PyTypeObject *) __Pyx_CyFunction_GetClassObj(cyfunc);
#if CYTHON_BACKPORT_VECTORCALL
    Py_ssize_t nargs = (Py_ssize_t)nargsf;
#else
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
#endif
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = PyCFunction_GetFunction(cyfunc->func);
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(cyfunc, nargs, NULL)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
#if CYTHON_COMPILING_IN_LIMITED_API
        self = PyCFunction_GetSelf(((__pyx_CyFunctionObject*)cyfunc)->func);
        if (unlikely(!self) && PyErr_Occurred()) return NULL;
#else
        self = ((PyCFunctionObject*)cyfunc)->m_self;
#endif
        break;
    default:
        return NULL;
    }
    return ((__Pyx_PyCMethod)(void(*)(void))meth)(self, cls, args, (size_t)nargs, kwnames);
}
#endif
static PyType_Slot __pyx_CyFunctionType_slots[] = {
    {Py_tp_dealloc, (void *)__Pyx_CyFunction_dealloc},
    {Py_tp_repr, (void *)__Pyx_CyFunction_repr},
    {Py_tp_call, (void *)__Pyx_CyFunction_CallAsMethod},
    {Py_tp_traverse, (void *)__Pyx_CyFunction_traverse},
    {Py_tp_clear, (void *)__Pyx_CyFunction_clear},
    {Py_tp_methods, (void *)__pyx_CyFunction_methods},
    {Py_tp_members, (void *)__pyx_CyFunction_members},
    {Py_tp_getset, (void *)__pyx_CyFunction_getsets},
    {Py_tp_descr_get, (void *)__Pyx_PyMethod_New},
    {0, 0},
};
static PyType_Spec __pyx_CyFunctionType_spec = {
    __PYX_TYPE_MODULE_PREFIX "cython_function_or_method",
    sizeof(__pyx_CyFunctionObject),
    0,
#ifdef Py_TPFLAGS_METHOD_DESCRIPTOR
    Py_TPFLAGS_METHOD_DESCRIPTOR |
#endif
#if CYTHON_METH_FASTCALL
#if defined(Py_TPFLAGS_HAVE_VECTORCALL)
    Py_TPFLAGS_HAVE_VECTORCALL |
#elif defined(_Py_TPFLAGS_HAVE_VECTORCALL)
    _Py_TPFLAGS_HAVE_VECTORCALL |
#endif
#endif // CYTHON_METH_FASTCALL
#if PY_VERSION_HEX >= 0x030A0000
    Py_TPFLAGS_IMMUTABLETYPE |
#endif
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HAVE_GC | Py_TPFLAGS_BASETYPE,
    __pyx_CyFunctionType_slots
};
static int __pyx_CyFunction_init(PyObject *module) {
    __pyx_mstatetype *mstate = __Pyx_PyModule_GetState(module);
    mstate->__pyx_CyFunctionType = __Pyx_FetchCommonTypeFromSpec(
        mstate->__pyx_CommonTypesMetaclassType, module, &__pyx_CyFunctionType_spec, NULL);
    if (unlikely(mstate->__pyx_CyFunctionType == NULL)) {
        return -1;
    }
    return 0;
}
static CYTHON_INLINE PyObject *__Pyx_CyFunction_InitDefaults(PyObject *func, PyTypeObject *defaults_type) {
    __pyx_CyFunctionObject *m = (__pyx_CyFunctionObject *) func;
    m->defaults = PyObject_CallObject((PyObject*)defaults_type, NULL); // _PyObject_New(defaults_type);
    if (unlikely(!m->defaults))
        return NULL;
    return m->defaults;
}
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsTuple(PyObject *func, PyObject *tuple) {
    __pyx_CyFunctionObject *m = (__pyx_CyFunctionObject *) func;
    m->defaults_tuple = tuple;
    Py_INCREF(tuple);
}
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsKwDict(PyObject *func, PyObject *dict) {
    __pyx_CyFunctionObject *m = (__pyx_CyFunctionObject *) func;
    m->defaults_kwdict = dict;
    Py_INCREF(dict);
}
static CYTHON_INLINE void __Pyx_CyFunction_SetAnnotationsDict(PyObject *func, PyObject *dict) {
    __pyx_CyFunctionObject *m = (__pyx_CyFunctionObject *) func;
    m->func_annotations = dict;
    Py_INCREF(dict);
}


static PyObject *__Pyx_CyFunction_New(PyMethodDef *ml, int flags, PyObject* qualname,
                                      PyObject *closure, PyObject *module, PyObject* globals, PyObject* code) {
    PyObject *op = __Pyx_CyFunction_Init(
        PyObject_GC_New(__pyx_CyFunctionObject, __pyx_mstate_global->__pyx_CyFunctionType),
        ml, flags, qualname, closure, module, globals, code
    );
    if (likely(op)) {
        PyObject_GC_Track(op);
    }
    return op;
}


#if CYTHON_CLINE_IN_TRACEBACK && CYTHON_CLINE_IN_TRACEBACK_RUNTIME
static int __Pyx_CLineForTraceback(PyThreadState *tstate, int c_line) {
    PyObject *use_cline;
    PyObject *ptype, *pvalue, *ptraceback;
#if CYTHON_COMPILING_IN_CPYTHON
    PyObject **cython_runtime_dict;
#endif
    CYTHON_MAYBE_UNUSED_VAR(tstate);
    if (unlikely(!__pyx_mstate_global->__pyx_cython_runtime)) {
        return c_line;
    }
    __Pyx_ErrFetchInState(tstate, &ptype, &pvalue, &ptraceback);
#if CYTHON_COMPILING_IN_CPYTHON
    cython_runtime_dict = _PyObject_GetDictPtr(__pyx_mstate_global->__pyx_cython_runtime);
    if (likely(cython_runtime_dict)) {
        __Pyx_BEGIN_CRITICAL_SECTION(*cython_runtime_dict);
        __PYX_PY_DICT_LOOKUP_IF_MODIFIED(
            use_cline, *cython_runtime_dict,
            __Pyx_PyDict_GetItemStr(*cython_runtime_dict, __pyx_mstate_global->__pyx_n_u_cline_in_traceback))
        Py_XINCREF(use_cline);
        __Pyx_END_CRITICAL_SECTION();
    } else
#endif
    {
      PyObject *use_cline_obj = __Pyx_PyObject_GetAttrStrNoError(__pyx_mstate_global->__pyx_cython_runtime, __pyx_mstate_global->__pyx_n_u_cline_in_traceback);
      if (use_cline_obj) {
        use_cline = PyObject_Not(use_cline_obj) ? Py_False : Py_True;
        Py_INCREF(use_cline);
        Py_DECREF(use_cline_obj);
      } else {
        PyErr_Clear();
        use_cline = NULL;
      }
    }
    if (!use_cline) {
        c_line = 0;
        (void) PyObject_SetAttr(__pyx_mstate_global->__pyx_cython_runtime, __pyx_mstate_global->__pyx_n_u_cline_in_traceback, Py_False);
    }
    else if (use_cline == Py_False || (use_cline != Py_True && PyObject_Not(use_cline) != 0)) {
        c_line = 0;
    }
    Py_XDECREF(use_cline);
    __Pyx_ErrRestoreInState(tstate, ptype, pvalue, ptraceback);
    return c_line;
}
#endif


static int __pyx_bisect_code_objects(__Pyx_CodeObjectCacheEntry* entries, int count, int code_line) {
    int start = 0, mid = 0, end = count - 1;
    if (end >= 0 && code_line > entries[end].code_line) {
        return count;
    }
    while (start < end) {
        mid = start + (end - start) / 2;
        if (code_line < entries[mid].code_line) {
            end = mid;
        } else if (code_line > entries[mid].code_line) {
             start = mid + 1;
        } else {
            return mid;
        }
    }
    if (code_line <= entries[mid].code_line) {
        return mid;
    } else {
        return mid + 1;
    }
}
static __Pyx_CachedCodeObjectType *__pyx__find_code_object(struct __Pyx_CodeObjectCache *code_cache, int code_line) {
    __Pyx_CachedCodeObjectType* code_object;
    int pos;
    if (unlikely(!code_line) || unlikely(!code_cache->entries)) {
        return NULL;
    }
    pos = __pyx_bisect_code_objects(code_cache->entries, code_cache->count, code_line);
    if (unlikely(pos >= code_cache->count) || unlikely(code_cache->entries[pos].code_line != code_line)) {
        return NULL;
    }
    code_object = code_cache->entries[pos].code_object;
    Py_INCREF(code_object);
    return code_object;
}
static __Pyx_CachedCodeObjectType *__pyx_find_code_object(int code_line) {
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && !CYTHON_ATOMICS
    (void)__pyx__find_code_object;
    return NULL; // Most implementation should have atomics. But otherwise, don't make it thread-safe, just miss.
#else
    struct __Pyx_CodeObjectCache *code_cache = &__pyx_mstate_global->__pyx_code_cache;
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_nonatomic_int_type old_count = __pyx_atomic_incr_acq_rel(&code_cache->accessor_count);
    if (old_count < 0) {
        __pyx_atomic_decr_acq_rel(&code_cache->accessor_count);
        return NULL;
    }
#endif
    __Pyx_CachedCodeObjectType *result = __pyx__find_code_object(code_cache, code_line);
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_atomic_decr_acq_rel(&code_cache->accessor_count);
#endif
    return result;
#endif
}
static void __pyx__insert_code_object(struct __Pyx_CodeObjectCache *code_cache, int code_line, __Pyx_CachedCodeObjectType* code_object)
{
    int pos, i;
    __Pyx_CodeObjectCacheEntry* entries = code_cache->entries;
    if (unlikely(!code_line)) {
        return;
    }
    if (unlikely(!entries)) {
        entries = (__Pyx_CodeObjectCacheEntry*)PyMem_Malloc(64*sizeof(__Pyx_CodeObjectCacheEntry));
        if (likely(entries)) {
            code_cache->entries = entries;
            code_cache->max_count = 64;
            code_cache->count = 1;
            entries[0].code_line = code_line;
            entries[0].code_object = code_object;
            Py_INCREF(code_object);
        }
        return;
    }
    pos = __pyx_bisect_code_objects(code_cache->entries, code_cache->count, code_line);
    if ((pos < code_cache->count) && unlikely(code_cache->entries[pos].code_line == code_line)) {
        __Pyx_CachedCodeObjectType* tmp = entries[pos].code_object;
        entries[pos].code_object = code_object;
        Py_INCREF(code_object);
        Py_DECREF(tmp);
        return;
    }
    if (code_cache->count == code_cache->max_count) {
        int new_max = code_cache->max_count + 64;
        entries = (__Pyx_CodeObjectCacheEntry*)PyMem_Realloc(
            code_cache->entries, ((size_t)new_max) * sizeof(__Pyx_CodeObjectCacheEntry));
        if (unlikely(!entries)) {
            return;
        }
        code_cache->entries = entries;
        code_cache->max_count = new_max;
    }
    for (i=code_cache->count; i>pos; i--) {
        entries[i] = entries[i-1];
    }
    entries[pos].code_line = code_line;
    entries[pos].code_object = code_object;
    code_cache->count++;
    Py_INCREF(code_object);
}
static void __pyx_insert_code_object(int code_line, __Pyx_CachedCodeObjectType* code_object) {
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && !CYTHON_ATOMICS
    (void)__pyx__insert_code_object;
    return; // Most implementation should have atomics. But otherwise, don't make it thread-safe, just fail.
#else
    struct __Pyx_CodeObjectCache *code_cache = &__pyx_mstate_global->__pyx_code_cache;
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_nonatomic_int_type expected = 0;
    if (!__pyx_atomic_int_cmp_exchange(&code_cache->accessor_count, &expected, INT_MIN)) {
        return;
    }
#endif
    __pyx__insert_code_object(code_cache, code_line, code_object);
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_atomic_sub(&code_cache->accessor_count, INT_MIN);
#endif
#endif
}


#include "compile.h"
#include "frameobject.h"
#include "traceback.h"
#if PY_VERSION_HEX >= 0x030b00a6 && !CYTHON_COMPILING_IN_LIMITED_API && !defined(PYPY_VERSION)
  #ifndef Py_BUILD_CORE
    #define Py_BUILD_CORE 1
  #endif
  #include "internal/pycore_frame.h"
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject *__Pyx_PyCode_Replace_For_AddTraceback(PyObject *code, PyObject *scratch_dict,
                                                       PyObject *firstlineno, PyObject *name) {
    PyObject *replace = NULL;
    if (unlikely(PyDict_SetItemString(scratch_dict, "co_firstlineno", firstlineno))) return NULL;
    if (unlikely(PyDict_SetItemString(scratch_dict, "co_name", name))) return NULL;
    replace = PyObject_GetAttrString(code, "replace");
    if (likely(replace)) {
        PyObject *result = PyObject_Call(replace, __pyx_mstate_global->__pyx_empty_tuple, scratch_dict);
        Py_DECREF(replace);
        return result;
    }
    PyErr_Clear();
    return NULL;
}
static void __Pyx_AddTraceback(const char *funcname, int c_line,
                               int py_line, const char *filename) {
    PyObject *code_object = NULL, *py_py_line = NULL, *py_funcname = NULL, *dict = NULL;
    PyObject *replace = NULL, *getframe = NULL, *frame = NULL;
    PyObject *exc_type, *exc_value, *exc_traceback;
    int success = 0;
    if (c_line) {
        (void) __pyx_cfilenm;
        (void) __Pyx_CLineForTraceback(__Pyx_PyThreadState_Current, c_line);
    }
    PyErr_Fetch(&exc_type, &exc_value, &exc_traceback);
    code_object = __pyx_find_code_object(c_line ? -c_line : py_line);
    if (!code_object) {
        code_object = Py_CompileString("_getframe()", filename, Py_eval_input);
        if (unlikely(!code_object)) goto bad;
        py_py_line = PyLong_FromLong(py_line);
        if (unlikely(!py_py_line)) goto bad;
        py_funcname = PyUnicode_FromString(funcname);
        if (unlikely(!py_funcname)) goto bad;
        dict = PyDict_New();
        if (unlikely(!dict)) goto bad;
        {
            PyObject *old_code_object = code_object;
            code_object = __Pyx_PyCode_Replace_For_AddTraceback(code_object, dict, py_py_line, py_funcname);
            Py_DECREF(old_code_object);
        }
        if (unlikely(!code_object)) goto bad;
        __pyx_insert_code_object(c_line ? -c_line : py_line, code_object);
    } else {
        dict = PyDict_New();
    }
    getframe = PySys_GetObject("_getframe");
    if (unlikely(!getframe)) goto bad;
    if (unlikely(PyDict_SetItemString(dict, "_getframe", getframe))) goto bad;
    frame = PyEval_EvalCode(code_object, dict, dict);
    if (unlikely(!frame) || frame == Py_None) goto bad;
    success = 1;
  bad:
    PyErr_Restore(exc_type, exc_value, exc_traceback);
    Py_XDECREF(code_object);
    Py_XDECREF(py_py_line);
    Py_XDECREF(py_funcname);
    Py_XDECREF(dict);
    Py_XDECREF(replace);
    if (success) {
        PyTraceBack_Here(
            (struct _frame*)frame);
    }
    Py_XDECREF(frame);
}
#else
static PyCodeObject* __Pyx_CreateCodeObjectForTraceback(
            const char *funcname, int c_line,
            int py_line, const char *filename) {
    PyCodeObject *py_code = NULL;
    PyObject *py_funcname = NULL;
    if (c_line) {
        py_funcname = PyUnicode_FromFormat( "%s (%s:%d)", funcname, __pyx_cfilenm, c_line);
        if (!py_funcname) goto bad;
        funcname = PyUnicode_AsUTF8(py_funcname);
        if (!funcname) goto bad;
    }
    py_code = PyCode_NewEmpty(filename, funcname, py_line);
    Py_XDECREF(py_funcname);
    return py_code;
bad:
    Py_XDECREF(py_funcname);
    return NULL;
}
static void __Pyx_AddTraceback(const char *funcname, int c_line,
                               int py_line, const char *filename) {
    PyCodeObject *py_code = 0;
    PyFrameObject *py_frame = 0;
    PyThreadState *tstate = __Pyx_PyThreadState_Current;
    PyObject *ptype, *pvalue, *ptraceback;
    if (c_line) {
        c_line = __Pyx_CLineForTraceback(tstate, c_line);
    }
    py_code = __pyx_find_code_object(c_line ? -c_line : py_line);
    if (!py_code) {
        __Pyx_ErrFetchInState(tstate, &ptype, &pvalue, &ptraceback);
        py_code = __Pyx_CreateCodeObjectForTraceback(
            funcname, c_line, py_line, filename);
        if (!py_code) {
            
            Py_XDECREF(ptype);
            Py_XDECREF(pvalue);
            Py_XDECREF(ptraceback);
            goto bad;
        }
        __Pyx_ErrRestoreInState(tstate, ptype, pvalue, ptraceback);
        __pyx_insert_code_object(c_line ? -c_line : py_line, py_code);
    }
    py_frame = PyFrame_New(
        tstate,            
        py_code,           
        __pyx_mstate_global->__pyx_d,    
        0                  
    );
    if (!py_frame) goto bad;
    __Pyx_PyFrame_SetLineNumber(py_frame, py_line);
    PyTraceBack_Here(py_frame);
bad:
    Py_XDECREF(py_code);
    Py_XDECREF(py_frame);
}
#endif


static CYTHON_INLINE PyObject* __Pyx_PyLong_From_long(long value) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const long neg_one = (long) -1, const_zero = (long) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    if (is_unsigned) {
        if (sizeof(long) < sizeof(long)) {
            return PyLong_FromLong((long) value);
        } else if (sizeof(long) <= sizeof(unsigned long)) {
            return PyLong_FromUnsignedLong((unsigned long) value);
#if defined(HAVE_LONG_LONG) && !CYTHON_COMPILING_IN_PYPY
        } else if (sizeof(long) <= sizeof(unsigned PY_LONG_LONG)) {
            return PyLong_FromUnsignedLongLong((unsigned PY_LONG_LONG) value);
#endif
        }
    } else {
        if (sizeof(long) <= sizeof(long)) {
            return PyLong_FromLong((long) value);
#ifdef HAVE_LONG_LONG
        } else if (sizeof(long) <= sizeof(PY_LONG_LONG)) {
            return PyLong_FromLongLong((PY_LONG_LONG) value);
#endif
        }
    }
    {
        unsigned char *bytes = (unsigned char *)&value;
#if !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030d00A4
        if (is_unsigned) {
            return PyLong_FromUnsignedNativeBytes(bytes, sizeof(value), -1);
        } else {
            return PyLong_FromNativeBytes(bytes, sizeof(value), -1);
        }
#elif !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX < 0x030d0000
        int one = 1; int little = (int)*(unsigned char *)&one;
        return _PyLong_FromByteArray(bytes, sizeof(long),
                                     little, !is_unsigned);
#else
        int one = 1; int little = (int)*(unsigned char *)&one;
        PyObject *from_bytes, *result = NULL, *kwds = NULL;
        PyObject *py_bytes = NULL, *order_str = NULL;
        from_bytes = PyObject_GetAttrString((PyObject*)&PyLong_Type, "from_bytes");
        if (!from_bytes) return NULL;
        py_bytes = PyBytes_FromStringAndSize((char*)bytes, sizeof(long));
        if (!py_bytes) goto limited_bad;
        order_str = PyUnicode_FromString(little ? "little" : "big");
        if (!order_str) goto limited_bad;
        {
            PyObject *args[3+(CYTHON_VECTORCALL ? 1 : 0)] = { NULL, py_bytes, order_str };
            if (!is_unsigned) {
                kwds = __Pyx_MakeVectorcallBuilderKwds(1);
                if (!kwds) goto limited_bad;
                if (__Pyx_VectorcallBuilder_AddArgStr("signed", __Pyx_NewRef(Py_True), kwds, args+3, 0) < 0) goto limited_bad;
            }
            result = __Pyx_Object_Vectorcall_CallFromBuilder(from_bytes, args+1, 2 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET, kwds);
        }
        limited_bad:
        Py_XDECREF(kwds);
        Py_XDECREF(order_str);
        Py_XDECREF(py_bytes);
        Py_XDECREF(from_bytes);
        return result;
#endif
    }
}


#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
static __Pyx_TypeName
__Pyx_PyType_GetFullyQualifiedName(PyTypeObject* tp)
{
    PyObject *module = NULL, *name = NULL, *result = NULL;
    #if __PYX_LIMITED_VERSION_HEX < 0x030b0000
    name = __Pyx_PyObject_GetAttrStr((PyObject *)tp,
                                               __pyx_mstate_global->__pyx_n_u_qualname);
    #else
    name = PyType_GetQualName(tp);
    #endif
    if (unlikely(name == NULL) || unlikely(!PyUnicode_Check(name))) goto bad;
    module = __Pyx_PyObject_GetAttrStr((PyObject *)tp,
                                               __pyx_mstate_global->__pyx_n_u_module);
    if (unlikely(module == NULL) || unlikely(!PyUnicode_Check(module))) goto bad;
    if (PyUnicode_CompareWithASCIIString(module, "builtins") == 0) {
        result = name;
        name = NULL;
        goto done;
    }
    result = PyUnicode_FromFormat("%U.%U", module, name);
    if (unlikely(result == NULL)) goto bad;
  done:
    Py_XDECREF(name);
    Py_XDECREF(module);
    return result;
  bad:
    PyErr_Clear();
    if (name) {
        result = name;
        name = NULL;
    } else {
        result = __Pyx_NewRef(__pyx_mstate_global->__pyx_kp_u__20);
    }
    goto done;
}
#endif


#define __PYX_VERIFY_RETURN_INT(target_type, func_type, func_value)\
    __PYX__VERIFY_RETURN_INT(target_type, func_type, func_value, 0)
#define __PYX_VERIFY_RETURN_INT_EXC(target_type, func_type, func_value)\
    __PYX__VERIFY_RETURN_INT(target_type, func_type, func_value, 1)
#define __PYX__VERIFY_RETURN_INT(target_type, func_type, func_value, exc)\
    {\
        func_type value = func_value;\
        if (sizeof(target_type) < sizeof(func_type)) {\
            if (unlikely(value != (func_type) (target_type) value)) {\
                func_type zero = 0;\
                if (exc && unlikely(value == (func_type)-1 && PyErr_Occurred()))\
                    return (target_type) -1;\
                if (is_unsigned && unlikely(value < zero))\
                    goto raise_neg_overflow;\
                else\
                    goto raise_overflow;\
            }\
        }\
        return (target_type) value;\
    }


static CYTHON_INLINE long __Pyx_PyLong_As_long(PyObject *x) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const long neg_one = (long) -1, const_zero = (long) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    if (unlikely(!PyLong_Check(x))) {
        long val;
        PyObject *tmp = __Pyx_PyNumber_Long(x);
        if (!tmp) return (long) -1;
        val = __Pyx_PyLong_As_long(tmp);
        Py_DECREF(tmp);
        return val;
    }
    if (is_unsigned) {
#if CYTHON_USE_PYLONG_INTERNALS
        if (unlikely(__Pyx_PyLong_IsNeg(x))) {
            goto raise_neg_overflow;
        } else if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(long, __Pyx_compact_upylong, __Pyx_PyLong_CompactValueUnsigned(x))
        } else {
            const digit* digits = __Pyx_PyLong_Digits(x);
            assert(__Pyx_PyLong_DigitCount(x) > 1);
            switch (__Pyx_PyLong_DigitCount(x)) {
                case 2:
                    if ((8 * sizeof(long) > 1 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) >= 2 * PyLong_SHIFT)) {
                            return (long) (((((long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
                        }
                    }
                    break;
                case 3:
                    if ((8 * sizeof(long) > 2 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) >= 3 * PyLong_SHIFT)) {
                            return (long) (((((((long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
                        }
                    }
                    break;
                case 4:
                    if ((8 * sizeof(long) > 3 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) >= 4 * PyLong_SHIFT)) {
                            return (long) (((((((((long)digits[3]) << PyLong_SHIFT) | (long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
                        }
                    }
                    break;
            }
        }
#endif
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX < 0x030C00A7
        if (unlikely(Py_SIZE(x) < 0)) {
            goto raise_neg_overflow;
        }
#else
        {
            int result = PyObject_RichCompareBool(x, Py_False, Py_LT);
            if (unlikely(result < 0))
                return (long) -1;
            if (unlikely(result == 1))
                goto raise_neg_overflow;
        }
#endif
        if ((sizeof(long) <= sizeof(unsigned long))) {
            __PYX_VERIFY_RETURN_INT_EXC(long, unsigned long, PyLong_AsUnsignedLong(x))
#ifdef HAVE_LONG_LONG
        } else if ((sizeof(long) <= sizeof(unsigned PY_LONG_LONG))) {
            __PYX_VERIFY_RETURN_INT_EXC(long, unsigned PY_LONG_LONG, PyLong_AsUnsignedLongLong(x))
#endif
        }
    } else {
#if CYTHON_USE_PYLONG_INTERNALS
        if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(long, __Pyx_compact_pylong, __Pyx_PyLong_CompactValue(x))
        } else {
            const digit* digits = __Pyx_PyLong_Digits(x);
            assert(__Pyx_PyLong_DigitCount(x) > 1);
            switch (__Pyx_PyLong_SignedDigitCount(x)) {
                case -2:
                    if ((8 * sizeof(long) - 1 > 1 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, long, -(long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) - 1 > 2 * PyLong_SHIFT)) {
                            return (long) (((long)-1)*(((((long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
                        }
                    }
                    break;
                case 2:
                    if ((8 * sizeof(long) > 1 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) - 1 > 2 * PyLong_SHIFT)) {
                            return (long) ((((((long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
                        }
                    }
                    break;
                case -3:
                    if ((8 * sizeof(long) - 1 > 2 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, long, -(long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) - 1 > 3 * PyLong_SHIFT)) {
                            return (long) (((long)-1)*(((((((long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
                        }
                    }
                    break;
                case 3:
                    if ((8 * sizeof(long) > 2 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) - 1 > 3 * PyLong_SHIFT)) {
                            return (long) ((((((((long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
                        }
                    }
                    break;
                case -4:
                    if ((8 * sizeof(long) - 1 > 3 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, long, -(long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) - 1 > 4 * PyLong_SHIFT)) {
                            return (long) (((long)-1)*(((((((((long)digits[3]) << PyLong_SHIFT) | (long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
                        }
                    }
                    break;
                case 4:
                    if ((8 * sizeof(long) > 3 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(long) - 1 > 4 * PyLong_SHIFT)) {
                            return (long) ((((((((((long)digits[3]) << PyLong_SHIFT) | (long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
                        }
                    }
                    break;
            }
        }
#endif
        if ((sizeof(long) <= sizeof(long))) {
            __PYX_VERIFY_RETURN_INT_EXC(long, long, PyLong_AsLong(x))
#ifdef HAVE_LONG_LONG
        } else if ((sizeof(long) <= sizeof(PY_LONG_LONG))) {
            __PYX_VERIFY_RETURN_INT_EXC(long, PY_LONG_LONG, PyLong_AsLongLong(x))
#endif
        }
    }
    {
        long val;
        int ret = -1;
#if PY_VERSION_HEX >= 0x030d00A6 && !CYTHON_COMPILING_IN_LIMITED_API
        Py_ssize_t bytes_copied = PyLong_AsNativeBytes(
            x, &val, sizeof(val), Py_ASNATIVEBYTES_NATIVE_ENDIAN | (is_unsigned ? Py_ASNATIVEBYTES_UNSIGNED_BUFFER | Py_ASNATIVEBYTES_REJECT_NEGATIVE : 0));
        if (unlikely(bytes_copied == -1)) {
        } else if (unlikely(bytes_copied > (Py_ssize_t) sizeof(val))) {
            goto raise_overflow;
        } else {
            ret = 0;
        }
#elif PY_VERSION_HEX < 0x030d0000 && !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_LIMITED_API) || defined(_PyLong_AsByteArray)
        int one = 1; int is_little = (int)*(unsigned char *)&one;
        unsigned char *bytes = (unsigned char *)&val;
        ret = _PyLong_AsByteArray((PyLongObject *)x,
                                    bytes, sizeof(val),
                                    is_little, !is_unsigned);
#else
        PyObject *v;
        PyObject *stepval = NULL, *mask = NULL, *shift = NULL;
        int bits, remaining_bits, is_negative = 0;
        int chunk_size = (sizeof(long) < 8) ? 30 : 62;
        if (likely(PyLong_CheckExact(x))) {
            v = __Pyx_NewRef(x);
        } else {
            v = PyNumber_Long(x);
            if (unlikely(!v)) return (long) -1;
            assert(PyLong_CheckExact(v));
        }
        {
            int result = PyObject_RichCompareBool(v, Py_False, Py_LT);
            if (unlikely(result < 0)) {
                Py_DECREF(v);
                return (long) -1;
            }
            is_negative = result == 1;
        }
        if (is_unsigned && unlikely(is_negative)) {
            Py_DECREF(v);
            goto raise_neg_overflow;
        } else if (is_negative) {
            stepval = PyNumber_Invert(v);
            Py_DECREF(v);
            if (unlikely(!stepval))
                return (long) -1;
        } else {
            stepval = v;
        }
        v = NULL;
        val = (long) 0;
        mask = PyLong_FromLong((1L << chunk_size) - 1); if (unlikely(!mask)) goto done;
        shift = PyLong_FromLong(chunk_size); if (unlikely(!shift)) goto done;
        for (bits = 0; bits < (int) sizeof(long) * 8 - chunk_size; bits += chunk_size) {
            PyObject *tmp, *digit;
            long idigit;
            digit = PyNumber_And(stepval, mask);
            if (unlikely(!digit)) goto done;
            idigit = PyLong_AsLong(digit);
            Py_DECREF(digit);
            if (unlikely(idigit < 0)) goto done;
            val |= ((long) idigit) << bits;
            tmp = PyNumber_Rshift(stepval, shift);
            if (unlikely(!tmp)) goto done;
            Py_DECREF(stepval); stepval = tmp;
        }
        Py_DECREF(shift); shift = NULL;
        Py_DECREF(mask); mask = NULL;
        {
            long idigit = PyLong_AsLong(stepval);
            if (unlikely(idigit < 0)) goto done;
            remaining_bits = ((int) sizeof(long) * 8) - bits - (is_unsigned ? 0 : 1);
            if (unlikely(idigit >= (1L << remaining_bits)))
                goto raise_overflow;
            val |= ((long) idigit) << bits;
        }
        if (!is_unsigned) {
            if (unlikely(val & (((long) 1) << (sizeof(long) * 8 - 1))))
                goto raise_overflow;
            if (is_negative)
                val = ~val;
        }
        ret = 0;
    done:
        Py_XDECREF(shift);
        Py_XDECREF(mask);
        Py_XDECREF(stepval);
#endif
        if (unlikely(ret))
            return (long) -1;
        return val;
    }
raise_overflow:
    PyErr_SetString(PyExc_OverflowError,
        "value too large to convert to long");
    return (long) -1;
raise_neg_overflow:
    PyErr_SetString(PyExc_OverflowError,
        "can't convert negative value to long");
    return (long) -1;
}


static CYTHON_INLINE int __Pyx_PyLong_As_int(PyObject *x) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const int neg_one = (int) -1, const_zero = (int) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    if (unlikely(!PyLong_Check(x))) {
        int val;
        PyObject *tmp = __Pyx_PyNumber_Long(x);
        if (!tmp) return (int) -1;
        val = __Pyx_PyLong_As_int(tmp);
        Py_DECREF(tmp);
        return val;
    }
    if (is_unsigned) {
#if CYTHON_USE_PYLONG_INTERNALS
        if (unlikely(__Pyx_PyLong_IsNeg(x))) {
            goto raise_neg_overflow;
        } else if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(int, __Pyx_compact_upylong, __Pyx_PyLong_CompactValueUnsigned(x))
        } else {
            const digit* digits = __Pyx_PyLong_Digits(x);
            assert(__Pyx_PyLong_DigitCount(x) > 1);
            switch (__Pyx_PyLong_DigitCount(x)) {
                case 2:
                    if ((8 * sizeof(int) > 1 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) >= 2 * PyLong_SHIFT)) {
                            return (int) (((((int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
                        }
                    }
                    break;
                case 3:
                    if ((8 * sizeof(int) > 2 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) >= 3 * PyLong_SHIFT)) {
                            return (int) (((((((int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
                        }
                    }
                    break;
                case 4:
                    if ((8 * sizeof(int) > 3 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) >= 4 * PyLong_SHIFT)) {
                            return (int) (((((((((int)digits[3]) << PyLong_SHIFT) | (int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
                        }
                    }
                    break;
            }
        }
#endif
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX < 0x030C00A7
        if (unlikely(Py_SIZE(x) < 0)) {
            goto raise_neg_overflow;
        }
#else
        {
            int result = PyObject_RichCompareBool(x, Py_False, Py_LT);
            if (unlikely(result < 0))
                return (int) -1;
            if (unlikely(result == 1))
                goto raise_neg_overflow;
        }
#endif
        if ((sizeof(int) <= sizeof(unsigned long))) {
            __PYX_VERIFY_RETURN_INT_EXC(int, unsigned long, PyLong_AsUnsignedLong(x))
#ifdef HAVE_LONG_LONG
        } else if ((sizeof(int) <= sizeof(unsigned PY_LONG_LONG))) {
            __PYX_VERIFY_RETURN_INT_EXC(int, unsigned PY_LONG_LONG, PyLong_AsUnsignedLongLong(x))
#endif
        }
    } else {
#if CYTHON_USE_PYLONG_INTERNALS
        if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(int, __Pyx_compact_pylong, __Pyx_PyLong_CompactValue(x))
        } else {
            const digit* digits = __Pyx_PyLong_Digits(x);
            assert(__Pyx_PyLong_DigitCount(x) > 1);
            switch (__Pyx_PyLong_SignedDigitCount(x)) {
                case -2:
                    if ((8 * sizeof(int) - 1 > 1 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, long, -(long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) - 1 > 2 * PyLong_SHIFT)) {
                            return (int) (((int)-1)*(((((int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
                        }
                    }
                    break;
                case 2:
                    if ((8 * sizeof(int) > 1 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) - 1 > 2 * PyLong_SHIFT)) {
                            return (int) ((((((int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
                        }
                    }
                    break;
                case -3:
                    if ((8 * sizeof(int) - 1 > 2 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, long, -(long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) - 1 > 3 * PyLong_SHIFT)) {
                            return (int) (((int)-1)*(((((((int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
                        }
                    }
                    break;
                case 3:
                    if ((8 * sizeof(int) > 2 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) - 1 > 3 * PyLong_SHIFT)) {
                            return (int) ((((((((int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
                        }
                    }
                    break;
                case -4:
                    if ((8 * sizeof(int) - 1 > 3 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, long, -(long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) - 1 > 4 * PyLong_SHIFT)) {
                            return (int) (((int)-1)*(((((((((int)digits[3]) << PyLong_SHIFT) | (int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
                        }
                    }
                    break;
                case 4:
                    if ((8 * sizeof(int) > 3 * PyLong_SHIFT)) {
                        if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                            __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
                        } else if ((8 * sizeof(int) - 1 > 4 * PyLong_SHIFT)) {
                            return (int) ((((((((((int)digits[3]) << PyLong_SHIFT) | (int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
                        }
                    }
                    break;
            }
        }
#endif
        if ((sizeof(int) <= sizeof(long))) {
            __PYX_VERIFY_RETURN_INT_EXC(int, long, PyLong_AsLong(x))
#ifdef HAVE_LONG_LONG
        } else if ((sizeof(int) <= sizeof(PY_LONG_LONG))) {
            __PYX_VERIFY_RETURN_INT_EXC(int, PY_LONG_LONG, PyLong_AsLongLong(x))
#endif
        }
    }
    {
        int val;
        int ret = -1;
#if PY_VERSION_HEX >= 0x030d00A6 && !CYTHON_COMPILING_IN_LIMITED_API
        Py_ssize_t bytes_copied = PyLong_AsNativeBytes(
            x, &val, sizeof(val), Py_ASNATIVEBYTES_NATIVE_ENDIAN | (is_unsigned ? Py_ASNATIVEBYTES_UNSIGNED_BUFFER | Py_ASNATIVEBYTES_REJECT_NEGATIVE : 0));
        if (unlikely(bytes_copied == -1)) {
        } else if (unlikely(bytes_copied > (Py_ssize_t) sizeof(val))) {
            goto raise_overflow;
        } else {
            ret = 0;
        }
#elif PY_VERSION_HEX < 0x030d0000 && !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_LIMITED_API) || defined(_PyLong_AsByteArray)
        int one = 1; int is_little = (int)*(unsigned char *)&one;
        unsigned char *bytes = (unsigned char *)&val;
        ret = _PyLong_AsByteArray((PyLongObject *)x,
                                    bytes, sizeof(val),
                                    is_little, !is_unsigned);
#else
        PyObject *v;
        PyObject *stepval = NULL, *mask = NULL, *shift = NULL;
        int bits, remaining_bits, is_negative = 0;
        int chunk_size = (sizeof(long) < 8) ? 30 : 62;
        if (likely(PyLong_CheckExact(x))) {
            v = __Pyx_NewRef(x);
        } else {
            v = PyNumber_Long(x);
            if (unlikely(!v)) return (int) -1;
            assert(PyLong_CheckExact(v));
        }
        {
            int result = PyObject_RichCompareBool(v, Py_False, Py_LT);
            if (unlikely(result < 0)) {
                Py_DECREF(v);
                return (int) -1;
            }
            is_negative = result == 1;
        }
        if (is_unsigned && unlikely(is_negative)) {
            Py_DECREF(v);
            goto raise_neg_overflow;
        } else if (is_negative) {
            stepval = PyNumber_Invert(v);
            Py_DECREF(v);
            if (unlikely(!stepval))
                return (int) -1;
        } else {
            stepval = v;
        }
        v = NULL;
        val = (int) 0;
        mask = PyLong_FromLong((1L << chunk_size) - 1); if (unlikely(!mask)) goto done;
        shift = PyLong_FromLong(chunk_size); if (unlikely(!shift)) goto done;
        for (bits = 0; bits < (int) sizeof(int) * 8 - chunk_size; bits += chunk_size) {
            PyObject *tmp, *digit;
            long idigit;
            digit = PyNumber_And(stepval, mask);
            if (unlikely(!digit)) goto done;
            idigit = PyLong_AsLong(digit);
            Py_DECREF(digit);
            if (unlikely(idigit < 0)) goto done;
            val |= ((int) idigit) << bits;
            tmp = PyNumber_Rshift(stepval, shift);
            if (unlikely(!tmp)) goto done;
            Py_DECREF(stepval); stepval = tmp;
        }
        Py_DECREF(shift); shift = NULL;
        Py_DECREF(mask); mask = NULL;
        {
            long idigit = PyLong_AsLong(stepval);
            if (unlikely(idigit < 0)) goto done;
            remaining_bits = ((int) sizeof(int) * 8) - bits - (is_unsigned ? 0 : 1);
            if (unlikely(idigit >= (1L << remaining_bits)))
                goto raise_overflow;
            val |= ((int) idigit) << bits;
        }
        if (!is_unsigned) {
            if (unlikely(val & (((int) 1) << (sizeof(int) * 8 - 1))))
                goto raise_overflow;
            if (is_negative)
                val = ~val;
        }
        ret = 0;
    done:
        Py_XDECREF(shift);
        Py_XDECREF(mask);
        Py_XDECREF(stepval);
#endif
        if (unlikely(ret))
            return (int) -1;
        return val;
    }
raise_overflow:
    PyErr_SetString(PyExc_OverflowError,
        "value too large to convert to int");
    return (int) -1;
raise_neg_overflow:
    PyErr_SetString(PyExc_OverflowError,
        "can't convert negative value to int");
    return (int) -1;
}


static unsigned long __Pyx_get_runtime_version(void) {
#if __PYX_LIMITED_VERSION_HEX >= 0x030b0000
    return Py_Version & ~0xFFUL;
#else
    static unsigned long __Pyx_cached_runtime_version = 0;
    if (__Pyx_cached_runtime_version == 0) {
        const char* rt_version = Py_GetVersion();
        unsigned long version = 0;
        unsigned long factor = 0x01000000UL;
        unsigned int digit = 0;
        int i = 0;
        while (factor) {
            while ('0' <= rt_version[i] && rt_version[i] <= '9') {
                digit = digit * 10 + (unsigned int) (rt_version[i] - '0');
                ++i;
            }
            version += factor * digit;
            if (rt_version[i] != '.')
                break;
            digit = 0;
            factor >>= 8;
            ++i;
        }
        __Pyx_cached_runtime_version = version;
    }
    return __Pyx_cached_runtime_version;
#endif
}


static int __Pyx_check_binary_version(unsigned long ct_version, unsigned long rt_version, int allow_newer) {
    const unsigned long MAJOR_MINOR = 0xFFFF0000UL;
    if ((rt_version & MAJOR_MINOR) == (ct_version & MAJOR_MINOR))
        return 0;
    if (likely(allow_newer && (rt_version & MAJOR_MINOR) > (ct_version & MAJOR_MINOR)))
        return 1;
    {
        char message[200];
        PyOS_snprintf(message, sizeof(message),
                      "compile time Python version %d.%d "
                      "of module '%.100s' "
                      "%s "
                      "runtime version %d.%d",
                       (int) (ct_version >> 24), (int) ((ct_version >> 16) & 0xFF),
                       __Pyx_MODULE_NAME,
                       (allow_newer) ? "was newer than" : "does not match",
                       (int) (rt_version >> 24), (int) ((rt_version >> 16) & 0xFF)
       );
        return PyErr_WarnEx(NULL, message, 1);
    }
}


#if CYTHON_COMPILING_IN_LIMITED_API
    static PyObject* __Pyx__PyCode_New(int a, int p, int k, int l, int s, int f,
                                       PyObject *code, PyObject *c, PyObject* n, PyObject *v,
                                       PyObject *fv, PyObject *cell, PyObject* fn,
                                       PyObject *name, int fline, PyObject *lnos) {
        PyObject *exception_table = NULL;
        PyObject *types_module=NULL, *code_type=NULL, *result=NULL;
        #if __PYX_LIMITED_VERSION_HEX < 0x030b0000
        PyObject *version_info;
        PyObject *py_minor_version = NULL;
        #endif
        long minor_version = 0;
        PyObject *type, *value, *traceback;
        PyErr_Fetch(&type, &value, &traceback);
        #if __PYX_LIMITED_VERSION_HEX >= 0x030b0000
        minor_version = 11;
        #else
        if (!(version_info = PySys_GetObject("version_info"))) goto end;
        if (!(py_minor_version = PySequence_GetItem(version_info, 1))) goto end;
        minor_version = PyLong_AsLong(py_minor_version);
        Py_DECREF(py_minor_version);
        if (minor_version == -1 && PyErr_Occurred()) goto end;
        #endif
        if (!(types_module = PyImport_ImportModule("types"))) goto end;
        if (!(code_type = PyObject_GetAttrString(types_module, "CodeType"))) goto end;
        if (minor_version <= 7) {
            (void)p;
            result = PyObject_CallFunction(code_type, "iiiiiOOOOOOiOOO", a, k, l, s, f, code,
                          c, n, v, fn, name, fline, lnos, fv, cell);
        } else if (minor_version <= 10) {
            result = PyObject_CallFunction(code_type, "iiiiiiOOOOOOiOOO", a,p, k, l, s, f, code,
                          c, n, v, fn, name, fline, lnos, fv, cell);
        } else {
            if (!(exception_table = PyBytes_FromStringAndSize(NULL, 0))) goto end;
            result = PyObject_CallFunction(code_type, "iiiiiiOOOOOOOiOOOO", a,p, k, l, s, f, code,
                          c, n, v, fn, name, name, fline, lnos, exception_table, fv, cell);
        }
    end:
        Py_XDECREF(code_type);
        Py_XDECREF(exception_table);
        Py_XDECREF(types_module);
        if (type) {
            PyErr_Restore(type, value, traceback);
        }
        return result;
    }
#elif PY_VERSION_HEX >= 0x030B0000
  static PyCodeObject* __Pyx__PyCode_New(int a, int p, int k, int l, int s, int f,
                                         PyObject *code, PyObject *c, PyObject* n, PyObject *v,
                                         PyObject *fv, PyObject *cell, PyObject* fn,
                                         PyObject *name, int fline, PyObject *lnos) {
    PyCodeObject *result;
    result =
      #if PY_VERSION_HEX >= 0x030C0000
        PyUnstable_Code_NewWithPosOnlyArgs
      #else
        PyCode_NewWithPosOnlyArgs
      #endif
        (a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, name, fline, lnos, __pyx_mstate_global->__pyx_empty_bytes);
    #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030c00A1
    if (likely(result))
        result->_co_firsttraceable = 0;
    #endif
    return result;
  }
#elif PY_VERSION_HEX >= 0x030800B2 && !CYTHON_COMPILING_IN_PYPY
  #define __Pyx__PyCode_New(a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)\
          PyCode_NewWithPosOnlyArgs(a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)
#else
  #define __Pyx__PyCode_New(a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)\
          PyCode_New(a, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)
#endif
static PyObject* __Pyx_PyCode_New(
        const __Pyx_PyCode_New_function_description descr,
        PyObject * const *varnames,
        PyObject *filename,
        PyObject *funcname,
        const char *line_table,
        PyObject *tuple_dedup_map
) {
    PyObject *code_obj = NULL, *varnames_tuple_dedup = NULL, *code_bytes = NULL, *line_table_bytes = NULL;
    Py_ssize_t var_count = (Py_ssize_t) descr.nlocals;
    PyObject *varnames_tuple = PyTuple_New(var_count);
    if (unlikely(!varnames_tuple)) return NULL;
    for (Py_ssize_t i=0; i < var_count; i++) {
        Py_INCREF(varnames[i]);
        if (__Pyx_PyTuple_SET_ITEM(varnames_tuple, i, varnames[i]) != (0)) goto done;
    }
    #if CYTHON_COMPILING_IN_LIMITED_API
    varnames_tuple_dedup = PyDict_GetItem(tuple_dedup_map, varnames_tuple);
    if (!varnames_tuple_dedup) {
        if (unlikely(PyDict_SetItem(tuple_dedup_map, varnames_tuple, varnames_tuple) < 0)) goto done;
        varnames_tuple_dedup = varnames_tuple;
    }
    #else
    varnames_tuple_dedup = PyDict_SetDefault(tuple_dedup_map, varnames_tuple, varnames_tuple);
    if (unlikely(!varnames_tuple_dedup)) goto done;
    #endif
    #if CYTHON_AVOID_BORROWED_REFS
    Py_INCREF(varnames_tuple_dedup);
    #endif
    if (__PYX_LIMITED_VERSION_HEX >= (0x030b0000) && line_table != NULL
        && !CYTHON_COMPILING_IN_GRAAL) {
        line_table_bytes = PyBytes_FromStringAndSize(line_table, descr.line_table_length);
        if (unlikely(!line_table_bytes)) goto done;
        Py_ssize_t code_len = (descr.line_table_length * 2 + 4) & ~3;
        code_bytes = PyBytes_FromStringAndSize(NULL, code_len);
        if (unlikely(!code_bytes)) goto done;
        char* c_code_bytes = PyBytes_AsString(code_bytes);
        if (unlikely(!c_code_bytes)) goto done;
        memset(c_code_bytes, 0, (size_t) code_len);
    }
    code_obj = (PyObject*) __Pyx__PyCode_New(
        (int) descr.argcount,
        (int) descr.num_posonly_args,
        (int) descr.num_kwonly_args,
        (int) descr.nlocals,
        0,
        (int) descr.flags,
        code_bytes ? code_bytes : __pyx_mstate_global->__pyx_empty_bytes,
        __pyx_mstate_global->__pyx_empty_tuple,
        __pyx_mstate_global->__pyx_empty_tuple,
        varnames_tuple_dedup,
        __pyx_mstate_global->__pyx_empty_tuple,
        __pyx_mstate_global->__pyx_empty_tuple,
        filename,
        funcname,
        (int) descr.first_line,
        (__PYX_LIMITED_VERSION_HEX >= (0x030b0000) && line_table_bytes) ? line_table_bytes : __pyx_mstate_global->__pyx_empty_bytes
    );
done:
    Py_XDECREF(code_bytes);
    Py_XDECREF(line_table_bytes);
    #if CYTHON_AVOID_BORROWED_REFS
    Py_XDECREF(varnames_tuple_dedup);
    #endif
    Py_DECREF(varnames_tuple);
    return code_obj;
}


static int __Pyx_InitStrings(__Pyx_StringTabEntry const *t, PyObject **target, const char* const* encoding_names) {
    while (t->s) {
        PyObject *str;
        if (t->is_unicode) {
            if (t->intern) {
                str = PyUnicode_InternFromString(t->s);
            } else if (t->encoding) {
                str = PyUnicode_Decode(t->s, t->n - 1, encoding_names[t->encoding], NULL);
            } else {
                str = PyUnicode_FromStringAndSize(t->s, t->n - 1);
            }
        } else {
            str = PyBytes_FromStringAndSize(t->s, t->n - 1);
        }
        if (!str)
            return -1;
        *target = str;
        if (PyObject_Hash(str) == -1)
            return -1;
        ++t;
        ++target;
    }
    return 0;
}

#include <string.h>
static CYTHON_INLINE Py_ssize_t __Pyx_ssize_strlen(const char *s) {
    size_t len = strlen(s);
    if (unlikely(len > (size_t) PY_SSIZE_T_MAX)) {
        PyErr_SetString(PyExc_OverflowError, "byte string is too long");
        return -1;
    }
    return (Py_ssize_t) len;
}
static CYTHON_INLINE PyObject* __Pyx_PyUnicode_FromString(const char* c_str) {
    Py_ssize_t len = __Pyx_ssize_strlen(c_str);
    if (unlikely(len < 0)) return NULL;
    return __Pyx_PyUnicode_FromStringAndSize(c_str, len);
}
static CYTHON_INLINE PyObject* __Pyx_PyByteArray_FromString(const char* c_str) {
    Py_ssize_t len = __Pyx_ssize_strlen(c_str);
    if (unlikely(len < 0)) return NULL;
    return PyByteArray_FromStringAndSize(c_str, len);
}
static CYTHON_INLINE const char* __Pyx_PyObject_AsString(PyObject* o) {
    Py_ssize_t ignore;
    return __Pyx_PyObject_AsStringAndSize(o, &ignore);
}
#if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII || __PYX_DEFAULT_STRING_ENCODING_IS_UTF8
static CYTHON_INLINE const char* __Pyx_PyUnicode_AsStringAndSize(PyObject* o, Py_ssize_t *length) {
    if (unlikely(__Pyx_PyUnicode_READY(o) == -1)) return NULL;
#if CYTHON_COMPILING_IN_LIMITED_API
    {
        const char* result;
        Py_ssize_t unicode_length;
        CYTHON_MAYBE_UNUSED_VAR(unicode_length); // only for __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
        #if __PYX_LIMITED_VERSION_HEX < 0x030A0000
        if (unlikely(PyArg_Parse(o, "s#", &result, length) < 0)) return NULL;
        #else
        result = PyUnicode_AsUTF8AndSize(o, length);
        #endif
        #if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
        unicode_length = PyUnicode_GetLength(o);
        if (unlikely(unicode_length < 0)) return NULL;
        if (unlikely(unicode_length != *length)) {
            PyUnicode_AsASCIIString(o);
            return NULL;
        }
        #endif
        return result;
    }
#else
#if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
    if (likely(PyUnicode_IS_ASCII(o))) {
        *length = PyUnicode_GET_LENGTH(o);
        return PyUnicode_AsUTF8(o);
    } else {
        PyUnicode_AsASCIIString(o);
        return NULL;
    }
#else
    return PyUnicode_AsUTF8AndSize(o, length);
#endif
#endif
}
#endif
static CYTHON_INLINE const char* __Pyx_PyObject_AsStringAndSize(PyObject* o, Py_ssize_t *length) {
#if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII || __PYX_DEFAULT_STRING_ENCODING_IS_UTF8
    if (PyUnicode_Check(o)) {
        return __Pyx_PyUnicode_AsStringAndSize(o, length);
    } else
#endif
    if (PyByteArray_Check(o)) {
#if (CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS) || (CYTHON_COMPILING_IN_PYPY && (defined(PyByteArray_AS_STRING) && defined(PyByteArray_GET_SIZE)))
        *length = PyByteArray_GET_SIZE(o);
        return PyByteArray_AS_STRING(o);
#else
        *length = PyByteArray_Size(o);
        if (*length == -1) return NULL;
        return PyByteArray_AsString(o);
#endif
    } else
    {
        char* result;
        int r = PyBytes_AsStringAndSize(o, &result, length);
        if (unlikely(r < 0)) {
            return NULL;
        } else {
            return result;
        }
    }
}
static CYTHON_INLINE int __Pyx_PyObject_IsTrue(PyObject* x) {
   int is_true = x == Py_True;
   if (is_true | (x == Py_False) | (x == Py_None)) return is_true;
   else return PyObject_IsTrue(x);
}
static CYTHON_INLINE int __Pyx_PyObject_IsTrueAndDecref(PyObject* x) {
    int retval;
    if (unlikely(!x)) return -1;
    retval = __Pyx_PyObject_IsTrue(x);
    Py_DECREF(x);
    return retval;
}
static PyObject* __Pyx_PyNumber_LongWrongResultType(PyObject* result) {
    __Pyx_TypeName result_type_name = __Pyx_PyType_GetFullyQualifiedName(Py_TYPE(result));
    if (PyLong_Check(result)) {
        if (PyErr_WarnFormat(PyExc_DeprecationWarning, 1,
                "__int__ returned non-int (type " __Pyx_FMT_TYPENAME ").  "
                "The ability to return an instance of a strict subclass of int is deprecated, "
                "and may be removed in a future version of Python.",
                result_type_name)) {
            __Pyx_DECREF_TypeName(result_type_name);
            Py_DECREF(result);
            return NULL;
        }
        __Pyx_DECREF_TypeName(result_type_name);
        return result;
    }
    PyErr_Format(PyExc_TypeError,
                 "__int__ returned non-int (type " __Pyx_FMT_TYPENAME ")",
                 result_type_name);
    __Pyx_DECREF_TypeName(result_type_name);
    Py_DECREF(result);
    return NULL;
}
static CYTHON_INLINE PyObject* __Pyx_PyNumber_Long(PyObject* x) {
#if CYTHON_USE_TYPE_SLOTS
  PyNumberMethods *m;
#endif
  PyObject *res = NULL;
  if (likely(PyLong_Check(x)))
      return __Pyx_NewRef(x);
#if CYTHON_USE_TYPE_SLOTS
  m = Py_TYPE(x)->tp_as_number;
  if (likely(m && m->nb_int)) {
      res = m->nb_int(x);
  }
#else
  if (!PyBytes_CheckExact(x) && !PyUnicode_CheckExact(x)) {
      res = PyNumber_Long(x);
  }
#endif
  if (likely(res)) {
      if (unlikely(!PyLong_CheckExact(res))) {
          return __Pyx_PyNumber_LongWrongResultType(res);
      }
  }
  else if (!PyErr_Occurred()) {
      PyErr_SetString(PyExc_TypeError,
                      "an integer is required");
  }
  return res;
}
static CYTHON_INLINE Py_ssize_t __Pyx_PyIndex_AsSsize_t(PyObject* b) {
  Py_ssize_t ival;
  PyObject *x;
  if (likely(PyLong_CheckExact(b))) {
    #if CYTHON_USE_PYLONG_INTERNALS
    if (likely(__Pyx_PyLong_IsCompact(b))) {
        return __Pyx_PyLong_CompactValue(b);
    } else {
      const digit* digits = __Pyx_PyLong_Digits(b);
      const Py_ssize_t size = __Pyx_PyLong_SignedDigitCount(b);
      switch (size) {
         case 2:
           if (8 * sizeof(Py_ssize_t) > 2 * PyLong_SHIFT) {
             return (Py_ssize_t) (((((size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
           }
           break;
         case -2:
           if (8 * sizeof(Py_ssize_t) > 2 * PyLong_SHIFT) {
             return -(Py_ssize_t) (((((size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
           }
           break;
         case 3:
           if (8 * sizeof(Py_ssize_t) > 3 * PyLong_SHIFT) {
             return (Py_ssize_t) (((((((size_t)digits[2]) << PyLong_SHIFT) | (size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
           }
           break;
         case -3:
           if (8 * sizeof(Py_ssize_t) > 3 * PyLong_SHIFT) {
             return -(Py_ssize_t) (((((((size_t)digits[2]) << PyLong_SHIFT) | (size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
           }
           break;
         case 4:
           if (8 * sizeof(Py_ssize_t) > 4 * PyLong_SHIFT) {
             return (Py_ssize_t) (((((((((size_t)digits[3]) << PyLong_SHIFT) | (size_t)digits[2]) << PyLong_SHIFT) | (size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
           }
           break;
         case -4:
           if (8 * sizeof(Py_ssize_t) > 4 * PyLong_SHIFT) {
             return -(Py_ssize_t) (((((((((size_t)digits[3]) << PyLong_SHIFT) | (size_t)digits[2]) << PyLong_SHIFT) | (size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
           }
           break;
      }
    }
    #endif
    return PyLong_AsSsize_t(b);
  }
  x = PyNumber_Index(b);
  if (!x) return -1;
  ival = PyLong_AsSsize_t(x);
  Py_DECREF(x);
  return ival;
}
static CYTHON_INLINE Py_hash_t __Pyx_PyIndex_AsHash_t(PyObject* o) {
  if (sizeof(Py_hash_t) == sizeof(Py_ssize_t)) {
    return (Py_hash_t) __Pyx_PyIndex_AsSsize_t(o);
  } else {
    Py_ssize_t ival;
    PyObject *x;
    x = PyNumber_Index(o);
    if (!x) return -1;
    ival = PyLong_AsLong(x);
    Py_DECREF(x);
    return ival;
  }
}
static CYTHON_INLINE PyObject *__Pyx_Owned_Py_None(int b) {
    CYTHON_UNUSED_VAR(b);
    return __Pyx_NewRef(Py_None);
}
static CYTHON_INLINE PyObject * __Pyx_PyBool_FromLong(long b) {
  return b ? __Pyx_NewRef(Py_True) : __Pyx_NewRef(Py_False);
}
static CYTHON_INLINE PyObject * __Pyx_PyLong_FromSize_t(size_t ival) {
    return PyLong_FromSize_t(ival);
}



#if CYTHON_PEP489_MULTI_PHASE_INIT && CYTHON_USE_MODULE_STATE
#ifndef CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
#if (CYTHON_COMPILING_IN_LIMITED_API || PY_VERSION_HEX >= 0x030C0000)
  #define CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE 1
#else
  #define CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE 0
#endif
#endif
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE && !CYTHON_ATOMICS
#error "Module state with PEP489 requires atomics. Currently that's one of\
 C11, C++11, gcc atomic intrinsics or MSVC atomic intrinsics"
#endif
#if !CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
#define __Pyx_ModuleStateLookup_Lock()
#define __Pyx_ModuleStateLookup_Unlock()
#elif !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030d0000
static PyMutex __Pyx_ModuleStateLookup_mutex = {0};
#define __Pyx_ModuleStateLookup_Lock() PyMutex_Lock(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() PyMutex_Unlock(&__Pyx_ModuleStateLookup_mutex)
#elif defined(__cplusplus) && __cplusplus >= 201103L
#include <mutex>
static std::mutex __Pyx_ModuleStateLookup_mutex;
#define __Pyx_ModuleStateLookup_Lock() __Pyx_ModuleStateLookup_mutex.lock()
#define __Pyx_ModuleStateLookup_Unlock() __Pyx_ModuleStateLookup_mutex.unlock()
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ > 201112L) && !defined(__STDC_NO_THREADS__)
#include <threads.h>
static mtx_t __Pyx_ModuleStateLookup_mutex;
static once_flag __Pyx_ModuleStateLookup_mutex_once_flag = ONCE_FLAG_INIT;
static void __Pyx_ModuleStateLookup_initialize_mutex(void) {
    mtx_init(&__Pyx_ModuleStateLookup_mutex, mtx_plain);
}
#define __Pyx_ModuleStateLookup_Lock()\
  call_once(&__Pyx_ModuleStateLookup_mutex_once_flag, __Pyx_ModuleStateLookup_initialize_mutex);\
  mtx_lock(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() mtx_unlock(&__Pyx_ModuleStateLookup_mutex)
#elif defined(HAVE_PTHREAD_H)
#include <pthread.h>
static pthread_mutex_t __Pyx_ModuleStateLookup_mutex = PTHREAD_MUTEX_INITIALIZER;
#define __Pyx_ModuleStateLookup_Lock() pthread_mutex_lock(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() pthread_mutex_unlock(&__Pyx_ModuleStateLookup_mutex)
#elif defined(_WIN32)
#include <Windows.h>  // synchapi.h on its own doesn't work
static SRWLOCK __Pyx_ModuleStateLookup_mutex = SRWLOCK_INIT;
#define __Pyx_ModuleStateLookup_Lock() AcquireSRWLockExclusive(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() ReleaseSRWLockExclusive(&__Pyx_ModuleStateLookup_mutex)
#else
#error "No suitable lock available for CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE.\
 Requires C standard >= C11, or C++ standard >= C++11,\
 or pthreads, or the Windows 32 API, or Python >= 3.13."
#endif
typedef struct {
    int64_t id;
    PyObject *module;
} __Pyx_InterpreterIdAndModule;
typedef struct {
    char interpreter_id_as_index;
    Py_ssize_t count;
    Py_ssize_t allocated;
    __Pyx_InterpreterIdAndModule table[1];
} __Pyx_ModuleStateLookupData;
#define __PYX_MODULE_STATE_LOOKUP_SMALL_SIZE 32
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
static __pyx_atomic_int_type __Pyx_ModuleStateLookup_read_counter = 0;
#endif
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
static __pyx_atomic_ptr_type __Pyx_ModuleStateLookup_data = 0;
#else
static __Pyx_ModuleStateLookupData* __Pyx_ModuleStateLookup_data = NULL;
#endif
static __Pyx_InterpreterIdAndModule* __Pyx_State_FindModuleStateLookupTableLowerBound(
        __Pyx_InterpreterIdAndModule* table,
        Py_ssize_t count,
        int64_t interpreterId) {
    __Pyx_InterpreterIdAndModule* begin = table;
    __Pyx_InterpreterIdAndModule* end = begin + count;
    if (begin->id == interpreterId) {
        return begin;
    }
    while ((end - begin) > __PYX_MODULE_STATE_LOOKUP_SMALL_SIZE) {
        __Pyx_InterpreterIdAndModule* halfway = begin + (end - begin)/2;
        if (halfway->id == interpreterId) {
            return halfway;
        }
        if (halfway->id < interpreterId) {
            begin = halfway;
        } else {
            end = halfway;
        }
    }
    for (; begin < end; ++begin) {
        if (begin->id >= interpreterId) return begin;
    }
    return begin;
}
static PyObject *__Pyx_State_FindModule(CYTHON_UNUSED void* dummy) {
    int64_t interpreter_id = PyInterpreterState_GetID(__Pyx_PyInterpreterState_Get());
    if (interpreter_id == -1) return NULL;
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __Pyx_ModuleStateLookupData* data = (__Pyx_ModuleStateLookupData*)__pyx_atomic_pointer_load_relaxed(&__Pyx_ModuleStateLookup_data);
    {
        __pyx_atomic_incr_acq_rel(&__Pyx_ModuleStateLookup_read_counter);
        if (likely(data)) {
            __Pyx_ModuleStateLookupData* new_data = (__Pyx_ModuleStateLookupData*)__pyx_atomic_pointer_load_acquire(&__Pyx_ModuleStateLookup_data);
            if (likely(data == new_data)) {
                goto read_finished;
            }
        }
        __pyx_atomic_decr_acq_rel(&__Pyx_ModuleStateLookup_read_counter);
        __Pyx_ModuleStateLookup_Lock();
        __pyx_atomic_incr_relaxed(&__Pyx_ModuleStateLookup_read_counter);
        data = (__Pyx_ModuleStateLookupData*)__pyx_atomic_pointer_load_relaxed(&__Pyx_ModuleStateLookup_data);
        __Pyx_ModuleStateLookup_Unlock();
    }
  read_finished:;
#else
    __Pyx_ModuleStateLookupData* data = __Pyx_ModuleStateLookup_data;
#endif
    __Pyx_InterpreterIdAndModule* found = NULL;
    if (unlikely(!data)) goto end;
    if (data->interpreter_id_as_index) {
        if (interpreter_id < data->count) {
            found = data->table+interpreter_id;
        }
    } else {
        found = __Pyx_State_FindModuleStateLookupTableLowerBound(
            data->table, data->count, interpreter_id);
    }
  end:
    {
        PyObject *result=NULL;
        if (found && found->id == interpreter_id) {
            result = found->module;
        }
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
        __pyx_atomic_decr_acq_rel(&__Pyx_ModuleStateLookup_read_counter);
#endif
        return result;
    }
}
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
static void __Pyx_ModuleStateLookup_wait_until_no_readers(void) {
    while (__pyx_atomic_load(&__Pyx_ModuleStateLookup_read_counter) != 0);
}
#else
#define __Pyx_ModuleStateLookup_wait_until_no_readers()
#endif
static int __Pyx_State_AddModuleInterpIdAsIndex(__Pyx_ModuleStateLookupData **old_data, PyObject* module, int64_t interpreter_id) {
    Py_ssize_t to_allocate = (*old_data)->allocated;
    while (to_allocate <= interpreter_id) {
        if (to_allocate == 0) to_allocate = 1;
        else to_allocate *= 2;
    }
    __Pyx_ModuleStateLookupData *new_data = *old_data;
    if (to_allocate != (*old_data)->allocated) {
         new_data = (__Pyx_ModuleStateLookupData *)realloc(
            *old_data,
            sizeof(__Pyx_ModuleStateLookupData)+(to_allocate-1)*sizeof(__Pyx_InterpreterIdAndModule));
        if (!new_data) {
            PyErr_NoMemory();
            return -1;
        }
        for (Py_ssize_t i = new_data->allocated; i < to_allocate; ++i) {
            new_data->table[i].id = i;
            new_data->table[i].module = NULL;
        }
        new_data->allocated = to_allocate;
    }
    new_data->table[interpreter_id].module = module;
    if (new_data->count < interpreter_id+1) {
        new_data->count = interpreter_id+1;
    }
    *old_data = new_data;
    return 0;
}
static void __Pyx_State_ConvertFromInterpIdAsIndex(__Pyx_ModuleStateLookupData *data) {
    __Pyx_InterpreterIdAndModule *read = data->table;
    __Pyx_InterpreterIdAndModule *write = data->table;
    __Pyx_InterpreterIdAndModule *end = read + data->count;
    for (; read<end; ++read) {
        if (read->module) {
            write->id = read->id;
            write->module = read->module;
            ++write;
        }
    }
    data->count = write - data->table;
    for (; write<end; ++write) {
        write->id = 0;
        write->module = NULL;
    }
    data->interpreter_id_as_index = 0;
}
static int __Pyx_State_AddModule(PyObject* module, CYTHON_UNUSED void* dummy) {
    int64_t interpreter_id = PyInterpreterState_GetID(__Pyx_PyInterpreterState_Get());
    if (interpreter_id == -1) return -1;
    int result = 0;
    __Pyx_ModuleStateLookup_Lock();
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __Pyx_ModuleStateLookupData *old_data = (__Pyx_ModuleStateLookupData *)
            __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, 0);
#else
    __Pyx_ModuleStateLookupData *old_data = __Pyx_ModuleStateLookup_data;
#endif
    __Pyx_ModuleStateLookupData *new_data = old_data;
    if (!new_data) {
        new_data = (__Pyx_ModuleStateLookupData *)calloc(1, sizeof(__Pyx_ModuleStateLookupData));
        if (!new_data) {
            result = -1;
            PyErr_NoMemory();
            goto end;
        }
        new_data->allocated = 1;
        new_data->interpreter_id_as_index = 1;
    }
    __Pyx_ModuleStateLookup_wait_until_no_readers();
    if (new_data->interpreter_id_as_index) {
        if (interpreter_id < __PYX_MODULE_STATE_LOOKUP_SMALL_SIZE) {
            result = __Pyx_State_AddModuleInterpIdAsIndex(&new_data, module, interpreter_id);
            goto end;
        }
        __Pyx_State_ConvertFromInterpIdAsIndex(new_data);
    }
    {
        Py_ssize_t insert_at = 0;
        {
            __Pyx_InterpreterIdAndModule* lower_bound = __Pyx_State_FindModuleStateLookupTableLowerBound(
                new_data->table, new_data->count, interpreter_id);
            assert(lower_bound);
            insert_at = lower_bound - new_data->table;
            if (unlikely(insert_at < new_data->count && lower_bound->id == interpreter_id)) {
                lower_bound->module = module;
                goto end;  // already in table, nothing more to do
            }
        }
        if (new_data->count+1 >= new_data->allocated) {
            Py_ssize_t to_allocate = (new_data->count+1)*2;
            new_data =
                (__Pyx_ModuleStateLookupData*)realloc(
                    new_data,
                    sizeof(__Pyx_ModuleStateLookupData) +
                    (to_allocate-1)*sizeof(__Pyx_InterpreterIdAndModule));
            if (!new_data) {
                result = -1;
                new_data = old_data;
                PyErr_NoMemory();
                goto end;
            }
            new_data->allocated = to_allocate;
        }
        ++new_data->count;
        int64_t last_id = interpreter_id;
        PyObject *last_module = module;
        for (Py_ssize_t i=insert_at; i<new_data->count; ++i) {
            int64_t current_id = new_data->table[i].id;
            new_data->table[i].id = last_id;
            last_id = current_id;
            PyObject *current_module = new_data->table[i].module;
            new_data->table[i].module = last_module;
            last_module = current_module;
        }
    }
  end:
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, new_data);
#else
    __Pyx_ModuleStateLookup_data = new_data;
#endif
    __Pyx_ModuleStateLookup_Unlock();
    return result;
}
static int __Pyx_State_RemoveModule(CYTHON_UNUSED void* dummy) {
    int64_t interpreter_id = PyInterpreterState_GetID(__Pyx_PyInterpreterState_Get());
    if (interpreter_id == -1) return -1;
    __Pyx_ModuleStateLookup_Lock();
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __Pyx_ModuleStateLookupData *data = (__Pyx_ModuleStateLookupData *)
            __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, 0);
#else
    __Pyx_ModuleStateLookupData *data = __Pyx_ModuleStateLookup_data;
#endif
    if (data->interpreter_id_as_index) {
        if (interpreter_id < data->count) {
            data->table[interpreter_id].module = NULL;
        }
        goto done;
    }
    {
        __Pyx_ModuleStateLookup_wait_until_no_readers();
        __Pyx_InterpreterIdAndModule* lower_bound = __Pyx_State_FindModuleStateLookupTableLowerBound(
            data->table, data->count, interpreter_id);
        if (!lower_bound) goto done;
        if (lower_bound->id != interpreter_id) goto done;
        __Pyx_InterpreterIdAndModule *end = data->table+data->count;
        for (;lower_bound<end-1; ++lower_bound) {
            lower_bound->id = (lower_bound+1)->id;
            lower_bound->module = (lower_bound+1)->module;
        }
    }
    --data->count;
    if (data->count == 0) {
        free(data);
        data = NULL;
    }
  done:
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, data);
#else
    __Pyx_ModuleStateLookup_data = data;
#endif
    __Pyx_ModuleStateLookup_Unlock();
    return 0;
}
#endif


#ifdef _MSC_VER
#pragma warning( pop )
#endif




#endif 
