"""
Hyperlink utilities for excelstyler.

This module provides functions to easily add hyperlinks to Excel cells.
"""

from typing import Any, Optional
from openpyxl.cell.cell import Hyperlink


def add_hyperlink(
    worksheet: Any,
    cell: str,
    url: str,
    text: Optional[str] = None,
    tooltip: Optional[str] = None
) -> None:
    """
    Add a hyperlink to a cell in the worksheet.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the hyperlink will be added.
    cell : str
        Cell reference (e.g., 'A1', 'B10').
    url : str
        URL, email address, or cell reference to link to.
        - Web URL: 'https://example.com'
        - Email: 'mailto:info@example.com'
        - Internal cell: 'Sheet2!A1'
        - File: 'file:///path/to/file.xlsx'
    text : str, optional
        Display text for the hyperlink. If None, uses the URL.
    tooltip : str, optional
        Tooltip text shown when hovering over the link.
    
    Example:
    --------
    >>> from excelstyler.links import add_hyperlink
    >>> # Web link
    >>> add_hyperlink(worksheet, 'A1', 'https://example.com', text='وب‌سایت')
    >>> # Email link
    >>> add_hyperlink(worksheet, 'B1', 'mailto:info@example.com', text='ایمیل')
    >>> # Internal link to another sheet
    >>> add_hyperlink(worksheet, 'C1', 'Sheet2!A1', text='برو به Sheet2')
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    if not url:
        raise ValueError("URL cannot be empty")
    
    # Set display text
    display_text = text if text is not None else url
    
    # Create hyperlink
    cell_obj = worksheet[cell]
    cell_obj.hyperlink = Hyperlink(ref=cell, target=url, tooltip=tooltip)
    cell_obj.value = display_text
    
    # Style hyperlink (blue and underlined)
    from openpyxl.styles import Font
    cell_obj.font = Font(color="0563C1", underline="single")


def add_email_link(
    worksheet: Any,
    cell: str,
    email: str,
    subject: Optional[str] = None,
    body: Optional[str] = None,
    text: Optional[str] = None
) -> None:
    """
    Add an email hyperlink to a cell.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the email link will be added.
    cell : str
        Cell reference (e.g., 'A1').
    email : str
        Email address.
    subject : str, optional
        Email subject line.
    body : str, optional
        Email body text.
    text : str, optional
        Display text. If None, uses the email address.
    
    Example:
    --------
    >>> add_email_link(worksheet, 'A1', 'info@example.com', 
    ...                subject='سوال', text='تماس با ما')
    """
    # Build mailto URL
    mailto_url = f"mailto:{email}"
    
    if subject or body:
        params = []
        if subject:
            params.append(f"subject={subject}")
        if body:
            params.append(f"body={body}")
        if params:
            mailto_url += "?" + "&".join(params)
    
    add_hyperlink(worksheet, cell, mailto_url, text=text or email)


def add_internal_link(
    worksheet: Any,
    cell: str,
    target_sheet: str,
    target_cell: str = "A1",
    text: Optional[str] = None
) -> None:
    """
    Add an internal hyperlink to another sheet in the same workbook.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the link will be added.
    cell : str
        Cell reference where the link will be placed.
    target_sheet : str
        Name of the target sheet.
    target_cell : str, optional
        Target cell reference (default: 'A1').
    text : str, optional
        Display text. If None, uses the target reference.
    
    Example:
    --------
    >>> add_internal_link(worksheet, 'A1', 'Sheet2', 'A1', text='برو به Sheet2')
    """
    target_ref = f"{target_sheet}!{target_cell}"
    display_text = text if text is not None else target_ref
    add_hyperlink(worksheet, cell, target_ref, text=display_text)

