"""
Number format utilities for excelstyler.

This module provides functions to format numbers, currency, percentages, and dates.
"""

from typing import Any, Optional, Union
from datetime import datetime, date
from .utils import shamsi_date


def format_currency(
    worksheet: Any,
    cell: str,
    value: Union[int, float],
    currency: str = "تومان",
    persian_format: bool = True
) -> None:
    """
    Format a cell as currency with Persian/Farsi support.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the formatted value will be added.
    cell : str
        Cell reference (e.g., 'A1').
    value : int or float
        Numeric value to format.
    currency : str, optional
        Currency symbol or text (default: "تومان").
    persian_format : bool, optional
        If True, uses Persian number format with period separator (default: True).
        If False, uses English format with comma separator.
    
    Example:
    --------
    >>> format_currency(worksheet, 'A1', 1000000)
    # Displays: 1.000.000 تومان (or 1,000,000 تومان if persian_format=False)
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    
    from .to_locale_string import to_locale_str
    
    # Format number with locale
    formatted_number = to_locale_str(value, persian=persian_format)
    
    # Set value with currency
    worksheet[cell] = f"{formatted_number} {currency}"
    
    # Apply number format for Excel
    if persian_format:
        worksheet[cell].number_format = '#,##0'
    else:
        worksheet[cell].number_format = '#,##0'


def format_percentage(
    worksheet: Any,
    cell: str,
    value: Union[int, float],
    decimals: int = 2
) -> None:
    """
    Format a cell as percentage.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the formatted value will be added.
    cell : str
        Cell reference (e.g., 'A1').
    value : int or float
        Numeric value (will be multiplied by 100 for display).
    decimals : int, optional
        Number of decimal places (default: 2).
    
    Example:
    --------
    >>> format_percentage(worksheet, 'A1', 0.15)
    # Displays: 15.00%
    >>> format_percentage(worksheet, 'B1', 0.25, decimals=1)
    # Displays: 25.0%
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    
    # Set value (Excel will format it as percentage)
    worksheet[cell] = value
    
    # Apply percentage format
    format_str = f"0.{'0' * decimals}%"
    worksheet[cell].number_format = format_str


def format_date(
    worksheet: Any,
    cell: str,
    date_value: Union[datetime, date],
    format_type: str = "persian",
    date_format: Optional[str] = None
) -> None:
    """
    Format a cell as date (Persian or Gregorian).
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the formatted date will be added.
    cell : str
        Cell reference (e.g., 'A1').
    date_value : datetime or date
        Date value to format.
    format_type : str, optional
        'persian' for Shamsi date, 'gregorian' for Gregorian date (default: 'persian').
    date_format : str, optional
        Custom Excel date format string (e.g., 'yyyy-mm-dd', 'dd/mm/yyyy').
        If None, uses default format based on format_type.
    
    Example:
    --------
    >>> from datetime import datetime
    >>> format_date(worksheet, 'A1', datetime.now(), format_type='persian')
    >>> format_date(worksheet, 'B1', datetime.now(), format_type='gregorian', 
    ...             date_format='dd/mm/yyyy')
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    
    if format_type.lower() == "persian":
        # Convert to Persian date
        persian_date = shamsi_date(date_value, in_value=True)
        worksheet[cell] = persian_date
        # Apply Persian date format
        if date_format is None:
            worksheet[cell].number_format = 'yyyy/mm/dd'
        else:
            worksheet[cell].number_format = date_format
    else:
        # Use Gregorian date
        worksheet[cell] = date_value
        if date_format is None:
            worksheet[cell].number_format = 'yyyy-mm-dd'
        else:
            worksheet[cell].number_format = date_format


def format_number(
    worksheet: Any,
    cell: str,
    value: Union[int, float],
    decimals: int = 0,
    thousands_separator: bool = True,
    persian_format: bool = False
) -> None:
    """
    Format a cell as number with custom formatting.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the formatted number will be added.
    cell : str
        Cell reference (e.g., 'A1').
    value : int or float
        Numeric value to format.
    decimals : int, optional
        Number of decimal places (default: 0).
    thousands_separator : bool, optional
        Whether to use thousands separator (default: True).
    persian_format : bool, optional
        If True, uses period as separator (Persian style).
        If False, uses comma as separator (English style).
    
    Example:
    --------
    >>> format_number(worksheet, 'A1', 1234567.89, decimals=2)
    # Displays: 1,234,567.89
    >>> format_number(worksheet, 'B1', 1234567, persian_format=True)
    # Displays: 1.234.567
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    
    worksheet[cell] = value
    
    # Build format string
    if thousands_separator:
        if persian_format:
            # Persian format uses period for thousands
            format_str = f"#,##0.{'0' * decimals}" if decimals > 0 else "#,##0"
        else:
            # English format uses comma for thousands
            format_str = f"#,##0.{'0' * decimals}" if decimals > 0 else "#,##0"
    else:
        format_str = f"0.{'0' * decimals}" if decimals > 0 else "0"
    
    worksheet[cell].number_format = format_str


def format_phone(
    worksheet: Any,
    cell: str,
    phone_number: str
) -> None:
    """
    Format a cell as phone number (for display purposes).
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the phone number will be added.
    cell : str
        Cell reference (e.g., 'A1').
    phone_number : str
        Phone number string.
    
    Example:
    --------
    >>> format_phone(worksheet, 'A1', '09123456789')
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    
    worksheet[cell] = phone_number
    # Format as text to preserve leading zeros
    worksheet[cell].number_format = '@'


def format_national_id(
    worksheet: Any,
    cell: str,
    national_id: str
) -> None:
    """
    Format a cell as national ID (for Iranian national IDs).
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the national ID will be added.
    cell : str
        Cell reference (e.g., 'A1').
    national_id : str
        National ID string.
    
    Example:
    --------
    >>> format_national_id(worksheet, 'A1', '1234567890')
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    
    worksheet[cell] = national_id
    # Format as text to preserve leading zeros
    worksheet[cell].number_format = '@'

