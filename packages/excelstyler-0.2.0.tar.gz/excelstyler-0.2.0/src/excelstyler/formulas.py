"""
Excel formula utilities for excelstyler.

This module provides functions to easily add Excel formulas to worksheets.
"""

from typing import Any, Optional, Union
from openpyxl.utils import get_column_letter


def SUM(range_ref: str) -> str:
    """
    Create a SUM formula for the given range.
    
    Parameters:
    -----------
    range_ref : str
        Cell range reference (e.g., 'A1:A10' or 'B2:B100').
    
    Returns:
    --------
    str
        Excel SUM formula string.
    
    Example:
    --------
    >>> SUM('A1:A10')
    '=SUM(A1:A10)'
    """
    return f"=SUM({range_ref})"


def AVERAGE(range_ref: str) -> str:
    """
    Create an AVERAGE formula for the given range.
    
    Parameters:
    -----------
    range_ref : str
        Cell range reference (e.g., 'A1:A10').
    
    Returns:
    --------
    str
        Excel AVERAGE formula string.
    
    Example:
    --------
    >>> AVERAGE('B1:B10')
    '=AVERAGE(B1:B10)'
    """
    return f"=AVERAGE({range_ref})"


def COUNT(range_ref: str) -> str:
    """
    Create a COUNT formula for the given range.
    
    Parameters:
    -----------
    range_ref : str
        Cell range reference (e.g., 'A1:A10').
    
    Returns:
    --------
    str
        Excel COUNT formula string.
    
    Example:
    --------
    >>> COUNT('C1:C10')
    '=COUNT(C1:C10)'
    """
    return f"=COUNT({range_ref})"


def MAX(range_ref: str) -> str:
    """
    Create a MAX formula for the given range.
    
    Parameters:
    -----------
    range_ref : str
        Cell range reference.
    
    Returns:
    --------
    str
        Excel MAX formula string.
    """
    return f"=MAX({range_ref})"


def MIN(range_ref: str) -> str:
    """
    Create a MIN formula for the given range.
    
    Parameters:
    -----------
    range_ref : str
        Cell range reference.
    
    Returns:
    --------
    str
        Excel MIN formula string.
    """
    return f"=MIN({range_ref})"


def IF(condition: str, true_value: Union[str, int, float], false_value: Union[str, int, float]) -> str:
    """
    Create an IF formula.
    
    Parameters:
    -----------
    condition : str
        Condition to evaluate (e.g., 'A1>100' or 'B2="Active"').
    true_value : str, int, float
        Value if condition is true.
    false_value : str, int, float
        Value if condition is false.
    
    Returns:
    --------
    str
        Excel IF formula string.
    
    Example:
    --------
    >>> IF('A1>100', 'High', 'Low')
    '=IF(A1>100,"High","Low")'
    """
    # Format string values with quotes
    if isinstance(true_value, str) and not true_value.startswith('='):
        true_value = f'"{true_value}"'
    if isinstance(false_value, str) and not false_value.startswith('='):
        false_value = f'"{false_value}"'
    
    return f"=IF({condition},{true_value},{false_value})"


def VLOOKUP(lookup_value: Union[str, int], table_array: str, col_index: int, range_lookup: bool = False) -> str:
    """
    Create a VLOOKUP formula.
    
    Parameters:
    -----------
    lookup_value : str or int
        Value to search for.
    table_array : str
        Table range (e.g., 'A1:B10').
    col_index : int
        Column index in the table (1-based).
    range_lookup : bool, optional
        Whether to use approximate match. Default is False (exact match).
    
    Returns:
    --------
    str
        Excel VLOOKUP formula string.
    
    Example:
    --------
    >>> VLOOKUP('A1', 'D1:E10', 2)
    '=VLOOKUP(A1,D1:E10,2,FALSE)'
    """
    lookup_str = f'"{lookup_value}"' if isinstance(lookup_value, str) else str(lookup_value)
    return f"=VLOOKUP({lookup_str},{table_array},{col_index},{'TRUE' if range_lookup else 'FALSE'})"


def add_formula(
    worksheet: Any,
    cell: str,
    formula: str,
    style: Optional[Any] = None,
    format_number: Optional[str] = None
) -> None:
    """
    Add a formula to a cell in the worksheet.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the formula will be added.
    cell : str
        Cell reference (e.g., 'A1', 'B10').
    formula : str
        Excel formula string (can use helper functions like SUM, AVERAGE, etc.).
    style : Any, optional
        Optional cell style to apply.
    format_number : str, optional
        Number format string (e.g., '#,##0', '0.00%').
    
    Example:
    --------
    >>> from excelstyler.formulas import add_formula, SUM
    >>> add_formula(worksheet, 'B10', SUM('B2:B9'))
    >>> add_formula(worksheet, 'C10', AVERAGE('C2:C9'), format_number='#,##0.00')
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    if not cell or not isinstance(cell, str):
        raise ValueError("Cell must be a non-empty string")
    if not formula:
        raise ValueError("Formula cannot be empty")
    
    # Ensure formula starts with =
    if not formula.startswith('='):
        formula = f'={formula}'
    
    worksheet[cell] = formula
    
    # Apply number format if provided
    if format_number:
        worksheet[cell].number_format = format_number
    
    # Apply style if provided
    if style:
        if hasattr(style, 'fill'):
            worksheet[cell].fill = style.fill
        if hasattr(style, 'font'):
            worksheet[cell].font = style.font


def add_summary_row(
    worksheet: Any,
    row: int,
    start_col: int,
    end_col: int,
    label: str = "مجموع",
    formula_type: str = "SUM",
    label_col: Optional[int] = None
) -> None:
    """
    Add a summary row with formulas (SUM, AVERAGE, etc.) for a range of columns.
    
    Parameters:
    -----------
    worksheet : openpyxl.Worksheet
        The worksheet where the summary will be added.
    row : int
        Row number for the summary row.
    start_col : int
        Starting column index (1-based).
    end_col : int
        Ending column index (1-based).
    label : str, optional
        Label text for the summary row (default: "مجموع").
    formula_type : str, optional
        Type of formula: 'SUM', 'AVERAGE', 'COUNT', 'MAX', 'MIN' (default: 'SUM').
    label_col : int, optional
        Column for the label. If None, uses start_col - 1.
    
    Example:
    --------
    >>> add_summary_row(worksheet, 10, 2, 5, label='مجموع', formula_type='SUM')
    # Adds SUM formulas in columns B, C, D, E for rows 2-9
    """
    if worksheet is None:
        raise ValueError("Worksheet cannot be None")
    
    # Determine data range (assumes data starts from row 2, ends at row-1)
    data_start_row = 2
    data_end_row = row - 1
    
    # Set label column
    if label_col is None:
        label_col = max(1, start_col - 1)
    
    # Add label
    if label:
        worksheet.cell(row=row, column=label_col, value=label)
    
    # Add formulas for each column
    formula_map = {
        'SUM': SUM,
        'AVERAGE': AVERAGE,
        'COUNT': COUNT,
        'MAX': MAX,
        'MIN': MIN
    }
    
    if formula_type.upper() not in formula_map:
        raise ValueError(f"formula_type must be one of: {list(formula_map.keys())}")
    
    formula_func = formula_map[formula_type.upper()]
    
    for col in range(start_col, end_col + 1):
        col_letter = get_column_letter(col)
        range_ref = f"{col_letter}{data_start_row}:{col_letter}{data_end_row}"
        formula = formula_func(range_ref)
        cell_ref = f"{col_letter}{row}"
        worksheet[cell_ref] = formula

