# Changelog

All notable changes to this project will be documented in this file.

## [0.2.0] - 2025-01-27

### Added
- **Excel Formulas Module** (`formulas.py`):
  - `SUM()`, `AVERAGE()`, `COUNT()`, `MAX()`, `MIN()` - Common aggregation functions
  - `IF()` - Conditional formulas
  - `VLOOKUP()` - Lookup formulas
  - `add_formula()` - Add formulas to cells with optional formatting
  - `add_summary_row()` - Automatically create summary rows with formulas

- **Hyperlinks Module** (`links.py`):
  - `add_hyperlink()` - Add web links, email links, or internal sheet links
  - `add_email_link()` - Add email links with subject and body support
  - `add_internal_link()` - Add links to other sheets in the same workbook

- **Number Formats Module** (`formats.py`):
  - `format_currency()` - Format cells as currency with Persian/Farsi support
  - `format_percentage()` - Format cells as percentage
  - `format_date()` - Format cells as date (Persian or Gregorian)
  - `format_number()` - Custom number formatting with thousands separators
  - `format_phone()` - Format phone numbers (preserves leading zeros)
  - `format_national_id()` - Format Iranian national IDs

- **Enhanced Chart Support**:
  - Added `pie` chart type
  - Added `scatter` chart type
  - Improved chart customization options

- **Enhanced Utilities**:
  - `to_locale_str()` now supports Persian format (period separator)
  - Better type hints throughout the codebase

- **Comprehensive Test Suite**:
  - Added `test_formulas.py` with 15 test cases
  - Added `test_links.py` with 10 test cases
  - Added `test_formats.py` with 12 test cases

### Improved
- Updated README with comprehensive examples for all new features
- Enhanced API documentation with detailed parameter descriptions
- Better code organization and modularity
- Improved error handling and validation
- Enhanced color dictionary with cream color variants

### Fixed
- Fixed `freeze_panes` and `auto_filter` being set inside loop in `create_header_freez()`
- Fixed row height calculation in `create_value()`
- Fixed conditional logic in `excel_description()`
- Improved color dictionary consistency

## [0.1.3] - 2025-01-27

### Added
- Added PyPI badges to README (version, downloads, Python version, license)
- Added comprehensive SEO keywords (persian, farsi, shamsi, iranian)
- Added detailed classifiers for better PyPI categorization
- Added robots.txt for search engine optimization
- Added SEO strategy documentation
- Enhanced README with better description for Iranian developers

### Improved
- Better discoverability in search engines
- Enhanced PyPI package metadata
- Improved SEO optimization
- Better categorization on PyPI

## [0.1.2] - 2025-01-27

### Fixed
- Fixed license inconsistency (changed from AGPL to MIT)
- Fixed missing imports in modules (Font, Border, Side)
- Fixed code quality issues in values.py and helpers.py
- Fixed font assignment bug in helpers.py

### Added
- Comprehensive error handling and validation
- Complete test suite with pytest
- Improved documentation and API reference
- Input validation for all main functions
- Better error messages with specific exceptions

### Improved
- Enhanced README with better examples and documentation
- Added pytest configuration
- Improved code structure and readability
- Better type hints and documentation

## [0.1.1] - 2025-01-26

### Added
- Initial release
- Basic Excel styling functionality
- Persian date support
- Header and value creation functions
- Chart creation capabilities
