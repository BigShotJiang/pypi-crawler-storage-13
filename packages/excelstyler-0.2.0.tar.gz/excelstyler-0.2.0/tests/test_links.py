import pytest
from openpyxl import Workbook
from excelstyler.links import (
    add_hyperlink, add_email_link, add_internal_link
)


class TestLinks:
    """Test cases for hyperlink functions."""
    
    def setup_method(self):
        """Set up test workbook and worksheet."""
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
    
    def test_add_hyperlink_web(self):
        """Test adding web hyperlink."""
        add_hyperlink(self.worksheet, 'A1', 'https://example.com', text='وب‌سایت')
        assert self.worksheet['A1'].hyperlink is not None
        assert self.worksheet['A1'].hyperlink.target == 'https://example.com'
        assert self.worksheet['A1'].value == 'وب‌سایت'
    
    def test_add_hyperlink_email(self):
        """Test adding email hyperlink."""
        add_hyperlink(self.worksheet, 'B1', 'mailto:info@example.com', text='ایمیل')
        assert self.worksheet['B1'].hyperlink is not None
        assert self.worksheet['B1'].hyperlink.target == 'mailto:info@example.com'
    
    def test_add_hyperlink_internal(self):
        """Test adding internal hyperlink."""
        add_hyperlink(self.worksheet, 'C1', 'Sheet2!A1', text='برو به Sheet2')
        assert self.worksheet['C1'].hyperlink is not None
        assert self.worksheet['C1'].hyperlink.target == 'Sheet2!A1'
    
    def test_add_hyperlink_with_tooltip(self):
        """Test adding hyperlink with tooltip."""
        add_hyperlink(self.worksheet, 'A1', 'https://example.com', 
                     text='لینک', tooltip='این یک لینک است')
        assert self.worksheet['A1'].hyperlink.tooltip == 'این یک لینک است'
    
    def test_add_hyperlink_no_text(self):
        """Test adding hyperlink without text uses URL."""
        add_hyperlink(self.worksheet, 'A1', 'https://example.com')
        assert self.worksheet['A1'].value == 'https://example.com'
    
    def test_add_email_link(self):
        """Test adding email link with subject."""
        add_email_link(self.worksheet, 'A1', 'info@example.com', 
                      subject='سوال', text='تماس')
        assert self.worksheet['A1'].hyperlink is not None
        assert 'mailto:' in self.worksheet['A1'].hyperlink.target
    
    def test_add_internal_link(self):
        """Test adding internal link to another sheet."""
        # Create another sheet
        self.workbook.create_sheet('Sheet2')
        add_internal_link(self.worksheet, 'A1', 'Sheet2', 'A1', text='برو به Sheet2')
        assert self.worksheet['A1'].hyperlink is not None
        assert 'Sheet2' in self.worksheet['A1'].hyperlink.target
    
    def test_add_hyperlink_none_worksheet(self):
        """Test add_hyperlink with None worksheet raises ValueError."""
        with pytest.raises(ValueError, match="Worksheet cannot be None"):
            add_hyperlink(None, 'A1', 'https://example.com')
    
    def test_add_hyperlink_empty_cell(self):
        """Test add_hyperlink with empty cell raises ValueError."""
        with pytest.raises(ValueError, match="Cell must be a non-empty string"):
            add_hyperlink(self.worksheet, '', 'https://example.com')
    
    def test_add_hyperlink_empty_url(self):
        """Test add_hyperlink with empty URL raises ValueError."""
        with pytest.raises(ValueError, match="URL cannot be empty"):
            add_hyperlink(self.worksheet, 'A1', '')

