import pytest
from openpyxl import Workbook
from datetime import datetime
from excelstyler.formats import (
    format_currency, format_percentage, format_date,
    format_number, format_phone, format_national_id
)


class TestFormats:
    """Test cases for format functions."""
    
    def setup_method(self):
        """Set up test workbook and worksheet."""
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
    
    def test_format_currency(self):
        """Test formatting currency."""
        format_currency(self.worksheet, 'A1', 1000000)
        assert '1000000' in str(self.worksheet['A1'].value)
        assert 'تومان' in str(self.worksheet['A1'].value)
    
    def test_format_currency_custom(self):
        """Test formatting currency with custom currency."""
        format_currency(self.worksheet, 'A1', 1000000, currency='ریال')
        assert 'ریال' in str(self.worksheet['A1'].value)
    
    def test_format_percentage(self):
        """Test formatting percentage."""
        format_percentage(self.worksheet, 'A1', 0.15)
        assert self.worksheet['A1'].value == 0.15
        assert '%' in self.worksheet['A1'].number_format
    
    def test_format_percentage_decimals(self):
        """Test formatting percentage with custom decimals."""
        format_percentage(self.worksheet, 'A1', 0.15, decimals=1)
        assert '0.0%' in self.worksheet['A1'].number_format
    
    def test_format_date_persian(self):
        """Test formatting Persian date."""
        test_date = datetime(2023, 3, 21)
        format_date(self.worksheet, 'A1', test_date, format_type='persian')
        assert self.worksheet['A1'].value is not None
    
    def test_format_date_gregorian(self):
        """Test formatting Gregorian date."""
        test_date = datetime(2023, 3, 21)
        format_date(self.worksheet, 'A1', test_date, format_type='gregorian')
        assert self.worksheet['A1'].value == test_date
    
    def test_format_number(self):
        """Test formatting number."""
        format_number(self.worksheet, 'A1', 1234567)
        assert self.worksheet['A1'].value == 1234567
        assert '#' in self.worksheet['A1'].number_format
    
    def test_format_number_with_decimals(self):
        """Test formatting number with decimals."""
        format_number(self.worksheet, 'A1', 1234.56, decimals=2)
        assert self.worksheet['A1'].value == 1234.56
    
    def test_format_phone(self):
        """Test formatting phone number."""
        format_phone(self.worksheet, 'A1', '09123456789')
        assert self.worksheet['A1'].value == '09123456789'
        assert self.worksheet['A1'].number_format == '@'
    
    def test_format_national_id(self):
        """Test formatting national ID."""
        format_national_id(self.worksheet, 'A1', '1234567890')
        assert self.worksheet['A1'].value == '1234567890'
        assert self.worksheet['A1'].number_format == '@'
    
    def test_format_currency_none_worksheet(self):
        """Test format_currency with None worksheet raises ValueError."""
        with pytest.raises(ValueError, match="Worksheet cannot be None"):
            format_currency(None, 'A1', 1000000)
    
    def test_format_percentage_none_worksheet(self):
        """Test format_percentage with None worksheet raises ValueError."""
        with pytest.raises(ValueError, match="Worksheet cannot be None"):
            format_percentage(None, 'A1', 0.15)

