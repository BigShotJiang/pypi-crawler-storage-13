import pytest
from openpyxl import Workbook
from excelstyler.formulas import (
    SUM, AVERAGE, COUNT, MAX, MIN, IF, VLOOKUP,
    add_formula, add_summary_row
)


class TestFormulas:
    """Test cases for formula functions."""
    
    def setup_method(self):
        """Set up test workbook and worksheet."""
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
        
        # Add sample data
        for i in range(1, 10):
            self.worksheet.cell(row=i+1, column=1, value=i * 10)
    
    def test_sum_formula(self):
        """Test SUM formula creation."""
        result = SUM('A2:A10')
        assert result == '=SUM(A2:A10)'
    
    def test_average_formula(self):
        """Test AVERAGE formula creation."""
        result = AVERAGE('A2:A10')
        assert result == '=AVERAGE(A2:A10)'
    
    def test_count_formula(self):
        """Test COUNT formula creation."""
        result = COUNT('A2:A10')
        assert result == '=COUNT(A2:A10)'
    
    def test_max_formula(self):
        """Test MAX formula creation."""
        result = MAX('A2:A10')
        assert result == '=MAX(A2:A10)'
    
    def test_min_formula(self):
        """Test MIN formula creation."""
        result = MIN('A2:A10')
        assert result == '=MIN(A2:A10)'
    
    def test_if_formula(self):
        """Test IF formula creation."""
        result = IF('A1>100', 'High', 'Low')
        assert '=IF' in result
        assert 'A1>100' in result
    
    def test_vlookup_formula(self):
        """Test VLOOKUP formula creation."""
        result = VLOOKUP('A1', 'D1:E10', 2, False)
        assert '=VLOOKUP' in result
        assert 'D1:E10' in result
    
    def test_add_formula(self):
        """Test adding formula to worksheet."""
        add_formula(self.worksheet, 'A11', SUM('A2:A10'))
        assert self.worksheet['A11'].value.startswith('=SUM')
    
    def test_add_formula_with_format(self):
        """Test adding formula with number format."""
        add_formula(self.worksheet, 'A11', SUM('A2:A10'), format_number='#,##0')
        assert self.worksheet['A11'].value.startswith('=SUM')
        assert self.worksheet['A11'].number_format == '#,##0'
    
    def test_add_summary_row(self):
        """Test adding summary row."""
        add_summary_row(self.worksheet, 11, 1, 1, label='مجموع', formula_type='SUM')
        assert self.worksheet['A11'].value.startswith('=SUM')
    
    def test_add_summary_row_average(self):
        """Test adding summary row with AVERAGE."""
        add_summary_row(self.worksheet, 11, 1, 1, formula_type='AVERAGE')
        assert self.worksheet['A11'].value.startswith('=AVERAGE')
    
    def test_add_formula_none_worksheet(self):
        """Test add_formula with None worksheet raises ValueError."""
        with pytest.raises(ValueError, match="Worksheet cannot be None"):
            add_formula(None, 'A1', SUM('A2:A10'))
    
    def test_add_formula_empty_cell(self):
        """Test add_formula with empty cell raises ValueError."""
        with pytest.raises(ValueError, match="Cell must be a non-empty string"):
            add_formula(self.worksheet, '', SUM('A2:A10'))
    
    def test_add_formula_empty_formula(self):
        """Test add_formula with empty formula raises ValueError."""
        with pytest.raises(ValueError, match="Formula cannot be empty"):
            add_formula(self.worksheet, 'A1', '')

