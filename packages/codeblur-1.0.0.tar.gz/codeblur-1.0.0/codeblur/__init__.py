"""
CodeBlur - A powerful GUI tool for obfuscating and deobfuscating code strings
"""

from .codeblur import main

__version__ = "1.0.0"
__author__ = "Your Name"
__all__ = ["main"]
