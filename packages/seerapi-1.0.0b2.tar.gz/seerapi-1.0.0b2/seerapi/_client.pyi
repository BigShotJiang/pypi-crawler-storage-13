from collections.abc import AsyncGenerator
from typing import Literal, overload
from typing_extensions import Self

from hishel.httpx import AsyncCacheClient
from httpx import URL
import seerapi_models as M
from seerapi_models.common import ResourceRef

from seerapi._model_map import T_ModelInstance
from seerapi._models import PagedResponse, PageInfo

class SeerAPI:
    scheme: str
    hostname: str
    version_path: str
    base_url: URL
    _client: AsyncCacheClient

    def __init__(
        self,
        *,
        scheme: str = 'https',
        hostname: str = 'api.seerapi.com',
        version_path: str = 'v1',
    ) -> None: ...
    async def __aenter__(self) -> Self: ...
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None: ...
    async def aclose(self) -> None: ...
    @overload
    async def get(
        self, resource_name: Literal['battle_effect'], id: int
    ) -> M.BattleEffect: ...
    @overload
    async def get(
        self, resource_name: Literal['battle_effect_type'], id: int
    ) -> M.BattleEffectCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_effect'], id: int
    ) -> M.PetEffect: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_effect_group'], id: int
    ) -> M.PetEffectGroup: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_variation'], id: int
    ) -> M.VariationEffect: ...
    @overload
    async def get(
        self, resource_name: Literal['energy_bead'], id: int
    ) -> M.EnergyBead: ...
    @overload
    async def get(self, resource_name: Literal['equip'], id: int) -> M.Equip: ...
    @overload
    async def get(self, resource_name: Literal['suit'], id: int) -> M.Suit: ...
    @overload
    async def get(
        self, resource_name: Literal['equip_type'], id: int
    ) -> M.EquipType: ...
    @overload
    async def get(
        self, resource_name: Literal['equip_effective_occasion'], id: int
    ) -> M.EquipEffectiveOccasion: ...
    @overload
    async def get(self, resource_name: Literal['soulmark'], id: int) -> M.Soulmark: ...
    @overload
    async def get(
        self, resource_name: Literal['soulmark_tag'], id: int
    ) -> M.SoulmarkTagCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['element_type'], id: int
    ) -> M.ElementType: ...
    @overload
    async def get(
        self, resource_name: Literal['element_type_combination'], id: int
    ) -> M.TypeCombination: ...
    @overload
    async def get(self, resource_name: Literal['item'], id: int) -> M.Item: ...
    @overload
    async def get(
        self, resource_name: Literal['item_category'], id: int
    ) -> M.ItemCategory: ...
    @overload
    async def get(self, resource_name: Literal['gem'], id: int) -> M.Gem: ...
    @overload
    async def get(
        self, resource_name: Literal['gem_category'], id: int
    ) -> M.GemCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['gem_generation_category'], id: int
    ) -> M.GemGenCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_activation_item'], id: int
    ) -> M.SkillActivationItem: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_stone'], id: int
    ) -> M.SkillStone: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_stone_category'], id: int
    ) -> M.SkillStoneCategory: ...
    @overload
    async def get(self, resource_name: Literal['mintmark'], id: int) -> M.Mintmark: ...
    @overload
    async def get(
        self, resource_name: Literal['ability_mintmark'], id: int
    ) -> M.AbilityMintmark: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_mintmark'], id: int
    ) -> M.SkillMintmark: ...
    @overload
    async def get(
        self, resource_name: Literal['universal_mintmark'], id: int
    ) -> M.UniversalMintmark: ...
    @overload
    async def get(
        self, resource_name: Literal['mintmark_class'], id: int
    ) -> M.MintmarkClassCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['mintmark_type'], id: int
    ) -> M.MintmarkTypeCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['mintmark_rarity'], id: int
    ) -> M.MintmarkRarityCategory: ...
    @overload
    async def get(self, resource_name: Literal['pet'], id: int) -> M.Pet: ...
    @overload
    async def get(self, resource_name: Literal['pet_class'], id: int) -> M.PetClass: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_gender'], id: int
    ) -> M.PetGenderCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_vipbuff'], id: int
    ) -> M.PetVipBuffCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_mount_type'], id: int
    ) -> M.PetMountTypeCategory: ...
    @overload
    async def get(self, resource_name: Literal['pet_skin'], id: int) -> M.PetSkin: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_skin_category'], id: int
    ) -> M.PetSkinCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_archive_story_entry'], id: int
    ) -> M.PetArchiveStoryEntry: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_archive_story_book'], id: int
    ) -> M.PetArchiveStoryBook: ...
    @overload
    async def get(
        self, resource_name: Literal['pet_encyclopedia_entry'], id: int
    ) -> M.PetEncyclopediaEntry: ...
    @overload
    async def get(self, resource_name: Literal['skill'], id: int) -> M.Skill: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_effect_type'], id: int
    ) -> M.SkillEffectType: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_effect_param'], id: int
    ) -> M.SkillEffectParam: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_hide_effect'], id: int
    ) -> M.SkillHideEffect: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_category'], id: int
    ) -> M.SkillCategory: ...
    @overload
    async def get(
        self, resource_name: Literal['skill_effect_type_tag'], id: int
    ) -> M.SkillEffectTypeTag: ...
    @overload
    async def get(
        self, resource_name: Literal['eid_effect'], id: int
    ) -> M.EidEffect: ...
    @overload
    async def get(
        self, resource_name: type[T_ModelInstance], id: int
    ) -> T_ModelInstance: ...
    @overload
    async def get(
        self, resource_name: ResourceRef[T_ModelInstance]
    ) -> T_ModelInstance: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['battle_effect'], page_info: PageInfo
    ) -> PagedResponse[M.BattleEffect]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['battle_effect_type'], page_info: PageInfo
    ) -> PagedResponse[M.BattleEffectCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_effect'], page_info: PageInfo
    ) -> PagedResponse[M.PetEffect]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_effect_group'], page_info: PageInfo
    ) -> PagedResponse[M.PetEffectGroup]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_variation'], page_info: PageInfo
    ) -> PagedResponse[M.VariationEffect]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['energy_bead'], page_info: PageInfo
    ) -> PagedResponse[M.EnergyBead]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['equip'], page_info: PageInfo
    ) -> PagedResponse[M.Equip]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['suit'], page_info: PageInfo
    ) -> PagedResponse[M.Suit]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['equip_type'], page_info: PageInfo
    ) -> PagedResponse[M.EquipType]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['equip_effective_occasion'], page_info: PageInfo
    ) -> PagedResponse[M.EquipEffectiveOccasion]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['soulmark'], page_info: PageInfo
    ) -> PagedResponse[M.Soulmark]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['soulmark_tag'], page_info: PageInfo
    ) -> PagedResponse[M.SoulmarkTagCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['element_type'], page_info: PageInfo
    ) -> PagedResponse[M.ElementType]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['element_type_combination'], page_info: PageInfo
    ) -> PagedResponse[M.TypeCombination]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['item'], page_info: PageInfo
    ) -> PagedResponse[M.Item]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['item_category'], page_info: PageInfo
    ) -> PagedResponse[M.ItemCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['gem'], page_info: PageInfo
    ) -> PagedResponse[M.Gem]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['gem_category'], page_info: PageInfo
    ) -> PagedResponse[M.GemCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['gem_generation_category'], page_info: PageInfo
    ) -> PagedResponse[M.GemGenCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_activation_item'], page_info: PageInfo
    ) -> PagedResponse[M.SkillActivationItem]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_stone'], page_info: PageInfo
    ) -> PagedResponse[M.SkillStone]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_stone_category'], page_info: PageInfo
    ) -> PagedResponse[M.SkillStoneCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['mintmark'], page_info: PageInfo
    ) -> PagedResponse[M.Mintmark]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['ability_mintmark'], page_info: PageInfo
    ) -> PagedResponse[M.AbilityMintmark]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_mintmark'], page_info: PageInfo
    ) -> PagedResponse[M.SkillMintmark]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['universal_mintmark'], page_info: PageInfo
    ) -> PagedResponse[M.UniversalMintmark]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['mintmark_class'], page_info: PageInfo
    ) -> PagedResponse[M.MintmarkClassCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['mintmark_type'], page_info: PageInfo
    ) -> PagedResponse[M.MintmarkTypeCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['mintmark_rarity'], page_info: PageInfo
    ) -> PagedResponse[M.MintmarkRarityCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet'], page_info: PageInfo
    ) -> PagedResponse[M.Pet]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_class'], page_info: PageInfo
    ) -> PagedResponse[M.PetClass]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_gender'], page_info: PageInfo
    ) -> PagedResponse[M.PetGenderCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_vipbuff'], page_info: PageInfo
    ) -> PagedResponse[M.PetVipBuffCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_mount_type'], page_info: PageInfo
    ) -> PagedResponse[M.PetMountTypeCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_skin'], page_info: PageInfo
    ) -> PagedResponse[M.PetSkin]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_skin_category'], page_info: PageInfo
    ) -> PagedResponse[M.PetSkinCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_archive_story_entry'], page_info: PageInfo
    ) -> PagedResponse[M.PetArchiveStoryEntry]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_archive_story_book'], page_info: PageInfo
    ) -> PagedResponse[M.PetArchiveStoryBook]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['pet_encyclopedia_entry'], page_info: PageInfo
    ) -> PagedResponse[M.PetEncyclopediaEntry]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill'], page_info: PageInfo
    ) -> PagedResponse[M.Skill]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_effect_type'], page_info: PageInfo
    ) -> PagedResponse[M.SkillEffectType]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_effect_param'], page_info: PageInfo
    ) -> PagedResponse[M.SkillEffectParam]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_hide_effect'], page_info: PageInfo
    ) -> PagedResponse[M.SkillHideEffect]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_category'], page_info: PageInfo
    ) -> PagedResponse[M.SkillCategory]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['skill_effect_type_tag'], page_info: PageInfo
    ) -> PagedResponse[M.SkillEffectTypeTag]: ...
    @overload
    async def paginated_list(
        self, resource_name: Literal['eid_effect'], page_info: PageInfo
    ) -> PagedResponse[M.EidEffect]: ...
    @overload
    async def paginated_list(
        self, resource_name: type[T_ModelInstance], page_info: PageInfo
    ) -> PagedResponse[T_ModelInstance]: ...
    @overload
    async def list(
        self, resource_name: Literal['battle_effect']
    ) -> AsyncGenerator[M.BattleEffect, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['battle_effect_type']
    ) -> AsyncGenerator[M.BattleEffectCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_effect']
    ) -> AsyncGenerator[M.PetEffect, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_effect_group']
    ) -> AsyncGenerator[M.PetEffectGroup, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_variation']
    ) -> AsyncGenerator[M.VariationEffect, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['energy_bead']
    ) -> AsyncGenerator[M.EnergyBead, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['equip']
    ) -> AsyncGenerator[M.Equip, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['suit']
    ) -> AsyncGenerator[M.Suit, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['equip_type']
    ) -> AsyncGenerator[M.EquipType, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['equip_effective_occasion']
    ) -> AsyncGenerator[M.EquipEffectiveOccasion, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['soulmark']
    ) -> AsyncGenerator[M.Soulmark, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['soulmark_tag']
    ) -> AsyncGenerator[M.SoulmarkTagCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['element_type']
    ) -> AsyncGenerator[M.ElementType, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['element_type_combination']
    ) -> AsyncGenerator[M.TypeCombination, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['item']
    ) -> AsyncGenerator[M.Item, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['item_category']
    ) -> AsyncGenerator[M.ItemCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['gem']
    ) -> AsyncGenerator[M.Gem, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['gem_category']
    ) -> AsyncGenerator[M.GemCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['gem_generation_category']
    ) -> AsyncGenerator[M.GemGenCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_activation_item']
    ) -> AsyncGenerator[M.SkillActivationItem, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_stone']
    ) -> AsyncGenerator[M.SkillStone, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_stone_category']
    ) -> AsyncGenerator[M.SkillStoneCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['mintmark']
    ) -> AsyncGenerator[M.Mintmark, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['ability_mintmark']
    ) -> AsyncGenerator[M.AbilityMintmark, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_mintmark']
    ) -> AsyncGenerator[M.SkillMintmark, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['universal_mintmark']
    ) -> AsyncGenerator[M.UniversalMintmark, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['mintmark_class']
    ) -> AsyncGenerator[M.MintmarkClassCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['mintmark_type']
    ) -> AsyncGenerator[M.MintmarkTypeCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['mintmark_rarity']
    ) -> AsyncGenerator[M.MintmarkRarityCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet']
    ) -> AsyncGenerator[M.Pet, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_class']
    ) -> AsyncGenerator[M.PetClass, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_gender']
    ) -> AsyncGenerator[M.PetGenderCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_vipbuff']
    ) -> AsyncGenerator[M.PetVipBuffCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_mount_type']
    ) -> AsyncGenerator[M.PetMountTypeCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_skin']
    ) -> AsyncGenerator[M.PetSkin, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_skin_category']
    ) -> AsyncGenerator[M.PetSkinCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_archive_story_entry']
    ) -> AsyncGenerator[M.PetArchiveStoryEntry, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_archive_story_book']
    ) -> AsyncGenerator[M.PetArchiveStoryBook, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['pet_encyclopedia_entry']
    ) -> AsyncGenerator[M.PetEncyclopediaEntry, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill']
    ) -> AsyncGenerator[M.Skill, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_effect_type']
    ) -> AsyncGenerator[M.SkillEffectType, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_effect_param']
    ) -> AsyncGenerator[M.SkillEffectParam, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_hide_effect']
    ) -> AsyncGenerator[M.SkillHideEffect, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_category']
    ) -> AsyncGenerator[M.SkillCategory, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['skill_effect_type_tag']
    ) -> AsyncGenerator[M.SkillEffectTypeTag, None]: ...
    @overload
    async def list(
        self, resource_name: Literal['eid_effect']
    ) -> AsyncGenerator[M.EidEffect, None]: ...
    @overload
    async def list(
        self, resource_name: type[T_ModelInstance]
    ) -> AsyncGenerator[T_ModelInstance, None]: ...
