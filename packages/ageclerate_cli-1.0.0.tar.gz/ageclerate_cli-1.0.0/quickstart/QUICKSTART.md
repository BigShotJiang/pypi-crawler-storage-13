# 🚀 Quick Start - Create Your Multi-Agent Project

Get a production-ready multi-agent project running in **60 seconds**.

## Two Ways to Start

### Option 1: Use This Project as Template

Already have this repository? Great! Just run the DevUI:

```bash
# 1. Install dependencies (if not already done)
pip install -r requirements.txt

# 2. Configure your LLM provider (choose one)
cp .env.example .env
# Edit .env and add your API key

# 3. Launch DevUI
python run_devui.py
```

You'll see:
- 🤖 **5 Agents**: Email, Calendar, Stock, Weather, HR
- 🔧 **20+ Tools**: Automatically discovered
- 🔄 **6 Workflows**: Different orchestration patterns

### Option 2: Create a New Project (Recommended for Learning)

Use our CLI to scaffold a minimal starter project:

```bash
# From this repository directory, run:
./create-agent-project my-awesome-project

# Follow the prompts, then:
cd my-awesome-project
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install agent-framework
cp .env.example .env  # Add your API keys
python run_devui.py
```

Your new project will have:
- ✅ **1 Sample Agent** (Calculator Assistant)
- ✅ **2 Sample Tools** (add, multiply)
- ✅ **1 Sample Workflow** (Simple orchestration)
- ✅ **Complete Framework** (Auto-discovery, DevUI, etc.)

## 🎯 What You Get

The new project includes everything you need:

```
my-awesome-project/
├── agents/
│   └── sample_agent.yaml          # Your first agent (YAML only!)
├── tools/
│   └── sample/
│       └── calculator.py           # Your first tools
├── workflows/
│   └── sample_workflow.py          # Your first workflow
├── run_devui.py                    # Launch command
├── QUICKSTART.md                   # Detailed guide
└── README.md                       # Project overview
```

## ⚡ Try It Out (2 minutes)

After launching DevUI, try these prompts:

1. **Simple Math**
   ```
   What is 25 plus 17?
   ```

2. **Chained Operations**
   ```
   Add 100 and 50, then multiply the result by 2
   ```

3. **Complex Calculation**
   ```
   Calculate 12 times 8, then add 25 to the result
   ```

## 🎓 Learn by Doing

### Add Your First Tool (30 seconds)

Create `tools/greetings/hello.py`:

```python
from typing import Annotated
from tools._decorators import tool

@tool(
    domain="greetings",
    description="Say hello to someone",
    tags=["greeting", "hello"],
)
def say_hello(name: Annotated[str, "Person's name"]) -> str:
    return f"Hello, {name}! Welcome to multi-agent systems! 👋"
```

**That's it!** Restart DevUI and your tool is available.

### Add Your First Agent (60 seconds)

Create `agents/greeter_agent.yaml`:

```yaml
name: "Friendly Greeter"
description: "A friendly assistant that greets people"

tool_domains:
  - greetings

instructions: |
  You are a friendly greeter. Use your tools to greet people warmly
  and make them feel welcome. Be enthusiastic and positive!

model:
  providers:
    - "openrouter"
```

**That's it!** Restart DevUI and your agent is ready.

### Create Your First Workflow (90 seconds)

Create `workflows/greeting_workflow.py`:

```python
from agent_framework import WorkflowBuilder
from agents import greeter_agent, sample_agent

greeting_workflow = (
    WorkflowBuilder(name="Greeting + Math Workflow")
    .set_start_executor(greeter_agent)
    .add_edge(greeter_agent, sample_agent)
    .build()
)
```

Import it in `run_devui.py` and it appears automatically!

## 🔧 Configuration

### Using OpenRouter (Easiest - Recommended)

1. Get API key from [openrouter.ai](https://openrouter.ai)
2. Add to `.env`:
   ```bash
   OPENROUTER_API_KEY=sk-or-v1-...
   OPENROUTER_MODEL=anthropic/claude-3.5-sonnet
   ```

### Using Azure OpenAI

1. Login to Azure: `az login`
2. Add to `.env`:
   ```bash
   AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
   AZURE_OPENAI_DEPLOYMENT=gpt-4o
   ```

### Using OpenAI

1. Get API key from [platform.openai.com](https://platform.openai.com)
2. Add to `.env`:
   ```bash
   OPENAI_API_KEY=sk-...
   OPENAI_MODEL=gpt-4o
   ```

## 📚 Understanding the Architecture

### 🔧 Tools = Decorated Functions

```python
@tool(domain="math", description="Add numbers")
def add(a: int, b: int) -> int:
    return a + b
```

- Drop in `tools/domain_name/`
- Use `@tool` decorator
- **Automatically registered** ✨

### 🤖 Agents = YAML Files

```yaml
name: "My Agent"
tool_domains: ["math"]
instructions: "You are helpful..."
```

- Drop in `agents/`
- Tools **auto-discovered by domain/tags**
- **Automatically created** ✨

### 🔄 Workflows = Orchestration

```python
workflow = (
    WorkflowBuilder(name="My Workflow")
    .set_start_executor(agent1)
    .add_edge(agent1, agent2)
    .build()
)
```

- Chain agents sequentially
- Run agents in parallel
- **Automatically in DevUI** ✨

## 💡 Key Concepts

### 1. Zero Boilerplate

- No manual imports needed
- No registration code
- Just drop files and go!

### 2. Convention Over Configuration

- Tools in `tools/domain/`
- Agents in `agents/`
- Framework handles the rest

### 3. YAML for Agents

- No Python needed for agents
- Change prompts without code
- Easy for non-developers

### 4. Type-Safe Tools

- Use Python type hints
- Annotated for descriptions
- Automatic validation

## 🎯 Common Tasks

### See What's Discovered

```bash
# List all tools
python -c "from tools import ToolRegistry; r = ToolRegistry(); print(f'{len(r._tools)} tools'); [print(f'  {k}') for k in r._tools.keys()]"

# List all agents
python -c "from agents import get_all_agents; print(f'{len(get_all_agents())} agents')"
```

### Test a Tool

```python
from tools.sample.calculator import add_numbers
result = add_numbers(10, 20)
print(result)
```

### Run a Workflow

```python
import asyncio
from workflows.sample_workflow import sample_workflow

async def main():
    result = await sample_workflow.run("What is 5 times 6?")
    print(result.get_outputs())

asyncio.run(main())
```

## 🐛 Troubleshooting

### "Command not found: ./create-agent-project"

```bash
chmod +x create-agent-project
```

### "No tools found for agent"

- Check tool `domain` matches agent's `tool_domains`
- Check tool `tags` match agent's `tool_tags`
- Restart DevUI

### "Azure credentials not found"

- Use OpenRouter instead: `OPENROUTER_API_KEY` in `.env`
- Or run: `az login`

### "Import error"

- Ensure `__init__.py` exists in tool directories
- Check virtual environment is activated

## 📖 Next Steps

1. **Explore Examples**: Check the 5 agents in this repository
2. **Read Documentation**: See `docs/` folder for architecture details
3. **Join Community**: Questions? Open an issue on GitHub
4. **Build Something**: Start with simple tools and grow from there

## 🎨 Example Use Cases

### Personal Assistant

- Email agent + Calendar agent + Weather agent
- "Schedule a meeting for tomorrow, send invites, check weather"

### Business Intelligence

- Stock agent + Financial workflow + Email reporting
- Automated market analysis with email summaries

### HR Automation

- HR agent + Email agent + Calendar agent
- Onboarding workflows, leave management, team coordination

### Development Tools

- Code analysis agent + Testing agent + Documentation agent
- Automated code review and documentation generation

## 💪 Pro Tips

1. **Start Small**: Begin with 1 tool, 1 agent, 1 workflow
2. **Use Mock Tools**: Set `mock=True` to test without APIs
3. **Copy Existing**: Learn by copying and modifying examples
4. **OpenRouter First**: Easiest way to get started (no Azure)
5. **Read the YAML**: Agent YAMLs are self-documenting

## 🚀 Ready to Build?

```bash
# Create your project now!
./create-agent-project my-project-name

# Or explore this repository
python run_devui.py
```

---

**Questions?** Check the `docs/` folder or open an issue!

**Happy Building!** 🎉
