# Quick Start - Project Scaffolding Tool

This directory contains the Quick Start CLI and documentation for creating new multi-agent projects.

## 📁 Contents

- **`create-agent-project`** - CLI tool to scaffold new projects
- **`QUICKSTART.md`** - Complete quick start guide
- **`QUICKSTART_CLI.md`** - CLI tool documentation
- **`CLI_DEMO.md`** - Step-by-step demo walkthrough

## 🚀 Quick Usage

### Create a New Project

```bash
# From the repository root:
./quickstart/create-agent-project my-project-name

# Then follow the setup steps:
cd my-project-name
python -m venv .venv
source .venv/bin/activate
pip install agent-framework
cp .env.example .env  # Add your API key
python run_devui.py
```

### Interactive Mode

```bash
./quickstart/create-agent-project
# Prompts for project name
```

## 📖 Documentation

### For First-Time Users
Start with **[QUICKSTART.md](QUICKSTART.md)** - A complete beginner's guide with:
- Step-by-step setup instructions
- Understanding the architecture
- Adding your first tool/agent/workflow
- Troubleshooting guide

### For CLI Tool Reference
See **[QUICKSTART_CLI.md](QUICKSTART_CLI.md)** for:
- CLI usage and options
- Generated project structure
- Customization patterns
- Advanced usage

### For Walkthrough Demo
See **[CLI_DEMO.md](CLI_DEMO.md)** for:
- Complete 5-minute demo
- Terminal command examples
- Customization examples
- Real usage scenarios

## 🎯 What Gets Created

When you run the CLI, it creates a complete project with:

```
my-project-name/
├── agents/
│   └── sample_agent.yaml          # Calculator agent
├── tools/
│   └── sample/
│       └── calculator.py          # Math tools
├── workflows/
│   └── sample_workflow.py         # Simple workflow
├── utils/                         # Utilities
├── run_devui.py                   # Launch script
├── QUICKSTART.md                  # Guide (copy)
├── README.md                      # Project readme
└── .env.example                   # Config template
```

Plus all necessary framework files for auto-discovery!

## 🎓 Why Use This?

### Instead of Cloning the Whole Repository

**Use this CLI when you want:**
- ✅ A minimal starting point for learning
- ✅ A clean slate for your own project
- ✅ Just the essentials without examples
- ✅ To start fresh with your own agents

**Clone the repository when you want:**
- ✅ 5 production-ready example agents
- ✅ Complete email, calendar, stock, weather, HR agents
- ✅ 6 different workflow patterns
- ✅ 20+ example tools across domains

### Benefits of Using the CLI

1. **Minimal Setup** - Only what you need to start
2. **Clean Slate** - No example clutter
3. **Learning Focused** - Simple examples to understand
4. **Quick Iteration** - Create multiple projects easily
5. **Template Base** - Customize from a working foundation

## 🔧 Requirements

- Python 3.11+
- Virtual environment (recommended)
- API key for: OpenRouter, Azure OpenAI, or OpenAI

## 💡 Pro Tips

1. **Use OpenRouter** - Easiest for quick start (no Azure setup)
2. **Start Small** - Use the generated sample, then expand
3. **Copy Examples** - Look at the main repository for more complex patterns
4. **Read Docs** - The generated QUICKSTART.md has detailed examples

## 🆘 Troubleshooting

### CLI Not Executable

```bash
chmod +x quickstart/create-agent-project
```

### Command Not Found

```bash
# Use full path:
./quickstart/create-agent-project my-project

# Or from quickstart directory:
cd quickstart
./create-agent-project my-project
```

### Generated Project Errors

See the generated project's `QUICKSTART.md` for troubleshooting specific issues.

## 🤝 Contributing

The CLI tool and templates are part of the main repository. To improve:

1. Edit `create-agent-project` for CLI changes
2. Edit template code within the CLI script
3. Update documentation in this folder
4. Test by creating a new project
5. Submit PR to main repository

## 📚 Related Documentation

- **[../README.md](../README.md)** - Main repository README
- **[../docs/](../docs/)** - Architecture and detailed docs
- **[Agent Framework](https://github.com/microsoft/agent-framework)** - Official framework docs

---

**Ready to create your first multi-agent project?** Run the CLI and get started in 60 seconds! 🚀
