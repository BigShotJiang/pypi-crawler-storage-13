# Quick Start CLI Documentation

The `create-agent-project` CLI tool scaffolds a complete multi-agent project in seconds.

## Usage

### Basic Usage

```bash
./create-agent-project my-project-name
```

This creates a new directory `my-project-name/` with everything you need to get started.

### Interactive Mode

```bash
./create-agent-project
# Prompts: "Enter project name (default: my-agent-project):"
```

## What Gets Created

```
my-project-name/
├── agents/
│   ├── __init__.py                # Agent auto-discovery
│   ├── agent_factory.py           # Agent factory class
│   ├── tool_context.py            # Tool context injection
│   └── sample_agent.yaml          # ✨ Your first agent (YAML only!)
├── tools/
│   ├── __init__.py                # Tool registry
│   ├── _decorators.py             # @tool decorator
│   ├── _loader.py                 # Auto-discovery loader
│   ├── _registry.py               # Tool registry system
│   └── sample/
│       ├── __init__.py
│       └── calculator.py          # ✨ Your first tools (add, multiply)
├── workflows/
│   └── sample_workflow.py         # ✨ Your first workflow
├── utils/
│   ├── __init__.py
│   └── startup_logger.py          # Beautiful startup logs
├── demos/                         # Empty (for your demos)
├── docs/                          # Empty (for your docs)
├── .env.example                   # Configuration template
├── QUICKSTART.md                  # Step-by-step guide
├── README.md                      # Project overview
└── run_devui.py                   # ✨ Launch DevUI server
```

## Getting Started After Creation

### Step 1: Navigate to Project

```bash
cd my-project-name
```

### Step 2: Setup Environment

```bash
# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# Install agent framework
pip install agent-framework
```

### Step 3: Configure LLM Provider

Choose one of these options:

#### Option A: OpenRouter (Easiest)

```bash
cp .env.example .env
# Edit .env and add:
OPENROUTER_API_KEY=your_key_here
OPENROUTER_MODEL=anthropic/claude-3.5-sonnet
```

#### Option B: Azure OpenAI

```bash
az login
# Or add to .env:
AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4o
```

#### Option C: OpenAI

```bash
# Add to .env:
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4o
```

### Step 4: Launch DevUI

```bash
python run_devui.py
```

Your browser opens to `http://localhost:8080` with:
- 🤖 1 Agent ready (Calculator Assistant)
- 🔧 2 Tools discovered (add_numbers, multiply_numbers)
- 🔄 1 Workflow configured

## Testing Your Project

### Test the Sample Tool Directly

```bash
python -c "from tools.sample.calculator import add_numbers; print(add_numbers(5, 3))"
# Output: ✨ Calculation Result: 5 + 3 = 8
```

### Test Agent Discovery

```bash
python -c "from agents import get_all_agents; agents = get_all_agents(); print(f'Found {len(agents)} agents'); [print(f'  - {a.name}') for a in agents.values()]"
# Output:
# Found 1 agents
#   - Calculator Assistant
```

### Test Tool Discovery

```bash
python -c "from tools import ToolRegistry; r = ToolRegistry(); print(f'Found {len(r._tools)} tools')"
# Output: Found 2 tools
```

## Adding to Your Project

### Add a New Tool

1. Create `tools/your_domain/your_tool.py`:

```python
from typing import Annotated
from tools._decorators import tool

@tool(
    domain="your_domain",
    description="What your tool does",
    tags=["tag1", "tag2"],
)
def your_function(
    param: Annotated[str, "Parameter description"],
) -> str:
    return f"Result: {param}"
```

2. Create `tools/your_domain/__init__.py`:

```python
"""Your domain tools."""
```

3. Restart DevUI - tool is automatically discovered!

### Add a New Agent

1. Create `agents/your_agent.yaml`:

```yaml
name: "Your Agent Name"
description: "What your agent does"

tool_domains:
  - your_domain

tool_tags:
  - tag1
  - tag2

instructions: |
  You are a helpful assistant that...

  Your capabilities include:
  - Capability 1
  - Capability 2

model:
  providers:
    - "openrouter"
```

2. Restart DevUI - agent is automatically created!

### Create a Workflow

1. Create `workflows/your_workflow.py`:

```python
from agent_framework import WorkflowBuilder
from agents import sample_agent, your_agent

your_workflow = (
    WorkflowBuilder(name="Your Workflow")
    .set_start_executor(sample_agent)
    .add_edge(sample_agent, your_agent)
    .build()
)

__all__ = ["your_workflow"]
```

2. Import in `run_devui.py`:

```python
from workflows.your_workflow import your_workflow

# Add to workflows_available list
workflows_available = [sample_workflow, your_workflow]
```

3. Restart DevUI - workflow appears automatically!

## Common Patterns

### Mock vs Real Tools

```python
@tool(
    domain="api",
    description="Call external API",
    mock=True,  # Set to False when ready for production
)
def call_api(endpoint: str) -> str:
    if mock:
        return "Mock response"
    else:
        # Real API call
        pass
```

### Multi-Domain Agent

```yaml
name: "Multi-Domain Agent"

tool_domains:
  - weather
  - stock
  - email

tool_tags:
  - forecast
  - prices
  - send
```

### Parallel Workflow

```python
from agent_framework import ConcurrentBuilder

parallel_workflow = (
    ConcurrentBuilder()
    .participants([agent1, agent2, agent3])
    .build()
)
```

## Troubleshooting

### "Command not found"

```bash
chmod +x create-agent-project
./create-agent-project my-project
```

### "Directory already exists"

```bash
rm -rf my-project  # Or choose a different name
./create-agent-project my-new-project
```

### "No module named 'agent_framework'"

```bash
# Make sure you're in virtual environment
source .venv/bin/activate
pip install agent-framework
```

### "No tools found"

- Check `__init__.py` exists in tool directory
- Check tool decorator is properly formatted
- Check agent's `tool_domains` matches tool's `domain`
- Restart DevUI to re-discover

### "Azure credentials not found"

- Use OpenRouter instead: Set `OPENROUTER_API_KEY` in `.env`
- Or run `az login` for Azure CLI

## Advanced Usage

### Custom Project Structure

After creation, you can organize your project however you like. The framework only requires:
- `agents/` directory with YAML files
- `tools/` directory with `@tool` decorated functions
- Framework files (copied automatically)

### Extending the Template

You can modify the generated files to suit your needs:
- Change agent instructions in YAML
- Add more tools to the sample domain
- Create additional workflows
- Add your own utility modules

### Using as a Template

```bash
# Create template project
./create-agent-project my-template

# Copy for new projects
cp -r my-template new-project-1
cp -r my-template new-project-2

# Customize each project independently
```

## Tips & Best Practices

1. **Start Simple**: Begin with the sample agent and tools, then expand
2. **Use Mock First**: Set `mock=True` for tools until ready for production
3. **YAML for Agents**: Keep agent configuration in YAML - easier to maintain
4. **Domain Organization**: Group related tools in the same domain
5. **Clear Naming**: Use descriptive names for tools, agents, and workflows
6. **Document Tools**: Write good docstrings - they appear in DevUI
7. **Test Incrementally**: Test each tool/agent before adding more
8. **Read QUICKSTART.md**: The generated guide has more detailed examples

## Next Steps

1. Explore the sample agent and tools
2. Try adding your own tool
3. Create your own agent YAML
4. Build a simple workflow
5. Check out the main repository for more examples
6. Read the architecture docs in `docs/`

---

**Questions?** Open an issue on GitHub or check the documentation!
