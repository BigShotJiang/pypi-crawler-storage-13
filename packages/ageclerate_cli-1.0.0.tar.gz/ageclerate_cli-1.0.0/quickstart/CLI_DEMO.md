# Quick Start CLI Demo

A complete walkthrough showing how to create your first multi-agent project from scratch.

## 🎬 Complete Demo (5 Minutes)

### Step 1: Create Your Project (30 seconds)

```bash
$ ./create-agent-project my-first-agent-project

╔══════════════════════════════════════════════════════════════╗
║   🚀 Multi-Agent Project Quick Start                        ║
║   Create a production-ready agent project in 60 seconds     ║
╚══════════════════════════════════════════════════════════════╝

ℹ️  Creating project: my-first-agent-project
✅ Project structure created
✅ Created sample tool: tools/sample/calculator.py
✅ Created sample agent: agents/sample_agent.yaml
✅ Created sample workflow: workflows/sample_workflow.py
✅ Created .env.example
✅ Created QUICKSTART.md
✅ Created README.md
✅ Created run_devui.py
✅ Framework files copied

╔══════════════════════════════════════════════════════════════╗
║   ✅ SUCCESS! Your multi-agent project is ready!            ║
╚══════════════════════════════════════════════════════════════╝

📁 Project created at: /path/to/my-first-agent-project

🎯 Next Steps:
  1. cd my-first-agent-project
  2. python -m venv .venv
  3. source .venv/bin/activate
  4. pip install agent-framework
  5. cp .env.example .env  # Add your API keys
  6. python run_devui.py
```

### Step 2: Navigate and Setup (2 minutes)

```bash
$ cd my-first-agent-project

$ python -m venv .venv
$ source .venv/bin/activate  # Windows: .venv\Scripts\activate

(.venv) $ pip install agent-framework
Collecting agent-framework...
Successfully installed agent-framework-x.x.x
```

### Step 3: Configure (30 seconds)

```bash
(.venv) $ cp .env.example .env

# Edit .env and add your API key (choose one):
# OPENROUTER_API_KEY=sk-or-v1-...
# AZURE_OPENAI_ENDPOINT=https://...
# OPENAI_API_KEY=sk-...

(.venv) $ echo "OPENROUTER_API_KEY=sk-or-v1-xxx" >> .env
(.venv) $ echo "OPENROUTER_MODEL=anthropic/claude-3.5-sonnet" >> .env
```

### Step 4: Verify Setup (30 seconds)

```bash
# Test the sample tool works
(.venv) $ python -c "from tools.sample.calculator import add_numbers; print(add_numbers(5, 3))"
✨ Calculation Result: 5 + 3 = 8

# Verify agent discovery
(.venv) $ python -c "from agents import get_all_agents; print(f'Found {len(get_all_agents())} agents')"
Found 1 agents

# Check project structure
(.venv) $ tree -L 2 -I '.venv|__pycache__'
.
├── agents
│   ├── __init__.py
│   ├── agent_factory.py
│   ├── tool_context.py
│   └── sample_agent.yaml
├── tools
│   ├── __init__.py
│   ├── _decorators.py
│   ├── _loader.py
│   ├── _registry.py
│   └── sample
├── workflows
│   └── sample_workflow.py
├── QUICKSTART.md
├── README.md
└── run_devui.py
```

### Step 5: Launch DevUI (10 seconds)

```bash
(.venv) $ python run_devui.py

======================================================================
🚀 Multi-Agent DevUI Starting...
======================================================================
✅ Discovered 1 agent(s)
✅ Loaded 1 workflow(s)
   🤖 Calculator Assistant
======================================================================
🌐 Opening DevUI at http://localhost:8080
======================================================================

[Browser opens automatically]
```

### Step 6: Test in DevUI (1 minute)

In the DevUI, try these prompts with the Calculator Assistant:

1. **Simple calculation**:
   ```
   What is 25 plus 17?
   ```
   Response:
   ```
   ✨ Calculation Result: 25 + 17 = 42
   ```

2. **Multiplication**:
   ```
   Calculate 12 times 8
   ```
   Response:
   ```
   ✨ Calculation Result: 12 × 8 = 96
   ```

3. **Complex**:
   ```
   Add 100 and 50, then multiply the result by 2
   ```
   Response:
   ```
   Let me break this down:
   1. First, adding: 100 + 50 = 150
   2. Then multiplying: 150 × 2 = 300
   ```

## 🎨 Customization Demo (5 Minutes)

### Add Your First Tool

```bash
# Create a new tool file
(.venv) $ cat > tools/sample/greeting.py << 'EOF'
from typing import Annotated
from tools._decorators import tool

@tool(
    domain="sample",
    description="Greet someone warmly",
    tags=["greeting", "hello", "welcome"],
)
def greet_user(
    name: Annotated[str, "Person's name"],
    enthusiastic: Annotated[bool, "Use exclamation marks"] = True,
) -> str:
    """Greet a user by name."""
    punctuation = "!" if enthusiastic else "."
    return f"Hello, {name}{punctuation} Welcome to multi-agent systems{punctuation}"
EOF

# Restart DevUI - tool is automatically discovered!
(.venv) $ python run_devui.py
```

**Test it:**
```
Greet Alice enthusiastically
```

Response:
```
Hello, Alice! Welcome to multi-agent systems!
```

### Add Your First Agent

```bash
# Create a new agent YAML
(.venv) $ cat > agents/greeter_agent.yaml << 'EOF'
name: "Friendly Greeter"
description: "A warm and welcoming assistant"

tool_domains:
  - sample

tool_tags:
  - greeting

instructions: |
  You are a friendly greeter bot. Use your greeting tools to welcome
  people warmly. Be enthusiastic and positive! Always make people feel
  valued and welcome.

model:
  providers:
    - "openrouter"
EOF

# Restart DevUI - agent is automatically created!
(.venv) $ python run_devui.py

======================================================================
✅ Discovered 2 agent(s)
   🤖 Calculator Assistant
   🤖 Friendly Greeter
======================================================================
```

### Create Your First Workflow

```bash
# Create a workflow
(.venv) $ cat > workflows/greeting_calc_workflow.py << 'EOF'
from agent_framework import WorkflowBuilder
from agents import greeter_agent, sample_agent

greeting_calc_workflow = (
    WorkflowBuilder(
        name="Greeting + Calculator Workflow",
        description="Greet first, then calculate"
    )
    .set_start_executor(greeter_agent)
    .add_edge(greeter_agent, sample_agent)
    .build()
)

__all__ = ["greeting_calc_workflow"]
EOF

# Add to run_devui.py
(.venv) $ cat >> run_devui.py << 'EOF'

# Import new workflow
try:
    from workflows.greeting_calc_workflow import greeting_calc_workflow
    workflows_available.append(greeting_calc_workflow)
except Exception as e:
    print(f"Could not load greeting workflow: {e}")
EOF

# Restart DevUI - workflow appears!
(.venv) $ python run_devui.py
```

## 📊 Complete Project Structure After Customization

```
my-first-agent-project/
├── agents/
│   ├── sample_agent.yaml          # Original
│   └── greeter_agent.yaml         # Your addition ✨
├── tools/
│   └── sample/
│       ├── calculator.py          # Original
│       └── greeting.py            # Your addition ✨
├── workflows/
│   ├── sample_workflow.py         # Original
│   └── greeting_calc_workflow.py  # Your addition ✨
└── run_devui.py                   # Updated ✨
```

## 💡 What You Learned

### Zero-Code Agent Creation
```yaml
# Just drop a YAML file - no Python needed!
name: "My Agent"
tool_domains: ["domain"]
instructions: "You are..."
```

### Simple Tool Creation
```python
# Just a decorated function!
@tool(domain="domain", description="...")
def my_tool(param: str) -> str:
    return result
```

### Automatic Discovery
- Tools auto-discovered from `tools/` directory
- Agents auto-created from YAML files
- Workflows auto-loaded in DevUI
- No manual registration needed

## 🚀 Next Steps

1. **Explore More**:
   - Check out the parent repository with 5 production agents
   - Read `docs/` for architecture details
   - Try different workflow patterns

2. **Build Real Agents**:
   - Connect to real APIs (weather, stock, email)
   - Create domain-specific tools
   - Build multi-step workflows

3. **Production Ready**:
   - Add error handling
   - Implement logging
   - Write tests
   - Deploy to production

## 📚 Resources

- [QUICKSTART.md](../QUICKSTART.md) - Complete quickstart guide
- [QUICKSTART_CLI.md](QUICKSTART_CLI.md) - CLI documentation
- Parent Repository - 5 production agents to learn from
- [Agent Framework Docs](https://github.com/microsoft/agent-framework) - Official documentation

---

**Ready to build something amazing?** Start experimenting! 🎉
