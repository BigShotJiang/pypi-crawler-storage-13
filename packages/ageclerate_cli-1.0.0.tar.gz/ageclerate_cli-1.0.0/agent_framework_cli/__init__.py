"""Agent Framework CLI - Quick Start Tool for Multi-Agent Projects."""

__version__ = "1.0.0"
__author__ = "Microsoft"
__description__ = "CLI tool to scaffold multi-agent projects using Microsoft's Agent Framework"

from .cli import main

__all__ = ["main"]
