#!/usr/bin/env python3
"""
Multi-Agent Project Quick Start CLI
Create a new multi-agent project in seconds!
"""

import os
import sys
import subprocess
from pathlib import Path
from textwrap import dedent


def print_banner():
    """Print welcome banner."""
    print("""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   🚀 Multi-Agent Project Quick Start                        ║
║   Create a production-ready agent project in 60 seconds     ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    """)


def print_success(message):
    """Print success message."""
    print(f"✅ {message}")


def print_info(message):
    """Print info message."""
    print(f"ℹ️  {message}")


def print_error(message):
    """Print error message."""
    print(f"❌ {message}")


def create_directory_structure(project_path: Path):
    """Create the project directory structure."""
    print_info("Creating project structure...")

    directories = [
        "agents",
        "tools/sample",
        "workflows",
        "utils",
        "demos",
        "docs",
    ]

    for directory in directories:
        (project_path / directory).mkdir(parents=True, exist_ok=True)

    print_success("Project structure created")


def create_sample_tool(project_path: Path):
    """Create a sample tool file."""
    tool_file = project_path / "tools" / "sample" / "calculator.py"

    content = dedent('''
    """Sample calculator tools - demonstrates tool creation."""

    from typing import Annotated
    from tools._decorators import tool


    @tool(
        domain="sample",
        description="Add two numbers together",
        tags=["calculator", "math", "addition"],
        mock=False,
    )
    def add_numbers(
        num1: Annotated[float, "First number"],
        num2: Annotated[float, "Second number"],
    ) -> str:
        """Add two numbers and return the result.

        Args:
            num1: First number to add
            num2: Second number to add

        Returns:
            Formatted string with the result

        Example:
            >>> add_numbers(5, 3)
            "5 + 3 = 8"
        """
        result = num1 + num2
        return f"✨ Calculation Result: {num1} + {num2} = {result}"


    @tool(
        domain="sample",
        description="Multiply two numbers together",
        tags=["calculator", "math", "multiplication"],
        mock=False,
    )
    def multiply_numbers(
        num1: Annotated[float, "First number"],
        num2: Annotated[float, "Second number"],
    ) -> str:
        """Multiply two numbers and return the result.

        Args:
            num1: First number to multiply
            num2: Second number to multiply

        Returns:
            Formatted string with the result

        Example:
            >>> multiply_numbers(5, 3)
            "5 × 3 = 15"
        """
        result = num1 * num2
        return f"✨ Calculation Result: {num1} × {num2} = {result}"
    ''').strip()

    tool_file.write_text(content)
    print_success("Created sample tool: tools/sample/calculator.py")


def create_sample_tool_init(project_path: Path):
    """Create __init__.py for sample tools."""
    init_file = project_path / "tools" / "sample" / "__init__.py"
    init_file.write_text('"""Sample tools for demonstration."""\n')


def create_sample_agent(project_path: Path):
    """Create a sample agent YAML file."""
    agent_file = project_path / "agents" / "sample_agent.yaml"

    content = dedent('''
    # Sample Agent Configuration
    # This agent demonstrates the YAML-based agent creation

    name: "Calculator Assistant"
    description: "A helpful assistant that can perform mathematical calculations"

    # Tool Discovery - automatically finds tools matching these criteria
    tool_domains:
      - sample

    tool_tags:
      - calculator
      - math

    # Agent Instructions (the agent's prompt)
    instructions: |
      You are a helpful calculator assistant. You can help users with mathematical calculations.

      Your capabilities include:
      - Adding numbers together
      - Multiplying numbers
      - Explaining mathematical concepts

      When users ask for calculations:
      1. Use the appropriate tool based on their request
      2. Show your work and explain the result
      3. Be friendly and encouraging

      Always format your responses clearly and help users understand the math.

    # Model Configuration
    # Supports multiple providers with automatic fallback
    model:
      # Provider list (will try in order until one succeeds)
      providers:
        - "openrouter"  # Try OpenRouter first
        - "azure"       # Fall back to Azure if available
        - "openai"      # Fall back to OpenAI if available

      # Azure configuration (used if azure provider succeeds)
      endpoint: "https://your-azure-endpoint.openai.azure.com/"
      deployment: "gpt-4o"
      credential_type: "azure_cli"

      # OpenRouter/OpenAI config loaded from environment:
      # OPENROUTER_API_KEY, OPENROUTER_MODEL, OPENAI_API_KEY
    ''').strip()

    agent_file.write_text(content)
    print_success("Created sample agent: agents/sample_agent.yaml")


def create_sample_workflow(project_path: Path):
    """Create a sample workflow file."""
    workflow_file = project_path / "workflows" / "sample_workflow.py"

    content = dedent('''
    # Copyright (c) Microsoft. All rights reserved.
    """Sample Workflow - Demonstrates workflow creation."""

    from agent_framework import WorkflowBuilder, ChatAgent
    from agent_framework.azure import AzureOpenAIChatClient
    from azure.identity import AzureCliCredential

    # Import the sample agent
    from agents import sample_agent


    # Create a simple sequential workflow
    sample_workflow = (
        WorkflowBuilder(
            name="Sample Calculator Workflow",
            description="Simple workflow demonstrating agent orchestration"
        )
        .set_start_executor(sample_agent)
        .build()
    )


    # Example: Creating a multi-step workflow
    # Uncomment to create a workflow with multiple agents

    # analyzer_agent = ChatAgent(
    #     name="Number Analyzer",
    #     description="Analyzes calculation results",
    #     instructions="You analyze mathematical results and provide insights.",
    #     chat_client=AzureOpenAIChatClient(
    #         endpoint="https://your-endpoint.openai.azure.com/",
    #         deployment_name="gpt-4o",
    #         credential=AzureCliCredential(),
    #     ),
    # )
    #
    # multi_step_workflow = (
    #     WorkflowBuilder(
    #         name="Multi-Step Workflow",
    #         description="Calculator → Analyzer (Sequential)"
    #     )
    #     .set_start_executor(sample_agent)
    #     .add_edge(sample_agent, analyzer_agent)
    #     .build()
    # )


    # Export for DevUI
    __all__ = ["sample_workflow"]


    # Usage example
    async def example_run():
        """Example of running the workflow."""
        result = await sample_workflow.run("What is 42 plus 58?")
        outputs = result.get_outputs()
        print("Workflow result:", outputs)
        return result


    if __name__ == "__main__":
        import asyncio
        print("Sample Workflow Example")
        print("=" * 50)
        print("To run: python -c 'import asyncio; from workflows.sample_workflow import example_run; asyncio.run(example_run())'")
    ''').strip()

    workflow_file.write_text(content)
    print_success("Created sample workflow: workflows/sample_workflow.py")


def create_env_example(project_path: Path):
    """Create .env.example file."""
    env_file = project_path / ".env.example"

    content = dedent('''
    # Azure OpenAI Configuration (Option 1)
    # AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
    # AZURE_OPENAI_DEPLOYMENT=gpt-4o

    # OpenRouter Configuration (Option 2 - Recommended for Quick Start)
    # OPENROUTER_API_KEY=your_openrouter_api_key
    # OPENROUTER_MODEL=anthropic/claude-3.5-sonnet

    # OpenAI Configuration (Option 3)
    # OPENAI_API_KEY=your_openai_api_key
    # OPENAI_MODEL=gpt-4o

    # Gmail API Configuration (if using email tools)
    # GMAIL_CREDENTIALS_PATH=path/to/credentials.json
    # GMAIL_TOKEN_PATH=path/to/token.json
    ''').strip()

    env_file.write_text(content)
    print_success("Created .env.example")


def create_quickstart_md(project_path: Path):
    """Create QUICKSTART.md guide."""
    quickstart_file = project_path / "QUICKSTART.md"

    content = dedent('''
    # 🚀 Quick Start Guide

    Welcome to your new multi-agent project! This guide will get you up and running in minutes.

    ## 📋 What You Got

    Your project includes:
    - ✅ **Sample Agent** (`agents/sample_agent.yaml`) - Calculator assistant
    - ✅ **Sample Tools** (`tools/sample/calculator.py`) - Math operations
    - ✅ **Sample Workflow** (`workflows/sample_workflow.py`) - Simple orchestration
    - ✅ **Framework** - Complete agent framework with auto-discovery

    ## ⚡ Quick Start (60 seconds)

    ### Step 1: Install Dependencies

    ```bash
    # Create virtual environment
    python -m venv .venv
    source .venv/bin/activate  # On Windows: .venv\\Scripts\\activate

    # Install agent framework
    pip install agent-framework

    # Or if using local development
    pip install -e /path/to/agent-framework
    ```

    ### Step 2: Configure Environment (Choose One)

    **Option A: OpenRouter (Easiest - No Azure needed)**

    ```bash
    cp .env.example .env
    # Edit .env and add:
    OPENROUTER_API_KEY=your_key_here
    OPENROUTER_MODEL=anthropic/claude-3.5-sonnet
    ```

    **Option B: Azure OpenAI**

    ```bash
    az login  # Login to Azure CLI
    # Or set in .env:
    AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
    AZURE_OPENAI_DEPLOYMENT=gpt-4o
    ```

    ### Step 3: Launch DevUI

    ```bash
    python run_devui.py
    ```

    Your browser will open to `http://localhost:8080` with:
    - 🤖 **1 Agent** ready to use (Calculator Assistant)
    - 🔧 **2 Tools** automatically discovered (add, multiply)
    - 🔄 **1 Workflow** ready to orchestrate

    ### Step 4: Try It Out!

    In the DevUI, try these prompts:
    - "What is 25 plus 17?"
    - "Calculate 12 times 8"
    - "Add 100 and 50, then multiply the result by 2"

    ## 📚 Next Steps

    ### Add Your Own Tool

    Create `tools/your_domain/your_tool.py`:

    ```python
    from typing import Annotated
    from tools._decorators import tool

    @tool(
        domain="your_domain",
        description="Your tool description",
        tags=["tag1", "tag2"],
    )
    def your_function(
        param: Annotated[str, "Parameter description"],
    ) -> str:
        return f"Result: {param}"
    ```

    **That's it!** The tool is automatically discovered. Just restart DevUI.

    ### Add Your Own Agent

    Create `agents/your_agent.yaml`:

    ```yaml
    name: "Your Agent Name"
    description: "What your agent does"

    tool_domains:
      - your_domain

    instructions: |
      You are a helpful assistant that...

    model:
      providers:
        - "openrouter"
    ```

    **That's it!** The agent is automatically created. Just restart DevUI.

    ### Create a Workflow

    Create `workflows/your_workflow.py`:

    ```python
    from agent_framework import WorkflowBuilder
    from agents import your_agent, another_agent

    your_workflow = (
        WorkflowBuilder(name="Your Workflow")
        .set_start_executor(your_agent)
        .add_edge(your_agent, another_agent)
        .build()
    )
    ```

    Import it in `run_devui.py` and it appears in DevUI automatically!

    ## 🎯 Core Concepts

    ### 1. Tools = Functions with @tool Decorator

    - Drop a Python file in `tools/domain_name/`
    - Add `@tool` decorator
    - Automatically registered and discoverable

    ### 2. Agents = YAML Configuration

    - Drop a YAML file in `agents/`
    - Specify tool domains/tags to auto-discover tools
    - Agent automatically created and ready to use

    ### 3. Workflows = Python Orchestration

    - Import agents and use `WorkflowBuilder`
    - Chain agents sequentially or run in parallel
    - Add to DevUI by importing in `run_devui.py`

    ## 🔧 Common Tasks

    ### See All Discovered Tools

    ```bash
    python -c "from tools import ToolRegistry; r = ToolRegistry(); print(f'Found {len(r._tools)} tools'); [print(f'  - {k}') for k in r._tools.keys()]"
    ```

    ### See All Discovered Agents

    ```bash
    python -c "from agents import get_all_agents; agents = get_all_agents(); print(f'Found {len(agents)} agents'); [print(f'  - {k}') for k in agents.keys()]"
    ```

    ### Test a Tool Directly

    ```python
    from tools.sample.calculator import add_numbers
    result = add_numbers(10, 20)
    print(result)  # "✨ Calculation Result: 10 + 20 = 30"
    ```

    ### Run a Workflow Programmatically

    ```python
    import asyncio
    from workflows.sample_workflow import sample_workflow

    async def main():
        result = await sample_workflow.run("What is 5 times 6?")
        print(result.get_outputs())

    asyncio.run(main())
    ```

    ## 📖 Architecture

    ```
    your-project/
    ├── agents/               # Agent YAML configs (auto-discovered)
    │   └── sample_agent.yaml
    ├── tools/                # Tool functions (auto-discovered)
    │   └── sample/
    │       ├── __init__.py
    │       └── calculator.py
    ├── workflows/            # Workflow orchestrations
    │   └── sample_workflow.py
    ├── run_devui.py         # Launch DevUI server
    └── .env                 # Configuration
    ```

    ### How Auto-Discovery Works

    1. **Tool Discovery**: Scans `tools/` for `@tool` decorated functions
    2. **Agent Discovery**: Scans `agents/` for YAML files and creates ChatAgents
    3. **Tool Matching**: Agents get tools based on `tool_domains` and `tool_tags`
    4. **DevUI Registration**: All discovered agents/workflows appear in UI

    ## 🐛 Troubleshooting

    ### "No tools found for agent"

    - Check that tool `domain` matches agent's `tool_domains`
    - Check that tool `tags` match agent's `tool_tags`
    - Restart DevUI to re-discover tools

    ### "Azure credentials not found"

    - Use OpenRouter instead (easier): Set `OPENROUTER_API_KEY` in `.env`
    - Or run `az login` for Azure CLI authentication

    ### "Import error"

    - Make sure `__init__.py` exists in tool directories
    - Check Python path includes project root

    ## 🎓 Learn More

    - **Full Documentation**: See `docs/` folder
    - **More Examples**: Check existing agents in parent project
    - **Framework Docs**: See Agent Framework documentation

    ## 💡 Pro Tips

    1. **Use OpenRouter** for quick start - no Azure setup needed
    2. **Start with YAML** - Agents are just YAML files, super easy!
    3. **Copy existing tools** - Easiest way to learn the pattern
    4. **Use mock=True** - Test tools without external APIs
    5. **Check DevUI logs** - See what's happening under the hood

    ---

    **Ready to build something amazing? Start coding!** 🚀

    Questions? Check the docs or open an issue on GitHub.
    ''').strip()

    quickstart_file.write_text(content)
    print_success("Created QUICKSTART.md")


def create_readme(project_path: Path, project_name: str):
    """Create README.md file."""
    readme_file = project_path / "README.md"

    content = dedent(f'''
    # {project_name}

    A multi-agent AI project built with Microsoft's Agent Framework.

    ## 🚀 Quick Start

    See [QUICKSTART.md](QUICKSTART.md) for detailed setup instructions.

    ### TL;DR

    ```bash
    # 1. Install dependencies
    python -m venv .venv
    source .venv/bin/activate
    pip install agent-framework

    # 2. Configure (choose one)
    cp .env.example .env
    # Add your OPENROUTER_API_KEY or Azure credentials

    # 3. Launch
    python run_devui.py
    ```

    ## 📁 Project Structure

    ```
    {project_name}/
    ├── agents/                 # Agent configurations (YAML)
    │   └── sample_agent.yaml   # Sample calculator agent
    ├── tools/                  # Tool functions
    │   └── sample/
    │       └── calculator.py   # Sample math tools
    ├── workflows/              # Workflow orchestrations
    │   └── sample_workflow.py  # Sample workflow
    ├── run_devui.py           # Launch DevUI server
    └── QUICKSTART.md          # Step-by-step guide
    ```

    ## ✨ Features

    - ✅ **Auto-Discovery**: Drop files, they're automatically registered
    - ✅ **YAML Agents**: Create agents with simple YAML files
    - ✅ **Zero Boilerplate**: Minimal code, maximum productivity
    - ✅ **DevUI Included**: Visual interface for testing
    - ✅ **Multi-Provider**: Azure, OpenAI, OpenRouter support

    ## 📚 Learn More

    - [QUICKSTART.md](QUICKSTART.md) - Complete setup guide
    - [docs/](docs/) - Additional documentation
    - [Agent Framework](https://github.com/microsoft/agent-framework) - Framework docs

    ## 🤝 Contributing

    This project was created with the Multi-Agent Framework Accelerator.

    ---

    Built with ❤️ using Microsoft's Agent Framework
    ''').strip()

    readme_file.write_text(content)
    print_success("Created README.md")


def create_run_devui(project_path: Path):
    """Create run_devui.py launcher."""
    run_file = project_path / "run_devui.py"

    content = dedent('''
    #!/usr/bin/env python3
    """Launch DevUI with automatic agent and workflow discovery."""

    import logging
    import os

    # Suppress verbose discovery logs
    os.environ['PYTHONWARNINGS'] = 'ignore'
    logging.basicConfig(level=logging.WARNING, format="%(message)s")

    from agent_framework.devui import serve
    from agents import get_all_agents

    # Get all auto-discovered agents
    agents = get_all_agents()

    # Try to import workflows (optional)
    workflows_available = []
    try:
        from workflows.sample_workflow import sample_workflow
        workflows_available = [sample_workflow]
    except Exception as e:
        print(f"⚠️  Workflows not available: {e}")
        print("💡 Tip: Configure your LLM provider in .env")

    print("=" * 70)
    print("🚀 Multi-Agent DevUI Starting...")
    print("=" * 70)
    print(f"✅ Discovered {len(agents)} agent(s)")
    print(f"✅ Loaded {len(workflows_available)} workflow(s)")

    for name, agent in agents.items():
        print(f"   🤖 {agent.name}")

    print("=" * 70)
    print("🌐 Opening DevUI at http://localhost:8080")
    print("=" * 70)

    # Build entities list - all agents plus workflows
    entities = list(agents.values()) + workflows_available

    # Launch server
    serve(
        entities=entities,
        port=8080,
        auto_open=True
    )
    ''').strip()

    run_file.write_text(content)
    run_file.chmod(0o755)  # Make executable
    print_success("Created run_devui.py")


def copy_framework_files(project_path: Path, source_path: Path):
    """Copy essential framework files."""
    print_info("Copying framework files...")

    # Copy tool decorators and registry
    import shutil

    # Try to use package resources if installed as package
    try:
        from importlib import resources
        import agent_framework_cli.templates as templates_pkg

        # Using package resources
        files_to_copy = [
            ("tools/_decorators.py", "tools/_decorators.py"),
            ("tools/_loader.py", "tools/_loader.py"),
            ("tools/_registry.py", "tools/_registry.py"),
            ("tools/__init__.py", "tools/__init__.py"),
            ("agents/agent_factory.py", "agents/agent_factory.py"),
            ("agents/tool_context.py", "agents/tool_context.py"),
            ("agents/__init__.py", "agents/__init__.py"),
            ("utils/startup_logger.py", "utils/startup_logger.py"),
            ("utils/__init__.py", "utils/__init__.py"),
        ]

        for source_file, dest_file in files_to_copy:
            # Parse the path
            parts = source_file.split('/')
            module_name = '.'.join(['agent_framework_cli', 'templates'] + parts[:-1])
            file_name = parts[-1]

            try:
                # Read from package resources
                content = resources.files(module_name).joinpath(file_name).read_text()

                # Write to destination
                dst = project_path / dest_file
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_text(content)
                print(f"  ✓ Copied {dest_file}")
            except Exception as e:
                print_error(f"Error copying {source_file}: {e}")

    except (ImportError, ModuleNotFoundError):
        # Fall back to file system copy (for development)
        files_to_copy = [
            ("tools/_decorators.py", "tools/_decorators.py"),
            ("tools/_loader.py", "tools/_loader.py"),
            ("tools/_registry.py", "tools/_registry.py"),
            ("tools/__init__.py", "tools/__init__.py"),
            ("agents/agent_factory.py", "agents/agent_factory.py"),
            ("agents/tool_context.py", "agents/tool_context.py"),
            ("agents/__init__.py", "agents/__init__.py"),
            ("utils/startup_logger.py", "utils/startup_logger.py"),
            ("utils/__init__.py", "utils/__init__.py"),
        ]

        for source_file, dest_file in files_to_copy:
            src = source_path / source_file
            dst = project_path / dest_file

            if src.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                print(f"  ✓ Copied {dest_file}")
            else:
                print_error(f"Source file not found: {source_file}")

    print_success("Framework files copied")


def create_next_steps_message(project_name: str, project_path: Path):
    """Print next steps message."""
    print("\n")
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║                                                              ║")
    print("║   ✅ SUCCESS! Your multi-agent project is ready!            ║")
    print("║                                                              ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print("\n")
    print(f"📁 Project created at: {project_path}")
    print("\n")
    print("🎯 Next Steps:")
    print("\n")
    print(f"  1. cd {project_name}")
    print("  2. python -m venv .venv")
    print("  3. source .venv/bin/activate  # Windows: .venv\\Scripts\\activate")
    print("  4. pip install agent-framework")
    print("  5. cp .env.example .env  # Add your API keys")
    print("  6. python run_devui.py")
    print("\n")
    print("📖 Read QUICKSTART.md for detailed instructions")
    print("\n")
    print("💡 Quick Test:")
    print(f"  cd {project_name}")
    print("  python -c \"from tools.sample.calculator import add_numbers; print(add_numbers(5, 3))\"")
    print("\n")
    print("Happy coding! 🚀")
    print("\n")


def main():
    """Main function."""
    print_banner()

    # Get project name
    if len(sys.argv) > 1:
        project_name = sys.argv[1]
    else:
        project_name = input("📝 Enter project name (default: my-agent-project): ").strip()
        if not project_name:
            project_name = "my-agent-project"

    # Create project path
    project_path = Path.cwd() / project_name

    if project_path.exists():
        print_error(f"Directory '{project_name}' already exists!")
        sys.exit(1)

    print_info(f"Creating project: {project_name}")
    project_path.mkdir(parents=True, exist_ok=True)

    # Get source path (repository root - one level up from this script)
    source_path = Path(__file__).parent.parent.resolve()

    try:
        # Create project structure
        create_directory_structure(project_path)
        create_sample_tool_init(project_path)
        create_sample_tool(project_path)
        create_sample_agent(project_path)
        create_sample_workflow(project_path)
        create_env_example(project_path)
        create_quickstart_md(project_path)
        create_readme(project_path, project_name)
        create_run_devui(project_path)

        # Copy framework files
        copy_framework_files(project_path, source_path)

        # Show next steps
        create_next_steps_message(project_name, project_path)

    except Exception as e:
        print_error(f"Error creating project: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
