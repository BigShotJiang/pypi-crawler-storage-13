import logging
import os
import shutil
import threading
from concurrent.futures.thread import ThreadPoolExecutor

from aiq.churn.dao.db.ChurnTrainStatusDAO import ChurnTrainStatusDAO
from aiq.churn.dao.db.SupportedAlgorithmDao import SupportedAlgorithmDao
from aiq.churn.main.server.DumyTrainer import DumyTrainerApp
from aiq.churn.main.server.dto import PublishModelResult
from aiq.churn.main.server.dto.PublishModelResult import PublishModelResult
from aiq.churn.main.server.dto.StartTrainResult import StartTrainResult
from aiq.churn.utility import round_double
from aiq.churn.utils.JSONUtils import JSONUtils


class ModelAndTrainingService:
    logger = logging.getLogger(__name__)
    config: dict = None
    churn_train_status: ChurnTrainStatusDAO = None
    train_executor: ThreadPoolExecutor = None
    trainer_app: DumyTrainerApp = None
    supported_algorithms_dao: SupportedAlgorithmDao = None

    def __init__(self, config: dict):
        self.config = config
        self.churn_train_status = ChurnTrainStatusDAO(config)
        self.supported_algorithms_dao = SupportedAlgorithmDao(config)
        self.train_executor = ThreadPoolExecutor(max_workers=1)
        self.trainer_app = DumyTrainerApp()
        self.churn_train_status.fail_running_status(error_message="stopped during restart")

    def start_train(self, data: dict) -> StartTrainResult:

        #
        # req data
        #

        service_name: str = JSONUtils.decode_str(data, "service_name", "")
        algorithm: str = JSONUtils.decode_str(data, "algorithm", "")
        overwrite_model: bool = JSONUtils.decode_bool(data, "overwrite_model", False)
        hyper_parameters = JSONUtils.decode_dict(data, "hyper_parameters")

        #validate Algo
        algo = self.supported_algorithms_dao.get_algo_by_id(algorithm)

        result: StartTrainResult = None
        if not algo:
            result = StartTrainResult(response_code=1, response_message="algo not found")
        else:

            # check if a train is running

            if self.churn_train_status.is_any_job_running():
                result = StartTrainResult(response_code=1,response_message="another training is running wait till completion")
            else:
                # insert the job in db
                run_id = self.churn_train_status.create(algorithm, "1", "RUNNING", hyperparams=hyper_parameters)

                # Submit training asynchronously
                train_input = {"algorithm": algo.get('algorithm'), "hyperparams": hyper_parameters, "service_name": service_name, "overwrite_model": overwrite_model}
                future_result = self.train_executor.submit(self.trainer_app.train, train_input)

                # Start monitoring in a separate thread
                monitor_thread = threading.Thread(target=self.monitor_future, args=(future_result, run_id))
                monitor_thread.start()

                # send a success
                response_message = "training started with run_id " + str(run_id)
                result = StartTrainResult(response_code=0, response_message=response_message)
        return result

    def publishModel(self, data: dict) -> PublishModelResult:

        #
        # req data
        #

        run_id: str = JSONUtils.decode_str(data, "run_id", "")

        # check this run was successful
        result: PublishModelResult = None
        trained_state = self.churn_train_status.get_to_publish_by_id(run_id);

        if not trained_state:
            result = PublishModelResult(response_code=1, response_message="this runID is not publishable or already published", service_name="", model_name="", model_version="", model_published=False)

        else:
            model_input = trained_state.get('model_artifact_path');
            model_published = model_input + "/published"
            source_dir = os.path.join(model_input)
            target_dir = os.path.join(model_published)
            if not os.path.exists(source_dir):
                result = PublishModelResult(response_code=1, response_message="invalid model_input dir " + model_input, service_name="", model_name="", model_version="", model_published=False)
                print(f"source_dir {source_dir} does not exist")
            else:
                try:
                    os.makedirs(target_dir, exist_ok=True)
                    shutil.rmtree(target_dir)
                    shutil.copytree(source_dir, target_dir)
                    self.churn_train_status.publish_by_id(run_id)

                    model_name = trained_state.get('algorithm_id');
                    model_version = trained_state.get('model_version');
                    result = PublishModelResult(response_code=0, response_message="success see " + target_dir, service_name="NA", model_name=model_name, model_version=model_version, model_published =True)
                except Exception as e:
                    print(e)
                    result = PublishModelResult(response_code=1, response_message="system error " + e, service_name="", model_name="", model_version="", model_published=False)
        return result



    # Function to monitor the future in a separate thread
    def monitor_future(self, future_result, run_id):
        print(f"Monitoring train in another thread for runID {run_id}")
        result = future_result.result()  # Blocks until training completes
        model_version = result.get("model_version")
        records_trained = result.get("records_trained")

        accuracy = result.get("accuracy")
        precision = result.get("precision")
        recall = result.get("recall")
        f1_score = result.get("f1_score")

        #normalize
        accuracy = round_double(accuracy, 3)
        precision = round_double(precision, 3)
        recall = round_double(recall, 3)
        f1_score = round_double(f1_score, 3)


        model_artifact_path = result.get("model_artifact_path")
        error_message = result.get("error_message")
        self.churn_train_status.complete(run_id, model_version, records_trained, accuracy, precision, recall, f1_score, model_artifact_path, error_message)
        print(f"Train completed with result: {result}, for runID: {run_id}")

    # def load_model_result(self, data: dict) -> LoadModelResult:
    #     service_name = data.get("service_name")
    #     model_name = data.get("model_name")
    #     model_version = data.get("model_version")
    #
    #     model_published = self.config["app_sever"]["model_published_dir"]
    #
    #     model_dir = os.path.join(model_published, service_name, model_name, model_version)
    #     file_name = f"{model_name}.joblib"
    #     model_path = os.path.join(model_dir, file_name)
    #
    #     if not os.path.exists(model_path):
    #         message = f"Model file '{file_name}' not found in published directory: {model_dir}"
    #         self.logger.error(message)
    #         load_model_result: LoadModelResult = LoadModelResult(service_name, model_name, model_version, False)
    #         return load_model_result
    #
    #     try:
    #         registry = ModelRegistry(model_published)
    #         model = registry.load_model(service_name, model_name, model_version)
    #
    #         message = f"Model '{model_name}' (version: {model_version}) loaded successfully for service '{service_name}'."
    #         self.logger.info(message)
    #
    #         load_model_result: LoadModelResult = LoadModelResult(service_name, model_name, model_version, True)
    #         return load_model_result
    #
    #     except Exception as e:
    #         message = f"Error while loading model '{model_name}' (version: {model_version}) — {e}"
    #         self.logger.exception(message)
    #         load_model_result: LoadModelResult = LoadModelResult(service_name, model_name, model_version, False)
    #         return load_model_result