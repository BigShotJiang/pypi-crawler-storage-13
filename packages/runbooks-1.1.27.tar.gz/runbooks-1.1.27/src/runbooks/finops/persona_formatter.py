#!/usr/bin/env python3
"""
PersonaFormatter - Executive Persona Formatting for FinOps Dashboards

Provides persona-specific data filtering and formatting for:
- CFO: Budget-focused with top 5 cost drivers
- CTO: Technical service breakdown with optimization signals
- CEO: Strategic KPIs with top 3 action items
- SRE: Anomaly detection with cost spike alerts
- Architect: Multi-account architecture patterns
- Technical: Full detailed data (default)
- Executive: Board-ready one-page summary

Manager Requirement: Persona-specific output customization for --mode parameter
Enterprise Pattern: KISS architecture (enhance existing, no new complexity)
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional

import pandas as pd

# Persona types matching CLI --mode options
PersonaType = Literal["cfo", "cto", "ceo", "sre", "architect", "technical", "executive"]


@dataclass
class PersonaConfig:
    """Configuration for persona-specific dashboard formatting."""

    persona: PersonaType
    primary_metric: str
    secondary_metrics: List[str]
    top_services: int | str  # int for limit, 'all' for unlimited
    summary_length: str
    focus_areas: List[str]
    exclude_zero_cost: bool = True
    include_recommendations: bool = False
    threshold_alerts: bool = False
    dependency_graph: bool = False
    action_items: Optional[int] = None


class PersonaFormatter:
    """
    Format dashboard data for executive personas.

    Implements persona-specific filtering, prioritization, and formatting
    to deliver role-appropriate insights from FinOps cost data.
    """

    def __init__(self, persona: PersonaType = "technical"):
        """
        Initialize PersonaFormatter.

        Args:
            persona: Target persona type (defaults to 'technical' for backward compatibility)
        """
        self.persona = persona.lower()
        self.config = self._get_persona_config()

    def _get_persona_config(self) -> PersonaConfig:
        """
        Get configuration for current persona.

        Returns:
            PersonaConfig with persona-specific settings
        """
        configs = {
            "cfo": PersonaConfig(
                persona="cfo",
                primary_metric="monthly_budget_utilization_pct",
                secondary_metrics=["forecast_accuracy", "cost_trend_mom"],
                top_services=5,
                summary_length="executive",
                focus_areas=["budget_compliance", "cost_optimization"],
                exclude_zero_cost=True,
                include_recommendations=True,
            ),
            "cto": PersonaConfig(
                persona="cto",
                primary_metric="service_cost_breakdown",
                secondary_metrics=["technical_debt_cost", "architecture_optimization"],
                top_services=15,
                summary_length="technical",
                focus_areas=["E1-E7_signals", "rightsizing_opportunities"],
                exclude_zero_cost=True,
                include_recommendations=True,
            ),
            "ceo": PersonaConfig(
                persona="ceo",
                primary_metric="total_cost_trend",
                secondary_metrics=["yoy_growth", "cloud_spend_as_pct_revenue"],
                top_services=3,
                summary_length="board_ready",
                focus_areas=["strategic_initiatives", "cost_trajectory"],
                exclude_zero_cost=True,
                action_items=3,
            ),
            "sre": PersonaConfig(
                persona="sre",
                primary_metric="cost_anomaly_score",
                secondary_metrics=["spike_alerts", "resource_utilization"],
                top_services=20,
                summary_length="operational",
                focus_areas=["cost_spikes", "resource_waste"],
                exclude_zero_cost=False,
                threshold_alerts=True,
            ),
            "architect": PersonaConfig(
                persona="architect",
                primary_metric="multi_account_cost_distribution",
                secondary_metrics=["architecture_patterns", "cross_account_dependencies"],
                top_services="all",
                summary_length="architectural",
                focus_areas=["workload_patterns", "optimization_architecture"],
                exclude_zero_cost=True,
                dependency_graph=True,
            ),
            "technical": PersonaConfig(
                persona="technical",
                primary_metric="all_metrics",
                secondary_metrics=[],
                top_services="all",
                summary_length="detailed",
                focus_areas=["all_signals", "full_analysis"],
                exclude_zero_cost=False,
            ),
            "executive": PersonaConfig(
                persona="executive",
                primary_metric="total_cost_summary",
                secondary_metrics=["key_trends", "top_recommendations"],
                top_services=5,
                summary_length="board_ready",
                focus_areas=["executive_summary", "decision_points"],
                exclude_zero_cost=True,
                include_recommendations=True,
                action_items=5,
            ),
        }
        return configs.get(self.persona, configs["technical"])

    def filter_top_services(
        self, service_data: pd.DataFrame, cost_column: str = "current_cost"
    ) -> pd.DataFrame:
        """
        Filter services based on persona preferences.

        Args:
            service_data: DataFrame with service cost information
            cost_column: Column name containing cost values

        Returns:
            Filtered DataFrame with top N services per persona config
        """
        if self.config.top_services == "all":
            return service_data

        # Sort by cost descending
        sorted_data = service_data.sort_values(by=cost_column, ascending=False)

        # Filter top N
        top_n = int(self.config.top_services)
        return sorted_data.head(top_n)

    def format_summary(self, dashboard_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format dashboard summary based on persona configuration.

        Args:
            dashboard_data: Raw dashboard data dictionary

        Returns:
            Persona-formatted summary dictionary
        """
        formatted = {
            "persona": self.persona,
            "summary_length": self.config.summary_length,
            "primary_metric": self.config.primary_metric,
            "focus_areas": self.config.focus_areas,
        }

        # Add persona-specific sections
        if self.config.include_recommendations:
            formatted["recommendations"] = self._generate_recommendations(dashboard_data)

        if self.config.action_items:
            formatted["action_items"] = self._extract_action_items(
                dashboard_data, self.config.action_items
            )

        if self.config.threshold_alerts:
            formatted["alerts"] = self._detect_threshold_alerts(dashboard_data)

        return formatted

    def _generate_recommendations(self, dashboard_data: Dict[str, Any]) -> List[str]:
        """
        Generate persona-specific recommendations.

        Args:
            dashboard_data: Raw dashboard data

        Returns:
            List of recommendations tailored to persona
        """
        recommendations = []

        if self.persona == "cfo":
            # Budget-focused recommendations
            recommendations.append("Review top 5 cost drivers for optimization opportunities")
            recommendations.append("Validate forecast accuracy against actual spend")

        elif self.persona == "cto":
            # Technical recommendations
            recommendations.append("Analyze E1-E7 signals for rightsizing candidates")
            recommendations.append("Review service architecture for optimization patterns")

        elif self.persona == "ceo":
            # Strategic recommendations
            recommendations.append("Monitor cost trajectory alignment with growth targets")
            recommendations.append("Review cloud spend as percentage of revenue")

        elif self.persona == "executive":
            # Executive-level recommendations
            recommendations.append("Review board-ready summary for strategic decisions")
            recommendations.append("Validate top recommendations with leadership team")

        return recommendations

    def _extract_action_items(
        self, dashboard_data: Dict[str, Any], max_items: int
    ) -> List[str]:
        """
        Extract top N action items for persona.

        Args:
            dashboard_data: Raw dashboard data
            max_items: Maximum number of action items

        Returns:
            List of prioritized action items
        """
        action_items = []

        # Extract from dashboard data based on persona focus
        if "recommendations" in dashboard_data:
            action_items = dashboard_data["recommendations"][:max_items]
        else:
            # Default action items
            action_items = [
                f"Review {self.config.primary_metric} trends",
                f"Analyze top {self.config.top_services} services",
                "Validate optimization opportunities",
            ]

        return action_items[:max_items]

    def _detect_threshold_alerts(self, dashboard_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Detect cost threshold alerts for SRE persona.

        Args:
            dashboard_data: Raw dashboard data

        Returns:
            List of alert dictionaries with severity and details
        """
        alerts = []

        # Cost spike detection (20% threshold for SRE)
        if "cost_change_pct" in dashboard_data:
            change_pct = dashboard_data.get("cost_change_pct", 0)
            if abs(change_pct) > 20:
                alerts.append(
                    {
                        "severity": "high" if abs(change_pct) > 50 else "medium",
                        "type": "cost_spike",
                        "message": f"Cost change of {change_pct:.1f}% exceeds 20% threshold",
                    }
                )

        return alerts

    def get_display_config(self) -> Dict[str, Any]:
        """
        Get display configuration for Rich CLI rendering.

        Returns:
            Dictionary with display preferences for current persona
        """
        return {
            "persona": self.persona,
            "top_n": self.config.top_services,
            "show_zero_cost": not self.config.exclude_zero_cost,
            "summary_style": self.config.summary_length,
            "include_recommendations": self.config.include_recommendations,
            "threshold_alerts": self.config.threshold_alerts,
        }

    def format_title(self, base_title: str) -> str:
        """
        Format dashboard title with persona context.

        Args:
            base_title: Base dashboard title

        Returns:
            Persona-customized title
        """
        persona_labels = {
            "cfo": "CFO Financial Dashboard",
            "cto": "CTO Technical Dashboard",
            "ceo": "CEO Executive Dashboard",
            "sre": "SRE Operations Dashboard",
            "architect": "Cloud Architecture Dashboard",
            "technical": "Technical Cost Analysis",
            "executive": "Executive Summary Dashboard",
        }
        return persona_labels.get(self.persona, base_title)


def create_persona_formatter(mode: str) -> PersonaFormatter:
    """
    Factory function to create PersonaFormatter from CLI mode.

    Args:
        mode: CLI mode parameter value

    Returns:
        PersonaFormatter instance configured for specified mode
    """
    # Map CLI mode values to persona types
    mode_mapping = {
        "executive": "executive",
        "architect": "architect",
        "sre": "sre",
        "cfo": "cfo",
        "cto": "cto",
        "ceo": "ceo",
        "technical": "technical",
    }

    persona = mode_mapping.get(mode.lower(), "technical")
    return PersonaFormatter(persona)
