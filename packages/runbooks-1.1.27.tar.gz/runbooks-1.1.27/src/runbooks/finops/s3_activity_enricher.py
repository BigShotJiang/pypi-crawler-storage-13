#!/usr/bin/env python3
"""
S3 Activity Enricher - S3 Bucket Activity Signals
==================================================

Business Value: Idle S3 bucket detection enabling cost optimization
Strategic Impact: Complement ECS/DynamoDB patterns for storage workloads
Integration: Feeds data to FinOps decommission scoring framework

Architecture Pattern: 5-layer enrichment framework (matches DynamoDB/ECS patterns)
- Layer 1: Resource discovery (consumed from external modules)
- Layer 2: Organizations enrichment (account names)
- Layer 3: Cost enrichment (pricing data)
- Layer 4: S3 activity enrichment (THIS MODULE)
- Layer 5: Decommission scoring (uses S1-S7 signals)

Decommission Signals (S1-S7):
- S1: 0 requests in 90 days (HIGH confidence: 0.90)
- S2: Old objects >1 year without lifecycle (MEDIUM confidence: 0.75)
- S3: Versioning enabled, no expiration (MEDIUM confidence: 0.70)
- S4: Public access + no encryption (MEDIUM confidence: 0.70)
- S5: Intelligent-Tiering candidates (MEDIUM confidence: 0.65)
- S6: Cross-region replication waste (MEDIUM confidence: 0.65)
- S7: Request cost >$10/month (MEDIUM confidence: 0.70)

Usage:
    from runbooks.finops.s3_activity_enricher import S3ActivityEnricher

    enricher = S3ActivityEnricher(
        operational_profile='CENTRALISED_OPS_PROFILE',
        region='ap-southeast-2'
    )

    # Analyze S3 bucket activity
    analyses = enricher.analyze_bucket_activity(
        bucket_names=['my-bucket-name']
    )

    # Display analysis
    enricher.display_analysis(analyses)

MCP Validation:
    - Cross-validate activity patterns with Cost Explorer S3 service costs
    - Flag discrepancies (low activity but high costs = potential issue)
    - Achieve ≥99.5% validation accuracy target

Author: Runbooks Team
Version: 1.0.0
Epic: v1.1.20 FinOps Dashboard Enhancements
Track: Track 2 - S3 Activity Enricher
"""

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import boto3
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import (
    console,
    create_panel,
    create_progress_bar,
    create_table,
    format_cost,
    print_error,
    print_info,
    print_section,
    print_success,
    print_warning,
)
from runbooks.common.profile_utils import (
    get_profile_for_operation,
    create_operational_session,
)
from runbooks.common.output_controller import OutputController

logger = logging.getLogger(__name__)


# ═════════════════════════════════════════════════════════════════════════════
# ENUMERATION TYPES
# ═════════════════════════════════════════════════════════════════════════════


class S3IdleSignal(str, Enum):
    """S3 idle/underutilization decommission signals (S1-S7)."""
    S1_ZERO_REQUESTS = "S1"  # 0 requests in 90 days
    S2_OLD_OBJECTS = "S2"  # Objects >1 year without lifecycle
    S3_VERSIONING_NO_EXPIRATION = "S3"  # Versioning enabled, no expiration
    S4_PUBLIC_NO_ENCRYPTION = "S4"  # Public access + no encryption
    S5_INTELLIGENT_TIERING = "S5"  # Intelligent-Tiering candidates
    S6_REPLICATION_WASTE = "S6"  # Cross-region replication waste
    S7_HIGH_REQUEST_COST = "S7"  # Request cost >$10/month


class ActivityPattern(str, Enum):
    """S3 bucket access pattern classification."""
    ACTIVE = "active"           # Production workload (>1000 requests/day)
    MODERATE = "moderate"       # Development/staging (100-1000 requests/day)
    LIGHT = "light"            # Test environment (<100 requests/day)
    IDLE = "idle"              # No requests in 90 days


class DecommissionRecommendation(str, Enum):
    """Decommission recommendations based on activity analysis."""
    DECOMMISSION = "DECOMMISSION"  # High confidence - decommission candidate
    INVESTIGATE = "INVESTIGATE"    # Medium confidence - needs review
    OPTIMIZE = "OPTIMIZE"          # Moderate underutilization - rightsize
    KEEP = "KEEP"                  # Active resource - retain


# ═════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═════════════════════════════════════════════════════════════════════════════


@dataclass
class S3ActivityMetrics:
    """
    CloudWatch metrics for S3 bucket.

    Comprehensive activity metrics for decommission decision-making with
    S1-S7 signal framework.
    """
    total_requests_90d: int
    avg_requests_per_day: float
    get_requests_90d: int
    put_requests_90d: int
    total_objects: int
    total_size_gb: float
    versioning_enabled: bool
    lifecycle_enabled: bool
    public_access_blocked: bool
    encryption_enabled: bool
    replication_enabled: bool
    intelligent_tiering_enabled: bool
    avg_object_age_days: float = 0.0
    request_cost_monthly: float = 0.0


@dataclass
class S3ActivityAnalysis:
    """
    S3 bucket activity analysis result.

    Comprehensive activity metrics for decommission decision-making with
    S1-S7 signal framework and cost impact analysis.
    """
    bucket_name: str
    region: str
    account_id: str
    metrics: S3ActivityMetrics
    activity_pattern: ActivityPattern
    idle_signals: List[S3IdleSignal] = field(default_factory=list)
    monthly_cost: float = 0.0
    annual_cost: float = 0.0
    potential_savings: float = 0.0
    confidence: float = 0.0  # 0.0-1.0
    recommendation: DecommissionRecommendation = DecommissionRecommendation.KEEP
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "bucket_name": self.bucket_name,
            "region": self.region,
            "account_id": self.account_id,
            "metrics": {
                "total_requests_90d": self.metrics.total_requests_90d,
                "avg_requests_per_day": self.metrics.avg_requests_per_day,
                "get_requests_90d": self.metrics.get_requests_90d,
                "put_requests_90d": self.metrics.put_requests_90d,
                "total_objects": self.metrics.total_objects,
                "total_size_gb": self.metrics.total_size_gb,
                "versioning_enabled": self.metrics.versioning_enabled,
                "lifecycle_enabled": self.metrics.lifecycle_enabled,
                "public_access_blocked": self.metrics.public_access_blocked,
                "encryption_enabled": self.metrics.encryption_enabled,
                "replication_enabled": self.metrics.replication_enabled,
                "intelligent_tiering_enabled": self.metrics.intelligent_tiering_enabled,
                "avg_object_age_days": self.metrics.avg_object_age_days,
                "request_cost_monthly": self.metrics.request_cost_monthly,
            },
            "activity_pattern": self.activity_pattern.value,
            "idle_signals": [signal.value for signal in self.idle_signals],
            "monthly_cost": self.monthly_cost,
            "annual_cost": self.annual_cost,
            "potential_savings": self.potential_savings,
            "confidence": self.confidence,
            "recommendation": self.recommendation.value,
            "metadata": self.metadata,
        }


# ═════════════════════════════════════════════════════════════════════════════
# CORE ENRICHER CLASS
# ═════════════════════════════════════════════════════════════════════════════


class S3ActivityEnricher:
    """
    S3 activity enricher for inventory resources.

    Analyzes S3 buckets for idle/underutilization patterns using CloudWatch
    metrics with S1-S7 signal framework.

    Capabilities:
    - Activity metrics analysis (90 day windows)
    - Request pattern tracking
    - Storage configuration analysis
    - Lifecycle policy evaluation
    - Public access and encryption validation
    - Comprehensive decommission recommendations

    Decommission Signals Generated:
    - S1: 0 requests in 90 days (HIGH confidence: 0.90)
    - S2: Old objects >1 year without lifecycle (MEDIUM confidence: 0.75)
    - S3: Versioning enabled, no expiration (MEDIUM confidence: 0.70)
    - S4: Public access + no encryption (MEDIUM confidence: 0.70)
    - S5: Intelligent-Tiering candidates (MEDIUM confidence: 0.65)
    - S6: Cross-region replication waste (MEDIUM confidence: 0.65)
    - S7: High request cost >$10/month (MEDIUM confidence: 0.70)

    Example:
        >>> enricher = S3ActivityEnricher(
        ...     operational_profile='ops-profile',
        ...     region='ap-southeast-2'
        ... )
        >>> analyses = enricher.analyze_bucket_activity(
        ...     bucket_names=['my-bucket']
        ... )
        >>> for analysis in analyses:
        ...     if S3IdleSignal.S1_ZERO_REQUESTS in analysis.idle_signals:
        ...         print(f"Idle bucket: {analysis.bucket_name}")
    """

    # Activity thresholds for classification
    ACTIVE_REQUESTS_THRESHOLD = 1000  # requests per day
    MODERATE_REQUESTS_THRESHOLD = 100  # requests per day

    # S3 pricing (ap-southeast-2) - placeholder, should use AWS Pricing API
    # Example: $0.025/GB-month Standard, $0.005/1000 GET requests
    DEFAULT_STORAGE_GB_MONTHLY_RATE = 0.025
    DEFAULT_GET_REQUEST_PER_1000 = 0.0005
    DEFAULT_PUT_REQUEST_PER_1000 = 0.005

    def __init__(
        self,
        operational_profile: Optional[str] = None,
        region: Optional[str] = None,
        lookback_days: int = 90,
        cache_ttl: int = 300,
        output_controller: Optional[OutputController] = None
    ):
        """
        Initialize S3 activity enricher.

        Args:
            operational_profile: AWS profile for operational account
            region: AWS region for S3 queries (default: ap-southeast-2)
            lookback_days: CloudWatch lookback period (default: 90)
            cache_ttl: Cache TTL in seconds (default: 300 = 5 minutes)
        """
        self.operational_profile = operational_profile or get_profile_for_operation("operational")
        self.region = region or 'ap-southeast-2'
        self.lookback_days = min(lookback_days, 455)  # CloudWatch metrics retention
        self.cache_ttl = cache_ttl

        # Initialize AWS session
        self.session = create_operational_session(self.operational_profile)
        self.s3_client = self.session.client('s3', region_name=self.region)
        self.cloudwatch_client = self.session.client('cloudwatch', region_name=self.region)

        # Validation cache (5-minute TTL for performance)
        self._cache: Dict[str, Tuple[S3ActivityAnalysis, float]] = {}

        # Performance tracking
        self.query_count = 0
        self.total_execution_time = 0.0

        # Logger
        self.logger = logging.getLogger(__name__)

        # OutputController for verbose mode support
        self.output_controller = output_controller or OutputController()

        # Verbose-aware initialization logging
        if self.output_controller.verbose:
            print_info(f"🔍 S3 Activity Enricher initialized: profile={self.operational_profile}, region={self.region}, lookback={self.lookback_days}d")
        else:
            self.logger.debug(f"S3 Activity Enricher initialized: profile={self.operational_profile}, region={self.region}, lookback={self.lookback_days}d")

    def analyze_bucket_activity(
        self,
        bucket_names: Optional[List[str]] = None,
        region: Optional[str] = None,
        lookback_days: Optional[int] = None
    ) -> List[S3ActivityAnalysis]:
        """
        Analyze S3 bucket activity for idle detection.

        Core analysis workflow:
        1. Query S3 buckets (all or specific names)
        2. Get CloudWatch metrics for each bucket (90 day window)
        3. Classify activity pattern (active/moderate/light/idle)
        4. Generate S1-S7 decommission signals based on patterns
        5. Compute confidence score and recommendation
        6. Calculate cost impact and potential savings

        Args:
            bucket_names: List of bucket names to analyze (analyzes all if None)
            region: AWS region filter (default: use instance region)
            lookback_days: Lookback period (default: use instance default)

        Returns:
            List of activity analyses with decommission signals

        Example:
            >>> analyses = enricher.analyze_bucket_activity(
            ...     bucket_names=['my-bucket']
            ... )
            >>> for analysis in analyses:
            ...     print(f"{analysis.bucket_name}: {analysis.recommendation.value}")
        """
        start_time = time.time()
        analysis_region = region or self.region
        lookback = lookback_days or self.lookback_days

        print_section(f"S3 Activity Analysis ({lookback}-day lookback)")

        # Get S3 buckets
        buckets = self._get_s3_buckets(bucket_names, analysis_region)

        if not buckets:
            print_warning("No S3 buckets found")
            return []

        print_info(f"Found {len(buckets)} S3 buckets")

        analyses: List[S3ActivityAnalysis] = []

        with create_progress_bar(description="Analyzing S3 buckets") as progress:
            task = progress.add_task(
                f"Analyzing {len(buckets)} buckets",
                total=len(buckets)
            )

            for bucket in buckets:
                try:
                    # Check cache first
                    bucket_name = bucket['Name']
                    cache_key = f"{bucket_name}:{lookback}"
                    cached_result = self._get_from_cache(cache_key)
                    if cached_result:
                        analyses.append(cached_result)
                        progress.update(task, advance=1)
                        continue

                    # Analyze bucket
                    analysis = self._analyze_bucket(bucket, lookback)

                    # Cache result
                    self._add_to_cache(cache_key, analysis)

                    analyses.append(analysis)

                except Exception as e:
                    self.logger.error(
                        f"Failed to analyze S3 bucket {bucket.get('Name')}: {e}",
                        exc_info=True
                    )
                    print_warning(f"⚠️  Skipped {bucket.get('Name')}: {str(e)[:100]}")

                progress.update(task, advance=1)

        # Update performance metrics
        self.total_execution_time += time.time() - start_time

        # Display summary
        self._display_summary(analyses)

        return analyses

    def _get_s3_buckets(
        self,
        bucket_names: Optional[List[str]],
        region: str
    ) -> List[Dict]:
        """
        Get S3 buckets from AWS API.

        Args:
            bucket_names: Specific buckets to retrieve (retrieves all if None)
            region: AWS region filter

        Returns:
            List of S3 bucket metadata dictionaries
        """
        buckets = []

        try:
            response = self.s3_client.list_buckets()
            all_buckets = response.get('Buckets', [])

            for bucket in all_buckets:
                bucket_name = bucket['Name']

                # Filter by specific bucket names if provided
                if bucket_names and bucket_name not in bucket_names:
                    continue

                # Get bucket region
                try:
                    bucket_region = self.s3_client.get_bucket_location(
                        Bucket=bucket_name
                    )['LocationConstraint'] or 'us-east-1'

                    # Filter by region if specified
                    if region and bucket_region != region:
                        continue

                except ClientError:
                    # Skip buckets we can't access
                    continue

                buckets.append(bucket)

        except ClientError as e:
            self.logger.error(f"Failed to list S3 buckets: {e}")

        return buckets

    def _analyze_bucket(
        self,
        bucket: Dict,
        lookback_days: int
    ) -> S3ActivityAnalysis:
        """
        Analyze individual S3 bucket.

        Args:
            bucket: S3 bucket metadata from list_buckets
            lookback_days: CloudWatch metrics lookback period

        Returns:
            Comprehensive activity analysis with idle signals
        """
        bucket_name = bucket['Name']

        # Get CloudWatch metrics
        metrics = self._get_cloudwatch_metrics(bucket, lookback_days)

        # Classify activity pattern
        activity_pattern = self._classify_activity_pattern(metrics)

        # Generate idle signals
        idle_signals = self._generate_idle_signals(metrics, activity_pattern)

        # Calculate costs
        monthly_cost = self._calculate_monthly_cost(metrics)
        annual_cost = monthly_cost * 12

        # Calculate potential savings
        confidence = self._calculate_confidence(idle_signals)
        potential_savings = self._calculate_potential_savings(
            annual_cost,
            confidence,
            activity_pattern
        )

        # Generate recommendation
        recommendation = self._generate_recommendation(
            activity_pattern,
            idle_signals,
            confidence
        )

        # Get account ID
        try:
            sts = self.session.client('sts')
            account_id = sts.get_caller_identity()['Account']
        except Exception:
            account_id = "unknown"

        # Get bucket region
        try:
            bucket_region = self.s3_client.get_bucket_location(
                Bucket=bucket_name
            )['LocationConstraint'] or 'us-east-1'
        except Exception:
            bucket_region = self.region

        return S3ActivityAnalysis(
            bucket_name=bucket_name,
            region=bucket_region,
            account_id=account_id,
            metrics=metrics,
            activity_pattern=activity_pattern,
            idle_signals=idle_signals,
            monthly_cost=monthly_cost,
            annual_cost=annual_cost,
            potential_savings=potential_savings,
            confidence=confidence,
            recommendation=recommendation,
            metadata={
                'lookback_days': lookback_days,
                'query_time': datetime.now(tz=timezone.utc).isoformat(),
            }
        )

    def _get_cloudwatch_metrics(
        self,
        bucket: Dict,
        lookback_days: int
    ) -> S3ActivityMetrics:
        """
        Get CloudWatch metrics for S3 bucket.

        Metrics queried:
        - NumberOfObjects (bucket size)
        - BucketSizeBytes (storage size)
        - AllRequests (total requests)

        Args:
            bucket: S3 bucket metadata
            lookback_days: Lookback period for metrics

        Returns:
            Comprehensive activity metrics
        """
        bucket_name = bucket['Name']
        now = datetime.utcnow()

        # Query total requests
        total_requests = self._get_s3_metric_sum(
            bucket_name, 'AllRequests',
            now - timedelta(days=lookback_days), now
        )

        # Query GET requests
        get_requests = self._get_s3_metric_sum(
            bucket_name, 'GetRequests',
            now - timedelta(days=lookback_days), now
        )

        # Query PUT requests
        put_requests = self._get_s3_metric_sum(
            bucket_name, 'PutRequests',
            now - timedelta(days=lookback_days), now
        )

        # Get bucket configuration
        versioning_enabled = self._check_versioning(bucket_name)
        lifecycle_enabled = self._check_lifecycle(bucket_name)
        public_access_blocked = self._check_public_access_block(bucket_name)
        encryption_enabled = self._check_encryption(bucket_name)
        replication_enabled = self._check_replication(bucket_name)
        intelligent_tiering_enabled = self._check_intelligent_tiering(bucket_name)

        # Get bucket size and object count
        total_objects, total_size_gb = self._get_bucket_size(bucket_name)

        # Calculate average object age (approximation)
        avg_object_age_days = self._estimate_object_age(bucket_name)

        # Calculate request costs
        request_cost_monthly = self._calculate_request_cost(get_requests, put_requests, lookback_days)

        avg_requests_per_day = total_requests / max(1, lookback_days)

        return S3ActivityMetrics(
            total_requests_90d=int(total_requests),
            avg_requests_per_day=avg_requests_per_day,
            get_requests_90d=int(get_requests),
            put_requests_90d=int(put_requests),
            total_objects=total_objects,
            total_size_gb=total_size_gb,
            versioning_enabled=versioning_enabled,
            lifecycle_enabled=lifecycle_enabled,
            public_access_blocked=public_access_blocked,
            encryption_enabled=encryption_enabled,
            replication_enabled=replication_enabled,
            intelligent_tiering_enabled=intelligent_tiering_enabled,
            avg_object_age_days=avg_object_age_days,
            request_cost_monthly=request_cost_monthly
        )

    def _get_s3_metric_sum(
        self,
        bucket_name: str,
        metric_name: str,
        start_time: datetime,
        end_time: datetime
    ) -> float:
        """
        Get S3 CloudWatch metric sum.

        Args:
            bucket_name: S3 bucket name
            metric_name: CloudWatch metric name
            start_time: Query start time
            end_time: Query end time

        Returns:
            Metric sum value, or 0.0 if no data
        """
        try:
            response = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/S3',
                MetricName=metric_name,
                Dimensions=[
                    {'Name': 'BucketName', 'Value': bucket_name},
                    {'Name': 'StorageType', 'Value': 'AllStorageTypes'}
                ],
                StartTime=start_time,
                EndTime=end_time,
                Period=86400,  # 1 day
                Statistics=['Sum']
            )

            datapoints = response['Datapoints']
            if not datapoints:
                return 0.0

            # Increment query counter
            self.query_count += 1

            return sum(d['Sum'] for d in datapoints)

        except ClientError as e:
            self.logger.debug(f"CloudWatch query failed for {bucket_name}/{metric_name}: {e}")
            return 0.0

    def _check_versioning(self, bucket_name: str) -> bool:
        """Check if bucket has versioning enabled."""
        try:
            response = self.s3_client.get_bucket_versioning(Bucket=bucket_name)
            return response.get('Status') == 'Enabled'
        except ClientError:
            return False

    def _check_lifecycle(self, bucket_name: str) -> bool:
        """Check if bucket has lifecycle policies."""
        try:
            self.s3_client.get_bucket_lifecycle_configuration(Bucket=bucket_name)
            return True
        except ClientError:
            return False

    def _check_public_access_block(self, bucket_name: str) -> bool:
        """Check if bucket has public access blocked."""
        try:
            response = self.s3_client.get_public_access_block(Bucket=bucket_name)
            config = response.get('PublicAccessBlockConfiguration', {})
            return all([
                config.get('BlockPublicAcls', False),
                config.get('IgnorePublicAcls', False),
                config.get('BlockPublicPolicy', False),
                config.get('RestrictPublicBuckets', False)
            ])
        except ClientError:
            return False

    def _check_encryption(self, bucket_name: str) -> bool:
        """Check if bucket has default encryption."""
        try:
            self.s3_client.get_bucket_encryption(Bucket=bucket_name)
            return True
        except ClientError:
            return False

    def _check_replication(self, bucket_name: str) -> bool:
        """
        Check if bucket has replication enabled.

        S7 Signal Enhancement (v1.1.27): 100% confidence via AWS API
        Replaces name-based heuristic (75% confidence) with direct API check.

        Returns:
            True if replication configured, False otherwise
        """
        try:
            self.s3_client.get_bucket_replication(Bucket=bucket_name)
            return True
        except ClientError as e:
            # ReplicationConfigurationNotFoundError means no replication
            if e.response['Error']['Code'] == 'ReplicationConfigurationNotFoundError':
                return False
            # Other errors (AccessDenied, etc.) treated as False
            self.logger.debug(f"S7 replication check failed for {bucket_name}: {e}")
            return False

    def _check_intelligent_tiering(self, bucket_name: str) -> bool:
        """Check if bucket has Intelligent-Tiering configuration."""
        try:
            self.s3_client.list_bucket_intelligent_tiering_configurations(Bucket=bucket_name)
            return True
        except ClientError:
            return False

    def _get_bucket_size(self, bucket_name: str) -> Tuple[int, float]:
        """
        Get bucket object count and size.

        Args:
            bucket_name: S3 bucket name

        Returns:
            Tuple of (object_count, size_gb)
        """
        try:
            # Query CloudWatch for bucket metrics
            now = datetime.utcnow()
            yesterday = now - timedelta(days=1)

            # Get number of objects
            objects_response = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/S3',
                MetricName='NumberOfObjects',
                Dimensions=[
                    {'Name': 'BucketName', 'Value': bucket_name},
                    {'Name': 'StorageType', 'Value': 'AllStorageTypes'}
                ],
                StartTime=yesterday,
                EndTime=now,
                Period=86400,
                Statistics=['Average']
            )

            objects_datapoints = objects_response['Datapoints']
            object_count = int(objects_datapoints[0]['Average']) if objects_datapoints else 0

            # Get bucket size
            size_response = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/S3',
                MetricName='BucketSizeBytes',
                Dimensions=[
                    {'Name': 'BucketName', 'Value': bucket_name},
                    {'Name': 'StorageType', 'Value': 'StandardStorage'}
                ],
                StartTime=yesterday,
                EndTime=now,
                Period=86400,
                Statistics=['Average']
            )

            size_datapoints = size_response['Datapoints']
            size_bytes = size_datapoints[0]['Average'] if size_datapoints else 0
            size_gb = size_bytes / (1024 ** 3)

            # v1.1.27: Full pagination for accurate object counts (user requested - Track 2)
            # CloudWatch metrics can be stale (24-48hr lag); use direct API for accurate counts
            if object_count == 0:
                try:
                    # Full pagination: Get actual object count (handles large buckets)
                    paginator = self.s3_client.get_paginator('list_objects_v2')
                    page_iterator = paginator.paginate(
                        Bucket=bucket_name,
                        PaginationConfig={'MaxItems': 1000000}  # Reasonable limit for decommission detection
                    )

                    # Sum KeyCount across all pages (more efficient than counting Contents)
                    total_count = sum(page.get('KeyCount', 0) for page in page_iterator)
                    object_count = total_count  # Actual count from pagination

                except ClientError as e:
                    # Access denied or bucket doesn't exist - keep CloudWatch value (0)
                    # Common for encrypted buckets without KMS permissions
                    pass

            return object_count, size_gb

        except ClientError:
            return 0, 0.0

    def _estimate_object_age(self, bucket_name: str) -> float:
        """
        Estimate average object age (days since creation).

        Args:
            bucket_name: S3 bucket name

        Returns:
            Average object age in days
        """
        # Simplified estimation: use bucket creation date as proxy
        # In production, would sample objects for accurate age
        try:
            response = self.s3_client.list_buckets()
            for bucket in response['Buckets']:
                if bucket['Name'] == bucket_name:
                    creation_date = bucket['CreationDate']
                    age_days = (datetime.now(tz=timezone.utc) - creation_date).days
                    return float(age_days)
        except Exception:
            pass

        return 0.0

    def _calculate_request_cost(
        self,
        get_requests: float,
        put_requests: float,
        lookback_days: int
    ) -> float:
        """
        Calculate monthly request costs.

        Args:
            get_requests: Total GET requests in period
            put_requests: Total PUT requests in period
            lookback_days: Lookback period

        Returns:
            Estimated monthly request cost
        """
        # Extrapolate to monthly
        days_per_month = 30
        monthly_gets = (get_requests / lookback_days) * days_per_month
        monthly_puts = (put_requests / lookback_days) * days_per_month

        # Calculate costs
        get_cost = (monthly_gets / 1000) * self.DEFAULT_GET_REQUEST_PER_1000
        put_cost = (monthly_puts / 1000) * self.DEFAULT_PUT_REQUEST_PER_1000

        return get_cost + put_cost

    def _classify_activity_pattern(self, metrics: S3ActivityMetrics) -> ActivityPattern:
        """
        Classify S3 activity pattern.

        Classification:
        - ACTIVE: >1000 requests/day (production)
        - MODERATE: 100-1000 requests/day (dev/staging)
        - LIGHT: <100 requests/day (test)
        - IDLE: 0 requests in 90 days

        Args:
            metrics: S3 activity metrics

        Returns:
            ActivityPattern enum
        """
        avg_requests = metrics.avg_requests_per_day

        if avg_requests >= self.ACTIVE_REQUESTS_THRESHOLD:
            return ActivityPattern.ACTIVE
        elif avg_requests >= self.MODERATE_REQUESTS_THRESHOLD:
            return ActivityPattern.MODERATE
        elif avg_requests > 0:
            return ActivityPattern.LIGHT
        else:
            return ActivityPattern.IDLE

    def _generate_idle_signals(
        self,
        metrics: S3ActivityMetrics,
        pattern: ActivityPattern
    ) -> List[S3IdleSignal]:
        """
        Generate S1-S7 idle signals.

        Signal generation rules:
        - S1: 0 requests in 90 days → HIGH confidence (0.90)
        - S2: Old objects >1 year without lifecycle → MEDIUM confidence (0.75)
        - S3: Versioning enabled, no expiration → MEDIUM confidence (0.70)
        - S4: Public access + no encryption → MEDIUM confidence (0.70)
        - S5: Intelligent-Tiering candidates → MEDIUM confidence (0.65)
        - S6: Cross-region replication waste → MEDIUM confidence (0.65)
        - S7: Request cost >$10/month → MEDIUM confidence (0.70)

        Args:
            metrics: S3 activity metrics
            pattern: Activity pattern classification

        Returns:
            List of applicable S3IdleSignal enums
        """
        signals: List[S3IdleSignal] = []

        # S1: Zero requests in 90 days
        if metrics.total_requests_90d == 0:
            signals.append(S3IdleSignal.S1_ZERO_REQUESTS)

        # S2: Old objects without lifecycle
        if metrics.avg_object_age_days > 365 and not metrics.lifecycle_enabled:
            signals.append(S3IdleSignal.S2_OLD_OBJECTS)

        # S3: Versioning enabled without expiration
        if metrics.versioning_enabled and not metrics.lifecycle_enabled:
            signals.append(S3IdleSignal.S3_VERSIONING_NO_EXPIRATION)

        # S4: Public access without encryption
        if not metrics.public_access_blocked and not metrics.encryption_enabled:
            signals.append(S3IdleSignal.S4_PUBLIC_NO_ENCRYPTION)

        # S5: Intelligent-Tiering candidates
        if pattern in [ActivityPattern.LIGHT, ActivityPattern.MODERATE]:
            if not metrics.intelligent_tiering_enabled and metrics.total_size_gb > 10:
                signals.append(S3IdleSignal.S5_INTELLIGENT_TIERING)

        # S6: Replication waste
        if metrics.replication_enabled and pattern in [ActivityPattern.IDLE, ActivityPattern.LIGHT]:
            signals.append(S3IdleSignal.S6_REPLICATION_WASTE)

        # S7: High request costs
        if metrics.request_cost_monthly > 10:
            signals.append(S3IdleSignal.S7_HIGH_REQUEST_COST)

        return signals

    def _calculate_confidence(self, signals: List[S3IdleSignal]) -> float:
        """
        Calculate idle confidence score.

        Signal weights:
        - S1: 0.90 (0 requests in 90 days)
        - S2: 0.75 (old objects without lifecycle)
        - S3: 0.70 (versioning without expiration)
        - S4: 0.70 (public access without encryption)
        - S5: 0.65 (intelligent-tiering candidates)
        - S6: 0.65 (replication waste)
        - S7: 0.70 (high request cost)

        Args:
            signals: List of idle signals

        Returns:
            Confidence score (0.0-1.0)
        """
        if not signals:
            return 0.0

        # Signal confidence mapping
        signal_confidence = {
            S3IdleSignal.S1_ZERO_REQUESTS: 0.90,
            S3IdleSignal.S2_OLD_OBJECTS: 0.75,
            S3IdleSignal.S3_VERSIONING_NO_EXPIRATION: 0.70,
            S3IdleSignal.S4_PUBLIC_NO_ENCRYPTION: 0.70,
            S3IdleSignal.S5_INTELLIGENT_TIERING: 0.65,
            S3IdleSignal.S6_REPLICATION_WASTE: 0.65,
            S3IdleSignal.S7_HIGH_REQUEST_COST: 0.70,
        }

        # Use maximum confidence from all signals
        return max(signal_confidence.get(signal, 0.0) for signal in signals)

    def _calculate_monthly_cost(self, metrics: S3ActivityMetrics) -> float:
        """
        Calculate monthly S3 bucket cost.

        Args:
            metrics: Activity metrics

        Returns:
            Monthly cost estimate
        """
        # Storage cost
        storage_cost = metrics.total_size_gb * self.DEFAULT_STORAGE_GB_MONTHLY_RATE

        # Request cost (already calculated)
        request_cost = metrics.request_cost_monthly

        return storage_cost + request_cost

    def _calculate_potential_savings(
        self,
        annual_cost: float,
        confidence: float,
        pattern: ActivityPattern
    ) -> float:
        """
        Calculate potential annual savings.

        Savings scenarios:
        - IDLE: 100% savings (decommission)
        - LIGHT: 80% savings (optimize with lifecycle)
        - MODERATE: 40% savings (intelligent-tiering)
        - ACTIVE: 0% savings (keep as-is)

        Args:
            annual_cost: Annual S3 bucket cost
            confidence: Idle confidence score
            pattern: Activity pattern

        Returns:
            Potential annual savings amount
        """
        savings_multiplier = {
            ActivityPattern.IDLE: 1.0,
            ActivityPattern.LIGHT: 0.8,
            ActivityPattern.MODERATE: 0.4,
            ActivityPattern.ACTIVE: 0.0
        }

        multiplier = savings_multiplier.get(pattern, 0.0)
        return annual_cost * multiplier * confidence

    def _generate_recommendation(
        self,
        pattern: ActivityPattern,
        signals: List[S3IdleSignal],
        confidence: float
    ) -> DecommissionRecommendation:
        """
        Generate optimization recommendation.

        Recommendation logic:
        - DECOMMISSION: confidence ≥ 0.90 OR S1 signal present
        - INVESTIGATE: confidence ≥ 0.70
        - OPTIMIZE: confidence ≥ 0.50
        - KEEP: confidence < 0.50

        Args:
            pattern: Activity pattern
            signals: List of idle signals
            confidence: Overall confidence score

        Returns:
            DecommissionRecommendation enum
        """
        # High confidence decommission candidates
        if confidence >= 0.90 or S3IdleSignal.S1_ZERO_REQUESTS in signals:
            return DecommissionRecommendation.DECOMMISSION

        # Medium confidence - needs investigation
        if confidence >= 0.70:
            return DecommissionRecommendation.INVESTIGATE

        # Moderate underutilization - optimize
        if confidence >= 0.50:
            return DecommissionRecommendation.OPTIMIZE

        # Low confidence - keep resource
        return DecommissionRecommendation.KEEP

    def display_analysis(self, analyses: List[S3ActivityAnalysis]) -> None:
        """
        Display S3 activity analysis in Rich table format.

        Creates comprehensive activity analysis table with:
        - Bucket name and region
        - Activity metrics (requests, storage size)
        - Decommission signals (S1-S7)
        - Recommendation and confidence

        Args:
            analyses: List of S3ActivityAnalysis objects
        """
        if not analyses:
            print_warning("No S3 buckets to display")
            return

        # Create analysis table
        table = create_table(
            title="S3 Bucket Activity Analysis",
            columns=[
                {"name": "Bucket Name", "style": "cyan"},
                {"name": "Requests/Day", "style": "bright_yellow"},
                {"name": "Size (GB)", "style": "white"},
                {"name": "Signals", "style": "bright_magenta"},
                {"name": "Monthly Cost", "style": "white"},
                {"name": "Potential Savings", "style": "bright_green"},
                {"name": "Recommendation", "style": "bold"},
            ]
        )

        for analysis in analyses:
            # Format signals
            signals_str = ', '.join(signal.value for signal in analysis.idle_signals)
            if not signals_str:
                signals_str = 'None'

            # Format recommendation with color
            rec = analysis.recommendation
            if rec == DecommissionRecommendation.DECOMMISSION:
                rec_str = f"[bright_red]{rec.value}[/bright_red]"
            elif rec == DecommissionRecommendation.INVESTIGATE:
                rec_str = f"[bright_yellow]{rec.value}[/bright_yellow]"
            elif rec == DecommissionRecommendation.OPTIMIZE:
                rec_str = f"[yellow]{rec.value}[/yellow]"
            else:
                rec_str = f"[bright_green]{rec.value}[/bright_green]"

            table.add_row(
                analysis.bucket_name,
                f"{analysis.metrics.avg_requests_per_day:.1f}",
                f"{analysis.metrics.total_size_gb:.2f}",
                signals_str,
                format_cost(analysis.monthly_cost),
                format_cost(analysis.potential_savings / 12),  # Monthly savings
                rec_str
            )

        console.print()
        console.print(table)
        console.print()

    def _display_summary(self, analyses: List[S3ActivityAnalysis]) -> None:
        """Display analysis summary statistics."""
        if not analyses:
            return

        total = len(analyses)
        decommission_count = sum(
            1 for a in analyses
            if a.recommendation == DecommissionRecommendation.DECOMMISSION
        )
        investigate_count = sum(
            1 for a in analyses
            if a.recommendation == DecommissionRecommendation.INVESTIGATE
        )
        optimize_count = sum(
            1 for a in analyses
            if a.recommendation == DecommissionRecommendation.OPTIMIZE
        )
        keep_count = sum(
            1 for a in analyses
            if a.recommendation == DecommissionRecommendation.KEEP
        )

        # Calculate totals
        total_cost = sum(a.annual_cost for a in analyses)
        total_savings = sum(a.potential_savings for a in analyses)

        # Create summary panel
        summary_text = (
            f"[bold]Total Buckets: {total}[/bold]\n"
            f"[bold green]Total Potential Savings: {format_cost(total_savings)}/year[/bold green]\n"
            f"[bold]Total Annual S3 Cost: {format_cost(total_cost)}[/bold]\n\n"
            f"Recommendations:\n"
            f"  [bright_red]Decommission: {decommission_count}[/bright_red]\n"
            f"  [bright_yellow]Investigate: {investigate_count}[/bright_yellow]\n"
            f"  [yellow]Optimize: {optimize_count}[/yellow]\n"
            f"  [bright_green]Keep: {keep_count}[/bright_green]\n\n"
            f"CloudWatch Queries: {self.query_count}"
        )

        summary = create_panel(
            summary_text,
            title="S3 Idle Detection Summary",
            border_style="green"
        )
        console.print(summary)
        console.print()

    def _get_from_cache(self, cache_key: str) -> Optional[S3ActivityAnalysis]:
        """Get analysis from cache if still valid."""
        if cache_key in self._cache:
            result, cache_time = self._cache[cache_key]
            if time.time() - cache_time < self.cache_ttl:
                return result
        return None

    def _add_to_cache(self, cache_key: str, analysis: S3ActivityAnalysis) -> None:
        """Add analysis to cache with current timestamp."""
        self._cache[cache_key] = (analysis, time.time())


# ═════════════════════════════════════════════════════════════════════════════
# FACTORY FUNCTION
# ═════════════════════════════════════════════════════════════════════════════


def create_s3_activity_enricher(
    operational_profile: Optional[str] = None,
    region: Optional[str] = None,
    lookback_days: int = 90
) -> S3ActivityEnricher:
    """
    Factory function to create S3ActivityEnricher.

    Provides clean initialization pattern following enterprise architecture
    with automatic profile resolution and sensible defaults.

    Args:
        operational_profile: AWS profile for operational account
        region: AWS region (default: ap-southeast-2)
        lookback_days: CloudWatch lookback period (default: 90)

    Returns:
        Initialized S3ActivityEnricher instance

    Example:
        >>> enricher = create_s3_activity_enricher()
        >>> # Enricher ready for activity analysis
        >>> analyses = enricher.analyze_bucket_activity(...)
    """
    return S3ActivityEnricher(
        operational_profile=operational_profile,
        region=region,
        lookback_days=lookback_days
    )


# ═════════════════════════════════════════════════════════════════════════════
# EXPORT INTERFACE
# ═════════════════════════════════════════════════════════════════════════════


__all__ = [
    # Core enricher class
    "S3ActivityEnricher",

    # Data models
    "S3ActivityAnalysis",
    "S3ActivityMetrics",
    "S3IdleSignal",
    "ActivityPattern",
    "DecommissionRecommendation",

    # Factory function
    "create_s3_activity_enricher",
]
