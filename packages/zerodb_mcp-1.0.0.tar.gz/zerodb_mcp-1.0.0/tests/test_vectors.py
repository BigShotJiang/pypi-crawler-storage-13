"""
Tests for Vector operations
"""

import pytest
from unittest.mock import MagicMock


class TestVectorOperations:
    """Test vector operations"""

    @pytest.mark.asyncio
    async def test_upsert_vector(self, client, mock_httpx_client, sample_project_id, sample_vector):
        """Test vector upsert"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "vector_id": "660e8400-e29b-41d4-a716-446655440001",
            "status": "success"
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.vectors.upsert(
            project_id=sample_project_id,
            **sample_vector
        )

        assert result["status"] == "success"
        assert "vector_id" in result

    @pytest.mark.asyncio
    async def test_upsert_vector_invalid_embedding(self, client, sample_project_id):
        """Test upsert with invalid embedding"""
        with pytest.raises(ValueError, match="Embedding"):
            await client.vectors.upsert(
                project_id=sample_project_id,
                embedding=[],  # Empty embedding
                document="test"
            )

    @pytest.mark.asyncio
    async def test_batch_upsert_vectors(self, client, mock_httpx_client, sample_project_id):
        """Test batch vector upsert"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total": 2,
            "successful": 2,
            "failed": 0
        }
        mock_httpx_client.post.return_value = mock_response

        vectors = [
            {"embedding": [0.1] * 1536, "document": "Doc 1", "metadata": {}},
            {"embedding": [0.2] * 1536, "document": "Doc 2", "metadata": {}}
        ]

        result = await client.vectors.batch_upsert(
            project_id=sample_project_id,
            vectors=vectors
        )

        assert result["total"] == 2
        assert result["successful"] == 2

    @pytest.mark.asyncio
    async def test_search_vectors(self, client, mock_httpx_client, sample_project_id, sample_search_results):
        """Test vector search"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = sample_search_results
        mock_httpx_client.post.return_value = mock_response

        results = await client.vectors.search(
            project_id=sample_project_id,
            query_vector=[0.1] * 1536,
            limit=10
        )

        assert len(results["results"]) == 2
        assert results["results"][0]["similarity"] == 0.95

    @pytest.mark.asyncio
    async def test_search_invalid_limit(self, client, sample_project_id):
        """Test search with invalid limit"""
        with pytest.raises(ValueError, match="Limit must be between"):
            await client.vectors.search(
                project_id=sample_project_id,
                query_vector=[0.1] * 1536,
                limit=2000  # Too high
            )

    @pytest.mark.asyncio
    async def test_delete_vector(self, client, mock_httpx_client, sample_project_id):
        """Test vector deletion"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success"}
        mock_httpx_client.post.return_value = mock_response

        result = await client.vectors.delete(
            project_id=sample_project_id,
            vector_id="660e8400-e29b-41d4-a716-446655440001"
        )

        assert result["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_vector(self, client, mock_httpx_client, sample_project_id):
        """Test get vector by ID"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "vector_id": "660e8400-e29b-41d4-a716-446655440001",
            "embedding": [0.1] * 1536,
            "document": "Test document",
            "metadata": {},
            "namespace": "default"
        }
        mock_httpx_client.post.return_value = mock_response

        vector = await client.vectors.get(
            project_id=sample_project_id,
            vector_id="660e8400-e29b-41d4-a716-446655440001"
        )

        assert vector["vector_id"] == "660e8400-e29b-41d4-a716-446655440001"
        assert len(vector["embedding"]) == 1536

    @pytest.mark.asyncio
    async def test_list_vectors(self, client, mock_httpx_client, sample_project_id):
        """Test list vectors with pagination"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "vectors": [],
            "total": 100,
            "limit": 50,
            "offset": 0
        }
        mock_httpx_client.post.return_value = mock_response

        result = await client.vectors.list(
            project_id=sample_project_id,
            limit=50,
            offset=0
        )

        assert result["total"] == 100
        assert result["limit"] == 50

    @pytest.mark.asyncio
    async def test_vector_stats(self, client, mock_httpx_client, sample_project_id):
        """Test vector statistics"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_vectors": 1000,
            "dimensions": 1536,
            "namespaces": ["default"],
            "storage_size_mb": 125.5
        }
        mock_httpx_client.post.return_value = mock_response

        stats = await client.vectors.stats(project_id=sample_project_id)

        assert stats["total_vectors"] == 1000
        assert stats["dimensions"] == 1536
