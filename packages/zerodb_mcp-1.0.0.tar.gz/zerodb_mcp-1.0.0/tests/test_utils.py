"""
Tests for utility functions
"""

import pytest
from zerodb_mcp.utils import (
    validate_uuid,
    validate_embedding,
    encode_file_content,
    decode_file_content,
    calculate_file_hash,
    sanitize_metadata,
    chunk_list,
    validate_tier,
)
from datetime import datetime
from uuid import UUID


class TestUtils:
    """Test utility functions"""

    def test_validate_uuid_valid(self):
        """Test UUID validation with valid UUID"""
        assert validate_uuid("550e8400-e29b-41d4-a716-446655440000") is True

    def test_validate_uuid_invalid(self):
        """Test UUID validation with invalid UUID"""
        assert validate_uuid("not-a-uuid") is False
        assert validate_uuid("") is False

    def test_validate_embedding_valid(self):
        """Test embedding validation with valid data"""
        validate_embedding([0.1, 0.2, 0.3] * 512)  # Should not raise

    def test_validate_embedding_empty(self):
        """Test embedding validation with empty list"""
        with pytest.raises(ValueError, match="cannot be empty"):
            validate_embedding([])

    def test_validate_embedding_too_large(self):
        """Test embedding validation with too many dimensions"""
        with pytest.raises(ValueError, match="exceeds maximum dimensions"):
            validate_embedding([0.1] * 5000)

    def test_validate_embedding_non_numeric(self):
        """Test embedding validation with non-numeric values"""
        with pytest.raises(ValueError, match="must be numbers"):
            validate_embedding([0.1, "not_a_number", 0.3])

    def test_encode_decode_file_content(self):
        """Test file content encoding and decoding"""
        original = b"Hello, World!"
        encoded = encode_file_content(original)
        decoded = decode_file_content(encoded)
        assert decoded == original

    def test_calculate_file_hash(self):
        """Test file hash calculation"""
        content = b"Test content"
        hash1 = calculate_file_hash(content)
        hash2 = calculate_file_hash(content)
        assert hash1 == hash2  # Same content = same hash
        assert len(hash1) == 64  # SHA256 hex length

    def test_sanitize_metadata(self):
        """Test metadata sanitization"""
        metadata = {
            "string": "value",
            "int": 42,
            "float": 3.14,
            "bool": True,
            "none": None,
            "datetime": datetime(2025, 1, 14, 12, 0, 0),
            "uuid": UUID("550e8400-e29b-41d4-a716-446655440000"),
            "list": [1, 2, "three"],
            "nested": {"key": "value"}
        }

        sanitized = sanitize_metadata(metadata)

        assert sanitized["string"] == "value"
        assert sanitized["int"] == 42
        assert sanitized["float"] == 3.14
        assert sanitized["bool"] is True
        assert sanitized["none"] is None
        assert isinstance(sanitized["datetime"], str)
        assert isinstance(sanitized["uuid"], str)
        assert sanitized["list"] == [1, 2, "three"]
        assert sanitized["nested"]["key"] == "value"

    def test_chunk_list(self):
        """Test list chunking"""
        items = list(range(10))
        chunks = chunk_list(items, chunk_size=3)

        assert len(chunks) == 4
        assert chunks[0] == [0, 1, 2]
        assert chunks[1] == [3, 4, 5]
        assert chunks[2] == [6, 7, 8]
        assert chunks[3] == [9]

    def test_validate_tier_valid(self):
        """Test tier validation with valid tiers"""
        validate_tier("free")  # Should not raise
        validate_tier("pro")
        validate_tier("enterprise")
        validate_tier("FREE")  # Case insensitive

    def test_validate_tier_invalid(self):
        """Test tier validation with invalid tier"""
        with pytest.raises(ValueError, match="Invalid tier"):
            validate_tier("invalid")
