"""
Pytest configuration and fixtures
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from zerodb_mcp import ZeroDBClient


@pytest.fixture
def mock_httpx_client():
    """Mock httpx AsyncClient"""
    mock_client = MagicMock()
    mock_client.post = AsyncMock()
    mock_client.get = AsyncMock()
    mock_client.aclose = AsyncMock()
    return mock_client


@pytest.fixture
def client(monkeypatch, mock_httpx_client):
    """Create test client with mocked HTTP client"""
    # Mock environment variable
    monkeypatch.setenv("ZERODB_API_KEY", "test_api_key")

    # Create client
    client = ZeroDBClient()

    # Replace HTTP client with mock
    client._client = mock_httpx_client

    return client


@pytest.fixture
def sample_project_id():
    """Sample project ID"""
    return "550e8400-e29b-41d4-a716-446655440000"


@pytest.fixture
def sample_vector():
    """Sample vector data"""
    return {
        "embedding": [0.1, 0.2, 0.3] * 512,  # 1536 dimensions
        "document": "Sample document about machine learning",
        "metadata": {"category": "AI", "language": "en"}
    }


@pytest.fixture
def sample_search_results():
    """Sample search results"""
    return {
        "results": [
            {
                "vector_id": "660e8400-e29b-41d4-a716-446655440001",
                "similarity": 0.95,
                "document": "Machine learning tutorial",
                "metadata": {"category": "AI"},
                "namespace": "default"
            },
            {
                "vector_id": "660e8400-e29b-41d4-a716-446655440002",
                "similarity": 0.85,
                "document": "Deep learning guide",
                "metadata": {"category": "AI"},
                "namespace": "default"
            }
        ],
        "total": 2
    }
