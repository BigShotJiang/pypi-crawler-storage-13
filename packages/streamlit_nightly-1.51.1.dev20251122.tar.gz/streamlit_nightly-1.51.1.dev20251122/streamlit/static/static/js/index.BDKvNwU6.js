import{F as c,ad as l,r as i,j as e,aM as d}from"./index.Dml8rEqP.js";import{P as p,R as f}from"./Particles.DhaHSQ17.js";const g=""+new URL("../media/flake-0.DgWaVvm5.png",import.meta.url).href,u=""+new URL("../media/flake-1.B2r5AHMK.png",import.meta.url).href,E=""+new URL("../media/flake-2.BnWSExPC.png",import.meta.url).href,o=150,s=150,S=10,x=90,M=4e3,a=(t,n=0)=>Math.random()*(t-n)+n,_=()=>l(`from{transform:translateY(0)
      rotateX(`,a(360),`deg)
      rotateY(`,a(360),`deg)
      rotateZ(`,a(360),"deg);}to{transform:translateY(calc(100vh + ",o,`px))
      rotateX(0)
      rotateY(0)
      rotateZ(0);}`),w=c("img",{target:"es7rdur0"})(({theme:t})=>({position:"fixed",top:`${-o}px`,marginLeft:`${-s/2}px`,zIndex:t.zIndices.balloons,left:`${a(x,S)}vw`,animationDelay:`${a(M)}ms`,height:`${o}px`,width:`${s}px`,pointerEvents:"none",animationDuration:"3000ms",animationName:_(),animationTimingFunction:"ease-in",animationDirection:"normal",animationIterationCount:1,opacity:1})),A=100,m=[g,u,E],I=m.length,h=i.memo(({particleType:t,resourceCrossOriginMode:n})=>{const r=m[t];return e(w,{src:r,crossOrigin:d(n,r)})}),F=function({scriptRunId:n}){return e(f,{children:e(p,{className:"stSnow","data-testid":"stSnow",scriptRunId:n,numParticleTypes:I,numParticles:A,ParticleComponent:h})})},L=i.memo(F);export{A as NUM_FLAKES,L as default};
