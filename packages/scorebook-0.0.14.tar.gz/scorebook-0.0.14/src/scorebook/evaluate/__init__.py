"""Evaluation module for Scorebook."""
