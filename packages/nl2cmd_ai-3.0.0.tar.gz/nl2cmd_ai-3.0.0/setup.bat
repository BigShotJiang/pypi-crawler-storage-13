@echo off
REM NL2CMD Setup Script for Windows

echo ================================================
echo    NL2CMD - Quick Setup Script
echo ================================================
echo.

echo [1/3] Installing Python dependencies...
pip install -r requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to install dependencies
    exit /b 1
)
echo.

echo [2/3] Training ML model...
python train_model.py
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to train model
    exit /b 1
)
echo.

echo [3/3] Testing installation...
python main.py "list all files"
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Test failed
    exit /b 1
)
echo.

echo ================================================
echo    Setup Complete!
echo ================================================
echo.
echo You can now use NL2CMD:
echo   - Single command: python main.py "your query"
echo   - REPL mode:      python main.py -i
echo   - Help:           python main.py -h
echo.
pause
