"""
Continuous Learning System
- Collects user feedback on command results
- Stores successful/failed queries
- Auto-retrains model with new data
- Improves accuracy over time
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path

class FeedbackCollector:
    """Collects and manages user feedback"""
    
    def __init__(self, feedback_file: str = 'user_feedback.json'):
        self.feedback_file = feedback_file
        self.feedback_data = self._load_feedback()
        self.session_queries = []
        
    def _load_feedback(self) -> Dict:
        """Load existing feedback"""
        if os.path.exists(self.feedback_file):
            try:
                with open(self.feedback_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            'successful': [],
            'failed': [],
            'corrections': [],
            'stats': {
                'total_queries': 0,
                'successful_rate': 0.0,
                'last_retrain': None
            }
        }
    
    def _save_feedback(self):
        """Save feedback to file"""
        with open(self.feedback_file, 'w', encoding='utf-8') as f:
            json.dump(self.feedback_data, f, indent=2)
    
    def record_query(self, query: str, command: str, method: str, confidence: float):
        """Record a query in current session"""
        self.session_queries.append({
            'query': query,
            'command': command,
            'method': method,
            'confidence': confidence,
            'timestamp': datetime.now().isoformat()
        })
    
    def mark_successful(self, query: str, command: str, intent: str = None):
        """Mark a command as successful"""
        entry = {
            'query': query,
            'command': command,
            'intent': intent or 'user_provided',
            'timestamp': datetime.now().isoformat(),
            'source': 'user_feedback'
        }
        
        self.feedback_data['successful'].append(entry)
        self.feedback_data['stats']['total_queries'] += 1
        self._update_success_rate()
        self._save_feedback()
        
        print("✓ Feedback recorded! This will help improve future predictions.")
    
    def mark_failed(self, query: str, suggested_command: str, reason: str = None):
        """Mark a command as failed/incorrect"""
        entry = {
            'query': query,
            'suggested_command': suggested_command,
            'reason': reason or 'incorrect_result',
            'timestamp': datetime.now().isoformat()
        }
        
        self.feedback_data['failed'].append(entry)
        self.feedback_data['stats']['total_queries'] += 1
        self._update_success_rate()
        self._save_feedback()
        
        print("✗ Feedback recorded. What was the correct command?")
    
    def add_correction(self, query: str, wrong_command: str, correct_command: str, intent: str = None):
        """Add a user correction"""
        entry = {
            'query': query,
            'wrong_command': wrong_command,
            'correct_command': correct_command,
            'intent': intent or 'user_correction',
            'timestamp': datetime.now().isoformat(),
            'source': 'user_correction'
        }
        
        self.feedback_data['corrections'].append(entry)
        
        # Also add to successful with correct command
        self.mark_successful(query, correct_command, intent)
        
        print(f"✓ Correction saved: '{query}' → {correct_command}")
    
    def _update_success_rate(self):
        """Calculate success rate"""
        total = self.feedback_data['stats']['total_queries']
        if total > 0:
            successful = len(self.feedback_data['successful'])
            self.feedback_data['stats']['successful_rate'] = (successful / total) * 100
    
    def get_new_training_data(self) -> List[Dict]:
        """Get new training examples from feedback"""
        new_data = []
        
        # Add successful queries
        for entry in self.feedback_data['successful']:
            new_data.append({
                'query': entry['query'],
                'command': entry['command'],
                'intent': entry['intent']
            })
        
        # Add corrections (with correct command)
        for entry in self.feedback_data['corrections']:
            new_data.append({
                'query': entry['query'],
                'command': entry['correct_command'],
                'intent': entry['intent']
            })
        
        return new_data
    
    def should_retrain(self, min_new_samples: int = 50) -> bool:
        """Check if we have enough new data to retrain"""
        new_data = len(self.get_new_training_data())
        return new_data >= min_new_samples
    
    def get_stats(self) -> Dict:
        """Get feedback statistics"""
        return {
            'total_queries': self.feedback_data['stats']['total_queries'],
            'successful': len(self.feedback_data['successful']),
            'failed': len(self.feedback_data['failed']),
            'corrections': len(self.feedback_data['corrections']),
            'success_rate': self.feedback_data['stats']['successful_rate'],
            'new_training_samples': len(self.get_new_training_data()),
            'ready_for_retrain': self.should_retrain()
        }


class AutoRetrainer:
    """Automatically retrain model with new feedback data"""
    
    def __init__(self, training_data_path: str = 'training_data_enhanced.json'):
        self.training_data_path = training_data_path
        self.feedback_collector = FeedbackCollector()
    
    def merge_feedback_into_training(self, os_type: str = 'windows') -> int:
        """Merge user feedback into training data"""
        # Load existing training data
        try:
            with open(self.training_data_path, 'r', encoding='utf-8') as f:
                training_data = json.load(f)
        except:
            training_data = {'windows': [], 'linux': []}
        
        # Get new samples from feedback
        new_samples = self.feedback_collector.get_new_training_data()
        
        if not new_samples:
            return 0
        
        # Add to appropriate OS section
        original_count = len(training_data.get(os_type, []))
        
        for sample in new_samples:
            # Avoid duplicates
            existing = any(
                item['query'].lower() == sample['query'].lower() 
                for item in training_data.get(os_type, [])
            )
            
            if not existing:
                training_data.setdefault(os_type, []).append(sample)
        
        new_count = len(training_data[os_type])
        added = new_count - original_count
        
        # Save updated training data
        with open(self.training_data_path, 'w', encoding='utf-8') as f:
            json.dump(training_data, f, indent=2)
        
        return added
    
    def retrain_model(self):
        """Trigger model retraining"""
        import subprocess
        import sys
        
        print("\n" + "="*70)
        print("🔄 AUTO-RETRAINING MODEL WITH NEW FEEDBACK DATA")
        print("="*70)
        
        try:
            # Run training script
            result = subprocess.run(
                [sys.executable, 'train_model.py'],
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            if result.returncode == 0:
                print("\n✓ Model retrained successfully!")
                print(result.stdout)
                
                # Update last retrain timestamp
                self.feedback_collector.feedback_data['stats']['last_retrain'] = datetime.now().isoformat()
                self.feedback_collector._save_feedback()
                
                return True
            else:
                print(f"\n✗ Retraining failed: {result.stderr}")
                return False
                
        except Exception as e:
            print(f"\n✗ Error during retraining: {e}")
            return False
    
    def auto_improve(self, os_type: str = 'windows', force: bool = False):
        """
        Automatically improve model if enough feedback collected
        
        Args:
            os_type: Operating system
            force: Force retrain even if not enough samples
        """
        stats = self.feedback_collector.get_stats()
        
        print("\n" + "="*70)
        print("📊 CONTINUOUS LEARNING STATUS")
        print("="*70)
        print(f"Total queries processed: {stats['total_queries']}")
        print(f"Successful: {stats['successful']}")
        print(f"Failed: {stats['failed']}")
        print(f"User corrections: {stats['corrections']}")
        print(f"Success rate: {stats['success_rate']:.1f}%")
        print(f"New training samples ready: {stats['new_training_samples']}")
        
        if stats['ready_for_retrain'] or force:
            print("\n✓ Sufficient data collected for retraining!")
            
            # Merge feedback
            added = self.merge_feedback_into_training(os_type)
            print(f"\n✓ Added {added} new training examples")
            
            # Retrain model
            if added > 0:
                response = input("\nRetrain model now? (yes/no): ").strip().lower()
                if response == 'yes':
                    return self.retrain_model()
        else:
            needed = 50 - stats['new_training_samples']
            print(f"\n⏳ Need {needed} more samples before auto-retraining")
            print("   Keep using the system and providing feedback!")
        
        return False


def test_feedback_system():
    """Test the feedback collection system"""
    print("="*70)
    print("CONTINUOUS LEARNING SYSTEM TEST")
    print("="*70)
    
    collector = FeedbackCollector()
    
    # Simulate some feedback
    print("\n1. Recording successful query...")
    collector.mark_successful(
        query="show me all running processes",
        command="tasklist",
        intent="list_processes"
    )
    
    print("\n2. Recording failed query...")
    collector.mark_failed(
        query="display network info",
        suggested_command="wrong_command",
        reason="incorrect suggestion"
    )
    
    print("\n3. Adding correction...")
    collector.add_correction(
        query="display network info",
        wrong_command="wrong_command",
        correct_command="ipconfig /all",
        intent="show_network_info"
    )
    
    # Show stats
    print("\n" + "="*70)
    print("📊 STATISTICS")
    print("="*70)
    stats = collector.get_stats()
    for key, value in stats.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    test_feedback_system()
