"""
Continuous Command Improvement System
- Tests various command categories
- Identifies gaps in coverage
- Adds new training examples
- Improves existing patterns
"""

import json
import os
from typing import List, Dict
from datetime import datetime

class CommandImprover:
    """Continuously improve command coverage"""
    
    def __init__(self, training_file='training_data_enhanced.json'):
        self.training_file = training_file
        self.data = self._load_data()
        
    def _load_data(self):
        """Load training data"""
        if os.path.exists(self.training_file):
            with open(self.training_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {'windows': [], 'linux': []}
    
    def _save_data(self):
        """Save training data"""
        with open(self.training_file, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2)
    
    def analyze_coverage(self):
        """Analyze current command coverage"""
        categories = {
            'file_operations': ['create', 'delete', 'copy', 'move', 'rename'],
            'folder_operations': ['create', 'delete', 'list', 'navigate'],
            'process_management': ['list', 'kill', 'start', 'priority'],
            'system_info': ['hardware', 'os', 'network', 'disk'],
            'network': ['ip', 'dns', 'ping', 'ports', 'connections'],
            'user_management': ['create', 'delete', 'permissions', 'groups'],
            'service_management': ['start', 'stop', 'restart', 'status'],
            'package_management': ['install', 'remove', 'update', 'list'],
            'search': ['files', 'text', 'processes'],
            'compression': ['zip', 'unzip', 'tar', 'extract'],
            'permissions': ['chmod', 'chown', 'acl'],
            'monitoring': ['cpu', 'memory', 'disk', 'network'],
            'logs': ['view', 'search', 'clear'],
            'security': ['firewall', 'antivirus', 'encryption'],
        }
        
        coverage = {}
        
        for category, operations in categories.items():
            coverage[category] = {
                'windows': 0,
                'linux': 0,
                'total': 0
            }
            
            for item in self.data['windows']:
                intent = item.get('intent', '').lower()
                if any(op in intent for op in operations):
                    coverage[category]['windows'] += 1
                    coverage[category]['total'] += 1
            
            for item in self.data['linux']:
                intent = item.get('intent', '').lower()
                if any(op in intent for op in operations):
                    coverage[category]['linux'] += 1
                    coverage[category]['total'] += 1
        
        return coverage
    
    def get_missing_commands(self):
        """Identify commonly needed but missing commands"""
        essential_commands = {
            'windows': [
                # File operations
                ('create empty file', 'type nul > file.txt', 'create_empty_file'),
                ('append to file', 'echo text >> file.txt', 'append_to_file'),
                ('find large files', 'forfiles /S /M * /C "cmd /c if @fsize GEQ 104857600 echo @path"', 'find_large_files'),
                ('count files in folder', 'dir /s /a-d | find /c ":"', 'count_files'),
                
                # System operations
                ('check windows version', 'ver', 'check_windows_version'),
                ('check system uptime', 'systeminfo | find "System Boot Time"', 'check_uptime'),
                ('view environment variables', 'set', 'view_environment_variables'),
                ('set environment variable', 'setx VAR value', 'set_environment_variable'),
                
                # Network operations
                ('flush dns cache', 'ipconfig /flushdns', 'flush_dns'),
                ('trace route to host', 'tracert google.com', 'trace_route'),
                ('test port connection', 'Test-NetConnection -Port 80 google.com', 'test_port'),
                ('show routing table', 'route print', 'show_routing_table'),
                
                # Process operations
                ('check process cpu usage', 'wmic process get name,processid,cpuusage', 'check_process_cpu'),
                ('set process priority', 'wmic process where name="app.exe" CALL setpriority "high priority"', 'set_process_priority'),
                
                # Disk operations
                ('check disk health', 'wmic diskdrive get status', 'check_disk_health'),
                ('format drive', 'format D: /FS:NTFS /Q', 'format_drive'),
                ('create partition', 'diskpart', 'create_partition'),
                
                # Service operations
                ('list all services', 'sc query type= service', 'list_services'),
                ('start service', 'net start ServiceName', 'start_service'),
                ('stop service', 'net stop ServiceName', 'stop_service'),
                
                # User operations
                ('list users', 'net user', 'list_users'),
                ('create user', 'net user username password /add', 'create_user'),
                ('add user to group', 'net localgroup Administrators username /add', 'add_user_to_group'),
                
                # Security
                ('check firewall status', 'netsh advfirewall show allprofiles', 'check_firewall'),
                ('open firewall port', 'netsh advfirewall firewall add rule name="Port" protocol=TCP dir=in localport=80 action=allow', 'open_firewall_port'),
                
                # Scheduled tasks
                ('list scheduled tasks', 'schtasks /query', 'list_scheduled_tasks'),
                ('create scheduled task', 'schtasks /create /tn TaskName /tr "command" /sc daily', 'create_scheduled_task'),
            ],
            'linux': [
                # File operations
                ('find files by extension', 'find . -name "*.txt"', 'find_files_by_extension'),
                ('find files modified today', 'find . -mtime 0', 'find_files_modified_today'),
                ('count lines in file', 'wc -l file.txt', 'count_lines'),
                ('split large file', 'split -b 100M largefile.bin part_', 'split_file'),
                
                # System operations
                ('check kernel version', 'uname -r', 'check_kernel_version'),
                ('check system load', 'uptime', 'check_system_load'),
                ('view system logs', 'journalctl -xe', 'view_system_logs'),
                ('check failed logins', 'lastb', 'check_failed_logins'),
                
                # Network operations
                ('show open ports', 'netstat -tulpn', 'show_open_ports'),
                ('trace route', 'traceroute google.com', 'trace_route'),
                ('test dns resolution', 'nslookup google.com', 'test_dns'),
                ('show network interfaces', 'ip link show', 'show_network_interfaces'),
                
                # Process operations
                ('show process tree', 'pstree', 'show_process_tree'),
                ('monitor process', 'watch -n 1 "ps aux | grep process"', 'monitor_process'),
                ('nice process', 'nice -n 10 command', 'nice_process'),
                
                # Disk operations
                ('check disk usage by directory', 'du -sh *', 'check_disk_usage_by_dir'),
                ('find largest directories', 'du -h / | sort -rh | head -10', 'find_largest_directories'),
                ('check inode usage', 'df -i', 'check_inode_usage'),
                
                # Service operations
                ('list running services', 'systemctl list-units --type=service --state=running', 'list_running_services'),
                ('enable service on boot', 'systemctl enable service', 'enable_service_boot'),
                ('check service logs', 'journalctl -u service', 'check_service_logs'),
                
                # User operations
                ('switch user', 'su - username', 'switch_user'),
                ('run as sudo', 'sudo command', 'run_as_sudo'),
                ('check user groups', 'groups username', 'check_user_groups'),
                
                # Package management
                ('update package list', 'sudo apt update', 'update_package_list'),
                ('upgrade all packages', 'sudo apt upgrade', 'upgrade_packages'),
                ('search for package', 'apt search package', 'search_package'),
                
                # Permissions
                ('change file permissions', 'chmod 755 file', 'change_permissions'),
                ('change file owner', 'chown user:group file', 'change_owner'),
                ('set sticky bit', 'chmod +t directory', 'set_sticky_bit'),
                
                # Compression
                ('create tar archive', 'tar -czf archive.tar.gz folder/', 'create_tar'),
                ('extract tar archive', 'tar -xzf archive.tar.gz', 'extract_tar'),
                ('zip folder', 'zip -r archive.zip folder/', 'zip_folder'),
            ]
        }
        
        missing = {'windows': [], 'linux': []}
        
        for os_type in ['windows', 'linux']:
            existing_intents = {item['intent'] for item in self.data[os_type]}
            
            for query, command, intent in essential_commands[os_type]:
                if intent not in existing_intents:
                    missing[os_type].append({
                        'query': query,
                        'command': command,
                        'intent': intent
                    })
        
        return missing
    
    def add_missing_commands(self):
        """Add missing essential commands"""
        missing = self.get_missing_commands()
        added = {'windows': 0, 'linux': 0}
        
        for os_type in ['windows', 'linux']:
            for cmd in missing[os_type]:
                self.data[os_type].append(cmd)
                added[os_type] += 1
        
        self._save_data()
        return added
    
    def generate_variations(self, base_queries: List[str]) -> List[str]:
        """Generate natural language variations"""
        variations = []
        
        prefixes = [
            '', 'how do i ', 'how can i ', 'how to ', 'i want to ', 
            'i need to ', 'please ', 'can you ', 'help me '
        ]
        
        suffixes = [
            '', ' please', ' now', ' quickly', ' on my computer',
            ' in windows', ' in linux', ' using command line'
        ]
        
        for query in base_queries:
            for prefix in prefixes[:3]:  # Limit variations
                for suffix in suffixes[:2]:
                    variant = f"{prefix}{query}{suffix}".strip()
                    if variant and variant not in variations:
                        variations.append(variant)
        
        return variations[:5]  # Return top 5 variations
    
    def test_command_coverage(self, test_queries: List[str]):
        """Test if queries have matching commands"""
        from fuzzy_matcher import FuzzyCommandMatcher
        
        matcher = FuzzyCommandMatcher()
        results = []
        
        for query in test_queries:
            result = matcher.smart_search(query, 'windows')
            
            results.append({
                'query': query,
                'found': result['best_match'] is not None,
                'confidence': result.get('confidence', 0),
                'method': result['best_match']['source'] if result['best_match'] else None,
                'command': result['best_match']['command'][:50] + '...' if result['best_match'] else None
            })
        
        return results


def main():
    """Run command improvement analysis"""
    improver = CommandImprover()
    
    print("="*70)
    print("COMMAND COVERAGE ANALYSIS")
    print("="*70)
    
    # Check current size
    win_count = len(improver.data['windows'])
    lin_count = len(improver.data['linux'])
    total = win_count + lin_count
    
    print(f"\nCurrent Training Data:")
    print(f"  Windows: {win_count} commands")
    print(f"  Linux: {lin_count} commands")
    print(f"  Total: {total} commands")
    
    # Analyze coverage
    print(f"\n{'='*70}")
    print("COVERAGE BY CATEGORY")
    print('='*70)
    
    coverage = improver.analyze_coverage()
    for category, counts in sorted(coverage.items()):
        print(f"{category:25} Windows: {counts['windows']:3}  Linux: {counts['linux']:3}  Total: {counts['total']:3}")
    
    # Find missing commands
    print(f"\n{'='*70}")
    print("MISSING ESSENTIAL COMMANDS")
    print('='*70)
    
    missing = improver.get_missing_commands()
    print(f"\nWindows: {len(missing['windows'])} missing commands")
    print(f"Linux: {len(missing['linux'])} missing commands")
    
    # Show samples
    if missing['windows']:
        print("\nSample Missing Windows Commands:")
        for cmd in missing['windows'][:5]:
            print(f"  - {cmd['query']}")
    
    if missing['linux']:
        print("\nSample Missing Linux Commands:")
        for cmd in missing['linux'][:5]:
            print(f"  - {cmd['query']}")
    
    # Add missing commands
    print(f"\n{'='*70}")
    response = input("Add missing commands to training data? (yes/no): ").strip().lower()
    
    if response == 'yes':
        added = improver.add_missing_commands()
        print(f"\n✓ Added {added['windows']} Windows commands")
        print(f"✓ Added {added['linux']} Linux commands")
        print(f"✓ Total added: {added['windows'] + added['linux']} commands")
        print(f"\nNew total: {len(improver.data['windows']) + len(improver.data['linux'])} commands")
        print("\n⚠️  Remember to retrain the model: python train_model.py")
    
    # Test common queries
    print(f"\n{'='*70}")
    print("TESTING COMMON QUERIES")
    print('='*70)
    
    test_queries = [
        "check disk health",
        "list all services",
        "flush dns cache",
        "find large files",
        "check system uptime",
        "show routing table",
        "set environment variable",
        "list scheduled tasks",
    ]
    
    print("\nTesting queries...")
    results = improver.test_command_coverage(test_queries)
    
    for r in results:
        status = "✓" if r['found'] else "✗"
        conf = f"{r['confidence']:.0f}%" if r['found'] else "N/A"
        print(f"{status} {r['query']:30} | {conf:5} | {r['method'] or 'NONE':20}")


if __name__ == "__main__":
    main()
