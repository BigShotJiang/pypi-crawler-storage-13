# Multi-Command Chaining Feature 🔗

## Overview

The Multi-Command Chaining feature allows you to execute multiple commands in a single natural language query. Instead of running commands one by one, you can chain them together using conjunctions like "and", "then", or "also".

---

## Quick Examples

```powershell
# Create folder and file
n2c "create a folder named project and create a file named readme.txt"

# List then show info
n2c "list all files and then show system information"

# Multiple operations
n2c "create folder test, create file notes.txt, list all files"

# Different verbs
n2c "delete old files then list remaining files"

# Mix operations
n2c "show running processes and kill chrome also list services"
```

---

## Supported Separators

The system recognizes these separators between commands:

| Separator | Example | Notes |
|-----------|---------|-------|
| `and` | "create X and create Y" | Most natural |
| `then` | "delete X then list Y" | Sequential |
| `and then` | "copy X and then verify Y" | Explicit sequence |
| `also` | "show X also show Y" | Additional action |
| `after that` | "backup X after that delete Y" | Clear ordering |
| `next` | "create X next create Y" | Next step |
| `,` (comma) | "list X, show Y, check Z" | Quick separation |
| `;` (semicolon) | "run X; run Y; run Z" | Command-style |

---

## How It Works

### 1. Detection
The system detects multi-commands by looking for:
- **2 or more action verbs** (create, list, show, delete, etc.)
- **At least one conjunction** (and, then, also, etc.)

### 2. Splitting
The query is split into individual commands using regex patterns:
```python
"create folder test and create file readme.txt"
→ ["create folder test", "create file readme.txt"]
```

### 3. Processing
Each command is processed individually through the intelligence engine:
- Template matching
- ML prediction
- Fuzzy search
- Problem diagnosis
- Rule-based matching

### 4. Chaining
Commands are combined with the `&&` operator:
```bash
mkdir test && echo. > readme.txt
```

On Windows, `&&` ensures the second command only runs if the first succeeds.

### 5. Execution
The chained command is executed as a single shell command, with all outputs combined.

---

## Output Format

When you run a multi-command query, you'll see:

```
🔗 Detected multi-command query. Processing each command...

Multi-Command Chain (2 commands)
============================================================
✓ Step 1: create a folder named project
   → mkdir project
   Method: template | Confidence: 95%

✓ Step 2: create a file named readme.txt
   → echo. > readme.txt
   Method: template | Confidence: 95%

Chained Command:
→ mkdir project && echo. > readme.txt

Do you want to execute this command chain? (y/n):
```

---

## Supported Action Verbs

The system recognizes these action verbs for detection:

- `create`, `make` - Create files/folders
- `delete`, `remove` - Remove files/folders
- `copy` - Copy files
- `move` - Move/rename files
- `list`, `show` - Display information
- `find` - Search operations
- `kill`, `stop` - Stop processes
- `start`, `run` - Start processes
- `open` - Open files/apps
- `close` - Close windows
- `install`, `update` - Package operations
- `rename`, `change` - Modify names/settings

---

## Real-World Use Cases

### 1. Project Setup
```powershell
n2c "create folder myapp and create file package.json and create folder src"
```

### 2. Cleanup and Verification
```powershell
n2c "delete temporary files then list remaining files"
```

### 3. System Diagnostics
```powershell
n2c "show memory usage and show disk space also show running processes"
```

### 4. Backup Operations
```powershell
n2c "copy important.txt to backup.txt then list all backups"
```

### 5. Process Management
```powershell
n2c "kill chrome and kill firefox then show running processes"
```

---

## Technical Details

### Files Modified/Created

1. **multi_command_processor.py** (NEW)
   - `MultiCommandProcessor` class
   - `is_multi_command()` - Detection logic
   - `split_commands()` - Query splitting
   - `process_multi_command()` - Main processor
   - `format_output()` - Pretty formatting

2. **command_processor.py** (MODIFIED)
   - Added multi-command detection
   - Integrated MultiCommandProcessor
   - Added formatted output display

3. **N2C_USAGE_GUIDE.md** (UPDATED)
   - Added multi-command documentation
   - Examples and use cases

### Implementation Details

```python
class MultiCommandProcessor:
    # Supported separators (in order of specificity)
    COMMAND_SEPARATORS = [
        r'\s+and\s+then\s+',  # "and then"
        r'\s+then\s+',         # "then"
        r'\s+and\s+',          # "and"
        r'\s+also\s+',         # "also"
        r'\s+after\s+that\s+', # "after that"
        r'\s+next\s+',         # "next"
        r'[,;]\s+',            # comma or semicolon
    ]
    
    # Detection: Count action verbs
    action_verbs = ['create', 'make', 'delete', 'remove', 'copy', 
                   'move', 'list', 'show', 'find', 'kill', ...]
    
    # Split using regex
    for separator in COMMAND_SEPARATORS:
        parts = re.split(separator, query, flags=re.IGNORECASE)
    
    # Process each part
    for cmd in parts:
        result = intelligence_engine.process_query(cmd)
    
    # Chain with &&
    chained = " && ".join(commands)
```

---

## Limitations

1. **Platform-specific**: Uses `&&` operator (works on Windows and Linux)
2. **Sequential only**: Commands run in order, one after another
3. **Error propagation**: If one command fails, subsequent commands may not execute
4. **No piping**: Use native commands for piping (e.g., `n2c "dir | findstr txt"`)
5. **Max complexity**: Best for 2-5 commands; very long chains may be hard to debug

---

## Safety Considerations

- **Risk assessment**: Each command's risk level is evaluated
- **Confirmation**: You must confirm before execution
- **Preview**: Always shows individual commands and chained result
- **Rollback**: Not automatic; use with caution for destructive operations

---

## Testing

### Test File: `test_multi.py`

Run tests with:
```powershell
python test_multi.py
```

### Test Cases

1. **Basic detection**
   ```python
   query = "create a folder named test and create a file named readme.txt"
   assert mp.is_multi_command(query) == True
   ```

2. **Command splitting**
   ```python
   parts = mp.split_commands(query)
   assert len(parts) == 2
   ```

3. **Full processing**
   ```python
   result = mp.process_multi_command(query)
   assert result['success'] == True
   assert result['command_count'] == 2
   ```

---

## Future Enhancements

Potential improvements for future versions:

1. **Parallel execution**: Run independent commands simultaneously
2. **Conditional execution**: "if X succeeds then Y"
3. **Variable substitution**: "create folder $name and cd $name"
4. **Output piping**: Automatic piping between commands
5. **Rollback support**: Undo chains if any command fails
6. **Smart dependencies**: Detect and reorder dependent commands

---

## Version History

- **v3.1 (Current)**: Initial multi-command chaining release
  - Basic detection and splitting
  - Sequential execution with `&&`
  - Pretty formatted output
  - Integrated into main command processor

---

## Troubleshooting

### Issue: Commands not detected as multi-command
**Solution**: Ensure you have:
- 2 or more action verbs (create, list, show, etc.)
- At least one conjunction (and, then, also, etc.)

### Issue: Commands split incorrectly
**Solution**: Use clearer separators:
- ❌ "create folder test create file readme"
- ✅ "create folder test and create file readme"

### Issue: Commands execute partially
**Solution**: Check individual commands first:
```powershell
n2c "create folder test"       # Test first command
n2c "create file readme.txt"   # Test second command
n2c "create folder test and create file readme.txt"  # Then chain
```

---

## API Reference

### `MultiCommandProcessor`

#### `__init__(intelligence_engine: Optional[IntelligenceEngine] = None)`
Initialize the processor with an optional intelligence engine.

#### `is_multi_command(query: str) -> bool`
Detect if a query contains multiple commands.

**Parameters:**
- `query`: Natural language query

**Returns:**
- `True` if query has 2+ action verbs and a conjunction

#### `split_commands(query: str) -> List[str]`
Split a query into individual command parts.

**Parameters:**
- `query`: Multi-command query

**Returns:**
- List of individual command strings

#### `process_multi_command(query: str) -> Dict`
Process a multi-command query end-to-end.

**Parameters:**
- `query`: Multi-command query

**Returns:**
- Dictionary with:
  - `success`: bool
  - `is_multi_command`: bool
  - `command_count`: int
  - `individual_commands`: List[Dict]
  - `chained_command`: str
  - `method`: str
  - `confidence`: float
  - `query`: str

#### `format_output(result: Dict) -> str`
Format the result into a pretty string for display.

**Parameters:**
- `result`: Result dictionary from `process_multi_command()`

**Returns:**
- Formatted string with command breakdown

---

## Examples Gallery

### File Management
```powershell
n2c "create folder docs and create folder src and create file README.md"
n2c "copy all txt files to backup then delete old txt files"
n2c "list all folders then show disk usage"
```

### Process Control
```powershell
n2c "show running processes and kill chrome"
n2c "stop service apache then start service nginx"
n2c "list services then show top CPU processes"
```

### System Administration
```powershell
n2c "check disk health and show memory usage also list large files"
n2c "flush dns cache then restart network adapter"
n2c "show system info and check windows updates"
```

### Development Workflow
```powershell
n2c "create folder myproject and create file index.html and create file style.css"
n2c "list git branches then show git status"
n2c "run tests and show coverage also check for errors"
```

---

## Summary

The Multi-Command Chaining feature brings powerful automation to NL2CMD by allowing you to:
- ✅ Execute multiple commands in one query
- ✅ Use natural language conjunctions
- ✅ See detailed breakdowns before execution
- ✅ Chain commands safely with error handling
- ✅ Save time with common multi-step workflows

Try it now:
```powershell
n2c "create a folder named tanish and create a file named smth.txt"
```

Happy commanding! 🚀
