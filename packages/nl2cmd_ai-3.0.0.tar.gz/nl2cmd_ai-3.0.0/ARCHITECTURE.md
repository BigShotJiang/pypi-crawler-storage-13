# NL2CMD ARCHITECTURE

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                              USER                                    │
│                    (Natural Language Query)                          │
└───────────────────────────┬─────────────────────────────────────────┘
                            │
                            ↓
┌─────────────────────────────────────────────────────────────────────┐
│                     MAIN.PY (Entry Point)                            │
│  • Argument parsing                                                  │
│  • REPL mode handling                                                │
│  • OS detection                                                      │
└───────────────────────────┬─────────────────────────────────────────┘
                            │
                            ↓
┌─────────────────────────────────────────────────────────────────────┐
│              COMMAND_PROCESSOR.PY (Orchestrator)                     │
│  • Calls intelligence engine                                         │
│  • Handles execution                                                 │
│  • Manages clipboard operations                                      │
└───────────────────────────┬─────────────────────────────────────────┘
                            │
                            ↓
┌─────────────────────────────────────────────────────────────────────┐
│         ① INPUT_PROCESSOR.PY (Input Processing)                     │
│  ┌─────────────────────────────────────────────────────┐            │
│  │ • Text normalization (lowercase, remove special)    │            │
│  │ • Keyword extraction (remove stop words)            │            │
│  │ • Categorization (actions, targets, modifiers)      │            │
│  │ • Parameter extraction (URLs, IPs, filenames)       │            │
│  └─────────────────────────────────────────────────────┘            │
└───────────────────────────┬─────────────────────────────────────────┘
                            │
                            ↓
┌─────────────────────────────────────────────────────────────────────┐
│         INTELLIGENCE_ENGINE.PY (Hybrid Decision Maker)               │
│                                                                       │
│  ┌───────────────────────────────────────────────────────────┐      │
│  │  Strategy: Try ML first, fallback to Rules               │      │
│  └───────────────────────────────────────────────────────────┘      │
│                                                                       │
│  ┌──────────────────────────┐  ┌──────────────────────────┐         │
│  │   ②A ML_PREDICTOR.PY     │  │  ②B RULE_MATCHER         │         │
│  │  ┌─────────────────────┐ │  │  ┌─────────────────────┐ │         │
│  │  │ • Load model.pkl    │ │  │  │ • windows_cmd.py    │ │         │
│  │  │ • TF-IDF vectorize  │ │  │  │ • linux_cmd.py      │ │         │
│  │  │ • Random Forest     │ │  │  │ • Keyword matching  │ │         │
│  │  │ • Confidence score  │ │  │  │ • Template lookup   │ │         │
│  │  └─────────────────────┘ │  │  └─────────────────────┘ │         │
│  │                          │  │                          │         │
│  │  Confidence ≥ 60%? ──┐   │  │  Fallback when ML       │         │
│  │  Yes → Use ML result │   │  │  confidence < 60%       │         │
│  │  No → Fallback ──────┼───┼─→│  or ML not available    │         │
│  └──────────────────────┘   │  └──────────────────────────┘         │
│                              │                                        │
│  Decision Logic:             │                                        │
│  1. Try ML prediction        │                                        │
│  2. If confidence ≥ 60% → use ML                                     │
│  3. Otherwise → try Rule Matcher                                     │
│  4. If rule found → use rule (100% confidence)                       │
│  5. Last resort → use low-confidence ML with warning                 │
└───────────────────────────┬─────────────────────────────────────────┘
                            │
                            ↓
┌─────────────────────────────────────────────────────────────────────┐
│              ③ SAFETY.PY (Safety Validator)                          │
│  ┌─────────────────────────────────────────────────────┐            │
│  │ • Detect risky keywords (del, rm, shutdown, etc.)   │            │
│  │ • Require explicit "yes" confirmation               │            │
│  │ • Warn user about dangerous operations              │            │
│  └─────────────────────────────────────────────────────┘            │
└───────────────────────────┬─────────────────────────────────────────┘
                            │
                            ↓
┌─────────────────────────────────────────────────────────────────────┐
│           ④ OUTPUT_HANDLER.PY (Formatted Display)                    │
│  ┌─────────────────────────────────────────────────────┐            │
│  │ • Color-coded output (green/yellow/red)             │            │
│  │ • Method badges (🤖 ML / 📋 RULE)                   │            │
│  │ • Confidence percentage display                     │            │
│  │ • Warning messages for low confidence               │            │
│  └─────────────────────────────────────────────────────┘            │
└───────────────────────────┬─────────────────────────────────────────┘
                            │
                            ↓
┌─────────────────────────────────────────────────────────────────────┐
│                         USER OUTPUT                                  │
│  ════════════════════════════════════════                            │
│  Query: 'list all files'                                             │
│  Method: 🤖 ML (78% confidence)                                      │
│  ✓ Command: dir                                                      │
│  ────────────────────────────────────────                            │
└─────────────────────────────────────────────────────────────────────┘

## Data Stores

┌─────────────────────────────────────┐
│   TRAINING_DATA.JSON                │
│   • 205 examples (Windows + Linux)  │
│   • Query → Command → Intent        │
└────────────┬────────────────────────┘
             │
             ↓
┌─────────────────────────────────────┐
│   TRAIN_MODEL.PY                    │
│   • TF-IDF vectorization            │
│   • Random Forest training          │
│   • 80/20 train/test split          │
└────────────┬────────────────────────┘
             │
             ↓
┌─────────────────────────────────────┐
│   ML MODEL FILES (Generated)        │
│   • nl2cmd_model.pkl                │
│   • tfidf_vectorizer.pkl            │
│   • intent_to_command.pkl           │
└─────────────────────────────────────┘

## Flow Example: "list all files"

1. User enters: "list all files"
2. INPUT_PROCESSOR normalizes → "list all files"
3. Keywords extracted → ["list", "all", "files"]
4. INTELLIGENCE_ENGINE calls ML_PREDICTOR
5. ML vectorizes with TF-IDF → [0.3, 0.5, 0.7, ...]
6. Random Forest predicts → intent: "list_files", confidence: 78%
7. Confidence 78% ≥ 60% → Use ML result
8. Command lookup → "dir" (Windows) or "ls" (Linux)
9. SAFETY checks → "dir" is safe
10. OUTPUT_HANDLER displays:
    "🤖 ML (78% confidence) → dir"
11. User confirms → Executes → Shows output

## Components Mapping to DFD

DFD Component           →  Implementation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
(1) Input Processor     →  input_processor.py
(2A) ML Predictor       →  ml_predictor.py
(2B) Rule Matcher       →  windows_cmd.py, linux_cmd.py
(3) Safety Validator    →  safety.py
(4) Output Handler      →  output_handler.py
Intelligence Engine     →  intelligence_engine.py
Main System             →  main.py
Command Executor        →  command_processor.py

## Key Features

✓ Hybrid ML + Rule approach for robustness
✓ Confidence-based automatic fallback
✓ Cross-platform (Windows/Linux)
✓ Safety validation for risky commands
✓ Color-coded user-friendly output
✓ Extensible training data
✓ REPL and single-command modes
✓ 75.61% ML accuracy (grows with more data)
