# N2C Command-Line Usage Guide

## ✅ Installation Complete!

The `n2c` command is now installed and ready to use from anywhere in your terminal!

---

## 🚀 Quick Start

### Basic Usage
```powershell
# Single command
n2c "list all files"
n2c "show system information"
n2c "check disk health"
n2c "find large files"
```

### Interactive REPL Mode
```powershell
# Start interactive mode
n2c -i

# Then type natural language queries:
n2c> list all services
n2c> create folder myproject
n2c> kill process chrome
n2c> exit
```

---

## 📋 All Available Options

### Command Modes
```powershell
n2c "your query"           # Single command mode (default)
n2c -i                     # Interactive REPL mode
n2c --help                 # Show help message
n2c --version              # Show version number
```

### Training & Learning
```powershell
n2c --train                # Train/retrain the ML model
n2c --feedback             # View learning statistics
n2c --retrain              # Retrain with user feedback
```

---

## 💡 Usage Examples

### File Operations
```powershell
n2c "list all files"
n2c "find files larger than 100MB"
n2c "create file test.txt"
n2c "delete file oldfile.txt"
n2c "copy file source.txt to backup.txt"
```

### Folder Operations
```powershell
n2c "create folder myproject"
n2c "list folders recursively"
n2c "delete empty folders"
n2c "show folder size"
```

### Process Management
```powershell
n2c "list all processes"
n2c "kill process chrome"
n2c "find process using port 8080"
n2c "show top CPU processes"
```

### System Information
```powershell
n2c "show system information"
n2c "check disk health"
n2c "show memory usage"
n2c "show CPU info"
n2c "show system uptime"
```

### Network Commands
```powershell
n2c "show IP address"
n2c "flush dns cache"
n2c "show network connections"
n2c "ping google.com"
n2c "show routing table"
n2c "check firewall status"
```

### Service Management
```powershell
n2c "list all services"
n2c "start service Apache"
n2c "stop service MySQL"
n2c "check service status"
```

### Windows Updates & Maintenance
```powershell
n2c "show windows updates"
n2c "check for windows updates"
n2c "show scheduled tasks"
n2c "defragment drive C"
```

### Advanced Features

#### Multi-Command Chaining 🔗 (NEW!)
Execute multiple commands in a single query using conjunctions like "and", "then", "also":

```powershell
# Create folder and file in one command
n2c "create a folder named project and create a file named readme.txt"

# List files then show system info
n2c "list all files and then show system information"

# Multiple operations
n2c "create folder test, also create file notes.txt, then list all files"
```

**Supported Separators:**
- `and` - Most common: "do X and do Y"
- `then` / `and then` - Sequential: "do X then do Y"
- `also` - Additional: "do X also do Y"
- `after that` - Explicit ordering: "do X after that do Y"
- `next` - Next step: "do X next do Y"
- `,` / `;` - Comma/semicolon separation

**How it works:**
1. Detects multiple action verbs (create, list, show, etc.)
2. Splits query into individual commands
3. Processes each command separately
4. Chains them with `&&` operator
5. Shows breakdown before execution

**Example Output:**
```
Multi-Command Chain (2 commands)
============================================================
✓ Step 1: create a folder named project
   → mkdir project
   Method: template | Confidence: 95%

✓ Step 2: create a file named readme.txt
   → echo. > readme.txt
   Method: template | Confidence: 95%

Chained Command:
→ mkdir project && echo. > readme.txt
```

#### Typo Tolerance (Fuzzy Search)
```powershell
n2c "lsit all fles"           # Still finds "list all files"
n2c "shwo systm info"         # Still finds "show system info"
```

#### Problem Diagnosis
```powershell
n2c "internet stopped working"     # Suggests network diagnostic commands
n2c "computer is slow"             # Suggests performance analysis
n2c "system files corrupted"       # Suggests system repair
```

#### Dynamic Parameters
```powershell
n2c "create folder MyProject"      # Extracts "MyProject" as folder name
n2c "kill process notepad"         # Extracts "notepad" as process name
n2c "create file report.txt"       # Extracts "report.txt" as filename
```

---

## 🎮 Interactive REPL Features

When in REPL mode (`n2c -i`), you get additional commands:

```powershell
n2c> help           # Show available commands
n2c> good           # Mark last result as good (for learning)
n2c> bad            # Mark last result as bad (for learning)
n2c> stats          # Show learning statistics
n2c> exit           # Exit REPL mode
n2c> quit           # Exit REPL mode
```

### REPL Example Session
```powershell
PS> n2c -i

n2c> list all running services
✓ Command: sc query type= service state= running
Do you want to execute this command? (y/n): y
[Command executes...]

n2c> good
✓ Feedback recorded: positive

n2c> create folder test123
✓ Command: mkdir test123
Do you want to execute this command? (y/n): y
[Creates folder...]

n2c> stats
Learning Statistics:
  Total feedback: 1
  Positive: 1
  Negative: 0

n2c> exit
```

---

## 🔧 Configuration Files

The following files are used (located in NL2CMD directory):

- `nl2cmd_model.pkl` - Trained ML model
- `tfidf_vectorizer.pkl` - TF-IDF vectorizer
- `intent_to_command.pkl` - Intent mapping
- `training_data_enhanced.json` - Training dataset (2,071 commands)
- `user_feedback.json` - Your feedback for continuous learning

---

## ⚙️ Advanced Options

### Training the Model
```powershell
# Retrain from scratch
n2c --train

# Retrain with user feedback
n2c --retrain

# View learning progress
n2c --feedback
```

### Command Execution Options
When n2c suggests a command, you have choices:
1. **Execute**: `y` - Runs the command immediately
2. **Skip**: `n` - Shows command but doesn't run it
3. **Copy**: `y` - Copies command to clipboard for manual editing

---

## 🛡️ Safety Features

NL2CMD includes built-in safety warnings for risky commands:

- **CRITICAL**: Commands that could cause data loss
- **HIGH**: Commands that modify system settings
- **MEDIUM**: Commands that require admin privileges
- **LOW**: Commands that view sensitive information

Example:
```powershell
n2c "format drive D"

⚠️  RISK LEVEL: CRITICAL
Risk: 'format' - Irreversible data destruction
Alternative: Backup all data before formatting

Proceed? (yes/no):
```

---

## 📊 Current Capabilities

### Dataset Size
- **Total Commands**: 2,071
- **Windows Commands**: 601
- **Linux Commands**: 1,470
- **Unique Intents**: 236

### Intelligence Methods
1. **Template Engine** (95% confidence) - Dynamic parameters
2. **ML Predictor** (60-100% confidence) - Machine learning
3. **Problem Diagnosis** (90% confidence) - Error-to-solution mapping
4. **Fuzzy Search** (60-100% confidence) - Typo tolerance
5. **Rule-Based** (100% confidence) - Pattern matching

### Supported Categories
✅ File operations
✅ Folder operations  
✅ Process management
✅ System information
✅ Network operations
✅ Service management
✅ User management
✅ Disk operations
✅ Search operations
✅ Compression/Archive
✅ Log viewing
✅ Package management
✅ Security & firewall
✅ Scheduled tasks

---

## 🆘 Troubleshooting

### Command not found
```powershell
# Reinstall the package
cd C:\Users\aicht\Downloads\NL2CMD
pip install -e .
```

### Model not loaded
```powershell
# Retrain the model
n2c --train
```

### Low accuracy
```powershell
# View and contribute feedback
n2c --feedback
n2c --retrain
```

---

## 🚀 Pro Tips

1. **Use Quotes**: Always wrap your query in quotes
   ```powershell
   n2c "list all files"     # ✅ Good
   n2c list all files       # ❌ Won't work
   ```

2. **Be Specific**: More specific queries get better results
   ```powershell
   n2c "show system info"              # Good
   n2c "show detailed system hardware" # Better
   ```

3. **Use REPL for Multiple Commands**: Interactive mode is faster
   ```powershell
   n2c -i    # Then run multiple queries
   ```

4. **Provide Feedback**: Help the system learn
   ```powershell
   # After each command, mark it as good/bad
   n2c> good
   n2c> bad
   ```

5. **Check Help First**: See all examples
   ```powershell
   n2c --help
   ```

---

## 📞 Quick Reference

| What you want | Command |
|---------------|---------|
| Single command | `n2c "your query"` |
| Interactive mode | `n2c -i` |
| Show help | `n2c --help` |
| Train model | `n2c --train` |
| View feedback | `n2c --feedback` |
| Exit REPL | `exit` or `quit` |
| Mark as good | `good` (in REPL) |
| Mark as bad | `bad` (in REPL) |
| View stats | `stats` (in REPL) |

---

## ✅ You're All Set!

The `n2c` command is now available system-wide. Just type:

```powershell
n2c "your natural language query"
```

And let NL2CMD do the rest! 🎉

---

**Need more commands?** The dataset is continuously expanding from 2,071 toward 18,000 commands!

**Found an issue?** Use the feedback system to help improve accuracy!
