#!/bin/bash
# NL2CMD Setup Script for Linux/macOS

echo "================================================"
echo "   NL2CMD - Quick Setup Script"
echo "================================================"
echo

echo "[1/3] Installing Python dependencies..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi
echo

echo "[2/3] Training ML model..."
python train_model.py
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to train model"
    exit 1
fi
echo

echo "[3/3] Testing installation..."
python main.py "list all files"
if [ $? -ne 0 ]; then
    echo "ERROR: Test failed"
    exit 1
fi
echo

echo "================================================"
echo "   Setup Complete!"
echo "================================================"
echo
echo "You can now use NL2CMD:"
echo "  - Single command: python main.py \"your query\""
echo "  - REPL mode:      python main.py -i"
echo "  - Help:           python main.py -h"
echo
