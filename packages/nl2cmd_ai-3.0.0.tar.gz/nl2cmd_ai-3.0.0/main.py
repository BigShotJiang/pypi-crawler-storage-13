#!/usr/bin/env python3
"""
NL2CMD - Natural Language to Command Line Interface
Main entry point with continuous learning support
"""

from command_processor import process_command
import argparse
import platform
import sys

# Try to import continuous learning
try:
    from continuous_learner import FeedbackCollector, AutoRetrainer
    LEARNING_AVAILABLE = True
except ImportError:
    LEARNING_AVAILABLE = False

def print_banner():
    """Print application banner"""
    banner = """
╔═══════════════════════════════════════════════════════════╗
║              NL2CMD - Natural Language to CLI             ║
║                   Hybrid ML + Rule Engine                 ║
╚═══════════════════════════════════════════════════════════╝
"""
    print(banner)

def main():
    """Main application entry point"""
    parser = argparse.ArgumentParser(
        description="Natural language to command line interface converter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  nl2cmd "list all files"
  nl2cmd "show system information" 
  nl2cmd -i                          # Start REPL mode
  nl2cmd --train                     # Train ML model
        """
    )
    
    parser.add_argument(
        "nl_cmd", 
        nargs="?", 
        type=str, 
        help="Natural language command to convert to CLI command"
    )
    
    parser.add_argument(
        "-i", "--repl", 
        action="store_true", 
        help="Start in interactive REPL mode"
    )
    
    parser.add_argument(
        "--train",
        action="store_true",
        help="Train the ML model from training data"
    )
    
    parser.add_argument(
        "--version",
        action="version",
        version="NL2CMD v3.0 (Advanced ML + Fuzzy Search + Continuous Learning)"
    )
    
    parser.add_argument(
        "--feedback",
        action="store_true",
        help="View feedback statistics and learning progress"
    )
    
    parser.add_argument(
        "--retrain",
        action="store_true",
        help="Retrain model with user feedback"
    )

    args = parser.parse_args()
    
    # Handle feedback statistics
    if args.feedback:
        if LEARNING_AVAILABLE:
            collector = FeedbackCollector()
            stats = collector.get_stats()
            
            print("\n" + "="*70)
            print("📊 FEEDBACK & LEARNING STATISTICS")
            print("="*70)
            print(f"Total queries processed: {stats['total_queries']}")
            print(f"Successful commands: {stats['successful']}")
            print(f"Failed commands: {stats['failed']}")
            print(f"User corrections: {stats['corrections']}")
            print(f"Success rate: {stats['success_rate']:.1f}%")
            print(f"New training samples ready: {stats['new_training_samples']}")
            print(f"Ready for retraining: {'✓ Yes' if stats['ready_for_retrain'] else '✗ No (need more samples)'}")
            print("="*70)
        else:
            print("❌ Continuous learning module not available")
        return
    
    # Handle retraining
    if args.retrain:
        if LEARNING_AVAILABLE:
            retrainer = AutoRetrainer()
            retrainer.auto_improve(force=True)
        else:
            print("❌ Continuous learning module not available")
        return
    
    # Handle training mode
    if args.train:
        print("Training ML model...")
        try:
            import train_model
            train_model.main()
        except Exception as e:
            print(f"Error during training: {e}")
            sys.exit(1)
        return
    
    # Print banner
    print_banner()
    
    # Detect OS
    os_name = platform.system()
    print(f"Detected OS: {os_name}")
    print(f"Mode: {'REPL' if args.repl else 'Single Command'}\n")
    
    # REPL mode
    if args.repl:
        print("Starting REPL mode...")
        print("Commands:")
        print("  - 'exit' or 'quit' to exit")
        print("  - 'help' for assistance")
        if LEARNING_AVAILABLE:
            print("  - 'good' to mark last result as successful")
            print("  - 'bad' to mark last result as failed")
            print("  - 'stats' to view learning statistics")
        print()
        
        # Initialize feedback collector
        feedback = FeedbackCollector() if LEARNING_AVAILABLE else None
        last_query = None
        last_command = None
        
        while True:
            try:
                user_input = input("n2c> ").strip()
                
                if not user_input:
                    continue
                
                if user_input.lower() in ("exit", "quit"):
                    print("\n👋 Exiting REPL mode. Goodbye!")
                    break
                
                if user_input.lower() == "help":
                    print_help()
                    continue
                
                # Feedback commands
                if LEARNING_AVAILABLE and feedback:
                    if user_input.lower() == "good" and last_command:
                        feedback.mark_successful(last_query, last_command)
                        continue
                    
                    if user_input.lower() == "bad" and last_command:
                        feedback.mark_failed(last_query, last_command)
                        correct = input("What was the correct command? ").strip()
                        if correct:
                            feedback.add_correction(last_query, last_command, correct)
                        continue
                    
                    if user_input.lower() == "stats":
                        stats = feedback.get_stats()
                        print(f"\n📊 Success rate: {stats['success_rate']:.1f}%")
                        print(f"   New samples: {stats['new_training_samples']}")
                        print(f"   Ready for retrain: {stats['ready_for_retrain']}\n")
                        continue
                
                # Process command
                print()  # Blank line for readability
                result = process_command(user_input)
                print()  # Blank line after output
                
                # Store for feedback
                last_query = user_input
                last_command = result.get('command') if isinstance(result, dict) else None
                
            except KeyboardInterrupt:
                print("\n\n👋 Interrupted. Exiting REPL mode.")
                break
            except EOFError:
                print("\n\n👋 EOF received. Exiting REPL mode.")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}\n")
    
    # Single command mode
    else:
        if not args.nl_cmd:
            print("❌ No command provided. Use -h for help or -i for REPL mode.")
            return
        
        print(f"Processing: '{args.nl_cmd}'\n")
        process_command(args.nl_cmd)

def print_help():
    """Print help message in REPL"""
    help_text = """
╔═══════════════════════════════════════════════════════════╗
║                       NL2CMD HELP                         ║
╠═══════════════════════════════════════════════════════════╣
║ Commands:                                                 ║
║   exit, quit  - Exit REPL mode                           ║
║   help        - Show this help message                   ║
║                                                           ║
║ Examples:                                                 ║
║   list all files                                         ║
║   show system information                                ║
║   kill chrome                                            ║
║   get my IP address                                      ║
║   clean temporary files                                  ║
║   shutdown computer                                      ║
╚═══════════════════════════════════════════════════════════╝
"""
    print(help_text)
    
    



if __name__ == "__main__":
    main()
    

