# NL2CMD v3.0 - Dynamic Parameter Extraction Feature

## 🎯 New Feature: Dynamic Command Generation

Your NL2CMD now supports **dynamic parameter extraction** - you can specify custom names, paths, and values directly in your natural language queries!

---

## ✨ What's New

### Before (v2.0):
```bash
nl2cmd "create a file"
# → Always creates generic command: echo. > file.txt
```

### Now (v3.0):
```bash
nl2cmd "create a file named myconfig.json"
# → Extracts "myconfig.json" and generates: echo. > myconfig.json

nl2cmd "create folder ProjectDocs with file readme.md inside"
# → Creates nested structure: mkdir ProjectDocs && echo. > ProjectDocs\readme.md

nl2cmd "kill process firefox"  
# → Extracts "firefox" and generates: taskkill /IM firefox.exe /F
```

---

## 🚀 Usage Examples

### 1. File Operations

**Create files with custom names:**
```bash
nl2cmd "create a file named config.json"
→ echo. > config.json

nl2cmd "create a file called notes.txt"
→ echo. > notes.txt

nl2cmd "make a file named data.csv"
→ type nul > data.csv
```

**Create files with content:**
```bash
nl2cmd "create a file named hello.txt with content 'Hello World'"
→ echo Hello World > hello.txt
```

### 2. Folder Operations

**Create folders with custom names:**
```bash
nl2cmd "create a folder named Documents"
→ mkdir Documents

nl2cmd "make a directory called ProjectFiles"
→ mkdir ProjectFiles

nl2cmd "create folder MyData"
→ md MyData
```

### 3. Nested Operations

**Create folder with file inside:**
```bash
nl2cmd "create folder Settings with file config.json inside"
→ mkdir Settings && echo. > Settings\config.json

nl2cmd "make directory Docs and file readme.md inside it"
→ mkdir Docs && echo. > Docs\readme.md

nl2cmd "create file app.py in folder src"
→ mkdir src && echo. > src\app.py
```

### 4. Process Management

**Kill processes by name:**
```bash
nl2cmd "kill process chrome"
→ taskkill /IM chrome.exe /F

nl2cmd "stop firefox"
→ taskkill /IM firefox.exe /F

nl2cmd "terminate notepad"
→ taskkill /IM notepad.exe /F
```

### 5. File Management

**Delete specific files:**
```bash
nl2cmd "delete file old_data.txt"
→ del old_data.txt

nl2cmd "remove file temp.log"
→ del temp.log
```

**Rename files:**
```bash
nl2cmd "rename file old.txt to new.txt"
→ ren old.txt new.txt
```

**Copy files:**
```bash
nl2cmd "copy file source.txt to backup.txt"
→ copy source.txt backup.txt
```

---

## 🎨 Supported Parameters

### File Names
- Detects: `.txt`, `.json`, `.py`, `.csv`, `.log`, etc.
- Quoted: `"my file.txt"` 
- Unquoted: `config.json`
- Patterns: `file named X`, `file called X`, `create X file`

### Folder Names
- Quoted: `"My Folder"`
- Unquoted: `ProjectDocs`
- Patterns: `folder named X`, `directory called X`, `create X folder`

### Process Names
- Any process: `chrome`, `firefox`, `notepad`, `excel`
- Patterns: `kill X`, `stop process X`, `terminate X`

### File Extensions
- `.py`, `.txt`, `.json`, `.csv`, `.log`, `.md`, etc.
- Patterns: `files with .py extension`, `.txt files`

### Content
- Quoted text: `"Hello World"`
- Patterns: `with content X`, `containing X`

### Paths
- Windows: `C:\Users\...`, `D:\Data\...`
- Linux: `/home/...`, `~/...`
- Patterns: `in path X`, `at location X`

---

## 🧠 How It Works

### 1. Parameter Extraction
```
Query: "create a file named test.txt"
         ↓
Extracted Parameters:
  - Intent: create
  - Target: file  
  - Filename: test.txt
```

### 2. Template Selection
```
Intent: create + Target: file
         ↓
Selected Template: "echo. > {filename}"
```

### 3. Command Generation
```
Template: "echo. > {filename}"
Parameters: filename=test.txt
         ↓
Generated Command: "echo. > test.txt"
```

---

## 📋 Template Patterns

### Windows Commands

**File Creation:**
- `echo. > {filename}`
- `type nul > {filename}`
- `echo {content} > {filename}`

**Folder Creation:**
- `mkdir {foldername}`
- `md {foldername}`

**Nested Creation:**
- `mkdir {foldername} && echo. > {foldername}\{filename}`

**File Operations:**
- `del {filename}` - Delete
- `ren {old} {new}` - Rename
- `copy {source} {dest}` - Copy

**Process Management:**
- `taskkill /IM {process}.exe /F` - Kill process

### Linux Commands

**File Creation:**
- `touch {filename}`
- `echo "{content}" > {filename}`

**Folder Creation:**
- `mkdir {foldername}`
- `mkdir -p {foldername}`

**Nested Creation:**
- `mkdir -p {foldername} && touch {foldername}/{filename}`

**File Operations:**
- `rm {filename}` - Delete
- `mv {old} {new}` - Rename/Move
- `cp {source} {dest}` - Copy

**Process Management:**
- `pkill {process}` - Kill process
- `killall {process}` - Kill all instances

---

## 🎯 Intelligence Priority

The system now uses this priority order:

1. **🎨 TEMPLATE** (95% confidence) - Dynamic parameter extraction
2. **🤖 ML** (60-100% confidence) - Machine learning prediction
3. **🔍 FUZZY** (60-100% confidence) - Fuzzy search with typos
4. **💡 DIAGNOSIS** (75-90% confidence) - Problem-to-solution mapping
5. **📋 RULE** (100% confidence) - Rule-based pattern matching

### Example Flow:
```
Query: "create a file named config.json"
  ↓
1. Template System: ✓ Matched! (95%)
   → Extracts "config.json"
   → Generates: echo. > config.json
   → Returns immediately
```

```
Query: "show system info" (no custom parameters)
  ↓
1. Template System: ✗ No parameters to extract
  ↓
2. ML Predictor: ✓ Matched! (92%)
   → Returns: systeminfo
```

---

## 🔧 Customization

### Add Your Own Templates

Edit `parameter_extractor.py` to add new templates:

```python
self.templates = {
    'windows': {
        'your_action_target': [
            'your_command {parameter1} {parameter2}',
        ],
    }
}
```

### Add Parameter Patterns

Add new extraction patterns:

```python
self.patterns = {
    'your_param': [
        r'your\s+pattern\s+(\w+)',
    ],
}
```

---

## 🧪 Testing

Run the parameter extractor test:

```bash
python parameter_extractor.py
```

Test in main program:

```bash
# Single command
python main.py "create folder MyProject with file app.py inside"

# REPL mode
python main.py -i
n2c> create a file named test.txt
n2c> kill process chrome
n2c> create folder Documents
```

---

## 📊 Examples with Output

```bash
PS> python main.py "create a file named mydata.csv"

╔═══════════════════════════════════════════════════════════╗
║              NL2CMD - Natural Language to CLI             ║
║                   Hybrid ML + Rule Engine                 ║
╚═══════════════════════════════════════════════════════════╝

Detected OS: Windows
Mode: Single Command

✓ Fuzzy search enabled (typo tolerance active)
✓ Dynamic parameter extraction enabled
✓ ML model loaded successfully

════════════════════════════════════════════════════════════
Query: 'create a file named mydata.csv'
Method: TEMPLATE (95% confidence)
✓ Command: echo. > mydata.csv
────────────────────────────────────────────────────────────

Do you want to execute this command? (y/n): y

--- Command Output ---
File created successfully
```

---

## 🎓 Advanced Features

### Multiple Parameters

```bash
"create file {name} with content {text} in folder {path}"
→ Extracts: name, text, path
→ Generates: mkdir {path} && echo {text} > {path}\{name}
```

### Nested Operations Detection

```bash
"create folder X with file Y inside"
→ Detects: parent=folder(X), child=file(Y)
→ Generates nested command automatically
```

### Context-Aware Selection

The system chooses templates based on:
- Detected intent (create, delete, kill, etc.)
- Target type (file, folder, process, etc.)
- Available parameters (name, path, content, etc.)

---

## ⚠️ Limitations

### Current Limitations:
1. **Single nesting level** - Can't do folder/subfolder/file in one command
2. **Simple patterns** - Complex rename/move operations need quotes
3. **No wildcards** - Can't extract patterns like `*.txt`

### Workarounds:
```bash
# For complex operations, use explicit commands:
nl2cmd "rename all .txt files"  
# Better: Use explicit pattern matching (future feature)
```

---

## 🔮 Future Enhancements

### Planned Features:
- [ ] Multiple file creation: `"create files a.txt, b.txt, c.txt"`
- [ ] Wildcard support: `"delete all .log files"`
- [ ] Variable paths: `"copy file.txt to %USERPROFILE%\Documents"`
- [ ] Conditional operations: `"if file exists, delete it"`
- [ ] Batch operations: `"create 10 files named test1.txt to test10.txt"`

---

## 📝 Summary

### Key Benefits:
✅ **Flexible** - Use any file/folder/process name
✅ **Natural** - Speak naturally with custom values
✅ **Fast** - 95% confidence = instant match
✅ **Smart** - Automatic nested operation detection
✅ **Cross-platform** - Windows & Linux support

### When to Use:
- Creating files/folders with specific names
- Killing processes by name
- Any operation requiring custom values
- Nested file/folder creation

### When ML is Better:
- Generic queries without parameters
- Complex multi-step operations
- System information queries
- Diagnostic commands

---

**Your system now has production-grade dynamic parameter extraction! 🎉**
