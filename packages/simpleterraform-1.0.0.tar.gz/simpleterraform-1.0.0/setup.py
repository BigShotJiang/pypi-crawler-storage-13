from setuptools import setup, find_packages

# Read requirements.txt
with open('requirements.txt') as f:
    required = f.read().splitlines()

# Read README.md for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="simpleterraform",  # <--- YOUR NEW PACKAGE NAME
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Automated Infrastructure as Code Generator for Terraform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/simpleterraform",
    
    # This tells setuptools to look for code inside the 'src' folder
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    
    py_modules=["main"], # Includes the root main.py if needed by entry points
    
    include_package_data=True, # Vital for including templates
    install_requires=required,
    
    entry_points={
        "console_scripts": [
            # This allows users to type 'simpleterraform' in their terminal
            "simpleterraform=main:run", 
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)