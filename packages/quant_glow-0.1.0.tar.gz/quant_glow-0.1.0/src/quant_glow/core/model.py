import numpy as np
from tinygrad import Tensor
import json
import pkg_resources
from pathlib import Path

class LuminaModel:
    """
    Lumina LSTM Model for cryptocurrency prediction
    """
    
    def __init__(self):
        # Load model files from package resources
        self.weights = np.load(
            pkg_resources.resource_filename('lumina', 'models/crypto_model_weights.npz')
        )
        
        with open(pkg_resources.resource_filename('lumina', 'models/crypto_metadata.json'), 'r') as f:
            self.metadata = json.load(f)
        
        # Model parameters from metadata
        self.seq_length = self.metadata.get('seq_length', 30)
        self.input_size = self.metadata.get('input_size', 13)
        self.hidden_size = self.metadata.get('hidden_size', 64)
        self.num_layers = self.metadata.get('num_layers', 2)
        self.features = self.metadata.get('features', [])
    
    def lstm_cell(self, x: Tensor, h_prev: Tensor, c_prev: Tensor, layer_idx: int):
        """LSTM cell implementation"""
        w_ih = Tensor(self.weights[f'lstm.weight_ih_l{layer_idx}'])
        w_hh = Tensor(self.weights[f'lstm.weight_hh_l{layer_idx}'])
        b_ih = Tensor(self.weights[f'lstm.bias_ih_l{layer_idx}'])
        b_hh = Tensor(self.weights[f'lstm.bias_hh_l{layer_idx}'])
        
        gates = (x @ w_ih.T + b_ih) + (h_prev @ w_hh.T + b_hh)
        i, f, g, o = gates.chunk(4, 1)
        
        i = i.sigmoid()
        f = f.sigmoid()  
        g = g.tanh()
        o = o.sigmoid()
        
        c_next = f * c_prev + i * g
        h_next = o * c_next.tanh()
        
        return h_next, c_next
    
    def forward(self, x: Tensor) -> Tensor:
        """Forward pass through LSTM layers"""
        batch_size, seq_len, _ = x.shape
        
        for layer in range(self.num_layers):
            h_layer = Tensor.zeros(batch_size, self.hidden_size)
            c_layer = Tensor.zeros(batch_size, self.hidden_size)
            outputs = []
            
            for t in range(seq_len):
                h_layer, c_layer = self.lstm_cell(
                    x[:, t, :], h_layer, c_layer, layer
                )
                outputs.append(h_layer.unsqueeze(1))
            
            x = Tensor.cat(*outputs, dim=1)
        
        last_output = x[:, -1, :]
        
        # Fully connected layers
        fc1_w = Tensor(self.weights['fc1.weight'])
        fc1_b = Tensor(self.weights['fc1.bias'])
        fc2_w = Tensor(self.weights['fc2.weight']) 
        fc2_b = Tensor(self.weights['fc2.bias'])
        
        x = last_output @ fc1_w.T + fc1_b
        x = x.relu()
        x = x @ fc2_w.T + fc2_b
        
        return x
    
    def predict(self, sequence_data: np.ndarray) -> np.ndarray:
        """Make prediction on sequence data"""
        x = Tensor(sequence_data.astype(np.float32)).unsqueeze(0)
        with Tensor.no_grad():
            prediction = self.forward(x)
        return prediction.numpy()[0]
    
    def get_model_info(self) -> dict:
        """Get model information"""
        return {
            'model': self.metadata.get('model', 'Unknown'),
            'input_size': self.input_size,
            'hidden_size': self.hidden_size,
            'seq_length': self.seq_length,
            'features': self.features,
            'test_loss': self.metadata.get('test_loss', 'Unknown')
        }
