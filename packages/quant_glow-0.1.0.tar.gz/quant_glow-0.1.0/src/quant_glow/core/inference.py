import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional
import pkg_resources
from .model import LuminaModel

class LuminaPredictor:
    """
    High-level predictor for cryptocurrency prices
    """
    
    def __init__(self):
        self.model = LuminaModel()
        self.sequence_buffer = []
    
    def add_data_point(self, features: List[float]):
        """Add new data point to sequence buffer"""
        if len(features) != self.model.input_size:
            raise ValueError(f"Expected {self.model.input_size} features, got {len(features)}")
        
        self.sequence_buffer.append(features)
        if len(self.sequence_buffer) > self.model.seq_length:
            self.sequence_buffer.pop(0)
    
    def predict_next(self) -> Dict[str, Any]:
        """Predict next price movement"""
        if len(self.sequence_buffer) < self.model.seq_length:
            raise ValueError(f"Need {self.model.seq_length} data points, got {len(self.sequence_buffer)}")
        
        sequence = np.array(self.sequence_buffer[-self.model.seq_length:])
        prediction = self.model.predict(sequence)
        
        return {
            'prediction': float(prediction[0]),
            'trend': 'bullish' if prediction[0] > 0 else 'bearish',
            'confidence': abs(float(prediction[0])),
            'sequence_used': len(sequence),
            'features_used': self.model.features
        }
    
    def predict_sequence(self, steps: int = 5) -> List[Dict[str, Any]]:
        """Predict multiple steps ahead"""
        predictions = []
        current_sequence = self.sequence_buffer.copy()
        
        for i in range(steps):
            if len(current_sequence) < self.model.seq_length:
                break
                
            seq_array = np.array(current_sequence[-self.model.seq_length:])
            pred = self.model.predict(seq_array)
            
            predictions.append({
                'step': i + 1,
                'prediction': float(pred[0]),
                'trend': 'bullish' if pred[0] > 0 else 'bearish',
                'confidence': abs(float(pred[0]))
            })
            
            # Simulate next data point
            if i < steps - 1:
                new_point = current_sequence[-1].copy()
                current_sequence.append(new_point)
        
        return predictions

def predict_from_csv(csv_path: str, steps: int = 1) -> Dict[str, Any]:
    """
    Make prediction directly from CSV file
    """
    predictor = LuminaPredictor()
    
    # Load data from CSV
    df = pd.read_csv(csv_path, header=None)
    
    # Assuming specific format: timestamp,symbol,feature1,feature2,...
    feature_data = df.iloc[:, 2:2+13].values  # Skip timestamp and symbol
    
    # Add data to predictor
    for features in feature_data:
        predictor.add_data_point(features.tolist())
    
    if steps == 1:
        return predictor.predict_next()
    else:
        return {
            'single_prediction': predictor.predict_next(),
            'future_predictions': predictor.predict_sequence(steps)
        }

def main():
    """CLI entry point"""
    import argparse
    import sys
    
    parser = argparse.ArgumentParser(description='Lumina AI - Cryptocurrency Prediction')
    parser.add_argument('--csv', type=str, help='Path to CSV file for prediction')
    parser.add_argument('--steps', type=int, default=1, help='Number of prediction steps')
    
    args = parser.parse_args()
    
    try:
        if args.csv:
            result = predict_from_csv(args.csv, args.steps)
            print("Lumina AI Prediction Results:")
            print(f"Trend: {result['trend']}")
            print(f"Prediction: {result['prediction']:.6f}")
            print(f"Confidence: {result['confidence']:.6f}")
        else:
            print("Lumina AI loaded successfully!")
            print("Usage: lumina --csv <path_to_csv> [--steps <number>]")
            
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
