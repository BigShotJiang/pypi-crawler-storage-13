from tinygrad import Tensor

class DenseLayer:
    """Dense/fully connected layer"""
    
    def __init__(self, input_size: int, output_size: int):
        self.weights = Tensor.uniform(output_size, input_size)
        self.bias = Tensor.uniform(output_size)
    
    def __call__(self, x: Tensor) -> Tensor:
        return x @ self.weights.T + self.bias

class Activation:
    """Activation functions"""
    
    @staticmethod
    def relu(x: Tensor) -> Tensor:
        return x.relu()
    
    @staticmethod
    def sigmoid(x: Tensor) -> Tensor:
        return x.sigmoid()
    
    @staticmethod
    def tanh(x: Tensor) -> Tensor:
        return x.tanh()
