# quant-glow  🔮

**Lightweight Cryptocurrency Prediction with TinyGraD**

Lumix  adalah package Python untuk prediksi cryptocurrency yang ringan dan efisien, dibangun dengan TinyGraD. Package ini sudah include model LSTM yang telah ditraining dan siap untuk inference.

## ✨ Features

- 🚀 **Pre-trained Model** - Model LSTM sudah included, tidak perlu training ulang
- 📈 **13 Technical Indicators** - Open, High, Low, Close, Volume, RSI, MACD, dll
- 🔮 **Trend Prediction** - Prediksi bullish/bearish dengan confidence score
- 💻 **Minimal Dependencies** - Hanya butuh TinyGraD dan NumPy
- 📊 **Multi-step Forecasting** - Prediksi beberapa steps ke depan
- 🐍 **Python & CLI** - Bisa digunakan via Python API atau command line

from quant_glow import LuminaPredictor
import numpy as np

# Initialize predictor
predictor = LuminaPredictor()

# Add your cryptocurrency data (13 features)
# Format: [open, high, low, close, volume, rsi, macd, macd_signal, bb_high, bb_low, ema_12, ema_26, atr]
sample_data = [
    19500.50, 19800.75, 19450.25, 19700.80,  # Price data
    3245678901.25,                            # Volume
    65.2, 125.8, 120.3,                      # RSI, MACD, MACD Signal
    19850.25, 19420.75,                      # Bollinger Bands
    19680.40, 19520.60,                      # EMA 12 & 26
    180.45                                   # ATR
]

# Add data points (need at least 30 sequences for prediction)
for i in range(35):
    # Simulate some price movement
    features = [x + (i * 10) for x in sample_data]
    predictor.add_data_point(features)

# Get prediction
result = predictor.predict_next()
print(f"🎯 Prediction: {result['prediction']:.6f}")
print(f"📈 Trend: {result['trend'].upper()}")
print(f"🎲 Confidence: {result['confidence']:.4f}")
print(f"📊 Features Used: {result['features_used']}")

## 🚀 Installation

```bash
pip install quant-glow
