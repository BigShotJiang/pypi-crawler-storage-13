# AutoResume

AutoResume is a crash-safe, resume-safe ML model runner.

It allows you to run many models sequentially and **automatically resumes**
from the first unfinished model if your Python session crashes.

## Example

```python
from autoresume import AutoResume

runner = AutoResume("lstm_experiment")

models = [lstm1, lstm2, lstm3]

def train(model):
    model.fit(X_train, y_train, epochs=20)
    return model.evaluate(X_test, y_test)

runner.run(models, train)
If your script crashes during model 2, AutoResume will resume at model 2.

MIT License
Copyright (c) 2025 Tej Gorde