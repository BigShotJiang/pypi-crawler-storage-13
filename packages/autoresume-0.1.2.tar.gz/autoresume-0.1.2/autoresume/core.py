{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "3b0d09ba-7d07-4cae-b860-d9b378dae365",
   "metadata": {},
   "outputs": [],
   "source": [
    "import os, json\n",
    "from datetime import datetime\n",
    "\n",
    "class AutoResume:\n",
    "    \"\"\"\n",
    "    AutoResume: Crash-safe sequential model executor.\n",
    "    Automatically resumes at the first unfinished model after a crash.\n",
    "    \"\"\"\n",
    "    def __init__(self, name):\n",
    "        self.name = name\n",
    "        self.base = os.path.expanduser(f\"~/.autoresume/{name}\")\n",
    "        os.makedirs(self.base, exist_ok=True)\n",
    "        self.status_file = os.path.join(self.base, \"status.json\")\n",
    "        self._load_status()\n",
    "\n",
    "    def _load_status(self):\n",
    "        if os.path.exists(self.status_file):\n",
    "            with open(self.status_file, \"r\") as f:\n",
    "                self.status = json.load(f)\n",
    "        else:\n",
    "            self.status = {\"completed\": []}\n",
    "            self._save_status()\n",
    "\n",
    "    def _save_status(self):\n",
    "        with open(self.status_file, \"w\") as f:\n",
    "            json.dump(self.status, f, indent=4)\n",
    "\n",
    "    def run(self, models, train_fn):\n",
    "        \"\"\"\n",
    "        models: list of models to run\n",
    "        train_fn: function that trains a model and returns results\n",
    "        \"\"\"\n",
    "        for idx, model in enumerate(models):\n",
    "            if idx in self.status[\"completed\"]:\n",
    "                print(f\"⏩ Skipping model {idx} (already completed)\")\n",
    "                continue\n",
    "\n",
    "            print(f\"🚀 Running model {idx}...\")\n",
    "            try:\n",
    "                result = train_fn(model)\n",
    "\n",
    "                # Save model result\n",
    "                with open(os.path.join(self.base, f\"model_{idx}_result.json\"), \"w\") as f:\n",
    "                    json.dump({\"result\": result}, f, indent=4)\n",
    "\n",
    "                # Mark as completed\n",
    "                self.status[\"completed\"].append(idx)\n",
    "                self._save_status()\n",
    "\n",
    "                print(f\"✅ Completed model {idx}\")\n",
    "\n",
    "            except Exception as e:\n",
    "                print(f\"❌ Crash on model {idx}: {e}\")\n",
    "                print(\"⚠️ Progress saved. Will resume here next time.\")\n",
    "                break\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "4518a4c5-99ed-49be-ae0d-372e9cb2cff8",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python [conda env:Python313]",
   "language": "python",
   "name": "conda-env-Python313-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.13.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
