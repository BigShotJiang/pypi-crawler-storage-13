from datetime import datetime
from pathlib import Path
from dateutil import parser

import git
import git.cmd
import numpy as np
import pandas as pd
import yaml

import json
from semantic_version_tools import Vers

__version__ = "0.4.0"

class DBFORMAT:
    CSV = '.csv'
    JSON = '.json'


def is_git_repo(path):
    try:
        _ = git.Repo(path).git_dir
        return True
    except git.exc.InvalidGitRepositoryError:
        return False

class ValidityPeriod:
    """Class to represent the validity period of a calibration item."""
    def __init__(self, start:str, end:str):
        self.start = parser.parse(start)
        if end.lower() == 'now':
            self.end = datetime.now()
        else:
            self.end = parser.parse(end)

    def __str__(self):
        return f"ValidityPeriod: {self.start} - {self.end}"
    
    def __repr__(self):
        return f"ValidityPeriod: {self.start} - {self.end}"

class CalibrationItem:
    """Class to represent a single calibration item."""
    def __init__(self, instrument:str,step:str,description:str,calibration_file:str, version:str, validity:dict, size:list=None, data_type:str="float32", applicated_function:str=None):
        self.instrument = instrument
        self.description = description
        self.step = step
        self.calibration_file = calibration_file
        self.validity = ValidityPeriod(validity.get("start"), validity.get("end"))
        self.version = Vers(version)
        self.size = size
        self.data_type = data_type
        self.applicated_function = applicated_function
        self.mtx = None

    def valid(self, on_date: datetime|None = None) -> bool:
        """Check if the calibration item is valid on a given date."""
        if on_date is None:
            on_date = datetime.now()
        if not isinstance(on_date, datetime):
            on_date = parser.parse(on_date)
        return self.validity.start <= on_date <= self.validity.end
    
    def check_version(self, version:Vers |str) -> bool:
        """Check if the calibration item's version matches the given version."""
        if isinstance(version, str):
            version = Vers(version)
        return self.version == version





class CalibDB:
    """Calibration Database Reader"""
    
    """TODO:
        - add support for PyPI packages
        - check the version of the database and compare with the remote (git or pip)
        - add instruments nicknames
    """

    def __init__(self, folder: str | Path = None, remote: str = None, check_git: bool = True, json_force: bool = False, dbname: str = "calib_db"):
        """
        Read the database from a folder or clone it from a remote repository

        Args:
            folder (str | Path, optional): folder of the database.
            remote (str, optional): URL of the remote repository. Defaults to None.

        """
        folder_not_exists = False
        if folder is None:
            raise ValueError("folder cannot be None")
        elif not isinstance(folder, Path):
            folder = Path(folder)
        self.db_name = dbname
        self.folder = folder
        self.db_format=None
        if not folder.exists():
            if remote is None:
                raise FileNotFoundError(
                    f"folder {folder} does not exist, please provide a remote")
            else:
                folder.mkdir(parents=True, exist_ok=True)
                git.Repo.clone_from(url=remote, to_path=folder)
                self._datainit(folder,json_force)
        else:
            if not folder.is_dir():
                raise NotADirectoryError(f"{folder} is not a directory")
            if not is_git_repo(folder) and check_git:
                raise git.exc.GitError(f"{folder} is not a git repository")
            else:
                self._datainit(folder, json_force)
            self.check_git = check_git

    def convert_size(self, value: str) -> list:
        """Convert the Size field to a list of integers"""
        return list(map(int, value.split('-')))

    def convert_date(self, value: str) -> datetime:
        """Convert the date field to a datetime object"""
        return pd.to_datetime(value, format='%Y-%m-%d')

    def convert_date_now(self, value: str) -> datetime:
        """Convert the end date field to a datetime object, if the value is 'Now' return the current time"""
        if value == 'Now':
            return pd.Timestamp.now()
        return pd.to_datetime(value, format='%Y-%m-%d')

    def convert_filter(self, value: str) -> int:
        """Convert the filter field to an integer, if the value is 'all' return 0"""
        if value == 'all':
            return 0
        else:
            return int(value)
        
    def convert_arrays(self, value: str) -> list|str:
        """Convert the Arrays field to a list of strings"""
        if '-' in value:
            return value.split('-')
        else:
            if value == 'Null':
                return 'Null'
        return value

    def _datainit(self, folder:Path, json_force:bool):
        """Load the dabase from the CSV file and the version from the version.yml file"""


        # Check the file extension of the DB file
        files=list(folder.glob(f"{self.db_name}.*"))
        if len(files)==0:
            raise FileNotFoundError(
                f"No calib_db file found in {folder}. Not a valid calib_db folder")
        elif len(files)==1:
            ext=files[0].suffix
            fl=files[0]
        else:
            # Find the file with the desired extension based on json_force
            if json_force:
                # Look for JSON file
                json_files = [f for f in files if f.suffix == DBFORMAT.JSON]
                if json_files:
                    ext = json_files[0].suffix
                    fl=json_files[0]
                else:
                    raise FileNotFoundError(f"JSON file not found in {folder}")
            else:
                # Look for CSV file
                csv_files = [f for f in files if f.suffix == DBFORMAT.CSV]
                if csv_files:
                    ext = csv_files[0].suffix
                    fl = csv_files[0]
                else:
                    raise FileNotFoundError(f"CSV file not found in {folder}")

        if ext==DBFORMAT.CSV and not json_force:
            self.db_format=DBFORMAT.CSV
            db_file = fl
            self.db = pd.read_csv(db_file)
            self.db['Size'] = self.db['Size'].apply(self.convert_size)
            self.db['Start'] = self.db['Start'].apply(self.convert_date)
            self.db['End'] = self.db['End'].apply(self.convert_date_now)
            if "Filter" in self.db.columns:
                self.db['Filter'] = self.db['Filter'].apply(self.convert_filter)
            if "Arrays" in self.db.columns:
                self.db['Arrays'] = self.db['Arrays'].apply(self.convert_arrays)
            with open(folder.joinpath("version.yml")) as f:
                sata = yaml.safe_load(f)
            self.version = sata["version"]
            self.instrument = sata["instrument"]
        elif ext==DBFORMAT.JSON:
            self.db_format=DBFORMAT.JSON
            db_file = fl

            json_data = json.load(open(db_file))
            self.version = json_data["version"]
            self.instrument = json_data["instrument"]
            self.db = json_data["database"]
        else:
            raise ValueError(f"Unsupported database format: {ext}")



            # self.db = pd.read_json(db_file)
            # self.db['Size'] = self.db['Size'].apply(self.convert_size)
            # self.db['Start'] = self.db['Start'].apply(self.convert_date)
            # self.db['End'] = self.db['End'].apply(self.convert_date_now)
            # if "Filter" in self.db.columns:
            #     self.db['Filter'] = self.db['Filter'].apply(self.convert_filter)
            # if "Arrays" in self.db.columns:
            #     self.db['Arrays'] = self.db['Arrays'].apply(self.convert_arrays)
            # with open(folder.joinpath("version.yml")) as f:
            #     sata = yaml.safe_load(f)
            # self.version = sata["version"]
            # self.instrument = sata["instrument"]

    def __str__(self):
        return f"CalibDB: {self.version} for {self.instrument}"

    def __repr__(self):
        return f"CalibDB: {self.version} for {self.instrument}"

    def get_calib(self, calibration_step: str, date: datetime, channel: str = None, filter: int = None, read_data: bool = False) -> dict:
        """
        Get the Calibrauion File for a given module, date, channel and filter

        Args:
            calibration_step (str): name of the calibration module
            date (datetime): acquisition date of the product to calibrate
            channel (str, optional): channel to calibrate. Defaults to None.
            filter (int, optional): filter to calibrate. Defaults to None.
            read_data (bool, optional): read the calibration file and add it to the returned dictionary. Defaults to False.

        Returns:
            dict: Dictionary with all the information of the calibration file and the data if read_data is True
        """
        df = self.db
        if self.db_format==DBFORMAT.CSV:
            module_mask = df['Calibration_Step'] == calibration_step
            date_mask = (df['Start'] <= date) & (df['End'] >= date)

            if "Channel" in df.columns and channel is not None:
                channel_mask = (df['Channel'] ==
                                channel)
            else:
                channel_mask = True

            if "Filter" in df.columns and filter is not None:
                filter_mask = (df['Filter'] == filter)
            else:
                filter_mask = True
            ret = df[module_mask & date_mask & channel_mask &
                    filter_mask].to_dict(orient='records')[0]
            if read_data:
                fileName = self.folder.joinpath(ret['File'])
                if fileName.suffix == '.npz':
                    if "Arrays" in df.columns:
                        mtx = {}
                        with np.load(fileName) as data:
                            for item in ret['Arrays']:
                                mtx[item] = data[item]
                    else:
                        with np.load(fileName) as data:
                            mtx = data['Data']
                else:
                    mtx = np.fromfile(self.folder.joinpath(
                        ret['File']), dtype=ret['Type'])
                    mtx = mtx.reshape(ret['Size'])
                ret['Data'] = mtx
            ret['File'] = self.folder.joinpath(ret['File'])
            return ret
        elif self.db_format==DBFORMAT.JSON:
            channel=channel.lower()
            calibration_step=calibration_step.lower()
            if calibration_step not in df[channel].keys():
                raise ValueError(f"Calibration step {calibration_step} not found in database")
            step_data=df[channel][calibration_step]
            if len(step_data)==0:
                raise ValueError(f"No data found for calibration step {calibration_step} in channel {channel}")
            steps_filtered=[]
            for item in step_data:
            
                steps_filtered.append(CalibrationItem(
                    instrument=channel,
                    step=calibration_step,
                    description=item.get('description',""),
                    calibration_file=item['file'],
                    version=item['version'],
                    validity=item['validity'],
                    data_type=item.get('type','float32'),
                    applicated_function=item.get('function',None),
                    size=item.get('size',None)
                ))
            steps_filtered = [item for item in steps_filtered if item.valid(date)]
            if len(steps_filtered)==0:
                raise ValueError(f"No valid calibration item found for step {calibration_step} on date {date} in channel {channel}")
            # Select the item with the highest version
            selected_item:CalibrationItem=max(steps_filtered, key=lambda x: x.version)
            # ret={
            #     "instrument": selected_item.instrument,
            #     "step": selected_item.step,
            #     "description": selected_item.description,
            #     "file": self.folder.joinpath(selected_item.calibration_file),
            #     "version": str(selected_item.version),
            #     "validity": {
            #         "start": selected_item.validity.start,
            #         "end": selected_item.validity.end
            #     }
            # }
            if read_data:
                fileName = self.folder.joinpath(selected_item.calibration_file)
                if fileName.suffix == '.npz':
                    with np.load(fileName) as data:
                        mtx = data['Data']
                else:
                    mtx = np.fromfile(self.folder.joinpath(
                        selected_item.calibration_file), dtype=selected_item.data_type)
                    mtx = mtx.reshape(selected_item.size)
                selected_item.mtx = mtx
            return selected_item
