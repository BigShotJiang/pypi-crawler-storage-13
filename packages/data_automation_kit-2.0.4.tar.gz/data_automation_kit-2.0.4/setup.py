from setuptools import setup, find_packages
import os

# Read the contents of README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
def parse_requirements(filename):
    """Load requirements from a requirements.txt file"""
    requirements = []
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    requirements.append(line)
    except FileNotFoundError:
        print(f"⚠️  {filename} not found, using default requirements")
        requirements = [
            "pandas>=1.3.0",
            "numpy>=1.21.0",
            "matplotlib>=3.5.0", 
            "seaborn>=0.11.0",
            "sqlalchemy>=1.4.0",
            "openpyxl>=3.0.0",
            "groq>=0.3.0",
            "scikit-learn>=1.0.0",
            "scipy>=1.7.0"
        ]
    return requirements

setup(
    name="data-automation-kit",
    version="2.0.4",  # Updated to 2.0.2
    author="Peter Gatitu",
    author_email="petergatitu61@gmail.com",
    description="A comprehensive Python package for automated data loading, cleaning, visualization, and quality checks with AI integration",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bellonbits/data-automation-kit",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=parse_requirements("requirements.txt"),
    keywords="data-analysis, automation, data-cleaning, visualization, data-quality, ai, machine-learning",
    project_urls={
       
    },
    include_package_data=True,
)
