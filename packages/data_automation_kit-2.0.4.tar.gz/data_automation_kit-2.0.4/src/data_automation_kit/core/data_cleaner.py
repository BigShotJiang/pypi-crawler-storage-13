import pandas as pd
import numpy as np
from typing import Dict, List, Any
import warnings
warnings.filterwarnings('ignore')

class DataCleaner:
    """
    Intelligent data cleaning with automatic issue detection and handling
    """
    
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.cleaning_report = {}
        self.cleaning_steps = []
    
    def auto_clean(self) -> pd.DataFrame:
        """Perform comprehensive automatic data cleaning"""
        print("🧹 Starting intelligent data cleaning...")
        
        original_shape = self.data.shape
        self.cleaning_steps = []
        
        # 1. Remove duplicate rows
        self._remove_duplicates()
        
        # 2. Handle missing values
        self._handle_missing_values()
        
        # 3. Fix data types
        self._fix_data_types()
        
        # 4. Remove constant columns
        self._remove_constant_columns()
        
        # 5. Clean text columns
        self._clean_text_columns()
        
        # 6. Handle outliers
        self._handle_outliers()
        
        # 7. Standardize formats
        self._standardize_formats()
        
        final_shape = self.data.shape
        rows_removed = original_shape[0] - final_shape[0]
        cols_removed = original_shape[1] - final_shape[1]
        
        self.cleaning_report['summary'] = {
            'original_shape': original_shape,
            'final_shape': final_shape,
            'rows_removed': rows_removed,
            'columns_removed': cols_removed,
            'cleaning_steps_applied': len(self.cleaning_steps)
        }
        
        print(f"✅ Data cleaning completed! Applied {len(self.cleaning_steps)} cleaning steps")
        print(f"   📊 Before: {original_shape[0]:,} rows × {original_shape[1]} columns")
        print(f"   📊 After: {final_shape[0]:,} rows × {final_shape[1]} columns")
        
        return self.data
    
    def _remove_duplicates(self):
        """Remove duplicate rows with reporting"""
        before = self.data.shape[0]
        self.data = self.data.drop_duplicates()
        after = self.data.shape[0]
        duplicates_removed = before - after
        
        if duplicates_removed > 0:
            self.cleaning_steps.append(f"Removed {duplicates_removed} duplicate rows")
            self.cleaning_report['duplicates_removed'] = duplicates_removed
            print(f"   ✅ Removed {duplicates_removed} duplicate rows")
    
    def _handle_missing_values(self):
        """Intelligent missing value handling based on data type and percentage"""
        missing_report = {}
        
        for column in self.data.columns:
            missing_count = self.data[column].isnull().sum()
            missing_percent = (missing_count / len(self.data)) * 100
            
            if missing_count > 0:
                if missing_percent > 70:
                    # Drop column if more than 70% missing
                    self.data = self.data.drop(column, axis=1)
                    missing_report[column] = {
                        'action': 'dropped_column',
                        'reason': f'high_missing_rate_{missing_percent:.1f}%',
                        'missing_count': missing_count
                    }
                    self.cleaning_steps.append(f"Dropped column '{column}' ({missing_percent:.1f}% missing)")
                    
                elif self.data[column].dtype in ['object']:
                    # For categorical, use mode or 'Unknown'
                    mode_value = self.data[column].mode()
                    if len(mode_value) > 0 and mode_value[0] is not np.nan:
                        fill_value = mode_value[0]
                        self.data[column] = self.data[column].fillna(fill_value)
                        missing_report[column] = {
                            'action': 'filled_with_mode',
                            'value': str(fill_value),
                            'missing_count': missing_count
                        }
                        self.cleaning_steps.append(f"Filled missing '{column}' with mode: {fill_value}")
                    else:
                        self.data[column] = self.data[column].fillna('Unknown')
                        missing_report[column] = {
                            'action': 'filled_with_unknown',
                            'missing_count': missing_count
                        }
                        self.cleaning_steps.append(f"Filled missing '{column}' with 'Unknown'")
                        
                else:
                    # For numerical, use median
                    median_value = self.data[column].median()
                    self.data[column] = self.data[column].fillna(median_value)
                    missing_report[column] = {
                        'action': 'filled_with_median',
                        'value': median_value,
                        'missing_count': missing_count
                    }
                    self.cleaning_steps.append(f"Filled missing '{column}' with median: {median_value:.2f}")
        
        self.cleaning_report['missing_values'] = missing_report
    
    def _fix_data_types(self):
        """Automatically fix data types where appropriate"""
        type_conversions = {}
        
        for column in self.data.columns:
            original_dtype = str(self.data[column].dtype)
            
            # Try to convert to numeric
            if self.data[column].dtype == 'object':
                numeric_version = pd.to_numeric(self.data[column], errors='coerce')
                numeric_success_rate = numeric_version.notna().mean()
                
                if numeric_success_rate > 0.8:  # If 80%+ can be converted
                    self.data[column] = numeric_version
                    type_conversions[column] = {
                        'from': original_dtype,
                        'to': 'numeric',
                        'success_rate': f'{numeric_success_rate*100:.1f}%'
                    }
                    self.cleaning_steps.append(f"Converted '{column}' from {original_dtype} to numeric")
                
                # Try to convert to datetime
                elif pd.to_datetime(self.data[column], errors='coerce').notna().mean() > 0.5:
                    self.data[column] = pd.to_datetime(self.data[column], errors='coerce')
                    type_conversions[column] = {
                        'from': original_dtype,
                        'to': 'datetime',
                        'success_rate': f'{pd.to_datetime(self.data[column], errors="coerce").notna().mean()*100:.1f}%'
                    }
                    self.cleaning_steps.append(f"Converted '{column}' from {original_dtype} to datetime")
        
        self.cleaning_report['type_conversions'] = type_conversions
    
    def _remove_constant_columns(self):
        """Remove columns with constant values"""
        constant_cols = []
        for column in self.data.columns:
            if self.data[column].nunique() <= 1:
                constant_cols.append(column)
        
        if constant_cols:
            self.data = self.data.drop(constant_cols, axis=1)
            self.cleaning_report['constant_columns_removed'] = constant_cols
            for col in constant_cols:
                self.cleaning_steps.append(f"Removed constant column '{col}'")
    
    def _clean_text_columns(self):
        """Clean and standardize text columns"""
        text_cleaning = {}
        
        for column in self.data.select_dtypes(include=['object']).columns:
            # Remove extra whitespace
            self.data[column] = self.data[column].astype(str).str.strip()
            
            # Replace empty strings and common null representations with NaN
            empty_strings = ['', 'nan', 'None', 'null', 'NULL', 'NaN', 'N/A', 'n/a']
            self.data[column] = self.data[column].replace(empty_strings, np.nan)
            
            # Capitalize first letter for consistency
            self.data[column] = self.data[column].str.capitalize()
            
            text_cleaning[column] = {
                'actions': ['trimmed_whitespace', 'standardized_nulls', 'capitalized']
            }
        
        self.cleaning_report['text_cleaning'] = text_cleaning
        if text_cleaning:
            self.cleaning_steps.append("Cleaned and standardized text columns")
    
    def _handle_outliers(self):
        """Handle extreme outliers in numerical columns"""
        outlier_treatment = {}
        
        for column in self.data.select_dtypes(include=[np.number]).columns:
            Q1 = self.data[column].quantile(0.25)
            Q3 = self.data[column].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 3 * IQR  # Using 3*IQR for more conservative outlier detection
            upper_bound = Q3 + 3 * IQR
            
            # Count outliers
            outlier_mask = (self.data[column] < lower_bound) | (self.data[column] > upper_bound)
            outlier_count = outlier_mask.sum()
            
            if outlier_count > 0 and outlier_count < len(self.data) * 0.05:  # Only treat if <5% are outliers
                # Cap outliers to bounds
                self.data[column] = np.where(self.data[column] < lower_bound, lower_bound, self.data[column])
                self.data[column] = np.where(self.data[column] > upper_bound, upper_bound, self.data[column])
                
                outlier_treatment[column] = {
                    'outliers_found': outlier_count,
                    'action': 'capped_to_bounds',
                    'lower_bound': lower_bound,
                    'upper_bound': upper_bound
                }
                self.cleaning_steps.append(f"Capped outliers in '{column}' ({outlier_count} values)")
        
        self.cleaning_report['outlier_treatment'] = outlier_treatment
    
    def _standardize_formats(self):
        """Standardize various data formats"""
        format_standardizations = {}
        
        # Standardize boolean-like columns
        for column in self.data.select_dtypes(include=['object']).columns:
            if self.data[column].nunique() == 2:
                unique_values = self.data[column].unique()
                if set(unique_values).issubset({'yes', 'no', 'true', 'false', '1', '0', 'y', 'n'}):
                    # Convert to boolean
                    self.data[column] = self.data[column].map({
                        'yes': True, 'true': True, '1': True, 'y': True,
                        'no': False, 'false': False, '0': False, 'n': False
                    }).astype(bool)
                    format_standardizations[column] = 'converted_to_boolean'
                    self.cleaning_steps.append(f"Standardized '{column}' to boolean")
        
        self.cleaning_report['format_standardizations'] = format_standardizations
    
    def get_cleaning_report(self) -> Dict[str, Any]:
        """Get comprehensive cleaning report"""
        return {
            'summary': self.cleaning_report.get('summary', {}),
            'steps_applied': self.cleaning_steps,
            'details': {
                'missing_values': self.cleaning_report.get('missing_values', {}),
                'type_conversions': self.cleaning_report.get('type_conversions', {}),
                'constant_columns': self.cleaning_report.get('constant_columns_removed', []),
                'outlier_treatment': self.cleaning_report.get('outlier_treatment', {}),
                'text_cleaning': self.cleaning_report.get('text_cleaning', {})
            }
        }
    
    def print_cleaning_summary(self):
        """Print a user-friendly cleaning summary"""
        report = self.get_cleaning_report()
        summary = report['summary']
        
        print("\n" + "="*50)
        print("🧹 DATA CLEANING SUMMARY")
        print("="*50)
        
        print(f"📊 Dataset Changes:")
        print(f"   • Original: {summary.get('original_shape', (0, 0))[0]:,} rows × {summary.get('original_shape', (0, 0))[1]} columns")
        print(f"   • Final: {summary.get('final_shape', (0, 0))[0]:,} rows × {summary.get('final_shape', (0, 0))[1]} columns")
        print(f"   • Rows removed: {summary.get('rows_removed', 0)}")
        print(f"   • Columns removed: {summary.get('columns_removed', 0)}")
        
        print(f"\n🔧 Cleaning Steps Applied ({summary.get('cleaning_steps_applied', 0)}):")
        for i, step in enumerate(report['steps_applied'][:10], 1):  # Show first 10 steps
            print(f"   {i}. {step}")
        
        if len(report['steps_applied']) > 10:
            print(f"   ... and {len(report['steps_applied']) - 10} more steps")
        
        print("\n✅ Data is now clean and ready for analysis!")
