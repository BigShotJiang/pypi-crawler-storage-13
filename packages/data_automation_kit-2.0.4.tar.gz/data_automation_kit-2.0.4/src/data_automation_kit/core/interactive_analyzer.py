import pandas as pd
import numpy as np
import os
import sys
import time
import json
from typing import Dict, List, Any, Optional
from .data_loader import DataLoader
from .auto_visualizer import AutoVisualizer
from .data_cleaner import DataCleaner
from .data_quality import DataQualityChecker
from .groq_analyzer import GroqAnalyzer

class InteractiveAnalyzer:
    """
    Modern Analytics Helper - Your AI-powered data analysis companion
    """
    
    def __init__(self):
        self.data = None
        self.cleaned_data = None
        self.quality_report = None
        self.analysis_history = []
        self.user_preferences = {}
        self.loaded_from = "Unknown"
        self.created_plots = []
        self.plot_paths = {}
        self.target_column = None
        self.selected_charts = []
        
        # Set Groq API Key properly
        self._setup_groq_api()
        
        self._print_welcome_message()
    
    def _setup_groq_api(self):
        """Setup Groq API with proper error handling"""
        # Set the API key
        os.environ['GROQ_API_KEY'] = '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'
        os.environ['GROQ_MODEL'] = 'meta-llama/llama-4-scout-17b-16e-instruct'
        
        # Test if Groq is available
        try:
            import groq
            self.groq_available = True
            print("🤖 Groq AI integration: ✅ Available")
        except ImportError:
            self.groq_available = False
            print("🤖 Groq AI integration: ❌ Install with: pip install groq")
    
    def _print_welcome_message(self):
        """Print welcome message with modern features"""
        print("")
        print("🚀" + "="*70 + "🚀")
        print("              MODERN ANALYTICS HELPER - AI-POWERED DATA COMPANION")
        print("🚀" + "="*70 + "🚀")
        print("")
        print("🎯 I'm your AI analytics assistant! Here's what I can help you with:")
        print("")
        print("📊 CORE FEATURES:")
        print("   • Flexible target variable analysis")
        print("   • Selective chart visualization")
        print("   • Interactive AI Q&A about your data")
        print("   • Smart data cleaning and quality checks")
        print("   • Business insights and recommendations")
        print("")
        print("🔄 INTERACTIVE MODES:")
        print("   • Guided analysis (step-by-step)")
        print("   • Quick analysis (automated)")
        print("   • Custom analysis (you choose what to do)")
        print("   • AI Chat mode (ask anything about your data)")
        print("")

    def start_interactive_session(self):
        """Start the main interactive session with mode selection"""
        try:
            print("\n🎛️  SELECT ANALYSIS MODE:")
            print("1. 🚀 Quick Analysis (Fully automated)")
            print("2. 🎯 Guided Analysis (Step-by-step with choices)")
            print("3. 🛠️  Custom Analysis (You choose each step)")
            print("4. 💬 AI Chat Mode (Ask questions about your data)")
            print("5. ❌ Exit")
            
            while True:
                mode_choice = input("\n👉 Choose mode (1-5): ").strip()
                
                if mode_choice == '1':
                    self._quick_analysis_mode()
                    break
                elif mode_choice == '2':
                    self._guided_analysis_mode()
                    break
                elif mode_choice == '3':
                    self._custom_analysis_mode()
                    break
                elif mode_choice == '4':
                    self._ai_chat_mode()
                    break
                elif mode_choice == '5':
                    print("👋 Goodbye! Hope to see you again!")
                    sys.exit(0)
                else:
                    print("❌ Please choose 1-5")
            
        except KeyboardInterrupt:
            print("\n\n⏹️  Session interrupted by user. Goodbye! 👋")
        except Exception as e:
            print(f"\n❌ An error occurred: {e}")
            print("Please try again or report this issue.")

    def _quick_analysis_mode(self):
        """Fully automated quick analysis"""
        print("\n🚀 QUICK ANALYSIS MODE - Sit back and relax!")
        print("="*60)
        
        # Auto-load sample data
        loader = DataLoader()
        self.data = loader.create_sample_data('sales')
        self.loaded_from = "Sample: Sales Data"
        
        # Auto-set target (last numeric column)
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            self.target_column = numeric_cols[-1]
        
        # Run automated analysis
        self._auto_quality_check()
        self._auto_data_cleaning()
        self._auto_visualization()
        self._auto_ai_analysis()
        self._generate_quick_report()

    def _guided_analysis_mode(self):
        """Step-by-step guided analysis with user choices"""
        print("\n🎯 GUIDED ANALYSIS MODE - Let me guide you through each step")
        print("="*60)
        
        # Step 1: Data loading
        self._interactive_data_loading()
        
        if self.data is not None:
            # Step 2: Target variable selection
            self._select_target_variable()
            
            # Step 3: Data exploration
            self._interactive_data_exploration()
            
            # Step 4: Quality assessment
            self._interactive_quality_check()
            
            # Step 5: Data cleaning
            self._interactive_data_cleaning()
            
            # Step 6: Chart selection
            self._select_charts_interactive()
            
            # Step 7: Create visualizations
            self._create_selected_visualizations()
            
            # Step 8: AI analysis options
            self._ai_analysis_options()
            
            # Step 9: Generate report
            self._generate_final_report()
            
            # Step 10: Next steps
            self._suggest_next_steps()

    def _custom_analysis_mode(self):
        """Custom analysis where user chooses each step"""
        print("\n🛠️  CUSTOM ANALYSIS MODE - You're in control!")
        print("="*60)
        
        analysis_options = {
            '1': {'name': 'Load Data', 'method': self._interactive_data_loading},
            '2': {'name': 'Set Target Variable', 'method': self._select_target_variable},
            '3': {'name': 'Explore Data', 'method': self._interactive_data_exploration},
            '4': {'name': 'Check Data Quality', 'method': self._interactive_quality_check},
            '5': {'name': 'Clean Data', 'method': self._interactive_data_cleaning},
            '6': {'name': 'Select Charts', 'method': self._select_charts_interactive},
            '7': {'name': 'Create Visualizations', 'method': self._create_selected_visualizations},
            '8': {'name': 'AI Analysis', 'method': self._ai_analysis_options},
            '9': {'name': 'AI Chat', 'method': self._interactive_ai_chat},
            '10': {'name': 'Generate Report', 'method': self._generate_final_report},
            '11': {'name': 'Start Over', 'method': self._custom_analysis_mode},
            '12': {'name': 'Exit', 'method': sys.exit}
        }
        
        while True:
            print("\n🛠️  AVAILABLE ANALYSIS STEPS:")
            for key, option in analysis_options.items():
                status = "✅" if key in ['1'] else "🔘"
                print(f"   {status} {key}. {option['name']}")
            
            step_choice = input("\n👉 Choose step to execute (1-12): ").strip()
            
            if step_choice in analysis_options:
                if step_choice == '12':
                    print("👋 Goodbye!")
                    sys.exit(0)
                analysis_options[step_choice]['method']()
            else:
                print("❌ Please choose a valid option (1-12)")

    def _ai_chat_mode(self):
        """Interactive AI chat about your data"""
        print("\n💬 AI CHAT MODE - Ask me anything about your data!")
        print("="*60)
        
        # First, load data if not already loaded
        if self.data is None:
            print("\n📥 Let's load your data first...")
            self._interactive_data_loading()
            if self.data is None:
                return
        
        print(f"\n📊 I'm ready to analyze your dataset: {self.data.shape[0]:,} rows × {self.data.shape[1]} columns")
        print("💡 You can ask me about patterns, insights, recommendations, or anything else!")
        print("   Type 'quit' to exit chat mode")
        print("   Type 'summary' for a dataset summary")
        print("   Type 'suggest' for analysis suggestions")
        
        analyzer = GroqAnalyzer()
        
        while True:
            user_question = input("\n🤔 Your question: ").strip()
            
            if user_question.lower() in ['quit', 'exit', 'q']:
                print("👋 Returning to main menu...")
                break
            elif user_question.lower() == 'summary':
                self._print_data_summary()
                continue
            elif user_question.lower() == 'suggest':
                self._suggest_analysis_questions()
                continue
            elif not user_question:
                continue
            
            print("\n🤖 Thinking...")
            try:
                # Prepare context for the AI
                context = f"""
                User Question: {user_question}
                
                Dataset Context:
                - Shape: {self.data.shape}
                - Columns: {list(self.data.columns)}
                - Sample Data: {self.data.head(3).to_dict()}
                - Data Types: {self.data.dtypes.to_dict()}
                """
                
                response = analyzer.client.chat.completions.create(
                    model=analyzer.model,
                    messages=[
                        {"role": "system", "content": "You are a helpful data analyst assistant. Provide clear, actionable insights about the dataset. Focus on practical recommendations and avoid markdown formatting."},
                        {"role": "user", "content": context}
                    ],
                    temperature=0.7,
                    max_tokens=1500
                )
                
                answer = analyzer._clean_response(response.choices[0].message.content)
                print(f"\n💡 {answer}")
                
            except Exception as e:
                print(f"❌ Error getting AI response: {e}")

    def _select_target_variable(self):
        """Flexible target variable selection"""
        if self.data is None:
            print("❌ No data loaded. Please load data first.")
            return
        
        print("\n🎯 TARGET VARIABLE SELECTION")
        print("="*50)
        
        print("\n📋 Available columns:")
        for i, col in enumerate(self.data.columns, 1):
            dtype = self.data[col].dtype
            unique_count = self.data[col].nunique()
            print(f"   {i}. {col} ({dtype}) - {unique_count} unique values")
        
        print(f"   {len(self.data.columns) + 1}. No target variable (unsupervised analysis)")
        print(f"   {len(self.data.columns) + 2}. Let AI suggest the best target")
        
        while True:
            try:
                target_choice = input(f"\n👉 Choose target variable (1-{len(self.data.columns) + 2}): ").strip()
                
                if target_choice == str(len(self.data.columns) + 1):
                    self.target_column = None
                    print("✅ No target variable selected - unsupervised analysis")
                    break
                elif target_choice == str(len(self.data.columns) + 2):
                    self.target_column = self._ai_suggest_target()
                    if self.target_column:
                        print(f"✅ AI suggested target: {self.target_column}")
                    break
                elif 1 <= int(target_choice) <= len(self.data.columns):
                    self.target_column = self.data.columns[int(target_choice) - 1]
                    print(f"✅ Target variable set: {self.target_column}")
                    break
                else:
                    print(f"❌ Please choose 1-{len(self.data.columns) + 2}")
            except ValueError:
                print("❌ Please enter a valid number")

    def _ai_suggest_target(self):
        """Use AI to suggest the best target variable"""
        if not self.groq_available:
            print("❌ AI not available for target suggestion")
            return None
        
        try:
            analyzer = GroqAnalyzer()
            
            prompt = f"""
            Based on this dataset, suggest the best target variable for analysis:
            
            Dataset Columns: {list(self.data.columns)}
            Data Types: {self.data.dtypes.to_dict()}
            Sample Data: {self.data.head(3).to_dict()}
            
            Please suggest the most appropriate target variable and briefly explain why.
            Consider:
            - Predictive potential
            - Business relevance
            - Data quality
            - Analysis goals
            
            Return only the column name as your answer.
            """
            
            response = analyzer.client.chat.completions.create(
                model=analyzer.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5,
                max_tokens=500
            )
            
            suggested_target = analyzer._clean_response(response.choices[0].message.content).strip()
            
            # Validate the suggestion
            if suggested_target in self.data.columns:
                return suggested_target
            else:
                print(f"❌ AI suggested '{suggested_target}' but it's not in the dataset")
                return None
                
        except Exception as e:
            print(f"❌ Error getting AI target suggestion: {e}")
            return None

    def _select_charts_interactive(self):
        """Interactive chart selection with preview"""
        if self.data is None:
            print("❌ No data loaded. Please load data first.")
            return
        
        print("\n🎨 CHART SELECTION")
        print("="*50)
        
        available_charts = {
            '1': {'name': 'Correlation Heatmap', 'type': 'correlation', 'desc': 'Relationships between numeric variables'},
            '2': {'name': 'Distribution Plots', 'type': 'distribution', 'desc': 'Histograms and box plots for all numeric columns'},
            '3': {'name': 'Categorical Analysis', 'type': 'categorical', 'desc': 'Bar and pie charts for categorical data'},
            '4': {'name': 'Missing Values', 'type': 'missing', 'desc': 'Visualization of missing data patterns'},
            '5': {'name': 'Target Analysis', 'type': 'target', 'desc': 'Focus on target variable relationships', 'requires_target': True},
            '6': {'name': 'Time Series', 'type': 'timeseries', 'desc': 'Trend analysis over time', 'requires_date': True},
            '7': {'name': 'Business Dashboard', 'type': 'business', 'desc': 'Executive summary dashboard'},
            '8': {'name': 'All Charts', 'type': 'all', 'desc': 'Generate complete visualization suite'}
        }
        
        print("\n📊 AVAILABLE CHARTS:")
        for key, chart in available_charts.items():
            # Check requirements
            available = True
            if chart.get('requires_target') and not self.target_column:
                available = False
            if chart.get('requires_date') and not any('date' in col.lower() or 'time' in col.lower() for col in self.data.columns):
                available = False
            
            status = "✅" if available else "❌"
            req_note = " (requires target)" if chart.get('requires_target') and not self.target_column else ""
            req_note += " (requires date)" if chart.get('requires_date') and not any('date' in col.lower() or 'time' in col.lower() for col in self.data.columns) else ""
            
            print(f"   {status} {key}. {chart['name']}{req_note}")
            print(f"      {chart['desc']}")
        
        print("\n💡 You can select multiple charts by entering numbers separated by commas (e.g., 1,3,5)")
        
        while True:
            chart_choices = input("\n👉 Select charts to create: ").strip()
            
            if not chart_choices:
                print("❌ Please select at least one chart")
                continue
            
            selected_keys = [choice.strip() for choice in chart_choices.split(',')]
            valid_selection = True
            self.selected_charts = []
            
            for key in selected_keys:
                if key in available_charts:
                    chart = available_charts[key]
                    # Check requirements
                    if chart.get('requires_target') and not self.target_column:
                        print(f"❌ {chart['name']} requires a target variable to be set")
                        valid_selection = False
                        break
                    if chart.get('requires_date') and not any('date' in col.lower() or 'time' in col.lower() for col in self.data.columns):
                        print(f"❌ {chart['name']} requires date/time columns")
                        valid_selection = False
                        break
                    
                    self.selected_charts.append(chart['type'])
                else:
                    print(f"❌ Invalid chart selection: {key}")
                    valid_selection = False
                    break
            
            if valid_selection and self.selected_charts:
                print(f"✅ Selected {len(self.selected_charts)} chart types")
                break

    def _create_selected_visualizations(self):
        """Create only the selected visualizations"""
        if not self.selected_charts:
            print("❌ No charts selected. Please select charts first.")
            return
        
        print("\n📊 CREATING SELECTED VISUALIZATIONS")
        print("="*50)
        
        # Use cleaned data if available, otherwise use original data
        data_to_visualize = self.cleaned_data if self.cleaned_data is not None else self.data
        
        visualizer = AutoVisualizer(data_to_visualize)
        
        try:
            # Create selected visualizations
            plots_created = []
            
            for chart_type in self.selected_charts:
                if chart_type == 'correlation' or chart_type == 'all':
                    if visualizer._create_correlation_heatmap():
                        plots_created.append("correlation_heatmap")
                
                if chart_type == 'distribution' or chart_type == 'all':
                    numeric_cols = data_to_visualize.select_dtypes(include=[np.number]).columns
                    for col in numeric_cols:
                        if visualizer._create_distribution_plot(col):
                            plots_created.append(f"distribution_{col}")
                
                if chart_type == 'categorical' or chart_type == 'all':
                    categorical_cols = data_to_visualize.select_dtypes(include=['object']).columns
                    for col in categorical_cols[:6]:
                        if data_to_visualize[col].nunique() <= 15:
                            if visualizer._create_categorical_plot(col):
                                plots_created.append(f"categorical_{col}")
                
                if chart_type == 'missing' or chart_type == 'all':
                    if visualizer._create_missing_values_plot():
                        plots_created.append("missing_values")
                
                if (chart_type == 'target' or chart_type == 'all') and self.target_column:
                    if visualizer._create_target_distribution(self.target_column):
                        plots_created.append(f"target_{self.target_column}")
                
                if chart_type == 'timeseries' or chart_type == 'all':
                    date_cols = data_to_visualize.select_dtypes(include=['datetime']).columns
                    if len(date_cols) > 0:
                        if visualizer._create_time_series_analysis(date_cols[0]):
                            plots_created.append("time_series")
                
                if chart_type == 'business' or chart_type == 'all':
                    if visualizer._create_business_dashboard():
                        plots_created.append("business_dashboard")
            
            print(f"\n✅ Created {len(plots_created)} visualizations!")
            print("📁 Saved to: 'data_visualizations/' folder")
            
            # Store plot paths for AI analysis
            self.plot_paths = visualizer.get_plot_paths()
            self.created_plots = plots_created
            
            # Show preview
            if plots_created:
                print("\n🖼️  Created visualizations:")
                for i, plot in enumerate(plots_created[:10], 1):
                    print(f"   {i}. {plot}")
                if len(plots_created) > 10:
                    print(f"   ... and {len(plots_created) - 10} more")
            
        except Exception as e:
            print(f"❌ Visualization creation failed: {e}")

    def _ai_analysis_options(self):
        """Interactive AI analysis options"""
        if not self.groq_available:
            print("❌ AI analysis not available")
            return
        
        print("\n🤖 AI ANALYSIS OPTIONS")
        print("="*50)
        
        ai_options = {
            '1': {'name': 'Visual Analysis', 'desc': 'AI analyzes your created charts'},
            '2': {'name': 'Business Insights', 'desc': 'Get business recommendations'},
            '3': {'name': 'Data Patterns', 'desc': 'Discover hidden patterns'},
            '4': {'name': 'Cleaning Suggestions', 'desc': 'Get data cleaning advice'},
            '5': {'name': 'Full Analysis Report', 'desc': 'Comprehensive AI report'},
            '6': {'name': 'Ask Specific Question', 'desc': 'Custom question about data'},
            '7': {'name': 'Skip AI Analysis', 'desc': 'Continue without AI'}
        }
        
        print("\n🧠 AVAILABLE AI ANALYSES:")
        for key, option in ai_options.items():
            print(f"   {key}. {option['name']} - {option['desc']}")
        
        while True:
            ai_choice = input("\n👉 Choose AI analysis (1-7): ").strip()
            
            if ai_choice == '1':
                self._interactive_visual_analysis()
                break
            elif ai_choice == '2':
                self._generate_business_insights()
                break
            elif ai_choice == '3':
                self._generate_data_patterns()
                break
            elif ai_choice == '4':
                self._generate_cleaning_suggestions()
                break
            elif ai_choice == '5':
                self._generate_full_ai_report()
                break
            elif ai_choice == '6':
                self._interactive_ai_chat()
                break
            elif ai_choice == '7':
                print("Skipping AI analysis...")
                break
            else:
                print("❌ Please choose 1-7")

    def _interactive_ai_chat(self):
        """Interactive Q&A about the data"""
        if not self.groq_available:
            print("❌ AI chat not available")
            return
        
        print("\n💬 AI CHAT - Ask anything about your data!")
        print("="*50)
        
        analyzer = GroqAnalyzer()
        
        while True:
            question = input("\n🤔 Your question (or 'back' to return): ").strip()
            
            if question.lower() in ['back', 'exit', 'quit']:
                break
            elif not question:
                continue
            
            print("\n🤖 Thinking...")
            try:
                response = analyzer.generate_data_report(self.data, {
                    'user_question': question,
                    'target_column': self.target_column
                })
                print(f"\n💡 {response}")
            except Exception as e:
                print(f"❌ Error: {e}")

    # [Previous data loading and other methods remain the same...]

    def _print_data_summary(self):
        """Print comprehensive data summary"""
        if self.data is None:
            print("❌ No data loaded")
            return
        
        print(f"\n📊 DATASET SUMMARY:")
        print(f"   • Shape: {self.data.shape[0]:,} rows × {self.data.shape[1]} columns")
        print(f"   • Memory: {self.data.memory_usage(deep=True).sum() / (1024*1024):.2f} MB")
        print(f"   • Numeric columns: {len(self.data.select_dtypes(include=[np.number]).columns)}")
        print(f"   • Categorical columns: {len(self.data.select_dtypes(include=['object']).columns)}")
        print(f"   • Date columns: {len(self.data.select_dtypes(include=['datetime']).columns)}")
        
        if self.target_column:
            print(f"   • Target variable: {self.target_column}")
        
        print(f"\n📋 COLUMNS:")
        for col in self.data.columns:
            dtype = self.data[col].dtype
            unique_count = self.data[col].nunique()
            missing_count = self.data[col].isnull().sum()
            print(f"   • {col} ({dtype}) - {unique_count} unique, {missing_count} missing")

    def _suggest_analysis_questions(self):
        """Suggest relevant analysis questions"""
        questions = [
            "What are the key trends in this data?",
            "Which variables are most correlated?",
            "What patterns can we see in the target variable?",
            "Are there any outliers or anomalies?",
            "What business insights can we derive?",
            "How is the data distributed across categories?",
            "What are the data quality issues?",
            "What predictive models could work well?",
            "How does time affect the variables?",
            "What are the key segments in the data?"
        ]
        
        print("\n💡 SUGGESTED QUESTIONS:")
        for i, question in enumerate(questions, 1):
            print(f"   {i}. {question}")

    # [Auto methods for quick analysis]
    def _auto_quality_check(self):
        """Automated quality check"""
        print("\n⚡ Running automated quality checks...")
        checker = DataQualityChecker(self.data)
        self.quality_report = checker.run_quality_checks()
        print(f"✅ Quality score: {self.quality_report.get('quality_score', 'N/A')}/100")

    def _auto_data_cleaning(self):
        """Automated data cleaning"""
        print("🧹 Running automated data cleaning...")
        cleaner = DataCleaner(self.data)
        self.cleaned_data = cleaner.auto_clean()
        print(f"✅ Data cleaned: {self.cleaned_data.shape[0]:,} rows × {self.cleaned_data.shape[1]} columns")

    def _auto_visualization(self):
        """Automated visualization"""
        print("📊 Creating automated visualizations...")
        data_to_viz = self.cleaned_data if self.cleaned_data is not None else self.data
        visualizer = AutoVisualizer(data_to_viz)
        self.created_plots = visualizer.create_comprehensive_dashboard()
        self.plot_paths = visualizer.get_plot_paths()
        print(f"✅ Created {len(self.created_plots)} visualizations")

    def _auto_ai_analysis(self):
        """Automated AI analysis"""
        if not self.groq_available:
            return
        print("🤖 Running automated AI analysis...")
        analyzer = GroqAnalyzer()
        report = analyzer.generate_data_report(
            self.cleaned_data if self.cleaned_data is not None else self.data
        )
        # Save AI report
        with open('ai_quick_analysis.txt', 'w') as f:
            f.write(report)
        print("✅ AI analysis completed and saved")

    def _generate_quick_report(self):
        """Generate quick analysis report"""
        report = f"""
🚀 QUICK ANALYSIS REPORT
{'='*50}

Dataset: {self.loaded_from}
Original: {self.data.shape}
Cleaned: {self.cleaned_data.shape if self.cleaned_data else self.data.shape}
Quality Score: {self.quality_report.get('quality_score', 'N/A')}/100
Visualizations: {len(self.created_plots)} charts
AI Analysis: {'✅ Completed' if self.groq_available else '❌ Skipped'}

📁 Outputs:
• Visualizations: data_visualizations/
• AI Report: ai_quick_analysis.txt
• Cleaned Data: Available for analysis

🎉 Quick analysis complete! Review the outputs above.
"""
        print(report)

    # [Previous data loading, exploration, cleaning methods remain the same...]

def quick_analyze():
    """
    One-function complete analysis - the easiest way to get started!
    """
    analyzer = InteractiveAnalyzer()
    analyzer.start_interactive_session()

if __name__ == "__main__":
    quick_analyze()
