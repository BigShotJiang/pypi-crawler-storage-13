import pandas as pd
import numpy as np
from typing import Dict, List, Any

class DataQualityChecker:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.quality_report = {}
    
    def run_quality_checks(self) -> Dict[str, Any]:
        """Run comprehensive data quality checks"""
        print("🔍 Running comprehensive data quality checks...")
        
        self.quality_report = {
            'dataset_overview': self._get_dataset_overview(),
            'completeness': self._check_completeness(),
            'uniqueness': self._check_uniqueness(),
            'consistency': self._check_consistency(),
            'validity': self._check_validity(),
            'outliers': self._detect_outliers(),
            'data_types': self._check_data_types(),
            'quality_score': self._calculate_quality_score(),
            'recommendations': self._generate_recommendations()
        }
        
        return self.quality_report
    
    def _get_dataset_overview(self) -> Dict[str, Any]:
        """Get comprehensive dataset overview"""
        return {
            'total_rows': len(self.data),
            'total_columns': len(self.data.columns),
            'memory_usage_mb': round(self.data.memory_usage(deep=True).sum() / 1024**2, 2),
            'numerical_columns': len(self.data.select_dtypes(include=[np.number]).columns),
            'categorical_columns': len(self.data.select_dtypes(include=['object']).columns),
            'datetime_columns': len(self.data.select_dtypes(include=['datetime']).columns),
            'boolean_columns': len(self.data.select_dtypes(include=['bool']).columns)
        }
    
    def _check_completeness(self) -> Dict[str, Any]:
        """Check data completeness with detailed analysis"""
        completeness = {}
        total_rows = len(self.data)
        
        for column in self.data.columns:
            missing_count = self.data[column].isnull().sum()
            missing_percentage = round((missing_count / total_rows) * 100, 2)
            completeness[column] = {
                'missing_count': missing_count,
                'missing_percentage': missing_percentage,
                'completeness_percentage': 100 - missing_percentage,
                'status': 'Good' if missing_percentage < 5 else 
                         'Warning' if missing_percentage < 20 else 
                         'Critical'
            }
        
        overall_missing = self.data.isnull().sum().sum()
        overall_completeness = 100 - (overall_missing / (total_rows * len(self.data.columns)) * 100)
        
        return {
            'column_completeness': completeness,
            'overall_completeness': round(overall_completeness, 2),
            'total_missing_values': int(overall_missing)
        }
    
    def _check_uniqueness(self) -> Dict[str, Any]:
        """Check data uniqueness with insights"""
        uniqueness = {}
        
        for column in self.data.columns:
            unique_count = self.data[column].nunique()
            total_count = len(self.data)
            uniqueness_percentage = (unique_count / total_count) * 100
            
            # Determine uniqueness type
            if unique_count == 1:
                uniqueness_type = "Constant"
            elif unique_count == total_count:
                uniqueness_type = "Unique"
            elif uniqueness_percentage > 90:
                uniqueness_type = "Highly Unique"
            elif uniqueness_percentage > 50:
                uniqueness_type = "Moderately Unique"
            else:
                uniqueness_type = "Low Uniqueness"
            
            uniqueness[column] = {
                'unique_values': unique_count,
                'uniqueness_percentage': round(uniqueness_percentage, 2),
                'uniqueness_type': uniqueness_type,
                'potential_key': unique_count == total_count and self.data[column].notna().all()
            }
        
        return uniqueness
    
    def _check_consistency(self) -> Dict[str, Any]:
        """Check data consistency across columns"""
        consistency_issues = {}
        
        # Check for negative values in positive-only columns
        for column in self.data.select_dtypes(include=[np.number]).columns:
            if (self.data[column] < 0).any():
                negative_count = (self.data[column] < 0).sum()
                consistency_issues[column] = {
                    'issue': 'negative_values',
                    'count': negative_count,
                    'percentage': round((negative_count / len(self.data)) * 100, 2)
                }
        
        # Check for values outside reasonable ranges
        for column in self.data.select_dtypes(include=[np.number]).columns:
            Q1 = self.data[column].quantile(0.01)
            Q99 = self.data[column].quantile(0.99)
            extreme_low = (self.data[column] < Q1).sum()
            extreme_high = (self.data[column] > Q99).sum()
            
            if extreme_low > 0 or extreme_high > 0:
                consistency_issues[f"{column}_extremes"] = {
                    'issue': 'extreme_values',
                    'low_extremes': extreme_low,
                    'high_extremes': extreme_high
                }
        
        return consistency_issues
    
    def _check_validity(self) -> Dict[str, Any]:
        """Check data validity and format"""
        validity_issues = {}
        
        # Check for common invalid strings
        invalid_patterns = ['', 'null', 'NULL', 'None', 'NaN', 'nan', 'undefined']
        
        for column in self.data.select_dtypes(include=['object']).columns:
            invalid_count = self.data[column].isin(invalid_patterns).sum()
            if invalid_count > 0:
                validity_issues[column] = {
                    'issue': 'invalid_strings',
                    'count': invalid_count,
                    'percentage': round((invalid_count / len(self.data)) * 100, 2)
                }
        
        # Check for whitespace issues
        for column in self.data.select_dtypes(include=['object']).columns:
            if self.data[column].astype(str).str.strip().str.len().min() != self.data[column].astype(str).str.len().min():
                validity_issues[f"{column}_whitespace"] = {
                    'issue': 'leading_trailing_whitespace',
                    'recommendation': 'Trim whitespace'
                }
        
        return validity_issues
    
    def _detect_outliers(self) -> Dict[str, Any]:
        """Detect outliers using multiple methods"""
        outliers = {}
        
        for column in self.data.select_dtypes(include=[np.number]).columns:
            # IQR method
            Q1 = self.data[column].quantile(0.25)
            Q3 = self.data[column].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            iqr_outliers = ((self.data[column] < lower_bound) | (self.data[column] > upper_bound)).sum()
            iqr_percentage = (iqr_outliers / len(self.data)) * 100
            
            # Z-score method (for normally distributed data)
            z_scores = np.abs((self.data[column] - self.data[column].mean()) / self.data[column].std())
            z_outliers = (z_scores > 3).sum()
            
            if iqr_outliers > 0 or z_outliers > 0:
                outliers[column] = {
                    'iqr_outliers': iqr_outliers,
                    'iqr_percentage': round(iqr_percentage, 2),
                    'z_score_outliers': z_outliers,
                    'lower_bound': round(lower_bound, 2),
                    'upper_bound': round(upper_bound, 2),
                    'outlier_status': 'High' if iqr_percentage > 10 else 
                                     'Medium' if iqr_percentage > 5 else 
                                     'Low'
                }
        
        return outliers
    
    def _check_data_types(self) -> Dict[str, Any]:
        """Check data types and potential conversions"""
        type_issues = {}
        
        for column in self.data.columns:
            current_dtype = str(self.data[column].dtype)
            potential_issues = []
            
            # Check if numeric column has string values
            if self.data[column].dtype == 'object':
                numeric_test = pd.to_numeric(self.data[column], errors='coerce')
                if numeric_test.notna().mean() > 0.8:
                    potential_issues.append('Potential numeric conversion')
            
            # Check if datetime conversion is possible
            if self.data[column].dtype == 'object':
                datetime_test = pd.to_datetime(self.data[column], errors='coerce')
                if datetime_test.notna().mean() > 0.5:
                    potential_issues.append('Potential datetime conversion')
            
            if potential_issues:
                type_issues[column] = {
                    'current_type': current_dtype,
                    'potential_issues': potential_issues
                }
        
        return type_issues
    
    def _calculate_quality_score(self) -> float:
        """Calculate overall data quality score (0-100)"""
        completeness = self.quality_report.get('completeness', {}).get('overall_completeness', 0)
        
        # Penalties for issues
        outlier_penalty = len(self.quality_report.get('outliers', {})) * 3
        consistency_penalty = len(self.quality_report.get('consistency', {})) * 5
        validity_penalty = len(self.quality_report.get('validity', {})) * 4
        
        # Bonus for good characteristics
        uniqueness_bonus = sum(1 for x in self.quality_report.get('uniqueness', {}).values() 
                             if x.get('potential_key', False)) * 2
        
        quality_score = completeness - outlier_penalty - consistency_penalty - validity_penalty + uniqueness_bonus
        return max(0, min(100, round(quality_score, 2)))
    
    def _generate_recommendations(self) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        report = self.quality_report
        
        # Completeness recommendations
        completeness = report.get('completeness', {})
        for col, stats in completeness.get('column_completeness', {}).items():
            if stats['missing_percentage'] > 20:
                recommendations.append(f"🚨 CRITICAL: Column '{col}' has {stats['missing_percentage']}% missing values")
            elif stats['missing_percentage'] > 5:
                recommendations.append(f"⚠️  Column '{col}' has {stats['missing_percentage']}% missing values - consider imputation")
        
        # Outlier recommendations
        outliers = report.get('outliers', {})
        for col, stats in outliers.items():
            if stats['outlier_status'] == 'High':
                recommendations.append(f"🔍 Investigate outliers in '{col}' ({stats['iqr_percentage']}% of data)")
        
        # Consistency recommendations
        consistency = report.get('consistency', {})
        for issue, details in consistency.items():
            recommendations.append(f"⚡ Address consistency issue: {issue}")
        
        # Validity recommendations
        validity = report.get('validity', {})
        for issue, details in validity.items():
            recommendations.append(f"🧹 Clean invalid data: {issue}")
        
        return recommendations
    
    def print_quality_report(self):
        """Print a beautifully formatted quality report"""
        report = self.quality_report
        
        print("\n" + "="*60)
        print("📊 COMPREHENSIVE DATA QUALITY REPORT")
        print("="*60)
        
        # Overview
        overview = report['dataset_overview']
        print(f"\n📈 DATASET OVERVIEW:")
        print(f"   • Rows: {overview['total_rows']:,}")
        print(f"   • Columns: {overview['total_columns']}")
        print(f"   • Memory: {overview['memory_usage_mb']} MB")
        print(f"   • Numerical: {overview['numerical_columns']} columns")
        print(f"   • Categorical: {overview['categorical_columns']} columns")
        
        # Quality Score
        print(f"\n🎯 OVERALL QUALITY SCORE: {report['quality_score']}/100")
        
        # Completeness
        completeness = report['completeness']
        print(f"\n✅ COMPLETENESS: {completeness['overall_completeness']}%")
        print(f"   • Missing values: {completeness['total_missing_values']:,}")
        
        # Critical issues
        critical_columns = [col for col, stats in completeness['column_completeness'].items() 
                          if stats['status'] == 'Critical']
        if critical_columns:
            print(f"   • 🚨 Critical columns: {', '.join(critical_columns)}")
        
        # Recommendations
        recommendations = report['recommendations']
        if recommendations:
            print(f"\n💡 RECOMMENDATIONS ({len(recommendations)}):")
            for i, rec in enumerate(recommendations[:5], 1):  # Show top 5
                print(f"   {i}. {rec}")
            if len(recommendations) > 5:
                print(f"   ... and {len(recommendations) - 5} more recommendations")
        
        print("\n" + "="*60)
