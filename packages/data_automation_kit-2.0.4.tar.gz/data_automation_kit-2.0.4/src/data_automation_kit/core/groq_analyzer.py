import pandas as pd
import numpy as np
import json
import os
import re
from typing import Dict, Any, List

try:
    import groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False
    print("⚠️  Groq package not available. Install with: pip install groq")

class GroqAnalyzer:
    def __init__(self, api_key: str = None, model: str = "meta-llama/llama-4-scout-17b-16e-instruct"):
        self.api_key = api_key or os.getenv('GROQ_API_KEY', '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')
        self.model = model or os.getenv('GROQ_MODEL', "meta-llama/llama-4-scout-17b-16e-instruct")
        
        if GROQ_AVAILABLE and self.api_key:
            try:
                self.client = groq.Groq(api_key=self.api_key)
                self.available = True
                print(f"🤖 Groq AI connected: {self.model}")
            except Exception as e:
                print(f"❌ Error initializing Groq client: {e}")
                self.available = False
        else:
            self.available = False
            if not GROQ_AVAILABLE:
                print("⚠️  Groq package not installed. Run: pip install groq")
            elif not self.api_key:
                print("⚠️  GROQ_API_KEY not set. AI features disabled.")
    
    def _clean_response(self, text: str) -> str:
        """Clean AI response by removing markdown formatting"""
        if not text:
            return text
        
        # Remove markdown headers
        text = re.sub(r'#+\s*', '', text)
        
        # Remove markdown bold and italic
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
        text = re.sub(r'\*(.*?)\*', r'\1', text)
        text = re.sub(r'_(.*?)_', r'\1', text)
        
        # Remove markdown code blocks
        text = re.sub(r'```.*?\n', '', text, flags=re.DOTALL)
        text = re.sub(r'`(.*?)`', r'\1', text)
        
        # Remove markdown lists and bullets
        text = re.sub(r'^\s*[-*+]\s+', '• ', text, flags=re.MULTILINE)
        text = re.sub(r'^\s*\d+\.\s+', '', text, flags=re.MULTILINE)
        
        # Remove extra whitespace
        text = re.sub(r'\n\s*\n', '\n\n', text)
        text = text.strip()
        
        return text
    
    def analyze_visualizations(self, plot_paths: Dict[str, str], data: pd.DataFrame) -> str:
        """AI analysis of generated visualizations"""
        if not self.available:
            return "❌ AI analysis not available. Please check Groq setup."
        
        try:
            print("👁️  AI is analyzing your visualizations...")
            
            # Create a summary of what plots are available
            plot_summary = self._create_plot_summary(plot_paths, data)
            
            prompt = f"""
            As an expert data analyst, analyze these visualizations and provide insights.

            DATASET SUMMARY:
            {self._prepare_data_summary(data)}

            VISUALIZATIONS GENERATED:
            {plot_summary}

            Please provide a comprehensive analysis covering:

            1. CHART INTERPRETATION:
               - What key patterns and trends do you see in each visualization?
               - Are there any surprising or unexpected findings?
               - What are the most significant correlations or relationships?

            2. BUSINESS INSIGHTS:
               - What actionable business recommendations can be derived?
               - What opportunities or risks are visible in the charts?
               - Which metrics should be monitored closely?

            3. DATA STORYTELLING:
               - What story does this data tell?
               - How would you present these findings to stakeholders?
               - What are the key takeaways?

            4. NEXT ANALYSIS STEPS:
               - What additional visualizations would be helpful?
               - What deeper analysis should be conducted?
               - Are there any data quality issues visible in the charts?

            Please be specific and reference the actual chart types in your analysis.
            Use clear, professional language without markdown formatting.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2500
            )
            
            raw_response = response.choices[0].message.content
            return self._clean_response(raw_response)
            
        except Exception as e:
            return f"❌ Error analyzing visualizations: {e}"
    
    def generate_visualization_insights(self, data: pd.DataFrame) -> str:
        """Get AI suggestions for visualizations"""
        if not self.available:
            return "❌ AI analysis not available."
        
        try:
            data_summary = self._prepare_data_summary(data)
            
            prompt = f"""
            Based on this dataset, recommend the most effective visualizations:

            {data_summary}

            Recommend:
            1. KEY CHARTS: Most important visualizations for insights
            2. STORYTELLING: How to create a narrative with the data
            3. DASHBOARD LAYOUT: How to organize visualizations
            4. COLOR SCHEMES: Appropriate color palettes
            5. INTERACTIVE ELEMENTS: Features that would add value

            Focus on clarity, insight generation, and business impact.
            Use clear, professional language without markdown formatting.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=1500
            )
            
            raw_response = response.choices[0].message.content
            return self._clean_response(raw_response)
            
        except Exception as e:
            return f"❌ Error generating visualization insights: {e}"
    
    def generate_data_report(self, data: pd.DataFrame, dataset_info: Dict[str, Any] = None) -> str:
        """Generate comprehensive data analysis report"""
        if not self.available:
            return "❌ AI analysis not available. Please check Groq setup."
        
        try:
            data_summary = self._prepare_data_summary(data, dataset_info)
            
            prompt = f"""
            As an expert data analyst, analyze this dataset and provide insights:

            {data_summary}

            Please provide a comprehensive report with:
            1. EXECUTIVE SUMMARY: Key findings and overall assessment
            2. DATA QUALITY: Assessment of data completeness and issues
            3. KEY PATTERNS: Important trends and relationships found
            4. BUSINESS INSIGHTS: Actionable recommendations for decision-makers
            5. RISKS & LIMITATIONS: Potential issues and data limitations
            6. NEXT STEPS: Recommended actions for further analysis

            Format the response with clear sections but without markdown formatting.
            Use professional, clean language that is easy to read.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2000
            )
            
            raw_response = response.choices[0].message.content
            return self._clean_response(raw_response)
            
        except Exception as e:
            return f"❌ Error generating report: {e}"
    
    def generate_business_insights(self, data: pd.DataFrame) -> str:
        """Generate business-focused insights"""
        if not self.available:
            return "❌ AI analysis not available."
        
        try:
            data_summary = self._prepare_data_summary(data)
            
            prompt = f"""
            Analyze this dataset from a business perspective:

            {data_summary}

            Provide BUSINESS-SPECIFIC insights:
            - Revenue and performance opportunities
            - Customer behavior patterns
            - Operational efficiencies
            - Risk factors
            - Strategic recommendations

            Focus on actionable business decisions and use business terminology.
            Use clear, professional language without markdown formatting.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.6,
                max_tokens=1500
            )
            
            raw_response = response.choices[0].message.content
            return self._clean_response(raw_response)
            
        except Exception as e:
            return f"❌ Error generating business insights: {e}"
    
    def generate_data_patterns(self, data: pd.DataFrame) -> str:
        """Generate data pattern insights"""
        if not self.available:
            return "❌ AI analysis not available."
        
        try:
            data_summary = self._prepare_data_summary(data)
            
            prompt = f"""
            Analyze patterns and relationships in this data:

            {data_summary}

            Identify:
            - Statistical patterns and correlations
            - Outliers and anomalies
            - Distribution characteristics
            - Temporal patterns (if time data exists)
            - Categorical relationships

            Provide technical insights suitable for data scientists.
            Use clear, professional language without markdown formatting.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5,
                max_tokens=1500
            )
            
            raw_response = response.choices[0].message.content
            return self._clean_response(raw_response)
            
        except Exception as e:
            return f"❌ Error generating data patterns: {e}"
    
    def suggest_cleaning_steps(self, data: pd.DataFrame, quality_report: Dict[str, Any]) -> str:
        """Get AI suggestions for data cleaning"""
        if not self.available:
            return "❌ AI analysis not available."
        
        try:
            prompt = f"""
            Based on this data quality report, provide specific cleaning recommendations:

            Data Shape: {data.shape}
            Quality Score: {quality_report.get('quality_score', 'N/A')}

            Key Issues:
            {json.dumps(quality_report, indent=2, default=str)}

            Provide a step-by-step cleaning plan:
            1. HIGH PRIORITY: Critical issues that must be fixed
            2. MEDIUM PRIORITY: Important improvements
            3. LOW PRIORITY: Optional enhancements
            4. VALIDATION: How to verify cleaning worked

            Include specific techniques and code examples where appropriate.
            Use clear, professional language without markdown formatting.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.4,
                max_tokens=1800
            )
            
            raw_response = response.choices[0].message.content
            return self._clean_response(raw_response)
            
        except Exception as e:
            return f"❌ Error getting cleaning suggestions: {e}"
    
    def _create_plot_summary(self, plot_paths: Dict[str, str], data: pd.DataFrame) -> str:
        """Create a summary of generated plots for AI analysis"""
        plot_categories = {
            'correlation': ['heatmap', 'correlation'],
            'distribution': ['distribution', 'histogram', 'box', 'density'],
            'categorical': ['categorical', 'bar', 'pie'],
            'relationship': ['scatter', 'pairplot', 'relationship'],
            'time_series': ['timeseries', 'time_series'],
            'target': ['target_'],
            'business': ['business', 'dashboard']
        }
        
        summary = "Visualization Summary:\n"
        
        for plot_name, plot_path in plot_paths.items():
            # Categorize the plot
            category = "Other"
            for cat, keywords in plot_categories.items():
                if any(keyword in plot_name.lower() for keyword in keywords):
                    category = cat
                    break
            
            summary += f"- {plot_name} ({category.capitalize()} Chart)\n"
        
        # Add data context
        summary += f"\nData Context:\n"
        summary += f"- Dataset: {data.shape[0]} rows × {data.shape[1]} columns\n"
        summary += f"- Numeric columns: {len(data.select_dtypes(include=[np.number]).columns)}\n"
        summary += f"- Categorical columns: {len(data.select_dtypes(include=['object']).columns)}\n"
        
        return summary
    
    def _prepare_data_summary(self, data: pd.DataFrame, additional_info: Dict[str, Any] = None) -> str:
        """Prepare comprehensive data summary for AI analysis"""
        summary = {
            "dataset_shape": data.shape,
            "columns": list(data.columns),
            "data_types": data.dtypes.astype(str).to_dict(),
            "missing_values": data.isnull().sum().to_dict(),
            "basic_statistics": data.describe(include='all').to_dict() if not data.empty else {},
            "sample_data": data.head(5).to_dict()
        }
        
        # Add correlation for numeric columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 1:
            summary["correlation_matrix"] = data[numeric_cols].corr().to_dict()
        
        # Add value counts for categorical columns
        categorical_cols = data.select_dtypes(include=['object']).columns
        if len(categorical_cols) > 0:
            categorical_summary = {}
            for col in categorical_cols[:5]:  # Limit to first 5 categorical columns
                if data[col].nunique() <= 20:  # Only if reasonable number of categories
                    categorical_summary[col] = data[col].value_counts().to_dict()
            summary["categorical_distribution"] = categorical_summary
        
        if additional_info:
            summary.update(additional_info)
        
        return json.dumps(summary, indent=2, default=str)
