import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import json
import os
from typing import Union, Dict, Any, List
import warnings
warnings.filterwarnings('ignore')

class DataLoader:
    """
    Smart data loader for multiple formats with enhanced sample datasets
    """
    
    def __init__(self):
        self.data = None
        self.loaded_from = None
        self.file_info = {}
        
    def load_csv(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Load data from CSV file with smart parsing"""
        try:
            print(f"📥 Loading CSV from: {file_path}")
            self.data = pd.read_csv(file_path, **kwargs)
            self.loaded_from = f"CSV: {file_path}"
            self.file_info = {
                'format': 'CSV',
                'path': file_path,
                'size_mb': os.path.getsize(file_path) / (1024 * 1024)
            }
            self._print_success_message()
            return self.data
        except Exception as e:
            self._print_error_message("CSV", e)
            return None
    
    def load_excel(self, file_path: str, sheet_name: Union[str, int] = 0, **kwargs) -> pd.DataFrame:
        """Load data from Excel file"""
        try:
            print(f"📊 Loading Excel from: {file_path}")
            self.data = pd.read_excel(file_path, sheet_name=sheet_name, **kwargs)
            self.loaded_from = f"Excel: {file_path}"
            self.file_info = {
                'format': 'Excel',
                'path': file_path,
                'sheet': sheet_name,
                'size_mb': os.path.getsize(file_path) / (1024 * 1024)
            }
            self._print_success_message()
            return self.data
        except Exception as e:
            self._print_error_message("Excel", e)
            return None
    
    def load_json(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Load data from JSON file"""
        try:
            print(f"📄 Loading JSON from: {file_path}")
            self.data = pd.read_json(file_path, **kwargs)
            self.loaded_from = f"JSON: {file_path}"
            self.file_info = {
                'format': 'JSON',
                'path': file_path,
                'size_mb': os.path.getsize(file_path) / (1024 * 1024)
            }
            self._print_success_message()
            return self.data
        except Exception as e:
            self._print_error_message("JSON", e)
            return None
    
    def load_sql(self, connection_string: str, query: str, **kwargs) -> pd.DataFrame:
        """Load data from SQL database"""
        try:
            print(f"🗄️ Loading from SQL database...")
            engine = create_engine(connection_string)
            self.data = pd.read_sql(query, engine, **kwargs)
            self.loaded_from = "SQL Database"
            self.file_info = {
                'format': 'SQL',
                'connection': connection_string.split('@')[1] if '@' in connection_string else connection_string,
                'query_rows': len(self.data)
            }
            self._print_success_message()
            return self.data
        except Exception as e:
            self._print_error_message("SQL", e)
            return None
    
    def auto_load(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Automatically detect file type and load data"""
        if not os.path.exists(file_path):
            print(f"❌ File not found: {file_path}")
            return None
            
        file_ext = os.path.splitext(file_path)[1].lower()
        
        loaders = {
            '.csv': self.load_csv,
            '.xlsx': self.load_excel,
            '.xls': self.load_excel,
            '.json': self.load_json
        }
        
        if file_ext in loaders:
            return loaders[file_ext](file_path, **kwargs)
        else:
            print(f"❌ Unsupported file format: {file_ext}")
            print("Supported formats: .csv, .xlsx, .xls, .json")
            return None
    
    def create_sample_data(self, dataset_type: str = "sales") -> pd.DataFrame:
        """Create enhanced sample datasets for demonstration"""
        np.random.seed(42)
        
        sample_generators = {
            "sales": self._create_sales_data,
            "customers": self._create_customer_data,
            "products": self._create_product_data,
            "call_center": self._create_call_center_data,
            "marketing": self._create_marketing_data,
            "finance": self._create_finance_data
        }
        
        if dataset_type in sample_generators:
            self.data = sample_generators[dataset_type]()
            self.loaded_from = f"Sample: {dataset_type}"
            self._print_success_message()
            return self.data
        else:
            print(f"❌ Unknown dataset type: {dataset_type}")
            print(f"Available: {', '.join(sample_generators.keys())}")
            return None
    
    def _create_sales_data(self) -> pd.DataFrame:
        """Create realistic sales data with multiple potential targets"""
        n_records = 1000
        dates = pd.date_range('2023-01-01', '2023-12-31', freq='D')
        
        data = pd.DataFrame({
            'order_id': range(1000, 1000 + n_records),
            'order_date': np.random.choice(dates, n_records),
            'customer_id': np.random.randint(100, 500, n_records),
            'product_category': np.random.choice(['Electronics', 'Clothing', 'Home', 'Books', 'Sports'], n_records),
            'region': np.random.choice(['North', 'South', 'East', 'West'], n_records),
            'sales_amount': np.abs(np.random.normal(150, 50, n_records)),
            'quantity': np.random.randint(1, 5, n_records),
            'profit': np.abs(np.random.normal(30, 10, n_records)),
            'customer_rating': np.random.choice([1, 2, 3, 4, 5], n_records, p=[0.05, 0.1, 0.15, 0.3, 0.4]),
            'promotion': np.random.choice([True, False], n_records, p=[0.3, 0.7]),
            'shipping_time': np.random.randint(1, 10, n_records)
        })
        
        # Add some missing values realistically
        data.loc[np.random.choice(n_records, 50), 'customer_rating'] = np.nan
        data.loc[np.random.choice(n_records, 30), 'profit'] = np.nan
        
        return data
    
    def _create_customer_data(self) -> pd.DataFrame:
        """Create realistic customer data"""
        n_customers = 500
        
        return pd.DataFrame({
            'customer_id': range(100, 100 + n_customers),
            'age': np.random.randint(18, 70, n_customers),
            'income': np.abs(np.random.normal(50000, 20000, n_customers)),
            'city': np.random.choice(['New York', 'London', 'Tokyo', 'Berlin', 'Paris'], n_customers),
            'country': np.random.choice(['USA', 'UK', 'Japan', 'Germany', 'France'], n_customers),
            'membership_tier': np.random.choice(['Basic', 'Silver', 'Gold', 'Platinum'], n_customers, p=[0.5, 0.3, 0.15, 0.05]),
            'total_purchases': np.random.randint(1, 50, n_customers),
            'total_spent': np.abs(np.random.normal(2000, 800, n_customers)),
            'last_purchase_days': np.random.exponential(30, n_customers).astype(int),
            'satisfaction_score': np.random.randint(1, 6, n_customers)
        })
    
    def _create_product_data(self) -> pd.DataFrame:
        """Create realistic product data"""
        n_products = 200
        
        return pd.DataFrame({
            'product_id': range(1, n_products + 1),
            'product_name': [f'Product_{i}' for i in range(1, n_products + 1)],
            'category': np.random.choice(['Electronics', 'Clothing', 'Home', 'Books', 'Sports'], n_products),
            'subcategory': np.random.choice(['Premium', 'Standard', 'Budget'], n_products),
            'price': np.abs(np.random.normal(100, 40, n_products)),
            'cost': np.abs(np.random.normal(40, 15, n_products)),
            'stock_quantity': np.random.randint(0, 1000, n_products),
            'rating': np.random.uniform(3.0, 5.0, n_products).round(1),
            'sales_count': np.random.randint(0, 500, n_products),
            'is_active': np.random.choice([True, False], n_products, p=[0.8, 0.2])
        })
    
    def _create_call_center_data(self) -> pd.DataFrame:
        """Create realistic call center data"""
        n_records = 800
        
        data = pd.DataFrame({
            'call_id': range(10000, 10000 + n_records),
            'start_datetime': pd.date_range('2023-01-01', periods=n_records, freq='H'),
            'agent_id': np.random.choice([f'A{str(i).zfill(3)}' for i in range(1, 51)], n_records),
            'skill': np.random.choice(['Sales', 'Support', 'Billing', 'Technical'], n_records),
            'call_type': np.random.choice(['Inbound', 'Outbound'], n_records, p=[0.7, 0.3]),
            'total_handle_time': np.random.randint(60, 1800, n_records),
            'total_talk_time': np.random.randint(30, 1500, n_records),
            'total_hold_time': np.random.randint(0, 300, n_records),
            'customer_satisfaction': np.random.choice([1, 2, 3, 4, 5], n_records, p=[0.05, 0.1, 0.15, 0.3, 0.4]),
            'first_call_resolution': np.random.choice([True, False], n_records, p=[0.6, 0.4]),
            'call_outcome': np.random.choice(['Sale', 'Support', 'Complaint', 'Information'], n_records)
        })
        
        # Add some missing values
        data.loc[np.random.choice(n_records, 40), 'customer_satisfaction'] = np.nan
        data.loc[np.random.choice(n_records, 25), 'total_hold_time'] = np.nan
        
        return data
    
    def _create_marketing_data(self) -> pd.DataFrame:
        """Create marketing campaign data"""
        n_records = 600
        
        return pd.DataFrame({
            'campaign_id': range(1, n_records + 1),
            'campaign_name': [f'Campaign_{i}' for i in range(1, n_records + 1)],
            'channel': np.random.choice(['Email', 'Social Media', 'PPC', 'TV', 'Radio'], n_records),
            'budget': np.abs(np.random.normal(5000, 2000, n_records)),
            'impressions': np.random.randint(1000, 100000, n_records),
            'clicks': np.random.randint(10, 5000, n_records),
            'conversions': np.random.randint(1, 500, n_records),
            'conversion_rate': np.random.uniform(0.01, 0.15, n_records).round(3),
            'cost_per_conversion': np.abs(np.random.normal(50, 20, n_records)),
            'roi': np.random.uniform(0.5, 3.0, n_records).round(2),
            'campaign_duration': np.random.randint(1, 30, n_records)
        })
    
    def _create_finance_data(self) -> pd.DataFrame:
        """Create financial data"""
        n_records = 400
        
        return pd.DataFrame({
            'transaction_id': range(1000, 1000 + n_records),
            'date': pd.date_range('2023-01-01', periods=n_records, freq='D'),
            'account_id': np.random.randint(1, 100, n_records),
            'transaction_type': np.random.choice(['Deposit', 'Withdrawal', 'Transfer', 'Payment'], n_records),
            'amount': np.abs(np.random.normal(1000, 500, n_records)),
            'balance_after': np.abs(np.random.normal(5000, 2000, n_records)),
            'category': np.random.choice(['Salary', 'Shopping', 'Bills', 'Entertainment', 'Investment'], n_records),
            'is_fraud': np.random.choice([True, False], n_records, p=[0.02, 0.98]),
            'location': np.random.choice(['Domestic', 'International'], n_records, p=[0.8, 0.2])
        })
    
    def get_data(self) -> pd.DataFrame:
        """Get the loaded data"""
        return self.data
    
    def get_info(self) -> Dict[str, Any]:
        """Get comprehensive information about the data"""
        if self.data is None:
            return {"error": "No data loaded"}
        
        return {
            "source": self.loaded_from,
            "file_info": self.file_info,
            "shape": self.data.shape,
            "columns": list(self.data.columns),
            "data_types": self.data.dtypes.astype(str).to_dict(),
            "missing_values": self.data.isnull().sum().to_dict(),
            "memory_usage_mb": round(self.data.memory_usage(deep=True).sum() / (1024 * 1024), 2)
        }
    
    def _print_success_message(self):
        """Print formatted success message"""
        if self.data is not None:
            print(f"✅ Successfully loaded {self.data.shape[0]:,} rows × {self.data.shape[1]} columns")
            print(f"   📊 Memory usage: {self.data.memory_usage(deep=True).sum() / (1024 * 1024):.2f} MB")
    
    def _print_error_message(self, format_type: str, error: Exception):
        """Print formatted error message"""
        print(f"❌ Error loading {format_type}: {error}")
