"""
Async Signal Exporter
Non-blocking signal export to OneX platform
"""

import os
import logging
import queue
import threading
from typing import Any, Dict, Optional

import requests  # type: ignore[import-not-found]

logger = logging.getLogger(__name__)


class AsyncSignalExporter:
    """
    Asynchronous signal exporter
    Exports signals in background thread to avoid blocking inference
    """
    
    def __init__(self, endpoint: str, api_key: str = None, batch_size: int = 10):
        self.endpoint = endpoint
        self.api_key = api_key
        self.batch_size = batch_size
        self.container_id = self._detect_container_id()
        if self.container_id:
            logger.info("Signal exporter running in container %s", self.container_id)
        else:
            logger.info("Signal exporter could not detect a container identifier")
        
        # Signal queue for async processing
        self.signal_queue = queue.Queue(maxsize=1000)
        
        # Start background export thread
        self.running = True
        self.export_thread = threading.Thread(target=self._export_loop, daemon=True)
        self.export_thread.start()
        
        logger.info(f"Signal exporter initialized: {endpoint}")
    
    def export(self, signals: Dict[str, Any]):
        """
        Export signals asynchronously
        Non-blocking - returns immediately
        """
        try:
            payload = self._ensure_container_id(dict(signals))
            self.signal_queue.put_nowait(payload)
        except queue.Full:
            logger.warning("Signal queue full, dropping signal")
    
    def _export_loop(self):
        """Background thread that exports signals"""
        batch = []
        
        while self.running:
            try:
                # Collect signals for batching
                timeout = 1.0  # seconds
                signal = self.signal_queue.get(timeout=timeout)
                logger.debug(f"Received signal: {signal}")
                batch.append(self._ensure_container_id(signal))
                
                # Send batch when full or timeout
                if len(batch) >= self.batch_size:
                    self._send_batch(batch)
                    batch = []
                
            except queue.Empty:
                # Timeout - send whatever we have
                if batch:
                    self._send_batch(batch)
                    batch = []
            
            except Exception as e:
                logger.error(f"Error in export loop: {e}")
    
    def _send_batch(self, batch):
        """Send batch of signals to OneX API"""
        try:
            headers = {}
            if self.api_key:
                headers['Authorization'] = f'Bearer {self.api_key}'
            
            sanitized_batch = [self._ensure_container_id(item) for item in batch]

            for index, payload in enumerate(sanitized_batch):
                logger.info(
                    "Preparing to export signal #%s (container_id=%s, type=%s)",
                    index,
                    payload.get("container_id"),
                    payload.get("signal_type"),
                )
                logger.info("Signal payload #%s content: %s", index, payload)

            response = requests.post(
                self.endpoint,
                json={'signals': sanitized_batch},
                headers=headers,
                timeout=5.0
            )
            
            if 200 <= response.status_code < 300:
                logger.info(f"Exported {len(batch)} signals successfully")
            else:
                logger.warning(f"Export failed: {response.status_code}")
        
        except Exception as e:
            logger.error(f"Failed to export signals: {e}")
    
    def close(self):
        """Stop exporter and cleanup"""
        self.running = False
        self.export_thread.join(timeout=5.0)
        logger.info("Signal exporter stopped")

    def _detect_container_id(self) -> Optional[str]:
        """Attempt to detect the container identifier (if running in Docker)."""
        hostname = os.environ.get("HOSTNAME")
        if hostname and len(hostname) >= 6:  # Docker hostnames are typically truncated IDs
            logger.debug("Detected container ID from HOSTNAME: %s", hostname)
            return hostname

        try:
            with open("/proc/self/cgroup", "r", encoding="utf-8") as cgroup_file:
                for line in cgroup_file:
                    parts = line.strip().split("/")
                    if parts and parts[-1]:
                        candidate = parts[-1]
                        if len(candidate) >= 6:
                            logger.debug("Detected container ID from cgroup: %s", candidate)
                            return candidate
        except OSError:
            logger.debug("Unable to read /proc/self/cgroup for container ID detection", exc_info=True)

        logger.debug("Container ID could not be detected")
        return None

    def _ensure_container_id(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Guarantee that each payload has the detected container identifier."""
        if self.container_id:
            payload['container_id'] = self.container_id
        return payload
