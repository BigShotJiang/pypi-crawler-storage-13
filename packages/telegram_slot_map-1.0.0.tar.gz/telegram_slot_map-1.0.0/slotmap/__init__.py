# slotmap/__init__.py

from .data import RAW_SLOT_COMBINATIONS

__version__ = "1.0.0"

DEFAULT_SYMBOLS = {
    'bar': 'bar',
    'cherry': '🍒',
    'lemon': '🍋',
    'seven': '7️⃣'
}

def get_slot_combination(value: int, symbols=None) -> str:
    """
    Возвращает комбинацию слота 🎰 по значению dice.value (1–64).
    
    :param value: целое число от 1 до 64
    :param symbols: словарь замены, например {'bar': '➖', 'cherry': '🔴', ...}
    :return: строка из трёх символов, разделённых пробелами
    """
    if not (1 <= value <= 64):
        raise ValueError("Slot value must be between 1 and 64")
    
    combo = RAW_SLOT_COMBINATIONS[str(value)]
    sym = symbols or DEFAULT_SYMBOLS
    rendered = [sym.get(token, token) for token in combo]
    return ' '.join(rendered)