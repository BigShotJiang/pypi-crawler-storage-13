# flexivtdk/__init__.py

"""
Teleoperation Development Kit (TDK) for Flexiv robots.

- GitHub: https://github.com/flexivrobotics/flexiv_tdk

"""

__version__ = "1.5.0"
__author__ = "Flexiv Ltd."

from .flexivtdk import *
