class MigrationException(Exception):
    pass
