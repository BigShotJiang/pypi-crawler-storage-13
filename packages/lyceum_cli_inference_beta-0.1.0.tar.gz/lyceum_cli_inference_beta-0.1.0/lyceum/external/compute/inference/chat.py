"""Synchronous inference commands for chat/completion"""

import json
from typing import Optional

import httpx
import typer
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from ....shared.config import config
from ...utils import (
    is_image_file, get_images_from_dir, read_file_as_base64,
    get_s3_files, get_s3_url, get_model_info, check_model_supports_input,
    build_sync_input, handle_inference_response
)
from ...utils.models import URLInput, Base64Input, SyncRequest, BatchRequest

console = Console()
chat_app = typer.Typer(name="chat", help="Synchronous inference commands")


@chat_app.command("send")
def send_message(
    message: str = typer.Argument(..., help="Message to send to the model"),
    model: str = typer.Option("gpt-4", "--model", "-m", help="Model to use for inference"),
    max_tokens: int = typer.Option(1000, "--max-tokens", help="Maximum tokens in response"),
    temperature: float = typer.Option(0.7, "--temperature", "-t", help="Temperature (0.0-2.0)"),
    system_prompt: str | None = typer.Option(None, "--system", "-s", help="System prompt"),
):
    """Send a message to an AI model and get a response"""
    try:
        config.get_client()

        # Create the sync request payload directly
        sync_request = {
            "model_id": model,
            "input": {
                "text": message,
                "parameters": {"system_prompt": system_prompt} if system_prompt else {}
            },
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": 1.0,
            "stream": False
        }

        console.print(f"[dim][SENDING] Sending message to {model}...[/dim]")

        # Make the API call using httpx directly (since we don't have generated client for sync inference yet)
        import httpx

        url = f"{config.base_url}/api/v2/external/sync/"
        headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}

        with httpx.Client() as http_client:
            response = http_client.post(
                url,
                json=sync_request,
                headers=headers,
                timeout=60.0
            )

            if response.status_code == 200:
                result = response.json()

                console.print(f"[green][SUCCESS] Response from {model}:[/green]")
                console.print(f"[cyan]{result['output']}[/cyan]")

                # Show usage stats
                if 'usage' in result:
                    usage = result['usage']
                    console.print(f"[dim]📊 Tokens: {usage.get('total_tokens', 0)} | "
                                f"Latency: {result.get('latency_ms', 0)}ms | "
                                f"Cost: ${result.get('cost', 0):.4f}[/dim]")

            elif response.status_code == 503:
                console.print(f"[red][ERROR] Model {model} is not running. Please contact support to start the model.[/red]")
                raise typer.Exit(1)
            else:
                console.print(f"[red][ERROR] Error: HTTP {response.status_code}[/red]")
                console.print(f"[red]{response.text}[/red]")
                raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        raise typer.Exit(1)


@chat_app.command("models")
def list_models():
    """List available models for inference"""
    try:
        config.get_client()

        # Make API call to get available models
        import httpx

        url = f"{config.base_url}/api/v2/external/models/"
        headers = {"Authorization": f"Bearer {config.api_key}"}

        with httpx.Client() as http_client:
            response = http_client.get(url, headers=headers, timeout=10.0)

            if response.status_code == 200:
                models = response.json()

                if models:
                    # Create a table
                    table = Table(title="Available AI Models")
                    table.add_column("Model", style="cyan", no_wrap=True)
                    table.add_column("Type", style="magenta")
                    table.add_column("Status", justify="center")
                    table.add_column("Price/1K tokens", justify="right", style="green")

                    # Sort models: running first, then by type, then by name
                    sorted_models = sorted(models, key=lambda m: (
                        not m.get('available', False),  # Running models first
                        m.get('type', 'text'),          # Then by type
                        m.get('model_id', '')           # Then by name
                    ))

                    for model in sorted_models:
                        # Status
                        status = "[RUNNING] Running" if model.get('available') else "[STOPPED] Stopped"

                        # Model type
                        model_type = model.get('type', 'text')
                        type_label = {
                            'text': 'Text',
                            'image': 'Image',
                            'audio': 'Audio',
                            'multimodal': 'Multi',
                            'embedding': 'Embed'
                        }.get(model_type, f'[UNKNOWN] {model_type.title()}')

                        # Price
                        price = model.get('price_per_1k_tokens', 0)
                        price_str = f"${price:.4f}" if price > 0 else "Free"

                        table.add_row(
                            model.get('model_id', 'Unknown'),
                            type_label,
                            status,
                            price_str
                        )

                    console.print(table)

                    # Show summary
                    running_count = sum(1 for m in models if m.get('available'))
                    total_count = len(models)
                    console.print(f"\n[dim][STATS] {running_count}/{total_count} models running[/dim]")

                else:
                    console.print("[yellow]No models are currently available[/yellow]")
            else:
                console.print(f"[red][ERROR] Error: HTTP {response.status_code}[/red]")
                console.print(f"[red]{response.text}[/red]")
                raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        raise typer.Exit(1)


@chat_app.command("image")
def analyze_image(
    image_source: Optional[str] = typer.Argument(None, help="Image/PDF URL, file path, or leave empty for batch options"),
    prompt: Optional[str] = typer.Option(None, "--prompt", "-p", help="Text prompt/question (required for multimodal/LLM models, optional for image-only models)"),
    model: str = typer.Option("paddle-ocr-vl", "--model", "-m", help="Model to use (supports text, image, and multimodal models)"),
    raw_output: bool = typer.Option(False, "--raw", help="Return full model response instead of just content"),
    dir: Optional[str] = typer.Option(None, "--dir", "-d", help="Directory containing images/PDFs to process as batch"),
    url: Optional[str] = typer.Option(None, "--url", "-u", help="One or more image/PDF URLs (comma-separated or use multiple times)"),
    from_s3: Optional[str] = typer.Option(None, "--from-s3", help="S3 prefix to list and process files from"),
):
    """Analyze image(s) or send text+image to models. Supports text-only (LLM), image-only (OCR), and multimodal models."""
    try:
        config.get_client()

        # Fetch model info to understand capabilities
        model_info = get_model_info(model)
        model_type = (model_info.get("type", "") if model_info else "").lower()
        supports_text = check_model_supports_input(model_info, "text")
        supports_image = check_model_supports_input(model_info, "image")
        
        # Determine if this is a text-only model
        is_text_only = model_type == "text" or (not supports_image and supports_text)
        
        # For text-only models, we should use the 'send' command instead
        if is_text_only:
            console.print(f"[yellow][WARNING] Model '{model}' is text-only. Use 'lyceum chat send' for text models.[/yellow]")
            console.print(f"[yellow]   Example: lyceum chat send \"your message\" --model {model}[/yellow]")
            raise typer.Exit(1)

        # Collect all input URLs
        input_urls = []
        
        # Handle --dir option
        if dir:
            console.print(f"[dim][DIR] Scanning directory '{dir}' for images...[/dim]")
            try:
                image_files = get_images_from_dir(dir)
                console.print(f"[green][SUCCESS] Found {len(image_files)} image file(s)[/green]")
                
                console.print("[dim][READING] Reading files...[/dim]")
                for img_file in image_files:
                    try:
                        base64_data = read_file_as_base64(img_file)
                        input_urls.append(Base64Input(data=base64_data, filename=img_file.name))
                    except Exception as e:
                        console.print(f"[yellow][WARNING] Warning: Could not read {img_file.name}: {e}[/yellow]")
                
                if not input_urls:
                    console.print("[red][ERROR] No valid image files could be read from directory[/red]")
                    raise typer.Exit(1)
            except ValueError as e:
                console.print(f"[red][ERROR] {e}[/red]")
                raise typer.Exit(1)
        
        # Handle --from-s3 option
        if from_s3 is not None:
            console.print(f"[dim][S3] Listing S3 files with prefix '{from_s3 or '(root)'}'...[/dim]")
            try:
                s3_files = get_s3_files(prefix=from_s3 or "")
                image_files = [f for f in s3_files if is_image_file(Path(f.get("key", "")))]
                
                if not image_files:
                    console.print(f"[yellow][WARNING] No image files found in S3 with prefix '{from_s3 or '(root)'}'[/yellow]")
                    raise typer.Exit(1)
                
                console.print(f"[green][SUCCESS] Found {len(image_files)} image file(s) in S3[/green]")
                
                for file_info in image_files:
                    file_key = file_info["key"]
                    s3_file_url = get_s3_url(file_key)
                    input_urls.append(URLInput(url=s3_file_url))
            except SystemExit:
                raise
            except Exception as e:
                console.print(f"[red][ERROR] Error accessing S3: {e}[/red]")
                raise typer.Exit(1)
        
        # Handle --url option (can be comma-separated or multiple values)
        if url:
            urls = [u.strip() for u in url.split(",") if u.strip()]
            for u in urls:
                input_urls.append(URLInput(url=u))
        
        # Handle positional argument (single image URL or path)
        if image_source:
            img_path = Path(image_source)
            if img_path.exists() and is_image_file(img_path):
                try:
                    base64_data = read_file_as_base64(img_path)
                    input_urls.append(Base64Input(data=base64_data, filename=img_path.name))
                except Exception as e:
                    console.print(f"[red][ERROR] Error reading file {image_source}: {e}[/red]")
                    raise typer.Exit(1)
            else:
                input_urls.append(URLInput(url=image_source))
        
        # Validate we have at least one input
        if not input_urls:
            console.print("[red][ERROR] Error: No input specified. Provide an image/PDF URL, --dir, --url, or --from-s3[/red]")
            raise typer.Exit(1)
        
        # For multimodal models, prompt is recommended but not always required
        # For image-only models (like OCR), prompt is optional
        # For text+image models, prompt should be provided
        if not prompt:
            if model_type == "multimodal":
                console.print("[yellow][WARNING] No prompt provided. Multimodal models work best with a text prompt.[/yellow]")
                console.print("[yellow]   Consider using --prompt to ask a question about the image(s).[/yellow]")
                # Use a default prompt for multimodal
                prompt = "What do you see in this image?"
                console.print(f"[dim]Using default prompt: '{prompt}'[/dim]")
            elif supports_text and not model_type == "image":
                # Model supports text but no prompt - use a default
                prompt = "What do you see in this image?"
                console.print(f"[dim]Using default prompt: '{prompt}'[/dim]")
            # For image-only models (like OCR), no prompt is fine
        
        # Remove duplicates while preserving order (for URLs only)
        seen_urls = set()
        unique_inputs = []
        for inp in input_urls:
            if isinstance(inp, URLInput):
                if inp.url not in seen_urls:
                    seen_urls.add(inp.url)
                    unique_inputs.append(inp)
            elif isinstance(inp, Base64Input):
                unique_inputs.append(inp)  # Always include base64 (can't easily dedupe)
            elif isinstance(inp, dict):
                # Legacy dict format
                if inp.get("type") == "url":
                    url = inp["url"]
                    if url not in seen_urls:
                        seen_urls.add(url)
                        unique_inputs.append(URLInput(url=url))
                else:
                    unique_inputs.append(inp)
            elif isinstance(inp, str):
                # Legacy string format
                if inp not in seen_urls:
                    seen_urls.add(inp)
                    unique_inputs.append(URLInput(url=inp))
        
        input_urls = unique_inputs
        
        # If single input, use sync endpoint; if multiple, use batch endpoint
        if len(input_urls) == 1:
            inp = input_urls[0]
            input_data = build_sync_input(inp, supports_image)
            if prompt and supports_text:
                input_data["text"] = prompt
            
            sync_request = SyncRequest(
                model_id=model,
                input=input_data,
                max_tokens=1000,
                temperature=0.7,
                stream=True,
                raw_output=raw_output
            )
            
            console.print(f"[dim][ANALYZING] Analyzing image with {model}...[/dim]")

            api_url = f"{config.base_url}/api/v2/external/sync/"
            headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}

            try:
                with httpx.Client(timeout=None) as http_client:
                    response = http_client.post(api_url, json=sync_request.to_dict(), headers=headers)

                    if response.status_code == 200:
                        result = response.json()
                        handle_inference_response(result, raw_output)
                    elif response.status_code == 503:
                        console.print(f"[red][ERROR] Vision model {model} is not running.[/red]")
                        raise typer.Exit(1)
                    else:
                        console.print(f"[red][ERROR] Error: HTTP {response.status_code}[/red]")
                        console.print(f"[red]{response.text}[/red]")
                        raise typer.Exit(1)
            except httpx.RequestError as e:
                console.print(f"[red][ERROR] Network error - request did not reach server[/red]")
                console.print(f"[red]   Error: {e}[/red]")
                console.print(f"[red]   URL attempted: {api_url}[/red]")
                console.print(f"[red]   Check your network connection and API URL[/red]")
                raise typer.Exit(1)
            except httpx.HTTPStatusError as e:
                console.print(f"[red][ERROR] HTTP error: {e.response.status_code}[/red]")
                console.print(f"[red]   Response: {e.response.text}[/red]")
                raise typer.Exit(1)
        else:
            # Multiple images - use batch endpoint
            console.print(f"[dim][PROCESSING] Processing {len(input_urls)} images as batch with {model}...[/dim]")
            
            # Build batch request - convert dataclasses to API format
            batch_inputs = []
            for inp in input_urls:
                if isinstance(inp, URLInput):
                    batch_inputs.append({"type": "url", "url": inp.url})
                elif isinstance(inp, Base64Input):
                    batch_inputs.append({"type": "base64", "data": inp.data})
                elif isinstance(inp, dict):
                    # Legacy dict format
                    batch_inputs.append(inp)
                else:
                    # Legacy string format
                    batch_inputs.append({"type": "url", "url": str(inp)})
            
            batch_request = BatchRequest(
                model_id=model,
                inputs=batch_inputs,
                prompt=prompt if (prompt and supports_text) else None,
                raw_output=raw_output
            )
            
            url = f"{config.base_url}/api/v2/external/inference/batch/direct"
            headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}

            # Create client with no timeout - wait indefinitely like curl
            with httpx.Client(timeout=None) as http_client:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=console
                ) as progress:
                    task = progress.add_task("[cyan]Processing batch...", total=None)
                    
                    response = http_client.post(
                        url,
                        json=batch_request.to_dict(),
                        headers=headers
                    )
                    
                    progress.update(task, completed=True)

                if response.status_code == 200:
                    result = response.json()
                    console.print(f"[green][SUCCESS] Batch completed: {result['completed']}/{result['total']} succeeded, {result['failed']} failed[/green]")

                    if raw_output:
                        console.print("\n[cyan]Raw Results:[/cyan]")
                        console.print(json.dumps(result, indent=2))
                    else:
                        table = Table(title="Batch Results")
                        table.add_column("Index", style="cyan", justify="right")
                        table.add_column("Status", style="magenta")
                        table.add_column("Output", style="green")
                        table.add_column("Error", style="red")
                        
                        for res in result.get("results", []):
                            status_prefix = "[OK]" if res["status"] == "completed" else "[FAILED]"
                            output_preview = str(res.get("output", ""))[:100] if res.get("output") else ""
                            error_msg = res.get("error", "")
                            table.add_row(
                                str(res["input_index"]),
                                f"{status_prefix} {res['status']}",
                                output_preview,
                                error_msg[:50] if error_msg else ""
                            )
                        console.print(table)
                elif response.status_code == 503:
                    console.print(f"[red][ERROR] Vision model {model} is not running.[/red]")
                    raise typer.Exit(1)
                else:
                    console.print(f"[red][ERROR] Error: HTTP {response.status_code}[/red]")
                    console.print(f"[red]{response.text}[/red]")
                    raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        import traceback
        console.print(f"[dim]{traceback.format_exc()}[/dim]")
        raise typer.Exit(1)
