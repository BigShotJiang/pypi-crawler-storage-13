"""Data models for inference operations"""
from dataclasses import dataclass, asdict
from typing import Optional, Literal, Union


@dataclass
class URLInput:
    """Input from a URL"""
    url: str
    type: Literal["url"] = "url"


@dataclass
class Base64Input:
    """Input from base64 encoded data"""
    data: str
    type: Literal["base64"] = "base64"
    filename: Optional[str] = None


InputData = Union[URLInput, Base64Input, str]


@dataclass
class SyncRequest:
    """Synchronous inference request"""
    model_id: str
    input: dict
    max_tokens: int = 1000
    temperature: float = 0.7
    stream: bool = True
    raw_output: bool = False
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class BatchRequest:
    """Batch inference request"""
    model_id: str
    inputs: list[dict]
    prompt: Optional[str] = None
    raw_output: bool = False
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class InferenceResponse:
    """Inference response"""
    id: str
    model_id: str
    output: dict
    status: str
    usage: Optional[dict] = None
    latency_ms: Optional[int] = None
    cost: Optional[float] = None
    raw_response: Optional[dict] = None
    created_at: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "InferenceResponse":
        """Create from API response dictionary"""
        return cls(
            id=data.get("id", ""),
            model_id=data.get("model_id", ""),
            output=data.get("output", {}),
            status=data.get("status", "unknown"),
            usage=data.get("usage"),
            latency_ms=data.get("latency_ms"),
            cost=data.get("cost"),
            raw_response=data.get("raw_response"),
            created_at=data.get("created_at"),
        )

