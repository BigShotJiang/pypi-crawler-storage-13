from .spec import PgTableSpec
