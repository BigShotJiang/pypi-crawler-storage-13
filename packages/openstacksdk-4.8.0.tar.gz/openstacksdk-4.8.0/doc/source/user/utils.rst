Utilities
=========
.. automodule:: openstack.utils
