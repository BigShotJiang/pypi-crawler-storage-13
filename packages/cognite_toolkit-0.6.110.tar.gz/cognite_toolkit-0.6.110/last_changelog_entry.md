## cdf 

### Fixed

- [alpha] The download chart command, `cdf data download charts`, no
longer fails to serialize

## templates

No changes.