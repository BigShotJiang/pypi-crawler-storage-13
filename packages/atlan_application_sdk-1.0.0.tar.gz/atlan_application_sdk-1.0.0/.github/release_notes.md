## v1.0.0 (November 21, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc63...v1.0.0

### Features

- GA release
