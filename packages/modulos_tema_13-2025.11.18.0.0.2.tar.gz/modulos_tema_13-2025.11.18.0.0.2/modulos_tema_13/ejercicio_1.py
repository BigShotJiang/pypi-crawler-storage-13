'''
Crear un módulo dentro de Pypi que contenga un método que permita realizar las operaciones de suma, resta, multiplicación y división de dos números.
'''
from decimal import Decimal, DivisionByZero, InvalidOperation

class SimpleMath:

    def suma(sumando_1: str | int | float | Decimal, sumando_2: str | int | float | Decimal) -> float:
        try:
            sumando_1 = Decimal(str(sumando_1))
            sumando_2 = Decimal(str(sumando_2))
            return float(sumando_1 + sumando_2)
        except InvalidOperation:
            raise "Invalid Number Format"
        except (TypeError, OverflowError) as e:
            raise ValueError(f"Invalid parameter: {e}")

    def resta(minuendo: str | int | float | Decimal, sustraendo: str | int | float | Decimal) -> float:
        try:
            minuendo = Decimal(str(minuendo))
            sustraendo = Decimal(str(sustraendo))
            return float(minuendo - sustraendo)
        except InvalidOperation:
            raise "Invalid Number Format"
        except (TypeError, OverflowError) as e:
            raise ValueError(f"Invalid parameter: {e}")

    def multiplicacion(factor_1: str | int | float | Decimal, factor_2: str | int | float | Decimal) -> float:
        try:
            factor_1 = Decimal(str(factor_1))
            factor_2 = Decimal(str(factor_2))
            return float(factor_1 * factor_2)
        except InvalidOperation:
            raise "Invalid Number Format"
        except (TypeError, OverflowError) as e:
            raise ValueError(f"Invalid parameter: {e}")

    def division(dividendo: str | int | float | Decimal, divisor: str | int | float | Decimal) -> float:
        try:
            dividendo = Decimal(str(dividendo))
            divisor = Decimal(str(divisor))
            return float(dividendo / divisor)
        except DivisionByZero:
            raise "Really? Intelligence is chasing you, but you are faster"
        except InvalidOperation:
            raise "Invalid Number Format"
        except (TypeError, OverflowError) as e:
            raise ValueError(f"Invalid parameter: {e}")
