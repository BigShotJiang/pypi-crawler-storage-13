from setuptools import setup, find_packages

setup(
    name = "modulos_tema_13",
    version = "2025.11.18.0.0.2",
    packages = ['modulos_tema_13'],
    classifiers = [
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.13",
    ],
    python_requires = ">=3.13"
)