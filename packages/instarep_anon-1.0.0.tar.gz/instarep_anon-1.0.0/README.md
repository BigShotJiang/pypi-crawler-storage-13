# InstaRep Anon

A unified Instagram reporting tool and bot that supports:
- Full CLI (argparse subcommands)
- Interactive terminal UI
- Lightweight Telegram polling bot
- Shared Instagram session, reporting, and target management

## Installation

```bash
pip install instarep-anon
```

## Usage

### CLI Mode

```bash
# Login
instarep login --username user --password pass

# Add targets
instarep add-targets target1 target2

# Run report
instarep report --mode one --report-type 4 --runs 3

# Start Telegram Bot
instarep start-bot --bot-token <TOKEN>
```

### Interactive Mode

Simply run the command without arguments:

```bash
instarep
```

## Disclaimer

This tool is for educational purposes only. Use responsibly.
