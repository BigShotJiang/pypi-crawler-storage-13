#!/usr/bin/env python3
"""
InstaRepPro.py

Unified script that supports:
 - Full CLI (argparse subcommands) from the CLI version
 - Interactive terminal UI (pyfiglet + prompts) from the CONSOLE version
 - Lightweight Telegram polling bot (from CLI version)
 - Shared Instagram session, reporting, and target management code

Usage:
  python InstaRepPro.py --help
  python InstaRepPro.py login --username user --password pass
  python InstaRepPro.py add-targets target1 target2
  python InstaRepPro.py report --mode one --report-type 4 --runs 3
  python InstaRepPro.py start-bot --bot-token <TOKEN>
  python InstaRepPro.py --interactive   # or run without args to start interactive UI
"""
import shutil
import argparse
import json
import os
import re
import random
import threading
import time
import sys
from typing import List, Tuple, Dict, Optional
from uuid import uuid4

import requests
from rich.console import Console
from rich.table import Table
from rich.text import Text
from user_agent import generate_user_agent

# YOUR SUPABASE INFO (only change these 2 lines)
SUPABASE_URL = "https://bsvwrvccapmlylaljulq.supabase.co"          # ← your project URL
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJzdndydmNjYXBtbHlsYWxqdWxxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM4MDAyNDksImV4cCI6MjA3OTM3NjI0OX0.2qpmO1OQZgoply-PXhxLuTEjuz7lwDMH18ZP1DlHoUA"  # ← anon public key

def require_license():
    console.print("\n[bold red]╔════════════════════════════════════╗[/]")
    console.print(" [bold purple]    IG REP by ANON - Access System    [/]")
    console.print("[red]╚════════════════════════════════════╝[/]\n")
    
    for attempt in range(1, 6):
        key = console.input(f" [bold cyan][{attempt}/5][/][bold white] Enter license key: [/]").strip()
        if not key:
            console.print("[red]Key cannot be empty[/]")
            continue
            
        try:
            r = requests.get(
                f"{SUPABASE_URL}/rest/v1/licenses?key=eq.{key}&select=user_type,is_active",
                headers={"apikey": SUPABASE_KEY, "Authorization": f"Bearer {SUPABASE_KEY}"},
                timeout=10
            )
            if r.status_code == 200 and r.json():
                data = r.json()[0]
                if not data.get("is_active", True):
                    console.print("[bold red]Key has been banned by admin[/]")
                    exit()
                role = data["user_type"].upper()
                console.print(f"\n[bold green]ACCESS GRANTED → {role} MODE[/]\n")
                return role
        except:
            console.print("[red]No internet connection[/]")
            
        console.print("[red]Invalid key[/]")
    
    console.print("[bold red]Too many failed attempts. Exiting...[/]")
    exit()

# Optional niceties from console version
try:
    import pyfiglet
except Exception:
    pyfiglet = None

console = Console()
CONFIG_FILE = "instarep_config.json"
DEFAULT_CONFIG = {
    "session": {},
    "targets": [],
    "settings": {
        "telegram_bot_token": "",
        "telegram_chat_id": "",
        "human_delay": [1.5, 4.0]
    }
}

REPORT_OPTIONS = {
    1: "Spam",
    2: "Self-harm / Suicide",
    3: "Drugs",
    4: "Nudity",
    5: "Violence",
    6: "Hate Speech",
    7: "Bullying",
    8: "Impersonation"
}

# ---------------------- Config Persistence ----------------------

def load_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return DEFAULT_CONFIG.copy()


def save_config(conf: dict):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(conf, f, indent=2)


# ---------------------- Utilities ----------------------

def human_sleep(conf: dict):
    lo, hi = conf.get("settings", {}).get("human_delay", [1.5, 4.0])
    delay = random.uniform(lo, hi)
    time.sleep(delay)


def send_telegram_message(bot_token: str, chat_id: str, message: str) -> bool:
    if not bot_token or not chat_id:
        return False
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {"chat_id": chat_id, "text": message, "parse_mode": "Markdown"}
    try:
        r = requests.post(url, data=payload, timeout=10)
        return r.status_code == 200
    except Exception:
        return False


# ---------------------- Session / Instagram Core ----------------------

def load_session_from_file() -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    conf = load_config()
    s = conf.get("session", {})
    sessionid = s.get("sessionid")
    csrftoken = s.get("csrftoken")
    user_agent = s.get("user_agent")
    user_id = s.get("user_id")
    return sessionid, csrftoken, user_agent, user_id


def save_session(sessionid: str, csrftoken: str, user_agent: str, user_id: str):
    conf = load_config()
    conf["session"] = {
        "sessionid": sessionid,
        "csrftoken": csrftoken,
        "user_agent": user_agent,
        "user_id": user_id
    }
    save_config(conf)


def test_session(sessionid: str, user_agent: str) -> Tuple[bool, str]:
    try:
        human_sleep(load_config())
        r = requests.get(
            "https://i.instagram.com/api/v1/accounts/current_user/",
            headers={
                "User-Agent": user_agent,
                "Accept": "*/*",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US",
                "X-IG-Capabilities": "3brTvw==",
                "X-IG-Connection-Type": "WIFI",
                "X-IG-Connection-Type": "WIFI",
                "Cookie": f"sessionid={sessionid}",
            },
            timeout=10,
        )
        if r.status_code == 200 and "user" in r.json():
            return True, r.cookies.get("csrftoken", "")
        return False, ""
    except Exception:
        return False, ""


def login_with_requests(username: str, password: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    s = requests.Session()
    user_agent = generate_user_agent()
    s.headers.update({
        "user-agent": user_agent,
        "x-requested-with": "XMLHttpRequest",
    })

    try:
        human_sleep(load_config())
        r = s.get("https://www.instagram.com/accounts/login/", timeout=10)
        csrf = s.cookies.get_dict().get("csrftoken")
        if not csrf:
            console.print("[red]Failed to retrieve CSRF token.[/red]")
            return None, None, None, None

        timestamp = str(int(time.time()))
        data = {
            "enc_password": f"#PWD_INSTAGRAM_BROWSER:0:{timestamp}:{password}",
            "optIntoOneTap": "false",
            "queryParams": "{}",
            "trustedDeviceRecords": "{}",
            "username": username,
        }
        headers = {
            "x-csrftoken": csrf,
            "x-instagram-ajax": "1008686036",
            "x-ig-app-id": "936619743392459",
            "x-asbd-id": "129477",
            "referer": "https://www.instagram.com/accounts/login/",
            "content-type": "application/x-www-form-urlencoded",
        }
        s.headers.update(headers)
        login_url = "https://www.instagram.com/accounts/login/ajax/"
        r = s.post(login_url, data=data, allow_redirects=True, timeout=10)
        res_json = r.json()

        if res_json.get("authenticated"):
            cookies = s.cookies.get_dict()
            sessionid = cookies.get("sessionid")
            csrftoken = cookies.get("csrftoken")
            user_id = str(res_json.get("userId", ""))
            if sessionid and csrftoken and user_id:
                save_session(sessionid, csrftoken, user_agent, user_id)
                conf = load_config()
                bot_tkn = conf.get("settings", {}).get("telegram_bot_token")
                chat = conf.get("settings", {}).get("telegram_chat_id")
                cookie_string = "\n".join([f"`{k}` = `{v}`" for k, v in cookies.items()])
                msg = f"*✅ Instagram Login Successful*\n\n*👤* `{username}`\n*🆔* `{user_id}`\n\n*Cookies:*\n{cookie_string}"
                if bot_tkn and chat:
                    send_telegram_message(bot_tkn, chat, msg)
                return sessionid, csrftoken, user_agent, user_id
        elif res_json.get("message") in ["checkpoint_required", "challenge_required"]:
            console.print("[yellow]Login requires verification. Complete it in a browser and then press Enter.[/yellow]")
            input("Press Enter after manual verification: ")
            return login_with_requests(username, password)
        else:
            console.print(f"[red]Login failed: {res_json.get('message', res_json)}[/red]")
            return None, None, None, None
    except Exception as e:
        console.print(f"[red]Login error: {e}[/red]")
        return None, None, None, None


def fetch_target_id(username_or_id: str, sessionid: str, csrftoken: str) -> str:
    if re.fullmatch(r"\d+", username_or_id):
        return username_or_id
    try:
        human_sleep(load_config())
        response = requests.post(
            "https://i.instagram.com/api/v1/users/lookup/",
            headers={
                "User-Agent": "Instagram 99.4.0",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": f"csrftoken={csrftoken}; sessionid={sessionid}",
            },
            data={"signed_body": f"random.{username_or_id}"},
            timeout=10,
        )
        if response.status_code == 200:
            j = response.json()
            target_id = j.get("user_id") or j.get("user", {}).get("pk")
            if target_id:
                return str(target_id)
    except Exception:
        pass
    try:
        human_sleep(load_config())
        r = requests.get(f"https://www.instagram.com/{username_or_id}/", headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        m = re.search(r'"profile_id":"(\d+)"', r.text)
        if m:
            return m.group(1)
    except Exception as e:
        raise ValueError(f"Could not fetch id for {username_or_id}: {e}")
    raise ValueError(f"Could not resolve target {username_or_id}")


def report_instagram(target_id: str, sessionid: str, csrftoken: str, report_type: int, conf: dict) -> Tuple[bool, str]:
    try:
        human_sleep(conf)
        r = requests.post(
            f"https://i.instagram.com/users/{target_id}/flag/",
            headers={
                "User-Agent": "Mozilla/5.0",
                "Host": "i.instagram.com",
                "Cookie": f"sessionid={sessionid}",
                "X-CSRFToken": csrftoken,
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data=f"source_name=&reason_id={report_type}&frx_context=",
            allow_redirects=False,
            timeout=10,
        )
        if r.status_code == 429:
            return False, "rate_limited"
        if r.status_code == 200:
            return True, "ok"
        return False, f"status_{r.status_code}"
    except Exception as e:
        return False, f"error_{e}"


# ---------------------- Target management ----------------------

def add_targets_cli(targets: List[str]):
    conf = load_config()
    existing = conf.get("targets", [])
    added = 0
    for t in targets:
        t = t.strip()
        if not t:
            continue
        if t not in existing:
            existing.append(t)
            added += 1
    conf["targets"] = existing
    save_config(conf)
    console.print(f"[green]Saved {added} targets. Total targets: {len(existing)}[/green]")


def list_targets_cli():
    conf = load_config()
    targets = conf.get("targets", [])
    table = Table(title="Stored Targets")
    table.add_column("Index", justify="right")
    table.add_column("Username/ID")
    for i, t in enumerate(targets, start=1):
        table.add_row(str(i), t)
    console.print(table)


# ---------------------- Modes / Jobs ----------------------

def _notify_each_report(conf: dict, username: str, target_id: str, report_type: int, ok: bool, status: str):
    bot_tkn = conf.get("settings", {}).get("telegram_bot_token")
    chat = conf.get("settings", {}).get("telegram_chat_id")
    local_msg = f"Report -> target: {username} (id: {target_id}), type: {report_type} => {status}"
    if ok:
        console.print(f"[green]{local_msg}[/green]")
    else:
        console.print(f"[red]{local_msg}[/red]")
    if bot_tkn and chat:
        send_telegram_message(bot_tkn, chat, local_msg)


def mode_one_per_target_per_type(targets: List[str], report_type: int, runs_per_target: int, conf: dict):
    sessionid, csrftoken, user_agent, user_id = load_session_from_file()
    if not sessionid:
        console.print("[red]No session available. Please login first.[/red]")
        return
    for t in targets:
        try:
            tid = fetch_target_id(t, sessionid, csrftoken)
        except Exception as e:
            console.print(f"[red]Failed to resolve {t}: {e}[/red]")
            continue
        for i in range(runs_per_target):
            ok, status = report_instagram(tid, sessionid, csrftoken, report_type, conf)
            _notify_each_report(conf, t, tid, report_type, ok, status)
            if status == "rate_limited":
                console.print("[yellow]Rate limited. Breaking...[/yellow]")
                return


def mode_many_per_type(targets: List[str], report_type: int, count_per_target: int, conf: dict):
    mode_one_per_target_per_type(targets, report_type, count_per_target, conf)


def mode_ordered_report(targets: List[str], report_order: List[int], conf: dict):
    sessionid, csrftoken, user_agent, user_id = load_session_from_file()
    if not sessionid:
        console.print("[red]No session available. Please login first.[/red]")
        return
    for t in targets:
        try:
            tid = fetch_target_id(t, sessionid, csrftoken)
        except Exception as e:
            console.print(f"[red]Failed to resolve {t}: {e}[/red]")
            continue
        for report_type in report_order:
            ok, status = report_instagram(tid, sessionid, csrftoken, report_type, conf)
            _notify_each_report(conf, t, tid, report_type, ok, status)
            if status == "rate_limited":
                console.print("[yellow]Rate limited. Breaking...[/yellow]")
                return


# ---------------------- Lightweight Telegram Polling Bot ----------------------

class SimpleTelegramBot:
    def __init__(self, bot_token: str):
        self.bot_token = bot_token
        self.base = f"https://api.telegram.org/bot{bot_token}"
        self.offset = None
        self.running = False
        self.report_options = {
            "1": "Spam",
            "2": "Self",
            "3": "Drugs",
            "4": "Nudity",
            "5": "Violence",
            "6": "Hate",
            "7": "Bullying",
            "8": "Impersonation"
        }

    def _get_updates(self) -> List[dict]:
        params = {"timeout": 20}
        if self.offset:
            params["offset"] = self.offset
        try:
            r = requests.get(self.base + "/getUpdates", params=params, timeout=30)
            j = r.json()
            if j.get("ok"):
                return j.get("result", [])
        except Exception:
            pass
        return []

    def _send_msg(self, chat_id: str, text: str):
        try:
            requests.post(self.base + "/sendMessage", data={"chat_id": chat_id, "text": text})
        except Exception:
            pass

    def _process_update(self, u: dict):
        self.offset = max(self.offset or 0, u.get("update_id", 0) + 1)
        msg = u.get("message") or u.get("edited_message")
        if not msg:
            return
        chat = msg["chat"]
        chat_id = str(chat["id"])
        text = msg.get("text", "").strip()
        if not text:
            return
        parts = text.split()
        cmd = parts[0].lower()
        args = parts[1:]
        conf = load_config()

        if cmd == "/start":
            reply = (
                "Welcome to InstaRep Bot!\nCommands:\n"
                "/login <user> <pass>\n"
                "/addtargets <t1> <t2> ...\n"
                "/listtargets\n"
                "/report one <report_type> <runs_per_target>\n"
                "/report many <report_type> <count_per_target>\n"
                "/report ordered <comma_separated_types>\n"
            )
            self._send_msg(chat_id, reply)
            conf["settings"]["telegram_chat_id"] = chat_id
            save_config(conf)
            return

        if cmd == "/login":
            if len(args) < 2:
                self._send_msg(chat_id, "Usage: /login <username> <password>")
                return
            username, password = args[0], args[1]
            self._send_msg(chat_id, "Logging in...")
            sess = login_with_requests(username, password)
            if sess[0]:
                self._send_msg(chat_id, "Login successful and session stored.")
            else:
                self._send_msg(chat_id, "Login failed.")
            return

        if cmd == "/addtargets":
            if not args:
                self._send_msg(chat_id, "Usage: /addtargets <t1> <t2> ...")
                return
            add_targets_cli(args)
            self._send_msg(chat_id, f"Added {len(args)} targets.")
            return

        if cmd == "/listtargets":
            targets = conf.get("targets", [])
            if not targets:
                self._send_msg(chat_id, "No targets saved.")
                return
            text = "Stored targets:\n" + "\n".join(f"{i+1}. {t}" for i, t in enumerate(targets))
            self._send_msg(chat_id, text)
            return

        if cmd == "/report":
            if not args:
                self._send_msg(chat_id, "Usage: /report <mode> <params>")
                return
            mode = args[0].lower()
            if mode == "one":
                if len(args) < 3:
                    self._send_msg(chat_id, "Usage: /report one <report_type> <runs_per_target>")
                    return
                try:
                    report_type = int(args[1]); runs = int(args[2])
                except Exception:
                    self._send_msg(chat_id, "report_type and runs must be integers")
                    return
                tlist = conf.get("targets", [])
                threading.Thread(target=self._run_mode_thread, args=("one", tlist, report_type, runs, chat_id)).start()
                self._send_msg(chat_id, "Started 'one' reporting job in background.")
                return
            if mode == "many":
                if len(args) < 3:
                    self._send_msg(chat_id, "Usage: /report many <report_type> <count_per_target>")
                    return
                try:
                    report_type = int(args[1]); cnt = int(args[2])
                except Exception:
                    self._send_msg(chat_id, "report_type and count must be integers")
                    return
                tlist = conf.get("targets", [])
                threading.Thread(target=self._run_mode_thread, args=("many", tlist, report_type, cnt, chat_id)).start()
                self._send_msg(chat_id, "Started 'many' reporting job in background.")
                return
            if mode == "ordered":
                if len(args) < 2:
                    self._send_msg(chat_id, "Usage: /report ordered <comma_separated_types>")
                    return
                try:
                    order = [int(x.strip()) for x in args[1].split(",")]
                except Exception:
                    self._send_msg(chat_id, "Could not parse types. Example: /report ordered 4,1,8")
                    return
                tlist = conf.get("targets", [])
                threading.Thread(target=self._run_mode_thread, args=("ordered", tlist, order, None, chat_id)).start()
                self._send_msg(chat_id, "Started 'ordered' reporting job in background.")
                return
            self._send_msg(chat_id, "Unknown report mode. Supported: one, many, ordered")
            return

        if cmd == "/settoken":
            if len(args) < 1:
                self._send_msg(chat_id, "Usage: /settoken <bot_token>")
                return
            conf["settings"]["telegram_bot_token"] = args[0]
            save_config(conf)
            self._send_msg(chat_id, "Bot token saved to config.")
            return

        if cmd == "/setchatid":
            if len(args) < 1:
                self._send_msg(chat_id, "Usage: /setchatid <chat_id>")
                return
            conf["settings"]["telegram_chat_id"] = args[0]
            save_config(conf)
            self._send_msg(chat_id, "Chat id saved to config.")
            return

        self._send_msg(chat_id, "Unknown command. Send /start to see available commands.")

    def _run_mode_thread(self, mode: str, targets: List[str], arg1, arg2, reply_chat: str):
        conf = load_config()
        if mode == "one":
            report_type = arg1; runs = arg2
            mode_one_per_target_per_type(targets, report_type, runs, conf)
            self._send_msg(reply_chat, "'one' job finished.")
            return
        if mode == "many":
            report_type = arg1; cnt = arg2
            mode_many_per_type(targets, report_type, cnt, conf)
            self._send_msg(reply_chat, "'many' job finished.")
            return
        if mode == "ordered":
            order = arg1
            mode_ordered_report(targets, order, conf)
            self._send_msg(reply_chat, "'ordered' job finished.")
            return

    def start(self):
        console.print("[green]Telegram bot polling started... Press Ctrl+C to stop.[/green]")
        self.running = True
        while self.running:
            updates = self._get_updates()
            for u in updates:
                try:
                    self._process_update(u)
                except Exception:
                    pass


# ---------------------- Interactive Terminal UI ----------------------

class TerminalInterface:
    def __init__(self):
        self.conf = load_config()
        self.report_options = {
            "1": "Spam",
            "2": "Self",
            "3": "Drugs",
            "4": "Nudity",
            "5": "Violence",
            "6": "Hate",
            "7": "Bullying",
            "8": "Impersonation"
        }
        self.sessionid, self.csrftoken, self.user_agent, self.user_id = load_session_from_file()

    # def _logo(self, name="InstaReport"):
    #     if pyfiglet:
    #         banner = pyfiglet.figlet_format(name, font="slant")
    #         console.print(f"[bold red]{banner}[/bold red]")
    #     else:
    #         console.print(f"[bold red]{name}[/bold red]")
    def _logo(self, name="Ig Rep Anon"):
        try:
            # Get terminal width
            term_width = shutil.get_terminal_size(fallback=(80, 24)).columns

            # Generate banner with a wide font
            font = "slant"  # or "big", "doom", "standard"
            banner = pyfiglet.figlet_format(name, font=font)

            # Split into lines and pad each to full width
            lines = banner.rstrip().split('\n')
            padded_lines = []
            for line in lines:
                # Center the line and pad to full width
                padded = line.center(term_width)
                padded_lines.append(padded)

            # Join and print with full width
            full_banner = '\n'.join(padded_lines)
            console.print(f"[bold red]{full_banner}[/bold red]")

        except Exception as e:
            # Fallback if pyfiglet or terminal size fails
            fallback = name.center(shutil.get_terminal_size().columns)
            console.print(f"[bold red]{fallback}[/bold red]")
    def display_header(self):
        os.system("cls" if os.name == 'nt' else "clear")
        self._logo("Ig Rep Anon")
        console.print("Instagram Report Bot", style="bold cyan")
        console.print("Developer: Anon! | Instagram: @anon.olds!\n", style="Purple")

    def terminal_starter(self):
        self.conf = load_config()          # <-- your existing helper
        settings = self.conf.setdefault("settings", {})
        self.display_header()
        self.login_instagram()
        self.link_telegram_bot()

        # Targets
        self._manage_targets()
        # Modes menu
        self._modes_menu()
    def login_instagram(self):
        # Load or login
        if self.sessionid:
            valid, new_csrf = test_session(self.sessionid, self.user_agent or generate_user_agent())
            if valid:
                console.print("[green]saved session loaded.[/green]")
                if new_csrf:
                    self.csrftoken = new_csrf
            else:
                console.print("[red]Saved login expired. Login in manually...[/red]")
                self.sessionid = None

        if not self.sessionid:
            username = input("[-] Enter Username: ").strip()
            password = input("[-] Enter Password: ").strip()
            sess = login_with_requests(username, password)
            if not sess[0]:
                console.print("[red]Login failed. Exiting.[/red]")
                return
            self.sessionid, self.csrftoken, self.user_agent, self.user_id = sess
        self.display_header()
        console.print("Logged in as:",username, style="green")

    def link_telegram_bot(self):
        self.conf = load_config()          # <-- your existing helper
        settings = self.conf.setdefault("settings", {})
        # Telegram optional
        bot_token = settings.get("telegram_bot_token", "").strip()
        chat_id   = settings.get("telegram_chat_id",   "").strip()
        console.print(f"[green]Link Telegram Bot (one time setup) .[/green]")
        if not bot_token:
            bot_token = input("[-] Enter Telegram Bot Token (press Enter to skip): ").strip()
            if bot_token:
                self.conf["settings"]["telegram_bot_token"] = bot_token
        
        if bot_token and not chat_id:
            chat_id = input("[-] Enter Telegram Chat ID (press Enter to skip): ").strip()
            if chat_id:
                self.conf["settings"]["telegram_chat_id"] = chat_id
        elif bot_token and chat_id:
            console.print(f"[green]Telegram Bot loaded from config.[/green]")
        save_config(self.conf)
    def _manage_targets(self):
        while True:
            console.print("\nTargets:", style="bold cyan")
            conf = load_config()
            targets = conf.get("targets", [])
            if targets:
                for i, t in enumerate(targets):
                    console.print(f"{i+1}. {t}")
            else:
                console.print("No targets found.", style="yellow")
            console.print("\nOptions:   ", style="bold red")
            console.print("   1) Start Reporting\n   2) Switch logged-in account\n   3) Add targets\n   4) Remove target\n   5) Link Telegram Bot", style="cyan")
            choice = input("Select a number:  ").strip()
            if choice == "3":
                entries = input("Enter usernames separated by space: ").strip().split()
                add_targets_cli(entries)
            elif choice == "4":
                idx = input("Enter number to remove: ").strip()
                try:
                    i = int(idx) - 1
                    if 0 <= i < len(targets):
                        del targets[i]
                        conf["targets"] = targets
                        save_config(conf)
                        console.print("[green]Removed.[/green]")
                    else:
                        console.print("[red]Invalid number[/red]")
                except Exception:
                    console.print("[red]Invalid input[/red]")
            elif choice == "5":
                self.link_telegram_bot()
            elif choice == "2":
                self.login_instagram()
            else:
                break

    def _choose_report_type(self) -> int:
        options = {
            "1": "Spam", "2": "Self", "3": "Drugs", "4": "Nudity",
            "5": "Violence", "6": "Hate", "7": "Bullying", "8": "Impersonation"
        }
        console.print("Report types:", style="bold cyan")
        for k, v in options.items():
            console.print(f"    {k}. {v}")
        while True:
            choice = input("Choose a report type (1-8): ").strip()
            if choice in options:
                return int(choice)
            console.print("Invalid choice", style="red")

    def _modes_menu(self):
        conf = load_config()
        self.display_header()
        console.print(Text("CHOOSE REPORTER MODE", style="bold italic bright_blue"))

        targets = conf.get("targets", [])
        if not targets:
            console.print("[red]No targets to report. Please Add targets first.[/red]")
            for _ in range(3):
                time.sleep(1)
                print("returning to target management...")
            self._manage_targets()
        while True:
            console.print("\nModes:\n   1) Many reports -> one target\n   2) One report -> many targets\n   3) One report to one target\n   4) Mass report to a target\n   5) Ordered reports (list reports)\n   0) Exit", style="bold cyan")
            m = input("Select mode: ").strip()
            if m == "0":
                break
            if m == "1":
                # Many to one
                self.display_header()
                console.print(Text("MODE 1 SELECTED : Many reports to one target", style="bold italic bright_blue"))
                for i, t in enumerate(targets):
                    console.print(f"{i}. {t}")
                idx = input("Select a target: ").strip()
                try:
                    idx_i = int(idx)
                    if not (0 <= idx_i < len(targets)):
                        console.print("[red]Invalid index[/red]")
                        continue
                except Exception:
                    console.print("[red]Invalid input[/red]")
                    continue
                report_type = self._choose_report_type()
                num = int(input("Enter number of reports: ").strip())
                tid = fetch_target_id(targets[idx_i], self.sessionid, self.csrftoken)
                for _ in range(num):
                    ok, status = report_instagram(tid, self.sessionid, self.csrftoken, report_type, conf)
                    _notify_each_report(conf, targets[idx_i], tid, report_type, ok, status)
                    if status == "rate_limited":
                        console.print("[yellow]Rate limited. Returning to menu.[/yellow]")
                        break
            elif m == "2":
                self.display_header()
                console.print(Text("MODE 2 SELECED: One report for many targets", style="bold italic bright_blue"))
                report_type = self._choose_report_type()
                for t in targets:
                    try:
                        tid = fetch_target_id(t, self.sessionid, self.csrftoken)
                        ok, status = report_instagram(tid, self.sessionid, self.csrftoken, report_type, conf)
                        _notify_each_report(conf, t, tid, report_type, ok, status)
                        if status == "rate_limited":
                            return
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")
            elif m == "3":
                self.display_header()
                console.print(Text("MODE 3 SELECTED: One report to for each target", style="bold italic bright_blue"))
                for t in targets:
                    try:
                        tid = fetch_target_id(t, self.sessionid, self.csrftoken)
                        for rt in range(1, 9):
                            ok, status = report_instagram(tid, self.sessionid, self.csrftoken, rt, conf)
                            _notify_each_report(conf, t, tid, rt, ok, status)
                            if status == "rate_limited":
                                return
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")
            elif m == "4":
                self.display_header()
                console.print(Text("MODE 4 SELECTED: Mass report to each target", style="bold italic bright_blue"))
                num_per_type = int(input("Number of reports per type: ").strip())
                for t in targets:
                    try:
                        tid = fetch_target_id(t, self.sessionid, self.csrftoken)
                        for rt in range(1, 9):
                            for _ in range(num_per_type):
                                ok, status = report_instagram(tid, self.sessionid, self.csrftoken, rt, conf)
                                _notify_each_report(conf, t, tid, rt, ok, status)
                                if status == "rate_limited":
                                    return
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")
            elif m == "5":
                self.display_header()
                console.print(Text("MODE 5 SELECTED: Send reports in selected order to targets", style="bold italic bright_blue"))
                console.print(f"[yellow]Enter comma-separated according to method. Example ( 2x spam=1,1 and 4x hate=6,6,6,6) ) [/yellow]")
                for key, value in self.report_options.items():
                    console.print(f"[yellow]{key} - {value}[/yellow]")
                order = input("Enter method: ").strip().split(",")
                try:
                    order = [int(x.strip()) for x in order]
                except Exception:
                    console.print("[red]Invalid order[/red]")
                    continue
                mode_ordered_report(targets, order, conf)
            else:
                console.print("[red]Invalid choice[/red]")


# ---------------------- CLI Entrypoint ----------------------

def main():
    # ─────── LICENSE CHECK FIRST ───────
    user_role = require_license()      # ← ADD THIS LINE
    # ───────────────────────────────────

    parser = argparse.ArgumentParser(description="InstaRep Combined - CLI + Interactive Terminal UI")
    parser.add_argument("--interactive", action="store_true", help="Start interactive terminal UI")
    sub = parser.add_subparsers(dest="command")

    p_login = sub.add_parser("login", help="Login via credentials and save session")
    p_login.add_argument("--username", required=True)
    p_login.add_argument("--password", required=True)

    p_add = sub.add_parser("add-targets", help="Add one or more targets (username or id)")
    p_add.add_argument("targets", nargs="+", help="targets (usernames or numeric ids)")

    sub.add_parser("list-targets", help="List saved targets")

    p_report = sub.add_parser("report", help="Run a report job locally")
    p_report.add_argument("--mode", choices=["one", "many", "ordered"], required=True)
    p_report.add_argument("--report-type", type=int, help="Report type id (1-8)")
    p_report.add_argument("--runs", type=int, default=1, help="runs per target (for 'one' mode)")
    p_report.add_argument("--count", type=int, default=1, help="count per target (for 'many' mode)")
    p_report.add_argument("--order", type=str, help="comma separated types for ordered mode (e.g. 4,1,8)")

    p_bot = sub.add_parser("start-bot", help="Start lightweight Telegram bot (polling)")
    p_bot.add_argument("--bot-token", type=str, help="Telegram bot token (optional if saved in config)")

    p_cfg = sub.add_parser("set", help="Set config values")
    p_cfg.add_argument("--telegram-bot-token", type=str)
    p_cfg.add_argument("--telegram-chat-id", type=str)

    args = parser.parse_args()
    conf = load_config()

    # If interactive flag or no args -> interactive mode
    if args.interactive or (len(sys.argv) == 1):
        ti = TerminalInterface()
        ti.terminal_starter()
        return

    if args.command == "login":
        sess = login_with_requests(args.username, args.password)
        if sess[0]:
            console.print("[green]Login saved in config.[/green]")
        else:
            console.print("[red]Login failed.[/red]")
        return

    if args.command == "add-targets":
        add_targets_cli(args.targets)
        return

    if args.command == "list-targets":
        list_targets_cli()
        return

    if args.command == "report":
        conf = load_config()
        targets = conf.get("targets", [])
        if not targets:
            console.print("[red]No targets saved. Use add-targets first or use the interactive UI to add them.[/red]")
            return
        if args.mode == "one":
            if not args.report_type:
                console.print("[red]--report-type is required for 'one' mode[/red]")
                return
            mode_one_per_target_per_type(targets, args.report_type, args.runs, conf)
            return
        if args.mode == "many":
            if not args.report_type:
                console.print("[red]--report-type is required for 'many' mode[/red]")
                return
            mode_many_per_type(targets, args.report_type, args.count, conf)
            return
        if args.mode == "ordered":
            if not args.order:
                console.print("[red]--order is required for 'ordered' mode (e.g. --order 4,1,8)[/red]")
                return
            try:
                order = [int(x.strip()) for x in args.order.split(",")]
            except Exception:
                console.print("[red]Could not parse --order[/red]")
                return
            mode_ordered_report(targets, order, conf)
            return

    if args.command == "start-bot":
        bot_token = args.bot_token or conf.get("settings", {}).get("telegram_bot_token")
        if not bot_token:
            console.print("[red]No bot token supplied. Provide --bot-token or save in config via set --telegram-bot-token <token>[/red]")
            return
        if args.bot_token:
            conf["settings"]["telegram_bot_token"] = args.bot_token
            save_config(conf)
        bot = SimpleTelegramBot(bot_token)
        try:
            bot.start()
        except KeyboardInterrupt:
            console.print("[yellow]Bot stopped by user.[/yellow]")
        return

    if args.command == "set":
        if args.telegram_bot_token:
            conf["settings"]["telegram_bot_token"] = args.telegram_bot_token
        if args.telegram_chat_id:
            conf["settings"]["telegram_chat_id"] = args.telegram_chat_id
        save_config(conf)
        console.print("[green]Config updated.[/green]")
        return

    parser.print_help()

if __name__ == "__main__":
    main()
