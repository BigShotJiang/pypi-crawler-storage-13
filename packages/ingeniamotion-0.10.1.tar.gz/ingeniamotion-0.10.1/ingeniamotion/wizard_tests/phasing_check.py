import time
from enum import IntEnum
from typing import TYPE_CHECKING, Optional

import ingenialogger
from typing_extensions import override

from ingeniamotion.enums import OperationMode, PhasingMode, SensorType, SeverityLevel
from ingeniamotion.metaclass import DEFAULT_AXIS, DEFAULT_SERVO
from ingeniamotion.wizard_tests.base_test import BaseTest, LegacyDictReportType, TestError

if TYPE_CHECKING:
    from ingeniamotion import MotionController


class PhasingCheck(BaseTest[LegacyDictReportType]):
    """Phasing check test class."""

    MAX_ALLOWED_ANGLE_MOVE = 15
    INITIAL_ANGLE = 180.0
    INITIAL_ANGLE_HALLS = 240.0
    CURRENT_SLOPE = 0.4

    PHASING_ACCURACY_REGISTER = "COMMU_PHASING_ACCURACY"
    PHASING_TIMEOUT_REGISTER = "COMMU_PHASING_TIMEOUT"
    MAX_CURRENT_ON_PHASING_SEQUENCE_REGISTER = "COMMU_PHASING_MAX_CURRENT"

    BACKUP_REGISTERS = ["DRV_OP_CMD", "CL_CUR_Q_SET_POINT", "CL_CUR_D_SET_POINT"]

    class ResultType(IntEnum):
        """Test result."""

        SUCCESS = 0
        WRONG_PHASING = -1

    result_description = {
        ResultType.SUCCESS: "Motor is well phased.",
        ResultType.WRONG_PHASING: "Phasing check failed. Wrong motor phasing.",
    }

    def __init__(
        self,
        mc: "MotionController",
        servo: str = DEFAULT_SERVO,
        axis: int = DEFAULT_AXIS,
        logger_drive_name: Optional[str] = None,
    ) -> None:
        super().__init__()
        self.mc = mc
        self.servo = servo
        self.axis = axis
        if logger_drive_name is None:
            self.logger = ingenialogger.get_logger(__name__, axis=axis, drive=mc.servo_name(servo))
        else:
            self.logger = ingenialogger.get_logger(__name__, axis=axis, drive=logger_drive_name)
        self.backup_registers_names = self.BACKUP_REGISTERS

    @override
    @BaseTest.stoppable
    def setup(self) -> None:
        self.mc.motion.motor_disable(servo=self.servo, axis=self.axis)
        self.mc.motion.set_operation_mode(OperationMode.CURRENT, servo=self.servo, axis=self.axis)
        self.mc.motion.set_current_quadrature(0, servo=self.servo, axis=self.axis)
        self.mc.motion.set_current_direct(0, servo=self.servo, axis=self.axis)

    @BaseTest.stoppable
    def __vary_current_and_check_position(self, current_sign: int, max_current: int) -> ResultType:
        self.logger.info(
            f"Slowly increasing Current Direct Set-point until {current_sign * max_current} A"
        )
        init_pos = self.mc.motion.get_actual_position(servo=self.servo, axis=self.axis)
        pos_resolution = self.mc.configuration.get_position_feedback_resolution(
            servo=self.servo, axis=self.axis
        )
        total_time = max_current / self.CURRENT_SLOPE
        try:
            for value in self.mc.motion.ramp_generator(
                0, current_sign * max_current, total_time, interval=0.1
            ):
                self.mc.motion.set_current_direct(value, servo=self.servo, axis=self.axis)
                if not self.__validate_motion_state(init_pos, pos_resolution):
                    return self.ResultType.WRONG_PHASING
        finally:
            self.mc.motion.set_current_direct(0, servo=self.servo, axis=self.axis)
        return self.ResultType.SUCCESS

    def __validate_motion_state(self, init_pos: int, pos_resolution: int) -> bool:
        if self.mc.errors.is_fault_active(servo=self.servo, axis=self.axis):
            raise TestError("The drive is in fault state")
        return self.__check_position(init_pos, pos_resolution)

    @BaseTest.stoppable
    def __check_position(self, init_pos: int, resolution: int) -> bool:
        current_pos = self.mc.motion.get_actual_position(servo=self.servo, axis=self.axis)
        allowed_move = resolution * self.MAX_ALLOWED_ANGLE_MOVE / 360
        result_check = float(abs(current_pos - init_pos)) < allowed_move
        return result_check

    @BaseTest.stoppable
    def __analyse_phasing_bit_and_force_to_high(self) -> None:
        if not self.mc.configuration.is_commutation_feedback_aligned(
            servo=self.servo, axis=self.axis
        ):
            phasing_mode = self.mc.configuration.get_phasing_mode(servo=self.servo, axis=self.axis)
            if phasing_mode == PhasingMode.FORCED:
                self.__forced_phasing()
            else:
                self.__not_forced_phasing()

    @BaseTest.stoppable
    def __define_phasing_steps(self) -> int:
        pha_accuracy = self.mc.communication.get_register(
            self.PHASING_ACCURACY_REGISTER, servo=self.servo, axis=self.axis
        )
        if not isinstance(pha_accuracy, int):
            raise TypeError(f"{self.PHASING_ACCURACY_REGISTER} has to be an integer")
        delta = 3 * pha_accuracy / 1000
        ref_feedback = self.mc.configuration.get_reference_feedback(
            servo=self.servo, axis=self.axis
        )

        num_of_steps = 1
        if ref_feedback == SensorType.HALLS:
            actual_angle = self.INITIAL_ANGLE_HALLS
        else:
            actual_angle = self.INITIAL_ANGLE
        while actual_angle > delta:
            actual_angle = actual_angle / 2
            num_of_steps += 1
        return num_of_steps

    @BaseTest.stoppable
    def __forced_phasing(self) -> None:
        num_of_steps = self.__define_phasing_steps()
        phasing_bit_latched = False
        phasing_timeout = self.mc.communication.get_register(
            self.PHASING_TIMEOUT_REGISTER, servo=self.servo, axis=self.axis
        )
        if not isinstance(phasing_timeout, int):
            raise TypeError(f"{self.PHASING_TIMEOUT_REGISTER} has to be an integer")
        timeout = time.time() + (num_of_steps * phasing_timeout / 1000)
        while time.time() < timeout:
            self.stoppable_sleep(0.1)
            if self.mc.configuration.is_commutation_feedback_aligned(
                servo=self.servo, axis=self.axis
            ):
                phasing_bit_latched = True
                break
        if not phasing_bit_latched:
            raise TestError("Motor phasing fail")

    @BaseTest.stoppable
    def __not_forced_phasing(self) -> None:
        self.logger.info(
            "Increasing slowly current quadrature set-point until phasing bit is latched"
        )
        phasing_bit_latched = False
        i = 0.0
        delta_i = 0.1
        while not phasing_bit_latched:
            if not self.mc.configuration.is_motor_enabled(servo=self.servo, axis=self.axis):
                self.mc.errors.get_last_buffer_error(servo=self.servo, axis=self.axis)
                self.show_error_message()
            self.mc.motion.set_current_quadrature(i, servo=self.servo, axis=self.axis)
            self.stoppable_sleep(0.1)
            i += delta_i
            if self.mc.configuration.is_commutation_feedback_aligned(
                servo=self.servo, axis=self.axis
            ):
                phasing_bit_latched = True
        self.mc.motion.set_current_quadrature(0, servo=self.servo, axis=self.axis)
        self.logger.info("Wait until motor has stopped")
        self.mc.motion.wait_for_velocity(0, servo=self.servo, axis=self.axis)

    @BaseTest.stoppable
    def __check_motor_commutation(self) -> ResultType:
        phasing_current = self.mc.communication.get_register(
            self.MAX_CURRENT_ON_PHASING_SEQUENCE_REGISTER, servo=self.servo, axis=self.axis
        )
        if not isinstance(phasing_current, float):
            raise TypeError(f"{self.MAX_CURRENT_ON_PHASING_SEQUENCE_REGISTER} has to be an integer")
        max_test_current = round(phasing_current, 2)
        ref_feedback = self.mc.configuration.get_reference_feedback(
            servo=self.servo, axis=self.axis
        )
        comm_feedback = self.mc.configuration.get_commutation_feedback(
            servo=self.servo, axis=self.axis
        )

        # With Halls only, this test makes no sense
        if ref_feedback == SensorType.HALLS and comm_feedback == SensorType.HALLS:
            return self.ResultType.SUCCESS
        result = self.__vary_current_and_check_position(1, max_test_current)
        if result != self.ResultType.SUCCESS:
            return result
        return self.__vary_current_and_check_position(-1, max_test_current)

    @override
    @BaseTest.stoppable
    def loop(self) -> ResultType:
        self.mc.motion.motor_enable(servo=self.servo, axis=self.axis)
        self.__analyse_phasing_bit_and_force_to_high()
        return self.__check_motor_commutation()

    @override
    def teardown(self) -> None:
        self.mc.motion.motor_disable(servo=self.servo, axis=self.axis)

    @override
    def get_result_msg(self, output: ResultType) -> str:
        return self.result_description[output]

    @override
    def get_result_severity(self, output: ResultType) -> SeverityLevel:
        if output < self.ResultType.SUCCESS:
            return SeverityLevel.FAIL
        else:
            return SeverityLevel.SUCCESS
