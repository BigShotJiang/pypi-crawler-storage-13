"""macholib_tests package"""
