# cal

Simple calculator package for Python.

## Usage

```python
import cal

print(cal.add(2, 3))
