from typing import List , Dict , Optional

class Library:
    def __init__(self) -> None:
        self._books : List[Dict[str , str]] = []

    def add_book(self , title : str, author : str) -> None :
        book = {'title' : title.strip() , 'author' : author.strip()}

        self._books.append(book)

    def remove_book(self , title : str) -> bool :
        title = title.strip().lower()

        for i , book in enumerate(self._books) :
            if book['title'].lower() == title :
                del self._books[i]
                return True
        return False
    
    def search_book(self , title : str) -> List[Dict[str , str]] :

        q = title.strip().lower()
        return [b for b in self._books if q in b['title'].lower()]
    
    def show_books(self) -> List[Dict[str , str]] :
        return self._books
        
