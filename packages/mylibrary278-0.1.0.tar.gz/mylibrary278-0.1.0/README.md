# MyLibrary

A simple Python library management system.

## Local Installation

```bash
pip install .

```

<!-- ctrl + shift + v -->