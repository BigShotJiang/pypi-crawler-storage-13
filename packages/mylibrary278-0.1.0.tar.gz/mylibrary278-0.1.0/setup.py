from setuptools import setup, find_packages

setup(
    name="mylibrary278",               
    version="0.1.0",
    description="A simple library management system (testtt)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="fafa no",
    author_email="fatemehnourani278@gmail.com",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],              
    include_package_data=True,
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
)
