# Himpunan Matdis
Library ini mengimplementasikan operasi himpunan menggunakan list tanpa class set.

## Instalasi
pip install himpunan-matdis

## Penggunaan
from himpunan import Himpunan
h1 = Himpunan(1,2,3)
print(h1)
