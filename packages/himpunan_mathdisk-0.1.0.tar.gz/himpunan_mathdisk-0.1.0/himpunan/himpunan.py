class Himpunan:
    """
    Implementasi Himpunan menggunakan list tanpa menggunakan class set.
    """

    # Constructor
    def __init__(self, *args):
        self.data = []
        for item in args:
            if item not in self.data:
                self.data.append(item)

    def __repr__(self):
        return '{' + ', '.join(str(x) for x in self.data) + '}'

    def __len__(self):
        return len(self.data)

    def __contains__(self, item):
        return item in self.data

    def __iadd__(self, item):
        if item not in self.data:
            self.data.append(item)
        return self

    def __isub__(self, item):
        if item in self.data:
            self.data.remove(item)
        return self

    def __eq__(self, other):
        return len(self.data) == len(other.data) and all(x in other.data for x in self.data)

    def __le__(self, other):
        return all(item in other.data for item in self.data)

    def __lt__(self, other):
        return self <= other and self != other

    def __ge__(self, other):
        return all(item in self.data for item in other.data)

    def __floordiv__(self, other):
        return self == other

    def __truediv__(self, other):
        hasil = [item for item in self.data if item in other.data]
        return Himpunan(*hasil)

    def __add__(self, other):
        hasil = self.data.copy()
        for item in other.data:
            if item not in hasil:
                hasil.append(item)
        return Himpunan(*hasil)

    def __sub__(self, other):
        hasil = [item for item in self.data if item not in other.data]
        return Himpunan(*hasil)

    def __mul__(self, other):
        kiri = [item for item in self.data if item not in other.data]
        kanan = [item for item in other.data if item not in self.data]
        return Himpunan(*(kiri + kanan))

    def __pow__(self, other):
        return [(a, b) for a in self.data for b in other.data]

    def Komplemen(self, semesta):
        hasil = [item for item in semesta.data if item not in self.data]
        return Himpunan(*hasil)

    def __abs__(self):
        return 2 ** len(self.data)

    def ListKuasa(self):
        subsets = []
        n = len(self.data)

        # Bitmasking method
        for mask in range(1 << n):
            subset = Himpunan()
            for i in range(n):
                if mask & (1 << i):
                    subset += self.data[i]
            subsets.append(subset)

        return subsets
