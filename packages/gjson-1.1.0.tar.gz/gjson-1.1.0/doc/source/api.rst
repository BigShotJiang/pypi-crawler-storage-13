API
===

.. automodule:: gjson
