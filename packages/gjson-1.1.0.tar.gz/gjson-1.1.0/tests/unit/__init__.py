"""gjson unit tests."""
