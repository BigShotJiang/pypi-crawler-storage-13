"""
VeriskGO SDK – Public API
This exposes only the clean, stable functions you want users to import.
"""

# Trace Manager
from .trace_manager import TraceManager

# Import the track_function decorator
from .trace_manager import track_function

# Export SQS sender
from .sqs import send_to_sqs

# User profile span helper
from .user import user_profile_span

# Models
from .models import UserProfile

__all__ = [
    "TraceManager",
    "track_function",
    "send_to_sqs",
    "user_profile_span",
    "UserProfile",
]
