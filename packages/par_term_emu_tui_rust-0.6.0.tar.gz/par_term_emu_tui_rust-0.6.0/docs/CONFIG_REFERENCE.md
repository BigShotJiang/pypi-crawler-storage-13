# TUI Configuration Reference

Comprehensive reference for par-term-emu-tui-rust TUI application configuration options and settings.

## Table of Contents

- [Overview](#overview)
- [Configuration File Location](#configuration-file-location)
- [Currently Implemented Settings](#currently-implemented-settings)
- [Selection & Clipboard](#selection--clipboard)
- [Mouse & Pointer](#mouse--pointer)
- [Cursor Configuration](#cursor-configuration)
- [Scrollback Configuration](#scrollback-configuration)
- [Paste Behavior](#paste-behavior)
- [Focus & Interaction](#focus--interaction)
- [Security Settings](#security-settings)
- [Theme Configuration](#theme-configuration)
- [Notification Settings](#notification-settings)
- [Screenshot Configuration](#screenshot-configuration)
- [Recording Configuration](#recording-configuration)
- [Hyperlinks & URLs](#hyperlinks--urls)
- [UI Elements](#ui-elements)
- [Shell Behavior](#shell-behavior)
- [Keyboard Protocol (KITTY)](#keyboard-protocol-kitty)
- [Related Documentation](#related-documentation)

---

## Overview

The TUI application settings are stored in a YAML configuration file and control the application experience. These settings are managed by the `TuiConfig` Python dataclass.

**Configuration layers:**
- **TUI Layer** (this document): Application-level settings managed by `TuiConfig` in Python
- **Terminal Core**: Low-level terminal emulator settings (see [par-term-emu-core-rust documentation](https://github.com/paulrobello/par-term-emu-core-rust))

**Key Distinction**: TUI settings control the *application experience* (selection, clipboard, themes), while core settings control the *terminal emulation behavior* (VT modes, color parsing).

---

## Configuration File Location

**XDG-compliant path:**
- Linux/macOS: `~/.config/par-term-emu-tui-rust/config.yaml`
- Configuration is type-safe with Python dataclasses
- Backward compatible (new fields use defaults)
- Auto-created on first run with default values

### Editing Configuration

**Built-in Config Editor (Recommended):**

Press **Alt+Ctrl+Shift+C** while the TUI is running to open the interactive config editor:
- **Syntax highlighting**: YAML syntax highlighting with Monokai theme
- **Live validation**: Checks YAML syntax before saving
- **Auto-creation**: Creates config file with defaults if it doesn't exist
- **Keyboard shortcuts**:
  - `Ctrl+S` or click "Save" button to save changes
  - `Escape` or click "Cancel" to discard changes
- **Line numbers**: Easy navigation with line numbers
- **Tab behavior**: Smart indentation for YAML editing

**Manual Editing:**

```bash
# Edit with your preferred editor
$EDITOR ~/.config/par-term-emu-tui-rust/config.yaml

# Or use command-line flag
par-term-emu-tui-rust --init-config  # Creates default config
```

### Configuration Safety & Backup

**Automatic Backups (v0.4.0+):**
- Every config save creates a timestamped backup: `config.yaml.backup.YYYYMMDD_HHMMSS`
- Backups stored in same directory as config file
- UTC timestamps for consistency across timezones
- Useful for recovering from configuration errors

**Validation & Type Safety:**
- All values validated for proper types (int, float, bool, str, list, tuple)
- Numeric values automatically converted from YAML strings
- Range validation and clamping:
  - Float ranges (0.0-1.0) for `minimum_contrast`, `screenshot_minimum_contrast`
  - Positive/non-negative validation for numeric settings
  - RGB tuple validation for color values
  - Enum validation for `theme` and `screenshot_format`
- Invalid values automatically corrected with warnings

**Interactive Recovery (v0.4.0+):**

When config parsing fails, the TUI prompts for recovery options (in interactive mode):
1. **Reset to defaults** - Start fresh with default configuration
2. **Restore from backup** - Select from available timestamped backups
3. **View all backups** - List all available backup files
4. **Exit** - Exit without loading config

Example:
```
Failed to parse config: invalid YAML syntax

Choose recovery option:
1. Reset to defaults
2. Restore from backup
3. View all backups
4. Exit
```

**Restart Notification:**
- After saving config, a warning toast appears: "Restart the TUI for changes to take effect"
- Ensures users are aware that config changes require application restart

---

## Currently Implemented Settings

**Implementation Status**:
- ✅ **56 options fully implemented**

| Setting | Config Key | Default | Notes |
|---------|-----------|---------|-------|
| Auto-copy selection | `auto_copy_selection` | `true` | Copies on double/triple-click and shift+drag |
| Keep selection after copy | `keep_selection_after_copy` | `true` | iTerm2-like behavior |
| Expose clipboard to apps | `expose_system_clipboard` | `true` | OSC 52 clipboard access |
| Copy trailing newline | `copy_trailing_newline` | `false` | Adds \\n when copying lines |
| Word characters | `word_characters` | `"/-+\\~_."` | iTerm2-compatible word boundaries for double-click |
| Triple-click wrapped lines | `triple_click_selects_wrapped_lines` | `true` | Intelligent line selection following wraps |
| Scrollback lines | `scrollback_lines` | `10000` | Configurable scrollback buffer |
| Max scrollback (safety) | `max_scrollback_lines` | `100000` | Safety limit for unlimited |
| Cursor blink enabled | `cursor_blink_enabled` | `false` | Cursor blinking with timer |
| Cursor blink rate | `cursor_blink_rate` | `0.5` | Configurable blink interval |
| Cursor style | `cursor_style` | `"blinking_block"` | Block/underline/bar with blink variants |
| Paste chunk size | `paste_chunk_size` | `0` | Chunked paste for large content |
| Paste chunk delay | `paste_chunk_delay_ms` | `10` | Delay between chunks |
| Paste warn size | `paste_warn_size` | `100000` | Warn before large paste |
| Focus follows mouse | `focus_follows_mouse` | `false` | Auto-focus on mouse enter |
| Middle-click paste | `middle_click_paste` | `true` | Paste on middle mouse button |
| Mouse wheel scroll lines | `mouse_wheel_scroll_lines` | `3` | Lines to scroll per wheel tick |
| Disable insecure sequences | `disable_insecure_sequences` | `false` | Blocks OSC 8/52/9/777 and Sixel when enabled |
| Accept OSC 7 | `accept_osc7` | `true` | Directory tracking via shell integration |
| Visual bell enabled | `visual_bell_enabled` | `true` | Shows bell icon (🔔) in header on BEL character |
| Theme | `theme` | `"dark-background"` | Color theme name |
| Bold brightening | `bold_brightening` | `false` | Use bright colors (8-15) for bold text with colors 0-7 |
| Minimum contrast | `minimum_contrast` | `0.0` | Live display contrast adjustment (0.0-1.0, iTerm2-compatible) |
| Faint text alpha | `faint_text_alpha` | `0.5` | Alpha multiplier for faint/dim text (0.0-1.0) |
| Show notifications | `show_notifications` | `true` | Display OSC 9/777 notifications |
| Notification timeout | `notification_timeout` | `5` | Notification display duration (seconds) |
| Notification bell desktop | `notification_bell_desktop` | `false` | Forward BEL to desktop notification center |
| Notification bell sound | `notification_bell_sound` | `0` | Volume (0-100) for backend bell audio |
| Notification bell visual | `notification_bell_visual` | `true` | Enable backend visual bell overlay |
| Notification activity enabled | `notification_activity_enabled` | `false` | Alert on activity after inactivity |
| Notification activity threshold | `notification_activity_threshold` | `10` | Seconds of inactivity before activity alert |
| Notification silence enabled | `notification_silence_enabled` | `false` | Alert after prolonged silence |
| Notification silence threshold | `notification_silence_threshold` | `300` | Seconds of silence before alert |
| Notification max buffer | `notification_max_buffer` | `64` | Max OSC 9/777 notifications buffered |
| Clipboard max sync events | `clipboard_max_sync_events` | `64` | Max clipboard sync events retained |
| Clipboard max event bytes | `clipboard_max_event_bytes` | `2048` | Max bytes per clipboard sync event |
| Screenshot directory | `screenshot_directory` | `None` | Directory for screenshots |
| Screenshot format | `screenshot_format` | `"png"` | Format: png, jpeg, svg, bmp, html |
| Screenshot minimum contrast | `screenshot_minimum_contrast` | `null` | Auto-contrast override (null inherits `minimum_contrast`) |
| Open screenshot after capture | `open_screenshot_after_capture` | `false` | Auto-open with system viewer |
| Recording directory | `recording_directory` | `None` | Directory for recordings (auto-detect if None) |
| Recording format | `recording_format` | `"asciicast"` | Format: asciicast, json |
| Recording title template | `recording_title_template` | `"Terminal Session {timestamp}"` | Title template with {timestamp} placeholder |
| Recording auto-export on stop | `recording_auto_export_on_stop` | `true` | Automatically export when recording stopped |
| Open recording after export | `open_recording_after_export` | `false` | Auto-open with default app after export |
| Exit on shell exit | `exit_on_shell_exit` | `true` | Exit TUI when shell exits |
| Clickable URLs | `clickable_urls` | `true` | Enable clicking URLs to open in browser |
| Link color | `link_color` | `[100, 150, 255]` | RGB color for hyperlinks (blue) |
| URL modifier key | `url_modifier` | `"ctrl"` | Required modifier: none, ctrl, shift, alt |
| Allowed URL schemes | `allowed_url_schemes` | `["http", "https", ...]` | Permitted URL schemes for clickable links |
| Warn on unknown scheme | `warn_on_unknown_url_scheme` | `true` | Warn when blocking unsupported schemes |
| Search match color | `search_match_color` | `[255, 255, 0]` | RGB color for search highlights (yellow) |
| Show status bar | `show_status_bar` | `true` | Show/hide status bar at bottom |
| Keyboard protocol enabled | `keyboard_protocol_enabled` | `false` | Enable KITTY keyboard protocol |
| Keyboard protocol flags | `keyboard_protocol_flags` | `1` | KITTY protocol feature flags (1=disambiguate) |
| Keyboard protocol auto-detect | `keyboard_protocol_auto_detect` | `false` | Auto-enable when apps request protocol |

---

## Selection & Clipboard

### Overview

These settings control how text selection and clipboard operations work in the TUI.

### Selection Behavior Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `auto_copy_selection` | `bool` | `true` | Automatically copy selected text to clipboard |
| `keep_selection_after_copy` | `bool` | `true` | Keep text highlighted after copying |
| `copy_trailing_newline` | `bool` | `false` | Include trailing newline when copying full lines |
| `word_characters` | `str` | `"/-+\\~_."` | Characters considered part of a word for double-click selection (iTerm2-compatible) |
| `triple_click_selects_wrapped_lines` | `bool` | `true` | Triple-click selects full wrapped lines vs just visible line |

### Clipboard Access

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `expose_system_clipboard` | `bool` | `true` | Allow applications to access clipboard via OSC 52 |

**Security Note**: OSC 52 clipboard write access is controlled here.

### Example Configuration

```yaml
# Selection & Clipboard
auto_copy_selection: true
keep_selection_after_copy: true
expose_system_clipboard: true
copy_trailing_newline: false
word_characters: "/-+\\~_."  # iTerm2-compatible (for URL-friendly: "-_.~:/?#[]@!$&'()*+,;=")
triple_click_selects_wrapped_lines: true
```

---

## Mouse & Pointer

### Mouse Behavior Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `focus_follows_mouse` | `bool` | `false` | Automatically focus terminal on mouse enter |
| `middle_click_paste` | `bool` | `true` | Paste on middle mouse button click (PRIMARY selection on Linux) |
| `mouse_wheel_scroll_lines` | `int` | `3` | Number of lines to scroll per mouse wheel tick |

### Example Configuration

```yaml
# Mouse & Focus
focus_follows_mouse: false       # Don't auto-focus on hover
middle_click_paste: true         # Enable middle-click paste
mouse_wheel_scroll_lines: 3      # Scroll 3 lines per tick
```

---

## Cursor Configuration

### Cursor Visual Settings

| Setting | Type | Default | Options | Description |
|---------|------|---------|---------|-------------|
| `cursor_blink_enabled` | `bool` | `false` | - | Enable cursor blinking animation |
| `cursor_blink_rate` | `float` | `0.5` | > 0 | Blink interval in seconds |
| `cursor_style` | `str` | `"blinking_block"` | See below | Cursor appearance |

### Cursor Style Options

- `"block"` - Solid block cursor
- `"blinking_block"` - Blinking block cursor
- `"underline"` - Solid underline cursor
- `"blinking_underline"` - Blinking underline cursor
- `"bar"` - Solid vertical bar cursor
- `"blinking_bar"` - Blinking vertical bar cursor

### Example Configuration

```yaml
# Cursor
cursor_blink_enabled: true
cursor_blink_rate: 0.5  # 500ms
cursor_style: "blinking_block"
```

---

## Scrollback Configuration

### Scrollback Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `scrollback_lines` | `int` | `10000` | Number of lines to keep in scrollback (0 = unlimited) |
| `max_scrollback_lines` | `int` | `100000` | Safety limit when unlimited is enabled |

**Notes:**
- `scrollback_lines = 0` enables unlimited scrollback (up to `max_scrollback_lines`)
- Scrollback is only available in the primary screen (not alternate screen)
- Memory usage: ~100 bytes per line (approximate)

### Example Configuration

```yaml
# Scrollback
scrollback_lines: 10000      # Keep 10k lines
max_scrollback_lines: 100000 # Safety limit
```

---

## Paste Behavior

### Paste Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `paste_chunk_size` | `int` | `0` | Paste in chunks of N bytes (0 = no chunking) |
| `paste_chunk_delay_ms` | `int` | `10` | Delay between chunks in milliseconds |
| `paste_warn_size` | `int` | `100000` | Warn before pasting more than N bytes |

**Chunked Paste**: Useful for large clipboard content that might overwhelm the shell or application.

### Example Configuration

```yaml
# Paste
paste_chunk_size: 0           # No chunking by default
paste_chunk_delay_ms: 10      # 10ms delay if chunking enabled
paste_warn_size: 100000       # Warn on >100KB pastes
```

---

## Focus & Interaction

### Focus Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `focus_follows_mouse` | `bool` | `false` | Auto-focus terminal on mouse enter |

### Example Configuration

```yaml
# Focus
focus_follows_mouse: false
```

---

## Security Settings

### Security Configuration

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `disable_insecure_sequences` | `bool` | `false` | Block potentially dangerous escape sequences |
| `accept_osc7` | `bool` | `true` | Accept OSC 7 directory tracking |

### Disabled Sequences When `disable_insecure_sequences = true`

When enabled, the following escape sequences are blocked by the terminal core:
- **OSC 8** - Hyperlinks (clickable URLs in terminal output)
- **OSC 52** - Clipboard operations (read/write access to system clipboard)
- **OSC 9** - iTerm2 notifications (simple notification messages)
- **OSC 777** - urxvt notifications (rich notifications with title and message)
- **Sixel graphics** - Inline images (bitmap graphics embedded in terminal)

**Security Implications:**
- OSC 52 can allow malicious applications to read sensitive clipboard data
- OSC 8 hyperlinks could redirect to malicious URLs
- Sixel graphics can consume significant memory and CPU

**Recommendation**: Enable `disable_insecure_sequences: true` in untrusted or sandboxed environments.

### OSC 7 Directory Tracking

**Purpose**: Allows terminal applications (typically shells) to report their current working directory to the TUI.

**Benefits:**
- Enables the status bar to display the current directory
- Used by shell integration (zsh, bash with proper hooks)
- Helps terminal know where to save screenshots (when `screenshot_directory: null`)

**Implementation**:
- The terminal core accepts OSC 7 sequences when `accept_osc7: true`
- Directory changes are tracked via `shell_integration_state()`
- TUI receives directory updates through polling

**Security**: Generally safe to keep enabled as it only receives information, doesn't grant control.

### Example Configuration

```yaml
# Security Settings
disable_insecure_sequences: false  # Allow all sequences (default)
accept_osc7: true                   # Enable directory tracking (default)

# For untrusted environments
# disable_insecure_sequences: true
# accept_osc7: false
```

---

## Theme Configuration

### Theme Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `theme` | `str` | `"dark-background"` | Color theme name to use for terminal colors |
| `bold_brightening` | `bool` | `false` | Use bright ANSI colors (8-15) for bold text with normal colors (0-7) |
| `minimum_contrast` | `float` | `0.0` | Minimum contrast adjustment for live terminal display (0.0-1.0) |
| `faint_text_alpha` | `float` | `0.5` | Alpha multiplier for faint/dim text (0.0-1.0) |

**Available Themes:**
- Use `par-term-emu-tui-rust --list-themes` to see all available themes
- Default theme is `dark-background`
- Themes control the terminal's color palette and appearance

**Bold Brightening:**
- When enabled, bold text with ANSI colors 0-7 automatically uses bright variants 8-15
- This matches iTerm2's "Use Bright Bold" setting
- When disabled (default), bold text keeps its original color (0-7) without brightening
- Useful for matching color appearance across different terminal emulators

**Minimum Contrast (Live Display):**
- **Range**: 0.0-1.0
- **Default**: 0.0 (disabled)
- **Algorithm**: NTSC perceived brightness formula (30% red, 59% green, 11% blue)
- **Behavior**: Automatically adjusts text colors when brightness difference < threshold
- **Recommended**: 0.5 for improved readability (matches iTerm2 slider at 50%)
- **Use Cases**: Accessibility, dark-on-dark/light-on-light color schemes
- **Note**: This affects live terminal display; use `screenshot_minimum_contrast` for screenshots

**Faint Text Alpha:**
- **Range**: 0.0-1.0
- **Default**: 0.5 (renders faint text at 50% opacity)
- **Behavior**: Blends faint text toward the background while preserving hue
- **Use Cases**: Match iTerm2's "Faint text" slider or customize dimming strength

### Example Configuration

```yaml
# Theme
theme: "dark-background"       # Default theme
bold_brightening: false        # Don't use bright colors for bold text (default)
minimum_contrast: 0.0          # Disabled by default (0.5 recommended for improved readability)
faint_text_alpha: 0.5          # 50% opacity for faint text
```

---

## Notification Settings

### Notification Configuration

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `show_notifications` | `bool` | `true` | Display OSC 9/777 notifications as toast messages |
| `notification_timeout` | `int` | `5` | Duration in seconds to display notifications |
| `notification_bell_desktop` | `bool` | `false` | Forward BEL events to desktop notification center |
| `notification_bell_sound` | `int` | `0` | Volume (0-100) for backend bell audio alerts |
| `notification_bell_visual` | `bool` | `true` | Enable backend visual bell overlay |
| `notification_activity_enabled` | `bool` | `false` | Notify when activity resumes after inactivity |
| `notification_activity_threshold` | `int` | `10` | Seconds of inactivity before an activity alert |
| `notification_silence_enabled` | `bool` | `false` | Notify after prolonged silence |
| `notification_silence_threshold` | `int` | `300` | Seconds of silence before a silence alert |
| `notification_max_buffer` | `int` | `64` | Max OSC 9/777 notifications retained by backend |

**Notes:**
- OSC 9 provides simple notifications (message only)
- OSC 777 provides rich notifications (title + message)
- Terminal applications can trigger desktop-style notifications
- Notifications appear as toast overlays in the TUI

### Example Configuration

```yaml
# Notifications
show_notifications: true      # Enable notification toasts
notification_timeout: 5       # Auto-dismiss after 5 seconds
notification_bell_desktop: false
notification_bell_sound: 25   # Light chime on BEL
notification_bell_visual: true
notification_activity_enabled: true
notification_activity_threshold: 30
notification_silence_enabled: true
notification_silence_threshold: 600
notification_max_buffer: 64
```

### Clipboard Sync Limits

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `clipboard_max_sync_events` | `int` | `64` | Maximum clipboard sync events retained |
| `clipboard_max_event_bytes` | `int` | `2048` | Maximum bytes stored per clipboard sync event |

```yaml
# Clipboard limits
clipboard_max_sync_events: 32
clipboard_max_event_bytes: 4096
```

---

## Screenshot Configuration

### Screenshot Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `screenshot_directory` | `str \| None` | `None` | Directory to save screenshots (None = auto-detect) |
| `screenshot_format` | `str` | `"png"` | File format: `"png"`, `"jpeg"`, `"bmp"`, `"svg"`, `"html"` |
| `screenshot_minimum_contrast` | `float \| None` | `None` | Minimum contrast override (None = inherit `minimum_contrast`) |
| `open_screenshot_after_capture` | `bool` | `false` | Automatically open screenshot with system viewer |

**Minimum Contrast Adjustment**:
- **Range**: 0.0-1.0
- **Default**: `None` (inherit the live `minimum_contrast`, default 0.0)
- **Algorithm**: NTSC perceived brightness formula (30% red, 59% green, 11% blue)
- **Behavior**: Automatically adjusts text colors when brightness difference < threshold
- **Recommended**: 0.5 for improved readability in screenshots
- **Use Cases**: Documentation, accessibility, dark-on-dark/light-on-light schemes

**Screenshot Directory Auto-Detection** (when `None`):
1. Shell's current working directory (from OSC 7)
2. XDG_PICTURES_DIR/Screenshots
3. ~/Pictures/Screenshots
4. Home directory

**Screenshot Format Options:**
- `png` - Lossless, best for text (default)
- `jpeg` - Smaller file size, lossy compression
- `bmp` - Uncompressed, large file size
- `svg` - Vector format, infinitely scalable with selectable text
- `html` - Full HTML document with inline styles, viewable in browsers

### Example Configuration

```yaml
# Screenshots
screenshot_directory: null             # Auto-detect directory
screenshot_format: "png"               # PNG format
screenshot_minimum_contrast: null      # Inherit live minimum_contrast (default 0.0)
open_screenshot_after_capture: false   # Don't auto-open
```

---

## Recording Configuration

### Recording Settings

Record terminal sessions with full fidelity for playback with asciinema or custom players.

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `recording_directory` | `str \| None` | `None` | Directory to save recordings (None = auto-detect) |
| `recording_format` | `str` | `"asciicast"` | File format: `"asciicast"`, `"json"` |
| `recording_title_template` | `str` | `"Terminal Session {timestamp}"` | Template for recording title (use {timestamp} for auto timestamp) |
| `recording_auto_export_on_stop` | `bool` | `true` | Automatically export recording when stopped |
| `open_recording_after_export` | `bool` | `false` | Automatically open recording with default application |

**Recording Control:**
- **Keyboard**: Ctrl+Shift+R to toggle recording (start/stop)
- **Visual Indicator**: Recording icon (⏺️ REC) appears in header when active
- **Flash Messages**: Confirmation messages for start/stop/save actions

**Recording Directory Auto-Detection** (when `None`):
1. Shell's current working directory (from OSC 7)
2. XDG_VIDEOS_DIR/Recordings
3. ~/Videos/Recordings
4. Home directory

**Recording Format Options:**
- `asciicast` - Asciinema v2 format (default, playback with `asciinema play`)
- `json` - JSON export with full session data for custom processing

**Title Template:**
- Use `{timestamp}` placeholder for automatic timestamp insertion
- Example: `"Build Session {timestamp}"` → `"Build Session 2025-01-19 12:00:00 UTC"`

**Playback:**
```bash
# Play recording with asciinema
asciinema play terminal_recording_20250119_120000.cast

# Upload to share
asciinema upload terminal_recording_20250119_120000.cast
```

### Example Configuration

```yaml
# Recording
recording_directory: null                              # Auto-detect directory
recording_format: "asciicast"                         # Asciicast v2 format
recording_title_template: "Terminal Session {timestamp}"  # Title with timestamp
recording_auto_export_on_stop: true                   # Auto-export when stopped
open_recording_after_export: false                    # Don't auto-open
```

**Use Cases:**
- **Documentation**: Capture command sequences for tutorials
- **Training**: Record demonstrations for team training
- **Debugging**: Capture intermittent issues with precise timing
- **Sharing**: Create reproducible examples for support

---

## Hyperlinks & URLs

### Overview

Control how clickable hyperlinks work in the terminal.

### Hyperlink Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `clickable_urls` | `bool` | `true` | Enable clicking URLs to open in browser |
| `link_color` | `tuple[int, int, int]` | `(100, 150, 255)` | RGB color for hyperlinks (blue) |
| `url_modifier` | `str` | `"ctrl"` | Modifier key required for URL clicks |
| `allowed_url_schemes` | `list[str]` | `["http", "https", "ftp", "ftps", "file", "mailto"]` | URL schemes allowed for clickable links |
| `warn_on_unknown_url_scheme` | `bool` | `true` | Warn when blocking URLs with unsupported schemes |

**URL Detection:**
- **OSC 8 Hyperlinks**: Properly formatted URLs with OSC 8 escape sequences
- **Plain Text URLs**: Auto-detected http://, https://, ftp://, and other common schemes

**Modifier Key Options:**
- `"none"` - Click URLs directly without any modifier
- `"ctrl"` - Require Ctrl+Click to open URLs
- `"shift"` - Require Shift+Click to open URLs
- `"alt"` - Require Alt+Click to open URLs

**Scheme Filtering & Safety:**
- `allowed_url_schemes` controls which URL schemes can be opened via clickable links.
  - Default allows common schemes: `http`, `https`, `ftp`, `ftps`, `file`, `mailto`.
  - Schemes are case-insensitive.
  - URLs without an explicit scheme (for example, plain host/path links) are treated as allowed
    to preserve compatibility with existing output.
- If a URL uses a scheme not in `allowed_url_schemes`:
  - It is blocked from opening.
  - When `warn_on_unknown_url_scheme` is `true`, a non-fatal warning is displayed in the TUI.

### Search Highlighting

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `search_match_color` | `tuple[int, int, int]` | `(255, 255, 0)` | RGB color for search match highlights |

**Notes:**
- This setting prepares for future search feature implementation
- Color is specified as RGB tuple with values 0-255
- Default is yellow for high visibility

### Example Configuration

```yaml
# Hyperlinks & URLs
clickable_urls: true                 # Enable URL clicking
link_color: [100, 150, 255]         # Blue hyperlinks
url_modifier: "ctrl"                # Require Ctrl+Click (safer default)
allowed_url_schemes:                # Allow common safe schemes
  - http
  - https
  - ftp
  - ftps
  - file
  - mailto
warn_on_unknown_url_scheme: true    # Show warning when blocking unknown schemes

# Search Highlighting
search_match_color: [255, 255, 0]   # Yellow search matches
```

### Usage Examples

```bash
# Create OSC 8 hyperlink
echo -e '\e]8;;https://example.com\e\\Click me!\e]8;;\e\\'

# Plain URL (auto-detected)
echo "Visit https://github.com"
```

---

## UI Elements

### Overview

These settings control the visibility and behavior of UI elements in the terminal application.

### UI Element Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `show_status_bar` | `bool` | `true` | Show or hide the status bar at the bottom |
| `visual_bell_enabled` | `bool` | `true` | Enable visual bell indicator (bell icon in header) |

**Status Bar Notes:**
- When `true`: Status bar is visible and can display information like current directory (OSC 7)
- When `false`: Status bar is completely hidden to maximize terminal space
- The status bar is always present in the DOM for runtime toggling, but hidden via CSS when disabled
- Changes to this setting require restarting the application

**Visual Bell Notes:**
- When `true`: Bell icon (🔔) appears in header when terminal receives BEL character (`\x07`)
- When `false`: Bell events are ignored (no visual feedback)
- Bell icon clears on next keyboard input or mouse click
- Provides non-intrusive visual notification without audio

### Example Configuration

```yaml
# UI Elements
show_status_bar: true        # Show status bar (default)
visual_bell_enabled: true    # Enable visual bell indicator (default)
```

---

## Shell Behavior

### Shell Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `exit_on_shell_exit` | `bool` | `true` | Exit TUI application when shell exits |

**Notes:**
- When `true`: TUI exits immediately when the shell process exits.
- When `false`: The TUI remains open after the shell process exits so you can
  inspect the final screen contents. To start a new shell session, restart the
  application from the command line.
- Useful for reviewing output after shell exits or debugging.

### Example Configuration

```yaml
# Shell Behavior
exit_on_shell_exit: true  # Exit immediately when shell exits
```

---

## Keyboard Protocol (KITTY)

### Overview

The KITTY keyboard protocol is an enhanced keyboard encoding scheme that provides applications with more detailed keyboard information than traditional terminal protocols. This enables modern terminal applications to distinguish between key combinations that were previously ambiguous (e.g., Ctrl+I vs Tab, Ctrl+M vs Enter).

### Keyboard Protocol Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `keyboard_protocol_enabled` | `bool` | `false` | Enable KITTY keyboard protocol for embedded applications |
| `keyboard_protocol_flags` | `int` | `1` | KITTY protocol feature flags (bitwise OR combination) |
| `keyboard_protocol_auto_detect` | `bool` | `false` | Auto-detect and enable when applications request protocol |

### Protocol Flags

The `keyboard_protocol_flags` setting controls which features of the KITTY protocol are enabled. These flags can be combined using bitwise OR:

| Flag | Value | Description | Status |
|------|-------|-------------|--------|
| **Disambiguate** | `1` | Disambiguate escape codes (Ctrl+I ≠ Tab, Ctrl+M ≠ Enter) | ✅ Supported |
| **Report Events** | `2` | Report key press and release events | ⚠️ Requires Textual enhancement |
| **Alternate Keys** | `4` | Report alternate key representations | ⚠️ Requires Textual enhancement |
| **Report All** | `8` | Report all keys as escape codes | ⚠️ Requires Textual enhancement |
| **Associated Text** | `16` | Include associated text with events | ⚠️ Requires Textual enhancement |

**Common Flag Combinations:**
- `1` - Just disambiguation (recommended default)
- `3` - Disambiguation + key release events (1 + 2)
- `7` - Disambiguation + events + alternate keys (1 + 2 + 4)

**Note**: Currently, only flag `1` (disambiguate) is fully supported. Flags 2, 4, 8, and 16 require upstream enhancements to the Textual framework.

### Operating Modes

**Mode 1: Manual (keyboard_protocol_enabled = true)**
- Always use enhanced keyboard sequences
- Application must support KITTY protocol to interpret sequences correctly
- Suitable for testing or when all applications support the protocol

**Mode 2: Auto-Detect (keyboard_protocol_auto_detect = true)**
- Monitors PTY output for protocol activation sequences (CSI >flags u)
- Automatically enables protocol when application requests it
- Automatically disables when application sends deactivation sequence (CSI <u)
- **Recommended** for seamless operation with mixed applications

### How Auto-Detection Works

```mermaid
sequenceDiagram
    participant App as Terminal Application
    participant TUI as TUI Terminal
    participant PTY as PTY/Shell

    App->>PTY: CSI >1 u (Request KITTY protocol)
    PTY->>TUI: Forward sequence
    TUI->>TUI: Detect activation, enable protocol
    Note over TUI: Enhanced sequences active

    TUI->>PTY: Enhanced keyboard sequences
    PTY->>App: Receives enhanced input

    App->>PTY: CSI <u (Disable KITTY protocol)
    PTY->>TUI: Forward sequence
    TUI->>TUI: Detect deactivation, disable protocol
    Note over TUI: Legacy sequences active
```

### Protocol Benefits

**Disambiguation**:
- Applications can distinguish Ctrl+I from Tab
- Applications can distinguish Ctrl+M from Enter
- Prevents key binding conflicts in editors and applications

**Enhanced Input**:
- Key release events (flag 2)
- Alternate representations (e.g., shifted variants)
- Full key event metadata

### Example Configuration

```yaml
# Keyboard Protocol (KITTY)

# Manual mode (always enabled)
keyboard_protocol_enabled: false     # Disabled by default
keyboard_protocol_flags: 1           # Just disambiguation

# Auto-detect mode (recommended)
keyboard_protocol_auto_detect: false # Enable for seamless operation
```

**Recommended Setup for Best Compatibility:**
```yaml
keyboard_protocol_enabled: false        # Don't force protocol
keyboard_protocol_flags: 1              # Support disambiguation
keyboard_protocol_auto_detect: true     # Enable auto-detection
```

### Application Support

Applications that support KITTY keyboard protocol:
- Vim/Neovim (with appropriate configuration)
- Kakoune
- Helix
- Modern terminal-based text editors

**Checking Application Support:**
Most supporting applications will request the protocol automatically when `keyboard_protocol_auto_detect` is enabled.

### Troubleshooting

#### Issue: Keys not working correctly in applications
**Symptom**: Strange characters or unexpected behavior when pressing keys
**Solution**: Ensure application supports KITTY protocol or disable `keyboard_protocol_enabled`

#### Issue: Ctrl+I and Tab still behave the same
**Symptom**: No disambiguation despite protocol being enabled
**Solution**:
1. Verify application supports KITTY protocol
2. Check `keyboard_protocol_flags` includes flag `1`
3. Enable `keyboard_protocol_auto_detect` for automatic activation

#### Issue: Protocol not activating automatically
**Symptom**: Auto-detect not working
**Solution**:
1. Ensure `keyboard_protocol_auto_detect: true`
2. Verify application is requesting protocol (check PTY output)
3. Some applications may need explicit configuration to request protocol

### Related Documentation

- [KEYBOARD_PROTOCOL.md](KEYBOARD_PROTOCOL.md) - Detailed KITTY protocol documentation
- [Textual Framework](https://textual.textualize.io/) - Underlying TUI framework
- [KITTY Terminal Documentation](https://sw.kovidgoyal.net/kitty/keyboard-protocol/) - Original protocol specification

---

## Related Documentation

- [README.md](../README.md) - TUI application overview and usage guide
- [DEBUG.md](DEBUG.md) - TUI debugging guide
- [KEYBOARD_PROTOCOL.md](KEYBOARD_PROTOCOL.md) - KITTY keyboard protocol details
- [Core Library Documentation](https://github.com/paulrobello/par-term-emu-core-rust) - Terminal emulator core features
