# Installation Guide

Complete installation instructions for Par Term Emu TUI Rust, including dependencies, setup, and post-installation configuration.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Post-Installation Setup](#post-installation-setup)
- [Component Installation](#component-installation)
- [Verification](#verification)
- [Troubleshooting Installation](#troubleshooting-installation)
- [Related Documentation](#related-documentation)

## Prerequisites

Before installing Par Term Emu TUI Rust, ensure your system meets these requirements:

### Required Software

| Requirement | Notes | Check Command |
|-------------|-------|---------------|
| Python | Requires 3.12 or later | `python --version` |
| uv | Package manager | `uv --version` |
| Terminal | True color support recommended | See below |

### Verify Terminal Capabilities

**Check true color support:**
```bash
# Test 24-bit color
printf "\x1b[38;2;255;100;0mTRUECOLOR\x1b[0m\n"
```

If you see "TRUECOLOR" in orange, your terminal supports true color.

**Recommended terminals:**
- **macOS**: iTerm2, Wezterm, Alacritty
- **Linux**: Alacritty, Kitty, Wezterm, GNOME Terminal
- **Windows**: Windows Terminal, Wezterm

### System Dependencies

**macOS:**
```bash
# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh
```

**Linux:**
```bash
# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install clipboard support (optional, for PRIMARY selection on Linux)
sudo apt-get install xclip  # Debian/Ubuntu
sudo dnf install xclip      # Fedora
sudo pacman -S xclip        # Arch
```

**Windows:**
```powershell
# Install uv if not already installed
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

## Installation

### Install from Source

**Clone and install:**
```bash
# Clone the repository
git clone https://github.com/paulrobello/par-term-emu-tui-rust.git
cd par-term-emu-tui-rust

# Install dependencies
uv sync

# Or use make
make install
```

### Install from PyPI

```bash
# Install using uv (recommended)
uv tool install par-term-emu-tui-rust

# Or install in a virtual environment
uv venv
uv pip install par-term-emu-tui-rust

# Traditional pip installation also works
pip install par-term-emu-tui-rust
```

> **📝 Note:** The package is available on PyPI for easy installation. For development work or testing the latest unreleased features, install from source instead.

### Development Installation

For development with editable install:

```bash
# Clone repository
git clone https://github.com/paulrobello/par-term-emu-tui-rust.git
cd par-term-emu-tui-rust

# Install with development dependencies
uv sync

# Install pre-commit hooks (recommended)
make pre-commit-install
```

> **📝 Note:** This project depends on `par-term-emu-core-rust` (Rust terminal emulation backend).
> - **PyPI Installation**: The backend is automatically fetched from PyPI when installing the published package
> - **Source Installation**: By default, `pyproject.toml` is configured to use a local path dependency (`../par-term-emu-core-rust`) for development
> - For local development of both TUI and backend, ensure the Rust backend is cloned alongside this repository

## Post-Installation Setup

After installation, install additional components for enhanced functionality.

### Quick Setup (Recommended)

Install all components with one command:

```bash
# Install terminfo, shell integration, and font
par-term-emu-tui-rust install all
```

This installs:
- Terminfo definition for optimal terminal compatibility
- Shell integration for directory tracking and enhanced features
- Hack font for high-quality screenshot rendering

### Verify Installation

```bash
# Test basic functionality
par-term-emu-tui-rust --auto-quit 2

# List available themes
par-term-emu-tui-rust --list-themes

# You can also use the shorter alias 'ptr'
ptr --auto-quit 2
```

## Component Installation

### Terminfo Definition

Install the par-term terminfo definition for optimal terminal compatibility.

**User installation (recommended):**
```bash
par-term-emu-tui-rust install terminfo
```

**System-wide installation:**
```bash
# Requires sudo/administrator privileges
sudo par-term-emu-tui-rust install terminfo --system
```

**Verify installation:**
```bash
# Check terminfo is installed
infocmp par-term

# Should display terminfo definition
```

**What it does:**
- Defines terminal capabilities for par-term
- Enables proper application behavior
- Provides correct key mapping

### Shell Integration

Install shell integration for enhanced terminal features.

```mermaid
graph LR
    Install[Install Integration]
    Source[Source in Shell]
    Features[Enhanced Features]

    Install --> Source
    Source --> Features

    style Install fill:#1b5e20,stroke:#4caf50,stroke-width:2px,color:#ffffff
    style Source fill:#0d47a1,stroke:#2196f3,stroke-width:2px,color:#ffffff
    style Features fill:#e65100,stroke:#ff9800,stroke-width:3px,color:#ffffff
```

**Auto-detect current shell:**
```bash
# Installs for $SHELL
par-term-emu-tui-rust install shell-integration
```

**Install for all shells:**
```bash
# Installs for bash, zsh, and fish
par-term-emu-tui-rust install shell-integration --all
```

**Install for specific shell:**
```bash
# Bash
par-term-emu-tui-rust install shell-integration bash

# Zsh
par-term-emu-tui-rust install shell-integration zsh

# Fish
par-term-emu-tui-rust install shell-integration fish
```

**Activate integration:**

After installation, restart your shell to activate the integration:

```bash
# Restart current shell
exec $SHELL
```

Or manually source the integration file:

```bash
# Bash
source ~/.par_term_emu_core_rust_shell_integration.bash

# Zsh
source ~/.par_term_emu_core_rust_shell_integration.zsh

# Fish - automatically loaded from config directory
```

**Features provided:**
- Current working directory tracking (OSC 7)
- Prompt navigation markers
- Command status tracking
- Enhanced terminal title

### Font for Screenshots

Install Hack font for optimal screenshot rendering.

```bash
par-term-emu-tui-rust install font
```

**Installation location:** `~/.local/share/fonts/Hack/`

**License:** MIT/Bitstream Vera License

**What it does:**
- Provides monospace font for screenshots
- Ensures consistent text rendering
- Supports extended Unicode characters

**Verify installation:**
```bash
# List installed fonts (macOS/Linux)
fc-list | grep Hack

# Windows: Check Fonts in Control Panel or Settings
```

### Installation Help

Get detailed help for any component:

```bash
# General help
par-term-emu-tui-rust install --help

# Component-specific help
par-term-emu-tui-rust install terminfo --help
par-term-emu-tui-rust install shell-integration --help
par-term-emu-tui-rust install font --help
```

## Verification

### Test Installation

**Basic functionality test:**
```bash
# Run for 2 seconds then quit
par-term-emu-tui-rust --auto-quit 2
```

**Test with command:**
```bash
# Inject command and screenshot
par-term-emu-tui-rust --command "echo 'Hello World'" --screenshot 1 --auto-quit 3
```

**Check available themes:**
```bash
par-term-emu-tui-rust --list-themes
```

**Verify components:**
```bash
# Check terminfo
infocmp par-term

# Check shell integration files
ls ~/.par_term_emu_core_rust_shell_integration.*

# Check font (Linux/macOS)
fc-list | grep Hack
```

### Configuration Test

**Create default config:**
```bash
par-term-emu-tui-rust --init-config
```

**Verify config location:**

The configuration file is stored using XDG Base Directory specification:

```bash
# macOS/Linux - XDG_CONFIG_HOME or ~/.config
cat ~/.config/par-term-emu-tui-rust/config.yaml
```

**Edit configuration interactively:**

While the TUI is running, press **Alt+Ctrl+Shift+C** to open the built-in config editor with:
- YAML syntax highlighting
- Live validation before saving
- Automatic backup on save
- Interactive error recovery

**Configuration features:**
- Automatic timestamped backups on every save
- Type validation for all config values
- Range clamping for numeric settings
- Interactive recovery when parsing fails

See [Configuration Reference](CONFIG_REFERENCE.md) for all available options.

## Troubleshooting Installation

### Python Version Issues

**Problem:** `python: command not found` or version below 3.12

**Solution:**
```bash
# Check Python version
python3 --version

# If 3.12+, create alias
alias python=python3

# Or install Python 3.12 or later
# macOS (using Homebrew)
brew install python@3.12

# Linux (using apt)
sudo apt-get install python3.12

# Windows: Download installer from python.org
```

### UV Not Found

**Problem:** `uv: command not found`

**Solution:**
```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Add to PATH (add to ~/.bashrc or ~/.zshrc)
export PATH="$HOME/.cargo/bin:$PATH"

# Reload shell
exec $SHELL
```

### Permission Errors

**Problem:** Permission denied during installation

**Solution:**
```bash
# User installation (no sudo required)
par-term-emu-tui-rust install terminfo

# For system-wide, use sudo
sudo par-term-emu-tui-rust install terminfo --system

# Fix file permissions
chmod +x ~/.local/bin/par-term-emu-tui-rust
```

### Dependency Conflicts

**Problem:** Conflicting package versions or corrupt virtual environment

**Solution:**
```bash
# Clean virtual environment and reinstall
rm -rf .venv
uv sync

# Force reinstall all packages
uv sync --reinstall

# Clear uv cache if issues persist
uv cache clean
```

### Shell Integration Not Loading

**Problem:** Shell integration features not working

**Solution:**
```bash
# Reinstall for current shell
par-term-emu-tui-rust install shell-integration --all

# Manually source (bash example)
echo 'source ~/.par_term_emu_core_rust_shell_integration.bash' >> ~/.bashrc

# Restart shell
exec $SHELL
```

### Font Not Available

**Problem:** Hack font not showing up

**Solution:**
```bash
# Reinstall font
par-term-emu-tui-rust install font

# Rebuild font cache (Linux)
fc-cache -f -v

# Restart applications that use fonts
```

## Related Documentation

- [Quick Start Guide](QUICK_START.md) - Get started in 5 minutes
- [Configuration Reference](CONFIG_REFERENCE.md) - Complete configuration options
- [Usage Guide](USAGE.md) - Running and using the terminal emulator
- [Troubleshooting](TROUBLESHOOTING.md) - Common issues and solutions
- [Contributing](../CONTRIBUTING.md) - Development setup and contribution guidelines
