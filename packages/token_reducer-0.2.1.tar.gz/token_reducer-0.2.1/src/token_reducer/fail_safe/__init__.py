# Fail-safe module
