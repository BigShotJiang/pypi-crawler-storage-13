# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.0.1] - 2025-11-21
### Fixed
- [#1675](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1675) Fix helpdesk_ticket_mail_message dependency issues

## [16.0.1.0.0] - 2025-10-16
### Added
- [#1642](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1642) Add helpdesk_somconnexio module
