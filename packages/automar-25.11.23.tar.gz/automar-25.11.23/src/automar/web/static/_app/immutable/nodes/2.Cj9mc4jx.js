import{_ as m}from"../chunks/dAYXHiis.js";export{m as component};
