Changelog
=========

All notable changes to this project will be documented in this file.
The format roughly follows `Keep a Changelog <https://keepachangelog.com/en/1.1.0/>`_
and adheres to semantic versioning where possible.


25.11.23 - 2025-11-23
------------------

- First public release of AuToMaR.
