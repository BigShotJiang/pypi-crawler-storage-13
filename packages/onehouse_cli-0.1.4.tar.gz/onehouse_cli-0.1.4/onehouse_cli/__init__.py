"""
Onehouse CLI - A command-line tool for executing SQL commands against the Onehouse API.
"""

try:
    # For Python 3.8+
    from importlib.metadata import version
except ImportError:
    # For Python 3.7
    from importlib_metadata import version

try:
    __version__ = version("onehouse-cli")
except Exception:
    # Fallback version if package is not installed
    __version__ = "0.0.0.dev"

from .cli import main as cli_main
from .configure import main as configure_main

__all__ = ["cli_main", "configure_main"]
