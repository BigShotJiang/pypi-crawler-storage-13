from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="FastAPI Lambda Example", version="1.0.0")


class Item(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    tax: Optional[float] = None


@app.get("/")
def read_root():
    """Root endpoint returning a welcome message."""
    return {
        "message": "Hello from FastAPI on AWS Lambda!",
        "framework": "FastAPI",
        "deployed_with": "cflabs-serverless"
    }


@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "fastapi-lambda"}


@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None):
    """Get an item by ID with optional query parameter."""
    response = {"item_id": item_id}
    if q:
        response["q"] = q
    return response


@app.post("/items/")
def create_item(item: Item):
    """Create a new item."""
    item_dict = item.dict()
    if item.tax:
        price_with_tax = item.price + item.tax
        item_dict.update({"price_with_tax": price_with_tax})
    return item_dict


@app.get("/info")
def get_info():
    """Get API information."""
    return {
        "title": "FastAPI Lambda Example",
        "version": "1.0.0",
        "description": "A FastAPI application deployed on AWS Lambda using cflabs-serverless",
        "endpoints": {
            "/": "Root endpoint",
            "/health": "Health check",
            "/items/{item_id}": "Get item by ID",
            "/items/": "Create a new item (POST)",
            "/info": "API information",
            "/docs": "Interactive API documentation (Swagger UI)",
            "/redoc": "Alternative API documentation (ReDoc)"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

