

from mangum import Mangum
from app import app

# Wrap FastAPI app with Mangum for AWS Lambda
handler = Mangum(app, lifespan="off")

def lambda_handler(event, context):
    return handler(event, context)
