import aframexr

data = aframexr.URLData('https://davidlab20.github.io/TFG/examples/data/data.json')
chart = aframexr.Chart(data, position='-2 0 -8').mark_bar().encode(x='model', y='sales')
chart.save('test.html')