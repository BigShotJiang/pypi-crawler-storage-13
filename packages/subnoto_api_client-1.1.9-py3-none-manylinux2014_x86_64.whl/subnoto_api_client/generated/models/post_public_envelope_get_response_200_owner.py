from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="PostPublicEnvelopeGetResponse200Owner")


@_attrs_define
class PostPublicEnvelopeGetResponse200Owner:
    """The creator of the envelope.

    Attributes:
        uuid (str): The unique identifier of the owner.
        email (str): The email of the owner.
        firstname (None | str | Unset): The first name of the owner.
        lastname (None | str | Unset): The last name of the owner.
    """

    uuid: str
    email: str
    firstname: None | str | Unset = UNSET
    lastname: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        email = self.email

        firstname: None | str | Unset
        if isinstance(self.firstname, Unset):
            firstname = UNSET
        else:
            firstname = self.firstname

        lastname: None | str | Unset
        if isinstance(self.lastname, Unset):
            lastname = UNSET
        else:
            lastname = self.lastname

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "uuid": uuid,
                "email": email,
            }
        )
        if firstname is not UNSET:
            field_dict["firstname"] = firstname
        if lastname is not UNSET:
            field_dict["lastname"] = lastname

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid")

        email = d.pop("email")

        def _parse_firstname(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        firstname = _parse_firstname(d.pop("firstname", UNSET))

        def _parse_lastname(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        lastname = _parse_lastname(d.pop("lastname", UNSET))

        post_public_envelope_get_response_200_owner = cls(
            uuid=uuid,
            email=email,
            firstname=firstname,
            lastname=lastname,
        )

        return post_public_envelope_get_response_200_owner
