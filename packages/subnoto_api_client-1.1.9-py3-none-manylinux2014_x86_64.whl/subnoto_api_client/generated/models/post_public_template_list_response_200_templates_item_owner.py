from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

T = TypeVar("T", bound="PostPublicTemplateListResponse200TemplatesItemOwner")


@_attrs_define
class PostPublicTemplateListResponse200TemplatesItemOwner:
    """The creator of the template.

    Attributes:
        uuid (str): The unique identifier of the owner.
        email (str): The email of the owner.
        firstname (None | str): The first name of the owner.
        lastname (None | str): The last name of the owner.
    """

    uuid: str
    email: str
    firstname: None | str
    lastname: None | str

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        email = self.email

        firstname: None | str
        firstname = self.firstname

        lastname: None | str
        lastname = self.lastname

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "uuid": uuid,
                "email": email,
                "firstname": firstname,
                "lastname": lastname,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid")

        email = d.pop("email")

        def _parse_firstname(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        firstname = _parse_firstname(d.pop("firstname"))

        def _parse_lastname(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        lastname = _parse_lastname(d.pop("lastname"))

        post_public_template_list_response_200_templates_item_owner = cls(
            uuid=uuid,
            email=email,
            firstname=firstname,
            lastname=lastname,
        )

        return post_public_template_list_response_200_templates_item_owner
