from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..models.post_public_contact_delete_response_403_error_code import (
    PostPublicContactDeleteResponse403ErrorCode,
)

T = TypeVar("T", bound="PostPublicContactDeleteResponse403Error")


@_attrs_define
class PostPublicContactDeleteResponse403Error:
    """
    Attributes:
        code (PostPublicContactDeleteResponse403ErrorCode): The error code
        message (str): The error message
        suggestion (str): A suggestion to resolve the error
        documentation_url (str): A URL to the documentation
    """

    code: PostPublicContactDeleteResponse403ErrorCode
    message: str
    suggestion: str
    documentation_url: str

    def to_dict(self) -> dict[str, Any]:
        code = self.code.value

        message = self.message

        suggestion = self.suggestion

        documentation_url = self.documentation_url

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "code": code,
                "message": message,
                "suggestion": suggestion,
                "documentationUrl": documentation_url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        code = PostPublicContactDeleteResponse403ErrorCode(d.pop("code"))

        message = d.pop("message")

        suggestion = d.pop("suggestion")

        documentation_url = d.pop("documentationUrl")

        post_public_contact_delete_response_403_error = cls(
            code=code,
            message=message,
            suggestion=suggestion,
            documentation_url=documentation_url,
        )

        return post_public_contact_delete_response_403_error
