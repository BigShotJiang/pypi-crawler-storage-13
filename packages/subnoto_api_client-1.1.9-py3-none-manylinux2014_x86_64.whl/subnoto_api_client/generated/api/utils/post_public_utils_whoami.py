from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_public_utils_whoami_body import PostPublicUtilsWhoamiBody
from ...models.post_public_utils_whoami_response_200 import (
    PostPublicUtilsWhoamiResponse200,
)
from ...models.post_public_utils_whoami_response_401 import (
    PostPublicUtilsWhoamiResponse401,
)
from ...models.post_public_utils_whoami_response_403 import (
    PostPublicUtilsWhoamiResponse403,
)
from ...models.post_public_utils_whoami_response_500 import (
    PostPublicUtilsWhoamiResponse500,
)
from ...types import Response


def _get_kwargs(
    *,
    body: PostPublicUtilsWhoamiBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/public/utils/whoami",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    PostPublicUtilsWhoamiResponse200
    | PostPublicUtilsWhoamiResponse401
    | PostPublicUtilsWhoamiResponse403
    | PostPublicUtilsWhoamiResponse500
    | None
):
    if response.status_code == 200:
        response_200 = PostPublicUtilsWhoamiResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = PostPublicUtilsWhoamiResponse401.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = PostPublicUtilsWhoamiResponse403.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = PostPublicUtilsWhoamiResponse500.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    PostPublicUtilsWhoamiResponse200
    | PostPublicUtilsWhoamiResponse401
    | PostPublicUtilsWhoamiResponse403
    | PostPublicUtilsWhoamiResponse500
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicUtilsWhoamiBody,
) -> Response[
    PostPublicUtilsWhoamiResponse200
    | PostPublicUtilsWhoamiResponse401
    | PostPublicUtilsWhoamiResponse403
    | PostPublicUtilsWhoamiResponse500
]:
    """whoami

     Get information about the authenticated team and api key

    Args:
        body (PostPublicUtilsWhoamiBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicUtilsWhoamiResponse200 | PostPublicUtilsWhoamiResponse401 | PostPublicUtilsWhoamiResponse403 | PostPublicUtilsWhoamiResponse500]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicUtilsWhoamiBody,
) -> (
    PostPublicUtilsWhoamiResponse200
    | PostPublicUtilsWhoamiResponse401
    | PostPublicUtilsWhoamiResponse403
    | PostPublicUtilsWhoamiResponse500
    | None
):
    """whoami

     Get information about the authenticated team and api key

    Args:
        body (PostPublicUtilsWhoamiBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicUtilsWhoamiResponse200 | PostPublicUtilsWhoamiResponse401 | PostPublicUtilsWhoamiResponse403 | PostPublicUtilsWhoamiResponse500
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicUtilsWhoamiBody,
) -> Response[
    PostPublicUtilsWhoamiResponse200
    | PostPublicUtilsWhoamiResponse401
    | PostPublicUtilsWhoamiResponse403
    | PostPublicUtilsWhoamiResponse500
]:
    """whoami

     Get information about the authenticated team and api key

    Args:
        body (PostPublicUtilsWhoamiBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostPublicUtilsWhoamiResponse200 | PostPublicUtilsWhoamiResponse401 | PostPublicUtilsWhoamiResponse403 | PostPublicUtilsWhoamiResponse500]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostPublicUtilsWhoamiBody,
) -> (
    PostPublicUtilsWhoamiResponse200
    | PostPublicUtilsWhoamiResponse401
    | PostPublicUtilsWhoamiResponse403
    | PostPublicUtilsWhoamiResponse500
    | None
):
    """whoami

     Get information about the authenticated team and api key

    Args:
        body (PostPublicUtilsWhoamiBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostPublicUtilsWhoamiResponse200 | PostPublicUtilsWhoamiResponse401 | PostPublicUtilsWhoamiResponse403 | PostPublicUtilsWhoamiResponse500
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
