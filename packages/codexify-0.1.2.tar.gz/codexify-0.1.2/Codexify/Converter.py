import string

nums = string.digits
letts = string.ascii_lowercase + string.ascii_uppercase

class Converter:
    def __init__(self):
        self.converted = ""

    def convert_text(self, text: str):
        self.converted = ""
        for c in text:
            if c in nums:
                i = nums.index(c)
                self.converted += nums[i]
            else:
                i = None
                self.converted += c

            if i is not None and i < len(letts):
                self.converted += letts[i]
            else:
                self.converted += c

        return self.converted