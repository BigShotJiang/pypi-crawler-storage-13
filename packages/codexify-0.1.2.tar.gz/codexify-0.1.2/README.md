#Codexify

Codexify is a small Python library that converts characters in a string using a simple custom transformation.
It can be used for encoding digits, generating mixed output (letters + numbers), or building your own text-processing logic.
---
###Installation
```bash
pip install codexify
```
###Usage
```python
from Codexify import *

conv = Converter()
result = conv.convert_text("a1b2c3")

print(result)
```
---
##Features

-Converts numeric characters based on their index

-Keeps non-numeric characters unchanged

-Easy to extend with your own logic

-Lightweight and simple to use