from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess
import sys
import requests
import json

class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        
        # Webhook URL-nizi bura əlavə edin
        WEBHOOK_URL = "https://webhook.site/33a92941-d730-4a54-9e41-d0c9a9319775"
        
        # Göndəriləcək məlumatlar
        payload = {
            "package_name": "sizin-paket-adiniz",
            "version": "1.0.0",
            "event": "installation",
            "python_version": sys.version,
            "status": "success"
        }
        
        try:
            response = requests.post(
                WEBHOOK_URL,
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            print(f"Webhook response: {response.status_code}")
        except Exception as e:
            print(f"Webhook error: {e}")

setup(
    name="peptest",
    version="1.2.0",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1",
        # digər asılılıqlar
    ],
    cmdclass={
        'install': PostInstallCommand,
    },
    author="siitoogether",
    author_email="anony-0x2@proton.me",
    description="Sizin paket təsviri",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)