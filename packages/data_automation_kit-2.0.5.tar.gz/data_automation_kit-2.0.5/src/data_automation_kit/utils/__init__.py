"""
Utility functions for Data Automation Kit
"""

__all__ = []
