import pandas as pd
import numpy as np
from typing import Dict, Any, List

class DataQualityChecker:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.quality_report = {}
    
    def run_quality_checks(self) -> Dict[str, Any]:
        report = {
            'completeness': self._check_completeness(),
            'consistency': self._check_consistency(),
            'uniqueness': self._check_uniqueness(),
            'validity': self._check_validity(),
            'quality_score': self._calculate_quality_score()
        }
        self.quality_report = report
        return report
    
    def _check_completeness(self) -> Dict[str, Any]:
        total_cells = self.data.size
        missing_cells = self.data.isnull().sum().sum()
        completeness_ratio = 1 - (missing_cells / total_cells) if total_cells > 0 else 1
        
        return {
            'total_cells': total_cells,
            'missing_cells': missing_cells,
            'overall_completeness': round(completeness_ratio * 100, 2)
        }
    
    def _check_consistency(self) -> Dict[str, Any]:
        numeric_consistency = len(self.data.select_dtypes(include=[np.number]).columns)
        categorical_consistency = len(self.data.select_dtypes(include=['object']).columns)
        
        return {
            'numeric_columns': numeric_consistency,
            'categorical_columns': categorical_consistency
        }
    
    def _check_uniqueness(self) -> Dict[str, Any]:
        duplicate_rows = self.data.duplicated().sum()
        duplicate_ratio = duplicate_rows / len(self.data) if len(self.data) > 0 else 0
        
        return {
            'duplicate_rows': duplicate_rows,
            'duplicate_ratio': round(duplicate_ratio * 100, 2)
        }
    
    def _check_validity(self) -> Dict[str, Any]:
        # Basic validity checks
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns
        infinite_values = 0
        
        for col in numeric_cols:
            infinite_values += np.isinf(self.data[col]).sum()
        
        return {
            'infinite_values': infinite_values
        }
    
    def _calculate_quality_score(self) -> float:
        completeness = self.quality_report.get('completeness', {}).get('overall_completeness', 0) / 100
        uniqueness = 1 - (self.quality_report.get('uniqueness', {}).get('duplicate_ratio', 0) / 100)
        
        # Simple weighted average
        quality_score = (completeness * 0.6 + uniqueness * 0.4) * 100
        return round(quality_score, 2)
    
    def print_quality_report(self):
        print("DATA QUALITY REPORT")
        print("=" * 50)
        
        completeness = self.quality_report.get('completeness', {})
        uniqueness = self.quality_report.get('uniqueness', {})
        
        print(f"Completeness: {completeness.get('overall_completeness', 0)}%")
        print(f"Missing Values: {completeness.get('missing_cells', 0)}")
        print(f"Duplicate Rows: {uniqueness.get('duplicate_rows', 0)}")
        print(f"Duplicate Ratio: {uniqueness.get('duplicate_ratio', 0)}%")
        print(f"Overall Quality Score: {self.quality_report.get('quality_score', 0)}/100")
