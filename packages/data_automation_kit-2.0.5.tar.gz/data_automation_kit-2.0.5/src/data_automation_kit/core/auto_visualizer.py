import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from typing import Dict, List, Any, Optional

class AutoVisualizer:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.plot_paths = {}
        os.makedirs('data_visualizations', exist_ok=True)
    
    def create_comprehensive_visualizations(self):
        """Create a comprehensive set of visualizations"""
        plots_created = []
        
        # Create correlation heatmap
        if self._create_correlation_heatmap():
            plots_created.append("correlation_heatmap")
        
        # Create distribution plots for numeric columns
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if self._create_distribution_plot(col):
                plots_created.append(f"distribution_{col}")
        
        return plots_created
    
    def _create_correlation_heatmap(self) -> bool:
        try:
            numeric_data = self.data.select_dtypes(include=[np.number])
            if len(numeric_data.columns) < 2:
                return False
            
            plt.figure(figsize=(12, 10))
            correlation_matrix = numeric_data.corr()
            sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0)
            plt.title('Correlation Heatmap')
            plt.tight_layout()
            plt.savefig('data_visualizations/correlation_heatmap.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths['correlation_heatmap'] = 'data_visualizations/correlation_heatmap.png'
            return True
        except Exception as e:
            print(f"Error creating correlation heatmap: {e}")
            return False
    
    def _create_distribution_plot(self, column: str) -> bool:
        try:
            plt.figure(figsize=(10, 6))
            plt.hist(self.data[column].dropna(), bins=30, alpha=0.7, edgecolor='black')
            plt.title(f'Distribution of {column}')
            plt.xlabel(column)
            plt.ylabel('Frequency')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(f'data_visualizations/distribution_{column}.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths[f'distribution_{column}'] = f'data_visualizations/distribution_{column}.png'
            return True
        except Exception as e:
            print(f"Error creating distribution plot for {column}: {e}")
            return False
    
    def get_plot_paths(self) -> Dict[str, str]:
        return self.plot_paths
