import pandas as pd
import numpy as np
from typing import Dict, Any, List

class DataCleaner:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.cleaning_report = {}
    
    def auto_clean(self) -> pd.DataFrame:
        cleaned_data = self.data.copy()
        
        # Remove duplicate rows
        initial_rows = len(cleaned_data)
        cleaned_data = cleaned_data.drop_duplicates()
        duplicates_removed = initial_rows - len(cleaned_data)
        
        # Handle missing values
        missing_before = cleaned_data.isnull().sum().sum()
        
        # Fill numeric columns with median
        numeric_cols = cleaned_data.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if cleaned_data[col].isnull().any():
                cleaned_data[col] = cleaned_data[col].fillna(cleaned_data[col].median())
        
        # Fill categorical columns with mode
        categorical_cols = cleaned_data.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            if cleaned_data[col].isnull().any():
                mode_val = cleaned_data[col].mode()
                if len(mode_val) > 0:
                    cleaned_data[col] = cleaned_data[col].fillna(mode_val[0])
        
        missing_after = cleaned_data.isnull().sum().sum()
        missing_filled = missing_before - missing_after
        
        self.cleaning_report = {
            'summary': {
                'rows_removed': duplicates_removed,
                'missing_values_filled': missing_filled,
                'columns_removed': 0
            }
        }
        
        return cleaned_data
    
    def get_cleaning_report(self) -> Dict[str, Any]:
        return self.cleaning_report
