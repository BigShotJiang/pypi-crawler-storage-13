import os
import pandas as pd
from typing import Dict, Any, Optional

class GroqAnalyzer:
    def __init__(self):
        self.api_key = os.getenv('GROQ_API_KEY', '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')
        self.model = os.getenv('GROQ_MODEL', 'meta-llama/llama-4-scout-17b-16e-instruct')
        self.client = self._initialize_client()
    
    def _initialize_client(self):
        try:
            from groq import Groq
            return Groq(api_key=self.api_key)
        except ImportError:
            print("Groq library not available. Please install with: pip install groq")
            return None
    
    def generate_data_report(self, data: pd.DataFrame, context: Optional[Dict] = None) -> str:
        if self.client is None:
            return "Groq client not available"
        
        try:
            prompt = self._build_analysis_prompt(data, context)
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2000
            )
            
            return self._clean_response(response.choices[0].message.content)
        except Exception as e:
            return f"Error generating analysis: {e}"
    
    def _build_analysis_prompt(self, data: pd.DataFrame, context: Optional[Dict] = None) -> str:
        base_prompt = f"""
        Analyze the following dataset and provide insights:
        
        Dataset Shape: {data.shape}
        Columns: {list(data.columns)}
        Data Types: {data.dtypes.to_dict()}
        Sample Data: {data.head(3).to_dict()}
        """
        
        if context and context.get('user_question'):
            base_prompt += f"\nUser Question: {context['user_question']}"
        
        if context and context.get('target_column'):
            base_prompt += f"\nTarget Variable: {context['target_column']}"
        
        base_prompt += """
        Please provide:
        1. Key insights and patterns
        2. Data quality observations
        3. Business recommendations
        4. Potential next steps for analysis
        
        Keep the response clear and actionable.
        """
        
        return base_prompt
    
    def _clean_response(self, response: str) -> str:
        return response.strip()
    
    def analyze_visualizations(self, plot_paths: Dict[str, str], data: pd.DataFrame) -> str:
        prompt = f"""
        Based on the created visualizations for this dataset, provide analysis:
        
        Dataset: {data.shape}
        Visualizations Created: {list(plot_paths.keys())}
        
        Please analyze what these visualizations reveal about the data patterns,
        relationships, and potential insights. Focus on actionable business insights.
        """
        
        return self.generate_data_report(data, {'user_question': prompt})
    
    def generate_business_insights(self, data: pd.DataFrame) -> str:
        prompt = "Provide key business insights and recommendations based on this dataset."
        return self.generate_data_report(data, {'user_question': prompt})
    
    def generate_data_patterns(self, data: pd.DataFrame) -> str:
        prompt = "Identify and explain the main patterns and relationships in this dataset."
        return self.generate_data_report(data, {'user_question': prompt})
    
    def suggest_cleaning_steps(self, data: pd.DataFrame, quality_report: Dict) -> str:
        prompt = f"""
        Based on this data quality report, suggest cleaning steps:
        Quality Report: {quality_report}
        """
        return self.generate_data_report(data, {'user_question': prompt})
