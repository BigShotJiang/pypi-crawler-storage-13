import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import json
import os
from typing import Union, Dict, Any, List
import warnings
warnings.filterwarnings('ignore')

class DataLoader:
    """Smart data loader for multiple formats with enhanced sample datasets"""
    
    def __init__(self):
        self.data = None
        self.loaded_from = None
        
    def load_csv(self, file_path: str, **kwargs) -> pd.DataFrame:
        try:
            self.data = pd.read_csv(file_path, **kwargs)
            self.loaded_from = f"CSV: {file_path}"
            return self.data
        except Exception as e:
            print(f"Error loading CSV: {e}")
            return None
    
    def create_sample_data(self, dataset_type: str = "sales") -> pd.DataFrame:
        np.random.seed(42)
        
        if dataset_type == "sales":
            n_records = 1000
            return pd.DataFrame({
                'order_id': range(1000, 1000 + n_records),
                'order_date': pd.date_range('2023-01-01', periods=n_records, freq='D'),
                'customer_id': np.random.randint(100, 500, n_records),
                'product_category': np.random.choice(['Electronics', 'Clothing', 'Home', 'Books', 'Sports'], n_records),
                'region': np.random.choice(['North', 'South', 'East', 'West'], n_records),
                'sales_amount': np.abs(np.random.normal(150, 50, n_records)),
                'quantity': np.random.randint(1, 5, n_records),
                'profit': np.abs(np.random.normal(30, 10, n_records)),
                'customer_rating': np.random.choice([1, 2, 3, 4, 5], n_records, p=[0.05, 0.1, 0.15, 0.3, 0.4])
            })
        return None
