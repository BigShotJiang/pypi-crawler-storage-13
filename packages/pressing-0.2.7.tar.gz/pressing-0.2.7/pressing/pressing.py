from pynput.keyboard import Key, Controller
from pynput.mouse import Button, Controller as MouseController
import time
import keyboard
import win32gui

wait = 0.03
kb = Controller()
mouse = MouseController()

def typewait(t):
    global wait
    wait = float(t)

def safe(name):
    return getattr(Key, name, None)

SPECIAL_KEYS = {
    "alt": safe("alt"),
    "lalt": safe("alt_l"),
    "ralt": safe("alt_r"),
    "ctrl": safe("ctrl"),
    "lctrl": safe("ctrl_l"),
    "rctrl": safe("ctrl_r"),
    "shift": safe("shift"),
    "lshift": safe("shift_l"),
    "rshift": safe("shift_r"),
    "cmd": safe("cmd"),
    "win": safe("cmd"),
    "meta": safe("cmd"),
    "super": safe("cmd"),
    "tab": safe("tab"),
    "enter": safe("enter"),
    "esc": safe("esc"),
    "escape": safe("esc"),
    "backspace": safe("backspace"),
    "delete": safe("delete"),
    "del": safe("delete"),
    "insert": safe("insert"),
    "home": safe("home"),
    "end": safe("end"),
    "pageup": safe("page_up"),
    "pagedown": safe("page_down"),
    "up": safe("up"),
    "down": safe("down"),
    "left": safe("left"),
    "right": safe("right"),
    " ": safe("space"),
    "space": safe("space"),
    **{f"f{i}": safe(f"f{i}") for i in range(1, 25)},
    "capslock": safe("caps_lock"),
    "numlock": safe("num_lock"),
    "scrolllock": safe("scroll_lock"),
    "pause": safe("pause"),
    "printscreen": safe("print_screen"),
}

def pixel_color(x, y):
    """Return RGB tuple of pixel at (x, y)."""
    hdc = win32gui.GetWindowDC(win32gui.GetDesktopWindow())
    color = win32gui.GetPixel(hdc, x, y)
    win32gui.ReleaseDC(win32gui.GetDesktopWindow(), hdc)
    return (color & 0xff, (color >> 8) & 0xff, (color >> 16) & 0xff)

def pixel_is(x, y, rgb):
    """Return True if pixel equals rgb."""
    return pixel_color(x, y) == tuple(rgb)

def wait_pixel(pos, rgb):
    """Block until pixel at pos matches rgb."""
    x, y = pos
    rgb = tuple(rgb)
    while True:
        if pixel_color(x, y) == rgb:
            return True
        time.sleep(0.001)

def pressed(k):
    """Return True if a key is currently held."""
    try:
        return keyboard.is_pressed(k)
    except:
        return False

def wait_key(k):
    """Wait until key is pressed."""
    keyboard.wait(k)

def get_key_obj(k):
    k = str(k).lower()
    if k in SPECIAL_KEYS and SPECIAL_KEYS[k] is not None:
        return SPECIAL_KEYS[k]
    return k

def run_macro(cmd_list):
    global wait
    import pressing

    delay = wait

    for cmd in cmd_list:

        # Hold
        if cmd.endswith("+"):
            kb.press(get_key_obj(cmd[:-1]))
            if delay: time.sleep(delay)
            continue

        # Release
        if cmd.endswith("-"):
            kb.release(get_key_obj(cmd[:-1]))
            if delay: time.sleep(delay)
            continue

        # Single key press
        key = get_key_obj(cmd)
        kb.press(key)
        kb.release(key)

        if delay: time.sleep(delay)

def creator():
    """Display creator info."""
    print("Pressing was created by Mongoose")

def press(character):
    """Hold a key."""
    cmds = [f"{c}+" for c in character] if isinstance(character, list) else [f"{character}+"]
    run_macro(cmds)

def release(character):
    """Release a held key."""
    cmds = [f"{c}-" for c in character] if isinstance(character, list) else [f"{character}-"]
    run_macro(cmds)

def click(character):
    """Press and release a key."""
    cmds = [f"{c}" for c in character] if isinstance(character, list) else [f"{character}"]
    run_macro(cmds)

def write(text):
    """Type a string instantly using click()."""
    for ch in text:
        click(ch)

def hotkey(keys):
    """Press multiple keys together."""
    for k in keys:
        press(k)
    for k in reversed(keys):
        release(k)

def hold(key, seconds):
    """Hold a key for a duration."""
    press(key)
    time.sleep(seconds)
    release(key)

def mouse_move(x, y):
    """Move mouse instantly."""
    mouse.position = (x, y)

def smooth_mouse_move(x, y, steps=20):
    """Move mouse smoothly."""
    start_x, start_y = mouse.position
    dx = (x - start_x) / steps
    dy = (y - start_y) / steps
    for i in range(steps):
        mouse.position = (start_x + dx*i, start_y + dy*i)
        time.sleep(0.01)

def mouse_click(x=None, y=None, button="left"):
    """Click the mouse."""
    if x is not None and y is not None:
        mouse.position = (x, y)
    btn = Button.left if button == "left" else Button.right
    mouse.click(btn)

def mouse_press(button="left"):
    """Press mouse button."""
    btn = Button.left if button == "left" else Button.right
    mouse.press(btn)

def mouse_release(button="left"):
    """Release mouse button."""
    btn = Button.left if button == "left" else Button.right
    mouse.release(btn)
