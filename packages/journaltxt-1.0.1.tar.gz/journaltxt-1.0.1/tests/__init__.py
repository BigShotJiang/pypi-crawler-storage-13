"""Tests for journaltxt package."""
