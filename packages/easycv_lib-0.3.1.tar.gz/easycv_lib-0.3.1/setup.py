"""
Setup file for EasyCV package

Note: Most configuration is now in pyproject.toml
This file is kept for backward compatibility.
"""

from setuptools import setup, find_packages

# Read pyproject.toml for configuration
# The actual configuration is in pyproject.toml
setup(
    packages=find_packages(),
)

