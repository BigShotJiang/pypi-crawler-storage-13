# EasyCV

یک کتابخانه راحت و ساده برای کار با OpenCV

[![PyPI version](https://badge.fury.io/py/easycv.svg)](https://badge.fury.io/py/easycv)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

## نصب

### نصب از PyPI

کتابخانه در PyPI منتشر شده است. برای نصب:

```bash
pip install easycv-lib
```

> **نکته:** نام پکیج در PyPI `easycv-lib` است (چون نام `easycv` قبلاً گرفته شده بود)، اما بعد از نصب می‌توانید با `import easycv` استفاده کنید.

### روش 1: نصب از پوشه پروژه (برای توسعه)

از پوشه اصلی پروژه این دستور را اجرا کنید:

```bash
pip install .
```

بعد از نصب، می‌توانید از هر جای سیستم از کتابخانه استفاده کنید:

```python
import easycv.vision
easycv.vision.open_live_window()
```

### روش 2: نصب با اسکریپت خودکار

**ویندوز:**
```bash
build_and_install.bat
```

**لینوکس/Mac:**
```bash
chmod +x build_and_install.sh
./build_and_install.sh
```

**یا با Python:**
```bash
python install.py
```

### روش 3: نصب از فایل wheel (بعد از build)

اگر قبلاً کتابخانه را build کرده‌اید:

```bash
# ابتدا build کنید
python -m build

# سپس از فایل wheel نصب کنید
pip install dist/easycv-0.1.0-py3-none-any.whl
```

### روش 4: نصب در حالت توسعه (برای توسعه‌دهندگان)

اگر می‌خواهید تغییرات را بلافاصله ببینید:

```bash
pip install -e .
```

> **نکته:** برای نصب از PyPI از `pip install easycv-lib` استفاده کنید.

## استفاده

### توابع موجود

#### عملیات تصویر
- `load_image()` - بارگذاری تصویر از فایل
- `show_image()` - نمایش تصویر در پنجره

#### عملیات دوربین
- `open_camera()` - باز کردن دوربین ساده
- `open_live_window()` - نمایش ویدیو زنده پیشرفته
- `open_live_window_from_file()` - پخش ویدیو از فایل

#### تشخیص دست
- `detect_hand()` - تشخیص دست در تصویر
- `hand_read()` - خواندن دست از دوربین (generator)
- `count_fingers()` - شمارش انگشت‌ها (generator)
- `detect_fist()` - تشخیص مشت (generator)

#### تشخیص چهره
- `detect_face()` - تشخیص چهره در تصویر
- `face_read()` - خواندن چهره از دوربین (generator)
- `count_faces()` - شمارش چهره‌ها (generator)
- `face_tracking()` - ردیابی چهره
- `enroll_face()` - ثبت چهره برای تشخیص (نیاز به InsightFace)
- `face_verification()` - تایید هویت چهره (نیاز به InsightFace)

### روش 1: استفاده از ماژول (پیشنهادی)

```python
import easycv.vision as cv

# بارگذاری و نمایش تصویر
img = cv.load_image("photo.jpg")
cv.show_image("photo.jpg")

# باز کردن دوربین
cv.open_camera()

# تشخیص دست در تصویر
result_img, hands = cv.detect_hand(img, draw_landmarks=True)
print(f"تعداد دست‌ها: {len(hands)}")

# شمارش انگشت‌ها از دوربین
for count in cv.count_fingers():
    print(f"تعداد انگشت‌ها: {count}")

# تشخیص چهره
result_img, faces = cv.detect_face(img, draw_landmarks=True)
print(f"تعداد چهره‌ها: {len(faces)}")

# ردیابی چهره
cv.face_tracking()
```

### روش 2: Import مستقیم توابع

```python
from easycv import open_live_window, load_image, detect_hand, detect_face

open_live_window(window_name="Live Feed", show_fps=True)
img = load_image("photo.jpg")
result, hands = detect_hand(img)
```

### روش 3: Import ماژول با نام کوتاه‌تر

```python
from easycv import vision

vision.open_live_window(window_name="Live Feed", show_fps=True)
```

## ساختار پروژه

```
easycv/
├── __init__.py          # نقطه ورود اصلی
├── vision.py            # ماژول پردازش ویدیو و دوربین
└── ...
```

## توسعه

این پروژه در حال توسعه است و توابع به تدریج اضافه خواهند شد.

