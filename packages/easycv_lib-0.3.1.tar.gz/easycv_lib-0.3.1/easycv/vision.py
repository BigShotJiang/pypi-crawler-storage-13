"""
Vision Module - Complete computer vision utilities for EasyCV

This module provides comprehensive functions for:
- Image loading and display
- Camera operations
- Hand detection and tracking
- Face detection, tracking, and recognition
"""

import cv2
import numpy as np
from typing import Optional, Callable, Tuple, Dict, List, Union, Generator
from pathlib import Path
import time
from datetime import datetime
from collections import deque
import os

# MediaPipe (optional but recommended)
try:
    import mediapipe as mp
    MEDIAPIPE_AVAILABLE = True
except ImportError:
    MEDIAPIPE_AVAILABLE = False
    mp = None

# Optional dependencies for advanced features
try:
    from send2trash import send2trash
    SEND2TRASH_AVAILABLE = True
except ImportError:
    SEND2TRASH_AVAILABLE = False

try:
    from insightface.app import FaceAnalysis
    from scipy.spatial.distance import cosine
    INSIGHTFACE_AVAILABLE = True
except ImportError:
    INSIGHTFACE_AVAILABLE = False
    FaceAnalysis = None

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    PYTTSX3_AVAILABLE = False

try:
    import tkinter as tk
    from tkinter import simpledialog
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False


# ============================================================================
# Image Operations
# ============================================================================

def load_image(image_path: Union[str, Path]) -> Optional[np.ndarray]:
    """
    بارگذاری یک تصویر از مسیر فایل.
    
    این تابع به راحتی یک تصویر رو از فایل می‌خونه و برمی‌گردونه.
    می‌تونی بعدش با اون کار کنی، پردازش کنی، یا نمایش بدی.
    
    Args:
        image_path: مسیر فایل تصویر (مثلاً "image.jpg" یا "path/to/image.png")
    
    Returns:
        numpy array تصویر (BGR format) یا None اگر خطا رخ دهد
    
    Examples:
        >>> img = load_image("photo.jpg")
        >>> if img is not None:
        ...     cv2.imshow("Image", img)
        ...     cv2.waitKey(0)
    """
    image_path = Path(image_path)
    
    if not image_path.exists():
        print(f"[خطا] فایل تصویر پیدا نشد: {image_path}")
        return None
    
    try:
        image = cv2.imread(str(image_path))
        if image is None:
            print(f"[خطا] نتوانست تصویر را بخواند: {image_path}")
            return None
        
        print(f"[موفق] تصویر بارگذاری شد: {image_path.name} ({image.shape[1]}x{image.shape[0]})")
        return image
    except Exception as e:
        print(f"[خطا] خطا در بارگذاری تصویر: {e}")
        return None


def show_image(
    image_path: Union[str, Path],
    window_name: str = "Image Viewer",
    window_width: int = 800,
    window_height: int = 600,
    exit_key: str = 'q',
    timeout: Optional[float] = None
) -> None:
    """
    نمایش یک تصویر در پنجره.
    
    Args:
        image_path: مسیر فایل تصویر
        window_name: نام پنجره
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        exit_key: کلید خروج (پیش‌فرض: 'q')
        timeout: زمان خودکار بسته شدن (ثانیه) - None یعنی بدون timeout
    
    Examples:
        >>> show_image("photo.jpg")
        >>> show_image("photo.jpg", timeout=5.0)  # بسته شدن خودکار بعد از 5 ثانیه
    """
    image = cv2.imread(str(image_path))
    
    if image is None:
        print(f"[خطا] تصویر پیدا نشد: {image_path}")
        return
    
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, window_width, window_height)
    cv2.imshow(window_name, image)
    
    start_time = time.time()
    
    while True:
        key = cv2.waitKey(1) & 0xFF
        
        # خروج با کلید مشخص شده
        if key == ord(exit_key) or key == 27:  # ESC
            break
        
        # خروج خودکار بعد از timeout
        if timeout is not None and (time.time() - start_time) > timeout:
            break
    
    cv2.destroyAllWindows()


# ============================================================================
# Camera Operations
# ============================================================================

def open_camera(
    camera_index: int = 0,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = "Live Camera",
    exit_key: str = 'q'
) -> None:
    """
    باز کردن دوربین و نمایش تصویر زنده.
    
    Args:
        camera_index: شماره دوربین (0 برای دوربین پیش‌فرض)
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج (پیش‌فرض: 'q')
    
    Examples:
        >>> open_camera()
        >>> open_camera(camera_index=1, window_name="Camera 2")
    """
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print(f"[خطا] نمی‌تواند دوربین {camera_index} را باز کند")
        return
    
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, window_width, window_height)
    
    print(f"[EasyCV] دوربین باز شد. برای خروج '{exit_key}' یا ESC را فشار دهید.")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("[هشدار] نمی‌تواند فریم را دریافت کند")
            break
        
        cv2.imshow(window_name, frame)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord(exit_key) or key == 27:  # ESC
            break
    
    cap.release()
    cv2.destroyAllWindows()
    print("[EasyCV] دوربین بسته شد.")


def open_live_window(
    camera_index: int = 0,
    window_name: str = "EasyCV Live Feed",
    frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
    show_fps: bool = True,
    resolution: Optional[Tuple[int, int]] = None,
    exit_key: str = 'q',
    flip_horizontal: bool = False,
    flip_vertical: bool = False,
    info_overlay: bool = True,
) -> None:
    """
    نمایش ویدیو زنده از دوربین به ساده ترین شکل!
    
    این تابع به راحتی یک پنجره باز می‌کند و تصویر دوربین رو نشون میده.
    میتونی خیلی راحت تصویر رو برگردونی، اندازه رو تغییر بدی، یا حتی راهی برای پردازش
    ساده هر فریم بذاری. برای مردم عادی طراحی شده تا بدون دغدغه وارد دنیای پردازش تصویر بشن!
    
    Args:
        camera_index: شماره دوربین (۰ دوربین پیش‌فرض)
        window_name: نام پنجره نمایشی
        frame_processor: تابع دلخواه شما که هر فریم رو می‌گیره و برمی‌گردونه
        show_fps: نمایش نرخ فریم (FPS)
        resolution: اندازه تصویر (مثلا (1280, 720))
        exit_key: کلید خروج (پیش‌فرض: q)
        flip_horizontal: تصویر افقی برگرده
        flip_vertical: تصویر عمودی برگرده
        info_overlay: توضیحات کاربری روی صفحه نمایش داده شود یا نه
    
    Examples:
        >>> open_live_window()
        >>> def gray(frame):
        ...     return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        >>> open_live_window(frame_processor=gray)
    """
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print(f"[خطا] باز کردن دوربین {camera_index} ناموفق بود.")
        return
    
    if resolution:
        try:
            w, h = int(resolution[0]), int(resolution[1])
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
        except Exception:
            print("[هشدار] تغییر رزولوشن ناموفق بود.")
    
    fps_counter = 0
    fps_start = cv2.getTickCount()
    current_fps = 0.0
    
    print(f"[EasyCV] لایو شروع شد! خروج با '{exit_key}' یا ESC.")
    
    while True:
        ret, frame = cap.read()
        if not ret or frame is None:
            print("[هشدار] دریافت فریم ناموفق. شاید دوربین قطع شده باشد.")
            break
        
        if flip_horizontal:
            frame = cv2.flip(frame, 1)
        if flip_vertical:
            frame = cv2.flip(frame, 0)
        
        if frame_processor:
            try:
                frame = frame_processor(frame)
            except Exception as e:
                print(f"[خطا] تابع پردازش فریم به مشکل خورد: {e}")
                continue
        
        if show_fps:
            fps_counter += 1
            now = cv2.getTickCount()
            sec = (now - fps_start) / cv2.getTickFrequency()
            if sec > 1.0:
                current_fps = fps_counter / sec
                fps_counter = 0
                fps_start = now
            fps_text = f"FPS: {current_fps:.1f}"
            if isinstance(frame, np.ndarray) and frame.ndim == 2:
                color = 255
            else:
                color = (0, 255, 0)
            cv2.putText(frame, fps_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
        
        if info_overlay and isinstance(frame, np.ndarray):
            info = f"Exit: '{exit_key.upper()}' or ESC"
            cv2.putText(
                frame, info, (10, frame.shape[0] - 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (64, 64, 255), 2
            )
        
        cv2.imshow(window_name, frame)
        
        key = cv2.waitKey(1) & 0xFF
        if key == 27 or key == ord(exit_key):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    print("[EasyCV] پنجره ویدیو بسته شد.")


def open_live_window_from_file(
    video_path: str,
    window_name: str = "EasyCV Video Player",
    frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
    loop: bool = False,
    exit_key: str = 'q'
) -> None:
    """
    باز کردن پنجره برای پخش فایل ویدیو.
    
    Args:
        video_path: مسیر فایل ویدیو
        window_name: نام پنجره
        frame_processor: تابع پردازش فریم (اختیاری)
        loop: آیا ویدیو را loop کند (پیش‌فرض: False)
        exit_key: کلید خروج (پیش‌فرض: 'q')
    
    Examples:
        >>> open_live_window_from_file("video.mp4")
        >>> open_live_window_from_file("video.mp4", loop=True)
    """
    video_path = Path(video_path)
    
    if not video_path.exists():
        raise FileNotFoundError(f"فایل ویدیو پیدا نشد: {video_path}")
    
    cap = cv2.VideoCapture(str(video_path))
    
    if not cap.isOpened():
        raise RuntimeError(f"نمی‌تواند فایل ویدیو را باز کند: {video_path}")
    
    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_delay = int(1000 / fps) if fps > 0 else 30
        
        print(f"[INFO] در حال پخش ویدیو: {video_path.name}")
        print(f"[INFO] برای خروج '{exit_key}' یا ESC را فشار دهید.")
        
        while True:
            ret, frame = cap.read()
            
            if not ret:
                if loop:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                else:
                    print("[INFO] ویدیو تمام شد.")
                    break
            
            if frame_processor is not None:
                try:
                    frame = frame_processor(frame)
                except Exception as e:
                    print(f"[ERROR] خطا در پردازش فریم: {e}")
                    continue
            
            cv2.imshow(window_name, frame)
            
            key = cv2.waitKey(frame_delay) & 0xFF
            if key == ord(exit_key.lower()) or key == 27:
                break
        
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("[INFO] پخش‌کننده ویدیو بسته شد.")


# ============================================================================
# Hand Detection
# ============================================================================

def detect_hand(
    image: np.ndarray,
    draw_landmarks: bool = True,
    max_hands: int = 2,
    min_detection_confidence: float = 0.5,
    min_tracking_confidence: float = 0.5
) -> Tuple[np.ndarray, List[Dict]]:
    """
    تشخیص دست انسان در تصویر با استفاده از MediaPipe.
    
    Args:
        image: تصویر ورودی (numpy array)
        draw_landmarks: آیا landmark های دست روی تصویر رسم شوند
        max_hands: حداکثر تعداد دست‌های قابل تشخیص
        min_detection_confidence: حداقل اطمینان برای تشخیص (0.0 تا 1.0)
        min_tracking_confidence: حداقل اطمینان برای tracking (0.0 تا 1.0)
    
    Returns:
        tuple شامل:
            - تصویر با landmark های رسم شده (یا تصویر اصلی)
            - لیست dictionary های اطلاعات دست‌ها
    
    Examples:
        >>> img = load_image("hand.jpg")
        >>> result_img, hands = detect_hand(img)
        >>> print(f"تعداد دست‌ها: {len(hands)}")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError(
            "MediaPipe نصب نشده است. برای استفاده از این تابع، MediaPipe را نصب کنید:\n"
            "pip install mediapipe"
        )
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image_rgb.flags.writeable = False
    
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=True,
        max_num_hands=max_hands,
        min_detection_confidence=min_detection_confidence,
        min_tracking_confidence=min_tracking_confidence
    )
    
    results = hands.process(image_rgb)
    
    image_rgb.flags.writeable = True
    output_image = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    
    hands_data = []
    
    if results.multi_hand_landmarks:
        mp_drawing = mp.solutions.drawing_utils
        
        for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
            if draw_landmarks:
                mp_drawing.draw_landmarks(
                    output_image,
                    hand_landmarks,
                    mp_hands.HAND_CONNECTIONS,
                    mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2),
                    mp_drawing.DrawingSpec(color=(255, 0, 0), thickness=2)
                )
            
            hand_info = {
                'landmarks': [],
                'handedness': handedness.classification[0].label,
                'confidence': handedness.classification[0].score
            }
            
            h, w, _ = image.shape
            for landmark in hand_landmarks.landmark:
                hand_info['landmarks'].append({
                    'x': landmark.x * w,
                    'y': landmark.y * h,
                    'z': landmark.z
                })
            
            hands_data.append(hand_info)
    
    hands.close()
    
    print(f"[EasyCV] {len(hands_data)} دست تشخیص داده شد")
    return output_image, hands_data


def hand_read(
    camera_index: int = 0,
    show_camera: bool = True,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = 'Hand Detection',
    exit_key: str = 'q'
) -> Generator[str, None, None]:
    """
    خواندن و تشخیص دست از دوربین (generator function).
    
    این تابع یک generator است که در هر فریم label دست را برمی‌گرداند.
    
    Args:
        camera_index: شماره دوربین
        show_camera: آیا دوربین نمایش داده شود
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
    
    Yields:
        str: label دست ('Left', 'Right', یا 'None')
    
    Examples:
        >>> for hand_label in hand_read():
        ...     print(hand_label)
        ...     if hand_label != 'None':
        ...         break
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError("MediaPipe نصب نشده است. pip install mediapipe")
    
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=2,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    )
    
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    if show_camera:
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, window_width, window_height)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)
            
            hand_label = 'None'
            
            if results.multi_hand_landmarks and results.multi_handedness:
                for idx, hand_handedness in enumerate(results.multi_handedness):
                    label = hand_handedness.classification[0].label
                    hand_landmarks = results.multi_hand_landmarks[idx]
                    
                    if show_camera:
                        for landmark in hand_landmarks.landmark:
                            x = int(landmark.x * frame.shape[1])
                            y = int(landmark.y * frame.shape[0])
                            cv2.circle(frame, (x, y), 5, (0, 255, 0), -1)
                    
                    hand_label = label
                    break
            
            if show_camera:
                cv2.putText(frame, f'Hand: {hand_label}', (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2, cv2.LINE_AA)
                cv2.imshow(window_name, frame)
            
            yield hand_label
            
            key = cv2.waitKey(1) & 0xFF
            if show_camera and (key == ord(exit_key) or key == 27):
                break
    finally:
        cap.release()
        hands.close()
        if show_camera:
            cv2.destroyAllWindows()


def count_fingers(
    camera_index: int = 0,
    show_camera: bool = True,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = "Finger Counter",
    exit_key: str = 'q'
) -> Generator[int, None, None]:
    """
    شمارش انگشت‌های دست از دوربین (generator function).
    
    Args:
        camera_index: شماره دوربین
        show_camera: آیا دوربین نمایش داده شود
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
    
    Yields:
        int: تعداد انگشت‌های باز شده
    
    Examples:
        >>> for count in count_fingers():
        ...     print(f"تعداد انگشت‌ها: {count}")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError("MediaPipe نصب نشده است. pip install mediapipe")
    
    mp_hands = mp.solutions.hands
    mp_drawing = mp.solutions.drawing_utils
    
    def get_finger_count(hand_landmarks):
        tips_ids = [4, 8, 12, 16, 20]
        fingers = []
        
        # انگشت شست
        if hand_landmarks.landmark[tips_ids[0]].x < hand_landmarks.landmark[tips_ids[0] - 1].x:
            fingers.append(1)
        else:
            fingers.append(0)
        
        # بقیه انگشت‌ها
        for i in range(1, 5):
            if hand_landmarks.landmark[tips_ids[i]].y < hand_landmarks.landmark[tips_ids[i] - 2].y:
                fingers.append(1)
            else:
                fingers.append(0)
        
        return sum(fingers)
    
    cap = cv2.VideoCapture(camera_index)
    
    if show_camera:
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, window_width, window_height)
    
    with mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7) as hands:
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                frame = cv2.flip(frame, 1)
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                result = hands.process(rgb_frame)
                
                finger_count = 0
                
                if result.multi_hand_landmarks:
                    for hand_landmarks in result.multi_hand_landmarks:
                        finger_count = get_finger_count(hand_landmarks)
                        if show_camera:
                            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                
                if show_camera:
                    cv2.putText(frame, f'Fingers: {finger_count}', (50, 50),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)
                    cv2.imshow(window_name, frame)
                
                yield finger_count
                
                key = cv2.waitKey(1) & 0xFF
                if key == ord(exit_key) or key == 27:
                    break
        finally:
            cap.release()
            if show_camera:
                cv2.destroyAllWindows()


def detect_fist(
    camera_index: int = 0,
    show_camera: bool = True,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = 'Fist Detection',
    exit_key: str = 'q'
) -> Generator[bool, None, None]:
    """
    تشخیص مشت از دوربین (generator function).
    
    Args:
        camera_index: شماره دوربین
        show_camera: آیا دوربین نمایش داده شود
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
    
    Yields:
        bool: True اگر مشت تشخیص داده شود، False در غیر این صورت
    
    Examples:
        >>> for is_fist in detect_fist():
        ...     if is_fist:
        ...         print("مشت تشخیص داده شد!")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError("MediaPipe نصب نشده است. pip install mediapipe")
    
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
    mp_draw = mp.solutions.drawing_utils
    
    cap = cv2.VideoCapture(camera_index)
    
    if show_camera:
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, window_width, window_height)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(frame_rgb)
            
            fist_detected = False
            
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                    
                    landmarks = hand_landmarks.landmark
                    thumb_tip = landmarks[4]
                    index_tip = landmarks[8]
                    middle_tip = landmarks[12]
                    ring_tip = landmarks[16]
                    pinky_tip = landmarks[20]
                    
                    if (thumb_tip.y > index_tip.y and
                        thumb_tip.y > middle_tip.y and
                        thumb_tip.y > ring_tip.y and
                        thumb_tip.y > pinky_tip.y):
                        fist_detected = True
                    
                    break
            
            if show_camera:
                text = "FIST DETECTED" if fist_detected else "HAND OPEN"
                color = (0, 0, 255) if fist_detected else (0, 255, 0)
                cv2.putText(frame, text, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
                cv2.imshow(window_name, frame)
            
            yield fist_detected
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord(exit_key) or key == 27:
                break
    finally:
        cap.release()
        hands.close()
        if show_camera:
            cv2.destroyAllWindows()


# ============================================================================
# Face Detection
# ============================================================================

def detect_face(
    image: np.ndarray,
    draw_landmarks: bool = True,
    max_faces: int = 1,
    min_detection_confidence: float = 0.5,
    refine_landmarks: bool = False
) -> Tuple[np.ndarray, List[Dict]]:
    """
    تشخیص چهره انسان در تصویر با استفاده از MediaPipe.
    
    Args:
        image: تصویر ورودی (numpy array)
        draw_landmarks: آیا landmark های چهره روی تصویر رسم شوند
        max_faces: حداکثر تعداد چهره‌های قابل تشخیص
        min_detection_confidence: حداقل اطمینان برای تشخیص (0.0 تا 1.0)
        refine_landmarks: استفاده از مدل دقیق‌تر برای landmark ها
    
    Returns:
        tuple شامل:
            - تصویر با landmark های رسم شده (یا تصویر اصلی)
            - لیست dictionary های اطلاعات چهره‌ها
    
    Examples:
        >>> img = load_image("face.jpg")
        >>> result_img, faces = detect_face(img)
        >>> print(f"تعداد چهره‌ها: {len(faces)}")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError(
            "MediaPipe نصب نشده است. برای استفاده از این تابع، MediaPipe را نصب کنید:\n"
            "pip install mediapipe"
        )
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image_rgb.flags.writeable = False
    
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        static_image_mode=True,
        max_num_faces=max_faces,
        refine_landmarks=refine_landmarks,
        min_detection_confidence=min_detection_confidence,
        min_tracking_confidence=0.5
    )
    
    results = face_mesh.process(image_rgb)
    
    image_rgb.flags.writeable = True
    output_image = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    
    faces_data = []
    
    if results.multi_face_landmarks:
        mp_drawing = mp.solutions.drawing_utils
        mp_drawing_styles = mp.solutions.drawing_styles
        
        for face_landmarks in results.multi_face_landmarks:
            if draw_landmarks:
                mp_drawing.draw_landmarks(
                    output_image,
                    face_landmarks,
                    mp_face_mesh.FACEMESH_CONTOURS,
                    None,
                    mp_drawing_styles.get_default_face_mesh_contours_style()
                )
            
            face_info = {
                'landmarks': []
            }
            
            h, w, _ = image.shape
            for landmark in face_landmarks.landmark:
                face_info['landmarks'].append({
                    'x': landmark.x * w,
                    'y': landmark.y * h,
                    'z': landmark.z
                })
            
            faces_data.append(face_info)
    
    face_mesh.close()
    
    print(f"[EasyCV] {len(faces_data)} چهره تشخیص داده شد")
    return output_image, faces_data


def face_read(
    camera_index: int = 0,
    show_camera: bool = True,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = 'Face Detection',
    exit_key: str = 'q'
) -> Generator[bool, None, None]:
    """
    خواندن و تشخیص چهره از دوربین (generator function).
    
    Args:
        camera_index: شماره دوربین
        show_camera: آیا دوربین نمایش داده شود
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
    
    Yields:
        bool: True اگر چهره تشخیص داده شود، False در غیر این صورت
    
    Examples:
        >>> for face_detected in face_read():
        ...     if face_detected:
        ...         print("چهره تشخیص داده شد!")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError("MediaPipe نصب نشده است. pip install mediapipe")
    
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        static_image_mode=False,
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5
    )
    
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    if show_camera:
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, window_width, window_height)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb_frame)
            
            face_detected = False
            
            if results.multi_face_landmarks:
                face_detected = True
                if show_camera:
                    for face_landmarks in results.multi_face_landmarks:
                        for landmark in face_landmarks.landmark:
                            x = int(landmark.x * frame.shape[1])
                            y = int(landmark.y * frame.shape[0])
                            cv2.circle(frame, (x, y), 1, (0, 255, 0), -1)
            
            if show_camera:
                text = 'Face Detected' if face_detected else 'No Face'
                cv2.putText(frame, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                            1, (255, 255, 0), 2, cv2.LINE_AA)
                cv2.imshow(window_name, frame)
            
            yield face_detected
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord(exit_key) or key == 27:
                break
    finally:
        cap.release()
        face_mesh.close()
        if show_camera:
            cv2.destroyAllWindows()


def count_faces(
    camera_index: int = 0,
    show_camera: bool = True,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = 'Face Counter',
    exit_key: str = 'q'
) -> Generator[int, None, None]:
    """
    شمارش چهره‌ها از دوربین (generator function).
    
    Args:
        camera_index: شماره دوربین
        show_camera: آیا دوربین نمایش داده شود
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
    
    Yields:
        int: تعداد چهره‌های تشخیص داده شده
    
    Examples:
        >>> for count in count_faces():
        ...     print(f"تعداد چهره‌ها: {count}")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError("MediaPipe نصب نشده است. pip install mediapipe")
    
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        static_image_mode=False,
        max_num_faces=10,
        refine_landmarks=True,
        min_detection_confidence=0.5
    )
    
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    if show_camera:
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, window_width, window_height)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb_frame)
            
            face_count = 0
            
            if results.multi_face_landmarks:
                face_count = len(results.multi_face_landmarks)
                if show_camera:
                    for face_landmarks in results.multi_face_landmarks:
                        for landmark in face_landmarks.landmark:
                            x = int(landmark.x * frame.shape[1])
                            y = int(landmark.y * frame.shape[0])
                            cv2.circle(frame, (x, y), 1, (0, 255, 0), -1)
            
            if show_camera:
                cv2.putText(frame, f'Faces: {face_count}', (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2, cv2.LINE_AA)
                cv2.imshow(window_name, frame)
            
            yield face_count
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord(exit_key) or key == 27:
                break
    finally:
        cap.release()
        face_mesh.close()
        if show_camera:
            cv2.destroyAllWindows()


def face_tracking(
    camera_index: int = 0,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = "Face Tracker",
    exit_key: str = 'q'
) -> None:
    """
    ردیابی چهره با استفاده از Haar Cascade و KCF Tracker.
    
    Args:
        camera_index: شماره دوربین
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
    
    Examples:
        >>> face_tracking()
    """
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print("[خطا] نمی‌تواند دوربین را باز کند")
        return
    
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, window_width, window_height)
    
    tracker = None
    tracking = False
    face_box = None
    
    print(f"[EasyCV] ردیابی چهره شروع شد. برای خروج '{exit_key}' یا ESC را فشار دهید.")
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            if not tracking:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=6, minSize=(40, 40))
                
                if len(faces) > 0:
                    (x, y, w, h) = faces[0]
                    face_box = (x, y, w, h)
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                    
                    tracker = cv2.TrackerKCF_create()
                    tracker.init(frame, face_box)
                    tracking = True
                else:
                    cv2.putText(frame, "Face not found", (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            else:
                ok, face_box = tracker.update(frame)
                if ok:
                    (x, y, w, h) = tuple(map(int, face_box))
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
                else:
                    tracking = False
            
            cv2.imshow(window_name, frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord(exit_key) or key == 27:
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("[EasyCV] ردیابی چهره بسته شد.")


def enroll_face(
    camera_index: int = 0,
    window_width: int = 1920,
    window_height: int = 1080,
    window_name: str = "Face Enrollment",
    exit_key: str = 'q',
    output_file: str = "face_embeddings.pkl"
) -> None:
    """
    ثبت چهره برای سیستم تشخیص چهره (نیاز به InsightFace).
    
    Args:
        camera_index: شماره دوربین
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
        output_file: مسیر فایل خروجی برای ذخیره embeddings
    
    Examples:
        >>> enroll_face(output_file="my_faces.pkl")
    """
    if not INSIGHTFACE_AVAILABLE:
        raise ImportError(
            "InsightFace نصب نشده است. برای استفاده از این تابع:\n"
            "pip install insightface scipy"
        )
    
    if not TKINTER_AVAILABLE:
        raise ImportError("tkinter در دسترس نیست. این تابع نیاز به tkinter دارد.")
    
    positions = ["Front", "Left", "Right", "Up", "Down"]
    embeddings = []
    
    app = FaceAnalysis(name="buffalo_l", providers=['CPUExecutionProvider'])
    app.prepare(ctx_id=0, det_size=(640, 640))
    
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, window_width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, window_height)
    
    print("[EasyCV] دوربین فعال شد. آماده ثبت چهره.")
    
    def get_user_name():
        root = tk.Tk()
        root.withdraw()
        user_name = simpledialog.askstring("نام کاربر", "لطفاً نام خود را وارد کنید:")
        root.destroy()
        return user_name
    
    user_name = get_user_name()
    if not user_name:
        print("[خطا] نام وارد نشد. فرایند ثبت لغو شد.")
        cap.release()
        cv2.destroyAllWindows()
        return
    
    def is_face_valid(face, frame_shape, min_box_size=100):
        box = face.bbox.astype(int)
        w, h = box[2] - box[0], box[3] - box[1]
        if w < min_box_size or h < min_box_size:
            return False
        frame_w, frame_h = frame_shape[1], frame_shape[0]
        face_center_x = (box[0] + box[2]) // 2
        face_center_y = (box[1] + box[3]) // 2
        if abs(face_center_x - frame_w // 2) > frame_w * 0.3 or abs(face_center_y - frame_h // 2) > frame_h * 0.3:
            return False
        return True
    
    try:
        for pos in positions:
            print(f"\nلطفاً سر خود را به سمت {pos} بچرخانید و به دوربین نگاه کنید.")
            print(f"در انتظار چهره... (برای خروج {exit_key.upper()} را فشار دهید)")
            
            embedding_buffer = deque(maxlen=30)
            start_time = time.time()
            timeout = 60
            
            while True:
                ret, frame = cap.read()
                if not ret:
                    print("[خطا] دریافت فریم ناموفق")
                    continue
                
                faces = app.get(frame)
                if len(faces) == 1 and is_face_valid(faces[0], frame.shape):
                    face = faces[0]
                    box = face.bbox.astype(int)
                    cv2.rectangle(frame, (box[0], box[1]), (box[2], box[3]), (0, 255, 0), 2)
                    
                    emb = face.embedding
                    embedding_buffer.append(emb)
                    
                    if len(embedding_buffer) >= 20:
                        mean_emb = np.mean(embedding_buffer, axis=0)
                        embeddings.append({
                            "name": user_name,
                            "position": pos,
                            "embedding": mean_emb.tolist(),
                            "timestamp": datetime.now().isoformat()
                        })
                        print(f"\nموقعیت '{pos}' با {len(embedding_buffer)} embedding ثبت شد.")
                        break
                else:
                    message = "چهره تشخیص داده نشد." if len(faces) == 0 else "چند چهره/چهره نامعتبر تشخیص داده شد."
                    print(message + " سر خود را تنظیم کنید.", end='\r')
                
                cv2.putText(frame, f"Position: {pos}", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)
                cv2.imshow(window_name, frame)
                
                if cv2.waitKey(1) & 0xFF == ord(exit_key):
                    print("[لغو] ثبت چهره لغو شد.")
                    cap.release()
                    cv2.destroyAllWindows()
                    return
                
                if time.time() - start_time > timeout:
                    print(f"\n[Timeout] در موقعیت '{pos}'. دوباره تلاش می‌کند...")
                    embedding_buffer.clear()
                    start_time = time.time()
    finally:
        cap.release()
        cv2.destroyAllWindows()
    
    if embeddings:
        import pickle
        previous_face_data = []
        if os.path.exists(output_file):
            with open(output_file, "rb") as f:
                try:
                    data = pickle.load(f)
                    previous_face_data = data.get("face_data", [])
                except Exception as e:
                    print(f"[خطا] خطا در بارگذاری داده‌های قبلی: {e}")
        
        combined_face_data = previous_face_data + embeddings
        
        output = {
            "enrollment_time": datetime.now().isoformat(),
            "face_data": combined_face_data
        }
        
        with open(output_file, "wb") as f:
            pickle.dump(output, f)
        
        print(f"\n[موفق] مدل چهره با موفقیت در '{output_file}' ذخیره شد.")
    else:
        print("[خطا] هیچ داده چهره‌ای ثبت نشد.")


def face_verification(
    camera_index: int = 0,
    window_width: int = 800,
    window_height: int = 600,
    window_name: str = "Face Verification",
    exit_key: str = 'q',
    model_path: str = "face_embeddings.pkl"
) -> None:
    """
    تایید هویت چهره با استفاده از InsightFace (نیاز به مدل ثبت شده).
    
    Args:
        camera_index: شماره دوربین
        window_width: عرض پنجره
        window_height: ارتفاع پنجره
        window_name: نام پنجره
        exit_key: کلید خروج
        model_path: مسیر فایل مدل ثبت شده
    
    Examples:
        >>> face_verification(model_path="my_faces.pkl")
    """
    if not INSIGHTFACE_AVAILABLE:
        raise ImportError(
            "InsightFace نصب نشده است. برای استفاده از این تابع:\n"
            "pip install insightface scipy"
        )
    
    if not PYTTSX3_AVAILABLE:
        print("[هشدار] pyttsx3 نصب نشده است. قابلیت گفتار غیرفعال است.")
    
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"فایل مدل پیدا نشد: {model_path}")
    
    import pickle
    
    with open(model_path, "rb") as f:
        data = pickle.load(f)
    
    ref_embeddings = []
    ref_names = []
    for item in data["face_data"]:
        emb = np.array(item["embedding"])
        emb = emb / np.linalg.norm(emb)
        ref_embeddings.append(emb)
        ref_names.append(item.get("name", "Unknown"))
    
    ref_embeddings = np.array(ref_embeddings)
    
    app = FaceAnalysis(name="buffalo_l", providers=['CPUExecutionProvider'])
    app.prepare(ctx_id=0, det_size=(640, 640))
    
    cap = cv2.VideoCapture(camera_index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, window_width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, window_height)
    
    print("[EasyCV] دوربین شروع شد. در حال جستجوی چهره...")
    
    threshold = 0.55
    threshold_time = 10
    alpha = 0.6
    buffer_size = 30
    
    embedding_buffers = {}
    mean_embs = {}
    recognized_times = {}
    miss_frames_counts = {}
    recognized_names = {}
    spoken_ids = set()
    
    if PYTTSX3_AVAILABLE:
        engine = pyttsx3.init()
        engine.setProperty('rate', 150)
    
    def draw_status_text(frame, text, color):
        rect_h = 30
        rect_y = frame.shape[0] - rect_h - 10
        cv2.rectangle(frame, (0, rect_y), (frame.shape[1], rect_y + rect_h), (0, 0, 0), -1)
        cv2.putText(frame, text, (10, rect_y + 22), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
    
    def enhance_image(frame):
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        frame[:, :, 0] = cv2.equalizeHist(frame[:, :, 0])
        frame = cv2.cvtColor(frame, cv2.COLOR_YCrCb2BGR)
        return frame
    
    def say_names(names_list):
        if not names_list or not PYTTSX3_AVAILABLE:
            return
        text = " سلام " + " و ".join(names_list)
        engine.say(text)
        engine.runAndWait()
    
    last_time = time.time()
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("[خطا] دریافت فریم ناموفق")
                continue
            
            frame = enhance_image(frame)
            faces = app.get(frame)
            current_time = time.time()
            dt = current_time - last_time
            last_time = current_time
            
            if len(faces) > 0:
                current_face_ids = set(range(len(faces)))
                for old_id in list(recognized_times.keys()):
                    if old_id not in current_face_ids:
                        recognized_times.pop(old_id, None)
                        embedding_buffers.pop(old_id, None)
                        mean_embs.pop(old_id, None)
                        miss_frames_counts.pop(old_id, None)
                        recognized_names.pop(old_id, None)
                        spoken_ids.discard(old_id)
                
                to_speak_names = []
                
                for i, face in enumerate(faces):
                    emb = face.embedding
                    emb = emb / np.linalg.norm(emb)
                    
                    if i not in embedding_buffers:
                        embedding_buffers[i] = deque(maxlen=buffer_size)
                        mean_embs[i] = None
                        recognized_times[i] = 0
                        miss_frames_counts[i] = 0
                        recognized_names[i] = "Unknown"
                    
                    embedding_buffers[i].append(emb)
                    
                    if mean_embs[i] is None:
                        mean_embs[i] = emb
                    else:
                        mean_embs[i] = alpha * emb + (1 - alpha) * mean_embs[i]
                        mean_embs[i] = mean_embs[i] / np.linalg.norm(mean_embs[i])
                    
                    distances = np.array([cosine(mean_embs[i], ref_emb) for ref_emb in ref_embeddings])
                    min_dist_idx = np.argmin(distances)
                    min_dist = distances[min_dist_idx]
                    
                    if min_dist < threshold:
                        recognized_times[i] += dt
                        miss_frames_counts[i] = 0
                        if recognized_times[i] >= threshold_time:
                            recognized_names[i] = ref_names[min_dist_idx]
                            if i not in spoken_ids:
                                to_speak_names.append(recognized_names[i])
                                spoken_ids.add(i)
                        else:
                            recognized_names[i] = "Unknown"
                    else:
                        miss_frames_counts[i] += 1
                        if miss_frames_counts[i] > buffer_size:
                            recognized_times[i] = 0
                            recognized_names[i] = "Unknown"
                        else:
                            recognized_names[i] = "Unknown"
                    
                    box = face.bbox.astype(int)
                    color = (0, 255, 0) if min_dist < threshold else (0, 0, 255)
                    cv2.rectangle(frame, (box[0], box[1]), (box[2], box[3]), color, 2)
                    
                    cv2.putText(frame, f"{recognized_names[i]}", (box[0], box[1] - 40),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                    
                    match_text = "Match" if min_dist < threshold else "Not Match"
                    cv2.putText(frame, f"ID {i}: {match_text} (Dist: {min_dist:.2f})",
                                (box[0], box[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                
                if to_speak_names:
                    say_names(to_speak_names)
            
            else:
                embedding_buffers.clear()
                mean_embs.clear()
                recognized_times.clear()
                miss_frames_counts.clear()
                recognized_names.clear()
                spoken_ids.clear()
                cv2.putText(frame, "No face detected", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
            
            for i, recognized_time in recognized_times.items():
                if recognized_time >= threshold_time:
                    draw_status_text(frame, f"ID {i} recognized for over {threshold_time} seconds!", (0, 255, 0))
                else:
                    draw_status_text(frame, f"ID {i} not recognized for {threshold_time} seconds yet", (0, 255, 255))
            
            cv2.imshow(window_name, frame)
            
            key = cv2.waitKey(1)
            if key & 0xFF == ord(exit_key):
                break
    
    except Exception as e:
        print(f"[خطا] خطا رخ داد: {e}")
    
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("[EasyCV] تایید هویت بسته شد.")

