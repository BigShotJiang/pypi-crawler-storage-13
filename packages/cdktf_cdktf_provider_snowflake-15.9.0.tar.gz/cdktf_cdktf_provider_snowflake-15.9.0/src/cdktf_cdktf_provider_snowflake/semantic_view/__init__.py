r'''
# `snowflake_semantic_view`

Refer to the Terraform Registry for docs: [`snowflake_semantic_view`](https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktf as _cdktf_9a9027ec
import constructs as _constructs_77d1e7e8


class SemanticView(
    _cdktf_9a9027ec.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticView",
):
    '''Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view snowflake_semantic_view}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        tables: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewTables", typing.Dict[builtins.str, typing.Any]]]],
        comment: typing.Optional[builtins.str] = None,
        dimensions: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewDimensions", typing.Dict[builtins.str, typing.Any]]]]] = None,
        facts: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewFacts", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        metrics: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewMetrics", typing.Dict[builtins.str, typing.Any]]]]] = None,
        relationships: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewRelationships", typing.Dict[builtins.str, typing.Any]]]]] = None,
        timeouts: typing.Optional[typing.Union["SemanticViewTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view snowflake_semantic_view} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param database: The database in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#database SemanticView#database}
        :param name: Specifies the identifier for the semantic view; must be unique within the schema. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#name SemanticView#name}
        :param schema: The schema in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#schema SemanticView#schema}
        :param tables: tables block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#tables SemanticView#tables}
        :param comment: Specifies a comment for the semantic view. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param dimensions: dimensions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#dimensions SemanticView#dimensions}
        :param facts: facts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#facts SemanticView#facts}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#id SemanticView#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param metrics: metrics block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#metrics SemanticView#metrics}
        :param relationships: relationships block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#relationships SemanticView#relationships}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#timeouts SemanticView#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6abd42e19075da522116ed6d33c19bc9f52db60d14f937eac2eaccda8676781c)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = SemanticViewConfig(
            database=database,
            name=name,
            schema=schema,
            tables=tables,
            comment=comment,
            dimensions=dimensions,
            facts=facts,
            id=id,
            metrics=metrics,
            relationships=relationships,
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    ) -> _cdktf_9a9027ec.ImportableResource:
        '''Generates CDKTF code for importing a SemanticView resource upon running "cdktf plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the SemanticView to import.
        :param import_from_id: The id of the existing SemanticView that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the SemanticView to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16a3c43ed79aea5ed9056ca374b7a9263c13c7cac91f707312839cb7d9194e8b)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktf_9a9027ec.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putDimensions")
    def put_dimensions(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewDimensions", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edf8219010d960572d4fc647baac52805111e91f807f80e3d05720907c3cc072)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putDimensions", [value]))

    @jsii.member(jsii_name="putFacts")
    def put_facts(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewFacts", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b8ab730b95b9620f6ae95bc2cb83ab4ed9ae409ad60ddfe193b2bed462fb44e0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putFacts", [value]))

    @jsii.member(jsii_name="putMetrics")
    def put_metrics(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewMetrics", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41fb5b83745944877344604a9acfb22ccd8dc1ee6dd1917e613976a1e6b06354)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putMetrics", [value]))

    @jsii.member(jsii_name="putRelationships")
    def put_relationships(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewRelationships", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2c769d2157b1d61831a2bd86ebc99c99414cf9a0e4ec20d06d500576f3a68a2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRelationships", [value]))

    @jsii.member(jsii_name="putTables")
    def put_tables(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewTables", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28d6eea80375658cc3e7720f3f886e5fafeea5146a714868ebdac25df86025ea)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putTables", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#create SemanticView#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#delete SemanticView#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#read SemanticView#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#update SemanticView#update}.
        '''
        value = SemanticViewTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetDimensions")
    def reset_dimensions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDimensions", []))

    @jsii.member(jsii_name="resetFacts")
    def reset_facts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFacts", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetMetrics")
    def reset_metrics(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMetrics", []))

    @jsii.member(jsii_name="resetRelationships")
    def reset_relationships(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRelationships", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="dimensions")
    def dimensions(self) -> "SemanticViewDimensionsList":
        return typing.cast("SemanticViewDimensionsList", jsii.get(self, "dimensions"))

    @builtins.property
    @jsii.member(jsii_name="facts")
    def facts(self) -> "SemanticViewFactsList":
        return typing.cast("SemanticViewFactsList", jsii.get(self, "facts"))

    @builtins.property
    @jsii.member(jsii_name="fullyQualifiedName")
    def fully_qualified_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fullyQualifiedName"))

    @builtins.property
    @jsii.member(jsii_name="metrics")
    def metrics(self) -> "SemanticViewMetricsList":
        return typing.cast("SemanticViewMetricsList", jsii.get(self, "metrics"))

    @builtins.property
    @jsii.member(jsii_name="relationships")
    def relationships(self) -> "SemanticViewRelationshipsList":
        return typing.cast("SemanticViewRelationshipsList", jsii.get(self, "relationships"))

    @builtins.property
    @jsii.member(jsii_name="showOutput")
    def show_output(self) -> "SemanticViewShowOutputList":
        return typing.cast("SemanticViewShowOutputList", jsii.get(self, "showOutput"))

    @builtins.property
    @jsii.member(jsii_name="tables")
    def tables(self) -> "SemanticViewTablesList":
        return typing.cast("SemanticViewTablesList", jsii.get(self, "tables"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "SemanticViewTimeoutsOutputReference":
        return typing.cast("SemanticViewTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="databaseInput")
    def database_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "databaseInput"))

    @builtins.property
    @jsii.member(jsii_name="dimensionsInput")
    def dimensions_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewDimensions"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewDimensions"]]], jsii.get(self, "dimensionsInput"))

    @builtins.property
    @jsii.member(jsii_name="factsInput")
    def facts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewFacts"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewFacts"]]], jsii.get(self, "factsInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="metricsInput")
    def metrics_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewMetrics"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewMetrics"]]], jsii.get(self, "metricsInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="relationshipsInput")
    def relationships_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewRelationships"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewRelationships"]]], jsii.get(self, "relationshipsInput"))

    @builtins.property
    @jsii.member(jsii_name="schemaInput")
    def schema_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "schemaInput"))

    @builtins.property
    @jsii.member(jsii_name="tablesInput")
    def tables_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTables"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTables"]]], jsii.get(self, "tablesInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "SemanticViewTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "SemanticViewTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de4c2c66b732960dbd368367d789e37c60fc928c429eb3095ad756b0566a23d1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="database")
    def database(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "database"))

    @database.setter
    def database(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5eab852463f8b3710f71c5b37cd2bf3821a47a826a25cab2377c036fa0ba072f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "database", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e6fc712459f9ac790f189b2e2c79544369ace868bb2b11f8db1dff7f740e6a57)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__13c2a0a66fc1b29dc526a5ea88602c7bcef132487fd8b03b7c3f196a254355d8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="schema")
    def schema(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schema"))

    @schema.setter
    def schema(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ac76a5be2e512371dd6ca9ef3c633452325c58b81e6e275451f656ac71c4cef9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "schema", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "database": "database",
        "name": "name",
        "schema": "schema",
        "tables": "tables",
        "comment": "comment",
        "dimensions": "dimensions",
        "facts": "facts",
        "id": "id",
        "metrics": "metrics",
        "relationships": "relationships",
        "timeouts": "timeouts",
    },
)
class SemanticViewConfig(_cdktf_9a9027ec.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        database: builtins.str,
        name: builtins.str,
        schema: builtins.str,
        tables: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewTables", typing.Dict[builtins.str, typing.Any]]]],
        comment: typing.Optional[builtins.str] = None,
        dimensions: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewDimensions", typing.Dict[builtins.str, typing.Any]]]]] = None,
        facts: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewFacts", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        metrics: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewMetrics", typing.Dict[builtins.str, typing.Any]]]]] = None,
        relationships: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewRelationships", typing.Dict[builtins.str, typing.Any]]]]] = None,
        timeouts: typing.Optional[typing.Union["SemanticViewTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param database: The database in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#database SemanticView#database}
        :param name: Specifies the identifier for the semantic view; must be unique within the schema. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#name SemanticView#name}
        :param schema: The schema in which to create the semantic view. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#schema SemanticView#schema}
        :param tables: tables block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#tables SemanticView#tables}
        :param comment: Specifies a comment for the semantic view. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param dimensions: dimensions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#dimensions SemanticView#dimensions}
        :param facts: facts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#facts SemanticView#facts}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#id SemanticView#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param metrics: metrics block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#metrics SemanticView#metrics}
        :param relationships: relationships block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#relationships SemanticView#relationships}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#timeouts SemanticView#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(timeouts, dict):
            timeouts = SemanticViewTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dfc0d65439beca57957c8190b6c5ee5ce12ce859fedeeb9bb903ddf8dae7664b)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument database", value=database, expected_type=type_hints["database"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
            check_type(argname="argument tables", value=tables, expected_type=type_hints["tables"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
            check_type(argname="argument facts", value=facts, expected_type=type_hints["facts"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument metrics", value=metrics, expected_type=type_hints["metrics"])
            check_type(argname="argument relationships", value=relationships, expected_type=type_hints["relationships"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "database": database,
            "name": name,
            "schema": schema,
            "tables": tables,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if comment is not None:
            self._values["comment"] = comment
        if dimensions is not None:
            self._values["dimensions"] = dimensions
        if facts is not None:
            self._values["facts"] = facts
        if id is not None:
            self._values["id"] = id
        if metrics is not None:
            self._values["metrics"] = metrics
        if relationships is not None:
            self._values["relationships"] = relationships
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def database(self) -> builtins.str:
        '''The database in which to create the semantic view.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#database SemanticView#database}
        '''
        result = self._values.get("database")
        assert result is not None, "Required property 'database' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Specifies the identifier for the semantic view;

        must be unique within the schema. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#name SemanticView#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def schema(self) -> builtins.str:
        '''The schema in which to create the semantic view.

        Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#schema SemanticView#schema}
        '''
        result = self._values.get("schema")
        assert result is not None, "Required property 'schema' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def tables(
        self,
    ) -> typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTables"]]:
        '''tables block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#tables SemanticView#tables}
        '''
        result = self._values.get("tables")
        assert result is not None, "Required property 'tables' is missing"
        return typing.cast(typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTables"]], result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the semantic view.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def dimensions(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewDimensions"]]]:
        '''dimensions block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#dimensions SemanticView#dimensions}
        '''
        result = self._values.get("dimensions")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewDimensions"]]], result)

    @builtins.property
    def facts(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewFacts"]]]:
        '''facts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#facts SemanticView#facts}
        '''
        result = self._values.get("facts")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewFacts"]]], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#id SemanticView#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def metrics(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewMetrics"]]]:
        '''metrics block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#metrics SemanticView#metrics}
        '''
        result = self._values.get("metrics")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewMetrics"]]], result)

    @builtins.property
    def relationships(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewRelationships"]]]:
        '''relationships block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#relationships SemanticView#relationships}
        '''
        result = self._values.get("relationships")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewRelationships"]]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["SemanticViewTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#timeouts SemanticView#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["SemanticViewTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewDimensions",
    jsii_struct_bases=[],
    name_mapping={
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
        "comment": "comment",
        "synonym": "synonym",
    },
)
class SemanticViewDimensions:
    def __init__(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the dimension, including the table name and a unique identifier for the dimension: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the dimension. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the dimension. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for the dimension. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ab8f9a351a84da1a0ba56d0196bf4bde19dfac33dce0f01937ec403394669501)
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }
        if comment is not None:
            self._values["comment"] = comment
        if synonym is not None:
            self._values["synonym"] = synonym

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the dimension, including the table name and a unique identifier for the dimension: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the dimension.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the dimension.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for the dimension.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewDimensions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewDimensionsList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewDimensionsList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aeb6f424d59f82b5a6135a9c10652f4985f407e7abaaa74e01c549f291b83eda)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewDimensionsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb80041f0dfc58835c981b2fb72021ac3a4814ad431dfb7d6a30942b188a74a0)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewDimensionsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59b4abcb364fa92b72e433e256f684a91df3a54b4adfc36f92c7db139f3652a1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b4cd23478f95f252b9f3b6b02b1ddb8475fc7ca726f01f5ae2b496f4245245f5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b77c1fb52f9ba154faecf5a86b9f61120a59c1170f97a65b907918e30cc1bd36)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewDimensions]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewDimensions]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewDimensions]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a0aca4dfff18cb56258e7dec7f7b58dfc28426932544fe7c890fc04601233b8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewDimensionsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewDimensionsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2637f444790a360a11da32ce14b71cc6e8d6aec49e0570f362fcca006dbb8753)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bef3cc00f783d263fc3fd43e408ac57ed356e335f3bf2c9d5ca17eec342b6fa1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c0528f6851f4f28111a9ca0d81650d464339896049082452863bbdf4cb89beb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fad8e8ce61f907264a6200918887034384679bfb1ba35f4a67b4eaed58edc99f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5b89707c19ca1db4323c2584326d4781c89edab1e719707f68e422ec4e46c1d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewDimensions]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewDimensions]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewDimensions]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b1ccdbd50d57a582567d66f77b4496b6aef7a9ebf299cc81e985f7150d920b0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewFacts",
    jsii_struct_bases=[],
    name_mapping={
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
        "comment": "comment",
        "synonym": "synonym",
    },
)
class SemanticViewFacts:
    def __init__(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the fact, including the table name and a unique identifier for the fact: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the fact. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the fact. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for the fact. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b803f0ad3de3cef0513a6664c07ff53194e47345bdfeba42b228a5138eb34a80)
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }
        if comment is not None:
            self._values["comment"] = comment
        if synonym is not None:
            self._values["synonym"] = synonym

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the fact, including the table name and a unique identifier for the fact: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the fact.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the fact.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for the fact.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewFacts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewFactsList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewFactsList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b692184c213e16d88864c9f1304e468bc8ddf9b17f4e04e21dd165cfced61ff)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewFactsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f16b37cd4f07bfb74174f866800f97a089be6e28b9f8e71c28f63a2a894f672a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewFactsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9369b8e703355b621dfc088e6a98965b33abfac31e9b4032b56b465cec6f0f3f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__190ff445e194de132ea2e0c0a12d961a20da2c1221d0e23d1f9a071b00001114)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c47dd2c36b92b8b12915ae3e0a1f857d170900796f523d3c2c65ede3912c747)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewFacts]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewFacts]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewFacts]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc9bcc74974752d4d8e61f90f30f28f4884c96032dcb4e5123c3a18b22d7518a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewFactsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewFactsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73fd7a0287ef7b75f61cb73b3ffa917e1638181cd9185c8b839c60230c6ca877)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a37b7f013696cac5974d474577008bc347bd20256c44d06da15e38c798e22b1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c39466c7fee3f52acf5bcc33219792964593dd7cde6029ea0bd897776f17520)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9dfd7f54746bb19289534df475e894f76ae31e568f581aa2f42fef4acb5135b3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a273eac0d2a5b1f5a7eceed533e6576182f07bd9d6b4f227ba449cff5b61c59)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewFacts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewFacts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewFacts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2afcb9eb3797fb52307919aee680b1b0219f649f6e9b853052d00062c86d4b50)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetrics",
    jsii_struct_bases=[],
    name_mapping={
        "semantic_expression": "semanticExpression",
        "window_function": "windowFunction",
    },
)
class SemanticViewMetrics:
    def __init__(
        self,
        *,
        semantic_expression: typing.Optional[typing.Union["SemanticViewMetricsSemanticExpression", typing.Dict[builtins.str, typing.Any]]] = None,
        window_function: typing.Optional[typing.Union["SemanticViewMetricsWindowFunction", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param semantic_expression: semantic_expression block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#semantic_expression SemanticView#semantic_expression}
        :param window_function: window_function block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#window_function SemanticView#window_function}
        '''
        if isinstance(semantic_expression, dict):
            semantic_expression = SemanticViewMetricsSemanticExpression(**semantic_expression)
        if isinstance(window_function, dict):
            window_function = SemanticViewMetricsWindowFunction(**window_function)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a2a46b291f6baa1833b5873b2c65bd7df8eed1cefb237961b45c63d66173999)
            check_type(argname="argument semantic_expression", value=semantic_expression, expected_type=type_hints["semantic_expression"])
            check_type(argname="argument window_function", value=window_function, expected_type=type_hints["window_function"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if semantic_expression is not None:
            self._values["semantic_expression"] = semantic_expression
        if window_function is not None:
            self._values["window_function"] = window_function

    @builtins.property
    def semantic_expression(
        self,
    ) -> typing.Optional["SemanticViewMetricsSemanticExpression"]:
        '''semantic_expression block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#semantic_expression SemanticView#semantic_expression}
        '''
        result = self._values.get("semantic_expression")
        return typing.cast(typing.Optional["SemanticViewMetricsSemanticExpression"], result)

    @builtins.property
    def window_function(self) -> typing.Optional["SemanticViewMetricsWindowFunction"]:
        '''window_function block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#window_function SemanticView#window_function}
        '''
        result = self._values.get("window_function")
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunction"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetrics(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6cbd3cd771abd2263f7751d52d3071481a2a398361e0ba76b346ee56e5e9b15e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewMetricsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e74e869dd14ef7cf173a2611f190528069ebaf1589ae18acb5edc56482db7c5)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewMetricsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e48ccf13ee2fed701fdc7c817070c52d59680df9036d34d86e5f28707dd9bacb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92cc0f0b591f8ebaeeb94f66f0e04acea8b3afab5286eea45922d66fb77f521b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63bd9f4aa0f21b6b8ce9b935206baa467382e54fae52973ecef4d6301c9b1833)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewMetrics]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewMetrics]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewMetrics]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f26ef6f88046d05959c72679b95710348c00f3f1525e372d28faae052e9588ed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewMetricsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77e6a7a01aee9f67e4073c43e64557cb8e818548ec0c232cf6916132bf9cec57)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putSemanticExpression")
    def put_semantic_expression(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for this semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        value = SemanticViewMetricsSemanticExpression(
            qualified_expression_name=qualified_expression_name,
            sql_expression=sql_expression,
            comment=comment,
            synonym=synonym,
        )

        return typing.cast(None, jsii.invoke(self, "putSemanticExpression", [value]))

    @jsii.member(jsii_name="putWindowFunction")
    def put_window_function(
        self,
        *,
        over_clause: typing.Union["SemanticViewMetricsWindowFunctionOverClause", typing.Dict[builtins.str, typing.Any]],
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
    ) -> None:
        '''
        :param over_clause: over_clause block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#over_clause SemanticView#over_clause}
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric following the ``<window_function>(<metric>)`` format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        value = SemanticViewMetricsWindowFunction(
            over_clause=over_clause,
            qualified_expression_name=qualified_expression_name,
            sql_expression=sql_expression,
        )

        return typing.cast(None, jsii.invoke(self, "putWindowFunction", [value]))

    @jsii.member(jsii_name="resetSemanticExpression")
    def reset_semantic_expression(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSemanticExpression", []))

    @jsii.member(jsii_name="resetWindowFunction")
    def reset_window_function(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWindowFunction", []))

    @builtins.property
    @jsii.member(jsii_name="semanticExpression")
    def semantic_expression(
        self,
    ) -> "SemanticViewMetricsSemanticExpressionOutputReference":
        return typing.cast("SemanticViewMetricsSemanticExpressionOutputReference", jsii.get(self, "semanticExpression"))

    @builtins.property
    @jsii.member(jsii_name="windowFunction")
    def window_function(self) -> "SemanticViewMetricsWindowFunctionOutputReference":
        return typing.cast("SemanticViewMetricsWindowFunctionOutputReference", jsii.get(self, "windowFunction"))

    @builtins.property
    @jsii.member(jsii_name="semanticExpressionInput")
    def semantic_expression_input(
        self,
    ) -> typing.Optional["SemanticViewMetricsSemanticExpression"]:
        return typing.cast(typing.Optional["SemanticViewMetricsSemanticExpression"], jsii.get(self, "semanticExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="windowFunctionInput")
    def window_function_input(
        self,
    ) -> typing.Optional["SemanticViewMetricsWindowFunction"]:
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunction"], jsii.get(self, "windowFunctionInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewMetrics]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewMetrics]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewMetrics]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd10dbe2661d0a9f8fa62e16d1943a2cd59c4212d533b7a1a7a217f63d23818e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsSemanticExpression",
    jsii_struct_bases=[],
    name_mapping={
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
        "comment": "comment",
        "synonym": "synonym",
    },
)
class SemanticViewMetricsSemanticExpression:
    def __init__(
        self,
        *,
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        :param comment: Specifies a comment for the semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param synonym: List of synonyms for this semantic expression. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f3a75495cfc8bbeb19df131ae2827aa370d9fbb3d23c53c6bd448927eab4efc)
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }
        if comment is not None:
            self._values["comment"] = comment
        if synonym is not None:
            self._values["synonym"] = synonym

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the metric.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the semantic expression.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for this semantic expression.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetricsSemanticExpression(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsSemanticExpressionOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsSemanticExpressionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a170c817edb984e3deb49964fd28fc263255c90cfd5efb110968cdd8fd48e414)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5be7ad944bb1dc0ed8ae93cf2fb72a8b34133866433d0771d95689402448c839)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1000cd4b7060e11fd723053e7ae88d41640ef0229fa9ef931a606aa29915d275)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9b0bf0835071fea6978f782d06760fee3b685aef5d05cdb1311126554e18adf5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5134cda65e0858b6a849097949d54af9b0ea56a0bee8a848725fa3a99d93500d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[SemanticViewMetricsSemanticExpression]:
        return typing.cast(typing.Optional[SemanticViewMetricsSemanticExpression], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[SemanticViewMetricsSemanticExpression],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__818d921f1a0421c7f8de8f2d901a91bdd20c2c134f911f3bc370e3acc01183a4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsWindowFunction",
    jsii_struct_bases=[],
    name_mapping={
        "over_clause": "overClause",
        "qualified_expression_name": "qualifiedExpressionName",
        "sql_expression": "sqlExpression",
    },
)
class SemanticViewMetricsWindowFunction:
    def __init__(
        self,
        *,
        over_clause: typing.Union["SemanticViewMetricsWindowFunctionOverClause", typing.Dict[builtins.str, typing.Any]],
        qualified_expression_name: builtins.str,
        sql_expression: builtins.str,
    ) -> None:
        '''
        :param over_clause: over_clause block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#over_clause SemanticView#over_clause}
        :param qualified_expression_name: Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        :param sql_expression: The SQL expression used to compute the metric following the ``<window_function>(<metric>)`` format. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        if isinstance(over_clause, dict):
            over_clause = SemanticViewMetricsWindowFunctionOverClause(**over_clause)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bcf1ecbbcaa21ff8fe24be8353cdf55679feb780b4ac9ec9ca23ea3037de796)
            check_type(argname="argument over_clause", value=over_clause, expected_type=type_hints["over_clause"])
            check_type(argname="argument qualified_expression_name", value=qualified_expression_name, expected_type=type_hints["qualified_expression_name"])
            check_type(argname="argument sql_expression", value=sql_expression, expected_type=type_hints["sql_expression"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "over_clause": over_clause,
            "qualified_expression_name": qualified_expression_name,
            "sql_expression": sql_expression,
        }

    @builtins.property
    def over_clause(self) -> "SemanticViewMetricsWindowFunctionOverClause":
        '''over_clause block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#over_clause SemanticView#over_clause}
        '''
        result = self._values.get("over_clause")
        assert result is not None, "Required property 'over_clause' is missing"
        return typing.cast("SemanticViewMetricsWindowFunctionOverClause", result)

    @builtins.property
    def qualified_expression_name(self) -> builtins.str:
        '''Specifies a qualified name for the metric: ``<table_alias>.<semantic_expression_name>``. Remember to wrap each part in double quotes like ``"\\"<table_alias>\\".\\"<semantic_expression_name>\\""``. For the `derived metric <https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics>`_ omit the ``<table_alias>.`` part but still wrap in double quotes, e.g. ``"\\"<semantic_expression_name>\\""``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
        '''
        result = self._values.get("qualified_expression_name")
        assert result is not None, "Required property 'qualified_expression_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sql_expression(self) -> builtins.str:
        '''The SQL expression used to compute the metric following the ``<window_function>(<metric>)`` format.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
        '''
        result = self._values.get("sql_expression")
        assert result is not None, "Required property 'sql_expression' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetricsWindowFunction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsWindowFunctionOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsWindowFunctionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d44cf21347f366ff74b866c145ab2969f291cfa01b5049ce087398a42ba08ecd)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putOverClause")
    def put_over_clause(
        self,
        *,
        order_by: typing.Optional[builtins.str] = None,
        partition_by: typing.Optional[builtins.str] = None,
        window_frame_clause: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param order_by: Specifies an order by clause. It must be a complete SQL expression, including any ``[ ASC | DESC ] [ NULLS { FIRST | LAST } ]`` modifiers. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#order_by SemanticView#order_by}
        :param partition_by: Specifies a partition by clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#partition_by SemanticView#partition_by}
        :param window_frame_clause: Specifies a window frame clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#window_frame_clause SemanticView#window_frame_clause}
        '''
        value = SemanticViewMetricsWindowFunctionOverClause(
            order_by=order_by,
            partition_by=partition_by,
            window_frame_clause=window_frame_clause,
        )

        return typing.cast(None, jsii.invoke(self, "putOverClause", [value]))

    @builtins.property
    @jsii.member(jsii_name="overClause")
    def over_clause(
        self,
    ) -> "SemanticViewMetricsWindowFunctionOverClauseOutputReference":
        return typing.cast("SemanticViewMetricsWindowFunctionOverClauseOutputReference", jsii.get(self, "overClause"))

    @builtins.property
    @jsii.member(jsii_name="overClauseInput")
    def over_clause_input(
        self,
    ) -> typing.Optional["SemanticViewMetricsWindowFunctionOverClause"]:
        return typing.cast(typing.Optional["SemanticViewMetricsWindowFunctionOverClause"], jsii.get(self, "overClauseInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionNameInput")
    def qualified_expression_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "qualifiedExpressionNameInput"))

    @builtins.property
    @jsii.member(jsii_name="sqlExpressionInput")
    def sql_expression_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sqlExpressionInput"))

    @builtins.property
    @jsii.member(jsii_name="qualifiedExpressionName")
    def qualified_expression_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "qualifiedExpressionName"))

    @qualified_expression_name.setter
    def qualified_expression_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2efb41d787394dac9a783cb71c791085d30c93fb8b041299699643f5d17d4a08)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "qualifiedExpressionName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sqlExpression")
    def sql_expression(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sqlExpression"))

    @sql_expression.setter
    def sql_expression(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75bf3d4b48f2309be926f98f50f1bb215ffde316635435b4f428683f794baac1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sqlExpression", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[SemanticViewMetricsWindowFunction]:
        return typing.cast(typing.Optional[SemanticViewMetricsWindowFunction], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[SemanticViewMetricsWindowFunction],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ea0487a8e33b3c5331d0150d19d5508805880238f6c959de5e499e96b567245)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsWindowFunctionOverClause",
    jsii_struct_bases=[],
    name_mapping={
        "order_by": "orderBy",
        "partition_by": "partitionBy",
        "window_frame_clause": "windowFrameClause",
    },
)
class SemanticViewMetricsWindowFunctionOverClause:
    def __init__(
        self,
        *,
        order_by: typing.Optional[builtins.str] = None,
        partition_by: typing.Optional[builtins.str] = None,
        window_frame_clause: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param order_by: Specifies an order by clause. It must be a complete SQL expression, including any ``[ ASC | DESC ] [ NULLS { FIRST | LAST } ]`` modifiers. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#order_by SemanticView#order_by}
        :param partition_by: Specifies a partition by clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#partition_by SemanticView#partition_by}
        :param window_frame_clause: Specifies a window frame clause. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#window_frame_clause SemanticView#window_frame_clause}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e10a996fccced210bc43d357870cb040df19d2f850ad3d731c9abb9a9245f24)
            check_type(argname="argument order_by", value=order_by, expected_type=type_hints["order_by"])
            check_type(argname="argument partition_by", value=partition_by, expected_type=type_hints["partition_by"])
            check_type(argname="argument window_frame_clause", value=window_frame_clause, expected_type=type_hints["window_frame_clause"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if order_by is not None:
            self._values["order_by"] = order_by
        if partition_by is not None:
            self._values["partition_by"] = partition_by
        if window_frame_clause is not None:
            self._values["window_frame_clause"] = window_frame_clause

    @builtins.property
    def order_by(self) -> typing.Optional[builtins.str]:
        '''Specifies an order by clause.

        It must be a complete SQL expression, including any ``[ ASC | DESC ] [ NULLS { FIRST | LAST } ]`` modifiers.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#order_by SemanticView#order_by}
        '''
        result = self._values.get("order_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def partition_by(self) -> typing.Optional[builtins.str]:
        '''Specifies a partition by clause.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#partition_by SemanticView#partition_by}
        '''
        result = self._values.get("partition_by")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def window_frame_clause(self) -> typing.Optional[builtins.str]:
        '''Specifies a window frame clause.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#window_frame_clause SemanticView#window_frame_clause}
        '''
        result = self._values.get("window_frame_clause")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewMetricsWindowFunctionOverClause(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewMetricsWindowFunctionOverClauseOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewMetricsWindowFunctionOverClauseOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2aab0e423ba3d041f5a60012a10fdc2691fe3c51bf7479b4c0bff4b875979340)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetOrderBy")
    def reset_order_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOrderBy", []))

    @jsii.member(jsii_name="resetPartitionBy")
    def reset_partition_by(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPartitionBy", []))

    @jsii.member(jsii_name="resetWindowFrameClause")
    def reset_window_frame_clause(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWindowFrameClause", []))

    @builtins.property
    @jsii.member(jsii_name="orderByInput")
    def order_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "orderByInput"))

    @builtins.property
    @jsii.member(jsii_name="partitionByInput")
    def partition_by_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "partitionByInput"))

    @builtins.property
    @jsii.member(jsii_name="windowFrameClauseInput")
    def window_frame_clause_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "windowFrameClauseInput"))

    @builtins.property
    @jsii.member(jsii_name="orderBy")
    def order_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "orderBy"))

    @order_by.setter
    def order_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__efaf5b9c940e8c1adc7fe87086e3802a1153ee6c02406b923e69ceee9c1954ea)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "orderBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="partitionBy")
    def partition_by(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "partitionBy"))

    @partition_by.setter
    def partition_by(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eda5c26646d9bd4e2a3908dc462b2b7e851d480201a247dc3f7625f9e83ec040)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "partitionBy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="windowFrameClause")
    def window_frame_clause(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "windowFrameClause"))

    @window_frame_clause.setter
    def window_frame_clause(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e47490dc0566db766742488b1f17b589c648c1de24f085c8528bc9122f550e6c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "windowFrameClause", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[SemanticViewMetricsWindowFunctionOverClause]:
        return typing.cast(typing.Optional[SemanticViewMetricsWindowFunctionOverClause], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[SemanticViewMetricsWindowFunctionOverClause],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6e6cb8a2ac684bddde095e5a817bdb530234df55ef92f660190f533698bf934)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewRelationships",
    jsii_struct_bases=[],
    name_mapping={
        "referenced_table_name_or_alias": "referencedTableNameOrAlias",
        "relationship_columns": "relationshipColumns",
        "table_name_or_alias": "tableNameOrAlias",
        "referenced_relationship_columns": "referencedRelationshipColumns",
        "relationship_identifier": "relationshipIdentifier",
    },
)
class SemanticViewRelationships:
    def __init__(
        self,
        *,
        referenced_table_name_or_alias: typing.Union["SemanticViewRelationshipsReferencedTableNameOrAlias", typing.Dict[builtins.str, typing.Any]],
        relationship_columns: typing.Sequence[builtins.str],
        table_name_or_alias: typing.Union["SemanticViewRelationshipsTableNameOrAlias", typing.Dict[builtins.str, typing.Any]],
        referenced_relationship_columns: typing.Optional[typing.Sequence[builtins.str]] = None,
        relationship_identifier: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param referenced_table_name_or_alias: referenced_table_name_or_alias block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#referenced_table_name_or_alias SemanticView#referenced_table_name_or_alias}
        :param relationship_columns: Specifies one or more columns in the first logical table that refers to columns in another logical table. Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#relationship_columns SemanticView#relationship_columns}
        :param table_name_or_alias: table_name_or_alias block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name_or_alias SemanticView#table_name_or_alias}
        :param referenced_relationship_columns: Specifies one or more columns in the second logical table that are referred to by the first logical table. Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#referenced_relationship_columns SemanticView#referenced_relationship_columns}
        :param relationship_identifier: Specifies an optional identifier for the relationship. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#relationship_identifier SemanticView#relationship_identifier}
        '''
        if isinstance(referenced_table_name_or_alias, dict):
            referenced_table_name_or_alias = SemanticViewRelationshipsReferencedTableNameOrAlias(**referenced_table_name_or_alias)
        if isinstance(table_name_or_alias, dict):
            table_name_or_alias = SemanticViewRelationshipsTableNameOrAlias(**table_name_or_alias)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b665e6ccc053f55e0310833efbd5f256a9712ba53d141316bca9c05f0e8ccc76)
            check_type(argname="argument referenced_table_name_or_alias", value=referenced_table_name_or_alias, expected_type=type_hints["referenced_table_name_or_alias"])
            check_type(argname="argument relationship_columns", value=relationship_columns, expected_type=type_hints["relationship_columns"])
            check_type(argname="argument table_name_or_alias", value=table_name_or_alias, expected_type=type_hints["table_name_or_alias"])
            check_type(argname="argument referenced_relationship_columns", value=referenced_relationship_columns, expected_type=type_hints["referenced_relationship_columns"])
            check_type(argname="argument relationship_identifier", value=relationship_identifier, expected_type=type_hints["relationship_identifier"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "referenced_table_name_or_alias": referenced_table_name_or_alias,
            "relationship_columns": relationship_columns,
            "table_name_or_alias": table_name_or_alias,
        }
        if referenced_relationship_columns is not None:
            self._values["referenced_relationship_columns"] = referenced_relationship_columns
        if relationship_identifier is not None:
            self._values["relationship_identifier"] = relationship_identifier

    @builtins.property
    def referenced_table_name_or_alias(
        self,
    ) -> "SemanticViewRelationshipsReferencedTableNameOrAlias":
        '''referenced_table_name_or_alias block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#referenced_table_name_or_alias SemanticView#referenced_table_name_or_alias}
        '''
        result = self._values.get("referenced_table_name_or_alias")
        assert result is not None, "Required property 'referenced_table_name_or_alias' is missing"
        return typing.cast("SemanticViewRelationshipsReferencedTableNameOrAlias", result)

    @builtins.property
    def relationship_columns(self) -> typing.List[builtins.str]:
        '''Specifies one or more columns in the first logical table that refers to columns in another logical table.

        Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#relationship_columns SemanticView#relationship_columns}
        '''
        result = self._values.get("relationship_columns")
        assert result is not None, "Required property 'relationship_columns' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def table_name_or_alias(self) -> "SemanticViewRelationshipsTableNameOrAlias":
        '''table_name_or_alias block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name_or_alias SemanticView#table_name_or_alias}
        '''
        result = self._values.get("table_name_or_alias")
        assert result is not None, "Required property 'table_name_or_alias' is missing"
        return typing.cast("SemanticViewRelationshipsTableNameOrAlias", result)

    @builtins.property
    def referenced_relationship_columns(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''Specifies one or more columns in the second logical table that are referred to by the first logical table.

        Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#referenced_relationship_columns SemanticView#referenced_relationship_columns}
        '''
        result = self._values.get("referenced_relationship_columns")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def relationship_identifier(self) -> typing.Optional[builtins.str]:
        '''Specifies an optional identifier for the relationship.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#relationship_identifier SemanticView#relationship_identifier}
        '''
        result = self._values.get("relationship_identifier")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewRelationships(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewRelationshipsList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewRelationshipsList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c6d07720e5f79c18fa0575f30a5c54838c990a8206a4558085c6bf9959be3fb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewRelationshipsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3fbc5a5c4e4ddead6f00a5a66b0eeb4da6d2e14294b9acedbac817635834f7b)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewRelationshipsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a757dcbaf22eb9f67497ce18a4022988348c3e5d0b98118212b00ad902ad2a6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__226d9dbc76eac645a6ad3818f50d57637a8d2da0eeabc7e048b30ee6ce10d73a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57cd0d354538d1fbb097bfe6152c96857367de8e05bb8659c1fe5b8b0b2af427)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewRelationships]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewRelationships]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewRelationships]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd63a31b6be445a3348ffa82e36b02fa3322c501bbe85c54c7a6055dc1aaeaa5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewRelationshipsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewRelationshipsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__318d82eccc28516114cad870bd897f32614af1050ff9d54c9c10281f74fd4492)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putReferencedTableNameOrAlias")
    def put_referenced_table_name_or_alias(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        value = SemanticViewRelationshipsReferencedTableNameOrAlias(
            table_alias=table_alias, table_name=table_name
        )

        return typing.cast(None, jsii.invoke(self, "putReferencedTableNameOrAlias", [value]))

    @jsii.member(jsii_name="putTableNameOrAlias")
    def put_table_name_or_alias(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        value = SemanticViewRelationshipsTableNameOrAlias(
            table_alias=table_alias, table_name=table_name
        )

        return typing.cast(None, jsii.invoke(self, "putTableNameOrAlias", [value]))

    @jsii.member(jsii_name="resetReferencedRelationshipColumns")
    def reset_referenced_relationship_columns(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReferencedRelationshipColumns", []))

    @jsii.member(jsii_name="resetRelationshipIdentifier")
    def reset_relationship_identifier(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRelationshipIdentifier", []))

    @builtins.property
    @jsii.member(jsii_name="referencedTableNameOrAlias")
    def referenced_table_name_or_alias(
        self,
    ) -> "SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference":
        return typing.cast("SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference", jsii.get(self, "referencedTableNameOrAlias"))

    @builtins.property
    @jsii.member(jsii_name="tableNameOrAlias")
    def table_name_or_alias(
        self,
    ) -> "SemanticViewRelationshipsTableNameOrAliasOutputReference":
        return typing.cast("SemanticViewRelationshipsTableNameOrAliasOutputReference", jsii.get(self, "tableNameOrAlias"))

    @builtins.property
    @jsii.member(jsii_name="referencedRelationshipColumnsInput")
    def referenced_relationship_columns_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "referencedRelationshipColumnsInput"))

    @builtins.property
    @jsii.member(jsii_name="referencedTableNameOrAliasInput")
    def referenced_table_name_or_alias_input(
        self,
    ) -> typing.Optional["SemanticViewRelationshipsReferencedTableNameOrAlias"]:
        return typing.cast(typing.Optional["SemanticViewRelationshipsReferencedTableNameOrAlias"], jsii.get(self, "referencedTableNameOrAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="relationshipColumnsInput")
    def relationship_columns_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "relationshipColumnsInput"))

    @builtins.property
    @jsii.member(jsii_name="relationshipIdentifierInput")
    def relationship_identifier_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "relationshipIdentifierInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameOrAliasInput")
    def table_name_or_alias_input(
        self,
    ) -> typing.Optional["SemanticViewRelationshipsTableNameOrAlias"]:
        return typing.cast(typing.Optional["SemanticViewRelationshipsTableNameOrAlias"], jsii.get(self, "tableNameOrAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="referencedRelationshipColumns")
    def referenced_relationship_columns(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "referencedRelationshipColumns"))

    @referenced_relationship_columns.setter
    def referenced_relationship_columns(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c47feda907fd4c61ac76ccb6b56ddb5d2eae799c4e5d14348d7d7e92b1dd190b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "referencedRelationshipColumns", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="relationshipColumns")
    def relationship_columns(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "relationshipColumns"))

    @relationship_columns.setter
    def relationship_columns(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9c97af98b125a9b96e700510ae634a5b325d07ef9c608b6364b37c6a076f6b1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "relationshipColumns", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="relationshipIdentifier")
    def relationship_identifier(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "relationshipIdentifier"))

    @relationship_identifier.setter
    def relationship_identifier(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aec3fea13a0ccb48cbe1e5ccdb2740c99b15b5ebc2fc60401926b7b49827b81c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "relationshipIdentifier", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewRelationships]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewRelationships]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewRelationships]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b53a9feb49e4a2c15739fcceea98f34f8b2411d7dc2664d8022f3735306a982)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewRelationshipsReferencedTableNameOrAlias",
    jsii_struct_bases=[],
    name_mapping={"table_alias": "tableAlias", "table_name": "tableName"},
)
class SemanticViewRelationshipsReferencedTableNameOrAlias:
    def __init__(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4521f4b6dfcc2e34b3b8dae80a5fcf29a5d20a2b14a0d6058f3a1aafb1751515)
            check_type(argname="argument table_alias", value=table_alias, expected_type=type_hints["table_alias"])
            check_type(argname="argument table_name", value=table_name, expected_type=type_hints["table_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if table_alias is not None:
            self._values["table_alias"] = table_alias
        if table_name is not None:
            self._values["table_name"] = table_name

    @builtins.property
    def table_alias(self) -> typing.Optional[builtins.str]:
        '''The alias used for the logical table, cannot be used in combination with the ``table_name``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        '''
        result = self._values.get("table_alias")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def table_name(self) -> typing.Optional[builtins.str]:
        '''The name of the logical table, cannot be used in combination with the ``table_alias``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        result = self._values.get("table_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewRelationshipsReferencedTableNameOrAlias(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5bc005ed798777ff66ee377c5eff4d1bce074e3ad6ee55dffcd41d914f94474)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetTableAlias")
    def reset_table_alias(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableAlias", []))

    @jsii.member(jsii_name="resetTableName")
    def reset_table_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableName", []))

    @builtins.property
    @jsii.member(jsii_name="tableAliasInput")
    def table_alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameInput")
    def table_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableNameInput"))

    @builtins.property
    @jsii.member(jsii_name="tableAlias")
    def table_alias(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableAlias"))

    @table_alias.setter
    def table_alias(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ae3ed441760843a123444482ea2cab24d059cf17775e333cf823a532b5863b5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableAlias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableName")
    def table_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableName"))

    @table_name.setter
    def table_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec2ba727f598c2bbc2b6baf1cf4df812f01837fd4e99cb080c2ceebc28ed7e18)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[SemanticViewRelationshipsReferencedTableNameOrAlias]:
        return typing.cast(typing.Optional[SemanticViewRelationshipsReferencedTableNameOrAlias], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[SemanticViewRelationshipsReferencedTableNameOrAlias],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05bfac43a27d38b092167562d12fe47e4c361f3e2e68ed3f8a426766d211c02f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewRelationshipsTableNameOrAlias",
    jsii_struct_bases=[],
    name_mapping={"table_alias": "tableAlias", "table_name": "tableName"},
)
class SemanticViewRelationshipsTableNameOrAlias:
    def __init__(
        self,
        *,
        table_alias: typing.Optional[builtins.str] = None,
        table_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param table_alias: The alias used for the logical table, cannot be used in combination with the ``table_name``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: The name of the logical table, cannot be used in combination with the ``table_alias``. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__74024f10db9816592c15c3c437a8a18e30592305fe8a670d8cd1bc32e03ec241)
            check_type(argname="argument table_alias", value=table_alias, expected_type=type_hints["table_alias"])
            check_type(argname="argument table_name", value=table_name, expected_type=type_hints["table_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if table_alias is not None:
            self._values["table_alias"] = table_alias
        if table_name is not None:
            self._values["table_name"] = table_name

    @builtins.property
    def table_alias(self) -> typing.Optional[builtins.str]:
        '''The alias used for the logical table, cannot be used in combination with the ``table_name``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        '''
        result = self._values.get("table_alias")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def table_name(self) -> typing.Optional[builtins.str]:
        '''The name of the logical table, cannot be used in combination with the ``table_alias``.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        result = self._values.get("table_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewRelationshipsTableNameOrAlias(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewRelationshipsTableNameOrAliasOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewRelationshipsTableNameOrAliasOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e101c1d4ce0dda4c8d2644bee22003f127e37da836c5f5d7e59ac8634ca8024)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetTableAlias")
    def reset_table_alias(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableAlias", []))

    @jsii.member(jsii_name="resetTableName")
    def reset_table_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTableName", []))

    @builtins.property
    @jsii.member(jsii_name="tableAliasInput")
    def table_alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameInput")
    def table_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableNameInput"))

    @builtins.property
    @jsii.member(jsii_name="tableAlias")
    def table_alias(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableAlias"))

    @table_alias.setter
    def table_alias(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1910cae7c988a81e6954ea8ed79bd659828041659f10f6d694d4958b2b234de2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableAlias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableName")
    def table_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableName"))

    @table_name.setter
    def table_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80125e8817d15411970762cac1470da4910a9e0d102427f41178c464154b6f88)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[SemanticViewRelationshipsTableNameOrAlias]:
        return typing.cast(typing.Optional[SemanticViewRelationshipsTableNameOrAlias], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[SemanticViewRelationshipsTableNameOrAlias],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__563637021bc1440e53508e08248f4a16cd77a2adb2acad5376190d9729df933e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewShowOutput",
    jsii_struct_bases=[],
    name_mapping={},
)
class SemanticViewShowOutput:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewShowOutput(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewShowOutputList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewShowOutputList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a23cd8907495abb0e8458d541e28e34c31f7cd39c7e4bed6309fb61e46b341f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewShowOutputOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c7bc50dd4ece5017d31522563caba682be55ecf7bae8c40a69e45fe8ddfe978)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewShowOutputOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35a350a98fd6b4200f01f43fec62291f6c9430d8b191d6c1b7fca6f259a07d48)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76d6e28aa4f81ca3be0afe10b87479b5b55c0c0ca1623c2ea4c1a80aadf2f8dc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9633a1b12fbaee2897a455eff670711217275eca3dd6c289c8da2176e7d9597b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class SemanticViewShowOutputOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewShowOutputOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca8872016c36d2491c0a275164b1a43f718ccbd769c6b7900dcc953b9d22a099)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @builtins.property
    @jsii.member(jsii_name="createdOn")
    def created_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "createdOn"))

    @builtins.property
    @jsii.member(jsii_name="databaseName")
    def database_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "databaseName"))

    @builtins.property
    @jsii.member(jsii_name="extension")
    def extension(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "extension"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @builtins.property
    @jsii.member(jsii_name="owner")
    def owner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "owner"))

    @builtins.property
    @jsii.member(jsii_name="ownerRoleType")
    def owner_role_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ownerRoleType"))

    @builtins.property
    @jsii.member(jsii_name="schemaName")
    def schema_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "schemaName"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[SemanticViewShowOutput]:
        return typing.cast(typing.Optional[SemanticViewShowOutput], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[SemanticViewShowOutput]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3bfe09eb235c71b870720bb199ccd6266fa8a3f93c1df5467f9946a1661de535)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTables",
    jsii_struct_bases=[],
    name_mapping={
        "table_alias": "tableAlias",
        "table_name": "tableName",
        "comment": "comment",
        "primary_key": "primaryKey",
        "synonym": "synonym",
        "unique": "unique",
    },
)
class SemanticViewTables:
    def __init__(
        self,
        *,
        table_alias: builtins.str,
        table_name: builtins.str,
        comment: typing.Optional[builtins.str] = None,
        primary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
        synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
        unique: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewTablesUnique", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param table_alias: Specifies an alias for a logical table in the semantic view. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        :param table_name: Specifies an identifier for the logical table. Example: ``"\\"<db_name>\\".\\"<schema_name>\\".\\"<table_name>\\""``. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        :param comment: Specifies a comment for the logical table. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        :param primary_key: Definitions of primary keys in the logical table. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#primary_key SemanticView#primary_key}
        :param synonym: List of synonyms for the logical table. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        :param unique: unique block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#unique SemanticView#unique}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f4a6dcc2c5a4c05826d8873a3c0ef518a353d45a5c586dc26b6a9d4ee545489)
            check_type(argname="argument table_alias", value=table_alias, expected_type=type_hints["table_alias"])
            check_type(argname="argument table_name", value=table_name, expected_type=type_hints["table_name"])
            check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
            check_type(argname="argument primary_key", value=primary_key, expected_type=type_hints["primary_key"])
            check_type(argname="argument synonym", value=synonym, expected_type=type_hints["synonym"])
            check_type(argname="argument unique", value=unique, expected_type=type_hints["unique"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "table_alias": table_alias,
            "table_name": table_name,
        }
        if comment is not None:
            self._values["comment"] = comment
        if primary_key is not None:
            self._values["primary_key"] = primary_key
        if synonym is not None:
            self._values["synonym"] = synonym
        if unique is not None:
            self._values["unique"] = unique

    @builtins.property
    def table_alias(self) -> builtins.str:
        '''Specifies an alias for a logical table in the semantic view.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
        '''
        result = self._values.get("table_alias")
        assert result is not None, "Required property 'table_alias' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def table_name(self) -> builtins.str:
        '''Specifies an identifier for the logical table.

        Example: ``"\\"<db_name>\\".\\"<schema_name>\\".\\"<table_name>\\""``. Due to technical limitations (read more `here <../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations>`_), avoid using the following characters: ``|``, ``.``, ``"``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#table_name SemanticView#table_name}
        '''
        result = self._values.get("table_name")
        assert result is not None, "Required property 'table_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def comment(self) -> typing.Optional[builtins.str]:
        '''Specifies a comment for the logical table.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#comment SemanticView#comment}
        '''
        result = self._values.get("comment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def primary_key(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Definitions of primary keys in the logical table.

        This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#primary_key SemanticView#primary_key}
        '''
        result = self._values.get("primary_key")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def synonym(self) -> typing.Optional[typing.List[builtins.str]]:
        '''List of synonyms for the logical table.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#synonym SemanticView#synonym}
        '''
        result = self._values.get("synonym")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def unique(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTablesUnique"]]]:
        '''unique block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#unique SemanticView#unique}
        '''
        result = self._values.get("unique")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTablesUnique"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewTables(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewTablesList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTablesList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d20145025272f4a78ccb72447df46222db3355a3cf1f2df27f03e56c35a171a9)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewTablesOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__daa06502deacc2520b220e4475b82ddb31805ba66a260d328a57cda9a03e0d60)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewTablesOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8bc36869c2756e5bec8711e02e5b5939ba76365cd0d88dc32d979be321797b75)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a0358dfb18798de2ba47ddcd868789bf42a089a87001afeef59868479aa848ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cd1d85b529de43b942cb7145a6a21c259141f5e78a12faa5a1e83ba3248e7c9f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTables]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTables]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTables]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e0dc07ff0433094021b4eb02028886618f701f6cb6d65ebcc4957590d3a9a7cf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewTablesOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTablesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__983ef3bcf32b5f5c3e78c392d3ca212ce538e0e9b193d4efe1fba5b7e6d4d52b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putUnique")
    def put_unique(
        self,
        value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union["SemanticViewTablesUnique", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77948af9f099ebda5c3584fd2680d294fd001eb2a1c4c9ed0e73e4b1f710456b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putUnique", [value]))

    @jsii.member(jsii_name="resetComment")
    def reset_comment(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetComment", []))

    @jsii.member(jsii_name="resetPrimaryKey")
    def reset_primary_key(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrimaryKey", []))

    @jsii.member(jsii_name="resetSynonym")
    def reset_synonym(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSynonym", []))

    @jsii.member(jsii_name="resetUnique")
    def reset_unique(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUnique", []))

    @builtins.property
    @jsii.member(jsii_name="unique")
    def unique(self) -> "SemanticViewTablesUniqueList":
        return typing.cast("SemanticViewTablesUniqueList", jsii.get(self, "unique"))

    @builtins.property
    @jsii.member(jsii_name="commentInput")
    def comment_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "commentInput"))

    @builtins.property
    @jsii.member(jsii_name="primaryKeyInput")
    def primary_key_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "primaryKeyInput"))

    @builtins.property
    @jsii.member(jsii_name="synonymInput")
    def synonym_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "synonymInput"))

    @builtins.property
    @jsii.member(jsii_name="tableAliasInput")
    def table_alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableAliasInput"))

    @builtins.property
    @jsii.member(jsii_name="tableNameInput")
    def table_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tableNameInput"))

    @builtins.property
    @jsii.member(jsii_name="uniqueInput")
    def unique_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTablesUnique"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List["SemanticViewTablesUnique"]]], jsii.get(self, "uniqueInput"))

    @builtins.property
    @jsii.member(jsii_name="comment")
    def comment(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "comment"))

    @comment.setter
    def comment(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ba1ecc0934f6ba99adb332ca40d6041a3cf8de9e208cf5e3ff42bd3b1f09ca4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "comment", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="primaryKey")
    def primary_key(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "primaryKey"))

    @primary_key.setter
    def primary_key(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ea63fb91553665769c1b8c332ecfd244c471b4e89da8151dab1e3cd486b757d1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "primaryKey", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="synonym")
    def synonym(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "synonym"))

    @synonym.setter
    def synonym(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aed83f5a29d7498df3934007cf4b1333ed0e7d8ed22d62c229d2318f4b8aff03)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "synonym", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableAlias")
    def table_alias(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableAlias"))

    @table_alias.setter
    def table_alias(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4588a4e4efd73095200b00c6418d80ef0c1108d9c646beb0314c533465ac4a9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableAlias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tableName")
    def table_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tableName"))

    @table_name.setter
    def table_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b235e61a22a06a3d11c9f3c1f45e434e73147803ac4dea661075d5eefe4bbb75)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tableName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTables]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTables]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTables]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f3dd0043aff71b38d71bdf0ef9a312341a168fb47f343d585ca996006dd1f58)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTablesUnique",
    jsii_struct_bases=[],
    name_mapping={"values": "values"},
)
class SemanticViewTablesUnique:
    def __init__(self, *, values: typing.Sequence[builtins.str]) -> None:
        '''
        :param values: Unique key combinations in the logical table. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#values SemanticView#values}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff6a2bd0b62c69494d98d1871ea0961e15c96fbbe1cab87c4e86502d9ea62097)
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "values": values,
        }

    @builtins.property
    def values(self) -> typing.List[builtins.str]:
        '''Unique key combinations in the logical table.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#values SemanticView#values}
        '''
        result = self._values.get("values")
        assert result is not None, "Required property 'values' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewTablesUnique(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewTablesUniqueList(
    _cdktf_9a9027ec.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTablesUniqueList",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38a5040331c14107f51f4cdc21d997106d2657b0254b732eb84f011d4da68886)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "SemanticViewTablesUniqueOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6d360b7f7aea4de42562ab3017e431430478907aa70234a104963e2577f673d9)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("SemanticViewTablesUniqueOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2648428f671355f82b3c0e0ab9f0a5782917f6302ba75c2f500dd4f8f7d24745)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktf_9a9027ec.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktf_9a9027ec.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktf_9a9027ec.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8cc430bed498d6a0e7da84efa7eceb2cb899fcfb55a40c1755d693c44a3e354e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9816fa80931da11b15bc4f6806846e1b3a581e08fc5de3529c2d6a254e8a63f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTablesUnique]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTablesUnique]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTablesUnique]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9745c577a8774aef93c0cb079d5c8083b289cd2a8da0d56cb8b94f8ba779bc91)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class SemanticViewTablesUniqueOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTablesUniqueOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__242b0ba554802d94eab3e4c2f152aa8a9a1d26e8bed1860b7daefe7bef9c299a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="valuesInput")
    def values_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "valuesInput"))

    @builtins.property
    @jsii.member(jsii_name="values")
    def values(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "values"))

    @values.setter
    def values(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a84575df5d4adca8c361191a51253079c7c061991397835ea71dd62d1772277)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "values", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTablesUnique]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTablesUnique]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTablesUnique]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec9aabcba70e13d9739ef9310e5c4b24889fd6939e913382804f8994163bd4d3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class SemanticViewTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#create SemanticView#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#delete SemanticView#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#read SemanticView#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#update SemanticView#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c9298082b540c96e71a4d3498c25c03776d619fef64b8c8cee47be871b5637a8)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#create SemanticView#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#delete SemanticView#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#read SemanticView#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.11.0/docs/resources/semantic_view#update SemanticView#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SemanticViewTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class SemanticViewTimeoutsOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-snowflake.semanticView.SemanticViewTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__403182edecece2b78cd0c37f2f2cb72dc03ca1881640ae93d453e59c38276e55)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__392a843773a36a95ca2b3e74a2368b86ec36bb25ca9328edc7b5231b25dcdaa5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__953aca89f7887d3d38e9726db426db662cd2961fe3a08d8debebfde03a15a1ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__58543a3e8751ab6d04997b072276a37e86c627eb523c728558db0e88e7204023)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9ff24123c002e6e36f228432e1c6b1de47b62dd07b591efee8af1fb2737ede8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__606f2a45091c0c8a0437d2844167d5bbd83ded8604db9e0a1c8e2efbb21dd502)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "SemanticView",
    "SemanticViewConfig",
    "SemanticViewDimensions",
    "SemanticViewDimensionsList",
    "SemanticViewDimensionsOutputReference",
    "SemanticViewFacts",
    "SemanticViewFactsList",
    "SemanticViewFactsOutputReference",
    "SemanticViewMetrics",
    "SemanticViewMetricsList",
    "SemanticViewMetricsOutputReference",
    "SemanticViewMetricsSemanticExpression",
    "SemanticViewMetricsSemanticExpressionOutputReference",
    "SemanticViewMetricsWindowFunction",
    "SemanticViewMetricsWindowFunctionOutputReference",
    "SemanticViewMetricsWindowFunctionOverClause",
    "SemanticViewMetricsWindowFunctionOverClauseOutputReference",
    "SemanticViewRelationships",
    "SemanticViewRelationshipsList",
    "SemanticViewRelationshipsOutputReference",
    "SemanticViewRelationshipsReferencedTableNameOrAlias",
    "SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference",
    "SemanticViewRelationshipsTableNameOrAlias",
    "SemanticViewRelationshipsTableNameOrAliasOutputReference",
    "SemanticViewShowOutput",
    "SemanticViewShowOutputList",
    "SemanticViewShowOutputOutputReference",
    "SemanticViewTables",
    "SemanticViewTablesList",
    "SemanticViewTablesOutputReference",
    "SemanticViewTablesUnique",
    "SemanticViewTablesUniqueList",
    "SemanticViewTablesUniqueOutputReference",
    "SemanticViewTimeouts",
    "SemanticViewTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__6abd42e19075da522116ed6d33c19bc9f52db60d14f937eac2eaccda8676781c(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    tables: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewTables, typing.Dict[builtins.str, typing.Any]]]],
    comment: typing.Optional[builtins.str] = None,
    dimensions: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewDimensions, typing.Dict[builtins.str, typing.Any]]]]] = None,
    facts: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewFacts, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    metrics: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewMetrics, typing.Dict[builtins.str, typing.Any]]]]] = None,
    relationships: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewRelationships, typing.Dict[builtins.str, typing.Any]]]]] = None,
    timeouts: typing.Optional[typing.Union[SemanticViewTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__16a3c43ed79aea5ed9056ca374b7a9263c13c7cac91f707312839cb7d9194e8b(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edf8219010d960572d4fc647baac52805111e91f807f80e3d05720907c3cc072(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewDimensions, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b8ab730b95b9620f6ae95bc2cb83ab4ed9ae409ad60ddfe193b2bed462fb44e0(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewFacts, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41fb5b83745944877344604a9acfb22ccd8dc1ee6dd1917e613976a1e6b06354(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewMetrics, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2c769d2157b1d61831a2bd86ebc99c99414cf9a0e4ec20d06d500576f3a68a2(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewRelationships, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28d6eea80375658cc3e7720f3f886e5fafeea5146a714868ebdac25df86025ea(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewTables, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de4c2c66b732960dbd368367d789e37c60fc928c429eb3095ad756b0566a23d1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5eab852463f8b3710f71c5b37cd2bf3821a47a826a25cab2377c036fa0ba072f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6fc712459f9ac790f189b2e2c79544369ace868bb2b11f8db1dff7f740e6a57(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13c2a0a66fc1b29dc526a5ea88602c7bcef132487fd8b03b7c3f196a254355d8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ac76a5be2e512371dd6ca9ef3c633452325c58b81e6e275451f656ac71c4cef9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dfc0d65439beca57957c8190b6c5ee5ce12ce859fedeeb9bb903ddf8dae7664b(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    database: builtins.str,
    name: builtins.str,
    schema: builtins.str,
    tables: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewTables, typing.Dict[builtins.str, typing.Any]]]],
    comment: typing.Optional[builtins.str] = None,
    dimensions: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewDimensions, typing.Dict[builtins.str, typing.Any]]]]] = None,
    facts: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewFacts, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    metrics: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewMetrics, typing.Dict[builtins.str, typing.Any]]]]] = None,
    relationships: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewRelationships, typing.Dict[builtins.str, typing.Any]]]]] = None,
    timeouts: typing.Optional[typing.Union[SemanticViewTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ab8f9a351a84da1a0ba56d0196bf4bde19dfac33dce0f01937ec403394669501(
    *,
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aeb6f424d59f82b5a6135a9c10652f4985f407e7abaaa74e01c549f291b83eda(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb80041f0dfc58835c981b2fb72021ac3a4814ad431dfb7d6a30942b188a74a0(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59b4abcb364fa92b72e433e256f684a91df3a54b4adfc36f92c7db139f3652a1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b4cd23478f95f252b9f3b6b02b1ddb8475fc7ca726f01f5ae2b496f4245245f5(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b77c1fb52f9ba154faecf5a86b9f61120a59c1170f97a65b907918e30cc1bd36(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a0aca4dfff18cb56258e7dec7f7b58dfc28426932544fe7c890fc04601233b8(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewDimensions]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2637f444790a360a11da32ce14b71cc6e8d6aec49e0570f362fcca006dbb8753(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bef3cc00f783d263fc3fd43e408ac57ed356e335f3bf2c9d5ca17eec342b6fa1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c0528f6851f4f28111a9ca0d81650d464339896049082452863bbdf4cb89beb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fad8e8ce61f907264a6200918887034384679bfb1ba35f4a67b4eaed58edc99f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5b89707c19ca1db4323c2584326d4781c89edab1e719707f68e422ec4e46c1d(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b1ccdbd50d57a582567d66f77b4496b6aef7a9ebf299cc81e985f7150d920b0(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewDimensions]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b803f0ad3de3cef0513a6664c07ff53194e47345bdfeba42b228a5138eb34a80(
    *,
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b692184c213e16d88864c9f1304e468bc8ddf9b17f4e04e21dd165cfced61ff(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f16b37cd4f07bfb74174f866800f97a089be6e28b9f8e71c28f63a2a894f672a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9369b8e703355b621dfc088e6a98965b33abfac31e9b4032b56b465cec6f0f3f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__190ff445e194de132ea2e0c0a12d961a20da2c1221d0e23d1f9a071b00001114(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c47dd2c36b92b8b12915ae3e0a1f857d170900796f523d3c2c65ede3912c747(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc9bcc74974752d4d8e61f90f30f28f4884c96032dcb4e5123c3a18b22d7518a(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewFacts]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73fd7a0287ef7b75f61cb73b3ffa917e1638181cd9185c8b839c60230c6ca877(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a37b7f013696cac5974d474577008bc347bd20256c44d06da15e38c798e22b1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c39466c7fee3f52acf5bcc33219792964593dd7cde6029ea0bd897776f17520(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9dfd7f54746bb19289534df475e894f76ae31e568f581aa2f42fef4acb5135b3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a273eac0d2a5b1f5a7eceed533e6576182f07bd9d6b4f227ba449cff5b61c59(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2afcb9eb3797fb52307919aee680b1b0219f649f6e9b853052d00062c86d4b50(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewFacts]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a2a46b291f6baa1833b5873b2c65bd7df8eed1cefb237961b45c63d66173999(
    *,
    semantic_expression: typing.Optional[typing.Union[SemanticViewMetricsSemanticExpression, typing.Dict[builtins.str, typing.Any]]] = None,
    window_function: typing.Optional[typing.Union[SemanticViewMetricsWindowFunction, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6cbd3cd771abd2263f7751d52d3071481a2a398361e0ba76b346ee56e5e9b15e(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e74e869dd14ef7cf173a2611f190528069ebaf1589ae18acb5edc56482db7c5(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e48ccf13ee2fed701fdc7c817070c52d59680df9036d34d86e5f28707dd9bacb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92cc0f0b591f8ebaeeb94f66f0e04acea8b3afab5286eea45922d66fb77f521b(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63bd9f4aa0f21b6b8ce9b935206baa467382e54fae52973ecef4d6301c9b1833(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f26ef6f88046d05959c72679b95710348c00f3f1525e372d28faae052e9588ed(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewMetrics]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77e6a7a01aee9f67e4073c43e64557cb8e818548ec0c232cf6916132bf9cec57(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd10dbe2661d0a9f8fa62e16d1943a2cd59c4212d533b7a1a7a217f63d23818e(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewMetrics]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f3a75495cfc8bbeb19df131ae2827aa370d9fbb3d23c53c6bd448927eab4efc(
    *,
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a170c817edb984e3deb49964fd28fc263255c90cfd5efb110968cdd8fd48e414(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5be7ad944bb1dc0ed8ae93cf2fb72a8b34133866433d0771d95689402448c839(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1000cd4b7060e11fd723053e7ae88d41640ef0229fa9ef931a606aa29915d275(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b0bf0835071fea6978f782d06760fee3b685aef5d05cdb1311126554e18adf5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5134cda65e0858b6a849097949d54af9b0ea56a0bee8a848725fa3a99d93500d(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__818d921f1a0421c7f8de8f2d901a91bdd20c2c134f911f3bc370e3acc01183a4(
    value: typing.Optional[SemanticViewMetricsSemanticExpression],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bcf1ecbbcaa21ff8fe24be8353cdf55679feb780b4ac9ec9ca23ea3037de796(
    *,
    over_clause: typing.Union[SemanticViewMetricsWindowFunctionOverClause, typing.Dict[builtins.str, typing.Any]],
    qualified_expression_name: builtins.str,
    sql_expression: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d44cf21347f366ff74b866c145ab2969f291cfa01b5049ce087398a42ba08ecd(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2efb41d787394dac9a783cb71c791085d30c93fb8b041299699643f5d17d4a08(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75bf3d4b48f2309be926f98f50f1bb215ffde316635435b4f428683f794baac1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ea0487a8e33b3c5331d0150d19d5508805880238f6c959de5e499e96b567245(
    value: typing.Optional[SemanticViewMetricsWindowFunction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e10a996fccced210bc43d357870cb040df19d2f850ad3d731c9abb9a9245f24(
    *,
    order_by: typing.Optional[builtins.str] = None,
    partition_by: typing.Optional[builtins.str] = None,
    window_frame_clause: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2aab0e423ba3d041f5a60012a10fdc2691fe3c51bf7479b4c0bff4b875979340(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__efaf5b9c940e8c1adc7fe87086e3802a1153ee6c02406b923e69ceee9c1954ea(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eda5c26646d9bd4e2a3908dc462b2b7e851d480201a247dc3f7625f9e83ec040(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e47490dc0566db766742488b1f17b589c648c1de24f085c8528bc9122f550e6c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6e6cb8a2ac684bddde095e5a817bdb530234df55ef92f660190f533698bf934(
    value: typing.Optional[SemanticViewMetricsWindowFunctionOverClause],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b665e6ccc053f55e0310833efbd5f256a9712ba53d141316bca9c05f0e8ccc76(
    *,
    referenced_table_name_or_alias: typing.Union[SemanticViewRelationshipsReferencedTableNameOrAlias, typing.Dict[builtins.str, typing.Any]],
    relationship_columns: typing.Sequence[builtins.str],
    table_name_or_alias: typing.Union[SemanticViewRelationshipsTableNameOrAlias, typing.Dict[builtins.str, typing.Any]],
    referenced_relationship_columns: typing.Optional[typing.Sequence[builtins.str]] = None,
    relationship_identifier: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c6d07720e5f79c18fa0575f30a5c54838c990a8206a4558085c6bf9959be3fb(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3fbc5a5c4e4ddead6f00a5a66b0eeb4da6d2e14294b9acedbac817635834f7b(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a757dcbaf22eb9f67497ce18a4022988348c3e5d0b98118212b00ad902ad2a6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__226d9dbc76eac645a6ad3818f50d57637a8d2da0eeabc7e048b30ee6ce10d73a(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57cd0d354538d1fbb097bfe6152c96857367de8e05bb8659c1fe5b8b0b2af427(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd63a31b6be445a3348ffa82e36b02fa3322c501bbe85c54c7a6055dc1aaeaa5(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewRelationships]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__318d82eccc28516114cad870bd897f32614af1050ff9d54c9c10281f74fd4492(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c47feda907fd4c61ac76ccb6b56ddb5d2eae799c4e5d14348d7d7e92b1dd190b(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9c97af98b125a9b96e700510ae634a5b325d07ef9c608b6364b37c6a076f6b1(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aec3fea13a0ccb48cbe1e5ccdb2740c99b15b5ebc2fc60401926b7b49827b81c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b53a9feb49e4a2c15739fcceea98f34f8b2411d7dc2664d8022f3735306a982(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewRelationships]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4521f4b6dfcc2e34b3b8dae80a5fcf29a5d20a2b14a0d6058f3a1aafb1751515(
    *,
    table_alias: typing.Optional[builtins.str] = None,
    table_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5bc005ed798777ff66ee377c5eff4d1bce074e3ad6ee55dffcd41d914f94474(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ae3ed441760843a123444482ea2cab24d059cf17775e333cf823a532b5863b5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec2ba727f598c2bbc2b6baf1cf4df812f01837fd4e99cb080c2ceebc28ed7e18(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05bfac43a27d38b092167562d12fe47e4c361f3e2e68ed3f8a426766d211c02f(
    value: typing.Optional[SemanticViewRelationshipsReferencedTableNameOrAlias],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74024f10db9816592c15c3c437a8a18e30592305fe8a670d8cd1bc32e03ec241(
    *,
    table_alias: typing.Optional[builtins.str] = None,
    table_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e101c1d4ce0dda4c8d2644bee22003f127e37da836c5f5d7e59ac8634ca8024(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1910cae7c988a81e6954ea8ed79bd659828041659f10f6d694d4958b2b234de2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80125e8817d15411970762cac1470da4910a9e0d102427f41178c464154b6f88(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__563637021bc1440e53508e08248f4a16cd77a2adb2acad5376190d9729df933e(
    value: typing.Optional[SemanticViewRelationshipsTableNameOrAlias],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a23cd8907495abb0e8458d541e28e34c31f7cd39c7e4bed6309fb61e46b341f(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c7bc50dd4ece5017d31522563caba682be55ecf7bae8c40a69e45fe8ddfe978(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35a350a98fd6b4200f01f43fec62291f6c9430d8b191d6c1b7fca6f259a07d48(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76d6e28aa4f81ca3be0afe10b87479b5b55c0c0ca1623c2ea4c1a80aadf2f8dc(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9633a1b12fbaee2897a455eff670711217275eca3dd6c289c8da2176e7d9597b(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca8872016c36d2491c0a275164b1a43f718ccbd769c6b7900dcc953b9d22a099(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3bfe09eb235c71b870720bb199ccd6266fa8a3f93c1df5467f9946a1661de535(
    value: typing.Optional[SemanticViewShowOutput],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f4a6dcc2c5a4c05826d8873a3c0ef518a353d45a5c586dc26b6a9d4ee545489(
    *,
    table_alias: builtins.str,
    table_name: builtins.str,
    comment: typing.Optional[builtins.str] = None,
    primary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    synonym: typing.Optional[typing.Sequence[builtins.str]] = None,
    unique: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewTablesUnique, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d20145025272f4a78ccb72447df46222db3355a3cf1f2df27f03e56c35a171a9(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__daa06502deacc2520b220e4475b82ddb31805ba66a260d328a57cda9a03e0d60(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8bc36869c2756e5bec8711e02e5b5939ba76365cd0d88dc32d979be321797b75(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a0358dfb18798de2ba47ddcd868789bf42a089a87001afeef59868479aa848ca(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cd1d85b529de43b942cb7145a6a21c259141f5e78a12faa5a1e83ba3248e7c9f(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e0dc07ff0433094021b4eb02028886618f701f6cb6d65ebcc4957590d3a9a7cf(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTables]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__983ef3bcf32b5f5c3e78c392d3ca212ce538e0e9b193d4efe1fba5b7e6d4d52b(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77948af9f099ebda5c3584fd2680d294fd001eb2a1c4c9ed0e73e4b1f710456b(
    value: typing.Union[_cdktf_9a9027ec.IResolvable, typing.Sequence[typing.Union[SemanticViewTablesUnique, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ba1ecc0934f6ba99adb332ca40d6041a3cf8de9e208cf5e3ff42bd3b1f09ca4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ea63fb91553665769c1b8c332ecfd244c471b4e89da8151dab1e3cd486b757d1(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aed83f5a29d7498df3934007cf4b1333ed0e7d8ed22d62c229d2318f4b8aff03(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4588a4e4efd73095200b00c6418d80ef0c1108d9c646beb0314c533465ac4a9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b235e61a22a06a3d11c9f3c1f45e434e73147803ac4dea661075d5eefe4bbb75(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f3dd0043aff71b38d71bdf0ef9a312341a168fb47f343d585ca996006dd1f58(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTables]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff6a2bd0b62c69494d98d1871ea0961e15c96fbbe1cab87c4e86502d9ea62097(
    *,
    values: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38a5040331c14107f51f4cdc21d997106d2657b0254b732eb84f011d4da68886(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6d360b7f7aea4de42562ab3017e431430478907aa70234a104963e2577f673d9(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2648428f671355f82b3c0e0ab9f0a5782917f6302ba75c2f500dd4f8f7d24745(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8cc430bed498d6a0e7da84efa7eceb2cb899fcfb55a40c1755d693c44a3e354e(
    value: _cdktf_9a9027ec.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9816fa80931da11b15bc4f6806846e1b3a581e08fc5de3529c2d6a254e8a63f(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9745c577a8774aef93c0cb079d5c8083b289cd2a8da0d56cb8b94f8ba779bc91(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, typing.List[SemanticViewTablesUnique]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__242b0ba554802d94eab3e4c2f152aa8a9a1d26e8bed1860b7daefe7bef9c299a(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a84575df5d4adca8c361191a51253079c7c061991397835ea71dd62d1772277(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec9aabcba70e13d9739ef9310e5c4b24889fd6939e913382804f8994163bd4d3(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTablesUnique]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c9298082b540c96e71a4d3498c25c03776d619fef64b8c8cee47be871b5637a8(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__403182edecece2b78cd0c37f2f2cb72dc03ca1881640ae93d453e59c38276e55(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__392a843773a36a95ca2b3e74a2368b86ec36bb25ca9328edc7b5231b25dcdaa5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__953aca89f7887d3d38e9726db426db662cd2961fe3a08d8debebfde03a15a1ca(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__58543a3e8751ab6d04997b072276a37e86c627eb523c728558db0e88e7204023(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9ff24123c002e6e36f228432e1c6b1de47b62dd07b591efee8af1fb2737ede8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__606f2a45091c0c8a0437d2844167d5bbd83ded8604db9e0a1c8e2efbb21dd502(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, SemanticViewTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
