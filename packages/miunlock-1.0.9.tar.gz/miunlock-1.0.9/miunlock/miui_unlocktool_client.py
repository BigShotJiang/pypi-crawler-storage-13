import requests
import json
import random
import hashlib
import hmac
import binascii
from base64 import b64encode, b64decode
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad


def _send(path, param_order, params_raw, domain, ssecurity, cookies):

    headers = {"User-Agent": "XiaomiPCSuite"}

    if 'data' in params_raw:
        params_raw['data'] = json.dumps(params_raw['data'])
        params_raw['data'] = b64encode(params_raw['data'].encode()).decode()

    cipher = lambda: AES.new(b64decode(ssecurity), AES.MODE_CBC, b'0102030405060708')
    ep = lambda x: b64encode(cipher().encrypt(pad(x.encode(), AES.block_size))).decode()

    params_raw["sid"] = "miui_unlocktool_client"
    sign_params = '&'.join(f"{k}={params_raw[k]}" for k in param_order)
    sign_str = f"POST\n{path}\n{sign_params}"
    current_sign = b64encode(cipher().encrypt(pad(binascii.hexlify(hmac.new(
        b'2tBeoEyJTunmWUGq7bQH2Abn0k2NhhurOaqBfyxCuLVgn4AVj7swcawe53uDUno',
        sign_str.encode(), hashlib.sha1).digest()).decode().encode(), AES.block_size))).decode()

    encoded_params = [f"{k}={ep(params_raw[k])}" for k in param_order]
    encoded_params.extend([f"sign={current_sign}", ssecurity])

    sha1_input = f"POST&{path}&{'&'.join(encoded_params)}"
    signature = b64encode(hashlib.sha1(sha1_input.encode()).digest()).decode()

    post_params = {k: ep(params_raw[k]) for k in param_order}
    post_params.update({'sign': current_sign, 'signature': signature})

    r = requests.post(f"{domain}{path}", params=post_params, cookies=cookies, headers=headers)

    if not r.text:
        return {"error": "Empty response", "status_code": r.status_code}

    decrypted = unpad(cipher().decrypt(b64decode(r.text)), AES.block_size)
    return json.loads(b64decode(decrypted).decode())



def _client(domain, ssecurity, cookies, token, product, pcId):
    userId = cookies.get("userId")
    r = "".join(random.choices("abcdefghijklmnopqrstuvwxyz", k=16))
    nonce_resp = _send("/api/v2/nonce", ["r", "sid"], {"r": r}, domain, ssecurity, cookies)
    nonce = nonce_resp.get("nonce")
    if not nonce:
        return nonce_resp

    data = {
        "clientId": "2",
        "clientVersion": "7.6.727.43",
        "deviceInfo": {
            "boardVersion": "",
            "deviceName": "",
            "product": product,
            "socId": ""
        },
        "deviceToken": token,
        "language": "en",
        "operate": "unlock",
        "pcId": hashlib.md5(pcId.encode()).hexdigest(),
        "region": "",
        "uid": userId
    }

    return _send(
        "/api/v3/ahaUnlock",
        ["appId", "data", "nonce", "sid"],
        {"appId": "1", "data": data, "nonce": nonce},
        domain, ssecurity, cookies
    )