import requests
import json
import hashlib

def _service(cookies):
    pcId = hashlib.md5(cookies.get('deviceId').encode()).hexdigest()
    url = 'https://account.xiaomi.com/pass/serviceLogin'
    params = {'sid': 'unlockApi'}
    headers = {"User-Agent": "XiaomiPCSuite"}
    r = requests.get(url, params=params, cookies=cookies, headers=headers)
    pragma = r.history[0].headers["extension-pragma"]
    data = json.loads(pragma)
    cookies = r.cookies.get_dict()
    ssecurity = data.get("ssecurity")
    return cookies, ssecurity, pcId
