from .miui_unlocktool_client import _client

from .domain_client import _DOMAINS

from .service_client import _service

from .login import _login_and_get_config

def client(domain, ssecurity, cookies, token, product, pcId):
    return _client(domain, ssecurity, cookies, token, product, pcId)

def DOMAINS(regionConfig):
    return _DOMAINS[regionConfig]

def service(cookies):
    return _service(cookies)

def login_and_get_config():
    return _login_and_get_config()





        