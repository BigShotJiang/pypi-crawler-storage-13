#!/usr/bin/python

import os
import json
import hashlib
import time
import platform
import webbrowser
from urllib.parse import urlparse, parse_qs
import requests


headers = {"User-Agent": "XiaomiPCSuite"}

def open_browser():
    input(f"\nPress Enter to open confirmation page, \n copy url after seeing \"R\":\"\",\"S\":\"OK\", \n  and return here\n\n")
    config_url = 'https://account.xiaomi.com/pass/serviceLogin?sid=unlockApi&checkSafeAddress=true'
    if platform.system() == "Linux":
        os.system("xdg-open '" + config_url + "'")
    else:
        webbrowser.open(config_url)
    time.sleep(2)
    url = input("Enter url: ").strip()
    deviceId = parse_qs(urlparse(url).query).get('d', [None])[0]
    if deviceId is None:
        print("\nInvalid url\n")
        return open_browser()
    for _ in range(3):
        userId = requests.get(url, headers=headers).cookies.get('userId')
        if userId:
            return userId, deviceId
        time.sleep(2)
    else:
        print("\nauth expired\n")
        return open_browser()

    
def _login_and_get_config():
    userId, deviceId = open_browser()
    
    cookies = {'deviceId': deviceId}
    
    url = 'https://account.xiaomi.com/pass/serviceLogin?sid=unlockApi'
    response = requests.get(url, headers=headers, cookies=cookies)
    cookies = response.cookies.get_dict()
    
    data = {
        '_json': 'true',
        'callback': 'https://unlock.update.miui.com/sts',
        'sid': 'unlockApi',
        'qs': '%3Fsid%3DunlockApi',
        '_sign': 'CiofaOM8ndWC+UjNoI6pjSx8sPM=',
        'serviceParam': '{"checkSafePhone":false,"checkSafeAddress":false,"lsrp_score":0.0}',
        '_locale': 'en_US',
        'useManMachine': 'false'
    }
    
    data.update({"user": userId})
    
    pwd = input('\nEnter password: ')
    data.update({"hash": hashlib.md5(pwd.encode()).hexdigest().upper()})
    
    response = requests.post(
        "https://account.xiaomi.com/pass/serviceLoginAuth2",
        data=data,
        headers=headers,
        cookies=cookies
    )
    
    response_text = json.loads(response.text[11:])
    if response_text["code"] == 70016:
        return {"error": "Invalid password"}

    cookies = response.cookies.get_dict()
    
    response = requests.get(
        "https://account.xiaomi.com/pass/user/login/region",
        headers=headers,
        cookies=cookies
    )
    
    region = json.loads(response.text[11:])["data"]["region"]
    
    print(f'\naccount region: {region}\n')

    response = requests.get(
        "https://account.xiaomi.com/pass2/config?key=regionConfig",
        headers=headers,
        cookies=cookies
    )
    
    config_data = json.loads(response.text[11:])
    region_config_dict = config_data["regionConfig"]
    
    regionConfig = next(
        (k for k, v in region_config_dict.items()
         if v.get("region.codes") and region in v["region.codes"]),
        None
    )
    
    if not regionConfig:
        return {"error": f"Region configuration not found for region: {region}"}
    
    return cookies, regionConfig