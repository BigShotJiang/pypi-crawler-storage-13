from setuptools import setup, find_packages

setup(
    name="gcp-route-optimizer",  # Must be unique on PyPI
    version="0.1.0",
    author="Preethi",
    description="A wrapper for Google Route Optimization API for single vehicle logistics.",
    long_description=open("README.md").read() if open("README.md") else "",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "requests",
        "google-auth",
        "google-auth-httplib2"
    ],
    python_requires='>=3.7',
)