# Route Optimization Solver

A Python wrapper for the Google Cloud Route Optimization API. It simplifies the complex JSON payload required by Google into a simple Python function call.

## Features
- **OAuth2 Handling:** Automatically fetches and refreshes Google Access Tokens.
- **Coordinate Validation:** Prevents API errors by validating lat/lng before sending.
- **VRP Support:** Supports capacity constraints (weights) and time windows.

## Installation

```bash
pip install gcp-route-optimizer