# Cardisk — USSD Framework 

This release includes:
- Logging (Python logging) with sensible defaults.
- Prometheus metrics endpoint (`/metrics`) for basic request metrics.
- Error handling middleware and safer handler execution.
- Dockerfile for running the example app.
- GitHub Actions workflow for CI (runs pytest).
- Example app and tests.

## Install (development)
```bash
pip install -e .
```

## Run example app (development)
```
uvicorn examples.mybank.main:ussd_app.app --reload --port 8000
```

## Metrics
Visit `http://localhost:8000/metrics` to see Prometheus metrics.

## Docker
Build:
```
docker build -t cardisk:latest .
```
Run:
```
docker run -p 8000:8000 cardisk:latest
```

## CI
GitHub Actions workflow at `.github/workflows/ci.yml` will install the package and run `pytest`.

## Tests
Run locally:
```
pytest -q
```

## Notes
- Redis is optional via `CARDISK_USE_REDIS`.
- This package is a starter kit—consider adding more robust logging, structured logs, and observability as needed.
