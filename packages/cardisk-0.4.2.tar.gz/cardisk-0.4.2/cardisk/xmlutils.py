# XML encoding utilities per TruRoute spec
def xml_escape(s: str) -> str:
    if s is None:
        return ""
    res = []
    for ch in s:
        code = ord(ch)
        if ch == '&':
            res.append('&amp;')
        elif ch == '<':
            res.append('&lt;')
        elif ch == '>':
            res.append('&gt;')
        elif ch == '"':
            res.append('&quot;')
        elif ch == "'":
            res.append('&apos;')
        elif ch == '\n':
            res.append('&#10;')
        elif code < 32:
            res.append(' ')
        elif code > 127:
            res.append('&#x{:x};'.format(code))
        else:
            res.append(ch)
    return ''.join(res)
