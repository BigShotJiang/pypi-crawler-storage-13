import xml.etree.ElementTree as ET
from typing import Dict

def parse_ussd_request(xml_data: str) -> Dict[str, str]:
    root = ET.fromstring(xml_data)
    return {
        "msisdn": root.findtext("msisdn") or "",
        "sessionid": root.findtext("sessionid") or "",
        "type": root.findtext("type") or "1",
        "msg": root.findtext("msg") or "",
    }
