from fastapi.responses import Response
import xml.etree.ElementTree as ET
from .xmlutils import xml_escape

def ussd_response(message: str, end_session: bool = False):
    root = ET.Element("ussd")
    type_el = ET.Element("type")
    type_el.text = "3" if end_session else "2"
    root.append(type_el)

    msg_el = ET.Element("msg")
    # already escaped
    msg_el.text = xml_escape(message)
    root.append(msg_el)

    xml_str = ET.tostring(root, encoding="utf-8")
    return Response(content=xml_str, media_type="application/xml")
