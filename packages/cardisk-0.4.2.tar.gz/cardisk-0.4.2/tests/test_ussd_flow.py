import pytest
from fastapi.testclient import TestClient
from examples.mybank import main as mybank_app
from cardisk import ussd_app

client = TestClient(ussd_app.app)

def build_xml(msisdn, sessionid, type_, msg):
    return f"""<ussd>
<msisdn>{msisdn}</msisdn>
<sessionid>{sessionid}</sessionid>
<type>{type_}</type>
<msg>{msg}</msg>
</ussd>"""

def test_full_flow():
    msisdn = '27829991234'
    xml = build_xml(msisdn, '', 1, '*123#')
    r = client.post('/ussd', data=xml)
    assert r.status_code == 200
    assert 'Welcome' in r.text

    xml2 = build_xml(msisdn, '', 2, '1')
    r2 = client.post('/ussd', data=xml2)
    assert r2.status_code == 200
    assert 'balance' in r2.text.lower()

    xml3 = build_xml(msisdn, '', 2, '')
    r3 = client.post('/ussd', data=xml3)
    assert r3.status_code == 200
