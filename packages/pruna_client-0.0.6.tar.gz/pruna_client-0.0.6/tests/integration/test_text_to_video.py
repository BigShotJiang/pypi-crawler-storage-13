"""Integration tests for text-to-video generation."""

from pruna_client import Response
from pruna_client.models import PredictionStatus


class TestTextToVideoFlow:
    """Integration tests for text-to-video generation flow."""

    def test_wan_t2v_model(self, client):
        """Test text-to-video generation with wan-t2v model using async polling."""
        # Start async generation
        response = client.generate_text_to_video(
            model="wan-t2v",
            prompt="A sports car is driving very fast along a beach at sunset, aerial drone shot, cinematic",
            sync=False,
        )

        # Verify initial response
        assert isinstance(response, Response)
        assert response.status in [
            PredictionStatus.STARTING,
            PredictionStatus.PROCESSING,
        ]
        assert response.id is not None
        assert response.raw_response.get("get_url") is not None

        # Poll until completion
        final_response = client.poll_status(response=response)

        # Verify final status
        assert final_response.status in [
            PredictionStatus.SUCCEEDED,
            PredictionStatus.FAILED,
        ]

        if final_response.status == PredictionStatus.SUCCEEDED:
            assert "output" in final_response.outputs
            video_bytes = final_response.outputs["output"]
            assert isinstance(video_bytes, bytes)
            assert len(video_bytes) > 0
