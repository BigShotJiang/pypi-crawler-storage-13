"""Integration tests for image-to-video generation."""

from pruna_client import Response
from pruna_client.models import PredictionStatus


class TestImageToVideoFlow:
    """Integration tests for image-to-video generation flow."""

    def test_wan_i2v_model(self, client, sample_image):
        """Test image-to-video generation with wan-i2v model using async polling."""
        # Start async generation
        response = client.generate_image_to_video(
            model="wan-i2v",
            prompt="The camera slowly pushes in, gentle movement",
            image=sample_image,
            sync=False,
        )

        # Verify initial response
        assert isinstance(response, Response)
        assert response.status in [
            PredictionStatus.STARTING,
            PredictionStatus.PROCESSING,
        ]
        assert response.id is not None
        assert response.raw_response.get("get_url") is not None

        # Poll until completion
        final_response = client.poll_status(response=response)

        # Verify final status
        assert final_response.status in [
            PredictionStatus.SUCCEEDED,
            PredictionStatus.FAILED,
        ]

        if final_response.status == PredictionStatus.SUCCEEDED:
            assert "output" in final_response.outputs
            video_bytes = final_response.outputs["output"]
            assert isinstance(video_bytes, bytes)
            assert len(video_bytes) > 0
