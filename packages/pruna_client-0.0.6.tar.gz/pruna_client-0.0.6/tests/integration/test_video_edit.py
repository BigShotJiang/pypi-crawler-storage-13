"""Integration tests for video editing with VACE model."""

from pruna_client import Response
from pruna_client.models import PredictionStatus


class TestVideoEditFlow:
    """Integration tests for video editing flow with VACE model."""

    def test_vace_model(self, client):
        """Test video generation with vace model using async polling."""
        # Start async generation
        response = client.generate_video_edit(
            model="vace",
            prompt="A person walking through a magical forest with glowing trees",
            sync=False,
        )

        # Verify initial response
        assert isinstance(response, Response)
        assert response.status in [
            PredictionStatus.STARTING,
            PredictionStatus.PROCESSING,
        ]
        assert response.id is not None
        assert response.raw_response.get("get_url") is not None

        # Poll until completion
        final_response = client.poll_status(response=response)

        # Verify final status
        assert final_response.status in [
            PredictionStatus.SUCCEEDED,
            PredictionStatus.FAILED,
        ]

        if final_response.status == PredictionStatus.SUCCEEDED:
            assert "output" in final_response.outputs
            video_bytes = final_response.outputs["output"]
            assert isinstance(video_bytes, bytes)
            assert len(video_bytes) > 0
