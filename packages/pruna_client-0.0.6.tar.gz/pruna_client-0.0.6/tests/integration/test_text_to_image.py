"""Integration tests for text-to-image generation."""
from PIL import Image

from pruna_client import Response
from pruna_client.models import PredictionStatus


class TestSynchronousTextToImageFlow:
    """Integration tests for synchronous text-to-image generation flow."""
    
    def test_complete_sync_generation_flow(self, client):
        """Test complete synchronous image generation flow from start to finish."""
        # Execute the full flow with real API
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A beautiful sunset over a calm ocean with vibrant colors",
            sync=True
        )
        
        # Verify the result
        assert response is not None
        assert isinstance(response, Response)
        
        if response.status == PredictionStatus.SUCCEEDED:
            # For sync request via generate_text_to_image, we expect an Image object directly
            assert "output" in response.outputs
            img = response.outputs["output"]
            if isinstance(img, Image.Image):
                assert img.size[0] > 0
                assert img.size[1] > 0    
                assert img.mode in ["RGB", "RGBA"]
    
    def test_sync_generation_with_parameters(self, client):
        """Test synchronous generation with additional parameters."""
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A serene mountain landscape at dawn",
            sync=True,
            aspect_ratio="custom",
            width=512,
            height=512
        )
        
        assert response is not None
        assert isinstance(response, Response)
        
        if response.status == PredictionStatus.SUCCEEDED:
            assert "output" in response.outputs
            img = response.outputs["output"]
            if isinstance(img, Image.Image):
                assert img.size == (512, 512)
    
    def test_sync_generation_error_handling(self, client):
        """Test error handling with invalid input."""
        response = client.generate_text_to_image(
            model="p-image",
            prompt="",  # Empty prompt might cause error
            sync=True
        )
        
        # Should return either an image or an error response
        assert response is not None
        assert isinstance(response, Response)
        # Status could be succeeded (if API handles empty prompt gracefully) or failed


class TestAsynchronousTextToImageFlow:
    """Integration tests for asynchronous text-to-image generation flow with polling."""
    
    def test_complete_async_generation_flow(self, client):
        """Test complete async generation flow: start -> poll -> download."""
        # Start async generation
        response = client.generate_text_to_image(
            model="p-image",
            prompt="An abstract painting with vibrant colors and geometric shapes",
            sync=False
        )
        
        # Verify initial response
        assert isinstance(response, Response)
        assert response.status == PredictionStatus.STARTING
        assert response.id is not None
        assert response.raw_response.get("get_url") is not None
        
        # Poll until completion
        final_response = client.poll_status(response=response)
        
        # Verify final status
        assert final_response.status in [PredictionStatus.SUCCEEDED, PredictionStatus.FAILED]
        
        if final_response.status == PredictionStatus.SUCCEEDED:
            assert "output" in final_response.outputs
            # poll_status is generic, so it returns bytes. We use helper to get Image.
            image = final_response.to_pil_image("output")
            assert isinstance(image, Image.Image)
    
    def test_async_generation_polling_with_url(self, client):
        """Test async generation polling using status URL directly."""
        # Start async generation
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A futuristic cityscape at night",
            sync=False
        )
        
        get_url = response.raw_response.get("get_url")
        assert get_url is not None
        
        # Poll using URL directly
        final_response = client.poll_status(status_url=get_url)
        
        assert final_response.status in [PredictionStatus.SUCCEEDED, PredictionStatus.FAILED]
        if final_response.status == PredictionStatus.SUCCEEDED:
            assert "output" in final_response.outputs
            # poll_status is generic, so it returns bytes. We use helper to get Image.
            image = final_response.to_pil_image("output")
            assert isinstance(image, Image.Image)
            assert image.size[0] > 0
            assert image.size[1] > 0


class TestEndToEndTextToImageWorkflows:
    """Integration tests for complete end-to-end text-to-image workflows."""
    
    def test_workflow_async_generate_and_download(self, client):
        """Test workflow: async generate -> poll -> download."""
        # Start async generation
        response = client.generate_text_to_image(
            model="p-image",
            prompt="A minimalist geometric design",
            sync=False
        )
        
        assert isinstance(response, Response)
        assert response.raw_response.get("get_url") is not None
        
        # Poll for completion
        final_response = client.poll_status(response=response)
        
        if final_response.status == PredictionStatus.SUCCEEDED:
            # Download the image (already downloaded by poll_status as bytes)
            assert "output" in final_response.outputs
            image = final_response.to_pil_image("output")
            assert isinstance(image, Image.Image)
            assert image.size[0] > 0
            assert image.size[1] > 0
