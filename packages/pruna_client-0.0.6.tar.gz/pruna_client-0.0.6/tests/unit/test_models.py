import base64
import io
import os
from PIL import Image
import pytest
from pruna_client.models import (
    Error,
    PredictionError,
    PredictionErrorCode,
    OutputFile,
    FileUploadResponse,
    PredictionResponse,
    PredictionStatusResponse,
    PredictionStatus,
    Response,
)

def test_error_model():
    error = Error(request_id="req_123")
    assert error.request_id == "req_123"

def test_prediction_error_model():
    error = PredictionError(
        code=PredictionErrorCode.INVALID_INPUT,
        message="Invalid input",
        details="More details"
    )
    assert error.code == PredictionErrorCode.INVALID_INPUT
    assert error.message == "Invalid input"
    assert error.details == "More details"

def test_output_file_model():
    output = OutputFile(
        url="/path/to/file",
        filename="file.txt",
        content_type="text/plain",
        size=100
    )
    assert output.url == "/path/to/file"
    assert output.size == 100

def test_file_upload_response_model():
    response = FileUploadResponse(
        id="file_123",
        filename="test.jpg",
        content_type="image/jpeg",
        size=1024,
        etag="etag123",
        checksums={"md5": "abc"},
        metadata={"key": "value"},
        created_at="2023-01-01",
        expires_at="2023-01-02",
        urls={"download": "http://example.com"}
    )
    assert response.id == "file_123"
    assert response.checksums["md5"] == "abc"

def test_prediction_response_model():
    response = PredictionResponse(
        id="pred_123",
        model="model_x",
        input={"prompt": "hello"},
        status_url="http://status"
    )
    assert response.id == "pred_123"
    assert response.input["prompt"] == "hello"

def test_prediction_status_response_model():
    status = PredictionStatusResponse(
        status=PredictionStatus.PROCESSING,
        message="Working..."
    )
    assert status.status == PredictionStatus.PROCESSING
    assert status.message == "Working..."
