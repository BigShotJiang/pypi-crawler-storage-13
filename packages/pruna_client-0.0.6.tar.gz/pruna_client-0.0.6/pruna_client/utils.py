import time


class TTLCache:
    """Simple TTL (Time-To-Live) cache using dict with timestamp tracking.
    
    This is a lightweight alternative to functools.lru_cache that supports TTL.
    Python's built-in lru_cache doesn't support time-based expiration.
    """
    
    def __init__(self, ttl_seconds: int = 600, cleanup_interval: int = 300):
        """Initialize TTL cache.
        
        Args:
            ttl_seconds: Time-to-live in seconds. Defaults to 600 (10 minutes).
            cleanup_interval: Interval in seconds between automatic cleanups. Defaults to 300 (5 minutes).
        """
        self.ttl_seconds = ttl_seconds
        self.cleanup_interval = cleanup_interval
        self._cache: dict[str, tuple[str, float]] = {}
        self._last_cleanup: float = time.time()
    
    def get(self, key: str) -> str | None:
        """Get cached value if not expired."""
        # Periodic cleanup to prevent memory growth
        self._maybe_cleanup()
        
        if key not in self._cache:
            return None
        
        value, timestamp = self._cache[key]
        if time.time() - timestamp > self.ttl_seconds:
            del self._cache[key]
            return None
        
        return value
    
    def set(self, key: str, value: str) -> None:
        """Cache value with current timestamp."""
        # Periodic cleanup to prevent memory growth
        self._maybe_cleanup()
        self._cache[key] = (value, time.time())
    
    def _maybe_cleanup(self) -> None:
        """Remove expired entries if cleanup interval has passed."""
        now = time.time()
        if now - self._last_cleanup < self.cleanup_interval:
            return
        
        self._last_cleanup = now
        expired_keys = [
            key for key, (_, timestamp) in self._cache.items()
            if now - timestamp > self.ttl_seconds
        ]
        for key in expired_keys:
            del self._cache[key]
    
    def clear(self) -> None:
        """Clear all cached entries."""
        self._cache.clear()
        self._last_cleanup = time.time()
