"""Data models for Pruna API responses."""
from dataclasses import dataclass, field
from enum import Enum
from io import BytesIO
from typing import Any

from PIL import Image


class PredictionStatus(str, Enum):
    """Current status of the prediction."""

    STARTING = "starting"
    PROCESSING = "processing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELED = "canceled"


class PredictionErrorCode(str, Enum):
    """Error code for programmatic handling."""

    INVALID_INPUT = "INVALID_INPUT"
    MODEL_ERROR = "MODEL_ERROR"
    TIMEOUT = "TIMEOUT"
    QUOTA_EXCEEDED = "QUOTA_EXCEEDED"
    INTERNAL_ERROR = "INTERNAL_ERROR"


@dataclass
class Error:
    """Unique request identifier for debugging."""

    request_id: str


@dataclass
class PredictionError:
    """Error details for a failed prediction."""

    code: PredictionErrorCode
    message: str
    details: str | None = None


@dataclass
class OutputFile:
    """Details of a generated content file."""

    url: str
    filename: str
    content_type: str
    size: int


@dataclass
class FileUploadResponse:
    """Response for a file upload."""

    id: str
    filename: str
    content_type: str
    size: int
    etag: str
    checksums: dict[str, str]
    metadata: dict[str, Any]
    created_at: str
    expires_at: str
    urls: dict[str, str]


@dataclass
class PredictionResponse:
    """Initial response when a prediction is created."""

    id: str
    model: str
    input: dict[str, Any]
    status_url: str


@dataclass
class PredictionStatusResponse:
    """Status response for a prediction."""

    status: PredictionStatus
    delivery_url: str | None = None
    message: str | None = None
    error: PredictionError | None = None


@dataclass
class Response:
    """Unified response class for Pruna API predictions."""

    id: str
    model: str
    inputs: dict[str, Any]
    outputs: dict[str, Any] = field(default_factory=dict)
    status: PredictionStatus = PredictionStatus.SUCCEEDED
    raw_response: Any | None = None

    def to_pil_image(self, key: str = "output") -> Image.Image:
        """
        Convert output bytes to PIL Image.

        Args:
            key: Key in outputs dict to convert. Defaults to "output".

        Returns:
            PIL Image object.

        Raises:
            KeyError: If key is not in outputs.
            ValueError: If output cannot be converted to Image.
        """
        if key not in self.outputs:
            raise KeyError(f"Output key '{key}' not found in outputs")

        output = self.outputs[key]

        # If already a PIL Image, return it
        if isinstance(output, Image.Image):
            return output

        # If bytes, convert to Image
        if isinstance(output, bytes):
            try:
                image = Image.open(BytesIO(output))
                image.load()  # Load image data to ensure it's valid
                return image
            except Exception as e:
                raise ValueError(f"Failed to convert bytes to PIL Image: {e}") from e

        raise ValueError(
            f"Output '{key}' is not bytes or PIL Image, got {type(output)}"
        )

