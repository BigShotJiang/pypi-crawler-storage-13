# Pruna Client

Official Pruna API client for image and video generation and editing.

## Installation

```bash
uv add pruna-client
```

## Quick Start

```python
from pruna_client import PrunaClient
from PIL import Image

# Initialize client (uses PRUNA_API_KEY env var if api_key not provided)
client = PrunaClient(api_key="your_api_key")

# Generate image
response = client.generate_text_to_image(
    model="p-image",
    prompt="A beautiful sunset over a calm ocean",
    sync=True
)

if isinstance(response.image, Image.Image):
    response.image.save("output.png")
```

## Basic Usage

### General Generation

```python
response = client.generate(
    model="p-image",
    input={"prompt": "A beautiful sunset over a calm ocean"},
    sync=True
)

# or batch
responses = client.generate_batch(
    requests=[
        {"model": "p-image", "input": {"prompt": "A beautiful sunset over a calm ocean"}},
        {"model": "p-image", "input": {"prompt": "A beautiful sunrise over a calm ocean"}},
    ],
    sync=True
)
```

### Text to Image

```python
response = client.generate_text_to_image(
    model="p-image",
    prompt="A beautiful sunset over a calm ocean",
    sync=True
)
```

### Image Editing

```python
response = client.generate_image_edit(
    model="p-image-edit",
    prompt="Edit the image to make it more beautiful",
    images=["path/to/image.png"],
    sync=True
)
```

### Text to Video

```python
response = client.generate_text_to_video(
    model="p-video",
    prompt="A beautiful sunset over a calm ocean",
    sync=True
)
```

## Async Usage

The client supports async operations for better performance when making multiple requests or integrating with async applications.

### General Generation (Async)

```python
import asyncio
from pruna_client import PrunaClient
from PIL import Image

async def main():
    client = PrunaClient(api_key="your_api_key")
    
    response = await client.agenerate(
        model="p-image",
        input={"prompt": "A beautiful sunset over a calm ocean"},
        sync=True
    )
    
    if isinstance(response.image, Image.Image):
        response.image.save("output.png")
    
    await client.aclose()

asyncio.run(main())

# or batch
responses = await client.agenerate_batch(
    requests=[
        {"model": "p-image", "input": {"prompt": "A beautiful sunset over a calm ocean"}},
        {"model": "p-image", "input": {"prompt": "A beautiful sunrise over a calm ocean"}},
    ],
    sync=True
)
```

## Running Tests

```bash
uv run pytest tests/integration/test_general.py -v
uv run pytest tests/integration/test_text_to_image.py -v
uv run pytest tests/integration/test_image_edit.py -v
uv run pytest tests/integration/test_text_to_video.py -v
uv run pytest tests/integration/test_video_edit.py -v
uv run pytest tests/integration/test_image_to_video.py -v
uv run pytest tests/integration/test_batch_generation.py -v
```

Tests require `PRUNA_API_KEY` environment variable to be set.
