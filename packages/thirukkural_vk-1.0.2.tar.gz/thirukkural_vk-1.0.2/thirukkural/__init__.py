from .api import (
    get_metadata,
    get_kurals,
    get_kural,
    search_by_adhigaram,
    search_by_paal,
    search_by_iyal,
)

__all__ = [
    "get_metadata",
    "get_kurals",
    "get_kural",
    "search_by_adhigaram",
    "search_by_paal",
    "search_by_iyal"
]
