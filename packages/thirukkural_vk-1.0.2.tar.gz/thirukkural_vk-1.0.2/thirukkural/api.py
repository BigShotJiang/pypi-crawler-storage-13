import json
import pathlib
from typing import List, Dict, Any

DATA_PATH = pathlib.Path(__file__).parent / "data.json"

with open(DATA_PATH, "r", encoding="utf-8") as f:
    _DB: Dict[str, Any] = json.load(f)

def get_metadata() -> Dict[str, Any]:
    """Return global metadata such as total kurals, paals, etc."""
    return _DB["thirukkural_metadata"]

def get_kurals() -> List[Dict[str, Any]]:
    """Return all 1330 kurals."""
    return _DB["kurals"]

def get_kural(number: int) -> Dict[str, Any]:
    """Return a single kural by number."""
    if number < 1 or number > 1330:
        raise ValueError("Kural number must be between 1 and 1330")
    return _DB["kurals"][number - 1]

def search_by_adhigaram(no: int) -> List[Dict[str, Any]]:
    return [k for k in _DB["kurals"] if k["adhigaram_number"] == no]

def search_by_paal(no: int) -> List[Dict[str, Any]]:
    return [k for k in _DB["kurals"] if k["paul_number"] == no]

def search_by_iyal(no: int) -> List[Dict[str, Any]]:
    return [k for k in _DB["kurals"] if k["iyal_number"] == no]
