#!/usr/bin/env python3
"""
Main entry point for the orchestra_server package when run as a module.
"""

from . import main

if __name__ == "__main__":
    main()