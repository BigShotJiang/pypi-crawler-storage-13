"""
Greb pipeline module.

Provides orchestrators, tools, and utilities for intelligent code search.
"""

from .base import (
    FileSpan,
    CandidateMatch,
    RankedResult,
    PipelineConfig,
    ExtractedKeywords,
    QueryRequest,
    QueryResponse,
)

from .orchestrator import PipelineOrchestrator, create_orchestrator
from .grep import GrepTool
from .glob import GlobTool
from .read import ReadTool
from .rerank import RerankTool

# Optional intelligent components
try:
    from .intelligent_orchestrator import IntelligentOrchestrator
    from .code_analyzer import FastCodeAnalyzer, CodeReference
    from .search_context import SearchContext

    __all__ = [
        # Base classes
        'FileSpan',
        'CandidateMatch',
        'RankedResult',
        'PipelineConfig',
        'ExtractedKeywords',
        'QueryRequest',
        'QueryResponse',
        # Orchestrators
        'PipelineOrchestrator',
        'IntelligentOrchestrator',
        'create_orchestrator',
        # Tools
        'GrepTool',
        'GlobTool',
        'ReadTool',
        'RerankTool',
        # Intelligent components
        'FastCodeAnalyzer',
        'CodeReference',
        'SearchContext',
    ]
except ImportError:
    # Intelligent components not available
    __all__ = [
        # Base classes
        'FileSpan',
        'CandidateMatch',
        'RankedResult',
        'PipelineConfig',
        'ExtractedKeywords',
        'QueryRequest',
        'QueryResponse',
        # Orchestrators
        'PipelineOrchestrator',
        'create_orchestrator',
        # Tools
        'GrepTool',
        'GlobTool',
        'ReadTool',
        'RerankTool',
    ]
