"""
OpenTelemetry 호환 ID 생성 모듈
- trace_id: 32자 hex 문자열 (16 bytes 랜덤)
- span_id: 16자 hex 문자열 (8 bytes 랜덤)
"""

import os
import re


def generate_trace_id() -> str:
    """
    Trace ID를 생성함 (32자 hex 문자열)

    역할: 전체 요청 추적을 식별하는 고유 ID를 생성함
    사용: HTTP 요청마다 새로운 trace_id가 생성되며, 해당 요청 내의 모든 span이 이 ID를 공유함

    Returns:
        32자 16진수 문자열
    """
    return os.urandom(16).hex()


def generate_span_id() -> str:
    """
    Span ID를 생성함 (16자 hex 문자열)

    역할: 개별 작업(HTTP 요청, API 호출, Bedrock 호출 등)을 식별하는 고유 ID를 생성함
    사용: 각 span(작업 단위)마다 새로운 span_id가 생성됨

    Returns:
        16자 16진수 문자열
    """
    return os.urandom(8).hex()


def is_valid_trace_id(trace_id: str) -> bool:
    """
    문자열이 유효한 Trace ID인지 검증함

    역할: Trace ID가 OpenTelemetry 표준 형식(32자 hex)에 맞는지 확인함

    Args:
        trace_id: 검증할 Trace ID

    Returns:
        유효하면 True, 아니면 False
    """
    return bool(re.match(r'^[0-9a-f]{32}$', trace_id))


def is_valid_span_id(span_id: str) -> bool:
    """
    문자열이 유효한 Span ID인지 검증함

    역할: Span ID가 OpenTelemetry 표준 형식(16자 hex)에 맞는지 확인함

    Args:
        span_id: 검증할 Span ID

    Returns:
        유효하면 True, 아니면 False
    """
    return bool(re.match(r'^[0-9a-f]{16}$', span_id))
