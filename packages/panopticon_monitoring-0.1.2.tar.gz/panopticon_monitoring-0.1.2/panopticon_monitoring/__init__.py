"""
@panopticon/fastapi-monitoring-sdk

간편한 FastAPI 모니터링 SDK (로그 및 분산 추적)

사용법:
```python
from fastapi import FastAPI
from panopticon_monitoring import MonitoringSDK

app = FastAPI()

MonitoringSDK.init(app, {
    'api_key': 'your-api-key',
    'endpoint': 'https://producer.woongno-monitoring.com',
    'service_name': 'llm-service',
    'environment': 'production'
})
```
"""

# SDK 메인 클래스 export
from .monitoring_sdk import MonitoringSDK

# 타입 정의 export
from .types.interfaces import (
    MonitoringConfig,
    LogEntry,
    SpanEntry,
    DataEntry,
    TraceContext,
    SpanOptions,
    ActiveSpan
)

# ID 생성 함수 export
from .tracing.id_generator import (
    generate_trace_id,
    generate_span_id,
    is_valid_trace_id,
    is_valid_span_id
)

# Trace Context 관리 함수 export
from .tracing.trace_context import (
    get_trace_context,
    set_trace_context,
    create_root_context,
    create_child_context,
    get_current_trace_id,
    get_current_span_id,
    get_current_parent_span_id,
    is_in_traced_context
)

# 고급 사용을 위한 collector 클래스 export
from .transport.batch_sender import BatchSender
from .tracing.http_tracer import HttpTracerMiddleware
from .collectors.log_collector import LogCollectorHandler
from .collectors.http_client_collector import HttpClientCollector
from .collectors.bedrock_collector import BedrockCollector

__version__ = '0.1.0'

__all__ = [
    # 메인 클래스
    'MonitoringSDK',

    # 타입
    'MonitoringConfig',
    'LogEntry',
    'SpanEntry',
    'DataEntry',
    'TraceContext',
    'SpanOptions',
    'ActiveSpan',

    # ID 생성
    'generate_trace_id',
    'generate_span_id',
    'is_valid_trace_id',
    'is_valid_span_id',

    # Trace Context
    'get_trace_context',
    'set_trace_context',
    'create_root_context',
    'create_child_context',
    'get_current_trace_id',
    'get_current_span_id',
    'get_current_parent_span_id',
    'is_in_traced_context',

    # Collectors
    'BatchSender',
    'HttpTracerMiddleware',
    'LogCollectorHandler',
    'HttpClientCollector',
    'BedrockCollector',
]
