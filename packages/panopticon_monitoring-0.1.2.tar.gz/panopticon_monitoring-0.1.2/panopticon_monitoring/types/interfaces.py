"""
FastAPI Monitoring SDK 타입 정의
로그 및 분산 추적을 지원함 (OpenTelemetry 호환)
"""

from typing import TypedDict, Literal, Optional, Union
from dataclasses import dataclass


class MonitoringConfig(TypedDict, total=False):
    """SDK 설정 인터페이스"""

    # 필수 설정
    api_key: str
    """Producer 서버 인증을 위한 API 키"""

    service_name: str
    """서비스 이름 식별자"""

    # 선택 설정
    endpoint: Optional[str]
    """Producer 서버 엔드포인트 URL (예: https://producer.woongno-monitoring.com)"""

    log_endpoint: Optional[str]
    """Log 전송 엔드포인트 URL (예: https://producer.woongno-monitoring.com/sdk/logs)"""

    trace_endpoint: Optional[str]
    """Trace 전송 엔드포인트 URL (예: https://producer.woongno-monitoring.com/sdk/traces)"""

    environment: Optional[str]
    """환경 설정 (예: production, staging, development)"""

    batch_size: Optional[int]
    """데이터 전송을 위한 배치 크기 (기본값: 100)"""

    flush_interval: Optional[int]
    """데이터 플러시 간격 (초 단위, 기본값: 5)"""

    enable_log_tracking: Optional[bool]
    """로그 추적 활성화 여부 (기본값: True)"""

    enable_http_tracking: Optional[bool]
    """HTTP 요청 추적 활성화 여부 (기본값: True)"""

    enable_http_client_tracking: Optional[bool]
    """외부 HTTP 클라이언트 추적 활성화 여부 (기본값: True)"""

    enable_bedrock_tracking: Optional[bool]
    """Bedrock API 호출 추적 활성화 여부 (기본값: True)"""


class LogEntry(TypedDict, total=False):
    """로그 엔트리 인터페이스"""

    type: Literal['log']
    timestamp: str
    service_name: str
    environment: str
    level: str
    message: str
    context: Optional[str]
    trace: Optional[str]
    trace_id: Optional[str]
    """Trace ID - 트레이스 도중 발생한 로그인 경우 상속됨, 아니면 None"""


class SpanEntry(TypedDict, total=False):
    """분산 추적을 위한 Span 엔트리 인터페이스"""

    type: Literal['span']
    timestamp: str
    service_name: str
    environment: str

    trace_id: str
    """Trace ID (32자 hex 문자열) - 전체 요청 추적을 식별함"""

    span_id: str
    """Span ID (16자 hex 문자열) - 특정 span을 식별함"""

    parent_span_id: Optional[str]
    """Parent Span ID (root span의 경우 None)"""

    name: str
    """Span 이름 (예: "POST /payments", "SELECT users")"""

    kind: Literal['SERVER', 'CLIENT']
    """Span 종류"""

    duration_ms: float
    """소요 시간 (밀리초 단위)"""

    status: Literal['OK', 'ERROR']
    """상태"""

    # HTTP span 속성들
    http_method: Optional[str]
    http_path: Optional[str]
    http_url: Optional[str]
    http_status_code: Optional[int]

    # Database span 속성들
    db_system: Optional[str]
    db_statement: Optional[str]
    db_operation: Optional[str]

    # Bedrock span 속성들
    bedrock_model_id: Optional[str]
    bedrock_operation: Optional[str]
    bedrock_input_tokens: Optional[int]
    bedrock_output_tokens: Optional[int]


# 통합 데이터 엔트리 타입
DataEntry = Union[LogEntry, SpanEntry]


@dataclass
class TraceContext:
    """ContextVar에 저장되는 Trace Context 데이터클래스"""

    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None


@dataclass
class SpanOptions:
    """새 span 생성을 위한 옵션 데이터클래스"""

    name: str
    kind: Literal['SERVER', 'CLIENT']
    attributes: Optional[dict] = None


@dataclass
class ActiveSpan:
    """활성 Span 추적 데이터클래스"""

    trace_id: str
    span_id: str
    parent_span_id: Optional[str]
    name: str
    kind: Literal['SERVER', 'CLIENT']
    start_time: float
    attributes: dict
