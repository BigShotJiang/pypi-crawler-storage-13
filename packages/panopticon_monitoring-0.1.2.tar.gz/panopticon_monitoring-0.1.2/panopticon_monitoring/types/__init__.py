"""Type definitions for monitoring SDK."""
