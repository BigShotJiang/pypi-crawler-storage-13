"""Collectors for logs, HTTP clients, and Bedrock calls."""
