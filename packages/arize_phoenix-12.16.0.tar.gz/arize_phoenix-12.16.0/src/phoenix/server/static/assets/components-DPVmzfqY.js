import{r as g,j as e,u as Ot,a as xn,e as va,s as nt,b as at,c as Wn,d as Lt,f as H1,g as cn,h as j1,i as Z1,k as St,$ as U1,l as G1,m as Vn,p as Fa,n as Pn,R as vn,o as F,q as $t,t as Qn,v as W1,C as Sa,w as Q1,x as q1,L as wi,y as xi,z as Ti,A as qe,B as Cn,D as ie,E as X1,F as An,G as Y1,H as J1,I as en,J as mn,K as J,M as es,N as he,O as Rn,P as Jn,Q as Ii,S as Hn,T as Da,U as p,V as s,W as zi,X as j,Y as Ai,Z as $,_ as Mi,a0 as Fi,a1 as ns,a2 as Ne,a3 as as,a4 as ts,a5 as nn,a6 as ls,a7 as B,a8 as Ze,a9 as P,aa as W,ab as ae,ac as Di,ad as Ei,ae as is,af as Ki,ag as rs,ah as _i,ai as os,aj as ss,ak as Vi,al as cs,am as ds,an as us,ao as Pi,ap as ms,aq as gs,ar as ps,as as Ri,at as we,au as hs,av as fs,aw as Ni,ax as Oe,ay as wt,az as xt,aA as Z,aB as an,aC as Fl,aD as Oi,aE as $i,aF as bs,aG as ys,aH as vs,aI as Cs,aJ as ks,aK as Ls,aL as Bi,aM as Ss,aN as ws,aO as xs,aP as Ts,aQ as Is,aR as zs,aS as As,aT as Ms,aU as Fs,aV as Bt,aW as se,aX as Ds,aY as Es,aZ as Hi,a_ as Ks,a$ as _s,b0 as Vs,b1 as Ps,b2 as Rs,b3 as Ns,b4 as Os,b5 as $s,b6 as Ge,b7 as ji,b8 as Dl,b9 as Bs,ba as Zi,bb as be,bc as Hs,bd as oa,be as js,bf as El,bg as Zs,bh as Us,bi as Gs,bj as Nn,bk as Ws,bl as Qs,bm as qs,bn as Xs,bo as te,bp as Ys,bq as Ht,br as ea,bs as jt,bt as Ui,bu as Js,bv as ec,bw as Ea,bx as nc,by as ac,bz as tc,bA as lc,bB as ic,bC as Gi,bD as Tt,bE as rc,bF as oc,bG as sc,bH as cc,bI as dc,bJ as Kl,bK as uc,bL as tt,bM as mc,bN as gc,bO as pc,bP as hc,bQ as fc,bR as bc,bS as yc,bT as vc,bU as Cc,bV as kc}from"./vendor-lqxaAnN2.js";import{a as _l,R as Lc,b as Sc,c as wc,m as xc,T as Tc,d as Ic,A as zc,S as Wi,e as Ac,f as Mc,g as Fc,u as Dc}from"./pages-BmLRjwv-.js";import{L as Qi,a as qi,j as Xi,E as Zt,k as Yi,d as Ji,l as It,b as Ec,c as Kc,e as _c,h as Vc,f as Pc,s as Rc,g as sa,i as ca,R as da,m as er,n as Nc,p as Oc,o as $c}from"./vendor-codemirror-Ci4D0cBP.js";import{V as Bc}from"./vendor-three-BtCyLs1w.js";const nr=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"clusters"},a={defaultValue:null,kind:"LocalArgument",name:"dataQualityMetricColumnName"},t={defaultValue:null,kind:"LocalArgument",name:"fetchDataQualityMetric"},l={defaultValue:null,kind:"LocalArgument",name:"fetchPerformanceMetric"},i={defaultValue:null,kind:"LocalArgument",name:"performanceMetric"},r=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"referenceValue",storageKey:null}],o=[{alias:null,args:[{kind:"Variable",name:"clusters",variableName:"clusters"}],concreteType:"Cluster",kind:"LinkedField",name:"clusters",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"eventIds",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"driftRatio",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"primaryToCorpusRatio",storageKey:null},{condition:"fetchDataQualityMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"columnName",variableName:"dataQualityMetricColumnName"},{kind:"Literal",name:"metric",value:"mean"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"dataQualityMetric",plural:!1,selections:r,storageKey:null}]},{condition:"fetchPerformanceMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"metric",variableName:"performanceMetric"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"performanceMetric",plural:!1,selections:r,storageKey:null}]}],storageKey:null}];return{fragment:{argumentDefinitions:[n,a,t,l,i],kind:"Fragment",metadata:null,name:"pointCloudStore_clusterMetricsQuery",selections:o,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,t,a,l,i],kind:"Operation",name:"pointCloudStore_clusterMetricsQuery",selections:o},params:{cacheID:"86666967012812887ac0a0149d2d2535",id:null,metadata:{},name:"pointCloudStore_clusterMetricsQuery",operationKind:"query",text:`query pointCloudStore_clusterMetricsQuery(
  $clusters: [ClusterInput!]!
  $fetchDataQualityMetric: Boolean!
  $dataQualityMetricColumnName: String
  $fetchPerformanceMetric: Boolean!
  $performanceMetric: PerformanceMetric!
) {
  clusters(clusters: $clusters) {
    id
    eventIds
    driftRatio
    primaryToCorpusRatio
    dataQualityMetric(metric: {metric: mean, columnName: $dataQualityMetricColumnName}) @include(if: $fetchDataQualityMetric) {
      primaryValue
      referenceValue
    }
    performanceMetric(metric: {metric: $performanceMetric}) @include(if: $fetchPerformanceMetric) {
      primaryValue
      referenceValue
    }
  }
}
`}}})();nr.hash="dbfc8c02ba1ec4f2ba0317b371854d9b";const ar=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"clusterMinSamples"},a={defaultValue:null,kind:"LocalArgument",name:"clusterSelectionEpsilon"},t={defaultValue:null,kind:"LocalArgument",name:"coordinates"},l={defaultValue:null,kind:"LocalArgument",name:"dataQualityMetricColumnName"},i={defaultValue:null,kind:"LocalArgument",name:"eventIds"},r={defaultValue:null,kind:"LocalArgument",name:"fetchDataQualityMetric"},o={defaultValue:null,kind:"LocalArgument",name:"fetchPerformanceMetric"},c={defaultValue:null,kind:"LocalArgument",name:"minClusterSize"},d={defaultValue:null,kind:"LocalArgument",name:"performanceMetric"},u=[{alias:null,args:null,kind:"ScalarField",name:"primaryValue",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"referenceValue",storageKey:null}],m=[{alias:null,args:[{kind:"Variable",name:"clusterMinSamples",variableName:"clusterMinSamples"},{kind:"Variable",name:"clusterSelectionEpsilon",variableName:"clusterSelectionEpsilon"},{kind:"Variable",name:"coordinates3d",variableName:"coordinates"},{kind:"Variable",name:"eventIds",variableName:"eventIds"},{kind:"Variable",name:"minClusterSize",variableName:"minClusterSize"}],concreteType:"Cluster",kind:"LinkedField",name:"hdbscanClustering",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"eventIds",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"driftRatio",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"primaryToCorpusRatio",storageKey:null},{condition:"fetchDataQualityMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"columnName",variableName:"dataQualityMetricColumnName"},{kind:"Literal",name:"metric",value:"mean"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"dataQualityMetric",plural:!1,selections:u,storageKey:null}]},{condition:"fetchPerformanceMetric",kind:"Condition",passingValue:!0,selections:[{alias:null,args:[{fields:[{kind:"Variable",name:"metric",variableName:"performanceMetric"}],kind:"ObjectValue",name:"metric"}],concreteType:"DatasetValues",kind:"LinkedField",name:"performanceMetric",plural:!1,selections:u,storageKey:null}]}],storageKey:null}];return{fragment:{argumentDefinitions:[n,a,t,l,i,r,o,c,d],kind:"Fragment",metadata:null,name:"pointCloudStore_clustersQuery",selections:m,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[i,t,c,n,a,r,l,o,d],kind:"Operation",name:"pointCloudStore_clustersQuery",selections:m},params:{cacheID:"a1a02d970d255935edfcdd797e4ca80d",id:null,metadata:{},name:"pointCloudStore_clustersQuery",operationKind:"query",text:`query pointCloudStore_clustersQuery(
  $eventIds: [ID!]!
  $coordinates: [InputCoordinate3D!]!
  $minClusterSize: Int!
  $clusterMinSamples: Int!
  $clusterSelectionEpsilon: Float!
  $fetchDataQualityMetric: Boolean!
  $dataQualityMetricColumnName: String
  $fetchPerformanceMetric: Boolean!
  $performanceMetric: PerformanceMetric!
) {
  hdbscanClustering(eventIds: $eventIds, coordinates3d: $coordinates, minClusterSize: $minClusterSize, clusterMinSamples: $clusterMinSamples, clusterSelectionEpsilon: $clusterSelectionEpsilon) {
    id
    eventIds
    driftRatio
    primaryToCorpusRatio
    dataQualityMetric(metric: {metric: mean, columnName: $dataQualityMetricColumnName}) @include(if: $fetchDataQualityMetric) {
      primaryValue
      referenceValue
    }
    performanceMetric(metric: {metric: $performanceMetric}) @include(if: $fetchPerformanceMetric) {
      primaryValue
      referenceValue
    }
  }
}
`}}})();ar.hash="b26f299a862a3bc4f5487ace49db1d43";const tr=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"corpusEventIds"},a={defaultValue:null,kind:"LocalArgument",name:"primaryEventIds"},t={defaultValue:null,kind:"LocalArgument",name:"referenceEventIds"},l=[{kind:"Variable",name:"eventIds",variableName:"primaryEventIds"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},o={alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},c={alias:null,args:null,kind:"ScalarField",name:"value",storageKey:null},d={alias:null,args:null,concreteType:"EventMetadata",kind:"LinkedField",name:"eventMetadata",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"predictionId",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"predictionScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualLabel",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"actualScore",storageKey:null}],storageKey:null},u={alias:null,args:null,concreteType:"PromptResponse",kind:"LinkedField",name:"promptAndResponse",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"prompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"response",storageKey:null}],storageKey:null},m={alias:null,args:null,kind:"ScalarField",name:"documentText",storageKey:null},h=[i,{alias:null,args:null,concreteType:"DimensionWithValue",kind:"LinkedField",name:"dimensions",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"dimension",plural:!1,selections:[r,o],storageKey:null},c],storageKey:null},d,u,m],b={alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"referenceInferences",plural:!1,selections:[{alias:null,args:[{kind:"Variable",name:"eventIds",variableName:"referenceEventIds"}],concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:[i,{alias:null,args:null,concreteType:"DimensionWithValue",kind:"LinkedField",name:"dimensions",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"dimension",plural:!1,selections:[i,r,o],storageKey:null},c],storageKey:null},d,u,m],storageKey:null}],storageKey:null},f=[{kind:"Variable",name:"eventIds",variableName:"corpusEventIds"}],y=[i,{alias:null,args:null,concreteType:"DimensionWithValue",kind:"LinkedField",name:"dimensions",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"dimension",plural:!1,selections:[r,o,i],storageKey:null},c],storageKey:null},d,u,m];return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"pointCloudStore_eventsQuery",selections:[{alias:null,args:null,concreteType:"InferenceModel",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"primaryInferences",plural:!1,selections:[{alias:null,args:l,concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:h,storageKey:null}],storageKey:null},b,{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"corpusInferences",plural:!1,selections:[{alias:null,args:f,concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:h,storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,t,n],kind:"Operation",name:"pointCloudStore_eventsQuery",selections:[{alias:null,args:null,concreteType:"InferenceModel",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"primaryInferences",plural:!1,selections:[{alias:null,args:l,concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:y,storageKey:null}],storageKey:null},b,{alias:null,args:null,concreteType:"Inferences",kind:"LinkedField",name:"corpusInferences",plural:!1,selections:[{alias:null,args:f,concreteType:"Event",kind:"LinkedField",name:"events",plural:!0,selections:y,storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"bcac76c653bed7d4f922f175d03a3408",id:null,metadata:{},name:"pointCloudStore_eventsQuery",operationKind:"query",text:`query pointCloudStore_eventsQuery(
  $primaryEventIds: [ID!]!
  $referenceEventIds: [ID!]!
  $corpusEventIds: [ID!]!
) {
  model {
    primaryInferences {
      events(eventIds: $primaryEventIds) {
        id
        dimensions {
          dimension {
            name
            type
            id
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
    referenceInferences {
      events(eventIds: $referenceEventIds) {
        id
        dimensions {
          dimension {
            id
            name
            type
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
    corpusInferences {
      events(eventIds: $corpusEventIds) {
        id
        dimensions {
          dimension {
            name
            type
            id
          }
          value
        }
        eventMetadata {
          predictionId
          predictionLabel
          predictionScore
          actualLabel
          actualScore
        }
        promptAndResponse {
          prompt
          response
        }
        documentText
      }
    }
  }
}
`}}})();tr.hash="00a957322684d9186fdf16d33a75b931";const lr=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"getDimensionCategories"},a={defaultValue:null,kind:"LocalArgument",name:"getDimensionMinMax"},t={defaultValue:null,kind:"LocalArgument",name:"id"},l=[{kind:"Variable",name:"id",variableName:"id"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={condition:"getDimensionMinMax",kind:"Condition",passingValue:!0,selections:[{alias:"min",args:[{kind:"Literal",name:"metric",value:"min"}],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(metric:"min")'},{alias:"max",args:[{kind:"Literal",name:"metric",value:"max"}],kind:"ScalarField",name:"dataQualityMetric",storageKey:'dataQualityMetric(metric:"max")'}]},o={condition:"getDimensionCategories",kind:"Condition",passingValue:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"categories",storageKey:null}]};return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"pointCloudStore_dimensionMetadataQuery",selections:[{kind:"RequiredField",field:{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[i,r,o],type:"Dimension",abstractKey:null}],storageKey:null},action:"THROW"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,a,n],kind:"Operation",name:"pointCloudStore_dimensionMetadataQuery",selections:[{alias:"dimension",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},i,{kind:"InlineFragment",selections:[r,o],type:"Dimension",abstractKey:null}],storageKey:null}]},params:{cacheID:"cc8c5b634ad1f06e595b1542b2f9830b",id:null,metadata:{},name:"pointCloudStore_dimensionMetadataQuery",operationKind:"query",text:`query pointCloudStore_dimensionMetadataQuery(
  $id: ID!
  $getDimensionMinMax: Boolean!
  $getDimensionCategories: Boolean!
) {
  dimension: node(id: $id) {
    __typename
    ... on Dimension {
      id
      min: dataQualityMetric(metric: min) @include(if: $getDimensionMinMax)
      max: dataQualityMetric(metric: max) @include(if: $getDimensionMinMax)
      categories @include(if: $getDimensionCategories)
    }
    id
  }
}
`}}})();lr.hash="2d61766d79c27d5fe1d17dba940dfe52";const Hc=30,lt=5,it=100,jc=0,rt=0,ot=.99,Zc=500,Vl=300,Pl=1e5,Uc=10,Rl=1,Gc=2,Wc=1,Qc=0;var Y=(n=>(n.inferences="inferences",n.correctness="correctness",n.dimension="dimension",n))(Y||{}),Kn=(n=>(n.list="list",n.gallery="gallery",n))(Kn||{}),Mn=(n=>(n.small="small",n.medium="medium",n.large="large",n))(Mn||{}),ne=(n=>(n.primary="primary",n.reference="reference",n.corpus="corpus",n))(ne||{}),pe=(n=>(n.correct="correct",n.incorrect="incorrect",n.unknown="unknown",n))(pe||{});const qc=["#05fbff","#cb8afd"],Xc=["#00add0","#4500d9"],Ye="#a5a5a5",In=Ye;var _e=(n=>(n.primary="primary",n.reference="reference",n.corpus="corpus",n))(_e||{});function N(n){throw new Error("Unreachable")}function Ut(n){return typeof n=="number"||n===null}function Yc(n){return typeof n=="string"||n===null}function Jc(n){return Yc(n)||n===void 0}function ed(n){return Array.isArray(n)?n.every(a=>typeof a=="string"):!1}function Le(n){return typeof n=="object"&&n!==null}function im(n){return Le(n)&&Object.keys(n).every(a=>typeof a=="string")}const nd=()=>n=>n,Gt=g.createContext(null);function Ka(){const n=g.useContext(Gt);if(n===null)throw new Error("useInferences must be used within a InferencesProvider");return n}function rm(n){return e(Gt.Provider,{value:{primaryInferences:n.primaryInferences,referenceInferences:n.referenceInferences,corpusInferences:n.corpusInferences,getInferencesNameByRole:a=>{var t,l;switch(a){case _e.primary:return n.primaryInferences.name;case _e.reference:return((t=n.referenceInferences)==null?void 0:t.name)??"reference";case _e.corpus:return((l=n.corpusInferences)==null?void 0:l.name)??"corpus";default:N()}}},children:n.children})}const Wt=g.createContext(null);function om({children:n,...a}){const[t]=g.useState(()=>Td(a));return e(Wt.Provider,{value:t,children:n})}function E(n,a){const t=g.useContext(Wt);if(!t)throw new Error("Missing PointCloudContext.Provider in the tree");return Ot(t,n,a)}var re=(n=>(n.last_hour="Last Hour",n.last_day="Last Day",n.last_week="Last Week",n.last_month="Last Month",n.last_3_months="Last 3 Months",n.first_hour="First Hour",n.first_day="First Day",n.first_week="First Week",n.first_month="First Month",n.all="All",n))(re||{});const ir=g.createContext(null);function ad(){const n=g.useContext(ir);if(n===null)throw new Error("useTimeRange must be used within a TimeRangeProvider");return n}function td(n,a){return g.useMemo(()=>{switch(n){case"Last Hour":{const l=xn(Z1(a.end),{roundingMethod:"ceil"});return{start:St(l,1),end:l}}case"Last Day":{const l=xn(j1(a.end),{roundingMethod:"ceil"});return{start:cn(l,1),end:l}}case"Last Week":{const l=xn(va(a.end),{roundingMethod:"ceil"});return{start:cn(l,7),end:l}}case"Last Month":{const l=xn(va(a.end),{roundingMethod:"ceil"});return{start:cn(l,30),end:l}}case"Last 3 Months":{const l=xn(va(a.end),{roundingMethod:"ceil"});return{start:cn(l,90),end:l}}case"First Hour":{const l=Lt(a.start);return{start:l,end:H1(l,1)}}case"First Day":{const l=Wn(a.start);return{start:l,end:at(l,1)}}case"First Week":{const l=nt(a.start);return{start:l,end:at(l,7)}}case"First Month":{const l=nt(a.start);return{start:l,end:at(l,30)}}case"All":{const l=xn(va(a.end),{roundingMethod:"floor"});return{start:nt(a.start),end:l}}default:N()}},[n,a])}function sm(n){const[a,t]=g.useState("Last Month"),l=td(a,n.timeRangeBounds),i=g.useCallback(r=>{g.startTransition(()=>{t(r)})},[]);return e(ir.Provider,{value:{timeRange:l,timePreset:a,setTimePreset:i},children:n.children})}const rr=5e3,Fn=new U1({wrapUpdate(n){"startViewTransition"in document?document==null||document.startViewTransition(()=>{G1.flushSync(n)}):n()}}),_a=()=>g.useCallback(({expireMs:n=rr,...a})=>Fn.add({...a,variant:"success"},n===null?void 0:{timeout:n}),[]),Va=()=>g.useCallback(({expireMs:n=rr,...a})=>Fn.add({...a,variant:"error"},n===null?void 0:{timeout:n}),[]);function or(n){return n==="light"||n==="dark"||n==="system"}const Qt="arize-phoenix-theme",sr="dark",cr="(prefers-color-scheme: dark)";function ld(){switch(localStorage.getItem(Qt)){case"light":return"light";case"dark":return"dark";case"system":return zt();default:return sr}}function id(){const n=localStorage.getItem(Qt);return or(n)?n:sr}function zt(){return window.matchMedia(cr).matches?"dark":"light"}const qt=g.createContext(null);function de(){const n=g.useContext(qt);if(n===null)throw new Error("useTheme must be used within a ThemeProvider");return n}function cm(n){const[a,t]=g.useState(()=>n.themeMode||id()),l=g.useCallback(c=>{localStorage.setItem(Qt,c),t(c)},[]),[i,r]=g.useState(zt),o=g.useMemo(()=>a==="system"?i:a,[a,i]);return g.useEffect(()=>{const c=window.matchMedia(cr),d=()=>{r(zt())};return c.addEventListener("change",d),()=>{c.removeEventListener("change",d)}},[]),g.useEffect(()=>{n.themeMode&&t(n.themeMode)},[n.themeMode,l]),g.useEffect(()=>(document.body.classList.add(`ac-theme--${o}`),document.body.classList.add("ac-theme"),()=>{document.body.classList.remove(`ac-theme--${o}`),document.body.classList.remove("ac-theme")}),[o]),e(qt.Provider,{value:{theme:o,systemTheme:i,themeMode:a,setThemeMode:l},children:n.children})}const dr=g.createContext({size:"M"});function Pa({size:n="M",children:a}){return e(dr.Provider,{value:{size:n},children:a})}function Xt(){return g.useContext(dr).size}const rd=n=>`arize-phoenix-project-${n}`;function od({projectId:n}){return{state:Vn()(Fa(Pn(t=>({defaultTab:"spans",setDefaultTab:l=>{t({defaultTab:l},!1,{type:"setDefaultTab"})},treatOrphansAsRoots:!1,setTreatOrphansAsRoots:l=>{t({treatOrphansAsRoots:l},!1,{type:"setTreatOrphansAsRoots"})}})),{name:rd(n)}))}}const ur=g.createContext(null);function dm({children:n,projectId:a}){const[t]=g.useState(()=>od({projectId:a}));return e(ur.Provider,{value:t,children:n})}function um(n,a){const t=g.useContext(ur);if(!t)throw new Error("Missing ProjectContext.Provider in the tree");return Ot(t.state,n,a)}const mr=Intl.DateTimeFormat().resolvedOptions();let Tn=[];function Xe(){return mr.locale}function gr(){return mr.timeZone}function sd(){return Tn.length===0&&(Tn=[...Intl.supportedValuesOf("timeZone")],Tn.includes("UTC")||(Tn=["UTC",...Tn])),Object.freeze([...Tn])}const cd=n=>{const a=t=>({markdownDisplayMode:"text",setMarkdownDisplayMode:l=>{t({markdownDisplayMode:l},!1,{type:"setMarkdownDisplayMode"})},traceStreamingEnabled:!0,setTraceStreamingEnabled:l=>{t({traceStreamingEnabled:l},!1,{type:"setTraceStreamingEnabled"})},lastNTimeRangeKey:"7d",setLastNTimeRangeKey:l=>{t({lastNTimeRangeKey:l})},projectsAutoRefreshEnabled:!0,setProjectAutoRefreshEnabled:l=>{t({projectsAutoRefreshEnabled:l},!1,{type:"setProjectAutoRefreshEnabled"})},showMetricsInTraceTree:!0,setShowMetricsInTraceTree:l=>{t({showMetricsInTraceTree:l},!1,{type:"setShowMetricsInTraceTree"})},modelConfigByProvider:{},setModelConfigForProvider:({provider:l,modelConfig:i})=>{t(r=>({modelConfigByProvider:{...r.modelConfigByProvider,[l]:i}}),!1,{type:"setModelConfigForProvider"})},playgroundStreamingEnabled:!0,setPlaygroundStreamingEnabled:l=>{t({playgroundStreamingEnabled:l},!1,{type:"setPlaygroundStreamingEnabled"})},isAnnotatingSpans:!0,setIsAnnotatingSpans:l=>{t({isAnnotatingSpans:l},!1,{type:"setIsAnnotatingSpans"})},projectViewMode:"grid",setProjectViewMode:l=>{t({projectViewMode:l},!1,{type:"setProjectViewMode"})},projectSortOrder:{column:"endTime",direction:"desc"},setProjectSortOrder:l=>{t({projectSortOrder:l},!1,{type:"setProjectSortOrder"})},isSideNavExpanded:!0,setIsSideNavExpanded:l=>{t({isSideNavExpanded:l},!1,{type:"setIsSideNavExpanded"})},setDisplayTimezone:l=>{if(l&&!sd().includes(l))throw new Error(`Invalid timezone: ${l}`);t({displayTimezone:l},!1,{type:"setDisplayTimezone"})},...n});return Vn()(Fa(Pn(a,{name:"preferencesStore"}),{name:"arize-phoenix-preferences"}))},pr=g.createContext(null);function mm({children:n,...a}){const[t]=g.useState(()=>cd(a));return e(pr.Provider,{value:t,children:n})}function Me(n,a){const t=g.useContext(pr);if(!t)throw new Error("Missing PreferencesContext.Provider in the tree");return Ot(t,n,a)}const hr=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null};return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"ViewerContextRefetchQuery",selections:[{args:null,kind:"FragmentSpread",name:"ViewerContext_viewer"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"ViewerContextRefetchQuery",selections:[{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"viewer",plural:!1,selections:[n,{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"isManagementUser",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[a,n],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{alias:null,args:null,concreteType:"UserApiKey",kind:"LinkedField",name:"apiKeys",plural:!0,selections:[n,a,{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"expiresAt",storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"79221da09cbb1334cb0c446af434f607",id:null,metadata:{},name:"ViewerContextRefetchQuery",operationKind:"query",text:`query ViewerContextRefetchQuery {
  ...ViewerContext_viewer
}

fragment APIKeysTableFragment on User {
  apiKeys {
    id
    name
    description
    createdAt
    expiresAt
  }
  id
}

fragment ViewerContext_viewer on Query {
  viewer {
    id
    username
    email
    profilePictureUrl
    isManagementUser
    role {
      name
      id
    }
    authMethod
    ...APIKeysTableFragment
  }
}
`}}})();hr.hash="d85505e5f9dffd2a1c791f8e0007ab61";const fr={argumentDefinitions:[],kind:"Fragment",metadata:{refetch:{connection:null,fragmentPathInResult:[],operation:hr}},name:"ViewerContext_viewer",selections:[{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"viewer",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"email",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"isManagementUser",storageKey:null},{alias:null,args:null,concreteType:"UserRole",kind:"LinkedField",name:"role",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"authMethod",storageKey:null},{args:null,kind:"FragmentSpread",name:"APIKeysTableFragment"}],storageKey:null}],type:"Query",abstractKey:null};fr.hash="d85505e5f9dffd2a1c791f8e0007ab61";const br=vn.createContext({viewer:null,refetchViewer:()=>{}});function kn(){const n=vn.useContext(br);if(n==null)throw new Error("useViewer must be used within a ViewerProvider");return n}function dd(){const{viewer:n}=kn();return!(n&&n.role.name==="VIEWER")}function ud(){var a;const{viewer:n}=kn();return!(n&&((a=n==null?void 0:n.role)==null?void 0:a.name)!=="ADMIN")}function gm({query:n,children:a}){const[t,l]=F.useRefetchableFragment(fr,n),i=g.useCallback(()=>{g.startTransition(()=>{l({},{fetchPolicy:"network-only"})})},[l]);return e(br.Provider,{value:{viewer:t.viewer,refetchViewer:i},children:a})}function md(n){return n.endsWith("/")?n.slice(0,-1):n}const gd=md(window.Config.basename),Ln=`${window.location.protocol}//${window.location.host}${gd}`,pm=window.Config.platformVersion,na="returnUrl";function Nl(n,a){const t=new URL(n,window.location.origin);return a.forEach((l,i)=>{t.searchParams.append(i,l)}),t.pathname+t.search}function yr(){const n=window.Config.basename,a=n==null||n===""||n==="/",t=n!=null&&n.startsWith("/")&&!n.endsWith("/");if(!(a||t))throw new Error(`Invalid basename: ${n}`);const l=window.location.pathname,i=window.location.origin,r=new URLSearchParams(window.location.search);if(a){const o=new URL("/login",i);return o.searchParams.set(na,Nl(l,r)),o.pathname+o.search}if(l.startsWith(n)){const o=l.slice(n.length);if(o===""||o.startsWith("/")){const d=new URL(n+"/login",i);return d.searchParams.set(na,Nl(o,r)),d.pathname+d.search}}return n+"/login"}function pd(n){const a=window.Config.basename,t=a==null||a===""||a==="/",l=a!=null&&a.startsWith("/")&&!a.endsWith("/");if(!(t||l))throw new Error(`Invalid basename: ${a}`);return t?n:a+n}const hm=({path:n,searchParams:a})=>{const l=new URL(window.location.href).searchParams.get(na),i=new URLSearchParams(a||{});l&&i.set(na,l);const r=i.toString();return`${n}${r?`?${r}`:""}`},hd=n=>!(typeof n!="string"||!n.startsWith("/")||n.replace(/\\/g,"/").startsWith("//")),fd=n=>hd(n)?n:"/",fm=()=>{const n=new URL(window.location.href);return fd(n.searchParams.get(na))},bd=Ln+"/auth/refresh";class Ol extends Error{constructor(){super("Unauthorized")}}async function yd(n,a){try{return await fetch(n,a).then(t=>{if(t.status===401)throw new Ol;return t})}catch(t){if(t instanceof Ol){const l=await vd();return $t(l.ok,`Failed to authenticate. Please visit ${yr()} to login.`),fetch(n,a)}if(t instanceof Error&&t.name==="AbortError")throw t}throw new Error("An unexpected error occurred while fetching data")}let jn=null;async function vd(){return jn||(jn=fetch(bd,{method:"POST"}).then(n=>n.ok?(jn=null,Promise.resolve(n)):(window.location.href=yr(),new Promise(()=>{}))),jn)}const vr=Ln+"/graphql",Cd=window.Config.authenticationEnabled,Cr=Cd?yd:fetch;function kd(n,a,t){return Qn.Observable.create(l=>{const i=new AbortController;return Cr(n,{...a,signal:i.signal}).then(r=>($t(r instanceof Response),r.json())).then(r=>{const o=t==null?void 0:t(r);if(o)throw o;l.next(r),l.complete()}).catch(r=>{r.name==="AbortError"?l.complete():l.error(r)}),()=>{i.abort()}})}const Ld=(n,a,t)=>kd(vr,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:n.text,variables:a})},l=>{if(!(!Le(l)||!("errors"in l))&&Array.isArray(l.errors))return new Error(`Error fetching GraphQL query '${n.name}' with variables '${JSON.stringify(a)}': ${JSON.stringify(l.errors)}`)}),Sd=W1(vr,{fetch:Cr}),ua=new Qn.Environment({network:Qn.Network.create(Ld,Sd),store:new Qn.Store(new Qn.RecordSource,{gcReleaseBufferSize:20})});function kr(n){return n.includes("PRIMARY")?_e.primary:n.includes("CORPUS")?_e.corpus:_e.reference}function Yt(n){const a=[],t=[],l=[];return n.forEach(i=>{const r=kr(i);r==_e.primary?a.push(i):r==_e.corpus?l.push(i):t.push(i)}),{primaryEventIds:a,referenceEventIds:t,corpusEventIds:l}}const wa=10,qn="unknown",Lr=q1,Sr=Q1,wd=n=>Sr[n],xd=n=>Lr(n/wa);var _n=(n=>(n.move="move",n.select="select",n))(_n||{}),Jt=(n=>(n.default="default",n.highlight="highlight",n))(Jt||{});const zn=()=>ld()==="light"?Xc:qc;function bm(){const n=zn();return{coloringStrategy:Y.inferences,pointGroupVisibility:{[ne.primary]:!0,[ne.reference]:!0},pointGroupColors:{[ne.primary]:n[0],[ne.reference]:n[1],[ne.corpus]:Ye},metric:{type:"drift",metric:"euclideanDistance"}}}function ym(){const n=zn();return{coloringStrategy:Y.inferences,pointGroupVisibility:{[ne.primary]:!0,[ne.corpus]:!0},pointGroupColors:{[ne.primary]:n[0],[ne.corpus]:Ye},metric:{type:"retrieval",metric:"queryDistance"},clusterSort:{dir:"desc",column:"primaryMetricValue"}}}function vm(){return{coloringStrategy:Y.correctness,pointGroupVisibility:{[pe.correct]:!0,[pe.incorrect]:!0,[pe.unknown]:!0},pointGroupColors:{[pe.correct]:Sa.Discrete2.LightBlueOrange[0],[pe.incorrect]:Sa.Discrete2.LightBlueOrange[1],[pe.unknown]:In},metric:{type:"performance",metric:"accuracyScore"},clusterSort:{dir:"asc",column:"primaryMetricValue"}}}const Td=n=>{const a={loading:!1,errorMessage:null,points:[],eventIdToDataMap:new Map,clusters:[],clusterSort:{dir:"desc",column:"driftRatio"},pointData:null,selectedEventIds:new Set,hoveredEventId:null,highlightedClusterId:null,selectedClusterId:null,canvasMode:"move",pointSizeScale:1,clusterColorMode:"default",coloringStrategy:Y.inferences,inferencesVisibility:{primary:!0,reference:!0,corpus:!0},pointGroupVisibility:{[ne.primary]:!0,[ne.reference]:!0,[ne.corpus]:!0},pointGroupColors:{[ne.primary]:zn()[0],[ne.reference]:zn()[1],[ne.corpus]:Ye},eventIdToGroup:{},selectionDisplay:Kn.gallery,selectionGridSize:Mn.large,dimension:null,dimensionMetadata:null,umapParameters:{minDist:jc,nNeighbors:Hc,nSamples:Zc},hdbscanParameters:{minClusterSize:Uc,clusterMinSamples:Wc,clusterSelectionEpsilon:Qc},clustersLoading:!1,metric:{type:"drift",metric:"euclideanDistance"},selectionSearchText:""},t=(l,i)=>({...a,...n,setInitialData:async({points:r,clusters:o,retrievals:c})=>{const d=i(),u=new Map,m=c.reduce((f,y)=>{const{queryId:v}=y;return f[v]?f[v].push(y):f[v]=[y],f},{});r.forEach(f=>{f={...f,retrievals:m[f.eventId]??[]},u.set(f.eventId,f)});const h=o.map(Bl).sort(ct(d.clusterSort));l({loading:!1,points:r,eventIdToDataMap:u,clusters:h,clustersLoading:!1,selectedEventIds:new Set,selectedClusterId:null,pointData:null,eventIdToGroup:sn({points:r,coloringStrategy:d.coloringStrategy,pointsData:d.pointData??{},dimension:d.dimension||null,dimensionMetadata:d.dimensionMetadata})});const b=await Ad(r.map(f=>f.eventId)).catch(()=>l({errorMessage:"Failed to load the point events"}));b&&l({pointData:b,clusters:h,clustersLoading:!1,eventIdToGroup:sn({points:r,coloringStrategy:d.coloringStrategy,pointsData:b??{},dimension:d.dimension||null,dimensionMetadata:d.dimensionMetadata})})},setClusters:r=>{const o=i(),c=r.map(Bl).sort(ct(o.clusterSort));l({clusters:c,clustersLoading:!1,selectedClusterId:null,highlightedClusterId:null})},setClusterSort:r=>{const c=[...i().clusters].sort(ct(r));l({clusterSort:r,clusters:c})},setSelectedEventIds:r=>l({selectedEventIds:r,selectionSearchText:""}),setHoveredEventId:r=>l({hoveredEventId:r}),setHighlightedClusterId:r=>l({highlightedClusterId:r}),setSelectedClusterId:r=>l({selectedClusterId:r,highlightedClusterId:null}),setPointSizeScale:r=>l({pointSizeScale:r}),setCanvasMode:r=>l({canvasMode:r}),setClusterColorMode:r=>l({clusterColorMode:r}),setColoringStrategy:r=>{const o=i();switch(l({coloringStrategy:r}),r){case Y.correctness:l({pointGroupVisibility:{[pe.correct]:!0,[pe.incorrect]:!0,[pe.unknown]:!0},pointGroupColors:{[pe.correct]:Sa.Discrete2.LightBlueOrange[0],[pe.incorrect]:Sa.Discrete2.LightBlueOrange[1],[pe.unknown]:In},dimension:null,dimensionMetadata:null,eventIdToGroup:sn({points:o.points,coloringStrategy:r,pointsData:o.pointData??{},dimension:o.dimension||null,dimensionMetadata:o.dimensionMetadata})});break;case Y.inferences:{l({pointGroupVisibility:{[ne.primary]:!0,[ne.reference]:!0,[ne.corpus]:!0},pointGroupColors:{[ne.primary]:zn()[0],[ne.reference]:zn()[1],[ne.corpus]:Ye},dimension:null,dimensionMetadata:null,eventIdToGroup:sn({points:o.points,coloringStrategy:r,pointsData:o.pointData??{},dimension:o.dimension||null,dimensionMetadata:o.dimensionMetadata})});break}case Y.dimension:{l({pointGroupVisibility:{unknown:!0},pointGroupColors:{unknown:In},dimension:null,dimensionMetadata:null,eventIdToGroup:sn({points:o.points,coloringStrategy:r,pointsData:o.pointData??{},dimension:o.dimension||null,dimensionMetadata:o.dimensionMetadata})});break}default:N()}},inferencesVisibility:{primary:!0,reference:!0,corpus:!0},setInferencesVisibility:r=>l({inferencesVisibility:r}),setPointGroupVisibility:r=>l({pointGroupVisibility:r}),selectionDisplay:Kn.gallery,setSelectionDisplay:r=>l({selectionDisplay:r}),setSelectionGridSize:r=>l({selectionGridSize:r}),reset:()=>{l({points:[],clusters:[],selectedEventIds:new Set,selectedClusterId:null,eventIdToGroup:{}})},setDimension:async r=>{const o=i();l({dimension:r,dimensionMetadata:null});const c=await zd(r).catch(()=>l({errorMessage:"Failed to load the dimension metadata"}));if(c){if(l({dimensionMetadata:c}),c.categories&&c.categories.length){const d=c.categories.length,m=d<=Sr.length?wd:h=>Lr(h/d);l({pointGroupVisibility:{...c.categories.reduce((h,b)=>({...h,[b]:!0}),{}),unknown:!0},pointGroupColors:{...c.categories.reduce((h,b,f)=>({...h,[b]:m(f)}),{}),unknown:In},eventIdToGroup:sn({points:o.points,coloringStrategy:o.coloringStrategy,pointsData:o.pointData??{},dimension:r,dimensionMetadata:c})})}else if(c.interval!==null){const d=wr(c.interval);l({pointGroupVisibility:{...d.reduce((u,m)=>({...u,[m.name]:!0}),{}),unknown:!0},pointGroupColors:{...d.reduce((u,m,h)=>({...u,[m.name]:xd(h)}),{}),unknown:In},eventIdToGroup:sn({points:o.points,coloringStrategy:o.coloringStrategy,pointsData:o.pointData??{},dimension:r,dimensionMetadata:c})})}}},setDimensionMetadata:r=>l({dimensionMetadata:r}),setUMAPParameters:r=>l({umapParameters:r}),setHDBSCANParameters:async r=>{const o=i();l({hdbscanParameters:r,clustersLoading:!0});const c=await Md({metric:o.metric,points:o.points,hdbscanParameters:r});o.setClusters(c)},getHDSCANParameters:()=>i().hdbscanParameters,getMetric:()=>i().metric,setErrorMessage:r=>l({errorMessage:r}),setLoading:r=>l({loading:r}),setMetric:async r=>{const o=i();l({metric:r,clustersLoading:!0});const c=await Fd({metric:r,clusters:o.clusters,hdbscanParameters:o.hdbscanParameters});o.setClusters(c)},setSelectionSearchText:r=>l({selectionSearchText:r})});return Vn()(Pn(t))},$l=new Intl.NumberFormat([],{maximumFractionDigits:2});function Id({min:n,max:a}){return`${$l.format(n)} - ${$l.format(a)}`}function wr({min:n,max:a}){const l=(a-n)/wa,i=[];for(let r=0;r<wa;r++){const o=n+r*l,c=n+(r+1)*l;i.push({min:o,max:c,name:Id({min:o,max:c})})}return i}function st({numericGroupIntervals:n,numericValue:a}){let t=qn,l=n.findIndex(i=>a>=i.min&&a<i.max);return l=l===-1?wa-1:l,t=n[l].name,t}function sn(n){const{points:a,coloringStrategy:t,pointsData:l,dimension:i,dimensionMetadata:r}=n,o={},c=a.map(d=>d.eventId);switch(t){case Y.inferences:{const{primaryEventIds:d,referenceEventIds:u,corpusEventIds:m}=Yt(c);d.forEach(h=>{o[h]=ne.primary}),u.forEach(h=>{o[h]=ne.reference}),m.forEach(h=>{o[h]=ne.corpus});break}case Y.correctness:{a.forEach(d=>{let u=pe.unknown;const{predictionLabel:m,actualLabel:h}=d.eventMetadata;m!==null&&h!==null&&(u=m===h?pe.correct:pe.incorrect),o[d.eventId]=u});break}case Y.dimension:{let d;r&&(r==null?void 0:r.interval)!==null&&(d=wr(r.interval));const u=(i==null?void 0:i.type)==="prediction"&&(i==null?void 0:i.dataType)==="categorical",m=(i==null?void 0:i.type)==="prediction"&&(i==null?void 0:i.dataType)==="numeric",h=(i==null?void 0:i.type)==="actual"&&(i==null?void 0:i.dataType)==="categorical",b=(i==null?void 0:i.type)==="actual"&&(i==null?void 0:i.dataType)==="numeric";a.forEach(f=>{let y=qn;const v=l[f.eventId];if(i!=null&&v!=null)if(u)y=v.eventMetadata.predictionLabel??qn;else if(m){if(d==null)throw new Error("Cannot color by prediction score without numeric group intervals");const k=v.eventMetadata.predictionScore;typeof k=="number"&&(y=st({numericGroupIntervals:d,numericValue:k}))}else if(b){if(d==null)throw new Error("Cannot color by actual score without numeric group intervals");const k=v.eventMetadata.actualScore;typeof k=="number"&&(y=st({numericGroupIntervals:d,numericValue:k}))}else if(h)y=v.eventMetadata.actualLabel??qn;else{const k=v.dimensions.find(T=>T.dimension.name===i.name);if(k!=null&&i.dataType==="categorical")y=k.value??qn;else if(k!=null&&i.dataType==="numeric"&&d!=null){const T=typeof(k==null?void 0:k.value)=="string"?parseFloat(k.value):null;typeof T=="number"&&(y=st({numericGroupIntervals:d,numericValue:T}))}}o[f.eventId]=y});break}default:N()}return o}async function zd(n){const a=await F.fetchQuery(ua,lr,{id:n.id,getDimensionMinMax:n.dataType==="numeric",getDimensionCategories:n.dataType==="categorical"}).toPromise(),t=a==null?void 0:a.dimension;if(!n)throw new Error("Dimension not found");let l=null;return typeof(t==null?void 0:t.min)=="number"&&typeof(t==null?void 0:t.max)=="number"&&(l={min:t.min,max:t.max}),{interval:l,categories:(t==null?void 0:t.categories)??null}}async function Ad(n){var u,m,h,b,f,y;const{primaryEventIds:a,referenceEventIds:t,corpusEventIds:l}=Yt([...n]),i=await F.fetchQuery(ua,tr,{primaryEventIds:a,referenceEventIds:t,corpusEventIds:l}).toPromise(),r=((m=(u=i==null?void 0:i.model)==null?void 0:u.primaryInferences)==null?void 0:m.events)??[],o=((b=(h=i==null?void 0:i.model)==null?void 0:h.referenceInferences)==null?void 0:b.events)??[],c=((y=(f=i==null?void 0:i.model)==null?void 0:f.corpusInferences)==null?void 0:y.events)??[];return[...r,...o,...c].reduce((v,L)=>(v[L.id]=L,v),{})}async function Md({metric:n,points:a,hdbscanParameters:t}){const l=await F.fetchQuery(ua,ar,{eventIds:a.map(i=>i.eventId),coordinates:a.map(i=>({x:i.position[0],y:i.position[1],z:i.position[2]})),fetchDataQualityMetric:n.type==="dataQuality",dataQualityMetricColumnName:n.type==="dataQuality"?n.dimension.name:null,fetchPerformanceMetric:n.type==="performance",performanceMetric:n.type==="performance"?n.metric:"accuracyScore",...t},{fetchPolicy:"network-only"}).toPromise();return(l==null?void 0:l.hdbscanClustering)??[]}async function Fd({metric:n,clusters:a,hdbscanParameters:t}){const l=await F.fetchQuery(ua,nr,{clusters:a.map(i=>({id:i.id,eventIds:i.eventIds})),fetchDataQualityMetric:n.type==="dataQuality",dataQualityMetricColumnName:n.type==="dataQuality"?n.dimension.name:null,fetchPerformanceMetric:n.type==="performance",performanceMetric:n.type==="performance"?n.metric:"accuracyScore",...t},{fetchPolicy:"network-only"}).toPromise();return(l==null?void 0:l.clusters)??[]}const ct=n=>(a,t)=>{const{dir:l,column:i}=n,r=l==="asc",o=a[i],c=t[i];return o==null?1:c==null?-1:o>c?r?1:-1:o<c?r?-1:1:0};function Bl(n){let a=n.driftRatio,t=null;return n.dataQualityMetric?(a=n.dataQualityMetric.primaryValue,t=n.dataQualityMetric.referenceValue):n.performanceMetric?(a=n.performanceMetric.primaryValue,t=n.performanceMetric.referenceValue):n.primaryToCorpusRatio!=null&&(a=(n.primaryToCorpusRatio+1)/2*100),{...n,size:n.eventIds.length,primaryMetricValue:a,referenceMetricValue:t}}const Dd=({projectId:n,tableId:a})=>`arize-phoenix-tracing-${n}-${a}`,Cm=n=>{const a=t=>({...n,columnVisibility:{metadata:!1},columnSizing:{metadata:200},annotationColumnVisibility:{},setColumnVisibility:l=>{t({columnVisibility:l},!1,{type:"setColumnVisibility"})},setAnnotationColumnVisibility:l=>{t({annotationColumnVisibility:l},!1,{type:"setAnnotationColumnVisibility"})},setColumnSizing:l=>{typeof l=="function"?t(i=>({columnSizing:l(i.columnSizing)}),!1,{type:"setColumnSizing"}):t({columnSizing:l},!1,{type:"setColumnSizing"})}});return Vn()(Fa(Pn(a,{name:"tracingStore"}),{name:Dd(n)}))},Je={NONE:"NONE",FString:"F_STRING",Mustache:"MUSTACHE"},km={OPENAI:"OpenAI",AZURE_OPENAI:"Azure OpenAI",ANTHROPIC:"Anthropic",GOOGLE:"Google",DEEPSEEK:"DeepSeek",XAI:"xAI",OLLAMA:"Ollama",AWS:"AWS Bedrock"},xr="OPENAI",Ed="gpt-4o",Kd="user",Lm=["2024-10-01-preview","2024-09-01-preview","2024-08-01-preview","2024-07-01-preview","2024-06-01","2024-05-01-preview","2024-04-01-preview","2024-03-01-preview","2024-02-15-preview","2024-02-01","2023-10-01-preview","2023-09-01-preview","2023-08-01-preview","2023-07-01-preview","2023-06-01-preview","2023-05-15","2023-03-15-preview"],Sm={user:["user","human"],ai:["assistant","bot","ai","model"],system:["system","developer"],tool:["tool"]},At={OPENAI:[{envVarName:"OPENAI_API_KEY",isRequired:!0}],AZURE_OPENAI:[{envVarName:"AZURE_OPENAI_API_KEY",isRequired:!0}],ANTHROPIC:[{envVarName:"ANTHROPIC_API_KEY",isRequired:!0}],GOOGLE:[{envVarName:"GEMINI_API_KEY",isRequired:!0}],DEEPSEEK:[{envVarName:"DEEPSEEK_API_KEY",isRequired:!0}],XAI:[{envVarName:"XAI_API_KEY",isRequired:!0}],OLLAMA:[],AWS:[{envVarName:"AWS_ACCESS_KEY_ID",isRequired:!0},{envVarName:"AWS_SECRET_ACCESS_KEY",isRequired:!0},{envVarName:"AWS_SESSION_TOKEN",isRequired:!1}]},Tr=({parser:n,text:a})=>{const t=n.parse(a),l=[],i=t.cursor();do if(i.name==="Variable"){const r=a.slice(i.node.from,i.node.to).trim();l.push(r)}while(i.next());return l},Ir=({parser:n,text:a,variables:t,postFormat:l})=>{if(!a)return"";let i=a,r=n.parse(i),o=r.cursor();do if(o.name==="Variable"){const c=i.slice(o.node.from,o.node.to).trim(),d=o.node.parent;c in t&&(i=`${i.slice(0,d.from)}${t[c]}${i.slice(d.to)}`,r=n.parse(i),o=r.cursor())}while(o.next());return l&&(i=l(i)),i},_d=wi.deserialize({version:14,states:"!WQQOPOOOcOQO'#C^OOOO'#Cb'#CbQQOPOOOOOO'#Cc'#CcOhOQO,58xOOOO-E6`-E6`OOOO-E6a-E6aOOOO1G.d1G.d",stateData:"v~ORPOXQOYQOZQO[QO~OSSO~OSSOTWO~OZRX[X~",goto:"iWPPXPPP]cTQORQRORURQTPRVT",nodeNames:"⚠ FStringTemplate Template LBrace Variable RBrace",maxTerm:12,skippedNodes:[0],repeatNodeCount:2,tokenData:"%[~RaXY!WYZ!W]^!Wpq!Wqr!Wrs!]sw!Wwx!bx#O!W#O#P!i#P#o!W#o#p$c#p#q!W#q#r$|#r;'S!W;'S;=`%U<%lO!W~!]OX~~!bO[~~!iOX~[~~!lYrs!W!P!Q!W#O#P!W#U#V!W#Y#Z!W#b#c!W#f#g!W#h#i!W#i#j#[#o#p$^~#_R!Q![#h!c!i#h#T#Z#h~#kR!Q![#t!c!i#t#T#Z#t~#wR!Q![$Q!c!i$Q#T#Z$Q~$TR!Q![!W!c!i!W#T#Z!W~$cOZ~~$jQR~X~#o#p$p#q#r$w~$wOZ~[~~$|OY~~%RPX~#q#r!]~%XP;=`<%l!W",tokenizers:[1,new xi("!p~RVO#Oh#O#P!P#P#qh#q#r!j#r;'Sh;'S;=`y<%lOh~mSS~O#qh#r;'Sh;'S;=`y<%lOh~|P;=`<%lh~!UTS~O#qh#q#r!e#r;'Sh;'S;=`y<%lOh~!jOS~~!oOT~~",77)],topRules:{FStringTemplate:[0,1]},tokenPrec:32}),el=Qi.define({parser:_d.configure({props:[Ti({"Template/LBrace":qe.quote,"Template/RBrace":qe.quote,"Template/Variable":qe.variableName,"⚠":qe.invalid})]}),languageData:{}}),Vd=({text:n,variables:a})=>Ir({parser:el.parser,text:n,variables:a,postFormat:t=>t.replaceAll("\\{","{").replaceAll("{{","{").replaceAll("}}","}")}),Pd=n=>Tr({parser:el.parser,text:n});function Rd(){return new qi(el)}const Nd=wi.deserialize({version:14,states:"!WQQOPOOOcOQO'#C^OOOO'#Cb'#CbQQOPOOOOOO'#Cc'#CcOhOQO,58xOOOO-E6`-E6`OOOO-E6a-E6aOOOO1G.d1G.d",stateData:"v~ORPOXQOYQOZQO[QO~OSSO~OSSOTWO~OZRX[X~",goto:"iWPPXPPP]cTQORQRORURQTPRVT",nodeNames:"⚠ MustacheLikeTemplate Template LBrace Variable RBrace",maxTerm:12,skippedNodes:[0],repeatNodeCount:2,tokenData:"%W~RaXY!WYZ!W]^!Wpq!Wqr!Wrs!]sw!Wwx!bx#O!W#O#P!i#P#o!W#o#p$c#p#q!W#q#r!b#r;'S!W;'S;=`%Q<%lO!W~!]OX~~!bO[~~!iOX~[~~!lYrs!W!P!Q!W#O#P!W#U#V!W#Y#Z!W#b#c!W#f#g!W#h#i!W#i#j#[#o#p$^~#_R!Q![#h!c!i#h#T#Z#h~#kR!Q![#t!c!i#t#T#Z#t~#wR!Q![$Q!c!i$Q#T#Z$Q~$TR!Q![!W!c!i!W#T#Z!W~$cOZ~~$jPX~[~#o#p$m~$rPR~#q#r$u~$xP#q#r${~%QOY~~%TP;=`<%l!W",tokenizers:[1,new xi("#e~RVO#oh#o#p!P#p#qh#q#r#X#r;'Sh;'S;=`y<%lOh~mSS~O#qh#r;'Sh;'S;=`y<%lOh~|P;=`<%lh~!USS~O#q!b#r;'S!b;'S;=`#R<%lO!b~!gVS~O#O!b#O#P!b#P#q!b#q#r!|#r;'S!b;'S;=`#R<%lO!b~#ROS~~#UP;=`<%l!b~#[P#q#r#_~#dOT~~",112)],topRules:{MustacheLikeTemplate:[0,1]},tokenPrec:32}),nl=Qi.define({parser:Nd.configure({props:[Ti({"Template/LBrace":qe.quote,"Template/RBrace":qe.quote,"Template/Variable":qe.variableName,"Template/⚠":qe.invalid})]}),languageData:{}}),Od=({text:n,variables:a})=>Ir({parser:nl.parser,text:n,variables:a,postFormat:t=>t.replaceAll("\\{{","{{")}),$d=n=>Tr({parser:nl.parser,text:n});function Bd(){return new qi(nl)}const wm=n=>{switch(n){case Je.FString:return{format:Vd,extractVariables:Pd};case Je.Mustache:return{format:Od,extractVariables:$d};case Je.NONE:return{format:({text:a})=>a,extractVariables:()=>[]};default:N()}},Hd=Cn([ie(),X1(),An(),Y1()]),xa=J1(()=>Cn([Hd,en(xa),mn(xa)])),Hl=J({type:es(["string","number","boolean","object","array","null","integer"]).describe("The type of the parameter"),description:ie().optional().describe("A description of the parameter"),enum:en(ie()).optional().describe("The allowed values")}).passthrough().describe("A map of parameter names to their definitions"),al=J({type:he("object"),properties:mn(Cn([Hl,J({anyOf:en(Hl)}).describe("A list of possible parameter names to their definitions")])).optional(),required:en(ie()).optional().describe("The required parameters"),additionalProperties:An().optional().describe("Whether or not additional properties are allowed in the schema")}).passthrough(),ma=J({type:he("function").describe("The type of the tool"),function:J({name:ie().describe("The name of the function"),description:ie().optional().describe("A description of the function"),parameters:al.extend({strict:An().optional().describe("Whether or not the arguments should exactly match the function definition, only supported for OpenAI models")}).describe("The parameters that the function accepts")}).passthrough().describe("The function definition")}).passthrough(),xm=Rn(ma,{removeAdditionalStrategy:"passthrough"}),Ra=J({name:ie(),description:ie(),input_schema:al}),Tm=Rn(Ra,{removeAdditionalStrategy:"passthrough"}),Na=J({toolSpec:J({name:ie(),description:ie().min(1),inputSchema:J({json:al})})}),Im=Rn(Na,{removeAdditionalStrategy:"passthrough"}),jd=Na.transform(n=>({type:"function",function:{name:n.toolSpec.name,description:n.toolSpec.description,parameters:n.toolSpec.inputSchema.json}})),Zd=ma.transform(n=>({toolSpec:{name:n.function.name,description:n.function.description??n.function.name,inputSchema:{json:n.function.parameters}}})),Ud=Ra.transform(n=>({type:"function",function:{name:n.name,description:n.description,parameters:n.input_schema}})),Gd=ma.transform(n=>({name:n.function.name,description:n.function.description??n.function.name,input_schema:n.function.parameters})),zr=Cn([ma,Ra,Na,xa]),Wd=n=>{const{success:a,data:t}=ma.safeParse(n);if(a)return{provider:"OPENAI",validatedToolDefinition:t};const{success:l,data:i}=Ra.safeParse(n);if(l)return{provider:"ANTHROPIC",validatedToolDefinition:i};const{success:r,data:o}=Na.safeParse(n);return r?{provider:"AWS",validatedToolDefinition:o}:{provider:"UNKNOWN",validatedToolDefinition:null}},dt=n=>{const{provider:a,validatedToolDefinition:t}=Wd(n);switch(a){case"AZURE_OPENAI":case"OPENAI":return t;case"ANTHROPIC":return Ud.parse(t);case"AWS":return jd.parse(t);case"UNKNOWN":return null;default:N()}},jl=({toolDefinition:n,targetProvider:a})=>{switch(a){case"AZURE_OPENAI":case"OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":return n;case"ANTHROPIC":return Gd.parse(n);case"AWS":return Zd.parse(n);case"GOOGLE":return n;default:N()}};function zm(n){return{type:"function",function:{name:`new_function_${n}`,description:"a description",parameters:{type:"object",properties:{new_arg:{type:"string"}},required:[]}}}}function Am(n){return{name:`new_function_${n}`,description:"a description",input_schema:{type:"object",properties:{new_arg:{type:"string"}},required:[]}}}function Mm(n){return{toolSpec:{name:`new_function_${n}`,description:"a description",inputSchema:{json:{type:"object",properties:{new_arg:{type:"string"}},required:[]}}}}}const Fm=n=>{const a=zr.safeParse(n);return!a.success||a.data===null||!Le(a.data)?null:"function"in a.data&&Le(a.data.function)&&"name"in a.data.function&&typeof a.data.function.name=="string"?a.data.function.name:"name"in a.data&&typeof a.data.name=="string"?a.data.name:null},Dm=n=>{const a=zr.safeParse(n);return!a.success||a.data===null||!Le(a.data)?null:"function"in a.data&&Le(a.data.function)&&"description"in a.data.function&&typeof a.data.function.description=="string"?a.data.function.description:"description"in a.data&&typeof a.data.description=="string"?a.data.description:null};function Qd({str:n,excludePrimitives:a=!1,excludeArray:t=!1,excludeNull:l=!1}){try{const i=JSON.parse(n);if(a&&typeof i!="object"||t&&Array.isArray(i)||l&&i===null)return!1}catch{return!1}return!0}function qd(n){return Qd({str:n,excludeArray:!0,excludePrimitives:!0})}function Oa(n){try{return{json:JSON.parse(n)}}catch(a){return{json:null,parseError:a}}}function Em(...n){try{return{json:JSON.stringify(...n)}}catch(a){return{json:null,stringifyError:a}}}function Ar(n,a="",t="."){const l={};for(const[i,r]of Object.entries(n)){const o=a?`${a}${t}${i}`:i;r&&typeof r=="object"?Object.assign(l,Ar(r,o,t)):l[o]=r}return l}function Km(n,a="."){try{const t=JSON.parse(n);return typeof t!="object"?{}:Ar(t,"",a)}catch{}return{}}const ga=J({id:ie().describe("The ID of the tool call"),type:he("function").describe("The type of the tool call").default("function"),function:J({name:ie().describe("The name of the function"),arguments:mn(Jn()).describe("The arguments for the function")}).describe("The function that is being called").passthrough()}),Xd=en(ga),_m=Rn(Xd,{removeAdditionalStrategy:"passthrough"}),$a=J({toolUse:J({toolUseId:ie().describe("The ID of the tool call"),name:ie().describe("The name of the tool"),input:mn(Jn()).describe("The input for the tool")})}),Yd=en($a),Vm=Rn(Yd,{removeAdditionalStrategy:"passthrough"}),Jd=ga.transform(n=>({toolUse:{toolUseId:n.id,name:n.function.name,input:n.function.arguments}})),e0=$a.transform(n=>({id:n.toolUse.toolUseId,type:"function",function:{name:n.toolUse.name,arguments:n.toolUse.input}})),Ba=J({id:ie().describe("The ID of the tool call"),type:he("tool_use"),name:ie().describe("The name of the tool"),input:mn(Jn()).describe("The input for the tool")}).passthrough(),n0=en(Ba),Pm=Rn(n0,{removeAdditionalStrategy:"passthrough"}),a0=Ba.transform(n=>({id:n.id,type:"function",function:{name:n.name,arguments:n.input}})),t0=ga.transform(n=>({id:n.id,type:"tool_use",name:n.function.name,input:typeof n.function.arguments=="string"?{[n.function.arguments]:n.function.arguments}:n.function.arguments??{}})),l0=Cn([ga,Ba,$a,xa]);en(l0);const i0=n=>{const{success:a,data:t}=ga.safeParse(n);if(a)return{provider:"OPENAI",validatedToolCall:t};const{success:l,data:i}=Ba.safeParse(n);if(l)return{provider:"ANTHROPIC",validatedToolCall:i};const{success:r,data:o}=$a.safeParse(n);return r?{provider:"AWS",validatedToolCall:o}:{provider:"UNKNOWN",validatedToolCall:null}},un=n=>{const{provider:a,validatedToolCall:t}=i0(n);switch(a){case"AZURE_OPENAI":case"OPENAI":return t;case"ANTHROPIC":return a0.parse(t);case"AWS":return e0.parse(t);case"UNKNOWN":return null;default:N()}},Mt=({toolCall:n,targetProvider:a})=>{switch(a){case"AZURE_OPENAI":case"OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":return n;case"AWS":return Jd.parse(n);case"ANTHROPIC":return t0.parse(n);case"GOOGLE":return n;default:N()}},Rm=(n,a)=>{const t=un({id:n.toolCall.toolCallId,function:{name:n.toolCall.toolCall.name,arguments:Oa(n.toolCall.toolCall.arguments).json||""}});return t?Mt({toolCall:t,targetProvider:a}):null};function Nm(){return{id:"",type:"function",function:{name:"",arguments:{}}}}function Om(){return{id:"",type:"tool_use",name:"",input:{}}}const tl=J({id:ie().optional(),name:ie().optional(),arguments:mn(Jn()).optional(),function:J({name:ie().optional(),arguments:mn(Jn()).optional()}).optional()});function $m(n){let a=n;typeof n=="string"&&(a=Oa(n).json);const t=un(a);if(t)return t.id;const l=tl.safeParse(a);return l.success?l.data.id??l.data.name??null:null}function Bm(n){var i;let a=n;typeof n=="string"&&(a=Oa(n).json);const t=un(a);if(t)return t.function.name;const l=tl.safeParse(a);return l.success?((i=l.data.function)==null?void 0:i.name)??l.data.name??l.data.id??null:null}function Hm(n){var i;let a=n;typeof n=="string"&&(a=Oa(n).json);const t=un(a);if(t)return t.function.arguments;const l=tl.safeParse(a);return l.success?l.data.arguments??((i=l.data.function)==null?void 0:i.arguments)??null:null}const Ha=nd()(Cn([he("auto"),he("none"),he("required"),J({type:he("function"),function:J({name:ie()})})]));Ii("type",[J({type:he("auto")}),J({type:he("any")}),J({type:he("tool"),name:ie()}),J({type:he("none")})]);const ll=Ii("type",[J({type:he("none")}),J({type:he("auto"),disable_parallel_tool_use:An().optional()}),J({type:he("any"),disable_parallel_tool_use:An().optional()}),J({type:he("tool"),name:ie(),disable_parallel_tool_use:An().optional()})]),r0=ll.transform(n=>{switch(n.type){case"any":return"required";case"auto":return"auto";case"tool":return n.name?{type:"function",function:{name:n.name}}:"auto";case"none":return"none";default:return"auto"}}),o0=Ha.transform(n=>{if(Le(n))return{type:"tool",name:n.function.name};switch(n){case"none":return{type:"none"};case"auto":return{type:"auto"};case"required":return{type:"any"};default:N()}}),s0=Ha.transform(n=>{if(Le(n))return{type:"tool",name:n.function.name};switch(n){case"none":return{type:"none"};case"auto":return{type:"auto"};case"required":return{type:"any"};default:N()}});Cn([Ha,ll]);const c0=n=>{const{success:a,data:t}=Ha.safeParse(n);if(a)return{provider:"OPENAI",toolChoice:t};const{success:l,data:i}=ll.safeParse(n);return l?{provider:"ANTHROPIC",toolChoice:i}:{provider:null,toolChoice:null}},d0=n=>{const{provider:a,toolChoice:t}=c0(n);if(a==null||t==null)throw new Error("Could not detect provider of tool choice");switch(a){case"AZURE_OPENAI":case"OPENAI":return t;case"ANTHROPIC":return r0.parse(t);default:N()}},u0=({toolChoice:n,targetProvider:a})=>{switch(a){case"AZURE_OPENAI":case"OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":return n;case"AWS":return o0.parse(n);case"ANTHROPIC":return s0.parse(n);case"GOOGLE":return n;default:N()}},m0=({toolChoice:n,targetProvider:a})=>{try{const t=d0(n);return u0({toolChoice:t,targetProvider:a})}catch{return null}},Zl=n=>n,Ul=n=>n,Gl=n=>n,g0=n=>Le(n)?"function"in n&&Le(n.function)&&"name"in n.function&&typeof n.function.name=="string"?n.function.name:"name"in n&&typeof n.name=="string"?n.name:null:null,p0=({instanceTools:n,provider:a})=>n.map(t=>{switch(a){case"OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":case"AZURE_OPENAI":{const l=dt(t.definition);return{...t,definition:l??t.definition}}case"ANTHROPIC":{const l=dt(t.definition),i=l?jl({toolDefinition:l,targetProvider:a}):t.definition;return{...t,definition:i}}case"AWS":{const l=dt(t.definition),i=l?jl({toolDefinition:l,targetProvider:a}):t.definition;return{...t,definition:i}}case"GOOGLE":return t;default:N()}}),h0=({toolCalls:n,provider:a})=>{if(n!=null)return n.map(t=>{switch(a){case"OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":case"AZURE_OPENAI":return un(t)??t;case"ANTHROPIC":{const l=un(t);return l!=null?Mt({toolCall:l,targetProvider:a}):t}case"AWS":{const l=un(t);return l!=null?Mt({toolCall:l,targetProvider:a}):t}case"GOOGLE":return t;default:N()}})};let f0=0,b0=0,y0=1,v0=0;const Mr=()=>f0++,Ta=()=>y0++,jm=()=>v0++,C0=()=>b0++,Fr=()=>({__type:"chat",messages:[{id:Ta(),role:"system",content:"You are a chatbot"},{id:Ta(),role:"user",content:"{{question}}"}]}),il=n=>({template:{__type:"chat",messageIds:n.messages.map(a=>a.id)},messages:n.messages.reduce((a,t)=>(a[t.id]=t,a),{})}),k0={__type:"text_completion",prompt:"{{question}}"},L0=()=>({model:{provider:xr,modelName:Ed,invocationParameters:[],supportedInvocationParameters:[]},tools:[],toolChoice:"auto",output:void 0,spanId:null,activeRunId:null});function S0(){const n=Fr(),a=il(n);return{instance:{id:Mr(),template:a.template,...L0()},instanceMessages:a.messages}}function Zm(){return{type:"json_schema",json_schema:{name:"response",schema:{type:"object",properties:{},required:[],additionalProperties:!1},strict:!0}}}function w0(n){if(n.instances!=null&&n.instances.length>0){let o={};return{instances:n.instances.map(d=>{if(d.template.__type==="chat"){const u=il(d.template);return o={...o,...u.messages},{...d,template:u.template}}return d}),instanceMessages:o}}const{instance:a,instanceMessages:t}=S0(),l=Object.values(n.modelConfigByProvider);if(!(l.length>0))return{instances:[a],instanceMessages:t};const r=l.find(o=>o.provider===xr)??l[0];return a.model={...a.model,...r},{instances:[a],instanceMessages:t}}const Um=n=>{const{instances:a,instanceMessages:t}=w0(n);return Vn(Pn((i,r)=>({streaming:!0,repetitions:1,operationType:"chat",inputMode:"manual",dirtyInstances:{},input:{variablesValueCache:{}},templateFormat:Je.Mustache,...n,instances:a,allInstanceMessages:t,setInput:o=>{i({input:o})},setOperationType:o=>{if(o==="chat"){const c=[];let d={};r().instances.forEach(u=>{const m=Fr(),h=il(m);d={...d,...h.messages},c.push({...u,template:h.template})}),i({instances:c,allInstanceMessages:d})}else i({instances:r().instances.map(c=>({...c,template:k0}))});i({operationType:o})},addInstance:()=>{const o=r().instances,c=r().allInstanceMessages,d=r().instances[0];if(!d)return;let u=[],m={};if(d.template.__type==="chat"){const b=d.template.messageIds.map(f=>c[f]).map(f=>({...f,id:Ta()}));u=b.map(f=>f.id),m=b.reduce((f,y)=>(f[y.id]=y,f),{})}i({allInstanceMessages:{...c,...m},instances:[...o,{...d,...d.template.__type==="chat"?{template:{...d.template,messageIds:u}}:{},id:Mr(),activeRunId:null,experimentId:null,spanId:null}]})},updateModelSupportedInvocationParameters:({instanceId:o,supportedInvocationParameters:c,modelConfigByProvider:d})=>{const u=r().instances;i({instances:u.map(m=>{if(m.id===o){const{baseUrl:h,endpoint:b,apiVersion:f,region:y}=d[m.model.provider]??{},v=wc(m.model.invocationParameters,c),L=xc(v,c);return{...m,model:{...m.model,baseUrl:m.model.baseUrl??h,endpoint:m.model.endpoint??b,apiVersion:m.model.apiVersion??f,region:m.model.region??y,supportedInvocationParameters:c,invocationParameters:L},tools:c.find(k=>k.canonicalName===Tc)?m.tools:[]}}return m})})},updateProvider:({instanceId:o,provider:c,modelConfigByProvider:d})=>{const u=r().instances,m=u.find(L=>L.id===o);if(!m||m.model.provider===c)return;const h=d[c],b=m.model.invocationParameters.find(L=>L.canonicalName===Lc||L.invocationName===Sc),f=L=>L==="OLLAMA"?"http://localhost:11434/v1":null,y={model:(()=>{const L={...m.model},k={modelName:null,baseUrl:f(c),apiVersion:null,endpoint:null,region:null,customHeaders:null};return{...L,...k,...h||{},...h&&{invocationParameters:[...h.invocationParameters,...b?[b]:[]]},provider:c}})(),toolChoice:m0({toolChoice:m.toolChoice,targetProvider:c})??void 0,tools:p0({instanceTools:m.tools,provider:c})},v={};m.template.__type==="chat"&&m.template.messageIds.forEach(L=>{const k=r().allInstanceMessages[L];k&&(v[L]={...k,toolCalls:h0({toolCalls:k.toolCalls,provider:c})})}),i({allInstanceMessages:{...r().allInstanceMessages,...v},dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:u.map(L=>L.id===o?{...L,...y}:L)})},updateModel:({instanceId:o,patch:c})=>{const d=r().instances;d.find(m=>m.id===o)&&i({dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:d.map(m=>m.id===o?{...m,model:{...m.model,...c}}:m)})},deleteInstance:o=>{const c=r().instances;i({instances:c.filter(d=>d.id!==o),dirtyInstances:{...r().dirtyInstances,[o]:!1}})},addMessage:({playgroundInstanceId:o,messages:c})=>{const d=r().instances;let u=[];Array.isArray(c)?u=c:c?u=[c]:u=[{id:Ta(),role:Kd,content:""}],i({allInstanceMessages:{...r().allInstanceMessages,...u.reduce((m,h)=>(m[h.id]=h,m),{})},dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:d.map(m=>m.id===o&&(m!=null&&m.template)&&(m==null?void 0:m.template.__type)==="chat"?{...m,template:{...m.template,messageIds:[...m.template.messageIds,...u.map(h=>h.id)]}}:m)})},updateMessage:({messageId:o,patch:c,instanceId:d})=>{const u=r().allInstanceMessages;i({allInstanceMessages:{...u,[o]:{...u[o],...c}},dirtyInstances:{...r().dirtyInstances,[d]:!0}})},deleteMessage:({instanceId:o,messageId:c})=>{const d=r().instances,u=r().allInstanceMessages;i({allInstanceMessages:Object.fromEntries(Object.entries(u).filter(([,{id:m}])=>m!==c)),dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:d.map(m=>m.id===o&&(m!=null&&m.template)&&(m==null?void 0:m.template.__type)==="chat"?{...m,template:{...m.template,messageIds:m.template.messageIds.filter(h=>h!==c)}}:m)})},updateInstance:({instanceId:o,patch:c,dirty:d})=>{const u=r().instances;i({dirtyInstances:{...r().dirtyInstances,...d!=null?{[o]:d}:{}},instances:u.map(m=>m.id===o?{...m,...c}:m)})},runPlaygroundInstances:()=>{const o=r().instances;i({instances:o.map(c=>({...c,activeRunId:C0(),spanId:null}))})},cancelPlaygroundInstances:()=>{const o=r().instances;i({instances:o.map(c=>({...c,activeRunId:null,spanId:null}))})},markPlaygroundInstanceComplete:o=>{const c=r().instances;i({instances:c.map(d=>d.id===o?{...d,activeRunId:null}:d)})},setTemplateFormat:o=>{i({templateFormat:o})},setVariableValue:(o,c)=>{const d=r().input;i({input:{...d,variablesValueCache:{...d.variablesValueCache,[o]:c}}})},setStreaming:o=>{i({streaming:o})},setRepetitions:o=>{i({repetitions:o})},updateInstanceModelInvocationParameters:({instanceId:o,invocationParameters:c})=>{r().instances.find(u=>u.id===o)&&i({dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:r().instances.map(u=>u.id===o?{...u,model:{...u.model,invocationParameters:c}}:u)})},upsertInvocationParameterInput:({instanceId:o,invocationParameterInput:c})=>{const d=r().instances.find(m=>m.id===o);if(!d)return;const u=d.model.invocationParameters.find(m=>_l(m,c));i(u?{dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:r().instances.map(m=>m.id===o?{...m,model:{...m.model,invocationParameters:m.model.invocationParameters.map(h=>_l(h,c)?c:h)}}:m)}:{dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:r().instances.map(m=>m.id===o?{...m,model:{...m.model,invocationParameters:[...m.model.invocationParameters,c]}}:m)})},deleteInvocationParameterInput:({instanceId:o,invocationParameterInputInvocationName:c})=>{r().instances.find(u=>u.id===o)&&i({dirtyInstances:{...r().dirtyInstances,[o]:!0},instances:r().instances.map(u=>u.id===o?{...u,model:{...u.model,invocationParameters:u.model.invocationParameters.filter(m=>m.invocationName!==c)}}:u)})},setDirty:(o,c)=>{i({dirtyInstances:{...r().dirtyInstances,[o]:c}})}})))};function x0(n){return n==="OPENAI"||n==="AZURE_OPENAI"||n==="ANTHROPIC"||n==="GOOGLE"||n==="DEEPSEEK"||n==="XAI"||n==="OLLAMA"||n==="AWS"}function Gm(n){switch(n){case"OPENAI":return"OpenAI";case"AZURE_OPENAI":return"Azure OpenAI";case"ANTHROPIC":return"Anthropic";case"GOOGLE":return"Google";case"DEEPSEEK":return"DeepSeek";case"XAI":return"XAI";case"OLLAMA":return"Ollama";case"AWS":return"AWS";default:N()}}function Wm(n){switch(n){case"OPENAI":return Hn.OPENAI.toString();case"AZURE_OPENAI":return Hn.AZURE.toString();case"ANTHROPIC":return Hn.ANTHROPIC.toString();case"GOOGLE":return Hn.GOOGLE.toString();case"AWS":return Hn.AWS.toString();case"DEEPSEEK":return"deepseek";case"XAI":return"xai";case"OLLAMA":throw new Error("Ollama is not supported");default:N()}}function T0(n){return typeof n=="object"&&n!==null&&Object.keys(n).length>0&&Object.keys(n).every(a=>a in At)&&Object.values(n).every(a=>typeof a=="string")}function I0(n){const a={};for(const t of Object.keys(n))x0(t)&&At[t].length===1&&(a[t]={[At[t][0].envVarName]:n[t]});return a}const Qm=n=>{const a=t=>({setCredential:({provider:l,envVarName:i,value:r})=>{t(o=>({[l]:{...o[l],[i]:r}}),!1,{type:"setCredential"})},...n});return Vn()(Fa(Pn(a),{version:1,name:"arize-phoenix-credentials",migrate:t=>{if(T0(t))return I0(t)}}))};function ja(n){return e("div",{onClick:a=>a.stopPropagation(),css:p`
        display: inline-block;
      `,children:e(Da,{css:p`
          color: var(--ac-global-link-color);
          &:not(:hover) {
            text-decoration: none;
          }
        `,...n})})}function fe({href:n,children:a}){return s("a",{href:n,target:"_blank",css:p`
        color: var(--ac-global-link-color);
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        &:hover {
          text-decoration: underline;
        }
        .ac-icon-wrap {
          display: inline-block;
          margin-left: 0.1em;
          font-size: 1em;
        }
      `,rel:"noreferrer",children:[a,e(x,{svg:e(d2,{})})]})}const qm=()=>e("div",{css:p`
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: rgba(0, 0, 0, 0.2);
      `,children:e(no,{isIndeterminate:!0,"aria-label":"loading"})});function Xm(n){const{width:a="size-1250"}=n;return e(w,{width:a,backgroundColor:"light",borderStartWidth:"thin",borderStartColor:"dark",padding:"size-200",flex:"none",children:e(S,{direction:"column",alignItems:"end",justifyContent:"center",height:"100%",children:n.children})})}const z0=2e3,A0=p`
  flex: none;
  box-sizing: content-box;
`;function pa(n){const{text:a,size:t="S",...l}=n,[i,r]=g.useState(!1),o=g.useCallback(()=>{const c=typeof a=="string"?a:a.current||"";zi(c),r(!0),setTimeout(()=>{r(!1)},z0)},[a]);return e("div",{className:"copy-to-clipboard-button",css:A0,children:s(j,{delay:0,children:[e(D,{size:t,leadingVisual:e(x,{svg:i?e(dl,{}):e(Nr,{})}),onPress:o,...l}),e(xe,{offset:5,children:"Copy"})]})})}const rl={margin:["margin",G],marginStart:[Ce("marginLeft","marginRight"),G],marginEnd:[Ce("marginRight","marginLeft"),G],marginTop:["marginTop",G],marginBottom:["marginBottom",G],marginX:[["marginLeft","marginRight"],G],marginY:[["marginTop","marginBottom"],G],width:["width",G],height:["height",G],minWidth:["minWidth",G],minHeight:["minHeight",G],maxWidth:["maxWidth",G],maxHeight:["maxHeight",G],isHidden:["display",_0],alignSelf:["alignSelf",ve],justifySelf:["justifySelf",ve],position:["position",mt],zIndex:["zIndex",mt],top:["top",G],bottom:["bottom",G],start:[Ce("left","right"),G],end:[Ce("right","left"),G],left:["left",G],right:["right",G],order:["order",mt],flex:["flex",V0],flexGrow:["flexGrow",ve],flexShrink:["flexShrink",ve],flexBasis:["flexBasis",ve],gridArea:["gridArea",ve],gridColumn:["gridColumn",ve],gridColumnEnd:["gridColumnEnd",ve],gridColumnStart:["gridColumnStart",ve],gridRow:["gridRow",ve],gridRowEnd:["gridRowEnd",ve],gridRowStart:["gridRowStart",ve]},Dr={...rl,backgroundColor:["backgroundColor",K0],borderWidth:["borderWidth",He],borderStartWidth:[Ce("borderLeftWidth","borderRightWidth"),He],borderEndWidth:[Ce("borderRightWidth","borderLeftWidth"),He],borderLeftWidth:["borderLeftWidth",He],borderRightWidth:["borderRightWidth",He],borderTopWidth:["borderTopWidth",He],borderBottomWidth:["borderBottomWidth",He],borderXWidth:[["borderLeftWidth","borderRightWidth"],He],borderYWidth:[["borderTopWidth","borderBottomWidth"],He],borderColor:["borderColor",Be],borderStartColor:[Ce("borderLeftColor","borderRightColor"),Be],borderEndColor:[Ce("borderRightColor","borderLeftColor"),Be],borderLeftColor:["borderLeftColor",Be],borderRightColor:["borderRightColor",Be],borderTopColor:["borderTopColor",Be],borderBottomColor:["borderBottomColor",Be],borderXColor:[["borderLeftColor","borderRightColor"],Be],borderYColor:[["borderTopColor","borderBottomColor"],Be],borderRadius:["borderRadius",je],borderTopStartRadius:[Ce("borderTopLeftRadius","borderTopRightRadius"),je],borderTopEndRadius:[Ce("borderTopRightRadius","borderTopLeftRadius"),je],borderBottomStartRadius:[Ce("borderBottomLeftRadius","borderBottomRightRadius"),je],borderBottomEndRadius:[Ce("borderBottomRightRadius","borderBottomLeftRadius"),je],borderTopLeftRadius:["borderTopLeftRadius",je],borderTopRightRadius:["borderTopRightRadius",je],borderBottomLeftRadius:["borderBottomLeftRadius",je],borderBottomRightRadius:["borderBottomRightRadius",je],padding:["padding",G],paddingStart:[Ce("paddingLeft","paddingRight"),G],paddingEnd:[Ce("paddingRight","paddingLeft"),G],paddingLeft:["paddingLeft",G],paddingRight:["paddingRight",G],paddingTop:["paddingTop",G],paddingBottom:["paddingBottom",G],paddingX:[["paddingLeft","paddingRight"],G],paddingY:[["paddingTop","paddingBottom"],G],overflow:["overflow",ve]},Wl={borderWidth:"borderStyle",borderLeftWidth:"borderLeftStyle",borderRightWidth:"borderRightStyle",borderTopWidth:"borderTopStyle",borderBottomWidth:"borderBottomStyle"},M0=/(%|px|em|rem|vw|vh|auto|cm|mm|in|pt|pc|ex|ch|rem|vmin|vmax|fr)$/,F0=/^\s*\w+\(/,D0=/(static-)?size-\d+|single-line-(height|width)/g;function G(n){return typeof n=="number"?n+"px":M0.test(n)?n:F0.test(n)?n.replace(D0,"var(--ac-global-dimension-$&)"):`var(--ac-global-dimension-${n})`}function ut(n,a){return n=ol(n,a),G(n)}function E0(n,a,t,l){const i={};for(const r in n){const o=a[r];if(!o||n[r]==null)continue;let[c,d]=o;typeof c=="function"&&(c=c(t));const u=ol(n[r],l),m=d(u);if(Array.isArray(c))for(const h of c)i[h]=m;else i[c]=m}for(const r in Wl)i[r]&&(i[Wl[r]]="solid",i.boxSizing="border-box");return i}function Ce(n,a){return t=>t==="rtl"?a:n}function ha(n,a="default"){return`var(--ac-global-color-${n}, var(--ac-semantic-${n}-color-${a}))`}function K0(n){return`var(--ac-global-background-color-${n}, ${ha(n,"background")})`}function Be(n){return n==="default"?"var(--ac-global-border-color)":`var(--ac-global-border-color-${n}, ${ha(n,"border")})`}function He(n){return`var(--ac-global-border-size-${n})`}function ve(n){return n}function je(n){return`var(--ac-global-rounding-${n})`}function _0(n){return n?"none":void 0}function mt(n){return n}function V0(n){return typeof n=="boolean"?n?"1":void 0:""+n}function ol(n,a){if(n&&typeof n=="object"&&!Array.isArray(n)){for(let t=0;t<a.length;t++){const l=a[t];if(n[l]!=null)return n[l]}return n.base}return n}function P0(n,a=rl){const t={...n};for(const l in a)delete t[l];return t}function aa(n,a=rl,t={}){const{direction:l}=Ai(),{matchedBreakpoints:i=["base"]}=t,c={style:{...E0(n,a,l,i)}};ol(n.isHidden,i)&&(c.hidden=!0);const d=P0(n,a);return{styleProps:c,otherProps:d}}const Er=p`
  margin: 0;
  font-weight: 400;
  &[data-size="XS"] {
    font-size: var(--ac-global-font-size-xs);
    line-height: var(--ac-global-line-height-xs);
  }
  &[data-size="S"] {
    font-size: var(--ac-global-font-size-s);
    line-height: var(--ac-global-line-height-s);
  }
  &[data-size="M"] {
    font-size: var(--ac-global-font-size-m);
    line-height: var(--ac-global-line-height-m);
  }
  &[data-size="L"] {
    font-size: var(--ac-global-font-size-l);
    line-height: var(--ac-global-line-height-l);
  }
  &[data-size="XL"] {
    font-size: var(--ac-global-font-size-xl);
    line-height: var(--ac-global-line-height-xl);
  }
  &[data-weight="heavy"] {
    font-weight: 600;
  }
`,R0=p`
  color: var(--ac-global-text-color-900);
  &[data-level="1"] {
    font-size: var(--ac-global-font-size-xl);
    line-height: var(--ac-global-line-height-xl);
  }
  &[data-level="2"] {
    font-size: var(--ac-global-font-size-l);
    line-height: var(--ac-global-line-height-l);
  }
  &[data-level="3"] {
    font-size: var(--ac-global-font-size-m);
    line-height: var(--ac-global-line-height-m);
  }
  &[data-level="4"] {
    font-size: var(--ac-global-font-size-s);
    line-height: var(--ac-global-line-height-s);
  }
  &[data-level="5"] {
    font-size: var(--ac-global-font-size-xs);
    line-height: var(--ac-global-line-height-xs);
  }
  &[data-level="6"] {
    font-size: var(--ac-global-font-size-xxs);
    line-height: var(--ac-global-line-height-xxs);
  }
`,N0=n=>{if(n==="inherit")return"inherit";if(n.startsWith("text-")){const[,a]=n.split("-");return`var(--ac-global-text-color-${a})`}return ha(n)},O0=n=>p(p`
      color: ${N0(n)};
    `,Er);function $0(n,a){const{isDisabled:t=!1}=n,{children:l,color:i=t?"text-300":"text-900",size:r="S",weight:o="normal",fontStyle:c="normal",fontFamily:d="default",...u}=n,{styleProps:m,otherProps:h}=aa(u),{className:b,...f}=h;return e(Mi,{className:$("ac-text",`font-${d}`,b),...f,...m,css:p`
        ${O0(i)};
        font-style: ${c};
      `,"data-size":r,"data-weight":o,ref:a,children:l})}const C=g.forwardRef($0);function B0(n,a){const{children:t,level:l=3,weight:i="normal",...r}=n;return e(Fi,{...r,css:p(Er,R0),className:$("ac-Heading",n.className),ref:a,level:l,"data-level":l,"data-weight":i,children:t})}const Q=g.forwardRef(B0),H0=p`
  font-family:
    -apple-system, "system-ui", "Segoe UI", "Noto Sans", Helvetica, Arial,
    sans-serif, "Apple Color Emoji", "Segoe UI Emoji";
`,j0=g.forwardRef(function({children:a,className:t,...l},i){return e("kbd",{ref:i,css:H0,className:$("ac-keyboard",t),...l,children:a})}),Z0=p`
  border: 0;
  clip: rect(0 0 0 0);
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
  height: 1px;
`,Ym=({children:n})=>e("span",{className:"ac-visually-hidden",css:Z0,children:n}),Jm=({children:n,bordered:a=!0})=>e("div",{"data-bordered":a,css:p`
        border-bottom: 1px solid var(--ac-global-border-color-default);
        &[data-bordered="true"] {
          border-top: 1px solid var(--ac-global-border-color-default);
        }
        & > * {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: var(--ac-global-dimension-static-size-100)
            var(--ac-global-dimension-static-size-200);
        }
      `,children:e(Q,{children:n})});function sl(n){const{message:a}=n;return e("div",{css:p`
        width: 100%;
        display: flex;
        justify-content: center;
      `,children:e("div",{css:p`
          margin: var(--ac-global-dimension-size-300);
          display: flex;
          flex-direction: column;
          align-items: center;
        `,children:a&&e(C,{size:"M",color:"text-700",children:a})})})}function U0({error:n}){return e(w,{padding:"size-200",children:s(S,{direction:"column",children:[e(S,{direction:"column",width:"100%",alignItems:"center",children:e("h1",{children:"Something went wrong"})}),e("p",{children:"We strive to do our very best but 🐛 bugs happen. It would mean a lot to us if you could file a an issue. If you feel comfortable, please include the error details below in your issue. We will get back to you as soon as we can."}),e(S,{direction:"row",width:"100%",justifyContent:"end",children:e(fe,{href:"https://github.com/Arize-ai/phoenix/issues/new?assignees=&labels=bug&template=bug_report.md&title=%5BBUG%5D",children:"file an issue with us"})}),s("details",{open:!0,children:[e("summary",{children:"error details"}),e("pre",{css:p`
              white-space: pre-wrap;
              overflow-wrap: break-word;
              overflow: hidden;
              overflow-y: auto;
              max-height: 500px;
            `,children:n})]})]})})}class eg extends g.Component{constructor(a){super(a),this.state={hasError:!1,error:null}}static getDerivedStateFromError(a){return{hasError:!0,error:a}}componentDidCatch(a,t){}render(){if(this.state.hasError){const a=this.state.error instanceof Error?this.state.error.message:null;return typeof this.props.fallback=="function"?e(this.props.fallback,{error:a}):e(U0,{error:a})}return this.props.children}}function ng(n){return s("div",{css:p`
        text-align: center;
        display: flex;
        color: var(--ac-global-text-color-300);
        gap: var(--ac-global-dimension-size-50);
      `,children:[e(x,{svg:e(cl,{})}),e(C,{color:"text-300",children:"error"})]})}const G0=p`
  background-color: var(--ac-global-color-primary-100);
  color: var(--ac-global-color-primary-700);
  padding: var(--ac-global-dimension-static-size-50)
    var(--ac-global-dimension-static-size-100);
  font-size: var(--ac-global-dimension-static-font-size-50);
  border-radius: var(--ac-global-dimension-static-size-100);
  border: 1px solid var(--ac-global-color-primary-200);
  box-shadow: 0 2px 0 0 var(--ac-global-color-primary-200);
  // Offset the shadow to make it look like it's on the key
  margin-top: -1px;
  text-transform: uppercase;
`,ag=g.forwardRef(function({children:a,...t},l){return e(j0,{ref:l,css:G0,...t,children:a})}),U=g.forwardRef(({color:n,size:a="M",shape:t="square"},l)=>{const i=typeof n=="string"&&n.startsWith("var"),r=i?p`
          background-color: ${n} !important;
        `:void 0;return e(ns,{color:i?void 0:n,"data-shape":t,"data-size":a,ref:l,css:p(p`
            --color-swatch-size: 6px;
            width: var(--color-swatch-size);
            height: var(--color-swatch-size);
            display: inline-block;
            &[data-shape="square"] {
              border-radius: 2px;
            }
            &[data-shape="circle"] {
              border-radius: 50%;
            }
            &[data-size="S"] {
              --color-swatch-size: 6px;
            }
            &[data-size="M"] {
              --color-swatch-size: 8px;
            }
            &[data-size="L"] {
              --color-swatch-size: 20px;
            }
          `,r)})});U.displayName="ColorSwatch";const W0=n=>{switch(n){case"info":return e(Wa,{});case"help":default:return e(C2,{})}},Q0=({children:n,variant:a="help",...t})=>s(j,{delay:0,children:[e(D,{css:p`
          & {
            all: unset;
            height: 14px !important;
            width: 14px !important;
            padding: var(--ac-global-dimension-size-50) !important;
            border-radius: var(--ac-global-rounding-small);
            svg {
              height: 14px;
              width: 14px;
            }
          }
        `,variant:"quiet",size:"S",leadingVisual:e(x,{svg:W0(a)})}),e(xe,{...t,children:n})]}),x=({svg:n,isDisabled:a,color:t="inherit",css:l,className:i="",...r})=>{const o=t==="inherit"?"inherit":ha(t);return e("i",{className:$("ac-icon-wrap",i),css:p(p`
          width: 1em;
          height: 1em;
          font-size: 1.2rem;
          color: ${o};
          display: flex;
          svg {
            fill: currentColor;
            width: 1em;
            height: 1em;
            display: inline-block;
            flex-shrink: 0;
            user-select: none;
          }
        `,l),...r,children:n})},q0=Ne`
 100% {
    transform: rotate(360deg);
  }
`,tg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-back",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M19 11H7.14l3.63-4.36a1 1 0 1 0-1.54-1.28l-5 6a1.19 1.19 0 0 0-.09.15c0 .05 0 .08-.07.13A1 1 0 0 0 4 12a1 1 0 0 0 .07.36c0 .05 0 .08.07.13a1.19 1.19 0 0 0 .09.15l5 6A1 1 0 0 0 10 19a1 1 0 0 0 .64-.23 1 1 0 0 0 .13-1.41L7.14 13H19a1 1 0 0 0 0-2z"})]})})}),lg=()=>s("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M7.18367 12.44H18.93C19.4765 12.44 19.92 12.8835 19.92 13.43C19.92 13.9765 19.4765 14.42 18.93 14.42H7.18367L10.7803 18.7364C11.1308 19.1562 11.0734 19.7809 10.6536 20.1303C10.4685 20.2848 10.2438 20.36 10.02 20.36C9.73688 20.36 9.45572 20.2382 9.2597 20.0036L4.3097 14.0636C4.27109 14.0171 4.25129 13.9626 4.22258 13.9111C4.19882 13.8696 4.17011 13.8339 4.15229 13.7884C4.10774 13.6745 4.08101 13.5547 4.08101 13.434C4.08101 13.433 4.08002 13.431 4.08002 13.43C4.08002 13.429 4.08101 13.427 4.08101 13.426C4.08101 13.3053 4.10774 13.1855 4.15229 13.0716C4.17011 13.0261 4.19882 12.9904 4.22258 12.9489C4.41566 12.6026 4.86258 12.476 5.25896 12.4699L7.18367 12.44Z"}),e("path",{d:"M16.8964 11.52H5.15003C4.60355 11.52 4.16003 11.0764 4.16003 10.53C4.16003 9.98348 4.60355 9.53996 5.15003 9.53996H16.8964L13.2997 5.22356C12.9493 4.8038 13.0067 4.17911 13.4264 3.82964C13.6116 3.6752 13.8363 3.59996 14.06 3.59996C14.3432 3.59996 14.6243 3.72173 14.8204 3.95636L19.7704 9.89636C19.809 9.94289 19.8288 9.99734 19.8575 10.0488C19.8812 10.0904 19.9099 10.126 19.9278 10.1716C19.9723 10.2854 19.999 10.4052 19.999 10.526C19.999 10.527 20 10.529 20 10.53C20 10.5309 19.999 10.5329 19.999 10.5339C19.999 10.6547 19.9723 10.7745 19.9278 10.8883C19.9099 10.9339 19.8812 10.9695 19.8575 11.0111C19.6644 11.3573 19.2175 11.4839 18.8211 11.4901L16.8964 11.52Z"})]}),X0=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-ios-back",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M13.83 19a1 1 0 0 1-.78-.37l-4.83-6a1 1 0 0 1 0-1.27l5-6a1 1 0 0 1 1.54 1.28L10.29 12l4.32 5.36a1 1 0 0 1-.78 1.64z"})]})})}),ig=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-downward",children:[e("rect",{width:"24",height:"24",transform:"rotate(-90 12 12)",opacity:"0"}),e("path",{d:"M12 17a1.72 1.72 0 0 1-1.33-.64l-4.21-5.1a2.1 2.1 0 0 1-.26-2.21A1.76 1.76 0 0 1 7.79 8h8.42a1.76 1.76 0 0 1 1.59 1.05 2.1 2.1 0 0 1-.26 2.21l-4.21 5.1A1.72 1.72 0 0 1 12 17z"})]})})}),Kr=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-ios-downward",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 16a1 1 0 0 1-.64-.23l-6-5a1 1 0 1 1 1.28-1.54L12 13.71l5.36-4.32a1 1 0 0 1 1.41.15 1 1 0 0 1-.14 1.46l-6 4.83A1 1 0 0 1 12 16z"})]})})}),rg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-upward",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M5.23 10.64a1 1 0 0 0 1.41.13L11 7.14V19a1 1 0 0 0 2 0V7.14l4.36 3.63a1 1 0 1 0 1.28-1.54l-6-5-.15-.09-.13-.07a1 1 0 0 0-.72 0l-.13.07-.15.09-6 5a1 1 0 0 0-.13 1.41z"})]})})}),og=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-downward",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M18.77 13.36a1 1 0 0 0-1.41-.13L13 16.86V5a1 1 0 0 0-2 0v11.86l-4.36-3.63a1 1 0 1 0-1.28 1.54l6 5 .15.09.13.07a1 1 0 0 0 .72 0l.13-.07.15-.09 6-5a1 1 0 0 0 .13-1.41z"})]})})}),sg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-up",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M16.21 16H7.79a1.76 1.76 0 0 1-1.59-1 2.1 2.1 0 0 1 .26-2.21l4.21-5.1a1.76 1.76 0 0 1 2.66 0l4.21 5.1A2.1 2.1 0 0 1 17.8 15a1.76 1.76 0 0 1-1.59 1z"})]})})}),_r=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"arrow-ios-forward",children:[e("rect",{width:"24",height:"24",transform:"rotate(-90 12 12)",opacity:"0"}),e("path",{d:"M10 19a1 1 0 0 1-.64-.23 1 1 0 0 1-.13-1.41L13.71 12 9.39 6.63a1 1 0 0 1 .15-1.41 1 1 0 0 1 1.46.15l4.83 6a1 1 0 0 1 0 1.27l-5 6A1 1 0 0 1 10 19z"})]})})}),Y0=()=>s("svg",{width:"16",height:"14",viewBox:"0 0 16 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M4.26532 0.250732C4.27852 0.250997 4.29171 0.25124 4.30488 0.252197C4.31815 0.25316 4.33135 0.254215 4.34443 0.255859C4.35326 0.256972 4.36199 0.258826 4.37079 0.260254C4.38486 0.262535 4.39875 0.265258 4.41254 0.268311C4.42087 0.27015 4.42917 0.272043 4.43744 0.27417C4.4879 0.28717 4.53597 0.305717 4.58173 0.328369C4.6532 0.363681 4.7207 0.410213 4.78022 0.469727L7.78022 3.46973C8.07307 3.76261 8.07307 4.23739 7.78022 4.53027C7.48733 4.82316 7.01257 4.82314 6.71967 4.53027L4.99994 2.81055V13C4.99994 13.4142 4.66413 13.75 4.24994 13.75C3.83573 13.75 3.49994 13.4142 3.49994 13V2.81055L1.78022 4.53027C1.48733 4.82316 1.01257 4.82314 0.71967 4.53027C0.426777 4.23738 0.426777 3.76262 0.71967 3.46973L3.71967 0.469727C3.76255 0.426853 3.81103 0.389923 3.86322 0.358398C3.87818 0.349363 3.89321 0.340661 3.90863 0.332764C3.95539 0.308804 4.00478 0.289423 4.05658 0.275635C4.06901 0.272324 4.08138 0.268775 4.09394 0.266113C4.10216 0.264374 4.11052 0.263186 4.11884 0.261719C4.13198 0.259392 4.14517 0.257482 4.15839 0.255859C4.17172 0.254238 4.18514 0.25311 4.19867 0.252197C4.21063 0.251378 4.22259 0.250981 4.23456 0.250732C4.23966 0.25063 4.24482 0.25 4.24994 0.25C4.25509 0.25 4.26021 0.250629 4.26532 0.250732Z"}),e("path",{d:"M11.7499 0.25C12.1641 0.250031 12.4999 0.585805 12.4999 1V11.1895L14.2197 9.46973C14.5126 9.17686 14.9873 9.17684 15.2802 9.46973C15.5731 9.76261 15.5731 10.2374 15.2802 10.5303L12.2802 13.5303C12.2453 13.5652 12.2064 13.5958 12.1652 13.6233C12.1359 13.6429 12.1057 13.6603 12.0744 13.6753C12.0403 13.6917 12.005 13.7059 11.9682 13.717C11.9557 13.7209 11.9428 13.7234 11.9301 13.7266C11.9184 13.7295 11.9069 13.733 11.895 13.7354C11.8896 13.7364 11.8842 13.7366 11.8788 13.7375C11.8369 13.7448 11.794 13.75 11.7499 13.75L11.673 13.7463C11.6569 13.7447 11.6412 13.7409 11.6254 13.7383C11.6176 13.737 11.6098 13.7362 11.602 13.7346C11.5934 13.7329 11.5849 13.7308 11.5764 13.7288C11.5609 13.7251 11.5454 13.7217 11.5302 13.717C11.4937 13.7059 11.4586 13.6916 11.4247 13.6753C11.3949 13.6609 11.3657 13.6448 11.3376 13.6262C11.2951 13.5982 11.2555 13.5661 11.2197 13.5303L8.21967 10.5303C7.92678 10.2374 7.92678 9.76262 8.21967 9.46973C8.51257 9.17686 8.98733 9.17684 9.28022 9.46973L10.9999 11.1895V1C10.9999 0.585786 11.3357 0.25 11.7499 0.25Z"})]}),J0=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"alert-triangle",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M22.56 16.3L14.89 3.58a3.43 3.43 0 0 0-5.78 0L1.44 16.3a3 3 0 0 0-.05 3A3.37 3.37 0 0 0 4.33 21h15.34a3.37 3.37 0 0 0 2.94-1.66 3 3 0 0 0-.05-3.04zm-1.7 2.05a1.31 1.31 0 0 1-1.19.65H4.33a1.31 1.31 0 0 1-1.19-.65 1 1 0 0 1 0-1l7.68-12.73a1.48 1.48 0 0 1 2.36 0l7.67 12.72a1 1 0 0 1 .01 1.01z"}),e("circle",{cx:"12",cy:"16",r:"1"}),e("path",{d:"M12 8a1 1 0 0 0-1 1v4a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"})]})})}),e2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"alert-triangle",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M22.56 16.3L14.89 3.58a3.43 3.43 0 0 0-5.78 0L1.44 16.3a3 3 0 0 0-.05 3A3.37 3.37 0 0 0 4.33 21h15.34a3.37 3.37 0 0 0 2.94-1.66 3 3 0 0 0-.05-3.04zM12 17a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm1-4a1 1 0 0 1-2 0V9a1 1 0 0 1 2 0z"})]})})}),cl=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"alert-circle",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("circle",{cx:"12",cy:"16",r:"1"}),e("path",{d:"M12 7a1 1 0 0 0-1 1v5a1 1 0 0 0 2 0V8a1 1 0 0 0-1-1z"})]})})}),Vr=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"alert-circle",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 15a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm1-4a1 1 0 0 1-2 0V8a1 1 0 0 1 2 0z"})]})})}),n2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"bar-chart",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M12 4a1 1 0 0 0-1 1v15a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1z"}),e("path",{d:"M19 12a1 1 0 0 0-1 1v7a1 1 0 0 0 2 0v-7a1 1 0 0 0-1-1z"}),e("path",{d:"M5 8a1 1 0 0 0-1 1v11a1 1 0 0 0 2 0V9a1 1 0 0 0-1-1z"})]})})}),cg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"book",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M19 3H7a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM7 19a1 1 0 0 1 0-2h11v2z"})]})})}),a2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"book",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M19 3H7a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM7 5h11v10H7a3 3 0 0 0-1 .18V6a1 1 0 0 1 1-1zm0 14a1 1 0 0 1 0-2h11v2z"})]})})}),dg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"bulb",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 7a5 5 0 0 0-3 9v4a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-4a5 5 0 0 0-3-9zm1.5 7.59a1 1 0 0 0-.5.87V20h-2v-4.54a1 1 0 0 0-.5-.87A3 3 0 0 1 9 12a3 3 0 0 1 6 0 3 3 0 0 1-1.5 2.59z"}),e("path",{d:"M12 6a1 1 0 0 0 1-1V3a1 1 0 0 0-2 0v2a1 1 0 0 0 1 1z"}),e("path",{d:"M21 11h-2a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"}),e("path",{d:"M5 11H3a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2z"}),e("path",{d:"M7.66 6.42L6.22 5a1 1 0 0 0-1.39 1.47l1.44 1.39a1 1 0 0 0 .73.28 1 1 0 0 0 .72-.31 1 1 0 0 0-.06-1.41z"}),e("path",{d:"M19.19 5.05a1 1 0 0 0-1.41 0l-1.44 1.37a1 1 0 0 0 0 1.41 1 1 0 0 0 .72.31 1 1 0 0 0 .69-.28l1.44-1.39a1 1 0 0 0 0-1.42z"})]})})}),t2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"calendar",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M18 4h-1V3a1 1 0 0 0-2 0v1H9V3a1 1 0 0 0-2 0v1H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3zM6 6h1v1a1 1 0 0 0 2 0V6h6v1a1 1 0 0 0 2 0V6h1a1 1 0 0 1 1 1v4H5V7a1 1 0 0 1 1-1zm12 14H6a1 1 0 0 1-1-1v-6h14v6a1 1 0 0 1-1 1z"}),e("circle",{cx:"8",cy:"16",r:"1"}),e("path",{d:"M16 15h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2z"})]})})}),l2=()=>s("svg",{xmlns:"http://www.w3.org/2000/svg",height:"24",viewBox:"0 0 18 18",width:"24",children:[e("path",{className:"fill",d:"M14,5.99a1,1,0,0,1-1.7055.7055L9.006,3.409,5.717,6.695A1,1,0,0,1,4.28,5.3085l.0245-.0245L8.3,1.2925a1,1,0,0,1,1.4125,0L13.707,5.284A.99446.99446,0,0,1,14,5.99Z"}),e("path",{className:"fill",d:"M4,12.01a1,1,0,0,1,1.7055-.7055l3.289,3.286,3.289-3.286a1,1,0,0,1,1.437,1.3865l-.0245.0245L9.7,16.707a1,1,0,0,1-1.4125,0L4.293,12.7155A.99452.99452,0,0,1,4,12.01Z"})]}),ug=()=>e("svg",{width:"12",height:"13",viewBox:"0 0 12 13",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M2.2 12.4H9.8C10.0889 12.4 10.375 12.3431 10.6419 12.2325C10.9088 12.122 11.1513 11.9599 11.3556 11.7556C11.5599 11.5513 11.722 11.3088 11.8325 11.0419C11.9431 10.775 12 10.4889 12 10.2V2.2C12 1.91109 11.9431 1.62501 11.8325 1.3581C11.722 1.09118 11.5599 0.848654 11.3556 0.644365C11.1513 0.440076 10.9088 0.278026 10.6419 0.167465C10.375 0.0569049 10.0889 0 9.8 0H2.2C1.61652 0 1.05694 0.231785 0.644365 0.644365C0.231785 1.05694 0 1.61652 0 2.2V10.2C0 10.7835 0.231785 11.3431 0.644365 11.7556C1.05694 12.1682 1.61652 12.4 2.2 12.4ZM4.8 11.2V1.2H7.2V11.2H4.8ZM10.8 2.2V10.2C10.8 10.4652 10.6946 10.7196 10.5071 10.9071C10.3196 11.0946 10.0652 11.2 9.8 11.2H8.4V1.2H9.8C10.0652 1.2 10.3196 1.30536 10.5071 1.49289C10.6946 1.68043 10.8 1.93478 10.8 2.2ZM1.2 2.2C1.2 1.93478 1.30536 1.68043 1.49289 1.49289C1.68043 1.30536 1.93478 1.2 2.2 1.2H3.6V11.2H2.2C1.93478 11.2 1.68043 11.0946 1.49289 10.9071C1.30536 10.7196 1.2 10.4652 1.2 10.2V2.2Z"})}),mg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"corner-up-right",children:[e("rect",{width:"24",height:"24",transform:"rotate(-90 12 12)",opacity:"0"}),e("path",{d:"M19.78 10.38l-4-5a1 1 0 0 0-1.56 1.24l2.7 3.38H8a3 3 0 0 0-3 3v5a1 1 0 0 0 2 0v-5a1 1 0 0 1 1-1h8.92l-2.7 3.38a1 1 0 0 0 .16 1.4A1 1 0 0 0 15 17a1 1 0 0 0 .78-.38l4-5a1 1 0 0 0 0-1.24z"})]})})}),gg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"code",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M8.64 5.23a1 1 0 0 0-1.41.13l-5 6a1 1 0 0 0 0 1.27l4.83 6a1 1 0 0 0 .78.37 1 1 0 0 0 .78-1.63L4.29 12l4.48-5.36a1 1 0 0 0-.13-1.41z"}),e("path",{d:"M21.78 11.37l-4.78-6a1 1 0 0 0-1.41-.15 1 1 0 0 0-.15 1.41L19.71 12l-4.48 5.37a1 1 0 0 0 .13 1.41A1 1 0 0 0 16 19a1 1 0 0 0 .77-.36l5-6a1 1 0 0 0 .01-1.27z"})]})})}),i2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"chevron-left",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M13.36 17a1 1 0 0 1-.72-.31l-3.86-4a1 1 0 0 1 0-1.4l4-4a1 1 0 1 1 1.42 1.42L10.9 12l3.18 3.3a1 1 0 0 1 0 1.41 1 1 0 0 1-.72.29z"})]})})}),Za=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"chevron-right",children:[e("rect",{width:"24",height:"24",transform:"rotate(-90 12 12)",opacity:"0"}),e("path",{d:"M10.5 17a1 1 0 0 1-.71-.29 1 1 0 0 1 0-1.42L13.1 12 9.92 8.69a1 1 0 0 1 0-1.41 1 1 0 0 1 1.42 0l3.86 4a1 1 0 0 1 0 1.4l-4 4a1 1 0 0 1-.7.32z"})]})})}),r2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"chevron-right",children:[e("rect",{width:"24",height:"24",transform:"rotate(-90 12 12)",opacity:"0"}),e("path",{d:"M10.5 17a1 1 0 0 1-.71-.29 1 1 0 0 1 0-1.42L13.1 12 9.92 8.69a1 1 0 0 1 0-1.41 1 1 0 0 1 1.42 0l3.86 4a1 1 0 0 1 0 1.4l-4 4a1 1 0 0 1-.7.32z"})]})})}),Pr=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"chevron-down",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 15.5a1 1 0 0 1-.71-.29l-4-4a1 1 0 1 1 1.42-1.42L12 13.1l3.3-3.18a1 1 0 1 1 1.38 1.44l-4 3.86a1 1 0 0 1-.68.28z"})]})})}),o2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"chevron-down",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 15.5a1 1 0 0 1-.71-.29l-4-4a1 1 0 1 1 1.42-1.42L12 13.1l3.3-3.18a1 1 0 1 1 1.38 1.44l-4 3.86a1 1 0 0 1-.68.28z"})]})})}),pg=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:s("g",{id:"cube",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M20.654 7.24778C20.6545 7.25157 20.655 7.25534 20.6564 7.25891C20.8684 7.62191 20.9994 8.02891 21.0004 8.45691V15.5399C20.9994 16.4879 20.4224 17.3659 19.5304 17.7779L13.1334 20.7499C12.7724 20.9179 12.3844 21.0019 11.9964 21.0019C11.6074 21.0019 11.2194 20.9179 10.8574 20.7489L4.45839 17.7769C3.56439 17.3589 2.99239 16.4749 3.00039 15.5249V8.45791C3.00039 8.02991 3.13139 7.62291 3.34239 7.26091C3.34439 7.25641 3.34514 7.25191 3.34589 7.24741C3.34664 7.24291 3.34739 7.23841 3.34939 7.23391C3.35141 7.22986 3.35446 7.22633 3.35763 7.22266C3.36072 7.21907 3.36392 7.21536 3.36639 7.21091C3.40377 7.14975 3.44764 7.09363 3.49188 7.03705C3.49972 7.02703 3.50756 7.017 3.51539 7.00691C3.52685 6.99407 3.53758 6.98061 3.54827 6.96723C3.56835 6.94207 3.58824 6.91715 3.61239 6.89691C3.84739 6.62091 4.12539 6.37891 4.46939 6.21991L10.8664 3.24791C11.5874 2.91591 12.4124 2.91491 13.1314 3.24691C13.1314 3.24791 13.1324 3.24791 13.1334 3.24791L19.5334 6.22091C19.8774 6.37991 20.1544 6.62291 20.3894 6.89891C20.4111 6.91742 20.4291 6.93959 20.4474 6.96205C20.4577 6.97478 20.4682 6.98761 20.4794 6.99991C20.492 7.01663 20.5049 7.03318 20.5177 7.04972C20.5586 7.10243 20.5994 7.15507 20.6344 7.21291C20.6365 7.21633 20.6392 7.21919 20.6418 7.22198C20.6453 7.22572 20.6487 7.22933 20.6504 7.23391C20.6526 7.23834 20.6533 7.24308 20.654 7.24778ZM11.7074 5.06391C11.7984 5.02091 11.8994 4.99991 12.0004 4.99991C12.1004 4.99991 12.2014 5.02091 12.2924 5.06391L17.6214 7.53791L12.0004 10.1499L6.37839 7.53791L11.7074 5.06391ZM5.00039 15.5319C4.99839 15.7139 5.11439 15.8759 5.30339 15.9639L11.0004 18.6089V11.8909L5.00039 9.10391V15.5319ZM13.0004 18.6069L18.6904 15.9629C18.8824 15.8749 19.0004 15.7129 19.0004 15.5389V9.10391L13.0004 11.8909V18.6069Z"}),e("mask",{id:"mask0_0_196",mask:"alpha",maskUnits:"userSpaceOnUse",x:"3",y:"2",width:"19",height:"20",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M20.654 7.24778C20.6545 7.25157 20.655 7.25534 20.6564 7.25891C20.8684 7.62191 20.9994 8.02891 21.0004 8.45691V15.5399C20.9994 16.4879 20.4224 17.3659 19.5304 17.7779L13.1334 20.7499C12.7724 20.9179 12.3844 21.0019 11.9964 21.0019C11.6074 21.0019 11.2194 20.9179 10.8574 20.7489L4.45839 17.7769C3.56439 17.3589 2.99239 16.4749 3.00039 15.5249V8.45791C3.00039 8.02991 3.13139 7.62291 3.34239 7.26091C3.34439 7.25641 3.34514 7.25191 3.34589 7.24741C3.34664 7.24291 3.34739 7.23841 3.34939 7.23391C3.35141 7.22986 3.35446 7.22633 3.35763 7.22266C3.36072 7.21907 3.36392 7.21536 3.36639 7.21091C3.40377 7.14975 3.44764 7.09363 3.49188 7.03705C3.49972 7.02703 3.50756 7.017 3.51539 7.00691C3.52685 6.99407 3.53758 6.98061 3.54827 6.96723C3.56835 6.94207 3.58824 6.91715 3.61239 6.89691C3.84739 6.62091 4.12539 6.37891 4.46939 6.21991L10.8664 3.24791C11.5874 2.91591 12.4124 2.91491 13.1314 3.24691C13.1314 3.24791 13.1324 3.24791 13.1334 3.24791L19.5334 6.22091C19.8774 6.37991 20.1544 6.62291 20.3894 6.89891C20.4111 6.91742 20.4291 6.93959 20.4474 6.96205C20.4577 6.97478 20.4682 6.98761 20.4794 6.99991C20.492 7.01663 20.5049 7.03318 20.5177 7.04972C20.5586 7.10243 20.5994 7.15507 20.6344 7.21291C20.6365 7.21633 20.6392 7.21919 20.6418 7.22198C20.6453 7.22572 20.6487 7.22933 20.6504 7.23391C20.6526 7.23834 20.6533 7.24308 20.654 7.24778ZM11.7074 5.06391C11.7984 5.02091 11.8994 4.99991 12.0004 4.99991C12.1004 4.99991 12.2014 5.02091 12.2924 5.06391L17.6214 7.53791L12.0004 10.1499L6.37839 7.53791L11.7074 5.06391ZM5.00039 15.5319C4.99839 15.7139 5.11439 15.8759 5.30339 15.9639L11.0004 18.6089V11.8909L5.00039 9.10391V15.5319ZM13.0004 18.6069L18.6904 15.9629C18.8824 15.8749 19.0004 15.7129 19.0004 15.5389V9.10391L13.0004 11.8909V18.6069Z"})}),e("g",{mask:"url(#mask0_0_196)"})]})}),s2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"clock",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("path",{d:"M16 11h-3V8a1 1 0 0 0-2 0v4a1 1 0 0 0 1 1h4a1 1 0 0 0 0-2z"})]})})}),dl=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"checkmark",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M9.86 18a1 1 0 0 1-.73-.32l-4.86-5.17a1 1 0 1 1 1.46-1.37l4.12 4.39 8.41-9.2a1 1 0 1 1 1.48 1.34l-9.14 10a1 1 0 0 1-.73.33z"})]})})}),Ua=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"checkmark",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M9.86 18a1 1 0 0 1-.73-.32l-4.86-5.17a1 1 0 1 1 1.46-1.37l4.12 4.39 8.41-9.2a1 1 0 1 1 1.48 1.34l-9.14 10a1 1 0 0 1-.73.33z"})]})})}),Rr=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:s("g",{children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M20.997 10.9741H21C21.551 10.9741 21.999 11.4201 22 11.9711C22.008 14.6421 20.975 17.1571 19.091 19.0511C17.208 20.9451 14.7 21.9921 12.029 22.0001H12C9.339 22.0001 6.836 20.9681 4.949 19.0911C3.055 17.2081 2.008 14.7001 2 12.0291C1.992 9.3571 3.025 6.8431 4.909 4.9491C6.792 3.0551 9.3 2.0081 11.971 2.0001C12.766 2.0121 13.576 2.0921 14.352 2.2781C14.888 2.4081 15.219 2.9481 15.089 3.4851C14.96 4.0211 14.417 4.3511 13.883 4.2231C13.262 4.0731 12.603 4.0101 11.977 4.0001C9.84 4.0061 7.833 4.8441 6.327 6.3591C4.82 7.8741 3.994 9.8861 4 12.0231C4.006 14.1601 4.844 16.1661 6.359 17.6731C7.869 19.1741 9.871 20.0001 12 20.0001H12.023C14.16 19.9941 16.167 19.1561 17.673 17.6411C19.18 16.1251 20.006 14.1141 20 11.9771C19.999 11.4251 20.445 10.9751 20.997 10.9741ZM8.293 11.293C8.684 10.902 9.316 10.902 9.707 11.293L11.951 13.537L18.248 6.341C18.612 5.928 19.243 5.884 19.659 6.248C20.074 6.611 20.116 7.243 19.752 7.659L12.752 15.659C12.57 15.867 12.31 15.99 12.033 16H12C11.735 16 11.481 15.895 11.293 15.707L8.293 12.707C7.902 12.316 7.902 11.684 8.293 11.293Z"}),e("mask",{mask:"alpha",maskUnits:"userSpaceOnUse",x:"2",y:"2",width:"20",height:"20",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M20.997 10.9741H21C21.551 10.9741 21.999 11.4201 22 11.9711C22.008 14.6421 20.975 17.1571 19.091 19.0511C17.208 20.9451 14.7 21.9921 12.029 22.0001H12C9.339 22.0001 6.836 20.9681 4.949 19.0911C3.055 17.2081 2.008 14.7001 2 12.0291C1.992 9.3571 3.025 6.8431 4.909 4.9491C6.792 3.0551 9.3 2.0081 11.971 2.0001C12.766 2.0121 13.576 2.0921 14.352 2.2781C14.888 2.4081 15.219 2.9481 15.089 3.4851C14.96 4.0211 14.417 4.3511 13.883 4.2231C13.262 4.0731 12.603 4.0101 11.977 4.0001C9.84 4.0061 7.833 4.8441 6.327 6.3591C4.82 7.8741 3.994 9.8861 4 12.0231C4.006 14.1601 4.844 16.1661 6.359 17.6731C7.869 19.1741 9.871 20.0001 12 20.0001H12.023C14.16 19.9941 16.167 19.1561 17.673 17.6411C19.18 16.1251 20.006 14.1141 20 11.9771C19.999 11.4251 20.445 10.9751 20.997 10.9741ZM8.293 11.293C8.684 10.902 9.316 10.902 9.707 11.293L11.951 13.537L18.248 6.341C18.612 5.928 19.243 5.884 19.659 6.248C20.074 6.611 20.116 7.243 19.752 7.659L12.752 15.659C12.57 15.867 12.31 15.99 12.033 16H12C11.735 16 11.481 15.895 11.293 15.707L8.293 12.707C7.902 12.316 7.902 11.684 8.293 11.293Z"})}),e("g",{mask:"url(#mask0)"})]})}),ul=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"checkmark-circle-2",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm4.3 7.61l-4.57 6a1 1 0 0 1-.79.39 1 1 0 0 1-.79-.38l-2.44-3.11a1 1 0 0 1 1.58-1.23l1.63 2.08 3.78-5a1 1 0 1 1 1.6 1.22z"})]})})}),c2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"close-circle",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm2.71 11.29a1 1 0 0 1 0 1.42 1 1 0 0 1-1.42 0L12 13.41l-1.29 1.3a1 1 0 0 1-1.42 0 1 1 0 0 1 0-1.42l1.3-1.29-1.3-1.29a1 1 0 0 1 1.42-1.42l1.29 1.3 1.29-1.3a1 1 0 0 1 1.42 1.42L13.41 12z"})]})})}),Ga=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"close",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29-4.3 4.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4.29-4.3 4.29 4.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"})]})})}),hg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"close-circle",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("path",{d:"M14.71 9.29a1 1 0 0 0-1.42 0L12 10.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l1.3 1.29-1.3 1.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l1.29-1.3 1.29 1.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L13.41 12l1.3-1.29a1 1 0 0 0 0-1.42z"})]})})}),Nr=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"clipboard",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M18 5V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v1a3 3 0 0 0-3 3v11a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V8a3 3 0 0 0-3-3zM8 4h8v4H8V4zm11 15a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1v1a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7a1 1 0 0 1 1 1z"})]})})}),fg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"collapse",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M19 9h-2.58l3.29-3.29a1 1 0 1 0-1.42-1.42L15 7.57V5a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2z"}),e("path",{d:"M10 13H5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L9 16.42V19a1 1 0 0 0 1 1 1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1z"})]})})}),bg=()=>s("svg",{width:"24",height:"24",viewBox:"0 0 24 24",stroke:"currentColor",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M12 8.66669C16.1421 8.66669 19.5 7.5474 19.5 6.16669C19.5 4.78598 16.1421 3.66669 12 3.66669C7.85786 3.66669 4.5 4.78598 4.5 6.16669C4.5 7.5474 7.85786 8.66669 12 8.66669Z",strokeWidth:"2",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"}),e("path",{d:"M19.5 12C19.5 13.3833 16.1667 14.5 12 14.5C7.83333 14.5 4.5 13.3833 4.5 12",strokeWidth:"2",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"}),e("path",{d:"M4.5 6.16669V17.8334C4.5 19.2167 7.83333 20.3334 12 20.3334C16.1667 20.3334 19.5 19.2167 19.5 17.8334V6.16669",strokeWidth:"2",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"})]}),yg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"download",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("rect",{x:"4",y:"18",width:"16",height:"2",rx:"1",ry:"1"}),e("rect",{x:"3",y:"17",width:"4",height:"2",rx:"1",ry:"1",transform:"rotate(-90 5 18)"}),e("rect",{x:"17",y:"17",width:"4",height:"2",rx:"1",ry:"1",transform:"rotate(-90 19 18)"}),e("path",{d:"M12 15a1 1 0 0 1-.58-.18l-4-2.82a1 1 0 0 1-.24-1.39 1 1 0 0 1 1.4-.24L12 12.76l3.4-2.56a1 1 0 0 1 1.2 1.6l-4 3a1 1 0 0 1-.6.2z"}),e("path",{d:"M12 13a1 1 0 0 1-1-1V4a1 1 0 0 1 2 0v8a1 1 0 0 1-1 1z"})]})})}),vg=()=>s("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9 13V12C9 10.346 10.346 9 12 9H13V5.667C13 5.299 12.701 5 12.333 5H5.667C5.299 5 5 5.299 5 5.667V12.333C5 12.701 5.299 13 5.667 13H9ZM9 15H5.667C4.196 15 3 13.804 3 12.333V5.667C3 4.196 4.196 3 5.667 3H12.333C13.804 3 15 4.196 15 5.667V9H18C19.654 9 21 10.346 21 12V18C21 19.654 19.654 21 18 21H12C10.346 21 9 19.654 9 18V15ZM12 11C11.449 11 11 11.449 11 12V18C11 18.551 11.449 19 12 19H18C18.552 19 19 18.551 19 18V12C19 11.449 18.552 11 18 11H12Z"}),e("mask",{id:"mask0_725_12898",style:{maskType:"alpha"},maskUnits:"userSpaceOnUse",x:"3",y:"3",width:"18",height:"18",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9 13V12C9 10.346 10.346 9 12 9H13V5.667C13 5.299 12.701 5 12.333 5H5.667C5.299 5 5 5.299 5 5.667V12.333C5 12.701 5.299 13 5.667 13H9ZM9 15H5.667C4.196 15 3 13.804 3 12.333V5.667C3 4.196 4.196 3 5.667 3H12.333C13.804 3 15 4.196 15 5.667V9H18C19.654 9 21 10.346 21 12V18C21 19.654 19.654 21 18 21H12C10.346 21 9 19.654 9 18V15ZM12 11C11.449 11 11 11.449 11 12V18C11 18.551 11.449 19 12 19H18C18.552 19 19 18.551 19 18V12C19 11.449 18.552 11 18 11H12Z"})}),e("g",{mask:"url(#mask0_725_12898)"})]}),Cg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"edit",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M19.4 7.34L16.66 4.6A2 2 0 0 0 14 4.53l-9 9a2 2 0 0 0-.57 1.21L4 18.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 20h.09l4.17-.38a2 2 0 0 0 1.21-.57l9-9a1.92 1.92 0 0 0-.07-2.71zM9.08 17.62l-3 .28.27-3L12 9.32l2.7 2.7zM16 10.68L13.32 8l1.95-2L18 8.73z"})]})})}),kg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"edit-2",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M19 20H5a1 1 0 0 0 0 2h14a1 1 0 0 0 0-2z"}),e("path",{d:"M5 18h.09l4.17-.38a2 2 0 0 0 1.21-.57l9-9a1.92 1.92 0 0 0-.07-2.71L16.66 2.6A2 2 0 0 0 14 2.53l-9 9a2 2 0 0 0-.57 1.21L4 16.91a1 1 0 0 0 .29.8A1 1 0 0 0 5 18zM15.27 4L18 6.73l-2 1.95L13.32 6zm-8.9 8.91L12 7.32l2.7 2.7-5.6 5.6-3 .28z"})]})})}),d2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"external-link",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M20 11a1 1 0 0 0-1 1v6a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h6a1 1 0 0 0 0-2H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-6a1 1 0 0 0-1-1z"}),e("path",{d:"M16 5h1.58l-6.29 6.28a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L19 6.42V8a1 1 0 0 0 1 1 1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-4a1 1 0 0 0 0 2z"})]})})}),Lg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"expand",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M20 5a1 1 0 0 0-1-1h-5a1 1 0 0 0 0 2h2.57l-3.28 3.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0L18 7.42V10a1 1 0 0 0 1 1 1 1 0 0 0 1-1z"}),e("path",{d:"M10.71 13.29a1 1 0 0 0-1.42 0L6 16.57V14a1 1 0 0 0-1-1 1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h5a1 1 0 0 0 0-2H7.42l3.29-3.29a1 1 0 0 0 0-1.42z"})]})})}),Sg=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M11.7325 8.3969L12.9778 9.61741L5.58892 16.9977C4.90368 17.6822 3.79253 17.6823 3.10751 16.9981C2.42238 16.3137 2.42238 15.2042 3.10751 14.5198L10.4967 7.13917L11.7245 8.38888L11.7244 8.38895L11.7325 8.3969Z",stroke:"currentColor",strokeWidth:"1.2",fill:"none"}),e("circle",{cx:"12",cy:"5",r:"0.75",stroke:"currentColor",strokeWidth:"0.5",fill:"none"}),e("circle",{cx:"15",cy:"4",r:"0.75",stroke:"currentColor",strokeWidth:"0.5",fill:"none"}),e("circle",{cx:"14.5",cy:"7.5",r:"1.2",stroke:"currentColor",strokeWidth:"0.6",fill:"none"})]}),u2=()=>s("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9.77475 4.16985C14.7548 4.01401 17.6914 8.65901 18.2231 9.58568C18.3698 9.84235 18.3698 10.1582 18.2231 10.4148C17.5114 11.6557 14.8314 15.7132 10.2256 15.8307C10.1573 15.8323 10.0889 15.8332 10.0206 15.8332C5.13475 15.8332 2.30142 11.329 1.77725 10.4148C1.62975 10.1582 1.62975 9.84235 1.77725 9.58568C2.48892 8.34485 5.16808 4.28651 9.77475 4.16985ZM10.1831 14.1648C6.59475 14.2482 4.25392 11.179 3.47725 9.99651C4.33225 8.65901 6.48558 5.92068 9.81725 5.83568C13.3914 5.74485 15.7456 8.82151 16.5223 10.004C15.6681 11.3415 13.5139 14.0798 10.1831 14.1648ZM7.08333 10.0002C7.08333 8.39185 8.39167 7.08351 10 7.08351C11.6083 7.08351 12.9167 8.39185 12.9167 10.0002C12.9167 11.6085 11.6083 12.9168 10 12.9168C8.39167 12.9168 7.08333 11.6085 7.08333 10.0002ZM8.75 10.0002C8.75 10.6893 9.31083 11.2502 10 11.2502C10.6892 11.2502 11.25 10.6893 11.25 10.0002C11.25 9.31101 10.6892 8.75018 10 8.75018C9.31083 8.75018 8.75 9.31101 8.75 10.0002Z"}),e("mask",{id:"mask0_935_15127",style:{maskType:"alpha"},maskUnits:"userSpaceOnUse",x:"1",y:"4",width:"18",height:"12",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9.77475 4.16985C14.7548 4.01401 17.6914 8.65901 18.2231 9.58568C18.3698 9.84235 18.3698 10.1582 18.2231 10.4148C17.5114 11.6557 14.8314 15.7132 10.2256 15.8307C10.1573 15.8323 10.0889 15.8332 10.0206 15.8332C5.13475 15.8332 2.30142 11.329 1.77725 10.4148C1.62975 10.1582 1.62975 9.84235 1.77725 9.58568C2.48892 8.34485 5.16808 4.28651 9.77475 4.16985ZM10.1831 14.1648C6.59475 14.2482 4.25392 11.179 3.47725 9.99651C4.33225 8.65901 6.48558 5.92068 9.81725 5.83568C13.3914 5.74485 15.7456 8.82151 16.5223 10.004C15.6681 11.3415 13.5139 14.0798 10.1831 14.1648ZM7.08333 10.0002C7.08333 8.39185 8.39167 7.08351 10 7.08351C11.6083 7.08351 12.9167 8.39185 12.9167 10.0002C12.9167 11.6085 11.6083 12.9168 10 12.9168C8.39167 12.9168 7.08333 11.6085 7.08333 10.0002ZM8.75 10.0002C8.75 10.6893 9.31083 11.2502 10 11.2502C10.6892 11.2502 11.25 10.6893 11.25 10.0002C11.25 9.31101 10.6892 8.75018 10 8.75018C9.31083 8.75018 8.75 9.31101 8.75 10.0002Z"})}),e("g",{mask:"url(#mask0_935_15127)"})]}),m2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"eye-off",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M4.71 3.29a1 1 0 0 0-1.42 1.42l5.63 5.63a3.5 3.5 0 0 0 4.74 4.74l5.63 5.63a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM12 13.5a1.5 1.5 0 0 1-1.5-1.5v-.07l1.56 1.56z"}),e("path",{d:"M12.22 17c-4.3.1-7.12-3.59-8-5a13.7 13.7 0 0 1 2.24-2.72L5 7.87a15.89 15.89 0 0 0-2.87 3.63 1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25a9.48 9.48 0 0 0 3.23-.67l-1.58-1.58a7.74 7.74 0 0 1-1.7.25z"}),e("path",{d:"M21.87 11.5c-.64-1.11-4.17-6.68-10.14-6.5a9.48 9.48 0 0 0-3.23.67l1.58 1.58a7.74 7.74 0 0 1 1.7-.25c4.29-.11 7.11 3.59 8 5a13.7 13.7 0 0 1-2.29 2.72L19 16.13a15.89 15.89 0 0 0 2.91-3.63 1 1 0 0 0-.04-1z"})]})})}),wg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"file",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M19.74 8.33l-5.44-6a1 1 0 0 0-.74-.33h-7A2.53 2.53 0 0 0 4 4.5v15A2.53 2.53 0 0 0 6.56 22h10.88A2.53 2.53 0 0 0 20 19.5V9a1 1 0 0 0-.26-.67zM17.65 9h-3.94a.79.79 0 0 1-.71-.85V4h.11zm-.21 11H6.56a.53.53 0 0 1-.56-.5v-15a.53.53 0 0 1 .56-.5H11v4.15A2.79 2.79 0 0 0 13.71 11H18v8.5a.53.53 0 0 1-.56.5z"})]})})}),g2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 24 24",children:s("g",{"data-name":"Layer 2",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 1A10.89 10.89 0 0 0 1 11.77 10.79 10.79 0 0 0 8.52 22c.55.1.75-.23.75-.52v-1.83c-3.06.65-3.71-1.44-3.71-1.44a2.86 2.86 0 0 0-1.22-1.58c-1-.66.08-.65.08-.65a2.31 2.31 0 0 1 1.68 1.11 2.37 2.37 0 0 0 3.2.89 2.33 2.33 0 0 1 .7-1.44c-2.44-.27-5-1.19-5-5.32a4.15 4.15 0 0 1 1.11-2.91 3.78 3.78 0 0 1 .11-2.84s.93-.29 3 1.1a10.68 10.68 0 0 1 5.5 0c2.1-1.39 3-1.1 3-1.1a3.78 3.78 0 0 1 .11 2.84A4.15 4.15 0 0 1 19 11.2c0 4.14-2.58 5.05-5 5.32a2.5 2.5 0 0 1 .75 2v2.95c0 .35.2.63.75.52A10.8 10.8 0 0 0 23 11.77 10.89 10.89 0 0 0 12 1"})]})}),Or=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"grid",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M9 3H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"}),e("path",{d:"M19 3h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"}),e("path",{d:"M9 13H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2z"}),e("path",{d:"M19 13h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2z"})]})})}),xg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"grid",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M9 3H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zM5 9V5h4v4z"}),e("path",{d:"M19 3h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm-4 6V5h4v4z"}),e("path",{d:"M9 13H5a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2zm-4 6v-4h4v4z"}),e("path",{d:"M19 13h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2zm-4 6v-4h4v4z"})]})})}),Ql=()=>s("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6.88518 8.68896C7.75814 8.4835 8.40614 9.00284 8.68987 9.55225C8.95537 10.0667 8.99811 10.7297 8.74748 11.3081C8.5089 11.8599 8.44142 12.4705 8.55412 13.061C8.6669 13.6517 8.9541 14.1955 9.37932 14.6206C9.80454 15.0457 10.3483 15.3332 10.9389 15.4458C11.5295 15.5583 12.141 15.4903 12.6928 15.2515C13.2706 15.0017 13.9337 15.0425 14.4487 15.3081C14.9995 15.5924 15.5175 16.2418 15.311 17.1147C15.0236 18.3268 14.4175 19.4414 13.5561 20.3413C12.6946 21.2412 11.608 21.8949 10.4096 22.2349C9.21104 22.5748 7.94245 22.5885 6.73674 22.2749C5.53125 21.9612 4.43113 21.3314 3.55022 20.4507C2.66926 19.5698 2.0389 18.4697 1.72502 17.2642C1.41119 16.0584 1.42527 14.79 1.76506 13.5913C2.10485 12.3928 2.75795 11.3064 3.65764 10.4448C4.5575 9.58317 5.67196 8.97749 6.8842 8.68994L6.88518 8.68896ZM6.79924 10.8003C6.14594 11.0366 5.54625 11.4058 5.04143 11.8892C4.39866 12.5047 3.9316 13.281 3.68889 14.1372C3.44624 14.9934 3.43642 15.899 3.66057 16.7603C3.88477 17.6214 4.33503 18.4075 4.96428 19.0366C5.59353 19.6656 6.37957 20.1153 7.24065 20.3394C8.10182 20.5633 9.00763 20.5538 9.86369 20.311C10.7196 20.0682 11.4955 19.6011 12.1108 18.9585C12.5943 18.4534 12.9624 17.8525 13.1987 17.1987C12.3568 17.5028 11.4468 17.578 10.5639 17.4097C9.57969 17.2219 8.67386 16.743 7.96526 16.0347C7.25661 15.3261 6.77721 14.4204 6.58928 13.436C6.42069 12.5527 6.495 11.6425 6.79924 10.8003Z"}),e("path",{d:"M11.5004 7.49951C12.8265 7.49953 14.0979 8.02669 15.0356 8.96436C15.9732 9.90203 16.5004 11.1734 16.5004 12.4995C16.5004 13.0518 16.0527 13.4995 15.5004 13.4995C14.9481 13.4995 14.5004 13.0518 14.5004 12.4995C14.5004 11.7039 14.1841 10.941 13.6215 10.3784C13.0589 9.81583 12.296 9.49953 11.5004 9.49951C10.9481 9.49951 10.5004 9.0518 10.5004 8.49951C10.5004 7.94723 10.9481 7.49951 11.5004 7.49951Z"}),e("path",{d:"M21.5004 11.4995C22.0527 11.4996 22.5004 11.9473 22.5004 12.4995C22.5004 13.0518 22.0527 13.4995 21.5004 13.4995H19.5004C18.9481 13.4995 18.5004 13.0518 18.5004 12.4995C18.5004 11.9472 18.9481 11.4995 19.5004 11.4995H21.5004Z"}),e("path",{d:"M17.7934 4.79248C18.1839 4.40207 18.8169 4.40206 19.2074 4.79248C19.5978 5.18298 19.5978 5.81604 19.2074 6.20654L17.9516 7.4624C17.5611 7.85289 16.9281 7.85283 16.5375 7.4624C16.1471 7.07187 16.147 6.43884 16.5375 6.04834L17.7934 4.79248Z"}),e("path",{d:"M11.5004 1.49951C12.0527 1.49955 12.5004 1.94725 12.5004 2.49951V4.49951C12.5004 5.05177 12.0527 5.49947 11.5004 5.49951C10.9481 5.49951 10.5004 5.0518 10.5004 4.49951V2.49951C10.5004 1.94723 10.9481 1.49951 11.5004 1.49951Z"})]}),p2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"info",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 14a1 1 0 0 1-2 0v-5a1 1 0 0 1 2 0zm-1-7a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"})]})})}),Wa=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"info",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("circle",{cx:"12",cy:"8",r:"1"}),e("path",{d:"M12 10a1 1 0 0 0-1 1v5a1 1 0 0 0 2 0v-5a1 1 0 0 0-1-1z"})]})})}),h2=()=>e("svg",{width:"20",height:"20",viewBox:"0 0 20 20",xmlns:"http://www.w3.org/2000/svg",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.2257 11.8L11.7393 8.41153C11.7109 8.22144 11.7902 8.03189 11.9431 7.9217C12.0956 7.81142 12.2951 7.79984 12.4586 7.89091L16.2173 9.99324C17.4623 8.99204 18.1154 7.77352 18.1154 6.53971C18.1154 5.16011 17.2989 3.79965 15.7513 2.74073C14.2085 1.6851 12.0218 1 9.55769 1C7.09362 1 4.90688 1.6851 3.36408 2.74073C1.81649 3.79965 1 5.16011 1 6.53971C1 7.9193 1.81649 9.27976 3.36408 10.3387C3.42007 10.377 3.4769 10.4148 3.53457 10.4521C3.57721 10.4488 3.6203 10.447 3.66378 10.447C4.25644 10.447 4.7771 10.7654 5.0742 11.2456C6.36894 11.7696 7.9006 12.0794 9.55769 12.0794C10.4938 12.0794 11.3898 11.9805 12.2257 11.8ZM12.3681 12.7921C11.4796 12.9789 10.5358 13.0794 9.55769 13.0794C8.03657 13.0794 6.59844 12.8363 5.32179 12.4037C5.2538 12.9334 4.95341 13.3874 4.5299 13.6526C4.61517 13.7612 4.70537 13.8853 4.79522 14.0242C5.16436 14.5947 5.54041 15.4345 5.51764 16.4699C5.49439 17.5267 5.00709 18.3616 4.55343 18.915C4.32482 19.1938 4.0981 19.4095 3.92766 19.5564C3.84217 19.63 3.77007 19.687 3.71793 19.7265C3.69184 19.7463 3.67068 19.7618 3.65525 19.7728L3.6365 19.7861L3.63052 19.7902L3.62841 19.7917L3.62759 19.7922L3.62723 19.7925C3.62707 19.7926 3.62691 19.7927 3.34519 19.379L3.62691 19.7927C3.39879 19.9479 3.08774 19.8884 2.93215 19.66C2.7767 19.4317 2.83526 19.1211 3.06288 18.9658L3.06295 18.9658L3.06304 18.9657L3.06326 18.9655L3.07183 18.9595C3.08034 18.9534 3.0943 18.9432 3.11293 18.9291C3.15023 18.9008 3.20601 18.8569 3.27421 18.7981C3.41116 18.6801 3.59512 18.5051 3.77969 18.28C4.15237 17.8254 4.50136 17.1997 4.51794 16.4459C4.53499 15.6707 4.25394 15.0268 3.95603 14.5663C3.80773 14.3371 3.65843 14.1585 3.54764 14.0386C3.49243 13.9788 3.44732 13.9342 3.41742 13.9058C3.40487 13.8938 3.39504 13.8848 3.38831 13.8787C2.59563 13.743 1.99119 13.0317 1.99119 12.1745C1.99119 11.6923 2.18248 11.2563 2.49096 10.9429C0.943505 9.78084 0 8.23567 0 6.53971C0 2.92793 4.27912 0 9.55769 0C14.8363 0 19.1154 2.92793 19.1154 6.53971C19.1154 8.03471 18.3822 9.41255 17.1485 10.5141L19.7425 11.965C19.9297 12.0691 20.029 12.285 19.9925 12.4988C19.9907 12.5093 19.9885 12.5192 19.9863 12.5291C19.9347 12.7525 19.7439 12.912 19.5215 12.9178L15.7303 13.0197C15.5329 13.0249 15.3583 13.1512 15.286 13.341L13.8962 16.9857C13.8153 17.1997 13.6049 17.3304 13.384 17.304C13.1626 17.2776 12.9862 17.1018 12.9542 16.8745L12.3681 12.7921ZM3.36757 11.5227C3.15331 11.6367 2.99119 11.872 2.99119 12.1745C2.99119 12.607 3.3225 12.902 3.66378 12.902C4.00506 12.902 4.33638 12.607 4.33638 12.1745C4.33638 12.1174 4.3306 12.0627 4.31979 12.0108C3.98738 11.8615 3.66939 11.6984 3.36757 11.5227Z"})}),Tg=()=>s("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e("circle",{cx:"12",cy:"12",r:"10",fill:"none"}),e("circle",{cx:"12",cy:"12",r:"4",fill:"none"}),e("line",{x1:"4.93",y1:"4.93",x2:"9.17",y2:"9.17"}),e("line",{x1:"14.83",y1:"14.83",x2:"19.07",y2:"19.07"}),e("line",{x1:"14.83",y1:"9.17",x2:"19.07",y2:"4.93"}),e("line",{x1:"14.83",y1:"9.17",x2:"18.36",y2:"5.64"}),e("line",{x1:"4.93",y1:"19.07",x2:"9.17",y2:"14.83"})]}),$r=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"list",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("circle",{cx:"4",cy:"7",r:"1"}),e("circle",{cx:"4",cy:"12",r:"1"}),e("circle",{cx:"4",cy:"17",r:"1"}),e("rect",{x:"7",y:"11",width:"14",height:"2",rx:".94",ry:".94"}),e("rect",{x:"7",y:"16",width:"14",height:"2",rx:".94",ry:".94"}),e("rect",{x:"7",y:"6",width:"14",height:"2",rx:".94",ry:".94"})]})})}),Br=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",css:p`
      animation: ${q0} 1s infinite linear;
    `,children:s("g",{id:"loading",children:[e("mask",{id:"mask0_804_24",style:{maskType:"alpha"},maskUnits:"userSpaceOnUse",x:"2",y:"2",width:"20",height:"20",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M2 12C2 6.486 6.486 2 12 2C17.514 2 22 6.486 22 12C22 17.514 17.514 22 12 22C6.486 22 2 17.514 2 12ZM4 12C4 16.411 7.589 20 12 20C16.411 20 20 16.411 20 12C20 7.589 16.411 4 12 4C7.589 4 4 7.589 4 12Z",fill:"inherit"})}),e("g",{mask:"url(#mask0_804_24)",children:e("path",{id:"Union",fillRule:"evenodd",clipRule:"evenodd",d:"M15.8268 2.7612C14.6136 2.25866 13.3132 2 12 2C11.4477 2 11 2.44772 11 3C11 3.55228 11.4477 4 12 4V12H20C20 12.5523 20.4477 13 21 13C21.5523 13 22 12.5523 22 12C22 10.6868 21.7413 9.38642 21.2388 8.17317C20.7362 6.95991 19.9997 5.85752 19.0711 4.92893C18.1425 4.00035 17.0401 3.26375 15.8268 2.7612Z",fill:"inherit"})})]})}),Ig=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"log-out",children:[e("rect",{width:"24",height:"24",transform:"rotate(90 12 12)",opacity:"0"}),e("path",{d:"M7 6a1 1 0 0 0 0-2H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h2a1 1 0 0 0 0-2H6V6z"}),e("path",{d:"M20.82 11.42l-2.82-4a1 1 0 0 0-1.39-.24 1 1 0 0 0-.24 1.4L18.09 11H10a1 1 0 0 0 0 2h8l-1.8 2.4a1 1 0 0 0 .2 1.4 1 1 0 0 0 .6.2 1 1 0 0 0 .8-.4l3-4a1 1 0 0 0 .02-1.18z"})]})})}),zg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"message-square",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("circle",{cx:"12",cy:"11",r:"1"}),e("circle",{cx:"16",cy:"11",r:"1"}),e("circle",{cx:"8",cy:"11",r:"1"}),e("path",{d:"M19 3H5a3 3 0 0 0-3 3v15a1 1 0 0 0 .51.87A1 1 0 0 0 3 22a1 1 0 0 0 .51-.14L8 19.14a1 1 0 0 1 .55-.14H19a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm1 13a1 1 0 0 1-1 1H8.55a3 3 0 0 0-1.55.43l-3 1.8V6a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1z"})]})})}),ql=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"minus-circle",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("path",{d:"M15 11H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2z"})]})})}),Xl=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M12.279 21.9783H12.179C10.8075 21.9678 9.4519 21.6838 8.19154 21.1429C6.93119 20.602 5.79142 19.8151 4.83898 18.8283C3.07283 16.9395 2.06886 14.4636 2.02085 11.8782C1.97283 9.29278 2.88417 6.78124 4.57898 4.82825C5.67086 3.60459 7.04351 2.66433 8.57898 2.08825C8.75814 2.01931 8.95336 2.00339 9.14133 2.0424C9.32929 2.08142 9.50205 2.1737 9.63898 2.30825C9.7658 2.43757 9.85511 2.59891 9.89738 2.77503C9.93965 2.95116 9.93329 3.13546 9.87898 3.30825C9.33094 4.80919 9.22236 6.4353 9.56598 7.99577C9.9096 9.55625 10.6912 10.9863 11.819 12.1183C12.9573 13.2426 14.3908 14.0215 15.9535 14.3649C17.5162 14.7082 19.1442 14.6019 20.649 14.0583C20.8281 13.9952 21.0214 13.9845 21.2064 14.0273C21.3914 14.0701 21.5604 14.1646 21.6936 14.3C21.8268 14.4353 21.9188 14.6057 21.9587 14.7913C21.9986 14.977 21.9848 15.1701 21.919 15.3483C21.4081 16.712 20.6101 17.9499 19.579 18.9783C18.6198 19.9346 17.4811 20.6919 16.2284 21.2067C14.9756 21.7216 13.6334 21.9838 12.279 21.9783ZM7.43898 4.89825C6.93666 5.25055 6.47691 5.65995 6.06898 6.11825C4.69352 7.69439 3.9524 9.72517 3.98935 11.8168C4.02631 13.9083 4.8387 15.9117 6.26898 17.4382C7.03751 18.2364 7.95825 18.8725 8.97678 19.3087C9.99531 19.745 11.091 19.9727 12.199 19.9783H12.279C13.6052 19.9775 14.9121 19.6605 16.0912 19.0535C17.2704 18.4466 18.2878 17.5671 19.059 16.4883C17.4873 16.6919 15.8899 16.5326 14.3894 16.0226C12.8889 15.5127 11.5253 14.6656 10.4032 13.5464C9.28114 12.4272 8.43051 11.0658 7.91666 9.5666C7.40281 8.06743 7.2394 6.47042 7.43898 4.89825Z"})}),Hr=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"more-horizotnal",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("circle",{cx:"12",cy:"12",r:"2"}),e("circle",{cx:"19",cy:"12",r:"2"}),e("circle",{cx:"5",cy:"12",r:"2"})]})})}),f2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"move",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M21.71 11.31l-3-3a1 1 0 0 0-1.42 1.42L18.58 11H13V5.41l1.29 1.3A1 1 0 0 0 15 7a1 1 0 0 0 .71-.29 1 1 0 0 0 0-1.42l-3-3A1 1 0 0 0 12 2a1 1 0 0 0-.7.29l-3 3a1 1 0 0 0 1.41 1.42L11 5.42V11H5.41l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3A1 1 0 0 0 2 12a1 1 0 0 0 .29.71l3 3A1 1 0 0 0 6 16a1 1 0 0 0 .71-.29 1 1 0 0 0 0-1.42L5.42 13H11v5.59l-1.29-1.3a1 1 0 0 0-1.42 1.42l3 3A1 1 0 0 0 12 22a1 1 0 0 0 .7-.29l3-3a1 1 0 0 0-1.42-1.42L13 18.58V13h5.59l-1.3 1.29a1 1 0 0 0 0 1.42A1 1 0 0 0 18 16a1 1 0 0 0 .71-.29l3-3A1 1 0 0 0 22 12a1 1 0 0 0-.29-.69z"})]})})}),b2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"options",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M7 14.18V3a1 1 0 0 0-2 0v11.18a3 3 0 0 0 0 5.64V21a1 1 0 0 0 2 0v-1.18a3 3 0 0 0 0-5.64zM6 18a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"}),e("path",{d:"M21 13a3 3 0 0 0-2-2.82V3a1 1 0 0 0-2 0v7.18a3 3 0 0 0 0 5.64V21a1 1 0 0 0 2 0v-5.18A3 3 0 0 0 21 13zm-3 1a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"}),e("path",{d:"M15 5a3 3 0 1 0-4 2.82V21a1 1 0 0 0 2 0V7.82A3 3 0 0 0 15 5zm-3 1a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"})]})})}),y2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"paper-plane",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M21 4a1.31 1.31 0 0 0-.06-.27v-.09a1 1 0 0 0-.2-.3 1 1 0 0 0-.29-.19h-.09a.86.86 0 0 0-.31-.15H20a1 1 0 0 0-.3 0l-18 6a1 1 0 0 0 0 1.9l8.53 2.84 2.84 8.53a1 1 0 0 0 1.9 0l6-18A1 1 0 0 0 21 4zm-4.7 2.29l-5.57 5.57L5.16 10zM14 18.84l-1.86-5.57 5.57-5.57z"})]})})}),Ag=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"person",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2 2 2 0 0 1 2-2z"}),e("path",{d:"M12 13a7 7 0 0 0-7 7 1 1 0 0 0 2 0 5 5 0 0 1 10 0 1 1 0 0 0 2 0 7 7 0 0 0-7-7z"})]})})}),Mg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"play-circle",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("path",{d:"M12.34 7.45a1.7 1.7 0 0 0-1.85-.3 1.6 1.6 0 0 0-1 1.48v6.74a1.6 1.6 0 0 0 1 1.48 1.68 1.68 0 0 0 .69.15 1.74 1.74 0 0 0 1.16-.45L16 13.18a1.6 1.6 0 0 0 0-2.36zm-.84 7.15V9.4l2.81 2.6z"})]})})}),Qa=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"plus",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M19 11h-6V5a1 1 0 0 0-2 0v6H5a1 1 0 0 0 0 2h6v6a1 1 0 0 0 2 0v-6h6a1 1 0 0 0 0-2z"})]})})}),v2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"plus-circle",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("path",{d:"M15 11h-2V9a1 1 0 0 0-2 0v2H9a1 1 0 0 0 0 2h2v2a1 1 0 0 0 2 0v-2h2a1 1 0 0 0 0-2z"})]})})}),jr=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"pricetags",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M12.87 22a1.84 1.84 0 0 1-1.29-.53l-6.41-6.42a1 1 0 0 1-.29-.61L4 5.09a1 1 0 0 1 .29-.8 1 1 0 0 1 .8-.29l9.35.88a1 1 0 0 1 .61.29l6.42 6.41a1.82 1.82 0 0 1 0 2.57l-7.32 7.32a1.82 1.82 0 0 1-1.28.53zm-6-8.11l6 6 7.05-7.05-6-6-7.81-.73z"}),e("circle",{cx:"10.5",cy:"10.5",r:"1.5"})]})})}),C2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"menu-arrow-circle",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"}),e("path",{d:"M12 6a3.5 3.5 0 0 0-3.5 3.5 1 1 0 0 0 2 0A1.5 1.5 0 1 1 12 11a1 1 0 0 0-1 1v2a1 1 0 0 0 2 0v-1.16A3.49 3.49 0 0 0 12 6z"}),e("circle",{cx:"12",cy:"17",r:"1"})]})})}),Yl=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"refresh",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M20.3 13.43a1 1 0 0 0-1.25.65A7.14 7.14 0 0 1 12.18 19 7.1 7.1 0 0 1 5 12a7.1 7.1 0 0 1 7.18-7 7.26 7.26 0 0 1 4.65 1.67l-2.17-.36a1 1 0 0 0-1.15.83 1 1 0 0 0 .83 1.15l4.24.7h.17a1 1 0 0 0 .34-.06.33.33 0 0 0 .1-.06.78.78 0 0 0 .2-.11l.09-.11c0-.05.09-.09.13-.15s0-.1.05-.14a1.34 1.34 0 0 0 .07-.18l.75-4a1 1 0 0 0-2-.38l-.27 1.45A9.21 9.21 0 0 0 12.18 3 9.1 9.1 0 0 0 3 12a9.1 9.1 0 0 0 9.18 9A9.12 9.12 0 0 0 21 14.68a1 1 0 0 0-.7-1.25z"})]})})}),Fg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"repeat",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M17.91 5h-12l1.3-1.29a1 1 0 0 0-1.42-1.42l-3 3a1 1 0 0 0 0 1.42l3 3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42L5.91 7h12a1.56 1.56 0 0 1 1.59 1.53V11a1 1 0 0 0 2 0V8.53A3.56 3.56 0 0 0 17.91 5z"}),e("path",{d:"M18.21 14.29a1 1 0 0 0-1.42 1.42l1.3 1.29h-12a1.56 1.56 0 0 1-1.59-1.53V13a1 1 0 0 0-2 0v2.47A3.56 3.56 0 0 0 6.09 19h12l-1.3 1.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l3-3a1 1 0 0 0 0-1.42z"})]})})}),Dg=()=>s("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",fill:"none"}),e("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",fill:"none"}),e("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",fill:"none"}),e("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",fill:"none"})]}),k2=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3 11.25C2.58579 11.25 2.25 11.5858 2.25 12C2.25 12.4142 2.58579 12.75 3 12.75H3.9C4.31421 12.75 4.65 12.4142 4.65 12C4.65 11.5858 4.31421 11.25 3.9 11.25H3ZM5.7 11.25C5.28579 11.25 4.95 11.5858 4.95 12C4.95 12.4142 5.28579 12.75 5.7 12.75H7.5C7.91421 12.75 8.25 12.4142 8.25 12C8.25 11.5858 7.91421 11.25 7.5 11.25H5.7ZM9.3 11.25C8.88579 11.25 8.55 11.5858 8.55 12C8.55 12.4142 8.88579 12.75 9.3 12.75H11.1C11.5142 12.75 11.85 12.4142 11.85 12C11.85 11.5858 11.5142 11.25 11.1 11.25H9.3ZM12.9 11.25C12.4858 11.25 12.15 11.5858 12.15 12C12.15 12.4142 12.4858 12.75 12.9 12.75H14.7C15.1142 12.75 15.45 12.4142 15.45 12C15.45 11.5858 15.1142 11.25 14.7 11.25H12.9ZM16.5 11.25C16.0858 11.25 15.75 11.5858 15.75 12C15.75 12.4142 16.0858 12.75 16.5 12.75L18.3 12.75C18.7142 12.75 19.05 12.4142 19.05 12C19.05 11.5858 18.7142 11.25 18.3 11.25L16.5 11.25ZM20.1 11.25C19.6858 11.25 19.35 11.5858 19.35 12C19.35 12.4142 19.6858 12.75 20.1 12.75H21C21.4142 12.75 21.75 12.4142 21.75 12C21.75 11.5858 21.4142 11.25 21 11.25H20.1ZM12.5746 15.1596L15.5744 16.7468C16.0263 17.025 16.1363 17.571 15.8174 17.9656C15.4994 18.3611 14.8754 18.4564 14.4245 18.1782L12.9816 17.55C12.9829 17.5618 12.9867 17.5728 12.9904 17.5838C12.995 17.5974 12.9996 17.6108 12.9996 17.6252V21.1251C12.9996 21.608 12.5526 22 11.9997 22C11.4467 22 10.9998 21.608 10.9998 21.1251V17.6252V17.6243L9.59887 18.3252C9.15791 18.6148 8.53096 18.5369 8.19998 18.1502C8.06499 17.9927 8 17.8081 8 17.6261C8 17.3601 8.13799 17.0967 8.39997 16.9253L11.3997 15.1753C11.7457 14.9478 12.2207 14.9408 12.5746 15.1596ZM12.5746 8.84043L15.5744 7.25325C16.0263 6.97502 16.1363 6.42904 15.8174 6.03444C15.4994 5.63895 14.8754 5.54358 14.4245 5.82182L12.9816 6.45004C12.9829 6.43826 12.9867 6.42718 12.9904 6.41617C12.995 6.40266 12.9996 6.38926 12.9996 6.3748V2.87496C12.9996 2.39198 12.5526 2 11.9997 2C11.4467 2 10.9998 2.39198 10.9998 2.87496V6.3748V6.37567L9.59887 5.67483C9.15791 5.38522 8.53096 5.46309 8.19998 5.84982C8.06499 6.00731 8 6.19193 8 6.37392C8 6.63991 8.13799 6.90327 8.39997 7.07476L11.3997 8.82468C11.7457 9.05217 12.2207 9.05917 12.5746 8.84043Z",fill:"currentColor"})}),L2=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3 11.25C2.58579 11.25 2.25 11.5858 2.25 12C2.25 12.4142 2.58579 12.75 3 12.75H3.9C4.31421 12.75 4.65 12.4142 4.65 12C4.65 11.5858 4.31421 11.25 3.9 11.25H3ZM5.7 11.25C5.28579 11.25 4.95 11.5858 4.95 12C4.95 12.4142 5.28579 12.75 5.7 12.75H7.5C7.91421 12.75 8.25 12.4142 8.25 12C8.25 11.5858 7.91421 11.25 7.5 11.25H5.7ZM9.3 11.25C8.88579 11.25 8.55 11.5858 8.55 12C8.55 12.4142 8.88579 12.75 9.3 12.75H11.1C11.5142 12.75 11.85 12.4142 11.85 12C11.85 11.5858 11.5142 11.25 11.1 11.25H9.3ZM12.9 11.25C12.4858 11.25 12.15 11.5858 12.15 12C12.15 12.4142 12.4858 12.75 12.9 12.75H14.7C15.1142 12.75 15.45 12.4142 15.45 12C15.45 11.5858 15.1142 11.25 14.7 11.25H12.9ZM16.5 11.25C16.0858 11.25 15.75 11.5858 15.75 12C15.75 12.4142 16.0858 12.75 16.5 12.75L18.3 12.75C18.7142 12.75 19.05 12.4142 19.05 12C19.05 11.5858 18.7142 11.25 18.3 11.25L16.5 11.25ZM20.1 11.25C19.6858 11.25 19.35 11.5858 19.35 12C19.35 12.4142 19.6858 12.75 20.1 12.75H21C21.4142 12.75 21.75 12.4142 21.75 12C21.75 11.5858 21.4142 11.25 21 11.25H20.1ZM11.4254 21.8405L8.42561 20.2533C7.97365 19.975 7.86366 19.4291 8.18263 19.0345C8.50061 18.639 9.12456 18.5436 9.57552 18.8219L11.0184 19.4501C11.0171 19.4383 11.0133 19.4272 11.0096 19.4162C11.005 19.4027 11.0004 19.3893 11.0004 19.3748V15.875C11.0004 15.392 11.4474 15 12.0003 15C12.5533 15 13.0002 15.392 13.0002 15.875V19.3748V19.3757L14.4011 18.6749C14.8421 18.3852 15.469 18.4631 15.8 18.8499C15.935 19.0073 16 19.192 16 19.374C16 19.6399 15.862 19.9033 15.6 20.0748L12.6003 21.8247C12.2543 22.0522 11.7793 22.0592 11.4254 21.8405ZM11.4254 2.1596L8.42561 3.74678C7.97365 4.02501 7.86366 4.57099 8.18263 4.96559C8.50061 5.36108 9.12456 5.45645 9.57552 5.17821L11.0184 4.54999C11.0171 4.56177 11.0133 4.57285 11.0096 4.58386C11.005 4.59737 11.0004 4.61077 11.0004 4.62523L11.0004 8.12507C11.0004 8.60805 11.4474 9.00003 12.0003 9.00003C12.5533 9.00003 13.0002 8.60805 13.0002 8.12507L13.0002 4.62523V4.62436L14.4011 5.3252C14.8421 5.61481 15.469 5.53694 15.8 5.15021C15.935 4.99272 16 4.8081 16 4.62611C16 4.36012 15.862 4.09676 15.6 3.92527L12.6003 2.17535C12.2543 1.94786 11.7793 1.94086 11.4254 2.1596Z",fill:"currentColor"})}),Eg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"save",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M20.12 8.71l-4.83-4.83A3 3 0 0 0 13.17 3H6a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7.17a3 3 0 0 0-.88-2.12zM10 19v-2h4v2zm9-1a1 1 0 0 1-1 1h-2v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h2v5a1 1 0 0 0 1 1h4a1 1 0 0 0 0-2h-3V5h3.17a1.05 1.05 0 0 1 .71.29l4.83 4.83a1 1 0 0 1 .29.71z"})]})})}),S2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"search",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M20.71 19.29l-3.4-3.39A7.92 7.92 0 0 0 19 11a8 8 0 1 0-8 8 7.92 7.92 0 0 0 4.9-1.69l3.39 3.4a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zM5 11a6 6 0 1 1 6 6 6 6 0 0 1-6-6z"})]})})}),w2=()=>s("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",style:{fill:"none"},stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e("rect",{x:"2",y:"2",width:"20",height:"8",rx:"2",ry:"2"}),e("rect",{x:"2",y:"14",width:"20",height:"8",rx:"2",ry:"2"}),e("line",{x1:"6",y1:"6",x2:"6.01",y2:"6"}),e("line",{x1:"6",y1:"18",x2:"6.01",y2:"18"})]}),Kg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"settings",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M8.61 22a2.25 2.25 0 0 1-1.35-.46L5.19 20a2.37 2.37 0 0 1-.49-3.22 2.06 2.06 0 0 0 .23-1.86l-.06-.16a1.83 1.83 0 0 0-1.12-1.22h-.16a2.34 2.34 0 0 1-1.48-2.94L2.93 8a2.18 2.18 0 0 1 1.12-1.41 2.14 2.14 0 0 1 1.68-.12 1.93 1.93 0 0 0 1.78-.29l.13-.1a1.94 1.94 0 0 0 .73-1.51v-.24A2.32 2.32 0 0 1 10.66 2h2.55a2.26 2.26 0 0 1 1.6.67 2.37 2.37 0 0 1 .68 1.68v.28a1.76 1.76 0 0 0 .69 1.43l.11.08a1.74 1.74 0 0 0 1.59.26l.34-.11A2.26 2.26 0 0 1 21.1 7.8l.79 2.52a2.36 2.36 0 0 1-1.46 2.93l-.2.07A1.89 1.89 0 0 0 19 14.6a2 2 0 0 0 .25 1.65l.26.38a2.38 2.38 0 0 1-.5 3.23L17 21.41a2.24 2.24 0 0 1-3.22-.53l-.12-.17a1.75 1.75 0 0 0-1.5-.78 1.8 1.8 0 0 0-1.43.77l-.23.33A2.25 2.25 0 0 1 9 22a2 2 0 0 1-.39 0zM4.4 11.62a3.83 3.83 0 0 1 2.38 2.5v.12a4 4 0 0 1-.46 3.62.38.38 0 0 0 0 .51L8.47 20a.25.25 0 0 0 .37-.07l.23-.33a3.77 3.77 0 0 1 6.2 0l.12.18a.3.3 0 0 0 .18.12.25.25 0 0 0 .19-.05l2.06-1.56a.36.36 0 0 0 .07-.49l-.26-.38A4 4 0 0 1 17.1 14a3.92 3.92 0 0 1 2.49-2.61l.2-.07a.34.34 0 0 0 .19-.44l-.78-2.49a.35.35 0 0 0-.2-.19.21.21 0 0 0-.19 0l-.34.11a3.74 3.74 0 0 1-3.43-.57L15 7.65a3.76 3.76 0 0 1-1.49-3v-.31a.37.37 0 0 0-.1-.26.31.31 0 0 0-.21-.08h-2.54a.31.31 0 0 0-.29.33v.25a3.9 3.9 0 0 1-1.52 3.09l-.13.1a3.91 3.91 0 0 1-3.63.59.22.22 0 0 0-.14 0 .28.28 0 0 0-.12.15L4 11.12a.36.36 0 0 0 .22.45z","data-name":"<Group>"}),e("path",{d:"M12 15.5a3.5 3.5 0 1 1 3.5-3.5 3.5 3.5 0 0 1-3.5 3.5zm0-5a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5z"})]})})}),x2=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"share",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M18 15a3 3 0 0 0-2.1.86L8 12.34V12v-.33l7.9-3.53A3 3 0 1 0 15 6v.34L7.1 9.86a3 3 0 1 0 0 4.28l7.9 3.53V18a3 3 0 1 0 3-3zm0-10a1 1 0 1 1-1 1 1 1 0 0 1 1-1zM5 13a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm13 6a1 1 0 1 1 1-1 1 1 0 0 1-1 1z"})]})})}),_g=()=>s("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:"feather feather-slack",children:[e("path",{d:"M14.5 10c-.83 0-1.5-.67-1.5-1.5v-5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5z"}),e("path",{d:"M20.5 10H19V8.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"}),e("path",{d:"M9.5 14c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5S8 21.33 8 20.5v-5c0-.83.67-1.5 1.5-1.5z"}),e("path",{d:"M3.5 14H5v1.5c0 .83-.67 1.5-1.5 1.5S2 16.33 2 15.5 2.67 14 3.5 14z"}),e("path",{d:"M14 14.5c0-.83.67-1.5 1.5-1.5h5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-5c-.83 0-1.5-.67-1.5-1.5z"}),e("path",{d:"M15.5 19H14v1.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5-.67-1.5-1.5-1.5z"}),e("path",{d:"M10 9.5C10 8.67 9.33 8 8.5 8h-5C2.67 8 2 8.67 2 9.5S2.67 11 3.5 11h5c.83 0 1.5-.67 1.5-1.5z"}),e("path",{d:"M8.5 5H10V3.5C10 2.67 9.33 2 8.5 2S7 2.67 7 3.5 7.67 5 8.5 5z"})]}),Zr=()=>s("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6 21H18C19.654 21 21 19.654 21 18V6C21 4.346 19.654 3 18 3H6C4.346 3 3 4.346 3 6V18C3 19.654 4.346 21 6 21ZM5 6C5 5.449 5.449 5 6 5H18C18.551 5 19 5.449 19 6V18C19 18.551 18.551 19 18 19H6C5.449 19 5 18.551 5 18V6Z",fill:"currentColor"}),e("rect",{x:"9",y:"4",width:"2",height:"16",fill:"currentColor"}),e("path",{d:"M16.0955 14.9999C15.9704 14.9999 15.8461 14.9455 15.7613 14.8401L13.6921 12.2686C13.5644 12.1095 13.5661 11.8824 13.6968 11.7255L15.8397 9.15401C15.991 8.97229 16.2614 8.94786 16.4435 9.09915C16.6253 9.25045 16.6497 9.52088 16.498 9.70261L14.5801 12.0045L16.4294 14.3026C16.5777 14.4869 16.5485 14.7569 16.3638 14.9052C16.285 14.9691 16.1898 14.9999 16.0955 14.9999Z",fill:"currentColor",stroke:"currentColor",strokeWidth:"0.5"}),e("mask",{id:"mask0_2304_25",maskUnits:"userSpaceOnUse",x:"3",y:"3",width:"18",height:"18",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6 21H18C19.654 21 21 19.654 21 18V6C21 4.346 19.654 3 18 3H6C4.346 3 3 4.346 3 6V18C3 19.654 4.346 21 6 21ZM5 6C5 5.449 5.449 5 6 5H18C18.551 5 19 5.449 19 6V18C19 18.551 18.551 19 18 19H6C5.449 19 5 18.551 5 18V6Z",fill:"white"})}),e("g",{mask:"url(#mask0_2304_25)"})]}),Ur=()=>s("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6 21H18C19.654 21 21 19.654 21 18V6C21 4.346 19.654 3 18 3H6C4.346 3 3 4.346 3 6V18C3 19.654 4.346 21 6 21ZM5 6C5 5.449 5.449 5 6 5H18C18.551 5 19 5.449 19 6V18C19 18.551 18.551 19 18 19H6C5.449 19 5 18.551 5 18V6Z",fill:"currentColor"}),e("rect",{x:"9",y:"4",width:"2",height:"16",fill:"currentColor"}),e("path",{d:"M14.0995 9.00021C14.2247 9.00021 14.349 9.05464 14.4338 9.16008L16.503 11.7316C16.6307 11.8906 16.629 12.1178 16.4982 12.2746L14.3554 14.8461C14.2041 15.0279 13.9337 15.0523 13.7515 14.901C13.5698 14.7497 13.5454 14.4793 13.6971 14.2975L15.615 11.9956L13.7657 9.69752C13.6174 9.51323 13.6465 9.24322 13.8312 9.09493C13.9101 9.03107 14.0052 9.00021 14.0995 9.00021Z",fill:"currentColor",stroke:"currentColor",strokeWidth:"0.5"}),e("mask",{id:"mask0_2304_26",maskUnits:"userSpaceOnUse",x:"3",y:"3",width:"18",height:"18",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6 21H18C19.654 21 21 19.654 21 18V6C21 4.346 19.654 3 18 3H6C4.346 3 3 4.346 3 6V18C3 19.654 4.346 21 6 21ZM5 6C5 5.449 5.449 5 6 5H18C18.551 5 19 5.449 19 6V18C19 18.551 18.551 19 18 19H6C5.449 19 5 18.551 5 18V6Z",fill:"white"})}),e("g",{mask:"url(#mask0_2304_26)"})]}),Jl=()=>s("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M12 18.9999C12.5523 18.9999 13 19.4477 13 19.9999V21.9999C13 22.5522 12.5523 22.9999 12 22.9999C11.4477 22.9999 11 22.5522 11 21.9999V19.9999C11 19.4477 11.4477 18.9999 12 18.9999Z"}),e("path",{d:"M5.63281 16.9531C6.02331 16.5627 6.65637 16.5627 7.04688 16.9531C7.4373 17.3436 7.4373 17.9766 7.04688 18.3671L5.63672 19.7773C5.24619 20.1674 4.61307 20.1676 4.22266 19.7773C3.83235 19.3869 3.83251 18.7537 4.22266 18.3632L5.63281 16.9531Z"}),e("path",{d:"M16.9531 16.9531C17.3436 16.5625 17.9767 16.5625 18.3672 16.9531L19.7773 18.3632C20.1676 18.7538 20.1678 19.3868 19.7773 19.7773C19.3869 20.1677 18.7538 20.1675 18.3633 19.7773L16.9531 18.3671C16.5626 17.9766 16.5626 17.3436 16.9531 16.9531Z"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12 6.99994C14.7614 6.99994 17 9.23852 17 11.9999C17 14.7614 14.7614 16.9999 12 16.9999C9.23858 16.9999 7 14.7614 7 11.9999C7 9.23852 9.23858 6.99994 12 6.99994ZM12 8.99994C10.3431 8.99994 9 10.3431 9 11.9999C9 13.6568 10.3431 14.9999 12 14.9999C13.6569 14.9999 15 13.6568 15 11.9999C15 10.3431 13.6569 8.99994 12 8.99994Z"}),e("path",{d:"M4 10.9999C4.55228 10.9999 5 11.4477 5 11.9999C5 12.5522 4.55228 12.9999 4 12.9999H2C1.44772 12.9999 1 12.5522 1 11.9999C1 11.4477 1.44772 10.9999 2 10.9999H4Z"}),e("path",{d:"M22 10.9999C22.5523 10.9999 23 11.4477 23 11.9999C23 12.5522 22.5523 12.9999 22 12.9999H20C19.4477 12.9999 19 12.5522 19 11.9999C19 11.4477 19.4477 10.9999 20 10.9999H22Z"}),e("path",{d:"M4.22266 4.2226C4.61306 3.83219 5.24617 3.83243 5.63672 4.2226L7.04688 5.63275C7.43724 6.02329 7.43735 6.65634 7.04688 7.04681C6.6564 7.43724 6.02333 7.43717 5.63281 7.04681L4.22266 5.63666C3.83251 5.24612 3.8323 4.613 4.22266 4.2226Z"}),e("path",{d:"M18.3633 4.2226C18.7538 3.8324 19.3869 3.83227 19.7773 4.2226C20.1677 4.61303 20.1676 5.24614 19.7773 5.63666L18.3672 7.04681C17.9767 7.43723 17.3436 7.43723 16.9531 7.04681C16.5627 6.65631 16.5627 6.02325 16.9531 5.63275L18.3633 4.2226Z"}),e("path",{d:"M12 0.999939C12.5523 0.999939 13 1.44765 13 1.99994V3.99994C13 4.55222 12.5523 4.99994 12 4.99994C11.4477 4.99994 11 4.55222 11 3.99994V1.99994C11 1.44765 11.4477 0.999939 12 0.999939Z"})]}),T2=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:s("g",{id:"timer",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.994 4.03164C12.9914 4.04002 12.9889 4.0485 12.988 4.058C17.487 4.552 21 8.372 21 13C21 17.963 16.962 22 12 22C7.038 22 3 17.963 3 13C3 8.372 6.513 4.552 11.012 4.058C11.0111 4.0485 11.0086 4.04002 11.006 4.03164C11.003 4.0215 11 4.0115 11 4V3H10C9.448 3 9 2.553 9 2C9 1.447 9.448 1 10 1H14C14.552 1 15 1.447 15 2C15 2.553 14.552 3 14 3H13V4C13 4.0115 12.997 4.0215 12.994 4.03164ZM12 19.75C8.278 19.75 5.25 16.722 5.25 13C5.25 9.278 8.278 6.25 12 6.25C15.722 6.25 18.75 9.278 18.75 13C18.75 16.722 15.722 19.75 12 19.75ZM16 13C16 12.447 15.552 12 15 12H13V10C13 9.447 12.552 9 12 9C11.448 9 11 9.447 11 10V13C11 13.553 11.448 14 12 14H15C15.552 14 16 13.553 16 13Z",fill:"currentColor"}),e("mask",{id:"mask0_0_1974",maskUnits:"userSpaceOnUse",x:"3",y:"1",width:"18",height:"21",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.994 4.03164C12.9914 4.04002 12.9889 4.0485 12.988 4.058C17.487 4.552 21 8.372 21 13C21 17.963 16.962 22 12 22C7.038 22 3 17.963 3 13C3 8.372 6.513 4.552 11.012 4.058C11.0111 4.0485 11.0086 4.04002 11.006 4.03164C11.003 4.0215 11 4.0115 11 4V3H10C9.448 3 9 2.553 9 2C9 1.447 9.448 1 10 1H14C14.552 1 15 1.447 15 2C15 2.553 14.552 3 14 3H13V4C13 4.0115 12.997 4.0215 12.994 4.03164ZM12 19.75C8.278 19.75 5.25 16.722 5.25 13C5.25 9.278 8.278 6.25 12 6.25C15.722 6.25 18.75 9.278 18.75 13C18.75 16.722 15.722 19.75 12 19.75ZM16 13C16 12.447 15.552 12 15 12H13V10C13 9.447 12.552 9 12 9C11.448 9 11 9.447 11 10V13C11 13.553 11.448 14 12 14H15C15.552 14 16 13.553 16 13Z",fill:"currentColor"})})]})}),I2=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.988 4.058C12.9889 4.0485 12.9914 4.04002 12.994 4.03164C12.997 4.0215 13 4.0115 13 4V3H14C14.552 3 15 2.553 15 2C15 1.447 14.552 1 14 1H10C9.448 1 9 1.447 9 2C9 2.553 9.448 3 10 3H11V4C11 4.0115 11.003 4.0215 11.006 4.03164C11.0086 4.04002 11.0111 4.0485 11.012 4.058C10.1864 4.14865 9.394 4.35131 8.65042 4.65041L10.4335 6.43348C10.9364 6.31352 11.4609 6.25 12 6.25C15.722 6.25 18.75 9.278 18.75 13C18.75 13.5391 18.6865 14.0636 18.5665 14.5665L20.3525 16.3525C20.7701 15.3159 21 14.1843 21 13C21 8.372 17.487 4.552 12.988 4.058ZM12 19.75C12.82 19.75 13.6063 19.603 14.334 19.334L16.0408 21.0408C14.825 21.6543 13.4521 22 12 22C7.038 22 3 17.963 3 13C3 11.8156 3.23007 10.6842 3.64786 9.64786L5.43348 11.4335C5.31353 11.9364 5.25 12.4609 5.25 13C5.25 16.722 8.278 19.75 12 19.75ZM3.85828 3.09123C3.35638 2.61722 2.56525 2.63982 2.09124 3.14172C1.61722 3.64362 1.63983 4.43475 2.14172 4.90877L20.1417 21.9088C20.6436 22.3828 21.4348 22.3602 21.9088 21.8583C22.3828 21.3564 22.3602 20.5652 21.8583 20.0912L3.85828 3.09123Z",fill:"currentColor"})}),Vg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:e("path",{fill:"None",d:"M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"})}),Pg=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:e("path",{fill:"None",d:"M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"})}),z2=()=>e("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:s("g",{children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M7.32264 7.73275L6.26721 6.67733C5.93552 6.34564 5.39776 6.34564 5.06607 6.67733L4.01064 7.73275C3.67895 8.06445 3.67895 8.60221 4.01064 8.9339L5.06607 9.98933C5.39776 10.321 5.93552 10.321 6.26721 9.98933L7.32264 8.9339C7.65433 8.60221 7.65433 8.06445 7.32264 7.73275ZM4.75695 8.33333L5.66664 7.42364L6.57633 8.33333L5.66664 9.24302L4.75695 8.33333Z"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M5.66672 13.3333C6.43362 13.3333 7.16019 13.1607 7.80972 12.8521C8.4596 13.1608 9.18643 13.3333 9.95243 13.3333C12.7139 13.3333 14.9524 11.0948 14.9524 8.33334C14.9524 5.57192 12.7139 3.33334 9.95243 3.33334C9.18643 3.33334 8.4596 3.50591 7.80969 3.81458C7.16019 3.50601 6.43362 3.33334 5.66672 3.33334C2.90529 3.33334 0.666718 5.57192 0.666718 8.33334C0.666718 11.0948 2.90529 13.3333 5.66672 13.3333ZM5.66672 4.28572C3.43129 4.28572 1.6191 6.09791 1.6191 8.33334C1.6191 10.5688 3.43129 12.381 5.66672 12.381C7.72319 12.381 9.42146 10.8473 9.68019 8.86141C9.70272 8.68858 9.71434 8.51232 9.71434 8.33334C9.71434 8.19363 9.70727 8.05556 9.69343 7.91949C9.48617 5.87846 7.76243 4.28572 5.66672 4.28572ZM9.95243 12.381C9.55679 12.381 9.17481 12.3243 8.81393 12.2188C9.81991 11.4029 10.5028 10.2043 10.6409 8.84456C10.658 8.67649 10.6667 8.50594 10.6667 8.33334C10.6667 8.10822 10.6518 7.88658 10.623 7.66934C10.451 6.37275 9.78208 5.23306 8.81393 4.44791C9.17481 4.34237 9.55679 4.28572 9.95243 4.28572C12.1879 4.28572 14.0001 6.09791 14.0001 8.33334C14.0001 10.5688 12.1879 12.381 9.95243 12.381Z"})]})}),ml=()=>e("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M7 5C7 4.44772 6.55228 4 6 4C5.44772 4 5 4.44772 5 5V9V15C5 16.6569 6.34315 18 8 18H13.4375C13.8375 19.0243 14.834 19.75 16 19.75C17.5188 19.75 18.75 18.5188 18.75 17C18.75 15.4812 17.5188 14.25 16 14.25C14.834 14.25 13.8375 14.9757 13.4375 16H8C7.44772 16 7 15.5523 7 15V11H13.4375C13.8375 12.0243 14.834 12.75 16 12.75C17.5188 12.75 18.75 11.5188 18.75 10C18.75 8.48122 17.5188 7.25 16 7.25C14.834 7.25 13.8375 7.97566 13.4375 9H7V5ZM16 8.75C15.3096 8.75 14.75 9.30964 14.75 10C14.75 10.6904 15.3096 11.25 16 11.25C16.6904 11.25 17.25 10.6904 17.25 10C17.25 9.30964 16.6904 8.75 16 8.75ZM14.75 17C14.75 16.3096 15.3096 15.75 16 15.75C16.6904 15.75 17.25 16.3096 17.25 17C17.25 17.6904 16.6904 18.25 16 18.25C15.3096 18.25 14.75 17.6904 14.75 17Z"})}),gl=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",children:e("g",{"data-name":"Layer 2",children:s("g",{"data-name":"trash",children:[e("rect",{width:"24",height:"24",opacity:"0"}),e("path",{d:"M21 6h-5V4.33A2.42 2.42 0 0 0 13.5 2h-3A2.42 2.42 0 0 0 8 4.33V6H3a1 1 0 0 0 0 2h1v11a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V8h1a1 1 0 0 0 0-2zM10 4.33c0-.16.21-.33.5-.33h3c.29 0 .5.17.5.33V6h-4zM18 19a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V8h12z"})]})})}),ze=()=>e(x,{svg:e(l2,{}),css:p`
        font-size: 0.8rem;
      `});function A2(n,{filled:a}={filled:!0}){let t;switch(n){case"warning":t=a?e(e2,{}):e(J0,{});break;case"info":t=a?e(p2,{}):e(Wa,{});break;case"danger":t=a?e(Vr,{}):e(cl,{});break;case"success":t=a?e(ul,{}):e(Rr,{});break}return e(x,{svg:t})}const M2=p`
  --alert-base-color: var(--ac-global-color-info);
  --alert-bg-color: lch(from var(--alert-base-color) l c h / 0.1);
  --alert-border-color: lch(from var(--alert-base-color) l c h / 0.3);
  --alert-text-color: lch(
    from var(--alert-base-color) calc((50 - l) * infinity) 0 0
  );

  padding: var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-200);
  border-radius: var(--ac-global-rounding-small);
  color: var(--alert-text-color);
  display: flex;
  flex-direction: row;
  align-items: center;
  backdrop-filter: blur(10px);
  border: 1px solid var(--alert-border-color);
  background-color: var(--alert-bg-color);

  &[data-banner="true"] {
    border-radius: 0;
    border-left: 0px;
    border-right: 0px;
  }

  &[data-variant="warning"] {
    --alert-base-color: var(--ac-global-color-warning);
  }

  &[data-variant="info"] {
    --alert-base-color: var(--ac-global-color-info);
  }

  &[data-variant="danger"] {
    --alert-base-color: var(--ac-global-color-danger);
  }

  &[data-variant="success"] {
    --alert-base-color: var(--ac-global-color-success);
  }

  &[data-theme="light"] {
    --alert-bg-color: lch(from var(--alert-base-color) l c h / 0.1);
    --alert-border-color: lch(from var(--alert-base-color) l c h / 0.3);
    --alert-text-color: var(--alert-base-color);
  }

  &[data-theme="dark"] {
    --alert-bg-color: lch(from var(--alert-base-color) l c h / 0.2);
    --alert-border-color: lch(from var(--alert-base-color) l c h / 0.4);
    --alert-text-color: lch(
      from var(--alert-base-color) calc((l) * infinity) c h / 1
    );
  }

  .ac-alert__icon-title-wrap {
    display: flex;
    flex-direction: row;

    .ac-icon-wrap {
      margin-top: 4px;
      margin-right: var(--ac-global-dimension-static-size-200);
      font-size: var(--ac-global-font-size-l);
    }
  }
`,F2=p`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  flex: 1 1 auto;
`,D2=p`
  background-color: transparent;
  color: inherit;
  padding: 0;
  border: none;
  cursor: pointer;
  width: 20px;
  height: 20px;
  margin-left: var(--ac-global-dimension-static-size-200);
`,On=({variant:n,title:a,icon:t,children:l,showIcon:i=!0,dismissable:r=!1,onDismissClick:o,banner:c=!1,extra:d,...u})=>{const{theme:m}=de();return!t&&i&&(t=A2(n)),s("div",{...u,css:M2,"data-variant":n,"data-banner":c,"data-has-title":!!a,"data-theme":m,children:[s("div",{css:F2,className:"ac-alert__icon-title-wrap",children:[t,s("div",{children:[a?e(C,{elementType:"h5",size:"L",weight:"heavy",color:"inherit",children:a}):null,e(C,{color:"inherit",size:"M",children:l})]})]}),d,r?e("button",{css:D2,onClick:o,children:e(x,{svg:e(Ga,{})})}):null]})},E2=p`
  & > * {
    width: 100%;
    .react-aria-Heading {
      width: 100%;
      .react-aria-Button[slot="trigger"] {
        width: 100%;
      }
    }
  }

  // add border between items, only when child is expanded
  > .ac-disclosure:not(:last-child) {
    &[data-expanded="true"] {
      border-bottom: 1px solid var(--ac-global-border-color-default);
    }
  }

  &[data-size="S"] > * {
    .react-aria-Heading {
      .react-aria-Button[slot="trigger"] {
        padding: var(--ac-global-dimension-static-size-50);
      }
    }
  }
`,K2=p`
  .react-aria-Heading {
    margin: 0;
  }

  .react-aria-Button[slot="trigger"] {
    // reset trigger styles
    background: none;
    border: none;
    box-shadow: none;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    font-size: var(--ac-global-font-size-s);
    line-height: var(--ac-global-line-height-s);
    padding: var(--ac-global-dimension-static-size-100)
      var(--ac-global-dimension-static-size-200);

    // style trigger
    color: var(--ac-global-text-color-900);
    border-bottom: 1px solid var(--ac-global-border-color-default);
    outline: none;
    background-color: transparent;
    &:hover:not([disabled]) {
      background-color: var(--ac-global-disclosure-background-color-active);
    }
    &[data-focus-visible] {
      outline: 1px solid var(--ac-global-input-field-border-color-active);
      outline-offset: -1px;
    }
    &:not([disabled]) {
      transition: all 0.2s ease-in-out;
    }
    &[disabled] {
      cursor: default;
      opacity: 0.6;
    }

    // style trigger icon
    > svg,
    > i {
      rotate: 90deg;
      transition: rotate 200ms;
      width: 1em;
      height: 1em;
      fill: currentColor;
    }

    &[data-arrow-position="start"] {
      flex-direction: row-reverse;
      > svg,
      > i {
        rotate: 0deg;
      }
    }
  }

  &[data-size="L"] .react-aria-Button[slot="trigger"] {
    height: 48px;
    max-height: 48px;
  }

  &[data-expanded] .react-aria-Button[slot="trigger"] {
    > svg,
    > i {
      rotate: -90deg;
    }

    &[data-arrow-position="start"] {
      > svg,
      > i {
        rotate: 90deg;
      }
    }
  }
`,Rg=({className:n,css:a,size:t,...l})=>e(as,{allowsMultipleExpanded:!0,className:$("ac-disclosure-group",n),css:p(E2,a),"data-size":t,...l}),Ng=({size:n,className:a,...t})=>e(ts,{className:$("ac-disclosure",a),css:K2,"data-size":n,defaultExpanded:!0,...t}),Og=({className:n,...a})=>e(ls,{className:$("ac-disclosure-panel",n),...a}),$g=({children:n,arrowPosition:a,justifyContent:t,width:l})=>e(Fi,{className:"react-aria-Heading ac-disclosure-trigger",children:s(nn,{slot:"trigger","data-arrow-position":a,style:{width:l},children:[e(S,{justifyContent:t,alignItems:"center",width:"100%",gap:"size-100",children:n}),a!=="none"?e(x,{svg:e(_r,{})}):null]})}),Te=p`
  &[data-required] {
    .react-aria-Label {
      &::after {
        content: " *";
      }
    }
  }
  .react-aria-Label {
    padding: 5px 0;
    display: inline-block;
    font-size: var(--ac-global-font-size-xs);
    line-height: var(--ac-global-line-height-xs);
    font-weight: var(--px-font-weight-heavy);
  }

  .react-aria-Input,
  .react-aria-TextArea {
    transition: all 0.2s ease-in-out;
    margin: 0;
    flex: 1 1 auto;
    font-size: var(--ac-global-font-size-s);
    min-width: var(--ac-global-input-field-min-width);
    background-color: var(--ac-global-input-field-background-color);
    color: var(--ac-global-text-color-900);
    border: var(--ac-global-border-size-thin) solid
      var(--ac-global-input-field-border-color);
    border-radius: var(--ac-global-rounding-small);
    vertical-align: middle;

    &[data-focused] {
      // TODO: figure out focus ring behavior. For now the color is enough
      outline: none;
    }
    &[data-focused]:not([data-invalid]) {
      border: 1px solid var(--ac-global-input-field-border-color-active);
    }
    &[data-hovered]:not([data-disabled]):not([data-invalid]) {
      border: 1px solid var(--ac-global-input-field-border-color-active);
    }
    &[data-disabled] {
      opacity: var(--ac-global-opacity-disabled);
    }
    &[data-invalid="true"] {
      border-color: var(--ac-global-color-danger);
    }
    &::placeholder {
      color: var(--ac-text-color-placeholder);
      font-style: italic;
    }
  }
  [slot="description"],
  [slot="errorMessage"],
  .react-aria-FieldError {
    /* The overriding cascade here is non ideal but it lets us have only one notion of text  */
    font-size: var(--ac-global-font-size-xs) !important;
    padding-top: var(--ac-global-dimension-static-size-50);
    display: inline-block;
    line-height: var(--ac-global-dimension-static-font-size-200) !important;
  }

  [slot="description"] {
    color: var(--ac-global-text-color-500);
  }

  .react-aria-FieldError {
    color: var(--ac-global-color-danger);
  }
`,_2=p`
  width: var(--trigger-width);
  background-color: var(--ac-global-menu-background-color);
  border-radius: var(--ac-global-rounding-small);
  color: var(--ac-global-text-color-900);
  box-shadow: 0px 4px 10px var(--px-overlay-shadow-color);
  border: 1px solid var(--ac-global-menu-border-color);
  max-height: inherit;
`,qa=p`
  position: relative;
  width: 100%;
  --field-icon-vertical-position: 50%;

  :has(.react-aria-Label) {
    /* 24px is the height of the label. TODO: make this variable based */
    --field-icon-vertical-position: calc(
      var(--textfield-vertical-padding) + 1px + 24px
    );
  }

  &[data-size="S"] {
    --textfield-input-height: var(--ac-global-input-height-s);
    --textfield-vertical-padding: 6px;
    --textfield-horizontal-padding: 6px;
  }
  &[data-size="M"] {
    --textfield-input-height: var(--ac-global-input-height-m);
    --textfield-vertical-padding: 10px;
    --textfield-horizontal-padding: var(--ac-global-dimension-static-size-200);
    --icon-size: var(--ac-global-font-size-l);
  }

  &:has(.ac-field-icon) {
    .react-aria-Input {
      padding-right: calc(
        var(--textfield-horizontal-padding) + var(--icon-size)
      );
    }
  }

  /* Icons */
  .ac-field-icon {
    position: absolute;
    right: var(--textfield-horizontal-padding);
    top: var(--field-icon-vertical-position);
  }

  .react-aria-Input,
  .react-aria-TextArea,
  input {
    width: 100%;
    margin: 0;
    border: var(--ac-global-border-size-thin) solid
      var(
        --ac-field-border-color-override,
        var(--ac-global-input-field-border-color)
      );
    border-radius: var(--ac-global-rounding-small);
    background-color: var(--ac-global-input-field-background-color);
    color: var(--ac-global-text-color-900);
    padding: var(--textfield-vertical-padding)
      var(--textfield-horizontal-padding);
    box-sizing: border-box;
    outline-offset: -1px;
    outline: var(--ac-global-border-size-thin) solid transparent;
    &[data-focused]:not([data-invalid]) {
      outline: 1px solid var(--ac-global-input-field-border-color-active);
    }
  }

  .react-aria-Input {
    /* TODO: remove this sizing */
    height: var(--textfield-input-height);
  }

  [slot="description"],
  [slot="errorMessage"],
  .react-aria-FieldError {
    grid-area: help;
  }
`,V2=p`
  &[data-size="M"] {
    --combobox-input-height: var(--ac-global-input-height-s);
    --combobox-vertical-padding: 6px;
    --combobox-start-padding: var(--ac-global-dimension-static-size-100);
    --combobox-end-padding: var(--ac-global-dimension-static-size-50);
  }
  &[data-size="L"] {
    --combobox-input-height: var(--ac-global-input-height-m);
    --combobox-vertical-padding: 10px;
    --combobox-start-padding: var(--ac-global-dimension-static-size-200);
    --combobox-end-padding: var(--ac-global-dimension-static-size-100);
  }
  color: var(--ac-global-text-color-900);
  &[data-required] {
    .react-aria-Label {
      &::after {
        content: " *";
      }
    }
  }

  .px-combobox-container {
    display: flex;
    flex-direction: row;
    min-width: 200px;
    position: relative;

    .react-aria-Input {
      height: var(--combobox-input-height);
      box-sizing: border-box;
      padding: var(--combobox-vertical-padding) var(--combobox-end-padding)
        var(--combobox-vertical-padding) var(--combobox-start-padding);
      &:hover:not([disabled]) {
        background-color: var(--ac-global-input-field-border-color-hover);
      }
    }
    .react-aria-Button {
      /* Account for the border width of the input */
      padding: 0 calc(var(--combobox-end-padding) + 1px);
      background: none;
      color: inherit;
      forced-color-adjust: none;
      position: absolute;
      top: 50%;
      right: 0;
      border: none;
      transform: translateY(-50%);
      cursor: pointer;

      &[data-disabled] {
        opacity: var(--ac-global-opacity-disabled);
      }
    }
  }
`,P2=p(_2,p`
    .react-aria-ListBox {
      display: block;
      width: unset;
      max-height: inherit;
      min-height: unset;
      border: none;
      overflow: auto;
    }
  `),R2=p`
  outline: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: var(--ac-global-text-color-900);
  padding: var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-200);
  font-size: var(--ac-global-dimension-static-font-size-100);
  cursor: pointer;
  position: relative;
  & > .ac-icon-wrap.px-menu-item__selected-checkmark {
    height: var(--ac-global-dimension-static-size-200);
    width: var(--ac-global-dimension-static-size-200);
  }
  &[href] {
    text-decoration: none;
    cursor: pointer;
  }
  &[data-selected] {
    i {
      color: var(--ac-global-color-primary);
    }
  }
  &[data-focused],
  &[data-hovered] {
    background-color: var(--ac-global-menu-item-background-color-hover);
  }

  &[data-disabled] {
    cursor: not-allowed;
    color: var(--ac-global-color-text-30);
  }
  &[data-focus-visible] {
    outline: none;
  }
`,gt=n=>{n.preventDefault(),n.stopPropagation()};function Bg({label:n,placeholder:a,description:t,errorMessage:l,children:i,size:r="M",width:o,stopPropagation:c,renderEmptyState:d,isInvalid:u,...m}){return s(is,{...m,css:p(Te,V2),"data-size":r,isInvalid:u||!!l,style:{width:o},children:[n&&e(P,{children:n}),s("div",{className:"px-combobox-container",onClick:c?gt:void 0,onKeyDown:c?gt:void 0,onKeyUp:c?gt:void 0,children:[e(W,{placeholder:a}),e(nn,{children:e(ze,{})})]}),t&&!l?e(Mi,{slot:"description",children:t}):null,e(ae,{children:l}),e(Ei,{css:P2,children:e(Di,{renderEmptyState:d,children:i})})]})}function Hg(n){const{children:a,...t}=n;return e(Ze,{...t,css:R2,children:({isSelected:l})=>s(B,{children:[a,l&&e(x,{svg:e(Ua,{}),className:"px-menu-item__selected-checkmark"})]})})}const Xa=p`
  --button-border-color: var(--ac-global-input-field-border-color);
  border: 1px solid var(--button-border-color);
  font-size: var(--ac-global-dimension-static-font-size-100);
  line-height: 20px; // TODO(mikeldking): move this into a consistent variable
  margin: 0;
  flex: none;

  display: flex;
  gap: var(--ac-global-dimension-static-size-100);
  justify-content: center;
  align-items: center;
  flex-direction: row;
  box-sizing: border-box;
  border-radius: var(--ac-global-rounding-small);
  color: var(--ac-global-text-color-900);
  transition: background-color 0.2s ease-in-out;
  cursor: pointer;

  /* Disable outline since there are other mechanisms to show focus */
  outline: none;
  &[data-focus-visible] {
    // Only show outline on focus-visible, aka only when tabbed but not clicked
    outline: 1px solid var(--ac-global-input-field-border-color-active);
    outline-offset: 1px;
  }
  &[disabled] {
    cursor: default;
    opacity: var(--ac-opacity-disabled);
  }
  &[data-size="S"] {
    height: var(--ac-global-button-height-s);
  }
  &[data-size="M"] {
    height: var(--ac-global-button-height-m);
  }
  &[data-size="M"][data-childless="false"] {
    padding: var(--ac-global-dimension-static-size-100)
      var(--ac-global-dimension-static-size-200);
  }
  &[data-size="S"][data-childless="false"] {
    padding: var(--ac-global-dimension-static-size-50)
      var(--ac-global-dimension-static-size-100);
  }
  &[data-size="M"][data-childless="true"] {
    padding: var(--ac-global-dimension-static-size-100)
      var(--ac-global-dimension-static-size-100);
  }
  &[data-size="S"][data-childless="true"] {
    padding: var(--ac-global-dimension-static-size-50)
      var(--ac-global-dimension-static-size-50);
  }
  // The default style

  background-color: var(--ac-global-input-field-background-color);
  border-color: var(--button-border-color);
  &:hover:not([disabled]) {
    background-color: var(--ac-global-input-field-border-color-hover);
  }

  &[data-variant="primary"] {
    background-color: var(--ac-global-button-primary-background-color);
    --button-border-color: var(--ac-global-button-primary-border-color);
    color: var(--ac-global-button-primary-foreground-color);
    &:hover:not([disabled]) {
      background-color: var(--ac-global-button-primary-background-color-hover);
    }
  }
  &[data-variant="danger"] {
    background-color: var(--ac-global-button-danger-background-color);
    --button-border-color: var(--ac-global-button-danger-border-color);
    color: var(--ac-global-static-color-white-900);
    &:hover:not([disabled]) {
      background-color: var(--ac-global-button-danger-background-color-hover);
    }
  }
  &[data-variant="success"] {
    background-color: var(--ac-global-button-success-background-color);
    --button-border-color: var(--ac-global-button-success-border-color);
    color: var(--ac-global-static-color-white-900);
    &:hover:not([disabled]) {
      background-color: var(--ac-global-button-success-background-color-hover);
    }
  }
  &[data-variant="quiet"] {
    background-color: transparent;
    --button-border-color: transparent;
    &:hover:not([disabled]) {
      border-color: transparent;
      background-color: var(--ac-global-input-field-background-color-active);
    }
  }

  kbd {
    background-color: var(--ac-global-color-grey-400);
    border-radius: var(--ac-global-rounding-small);
    padding: var(--ac-global-dimension-size-50)
      var(--ac-global-dimension-size-75);
    font-size: var(--ac-global-font-size-xs);
    line-height: var(--ac-global-font-size-xxs);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--ac-global-dimension-static-size-25);
    text-transform: uppercase;
  }

  &[data-variant="primary"] {
    kbd {
      background-color: var(--ac-global-color-grey-700);
    }
  }
`;function N2(n,a){const{size:t,variant:l="default",leadingVisual:i,trailingVisual:r,children:o,css:c,className:d,...u}=n,m=Xt(),h=t||m||"M",b=g.useCallback(f=>s(B,{children:[i,typeof o=="function"?o(f):o,r]}),[i,r,o]);return e(nn,{...u,ref:a,"data-size":h,"data-variant":l,"data-childless":!o,css:p(Xa,c),className:$("react-aria-Button",d),children:b})}const D=g.forwardRef(N2),O2=p`
  text-decoration: none;
  user-select: none;
  &[data-disabled="true"] {
    pointer-events: none;
    cursor: default;
    opacity: var(--ac-opacity-disabled);
  }
`;function $2(n,a){const{size:t="M",variant:l="default",leadingVisual:i,trailingVisual:r,children:o,css:c,isDisabled:d,to:u}=n;return s(Da,{ref:a,"data-size":t,"data-variant":l,"data-childless":!o,"data-disabled":d,css:p(Xa,O2,c),to:u,children:[i,o,r]})}const pl=g.forwardRef($2),B2=p`
  text-decoration: none;
  user-select: none;
  &[data-disabled="true"] {
    pointer-events: none;
    cursor: default;
    opacity: var(--ac-opacity-disabled);
  }
`;function H2(n,a){const{size:t="M",variant:l="default",leadingVisual:i,trailingVisual:r,children:o,css:c,isDisabled:d,target:u="_blank",...m}=n;return s("a",{ref:a,target:u,rel:"noopener noreferrer","data-size":t,"data-variant":l,"data-childless":!o,"data-disabled":d,css:p(Xa,B2,c),tabIndex:d?-1:void 0,"aria-disabled":d,...m,children:[i,o,r]})}const jg=vn.forwardRef(H2),j2=n=>{if(n==="inherit")return"inherit";if(n.startsWith("text-")){const[,a]=n.split("-");return`var(--ac-global-text-color-${a})`}return ha(n)},Z2=n=>p`
  --icon-button-font-size-s: var(--ac-global-font-size-l);
  --icon-button-font-size-m: var(--ac-global-font-size-xl);
  --icon-button-font-size-l: var(--ac-global-font-size-2xl);

  display: flex;
  align-items: center;
  justify-content: center;
  border: var(--ac-global-border-size-thin) solid transparent;
  border-radius: var(--ac-global-rounding-small);
  color: ${j2(n)};
  background-color: transparent;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  padding: 0;

  &[data-size="S"] {
    width: var(--ac-global-button-height-s);
    min-width: var(--ac-global-button-height-s);
    min-height: var(--ac-global-button-height-s);
    height: var(--ac-global-button-height-s);
    .ac-icon-wrap {
      font-size: var(--icon-button-font-size-s);
    }
  }

  &[data-size="M"] {
    width: var(--ac-global-button-height-m);
    min-width: var(--ac-global-button-height-m);
    min-height: var(--ac-global-button-height-m);
    height: var(--ac-global-button-height-m);
    .ac-icon-wrap {
      font-size: var(--icon-button-font-size-m);
    }
  }

  .ac-icon-wrap {
    opacity: 0.7;
    transition: opacity 0.2s ease;
  }

  &[data-hovered] {
    background-color: var(--ac-hover-background);
    .ac-icon-wrap {
      opacity: 1;
    }
  }

  &[data-pressed] {
    background-color: var(--ac-global-color-primary-100);
    color: var(--ac-global-text-color-900);
  }

  &[data-focus-visible] {
    outline: var(--ac-global-border-size-thick) solid var(--ac-focus-ring-color);
    outline-offset: var(--ac-global-border-offset-thin);
  }

  &[data-disabled] {
    opacity: var(--ac-global-opacity-disabled);
    cursor: not-allowed;
  }
`;function $n({size:n="M",color:a="text-700",children:t,...l}){return e(nn,{css:Z2(a),"data-size":n,...l,children:t})}function U2(n,a){const{children:t,elementType:l="div",...i}=n,{styleProps:r}=aa(n,Dr);return e(l,{...Ki(i),...r,ref:a,css:p`
        overflow: hidden;
        box-sizing: border-box;
      `,className:"ac-view",children:t})}const w=g.forwardRef(U2),G2=p`
  display: flex;
`,W2={direction:["flexDirection",ve],wrap:["flexWrap",q2],justifyContent:["justifyContent",pt],alignItems:["alignItems",pt],alignContent:["alignContent",pt]};function Q2(n,a){const{children:t,className:l,...i}=n,r=["base"],{styleProps:o}=aa(i),{styleProps:c}=aa(i,W2),d={...o.style,...c.style};return n.gap!=null&&(d.gap=ut(n.gap,r)),n.columnGap!=null&&(d.columnGap=ut(n.columnGap,r)),n.rowGap!=null&&(d.rowGap=ut(n.rowGap,r)),e("div",{css:G2,...Ki(i),className:$("flex",l),style:d,ref:a,children:t})}function pt(n){return n==="start"?"flex-start":n==="end"?"flex-end":n}function q2(n){return typeof n=="boolean"?n?"wrap":"nowrap":n}const S=g.forwardRef(Q2),X2=p`
  display: flex;
  align-items: center;
  gap: var(--ac-global-dimension-size-100);
`,Y2=g.forwardRef(({size:n,...a},t)=>e(Pa,{size:n,children:e(rs,{...a,ref:t,css:X2,className:"ac-group react-aria-Group"})}));Y2.displayName="Group";function J2(n,a){const{size:t="M",...l}=n;return e(_i,{"data-size":t,className:"ac-textfield",ref:a,...l,css:p(Te,qa)})}const ee=g.forwardRef(J2),eu=p`
  --searchfield-icon-left-padding: var(--textfield-horizontal-padding);

  &[data-size="M"] {
    --searchfield-icon-left-padding: calc(
      var(--textfield-horizontal-padding) - 0.4rem
    );
  }

  display: grid;
  grid-template-areas:
    "label label"
    "icon input"
    "help  help";
  grid-template-columns: auto 1fr;
  .react-aria-Label {
    grid-area: label;
  }
  .ac-search-icon {
    grid-area: icon;
    position: absolute;
    left: var(--searchfield-icon-left-padding);
    top: 50%;
    transform: translateY(-50%);
  }
  .react-aria-Input {
    grid-area: input;
    width: 100%;
  }
  [slot="description"],
  [slot="errorMessage"],
  .react-aria-FieldError {
    grid-area: help;
  }

  /* Adjust the padding if there is an icon */
  .ac-search-icon + .react-aria-Input {
    padding-left: calc(
      2 * var(--searchfield-icon-left-padding) + 1rem
    ) !important;
  }

  &[data-invalid="true"] {
    .ac-search-icon {
      color: var(--ac-global-color-danger);
    }
  }
`;function nu(n,a){const{size:t="M",...l}=n;return e(os,{"data-size":t,className:"ac-searchfield",ref:a,...l,css:p(Te,qa,eu)})}const Ft=g.forwardRef(nu),Gr=g.createContext(null);function au(){const n=g.useContext(Gr);if(!n)throw new Error("useCredentialContext must be used within a CredentialContext.Provider");return n}function tu(n,a){const{size:t="M",children:l,...i}=n,[r,o]=g.useState(!1);return e(Gr.Provider,{value:{isVisible:r,setIsVisible:o},children:e(Pa,{size:t,children:e(_i,{"data-size":t,className:"ac-credentialfield",autoComplete:"off",ref:a,...i,css:p(Te,qa),children:l})})})}const Zg=g.forwardRef(tu);function lu(n,a){const{isVisible:t,setIsVisible:l}=au(),i=Xt(),{disabled:r,readOnly:o,...c}=n;return s("div",{"data-size":i,"data-testid":"credential-input",css:p`
        position: relative;
        display: flex;
        align-items: center;
        width: 100%;
        // The 2px (e.g. 50) is to account making the toggle button to be slightly bigger
        --credential-visibility-toggle-size: calc(
          var(--textfield-input-height) - 2 *
            var(--textfield-vertical-padding) +
            var(--ac-global-dimension-size-50)
        );

        & > input {
          padding-right: calc(
            var(--textfield-vertical-padding) +
              var(--credential-visibility-toggle-size) +
              var(--textfield-vertical-padding)
          ) !important; // Don't want to fight specificity here
        }

        .ac-credential-input__toggle {
          position: absolute;
          right: var(
            --textfield-vertical-padding
          ); // We want it to be nestled evenly
          background: transparent;
          border: none;
          cursor: pointer;
          padding: 0;
          width: var(--credential-visibility-toggle-size);
          height: var(--credential-visibility-toggle-size);
          color: var(--ac-global-text-color-700);
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: var(--ac-global-rounding-small);
          transition: background-color 0.2s;
          background-color: var(--ac-global-color-grey-200);
          &:hover {
            background-color: var(--ac-global-color-grey-300);
          }

          &:focus-visible {
            outline: 2px solid var(--ac-global-color-primary);
            outline-offset: 2px;
          }

          &[disabled] {
            cursor: not-allowed;
            opacity: 0.5;
          }
        }
      `,children:[e(W,{...c,ref:a,type:t?"text":"password",disabled:r,readOnly:o}),e(nn,{className:"ac-credential-input__toggle",onPress:()=>l(!t),isDisabled:r||o,"aria-label":t?"Hide credential":"Show credential",children:e(x,{svg:t?e(u2,{}):e(m2,{})})})]})}const Ug=g.forwardRef(lu),iu=p`
  .react-aria-Input {
    text-align: right;
  }
`,Wr=g.forwardRef(function(a,t){const{size:l="M",...i}=a;return e(ss,{"data-size":l,...i,className:$("ac-textfield react-aria-NumberField",a.className),ref:t,css:p(Te,qa,iu)})}),ru=()=>e(x,{className:"ac-search-icon",svg:e(S2,{})});function hl({onChange:n,debounceMs:a=200,placeholder:t,...l}){const i=g.useMemo(()=>Vi(o=>{g.startTransition(()=>{n(o)})},a),[n,a]),r=g.useCallback(o=>{i(o)},[i]);return s(Ft,{onChange:r,...l,children:[e(ru,{}),e(W,{placeholder:t})]})}const ou=p`
  border: 1px solid var(--ac-global-border-color-light);
  forced-color-adjust: none;
  border-radius: var(--ac-global-rounding-small);
  padding: var(--ac-global-dimension-size-50)
    var(--ac-global-dimension-size-100);
  font-size: var(--ac-global-font-size-s);
  color: var(--ac-global-text-color-900);
  outline: none;
  cursor: default;
  display: flex;
  align-items: center;
  transition: all 200ms;

  &[data-hovered] {
    border-color: var(--ac-global-border-color-dark);
  }

  &[data-focus-visible] {
    outline: 1px solid var(--ac-global-color-primary);
    outline-offset: 1px;
  }

  &[data-selected] {
    border-color: var(--ac-global-color-primary);
    background: var(--ac-global-color-primary-700);
  }
`;function su(n,a){return e(cs,{...n,ref:a,css:ou})}g.forwardRef(su);function cu(n,a){return e(ds,{...n,ref:a,css:Te})}g.forwardRef(cu);const du=p`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: var(--ac-global-dimension-size-50);
  height: 28px;
`;function uu(n,a){return e(us,{...n,ref:a,css:du})}g.forwardRef(uu);function mu(n,a){return e(Pi,{...n,ref:a,children:e("svg",{width:12,height:12,viewBox:"0 0 12 12",children:e("path",{d:"M0 0 L6 6 L12 0"})})})}const tn=g.forwardRef(mu),ei=Ne`
 100% {
  from {
     transform: var(--origin);
     opacity: 0;
   }

   to {
     transform: translateY(0);
     opacity: 1;
   }
  }
`,gu=p`
  box-sizing: border-box;
  --background-color: var(--ac-global-popover-background-color);
  transition:
    transform 200ms,
    opacity 200ms;
  border: 1px solid var(--ac-global-popover-border-color);
  box-shadow: var(--px-overlay-box-shadow);
  border-radius: var(--ac-global-rounding-small);
  background: var(--background-color);
  color: var(--ac-global-text-color-900);
  outline: none;

  &[data-entering],
  &[data-exiting] {
    transform: var(--origin);
    opacity: 0;
  }

  .react-aria-OverlayArrow svg {
    display: block;
    fill: var(--background-color);
    stroke: var(--ac-global-border-color-light);
    stroke-width: 1px;
  }

  &[data-trigger="Select"] {
    min-width: var(--trigger-width);
  }

  &[data-placement="top"] {
    --origin: translateY(8px);

    &:has(.react-aria-OverlayArrow) {
      margin-bottom: 6px;
    }
  }

  &[data-placement="bottom"] {
    --origin: translateY(-8px);

    &:has(.react-aria-OverlayArrow) {
      margin-top: 4px;
    }

    .react-aria-OverlayArrow svg {
      transform: rotate(180deg);
    }
  }

  &[data-placement="right"] {
    --origin: translateX(-8px);

    &:has(.react-aria-OverlayArrow) {
      margin-left: 6px;
    }

    .react-aria-OverlayArrow svg {
      transform: rotate(90deg);
    }
  }

  &[data-placement="left"] {
    --origin: translateX(8px);

    &:has(.react-aria-OverlayArrow) {
      margin-right: 6px;
    }

    .react-aria-OverlayArrow svg {
      transform: rotate(-90deg);
    }
  }

  &[data-entering] {
    animation: ${ei} 200ms;
  }

  &[data-exiting] {
    animation: ${ei} 200ms reverse ease-in;
  }

  .react-aria-Dialog {
    outline: none;
  }

  & div[role="listbox"] {
    padding: var(--ac-global-dimension-size-25);
  }
`;function pu(n,a){return e(Ei,{...n,ref:a,className:$("ac-popover react-aria-Popover",n.className),css:gu})}const le=g.forwardRef(pu),ni=Ne`
  from {
    transform: translateX(100%);
  }
  to {
    transform: translateX(0);
  }
    `,Ia=Ne`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
  `,hu=Ne`
  from {
    transform: scale(0.8);
  }
  to {
    transform: scale(1);
  }
  `,fu=p`
  --modal-width: var(--ac-global-modal-width-M);

  &[data-size="S"] {
    --modal-width: var(--ac-global-modal-width-S);
  }

  &[data-size="M"] {
    --modal-width: var(--ac-global-modal-width-M);
  }

  &[data-size="L"] {
    --modal-width: var(--ac-global-modal-width-L);
  }

  &[data-size="fullscreen"] {
    --modal-width: var(--ac-global-modal-width-FULLSCREEN);
  }

  &[data-variant="slideover"] {
    --visual-viewport-height: 100vh;
    width: var(--modal-width);
    height: var(--visual-viewport-height);
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 100;
    top: 0;
    right: 0;
    left: auto;
    align-items: flex-start;
    justify-content: flex-end;

    &[data-entering] {
      animation: ${ni} 300ms;
    }

    &[data-exiting] {
      animation: ${ni} 300ms reverse ease-in;
    }

    .react-aria-Dialog {
      height: 100%;
      border-radius: 0;
      border-left-color: var(--ac-global-border-color-dark);
      border-top: none;
      border-bottom: none;
      border-right: none;
    }
  }

  &[data-variant="default"] {
    &[data-entering] {
      animation: ${Ia} 200ms;
    }

    &[data-exiting] {
      animation: ${Ia} 200ms reverse ease-in;
    }

    .react-aria-Dialog {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 1001;
      // 90% gives a decent amount of padding around the dialog when it would
      // otherwise be cut off by the edges of the screen
      max-height: calc(100% - var(--ac-global-dimension-size-800));
      overflow: auto;
      // prevent bounce in safari when scrolling
      overscroll-behavior: contain;

      &[data-entering] {
        animation: ${hu} 300ms cubic-bezier(0.175, 0.885, 0.32, 1.275);
      }
    }
  }

  .react-aria-Dialog {
    box-shadow: 0 8px 20px rgba(0 0 0 / 0.1);
    width: var(--modal-width);
    border-radius: var(--ac-global-rounding-medium);
    background: var(--ac-global-background-color-dark);
    color: var(--ac-global-text-color-900);
    border: 1px solid var(--ac-global-border-color-light);
    outline: none;

    & .ac-DialogHeader {
      position: sticky;
      top: 0;
      background: var(--ac-global-background-color-dark);
      z-index: 1;
    }
  }
`;function bu(n,a){const{size:t="M",variant:l="default",...i}=n;return e(ms,{...i,"data-size":t,"data-variant":l,ref:a,css:fu})}const gn=g.forwardRef(bu),yu=p`
  position: fixed;
  inset: 0;
  background: rgba(0 0 0 / 0.5);
  z-index: 1000;

  &[data-entering] {
    // ensure overlay animation is longer than child animations
    animation: ${Ia} 300ms;
  }

  &[data-exiting] {
    // ensure overlay animation is longer than child animations
    animation: ${Ia} 300ms reverse ease-in;
  }
`;function vu(n,a){return e(gs,{...n,"data-testid":"modal-overlay",css:yu,className:$(n.className,"react-aria-ModalOverlay"),isDismissable:n.isDismissable??!0,ref:a})}const pn=g.forwardRef(vu),za=[{key:"15m",label:"Last 15 Min"},{key:"1h",label:"Last Hour"},{key:"12h",label:"Last 12 Hours"},{key:"1d",label:"Last Day"},{key:"7d",label:"Last 7 Days"},{key:"30d",label:"Last Month"}];za.reduce((n,a)=>({...n,[a.key]:a}),{});function Dt(n){const a=Date.now();switch(n){case"15m":return{start:Lt(ps(a))};case"1h":return{start:Lt(St(a,1))};case"12h":return{start:Wn(St(a,12))};case"1d":return{start:Wn(cn(a,1))};case"7d":return{start:Wn(cn(a,7))};case"30d":return{start:Wn(cn(a,30))};default:N()}}function Et(n){return za.some(a=>a.key===n)}function Cu(n){return Et(n)||n==="custom"}const Qr=g.createContext(null);function qr(){return vn.useContext(Qr)}function ku(){const n=qr();if(n===null)throw new Error("useTimeRange must be used within a TimeRangeContextProvider");return n}function Gg({children:n}){const a=Me(o=>o.lastNTimeRangeKey),t=Me(o=>o.setLastNTimeRangeKey),[l,i]=g.useState(()=>Et(a)?{timeRangeKey:a,...Dt(a)}:{timeRangeKey:"7d",...Dt("7d")}),r=g.useCallback(o=>{i(o),Et(o.timeRangeKey)&&t(o.timeRangeKey)},[t]);return e(Qr.Provider,{value:{timeRange:l,setTimeRange:r},children:n})}function Ee(n,a){const t=new Intl.DateTimeFormat(n,{...a});return l=>t.format(l)}function Xr(n){const{locale:a,timeZone:t}=n;return Ee(a,{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:!0,timeZone:t})}function Lu(n){const{locale:a,timeZone:t}=n;return Ee(a,{hour:"2-digit",minute:"2-digit",hour12:!0,timeZone:t})}function Su(n){const{locale:a,timeZone:t}=n;return Ee(a,{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:!0,timeZone:t})}function wu(n){const a=Xr(n);return t=>t.start&&t.end?`${a(t.start)} - ${a(t.end)}`:t.start?`From ${a(t.start)}`:t.end?`Until ${a(t.end)}`:"All Time"}function ai(n){var l;const{timeZone:a,locale:t}=n;return(l=Intl.DateTimeFormat(t,{timeZoneName:"short",timeZone:a}).formatToParts().find(i=>i.type==="timeZoneName"))==null?void 0:l.value}function xu(n){return new Intl.DateTimeFormat(n,{day:"2-digit",month:"2-digit",year:"numeric"}).formatToParts(new Date).map(l=>{switch(l.type){case"day":return"dd";case"month":return"mm";case"year":return"yyyy";case"literal":return l.value;default:return""}}).join("")}function Bn(){const n=Me(a=>a.displayTimezone);return g.useMemo(()=>{const a=n??gr();return{fullTimeFormatter:Xr({locale:Xe(),timeZone:a}),shortTimeFormatter:Lu({locale:Xe(),timeZone:a}),shortDateTimeFormatter:Su({locale:Xe(),timeZone:a}),timeRangeFormatter:wu({locale:Xe(),timeZone:a})}},[n])}const Tu=p`
  width: 130px;
`;function Iu(n){const{value:a,isDisabled:t,onChange:l,size:i="S"}=n,{timeRangeKey:r,start:o,end:c}=a,{timeRangeFormatter:d}=Bn(),u=Me(f=>f.displayTimezone),m=({timeRangeKey:f,start:y,end:v})=>{if(f==="custom")return d({start:y,end:v});const L=za.find(k=>k.key===f);return L?L.label:"invalid"},h=u!==void 0,b=u??gr();return s(we,{children:[s(D,{size:i,leadingVisual:e(x,{svg:e(t2,{})}),isDisabled:t,children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e(B,{children:m(a)}),h&&e(C,{size:"S",color:"text-500",children:ai({locale:Xe(),timeZone:b})})]}),e(ze,{})]}),e(le,{placement:"bottom end",children:e(Ri,{children:({close:f})=>s(B,{children:[e(tn,{}),s(S,{direction:"row",children:[e(zu,{visible:r==="custom",children:r==="custom"&&s(S,{direction:"column",gap:"size-100",height:"100%",children:[e(Q,{level:2,weight:"heavy",children:"Time Range"}),e(C,{color:"text-700",size:"S",children:`Displayed in ${b} (${ai({locale:Xe(),timeZone:b})})`}),e(Vu,{initialValue:{start:o,end:c},timeZone:u,onSubmit:y=>{l&&l({timeRangeKey:"custom",...y}),f()}})]})}),s(Ie,{"aria-label":"time range preset selection",selectionMode:"single",autoFocus:!0,selectedKeys:[r],css:Tu,onSelectionChange:y=>{if(y==="all"){f();return}const v=y.keys().next().value;if(Cu(v))if(v!=="custom"){l({timeRangeKey:v,...Dt(v)}),f();return}else l({timeRangeKey:v,start:o,end:c})},children:[za.map(({key:y,label:v})=>e(Ze,{id:y,children:v},y)),e(Ze,{id:"custom",children:"Custom"},"custom")]})]})]})})})]})}function zu({children:n,visible:a}){return e("div",{css:p`
        display: ${a?"block":"none"};
      `,children:e(w,{borderEndWidth:"thin",borderColor:"light",padding:"size-200",height:"100%",children:n})})}function Wg({size:n="S"}){const{timeRange:a,setTimeRange:t}=ku(),l=g.useCallback(i=>{g.startTransition(()=>{t(i)})},[t]);return e(Iu,{value:a,onChange:l,size:n})}const Au=p`
  --date-field-vertical-padding: 6px;
  --date-field-horizontal-padding: 8px;
  color: var(--ac-global-text-color-900);

  &[data-size="S"] .react-aria-DateInput {
    height: var(--ac-global-input-height-s);
  }

  &[data-size="M"] .react-aria-DateInput {
    height: var(--ac-global-input-height-m);
  }

  .react-aria-DateInput {
    display: flex;
    padding: var(--date-field-vertical-padding)
      var(--date-field-horizontal-padding);
    border: var(--ac-global-border-size-thin) solid
      var(--ac-global-input-field-border-color);
    border-radius: var(--ac-global-rounding-small);
    background-color: var(--ac-global-input-field-background-color);
    width: fit-content;
    box-sizing: border-box;
    min-width: 150px;
    white-space: nowrap;
    forced-color-adjust: none;

    &[data-focus-within] {
      outline: 1px solid var(--ac-global-color-primary);
      outline-offset: -1px;
    }

    &[data-invalid] {
      border-color: var(--ac-global-color-danger);
    }
  }

  .react-aria-DateSegment {
    padding: 0 2px;
    font-variant-numeric: tabular-nums;
    text-align: end;
    color: var(--ac-global-text-color-900);

    &[data-type="literal"] {
      padding: 0;
    }

    &[data-placeholder] {
      color: var(--ac-text-color-placeholder);
      font-style: italic;
    }

    &:focus {
      color: var(--ac-highlight-foreground);
      background: var(--ac-highlight-background);
      outline: none;
      border-radius: var(--ac-global-rounding-small);
      caret-color: transparent;
    }
  }
`;function Mu(n,a){const{css:t,...l}=n;return e(hs,{css:p(Te,Au,t),...l,"data-size":"S",ref:a})}const Kt=g.forwardRef(Mu),Fu=p`
  --date-field-vertical-padding: 6px;
  --date-field-horizontal-padding: 8px;
  color: var(--ac-global-text-color-900);

  .react-aria-DateInput {
    display: flex;
    padding: var(--date-field-vertical-padding)
      var(--date-field-horizontal-padding);
    border: var(--ac-global-border-size-thin) solid
      var(--ac-global-input-field-border-color);
    border-radius: var(--ac-global-rounding-small);
    background-color: var(--ac-global-input-field-background-color);
    width: fit-content;
    min-width: 150px;
    white-space: nowrap;
    forced-color-adjust: none;

    &[data-focus-within] {
      outline: 1px solid var(--ac-global-color-primary);
      outline-offset: -1px;
    }
  }

  .react-aria-DateSegment {
    padding: 0 2px;
    font-variant-numeric: tabular-nums;
    text-align: end;
    color: var(--ac-global-text-color-900);

    &[data-type="literal"] {
      padding: 0;
    }

    &[data-placeholder] {
      color: var(--ac-text-color-placeholder);
      font-style: italic;
    }

    &:focus {
      color: var(--ac-highlight-foreground);
      background: var(--ac-highlight-background);
      outline: none;
      border-radius: var(--ac-global-rounding-small);
      caret-color: transparent;
    }
  }
`;function Du(n,a){return e(fs,{css:p(Te,Fu),...n,ref:a})}g.forwardRef(Du);const Eu=p`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-size-200);
`,ti=p`
  display: flex;
  gap: var(--ac-global-dimension-size-100);
  align-items: start;
  justify-content: end;
  /* Move the button down to align */
  button {
    margin-top: 26px;
  }
`,Ku=p`
  width: 100%;
  display: flex;
  justify-content: flex-end;
  gap: var(--ac-global-dimension-size-100);
`,li=p`
  width: 100%;
  .react-aria-DateInput {
    width: 100%;
    // Eliminate the re-sizing of the DateField as you type
    min-width: 200px;
  }
`;function _u(n,a){return{startDate:n.start?Fl(n.start.toISOString(),a):null,endDate:n.end?Fl(n.end.toISOString(),a):null}}function Vu(n){const{initialValue:a,onSubmit:t,timeZone:l=Ni()}=n,{control:i,handleSubmit:r,formState:{isValid:o},resetField:c,setError:d,clearErrors:u}=Oe({defaultValues:_u(a||{},l)}),m=g.useCallback(()=>{c("startDate",{defaultValue:null})},[c]),h=g.useCallback(()=>{c("endDate",{defaultValue:null})},[c]),b=g.useCallback(f=>{u();const{startDate:y,endDate:v}=f,L=y?y.toDate(l):null,k=v?v.toDate(l):null;if(L&&k&&L>k){d("endDate",{message:"End must be after the start date"});return}t({start:L,end:k})},[t,d,u,l]);return s(an,{css:Eu,"data-testid":"time-range-form",onSubmit:r(b),children:[s("div",{"data-testid":"start-time",css:ti,children:[e(Z,{name:"startDate",control:i,render:({field:{onChange:f,onBlur:y,value:v},fieldState:{invalid:L}})=>s(Kt,{isInvalid:L,onChange:f,onBlur:y,value:v,granularity:"second",hideTimeZone:!0,css:li,children:[e(P,{children:"Start Date"}),e(wt,{children:k=>e(xt,{segment:k})})]})}),e(D,{size:"S",excludeFromTabOrder:!0,onPress:m,"aria-label":"Clear start date and time",leadingVisual:e(x,{svg:e(Yl,{})})})]}),s("div",{"data-testid":"end-time",css:ti,children:[e(Z,{name:"endDate",control:i,render:({field:{onChange:f,onBlur:y,value:v},fieldState:{invalid:L,error:k}})=>s(Kt,{isInvalid:L,onChange:f,onBlur:y,value:v,granularity:"second",hideTimeZone:!0,css:li,children:[e(P,{children:"End Date"}),e(wt,{children:T=>e(xt,{segment:T})}),k?e(ae,{children:k.message}):null]})}),e(D,{size:"S",excludeFromTabOrder:!0,onPress:h,"aria-label":"Clear end date and time",leadingVisual:e(x,{svg:e(Yl,{})})})]}),e("div",{"data-testid":"controls",css:Ku,children:e(D,{isDisabled:!o,size:"S",type:"submit",variant:"primary",children:"Apply"})})]})}const Pu=p(`
  // fixes esoteric overflow bug with VisuallyHidden, which is used by Radio
  // If position is not set to relative, the radio group will explode the parent layout
  // This will impact any other react aria component that uses VisuallyHidden
  // https://github.com/adobe/react-spectrum/issues/5094
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  width: fit-content;
  gap: var(--ac-global-dimension-size-200);
  font-size: var(--ac-global-dimension-static-font-size-100);

  & > .ac-radio:not(:first-of-type) {
    border-left: none;
  }

  & > .ac-radio:first-of-type {
    border-radius: var(--ac-global-rounding-small) 0 0 var(--ac-global-rounding-small);
  }

  & > .ac-radio:last-of-type {
    border-radius: 0 var(--ac-global-rounding-small) var(--ac-global-rounding-small) 0;
  }

  &[data-direction="row"] {
    flex-direction: row;
    flex-wrap: wrap;

    .react-aria-Label {
      flex-basis: 100%;
    }

    [slot="description"] {
      flex-basis: 100%;
    }
  }

  &[data-direction="column"] {
    flex-direction: column;
    align-items: flex-start;
  }

  &[data-size="S"] {
    .ac-radio {
      padding: var(--ac-global-dimension-size-25) var(--ac-global-dimension-size-100);
    }
  }

  &[data-size="L"] {
    .ac-radio {
      padding: var(--ac-global-dimension-size-100) var(--ac-global-dimension-size-150);
    }
  }

  &[data-disabled] {
    opacity: 0.5;
  }

  &[data-readonly] {
    .ac-radio:before {
      opacity: 0.5;
    }
  }

  &:has(.ac-radio[data-focus-visible]) {
    border-radius: var(--ac-global-rounding-small);
    outline: 1px solid var(--ac-global-input-field-border-color-active);
    // display an outline offset around the radio group, accounting for the outline offset of the inner radios
    outline-offset: var(--ac-global-dimension-size-100);
  }
`),Qg=({size:n,css:a,className:t,direction:l="row",...i})=>e(Oi,{"data-size":n,"data-direction":l,className:$("ac-radio-group",t),css:p(Te,Pu,a),...i}),Ru=p(`
  display: flex;
  align-items: center;
  gap: var(--ac-global-dimension-size-50);
  font-size: 14px;
  color: var(--ac-global-text-color-900);
  forced-color-adjust: none;

  &:before {
    content: '';
    display: block;
    width: 1.286rem;
    height: 1.286rem;
    box-sizing: border-box;
    border: 0.143rem solid var(--ac-global-input-field-border-color);
    background: var(--ac-global-input-field-background-color);
    border-radius: 1.286rem;
    transition: all 200ms;
  }

  &[data-pressed]:before {
    border-color: var(--ac-global-input-field-border-color-active);
  }

  &[data-selected] {
    &:before {
      border-color: var(--ac-global-button-primary-background-color);
      border-width: 0.429rem;
    }

    &[data-pressed]:before {
      border-color: var(--ac-global-button-primary-background-color-active);
    }
  }

  &[data-focus-visible]:before {
    outline: 2px solid var(--ac-global-input-field-border-color-active);
    outline-offset: 2px;
  }

  &[data-disabled] {
    opacity: var(--ac-global-opacity-disabled);
  }
`),qg=({className:n,css:a,...t})=>e($i,{className:$("ac-radio",n),css:p(Ru,a),...t}),Nu=p(Xa,`
    text-wrap: nowrap;
    &[data-selected="true"] {
      background-color: var(--ac-global-button-primary-background-color);
      --button-border-color: var(--ac-global-button-primary-border-color);
      color: var(--ac-global-button-primary-foreground-color);
      &:hover:not([data-disabled]) {
        background-color: var(--ac-global-button-primary-background-color-hover);
      }
    }
    &[data-hovered]:not([data-disabled]):not([data-selected="true"]) {
      background-color: var(--ac-global-input-field-border-color-hover);
    }
    &[data-focus-visible] {
      outline: 1px solid var(--ac-global-input-field-border-color-active);
      outline-offset: -2px;
    }
`),Ae=({className:n,css:a,...t})=>{const{leadingVisual:l,trailingVisual:i,size:r,children:o,...c}=t,d=Xt(),u=r??d,m=g.useCallback(h=>s(B,{children:[l,typeof o=="function"?o(h):o,i]}),[l,i,o]);return e(bs,{css:p(Nu,a),"data-size":u,"data-childless":!o,className:$("ac-toggle-button",n),...c,children:m})},Ou=p(`
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  width: fit-content;
  & > button {
    border-radius: 0;
    z-index: 1;

    &[data-disabled] {
      z-index: 0;
    }

    &[data-selected],
    &[data-focus-visible] {
      z-index: 2;
    }
  }

  & > .ac-toggle-button:not(:first-of-type):not([data-selected="true"]) {
    border-left: none;
  }
    
  & > .ac-toggle-button[data-selected="true"]:not(:first-of-type) {
    margin-left: -1px;
  }

  & > .ac-toggle-button:first-of-type {
    border-radius: var(--ac-global-rounding-small) 0 0 var(--ac-global-rounding-small);
  }

  & > .ac-toggle-button:last-of-type {
    border-radius: 0 var(--ac-global-rounding-small) var(--ac-global-rounding-small) 0;
  }

  &:has(.ac-toggle-button[data-focus-visible]) {
    border-radius: var(--ac-global-rounding-small);
    outline: 1px solid var(--ac-global-input-field-border-color-active);
    outline-offset: 1px;
  }
`),fa=({size:n="M",css:a,className:t,selectionMode:l="single",...i})=>e(Pa,{size:n,children:e(ys,{"data-size":n,className:$("ac-toggle-button-group",t),css:p(Ou,a),selectionMode:l,...i})}),$u=p`
  display: flex;
  flex-direction: column;
  max-height: inherit;
  overflow: auto;
  forced-color-adjust: none;
  outline: none;
  box-sizing: border-box;

  &[data-focus-visible] {
    outline: 2px solid var(--focus-ring-color);
    outline-offset: -1px;
  }

  &[data-empty] {
    align-items: center;
    justify-content: center;
    font-style: italic;
    color: var(--ac-global-text-color-700);
  }

  .react-aria-ListBoxItem {
    margin: var(--ac-global-dimension-size-25);
    padding: var(--ac-global-dimension-size-100)
      var(--ac-global-dimension-size-150);
    border-radius: var(--ac-global-rounding-small);
    outline: none;
    cursor: default;
    color: var(--ac-global-text-color-900);
    font-size: var(--ac-global-font-size-s);
    line-height: var(--ac-global-line-height-s);

    position: relative;
    display: flex;
    flex-direction: column;

    &[data-focus-visible] {
      outline: 2px solid var(--ac-focus-ring-color);
      outline-offset: -2px;
    }

    &[data-selected] {
      background: var(--ac-highlight-background);
      color: var(--ac-highlight-foreground);

      &[data-focus-visible] {
        outline-color: var(--ac-highlight-foreground);
        outline-offset: -4px;
      }
    }
    &[data-hovered],
    &[data-active] {
      background: var(--ac-global-background-color-light-hover);
    }
  }
`;function Ie(n){const{css:a,ref:t,...l}=n,i=p($u,a);return e(Di,{css:i,ref:t,...l})}const Bu=p`
  display: inline-flex;
  align-items: center;
  gap: var(--ac-global-dimension-static-size-100);
  font-size: var(--ac-global-dimension-static-font-size-75);
  line-height: var(--ac-global-line-height-s);
  padding: 0 var(--ac-global-dimension-static-size-100);
  border-radius: var(--ac-global-rounding-large);
  border: 1px solid
    lch(from var(--ac-internal-token-color) calc((l) * infinity) c h / 0.3);
  color: lch(from var(--ac-internal-token-color) calc((50 - l) * infinity) 0 0);
  user-select: none;
  text-wrap: nowrap;

  &[data-size="S"] {
    height: var(--ac-global-dimension-static-size-200);
  }

  &[data-size="M"] {
    height: var(--ac-global-dimension-static-size-250);
  }

  &[data-size="L"] {
    height: var(--ac-global-dimension-static-size-300);
  }

  &[data-disabled] {
    opacity: 0.5;
    cursor: not-allowed;
  }

  &[data-theme="light"] {
    background: var(--ac-internal-token-color);
    border-color: var(--ac-internal-token-color);
  }

  &[data-theme="dark"] {
    // generate a new dark token bg color from the input color
    --scoped-token-dark-bg: lch(
      from var(--ac-internal-token-color) l c h / calc(alpha - 0.8)
    );
    background: var(--scoped-token-dark-bg);
    // generate a new dark token text color from the input color
    color: lch(from var(--scoped-token-dark-bg) calc((l) * infinity) c h / 1);
  }

  &[data-interactive]:not([data-disabled]) {
    cursor: pointer;

    > button {
      &:focus-visible {
        outline: 2px solid var(--ac-focus-ring-color);
        border-radius: var(--ac-global-rounding-small);
      }
    }
  }

  &[data-removable] {
    padding-right: var(--ac-global-dimension-static-size-25);
  }

  > button {
    all: unset;
    cursor: pointer;
    display: flex;
    align-items: center;

    &[disabled] {
      cursor: not-allowed;
    }
  }
`;function Hu({children:n,size:a="M"}){return e("span",{"data-size":a,css:p`
        display: flex;
        align-items: center;
        justify-content: center;
        width: var(--ac-global-dimension-static-size-200);
        height: var(--ac-global-dimension-static-size-200);

        &[data-size="M"] {
          margin-right: var(--ac-global-dimension-static-size-50);
        }

        &[data-size="L"] {
          margin-right: var(--ac-global-dimension-static-size-100);
        }
      `,children:n})}function ju({children:n,isDisabled:a,css:t,color:l="var(--ac-global-color-grey-300)",onPress:i,onRemove:r,size:o="M",style:c,leadingVisual:d,...u},m){const{theme:h}=de(),b=d&&o!=="S"?e(Hu,{size:o,children:d}):null,f=r?e("button",{onClick:()=>{r()},disabled:a,"aria-label":"Remove",children:e(x,{svg:e(Ga,{})})}):null,y=()=>i&&r?s(B,{children:[s("button",{onClick:()=>{i()},disabled:a,children:[b,n]}),f]}):i?s("button",{onClick:()=>{i()},disabled:a,children:[b,n]}):r?s(B,{children:[s("span",{children:[b,n]}),f]}):s(B,{children:[b,n]});return e("div",{ref:m,css:p(Bu,t),style:{"--ac-internal-token-color":l,...c},"data-theme":h,"data-size":o,...i&&{"data-interactive":!0},...r&&{"data-removable":!0},...a&&{"data-disabled":!0},...u,children:y()})}const Se=g.forwardRef(ju),Zu=p`
  --ac-slider-handle-width: var(--ac-global-dimension-size-250);
  --ac-slider-handle-height: var(--ac-global-dimension-size-250);
  --ac-slider-handle-halo-width: var(--ac-global-dimension-size-350);
  --ac-slider-handle-border-radius: var(--ac-global-dimension-size-250);
  --ac-slider-handle-background-color: white;
  --ac-slider-track-height: var(--ac-global-dimension-size-100);
  --ac-slider-filled-color: var(--ac-global-color-primary);

  display: grid;
  grid-template-areas:
    "label output"
    "track track";
  gap: var(--ac-global-dimension-size-100);
  grid-template-columns: 1fr auto;
  width: var(
    --ac-alias-single-line-width,
    var(--ac-global-dimension-size-2400)
  );
  color: var(--text-color);

  .ac-slider-label {
    grid-area: label;
  }

  .ac-slider-output {
    grid-area: output;
    min-height: var(--ac-global-dimension-size-350);
  }

  .ac-slider-track {
    grid-area: track;
    position: relative;
    height: var(--ac-slider-track-height, var(--ac-global-border-size-thick));
    width: 100%;

    /* Background track line */
    &:before {
      content: "";
      display: block;
      position: absolute;
      background: var(--ac-global-color-grey-300);
      height: 100%;
      border-radius: var(--ac-global-border-size-thicker);
    }

    /* Filled track line */
    &:after {
      content: "";
      display: block;
      position: absolute;
      background: var(--ac-slider-filled-color);
      height: 100%;
      border-radius: var(--ac-global-border-size-thicker);
    }
  }

  .ac-slider-thumb {
    width: var(--ac-slider-handle-width, var(--ac-global-dimension-size-200));
    height: var(--ac-slider-handle-height, var(--ac-global-dimension-size-200));
    border-radius: var(
      --ac-slider-handle-border-radius,
      var(--ac-global-rounding-medium)
    );
    background-color: var(--ac-slider-handle-background-color);
    border: 2px solid var(--background-color);
    box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
    forced-color-adjust: none;
    transition: border-width
      var(
        --ac-slider-animation-duration,
        var(--ac-global-animation-duration-100)
      )
      ease-in-out;
    position: relative;

    /* show a halo when hovering over the thumb */
    &:hover::after {
      content: "";
      position: absolute;
      background: white;
      opacity: 0.5;
      display: block;
      width: var(--ac-slider-handle-halo-width);
      height: var(--ac-slider-handle-halo-width);
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      border-radius: var(
        --ac-slider-handle-border-radius,
        var(--ac-global-rounding-medium)
      );
      z-index: -1;
    }

    &[data-dragging] {
      background: white;
    }

    &[data-focus-visible] {
      outline: 2px solid var(--ac-focus-ring-color);
    }
  }

  &[data-orientation="horizontal"] {
    flex-direction: column;
    width: 100%;
    align-items: baseline;

    .ac-slider-number-field {
      .react-aria-Input {
        min-width: var(--ac-global-dimension-size-800);
        width: var(--ac-global-dimension-size-800);
        padding: 0 var(--ac-global-dimension-size-100);
        height: var(--ac-global-dimension-size-350);
        text-align: right;
        margin-bottom: var(--ac-global-dimension-size-100);
      }
    }

    .ac-slider-track {
      height: var(--ac-slider-track-height, var(--ac-global-border-size-thick));
      width: calc(100% - var(--ac-slider-handle-width));
      left: calc(var(--ac-slider-handle-width) / 2);

      /* background track line */
      &:before {
        left: calc(var(--ac-slider-handle-width) / -2);
        width: calc(100% + var(--ac-slider-handle-width));
        top: 50%;
        transform: translateY(-50%);
      }

      /* filled track line */
      &:after {
        left: calc(var(--slider-start) - var(--ac-slider-handle-width) / 2);
        width: calc(
          var(--slider-end) - var(--slider-start) +
            var(--ac-slider-handle-width)
        );
        top: 50%;
        transform: translateY(-50%);
        z-index: 1;
      }
    }

    .ac-slider-thumb {
      top: 50%;
      z-index: 2;
    }
  }
`;function Uu({label:n,thumbLabels:a,children:t,css:l,...i},r){return s(Ls,{css:p(Zu,l),...i,ref:r,children:[n&&e(P,{className:"ac-slider-label",children:n}),e(vs,{className:"ac-slider-output",children:typeof t>"u"?e(Wu,{}):t}),e(ks,{className:"ac-slider-track",style:({state:o})=>o.values.length===1?{"--slider-start":"0%","--slider-end":`${o.getThumbPercent(0)*100}%`}:{"--slider-start":`${o.getThumbPercent(0)*100}%`,"--slider-end":`${o.getThumbPercent(1)*100}%`},children:({state:o})=>e(B,{children:o.values.map((c,d)=>e(Cs,{index:d,"aria-label":a==null?void 0:a[d],className:"ac-slider-thumb"},d))})})]})}const Gu=g.forwardRef(Uu);function Xg({onChange:n,...a}){const t=g.useContext(Bi),{step:l,getThumbMinValue:i,getThumbMaxValue:r,values:o,setThumbValue:c}=t,d="defaultValue"in a,u=o[0]===i(0),h=d&&u?a.defaultValue:o[0],b=Ss(ws);return e(Wr,{className:"ac-slider-number-field","aria-labelledby":b.id,value:h,onChange:f=>{n?n(f):typeof f=="number"&&c(0,f)},step:l,maxValue:r(0),minValue:i(0),...a,children:e(W,{})})}function Wu(){const n=g.useContext(Bi);return e(C,{children:n.values.map(a=>a.toString()).join(" – ")})}const Qu=p`
  display: inline-block;
  padding: 0 var(--ac-global-dimension-size-50);
  border-radius: var(--ac-global-rounding-large);
  border: 1px solid var(--ac-global-color-grey-300);
  min-width: var(--ac-global-dimension-size-150);
  background-color: var(--ac-global-background-color-light);
  font-size: var(--ac-global-font-size-xs);
  line-height: var(--ac-global-line-height-xs);
  text-align: center;
  color: var(--ac-global-text-color-900);
  &[data-variant="danger"] {
    background-color: var(--ac-global-background-color-danger);
  }
`;function qu(n){const{children:a,variant:t="default"}=n;return e("span",{css:Qu,"data-variant":t,className:"ac-counter",children:a})}const Xu=p`
  display: flex;
  color: var(--ac-global-text-color-900);
  --ac-tab-border-color: var(--ac-global-border-color-default);

  flex-direction: column;
  height: 100%;

  &[data-orientation="horizontal"] {
    flex: 1 1 auto;
    overflow: hidden;
    box-sizing: border-box;
    .react-aria-TabPanel[data-padded="true"] {
      padding-top: var(--ac-global-dimension-static-size-200);
    }
  }

  &[data-orientation="vertical"] {
    flex-direction: row;
    .react-aria-TabPanel[data-padded="true"] {
      padding-left: var(--ac-global-dimension-static-size-200);
    }
  }
`;function Yr({children:n,css:a,className:t,orientation:l="horizontal",...i}){return e(zs,{css:p(Xu,a),className:$("react-aria-Tabs","ac-tabs",t),orientation:l,...i,children:n})}const Yu=p`
  display: flex;

  &[data-orientation="vertical"] {
    flex-direction: column;
    border-inline-end: 1px solid var(--ac-tab-border-color);

    .react-aria-Tab {
      border-inline-end: 3px solid var(--ac-tab-border-color, transparent);
    }
  }

  &[data-orientation="horizontal"] {
    border-bottom: 1px solid var(--ac-tab-border-color);

    .react-aria-Tab {
      border-bottom: 3px solid var(--ac-tab-border-color);
    }
  }
`;function Jr({children:n,css:a,className:t,...l}){return e(xs,{css:p(Yu,a),className:$("react-aria-TabList",t),...l,children:n})}const Ju=p`
  margin-top: 0;
  padding: 0;
  border-radius: 0;
  outline: none;
  flex: 1 1 auto;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-sizing: border-box;
  height: 100%;

  &[data-focus-visible] {
    outline: unset;
  }
`;function Dn({css:n,className:a,padded:t,...l}){return e(Is,{css:p(Ju,n),className:$("react-aria-TabPanel",a),"data-padded":t,...l})}function Yg({children:n,id:a,...t}){return e(Dn,{id:a,...t,children:({state:{selectedKey:l}})=>l===a?n:null})}const e3=p`
  padding: var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-200);
  cursor: default;
  outline: none;
  position: relative;
  color: var(--ac-global-text-color-700);
  transition: color 200ms;
  --ac-tab-border-color: transparent;
  forced-color-adjust: none;
  font-weight: 600;
  line-height: var(--ac-global-line-height-s);
  font-size: var(--ac-global-font-size-s);

  &[data-hovered],
  &[data-focused] {
    --ac-tab-border-color: var(--ac-global-color-primary-300);
  }

  &[data-selected] {
    --ac-tab-border-color: var(--ac-global-color-primary);
    color: var(--ac-global-text-color-900);
  }

  &[data-disabled] {
    color: var(--ac-global-text-color-300);
    &[data-selected] {
      --ac-tab-border-color: var(--ac-global-text-color-300);
    }
  }

  &[data-focus-visible]:after {
    content: "";
    position: absolute;
    inset: var(--ac-global-dimension-size-50);
    border-radius: var(--ac-global-rounding-small);
    border: 2px solid var(--ac-focus-ring-color);
  }
`;function Yn({children:n,css:a,className:t,...l}){return e(Ts,{css:p(e3,a),className:$("react-aria-Tab",t),...l,children:n})}const ue=({message:n,size:a,className:t})=>s("div",{className:t,css:p`
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 100%;
        gap: var(--ac-global-dimension-static-size-100);
      `,children:[e(no,{isIndeterminate:!0,"aria-label":"loading",size:a}),n!=null?e(C,{children:n}):null]}),n3=Ne`
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0.4;
  }
  100% {
    opacity: 1;
  }
`,a3=Ne`
  0% {
    transform: translateX(-100%);
  }
  50% {
    transform: translateX(100%);
  }
  100% {
    transform: translateX(100%);
  }
`,t3=p`
  display: block;
  background-color: var(--ac-global-color-grey-200);
`,l3=p`
  animation: ${n3} 2s ease-in-out 0.5s infinite;
`,i3=p`
  position: relative;
  overflow: hidden;
  /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
  -webkit-mask-image: -webkit-radial-gradient(white, black);

  &::after {
    animation: ${a3} 2s linear 0.5s infinite;
    background: linear-gradient(
      90deg,
      transparent,
      var(--ac-global-color-grey-300),
      transparent
    );
    content: "";
    position: absolute;
    transform: translateX(-100%);
    bottom: 0;
    left: 0;
    right: 0;
    top: 0;
  }
`,r3=n=>{if(typeof n=="number")return`${n}px`;if(typeof n=="string")switch(n){case"none":return"0";case"XS":return"var(--ac-global-rounding-xsmall)";case"S":return"var(--ac-global-rounding-small)";case"M":return"var(--ac-global-rounding-medium)";case"L":return"var(--ac-global-rounding-large)";case"circle":return"50%";default:return n}return"var(--ac-global-rounding-medium)"},En=g.forwardRef(({width:n="100%",height:a="1.2em",borderRadius:t="S",animation:l="pulse",className:i,...r},o)=>{const c=typeof n=="number"?`${n}px`:n,d=typeof a=="number"?`${a}px`:a,u=r3(t);return e("span",{ref:o,className:$(i,"ac-skeleton"),css:[t3,l==="pulse"&&l3,l==="wave"&&i3,p`
            width: ${c};
            height: ${d};
            border-radius: ${u};
          `],...r})});En.displayName="Skeleton";const Jg=n=>s(S,{direction:"column",gap:"size-100",width:"100%",...n,children:[e(En,{height:100,borderRadius:8,animation:"wave"}),e(En,{height:24,width:"80%",animation:"wave"}),e(En,{height:16,width:"60%",animation:"wave"})]}),o3=p`
  // TODO: respect trailingVisual and leadingVisual inside of phoenix button
  // ideally the content is justified start with leading visual, and trailing visual
  // is positioned at the end
  // the current styling assumes content + 1 trailing visual
  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-width: 200px;
    width: 100%;

    &[data-pressed],
    &:hover {
      --button-border-color: var(--ac-global-input-field-border-color-active);
    }
  }

  button[data-size="S"][data-childless="false"] {
    padding-right: var(--ac-global-dimension-size-50);
  }

  button[data-size="M"][data-childless="false"] {
    padding-right: var(--ac-global-dimension-size-100);
  }

  &[data-invalid="true"] button {
    border-color: var(--ac-global-color-danger);
  }

  .react-aria-SelectValue {
    &[data-placeholder] {
      font-style: italic;
      color: var(--ac-text-color-placeholder);
    }
  }
`;function s3(n,a){const{size:t="M",...l}=n;return e(Pa,{size:t,children:e(As,{"data-size":t,className:"ac-select",ref:a,css:p(Te,o3),...l})})}const We=g.forwardRef(s3),oe=g.forwardRef((n,a)=>{const{children:t,...l}=n;return e(Ze,{...l,ref:a,children:({isSelected:i})=>s(S,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[e("span",{children:t}),i&&e(x,{svg:e(dl,{})})]})})});oe.displayName="SelectItem";const c3=p`
  max-width: 100%;
  height: auto;
`,ep=({src:n,width:a,height:t,controls:l=!0,autoPlay:i=!1,loop:r=!1,muted:o=!1,poster:c,preload:d="none",className:u})=>e("video",{css:c3,src:n,width:a,height:t,controls:l,autoPlay:i,loop:r,muted:o,poster:c,className:u,preload:d,children:"Your browser does not support the video tag."}),me=g.forwardRef(({children:n,...a},t)=>e(Ri,{"data-testid":"dialog",...a,className:$(a.className,"react-aria-Dialog"),ref:t,children:n}));me.displayName="Dialog";const Ve=({children:n,...a})=>e(S,{direction:"column",height:"100%","data-testid":"dialog-content",...a,className:$(a.className,"react-aria-DialogContent"),children:n}),d3=p`
  padding: var(--ac-global-dimension-size-100)
    var(--ac-global-dimension-size-200);
  border-bottom: var(--ac-global-border-size-thin) solid
    var(--ac-global-border-color-dark);
  flex-shrink: 0;
`,Pe=({children:n,...a})=>e("div",{...a,css:d3,className:$(a.className,"ac-DialogHeader"),children:e(S,{width:"100%",justifyContent:"space-between",alignItems:"center",children:n})}),Re=({children:n,...a})=>e(Q,{level:2,"data-testid":"dialog-title",slot:"title",...a,className:$(a.className,"ac-DialogTitle"),children:n}),hn=({children:n,...a})=>e(S,{gap:"size-100",alignItems:"center","data-testid":"dialog-title-extra",...a,className:$(a.className,"ac-DialogTitleExtra"),children:n}),Ue=({children:n,close:a,onPress:t,...l})=>e(D,{size:"S","data-testid":"dialog-close-button",leadingVisual:e(x,{svg:e(Ga,{})}),onPress:i=>{a==null||a(),t==null||t(i)},type:"button",slot:"close",...l,className:$(l.className,"ac-DialogCloseButton"),children:n}),u3=p`
  position: fixed;
  bottom: 24px;
  right: 24px;
  display: flex;
  flex-direction: column-reverse;
  gap: 8px;
  border-radius: 8px;
  outline: none;
`,m3=p`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-static-size-100);
  padding: var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-100);
  border-radius: 8px;
  outline: none;
  width: 400px;
  position: relative;
  --toast-border: 1px solid var(--ac-global-border-color-default);
  --toast-background-color: var(--ac-global-background-color-dark);
  --toast-color: var(--ac-global-static-color-900);
  &[data-theme="light"] {
    --toast-border: 1px solid
      lch(from var(--ac-internal-token-color) calc((50 - l) * infinity) 0 0);
    --toast-background-color: var(--ac-internal-token-color);
    --toast-color: lch(
      from var(--ac-internal-token-color) calc((50 - l) * infinity) 0 0
    );
  }
  &[data-theme="dark"] {
    // generate a new dark token bg color from the input color
    --scoped-token-dark-bg: lch(
      from var(--ac-internal-token-color) l c h / calc(alpha - 0.8)
    );
    --toast-border: 1px solid
      lch(from var(--ac-internal-token-color) calc((l) * infinity) c h / 0.3);
    --toast-background-color: var(--scoped-token-dark-bg);
    // generate a new dark token text color from the input color
    --toast-color: lch(
      from var(--scoped-token-dark-bg) calc((l) * infinity) c h / 1
    );
    // because the background may render with transparency, add a blur to improve
    // text readability
    backdrop-filter: blur(4px);
  }
  background: var(--toast-background-color);
  background-color: var(--toast-background-color);
  border: var(--toast-border);
  color: var(--toast-color);

  &[data-focus-visible] {
    outline: 2px solid slateblue;
    outline-offset: 2px;
  }

  .toast-action-container {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    width: 100%;
  }

  .toast-action-button {
    background: transparent;
    border: var(--toast-border);
    color: var(--toast-color);
    outline: none;
    backdrop-filter: blur(10px);

    &:hover,
    &:focus-visible,
    &:active {
      background: var(--toast-background-color);
      background-color: var(--toast-background-color);
    }
  }

  .react-aria-ToastContent {
    display: flex;
    flex-direction: column;
    flex: 1 1 auto;
    min-width: 0px;

    [slot="title"] {
      align-items: center;
      color: var(--toast-color);
      font-weight: bold;
      display: flex;
      flex-direction: row;
      gap: var(--ac-global-dimension-static-size-50);
    }

    [slot="description"] {
      color: var(--toast-color);
    }
  }

  .react-aria-Button[slot="close"] {
    flex: 0 0 auto;
    background: none;
    border: none;
    appearance: none;
    border-radius: 50%;
    height: 18px;
    width: 18px;
    border: none;
    color: var(--toast-color);
    padding: 0;
    outline: none;

    &[data-focus-visible] {
      border: 1px solid var(--ac-global-input-field-border-color-active);
      background: var(--toast-background-color);
    }

    &[data-hovered] {
      background: var(--toast-background-color);
    }

    &[data-pressed] {
      background: var(--toast-background-color);
    }
  }
`,g3=n=>{switch(n){case"success":return e(x,{svg:e(ul,{})});case"error":return e(x,{svg:e(Vr,{})});default:return null}},p3=n=>{switch(n){case"success":return"var(--ac-global-color-success)";case"error":return"var(--ac-global-color-danger)";default:return"var(--ac-global-background-color-dark)"}},h3=({toast:n})=>{const{theme:a}=de(),t=g3(n.content.variant);return s(Fs,{toast:n,css:m3,className:"react-aria-Toast",style:{viewTransitionName:n.key,"--ac-internal-token-color":p3(n.content.variant)},"data-variant":n.content.variant,"data-theme":a,children:[s("div",{css:p`
          display: flex;
          justify-content: space-between;
          width: 100%;
        `,children:[s(Ms,{children:[s(C,{slot:"title",size:"M",children:[t,n.content.title]}),e(C,{slot:"description",children:n.content.message})]}),e(D,{slot:"close",size:"S",type:"button",leadingVisual:e(x,{svg:e(Ga,{})})})]}),n.content.action?e("div",{className:"toast-action-container",children:typeof n.content.action=="object"&&"text"in n.content.action?e(D,{className:"toast-action-button",onPress:()=>{const l=n.content.action;if(typeof l=="object"&&l&&"onClick"in l){const i=l.closeOnClick??!0,r=()=>{Fn==null||Fn.close(n.key)};l.onClick(r),i&&r()}},size:"S",children:n.content.action.text}):n.content.action}):null]})},f3=p`
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  border-radius: var(--ac-global-rounding-small);
  background: var(--ac-global-tooltip-background-color);
  border: var(--ac-global-border-size-thin) solid
    var(--ac-global-tooltip-border-color);
  color: var(--ac-global-text-color-900);
  forced-color-adjust: none;
  outline: none;
  padding: var(--ac-global-dimension-static-size-100)
    var(--ac-global-dimension-static-size-200);
  max-width: 200px;
  font-size: var(--ac-global-font-size-s);
  /* fixes FF gap */
  transform: translate3d(0, 0, 0);
  transition:
    transform 200ms,
    opacity 200ms;

  &[data-entering],
  &[data-exiting] {
    transform: var(--tooltip-origin);
    opacity: 0;
  }

  &[data-placement="top"] {
    margin-bottom: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateY(4px);
  }

  &[data-placement="bottom"] {
    margin-top: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateY(-4px);

    & .react-aria-OverlayArrow svg {
      transform: rotate(180deg);
    }
  }

  &[data-placement="right"] {
    margin-left: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateX(-4px);

    & .react-aria-OverlayArrow svg {
      transform: rotate(90deg);
    }
  }

  &[data-placement="left"] {
    margin-right: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateX(4px);

    & .react-aria-OverlayArrow svg {
      transform: rotate(-90deg);
    }
  }

  & .react-aria-OverlayArrow svg {
    display: block;
    fill: var(--ac-global-tooltip-background-color);
    stroke: var(--ac-global-tooltip-border-color);
    stroke-width: 1px;
  }
`,b3=p`
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  border-radius: var(--ac-global-rounding-medium);
  background: var(--ac-global-tooltip-background-color);
  border: var(--ac-global-border-size-thin) solid
    var(--ac-global-tooltip-border-color);
  color: var(--ac-global-text-color-900);
  forced-color-adjust: none;
  outline: none;
  padding: var(--ac-global-dimension-static-size-200);
  min-width: 200px;
  font-size: var(--ac-global-font-size-s);
  /* fixes FF gap */
  transform: translate3d(0, 0, 0);
  transition:
    transform 200ms,
    opacity 200ms;

  &[data-entering],
  &[data-exiting] {
    transform: var(--tooltip-origin);
    opacity: 0;
  }

  &[data-placement="top"] {
    margin-bottom: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateY(4px);
  }

  &[data-placement="bottom"] {
    margin-top: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateY(-4px);

    & .react-aria-OverlayArrow svg {
      transform: rotate(180deg);
    }
  }

  &[data-placement="right"] {
    margin-left: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateX(-4px);

    & .react-aria-OverlayArrow svg {
      transform: rotate(90deg);
    }
  }

  &[data-placement="left"] {
    margin-right: var(--ac-global-dimension-static-size-100);
    --tooltip-origin: translateX(4px);

    & .react-aria-OverlayArrow svg {
      transform: rotate(-90deg);
    }
  }

  & .react-aria-OverlayArrow svg {
    display: block;
    fill: var(--ac-global-tooltip-background-color);
    stroke: var(--ac-global-tooltip-border-color);
    stroke-width: 1px;
  }
`;function y3(n,a){const{css:t,...l}=n;return e(Bt,{...l,ref:a,css:p(f3,t)})}const xe=g.forwardRef(y3);function v3(n,a){const{css:t}=n;return e(Pi,{ref:a,css:t,className:$("react-aria-OverlayArrow"),children:e("svg",{width:8,height:8,viewBox:"0 0 8 8",children:e("path",{d:"M0 0 L4 4 L8 0"})})})}const ce=g.forwardRef(v3);function eo({children:n,...a}){return e(se,{...a,children:e("div",{role:"button",children:n})})}function C3(n,a){const{children:t,css:l,width:i,...r}=n;return e(Bt,{...r,ref:a,css:p(b3,l),style:i?{width:i}:{maxWidth:"300px"},children:t})}const ge=g.forwardRef(C3),k3=p`
  display: flex;
  align-items: center;

  a {
    color: var(--ac-global-text-color-700);
    text-decoration: none;
    &:hover {
      text-decoration: underline;
    }
  }

  &[data-current],
  &[data-current] a {
    color: var(--ac-global-text-color-900);
    font-weight: 600;
    cursor: default;
    &:hover {
      text-decoration: none;
    }
  }
`;function L3(n,a){const{children:t,...l}=n;return e(Ds,{css:k3,...l,ref:a,children:({isCurrent:i})=>s(B,{children:[t,!i&&e(x,{svg:e(Za,{})})]})})}const S3=g.forwardRef(L3),w3=p`
  display: flex;
  align-items: center;
  margin: 0;
  padding: 0;
  color: var(--ac-global-text-color-900);
  --breadcrumb-separator-icon-padding: var(--ac-global-dimension-size-50);

  &[data-size="S"] {
    font-size: var(--ac-global-font-size-s);
    line-height: var(--ac-global-line-height-s);
    --breadcrumb-separator-icon-padding: var(--ac-global-dimension-size-25);
  }

  &[data-size="M"] {
    font-size: var(--ac-global-font-size-m);
    line-height: var(--ac-global-line-height-m);
    --breadcrumb-separator-icon-padding: var(--ac-global-dimension-size-50);
  }

  &[data-size="L"] {
    font-size: var(--ac-global-font-size-l);
    line-height: var(--ac-global-line-height-l);
    --breadcrumb-separator-icon-padding: var(--ac-global-dimension-size-75);
  }

  .ac-icon-wrap {
    padding: 0 var(--breadcrumb-separator-icon-padding);
  }
`;function x3(n,a){const{size:t="M",...l}=n;return e(Es,{css:w3,...l,ref:a,"data-size":t})}const T3=g.forwardRef(x3),I3=Ne`
  100% {
    transform: rotate(360deg);
  }
`,z3=Ne`
  0% {
    stroke-dasharray: calc(var(--progress-circle-circumference) * 0.25), var(--progress-circle-circumference);
    stroke-dashoffset: 0;
  }
  80% {
    stroke-dasharray: calc(var(--progress-circle-circumference) * 0.75), var(--progress-circle-circumference);
    stroke-dashoffset: calc(-1 * var(--progress-circle-circumference));
  }
  100% {
    stroke-dasharray: calc(var(--progress-circle-circumference) * 0.25), var(--progress-circle-circumference);
    stroke-dashoffset: calc(-1.25 * var(--progress-circle-circumference));
  }
`,A3=p`
  &[data-size="S"] {
    --progress-circle-size: 18px;
    --progress-circle-stroke-width: 2px;
  }
  &[data-size="M"] {
    --progress-circle-size: 32px;
    --progress-circle-stroke-width: 3px;
  }

  --progress-circle-center: calc(var(--progress-circle-size) / 2);
  --progress-circle-radius: calc(
    var(--progress-circle-center) - var(--progress-circle-stroke-width)
  );
  --progress-circle-circumference: calc(
    2 * 3.141592653589793 * var(--progress-circle-radius)
  );

  // Progress calculations for determinate mode
  --progress-circle-value: 0;
  --progress-circle-dasharray: var(--progress-circle-circumference)
    var(--progress-circle-circumference);
  --progress-circle-dashoffset: calc(
    var(--progress-circle-circumference) -
      (
        var(--progress-circle-value) / 100 *
          var(--progress-circle-circumference)
      )
  );

  .progress-circle__svg {
    width: var(--progress-circle-size);
    height: var(--progress-circle-size);
    fill: none;
    display: block;
  }

  .progress-circle__background {
    cx: var(--progress-circle-center);
    cy: var(--progress-circle-center);
    r: var(--progress-circle-radius);
    stroke: var(--ac-global-color-grey-300);
    stroke-width: var(--progress-circle-stroke-width);
  }

  .progress-circle__arc {
    cx: var(--progress-circle-center);
    cy: var(--progress-circle-center);
    r: var(--progress-circle-radius);
    stroke: var(--ac-global-color-primary);
    stroke-width: var(--progress-circle-stroke-width);
    transition: stroke-dashoffset 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    stroke-dasharray: var(--progress-circle-dasharray);
    stroke-dashoffset: var(--progress-circle-dashoffset);
  }

  &[data-indeterminate] {
    .progress-circle__svg {
      animation: ${I3} 3s linear infinite;
    }
    .progress-circle__arc {
      animation: ${z3} 3s cubic-bezier(0.4, 0, 0.2, 1) infinite;
      stroke-dasharray:
        calc(var(--progress-circle-circumference) * 0.25),
        var(--progress-circle-circumference);
      stroke-dashoffset: 0;
    }
  }
`,M3=p`
  inline-size: var(--ac-global-dimension-size-2400);
  height: var(--ac-global-dimension-size-75);

  .progress-bar__track {
    forced-color-adjust: none;
    height: 100%;
    border-radius: 3px;
    overflow: hidden;
    background-color: var(
      --mod-barloader-track-color,
      var(--ac-global-color-grey-300)
    );
  }

  .progress-bar__fill {
    background: var(--mod-barloader-fill-color, var(--ac-global-color-primary));
    height: 100%;
  }
`;function F3(n,a){const{isIndeterminate:t=!1,value:l,size:i="M"}=n;return e(Hi,{...n,"data-size":i,"data-indeterminate":t||void 0,css:A3,ref:a,style:!t&&l!=null?{"--progress-circle-value":l}:void 0,children:s("svg",{className:"progress-circle__svg",children:[e("circle",{className:"progress-circle__background"}),e("circle",{className:"progress-circle__arc"})]})})}const no=g.forwardRef(F3);function D3({width:n,height:a,...t},l){return e(Hi,{...t,ref:l,css:M3,style:{width:n,height:a},children:({percentage:i})=>e("div",{className:"progress-bar__track",children:e("div",{className:"progress-bar__fill",style:{width:i+"%"}})})})}const E3=g.forwardRef(D3),K3=p`
  list-style: none;
  padding: 0;
  margin: 0;

  & li {
    position: relative;
    padding: var(--ac-global-dimension-static-size-200);

    &:not(:first-of-type)::after {
      content: " ";
      border-top: 1px solid var(--ac-global-border-color-default);
      position: absolute;
      left: var(--ac-global-dimension-static-size-200);
      right: 0;
      top: 0;
    }
  }

  &[data-list-size="S"] {
    & li {
      padding: var(--ac-global-dimension-static-size-100);

      &:not(:first-of-type)::after {
        left: var(--ac-global-dimension-static-size-100);
      }
    }
  }
`;function _3({size:n="M",children:a,...t},l){return e("ul",{ref:l,css:K3,"data-list-size":n,...t,children:a})}const np=g.forwardRef(_3);function V3({children:n,...a},t){return e("li",{ref:t,...a,children:n})}const ap=g.forwardRef(V3),P3=Ne`
  from {
    transform: translate(-50%, var(--ac-global-dimension-size-450));
    opacity: 0;
  }
  to {
    transform: translate(-50%, 0);
    opacity: 1;
  }
`,R3=p`
  position: absolute;
  bottom: var(--ac-global-dimension-size-450);
  left: 50%;
  transform: translateX(-50%);
  z-index: 10;
  box-shadow:
    0px 10px 20px 0px rgba(0, 0, 0, 0.1),
    0px 4px 8px 0px rgba(0, 0, 0, 0.1);
  border-radius: var(--ac-global-rounding-medium);
  padding: var(--ac-global-dimension-size-100);
  background-color: var(--ac-floating-toolbar-background-color);
  border: 1px solid var(--ac-floating-toolbar-border-color);
  animation: ${P3} 0.1s ease-in-out;
`,tp=({children:n})=>e("div",{css:R3,children:n}),N3=p`
  display: flex;

  gap: var(--ac-global-dimension-size-100);

  &[data-orientation="vertical"] {
    flex-direction: column;
    align-items: start;
  }

  &[data-orientation="horizontal"] {
    flex-direction: row;
    align-items: center;
  }

  .react-aria-Group {
    display: contents;
  }
`;function O3(n,a){return e(Ks,{...n,ref:a,css:N3,children:n.children})}const $3=g.forwardRef(O3);$3.displayName="Toolbar";const B3=p`
  align-self: stretch;
  background-color: var(--ac-global-border-color-default);

  &[aria-orientation="vertical"] {
    width: 1px;
    margin: 0 var(--ac-global-dimension-size-50);
  }

  &:not([aria-orientation="vertical"]) {
    border: none;
    height: 1px;
    width: 100%;
    margin: var(--ac-global-dimension-size-50) 0;
  }
`;function H3(n,a){return e(_s,{...n,ref:a,css:B3,className:"ac-separator react-aria-Separator"})}const j3=g.forwardRef(H3);j3.displayName="Separator";const Z3=n=>p`
  --scope-border-color: ${(n==null?void 0:n.borderColor)??"var(--ac-global-border-color-default)"};
  --collapsible-card-animation-duration: 200ms;
  --collapsible-card-icon-size: var(--ac-global-dimension-size-300);

  display: flex;
  flex-direction: column;
  background-color: var(--ac-global-background-color-dark);
  color: var(--ac-global-text-color-900);
  border-radius: var(--ac-global-rounding-medium);
  border: 1px solid var(--scope-border-color);
  overflow: hidden;

  /* Card Header Styles */
  & > header {
    display: flex;
    flex-direction: row;
    flex: none;
    justify-content: space-between;
    align-items: center;
    padding: 0 var(--ac-global-dimension-static-size-200);
    height: var(--ac-global-card-header-height);
    transition: background-color 0.2s ease-in-out;

    & .card__collapse-toggle-icon {
      width: var(--collapsible-card-icon-size);
      height: var(--collapsible-card-icon-size);
      font-size: 1.3em;
      color: inherit;
      display: flex;
      margin-right: var(--ac-global-dimension-static-size-100);
      transition: transform ease var(--collapsible-card-animation-duration);

      & svg {
        height: var(--collapsible-card-icon-size);
        width: var(--collapsible-card-icon-size);
      }
    }

    & .card__title {
      font-size: var(--ac-global-font-size-m);
      line-height: var(--ac-global-line-height-m);
      display: flex;
      align-items: center;
      gap: var(--ac-global-dimension-static-size-100);
    }

    & .card__sub-title {
      color: var(--ac-global-text-color-700);
    }

    /* Collapsible button styles */
    & .card__collapsible-button {
      display: flex;
      flex: 1;
      flex-direction: row;
      align-items: center;
      text-align: left;
      width: 100%;
      height: 100%;
      appearance: none;
      cursor: pointer;
      color: var(--ac-global-text-color-900);
    }
  }

  &[data-collapsed="false"][data-title-separator="true"] > header {
    border-bottom: 1px solid var(--scope-border-color);
  }

  /* Card Body Styles */
  & .card__body {
    flex: 1 1 auto;
    &[data-scrollable="true"] {
      overflow-y: auto;
    }
  }

  /* Compact variant styles */
  &[data-variant="compact"] .card__title {
    font-size: var(--ac-global-font-size-m);
    line-height: var(--ac-global-line-height-m);
  }

  /* Collapsible behavior */
  &[data-collapsible="true"] {
    & > header:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
  }

  &[data-collapsed="true"] {
    & .card__body {
      display: none !important;
    }
    & .card__collapse-toggle-icon {
      transform: rotate(-90deg);
    }
  }
`;function U3({title:n,titleExtra:a,titleSeparator:t=!0,subTitle:l,children:i,collapsible:r=!1,defaultOpen:o=!0,scrollBody:c=!1,extra:d,onCollapseChange:u,...m},h){const{styleProps:b}=aa(m,Dr),[f,y]=g.useState(r?!o:!1),v=g.useId(),L=g.useId(),k=g.useId(),T=g.useEffectEvent(V=>{u==null||u(V)});g.useEffect(()=>{T(f)},[f]);const I=s("div",{children:[s(Q,{level:3,weight:"heavy",className:"card__title",children:[n,a]}),l&&e(Q,{level:4,className:"card__sub-title",children:l})]});return s("section",{ref:h,css:Z3(b.style),className:"card","data-collapsible":r,"data-collapsed":f,"data-title-separator":t,style:b.style,children:[s("header",{id:v,children:[r?s("button",{onClick:()=>{y(!f)},className:"card__collapsible-button button--reset",id:L,"aria-controls":k,"aria-expanded":!f,children:[e(x,{svg:e(Pr,{}),className:"card__collapse-toggle-icon","aria-hidden":"true"}),I]}):I,d]}),e("div",{className:"card__body",id:k,"aria-labelledby":v,"aria-hidden":f,"data-scrollable":c,children:i})]})}const ao=g.forwardRef(U3),G3=p`
  --selected-color: var(--ac-global-checkbox-selected-color);
  --selected-color-pressed: var(--ac-global-checkbox-selected-color-pressed);
  --checkmark-color: var(--ac-global-checkbox-checkmark-color);
  --border-color: var(--ac-global-checkbox-border-color);
  --border-color-pressed: var(--ac-global-checkbox-border-color-pressed);
  --border-color-hover: var(--ac-global-checkbox-border-color-hover);
  --focus-ring-color: var(--ac-focus-ring-color);
  --checkbox-size: var(--ac-global-dimension-static-size-200);

  display: flex;
  /* This is needed so the HiddenInput is positioned correctly */
  position: relative;
  align-items: center;
  gap: var(--ac-global-dimension-size-100);
  forced-color-adjust: none;
  cursor: pointer;

  .checkbox {
    box-sizing: border-box;
    width: var(--checkbox-size);
    height: var(--checkbox-size);
    border: 2px solid var(--border-color);
    border-radius: var(--ac-global-rounding-small);
    transition: all 200ms;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }

  .checkbox svg {
    width: 1rem;
    height: 1rem;
    fill: none;
    stroke: var(--checkmark-color);
    stroke-width: 3px;
    stroke-dasharray: 22px;
    stroke-dashoffset: 66;
    transition: all 200ms;
  }

  &[data-pressed] .checkbox {
    border-color: var(--border-color-pressed);
  }

  &[data-is-hovered] .checkbox {
    border-color: var(--border-color-hover);
  }

  &[data-focus-visible] .checkbox {
    outline: 2px solid var(--focus-ring-color);
    outline-offset: 2px;
  }

  &[data-selected],
  &[data-indeterminate] {
    .checkbox {
      border-color: var(--selected-color);
      background: var(--selected-color);
    }

    &[data-pressed] .checkbox {
      border-color: var(--selected-color-pressed);
      background: var(--selected-color-pressed);
    }

    .checkbox svg {
      stroke-dashoffset: 44;
    }
  }

  &[data-indeterminate] {
    & .checkbox svg {
      stroke: none;
      fill: var(--checkmark-color);
    }
  }

  &[data-disabled] {
    cursor: not-allowed;
    opacity: 0.5;
  }
`;function W3(n,a){const{children:t,isHovered:l,...i}=n;return e(Vs,{...i,ref:a,css:G3,"data-is-hovered":l||void 0,children:({isIndeterminate:r})=>s(B,{children:[e("div",{className:"checkbox",children:e("svg",{viewBox:"0 0 18 18","aria-hidden":"true",children:r?e("rect",{x:1,y:7.5,width:15,height:3}):e("polyline",{points:"1 9 7 14 15 4"})})}),t]})})}const fn=g.forwardRef(W3),Q3=p`
  display: flex;
  position: relative;
  align-items: center;
  gap: var(--ac-global-dimension-size-100);
  color: var(--ac-global-text-color-900);
  font-size: var(--ac-global-font-size-m);
  line-height: var(--ac-global-line-height-m);

  .indicator {
    width: var(--ac-global-dimension-size-400);
    height: var(--ac-global-dimension-size-150);
    background: var(--ac-global-color-grey-300);
    border-radius: var(--ac-global-rounding-medium);
    transition: background 0.1s ease-in-out;
    position: relative;

    &:before {
      content: "";
      position: absolute;
      top: 50%;
      left: 0;
      transform: translateY(-50%);
      width: var(--ac-global-dimension-size-250);
      height: var(--ac-global-dimension-size-250);
      background: var(--ac-global-color-grey-500);
      border-radius: 50%;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      transition: all 0.1s ease-in-out;
    }

    &:hover::after {
      content: "";
      position: absolute;
      top: 50%;
      left: calc(var(--ac-global-dimension-size-250) / 2);
      transform: translate(-50%, -50%);
      width: var(--ac-global-dimension-size-350);
      height: var(--ac-global-dimension-size-350);
      background: var(--ac-global-color-primary);
      border-radius: 50%;
      opacity: 0.4;
      transition: all 0.1s ease-in-out;
    }
  }

  &[data-selected] {
    .indicator {
      background: var(--ac-global-color-primary-700);

      &:before {
        background: var(--ac-global-color-primary);
        transform: translateY(-50%)
          translateX(
            calc(
              var(--ac-global-dimension-size-400) - var(
                  --ac-global-dimension-size-250
                )
            )
          );
      }

      &:hover::after {
        left: calc(
          var(--ac-global-dimension-size-400) - var(
              --ac-global-dimension-size-250
            ) +
            var(--ac-global-dimension-size-250) / 2
        );
      }
    }
  }

  &[data-focus-visible] .indicator {
    outline: 2px solid var(--ac-focus-ring-color);
    outline-offset: 2px;
  }

  &[data-label-placement="start"] {
    flex-direction: row-reverse;
  }

  &[data-label-placement="end"] {
    flex-direction: row;
  }
`;function q3({children:n,labelPlacement:a="end",...t},l){return s(Ps,{...t,ref:l,css:Q3,"data-label-placement":a,children:[e("div",{className:"indicator"}),n]})}const lp=g.forwardRef(q3),X3=p`
  --menu-min-width: 250px;
  min-width: var(--menu-min-width);
  flex: 1 1 auto;
  overflow-y: auto;
  overflow-x: hidden;
  padding: var(--ac-global-dimension-static-size-50);
  &:focus-visible {
    border-radius: var(--ac-global-rounding-small);
    outline: 2px solid var(--ac-global-color-primary);
    outline-offset: 0px;
  }
  &[data-empty] {
    align-items: center;
    justify-content: center;
    display: flex;
    padding: var(--ac-global-dimension-static-size-100);
  }
`,Ya=Rs,ta=({className:n,...a})=>e(Ns,{className:$("react-aria-Menu",n),css:X3,...a}),Y3=p`
  margin: var(--ac-global-dimension-static-size-100);
  padding: var(--ac-global-dimension-static-size-100) var(--ac-global-dimension-static-size-200);
  border-radius: var(--ac-global-rounding-small);
  outline: none;
  cursor: default;
  color: var(--ac-global-text-color-900);
  position: relative;
  display: flex;
  gap: var(--ac-global-dimension-static-size-100);
  align-items: center;
  justify-content: space-between;

  &[data-selected] {
    background-color: var(--ac-highlight-background);
    color: var(--ac-highlight-foreground);
    i {
      color: var(--ac-global-color-primary);
    }
  }

  &[data-open],
  &[data-focused],
  &[data-hovered] {
    background-color: var(--ac-global-menu-item-background-color-hover);
  }

  &[data-disabled] {
    cursor: not-allowed;
    color: var(--ac-global-color-text-300);
  }

  &[data-focus-visible] {
    outline: none;
  }
}

@media (forced-colors: active) {
  &[data-focused] {
    forced-color-adjust: none;
    background: Highlight;
    color: HighlightText;
  }
`,Ke=({className:n,...a})=>{const t=a.textValue||(typeof a.children=="string"?a.children:void 0);return e(Os,{...a,css:Y3,className:$("react-aria-MenuItem",n),textValue:t,children:({hasSubmenu:l,isSelected:i})=>s(B,{children:[a.children,i&&e(x,{svg:e(dl,{})}),l&&e(x,{svg:e(Za,{})})]})})},J3=p`
  overflow-y: hidden;
`,ii=({children:n,placement:a="bottom end",...t})=>s(le,{shouldFlip:!1,placement:a,css:J3,...t,children:[e(tn,{}),e("div",{css:p`
          min-height: 300px;
          display: flex;
          flex-direction: column;
          height: 100%;
          min-width: 300px;
          max-height: inherit;
        `,children:n})]}),ri=({children:n})=>e("div",{css:p`
        padding: var(--ac-global-dimension-static-size-100);
        border-bottom: 1px solid var(--ac-global-menu-border-color);
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
        gap: var(--ac-global-dimension-static-size-100);
      `,children:n}),ip=({children:n,leadingContent:a,trailingContent:t})=>s(S,{direction:"row",gap:"size-50",alignItems:"center",wrap:"nowrap",minHeight:30,children:[a,e(Q,{level:4,weight:"heavy",css:p`
          flex: 1 1 auto;
          width: 100%;
        `,children:n}),t]}),e5=({children:n})=>e("div",{css:p`
        padding: var(--ac-global-dimension-static-size-100);
        border-top: 1px solid var(--ac-global-menu-border-color);
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
        gap: var(--ac-global-dimension-static-size-50);
      `,children:n}),n5=({children:n})=>e(C,{color:"grey-400",fontStyle:"italic",css:p`
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      `,children:n}),rp=()=>e($s,{queue:Fn,css:u3,className:"react-aria-ToastRegion",children:({toast:n})=>e(h3,{toast:n})}),Aa={OPENAI:["required","auto","none"],AZURE_OPENAI:["required","auto","none"],DEEPSEEK:["required","auto","none"],XAI:["required","auto","none"],OLLAMA:["required","auto","none"],ANTHROPIC:["any","auto","none"],AWS:["any","auto","none"]},a5=(n,a)=>{switch(n){case"AZURE_OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":case"OPENAI":return Le(a)&&"type"in a&&typeof a.type=="string"?a.type:a;case"AWS":return Le(a)&&"type"in a&&typeof a.type=="string"?a.type:a;case"ANTHROPIC":return Le(a)&&"type"in a&&typeof a.type=="string"?a.type:a;case"GOOGLE":return"auto";default:N()}},op=n=>n in Aa,oi=(n,a)=>{var t;return((t=Aa[n])==null?void 0:t.includes(a))??!1},Ma="tool_",ht=n=>`${Ma}${n}`,ft=n=>n.startsWith(Ma)?n.slice(Ma.length):n,t5=({choiceType:n})=>{switch(n){case"any":case"required":return s(S,{gap:"size-100",alignItems:"center",justifyContent:"space-between",width:"100%",children:[e("span",{children:"Use at least one tool"}),e(Se,{color:"var(--ac-global-color-grey-900)",size:"S",children:n})]});case"none":return s(S,{gap:"size-100",alignItems:"center",justifyContent:"space-between",width:"100%",children:[e("span",{children:"Don't use any tools"}),e(Se,{color:"var(--ac-global-color-grey-900)",size:"S",children:n})]});case"auto":default:return s(S,{gap:"size-100",alignItems:"center",justifyContent:"space-between",width:"100%",children:[e("span",{children:"Tools auto-selected by LLM"}),e(Se,{color:"var(--ac-global-color-grey-900)",size:"S",children:n})]})}};function sp({choice:n,onChange:a,toolNames:t,provider:l}){const i=a5(l,n),o=oi(l,i)?i:ht(g0(n)??"");return s(We,{value:o,"aria-label":"Tool Choice for an LLM",onChange:c=>{if(typeof c=="string"){if(c.startsWith(Ma))switch(l){case"AZURE_OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":case"OPENAI":a(Zl({type:"function",function:{name:ft(c)}}));break;case"AWS":a(Gl({type:"tool",name:ft(c)}));break;case"ANTHROPIC":a(Ul({type:"tool",name:ft(c)}));break;default:N()}else if(oi(l,c))switch(l){case"AZURE_OPENAI":case"DEEPSEEK":case"XAI":case"OLLAMA":case"OPENAI":a(Zl(c));break;case"AWS":a(Gl({type:c}));break;case"ANTHROPIC":a(Ul({type:c}));break;default:N()}}},children:[e(P,{children:"Tool Choice"}),s(D,{children:[e(Ge,{}),e(ze,{})]}),e(le,{children:e(Ie,{children:[...Aa[l]?Aa[l].map(c=>e(oe,{id:c,textValue:c,children:e(t5,{choiceType:c})},c)):[],...t.map(c=>e(oe,{id:ht(c),textValue:c,children:c},ht(c)))]})})]})}const l5=({height:n})=>s("svg",{viewBox:"0 0 24 24",width:n,height:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"Azure"}),e("path",{d:"M11.49 2H2v9.492h9.492V2h-.002z",fill:"#F25022"}),e("path",{d:"M22 2h-9.492v9.492H22V2z",fill:"#7FBA00"}),e("path",{d:"M11.49 12.508H2V22h9.492v-9.492h-.002z",fill:"#00A4EF"}),e("path",{d:"M22 12.508h-9.492V22H22v-9.492z",fill:"#FFB900"})]}),i5=({height:n})=>s("svg",{viewBox:"0 0 24 24",width:n,height:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"Google"}),e("defs",{children:s("linearGradient",{id:"lobe-icons-google-fill",x1:"0%",x2:"68.73%",y1:"100%",y2:"30.395%",children:[e("stop",{offset:"0%",stopColor:"#1C7DFF"}),e("stop",{offset:"52.021%",stopColor:"#1C69FF"}),e("stop",{offset:"100%",stopColor:"#F0DCD6"})]})}),e("path",{d:"M12 24A14.304 14.304 0 000 12 14.304 14.304 0 0012 0a14.305 14.305 0 0012 12 14.305 14.305 0 00-12 12",fill:"url(#lobe-icons-google-fill)",fillRule:"nonzero"})]}),r5=({height:n})=>s("svg",{fill:"var(--ac-global-text-color-900)",fillRule:"evenodd",viewBox:"0 0 24 24",width:n,height:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"OpenAI"}),e("path",{d:"M21.55 10.004a5.416 5.416 0 00-.478-4.501c-1.217-2.09-3.662-3.166-6.05-2.66A5.59 5.59 0 0010.831 1C8.39.995 6.224 2.546 5.473 4.838A5.553 5.553 0 001.76 7.496a5.487 5.487 0 00.691 6.5 5.416 5.416 0 00.477 4.502c1.217 2.09 3.662 3.165 6.05 2.66A5.586 5.586 0 0013.168 23c2.443.006 4.61-1.546 5.361-3.84a5.553 5.553 0 003.715-2.66 5.488 5.488 0 00-.693-6.497v.001zm-8.381 11.558a4.199 4.199 0 01-2.675-.954c.034-.018.093-.05.132-.074l4.44-2.53a.71.71 0 00.364-.623v-6.176l1.877 1.069c.02.01.033.029.036.05v5.115c-.003 2.274-1.87 4.118-4.174 4.123zM4.192 17.78a4.059 4.059 0 01-.498-2.763c.032.02.09.055.131.078l4.44 2.53c.225.13.504.13.73 0l5.42-3.088v2.138a.068.068 0 01-.027.057L9.9 19.288c-1.999 1.136-4.552.46-5.707-1.51h-.001zM3.023 8.216A4.15 4.15 0 015.198 6.41l-.002.151v5.06a.711.711 0 00.364.624l5.42 3.087-1.876 1.07a.067.067 0 01-.063.005l-4.489-2.559c-1.995-1.14-2.679-3.658-1.53-5.63h.001zm15.417 3.54l-5.42-3.088L14.896 7.6a.067.067 0 01.063-.006l4.489 2.557c1.998 1.14 2.683 3.662 1.529 5.633a4.163 4.163 0 01-2.174 1.807V12.38a.71.71 0 00-.363-.623zm1.867-2.773a6.04 6.04 0 00-.132-.078l-4.44-2.53a.731.731 0 00-.729 0l-5.42 3.088V7.325a.068.068 0 01.027-.057L14.1 4.713c2-1.137 4.555-.46 5.707 1.513.487.833.664 1.809.499 2.757h.001zm-11.741 3.81l-1.877-1.068a.065.065 0 01-.036-.051V6.559c.001-2.277 1.873-4.122 4.181-4.12.976 0 1.92.338 2.671.954-.034.018-.092.05-.131.073l-4.44 2.53a.71.71 0 00-.365.623l-.003 6.173v.002zm1.02-2.168L12 9.25l2.414 1.375v2.75L12 14.75l-2.415-1.375v-2.75z"})]}),o5=({height:n})=>s("svg",{fill:"var(--ac-global-text-color-900)",fillRule:"evenodd",viewBox:"0 0 24 24",width:n,height:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"Anthropic"}),e("path",{d:"M13.827 3.52h3.603L24 20h-3.603l-6.57-16.48zm-7.258 0h3.767L16.906 20h-3.674l-1.343-3.461H5.017l-1.344 3.46H0L6.57 3.522zm4.132 9.959L8.453 7.687 6.205 13.48H10.7z"})]}),s5=({height:n})=>s("svg",{viewBox:"0 0 24 24",width:n,height:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"DeepSeek"}),e("path",{d:"M23.748 4.482c-.254-.124-.364.113-.512.234-.051.039-.094.09-.137.136-.372.397-.806.657-1.373.626-.829-.046-1.537.214-2.163.848-.133-.782-.575-1.248-1.247-1.548-.352-.156-.708-.311-.955-.65-.172-.241-.219-.51-.305-.774-.055-.16-.11-.323-.293-.35-.2-.031-.278.136-.356.276-.313.572-.434 1.202-.422 1.84.027 1.436.633 2.58 1.838 3.393.137.093.172.187.129.323-.082.28-.18.552-.266.833-.055.179-.137.217-.329.14a5.526 5.526 0 01-1.736-1.18c-.857-.828-1.631-1.742-2.597-2.458a11.365 11.365 0 00-.689-.471c-.985-.957.13-1.743.388-1.836.27-.098.093-.432-.779-.428-.872.004-1.67.295-2.687.684a3.055 3.055 0 01-.465.137 9.597 9.597 0 00-2.883-.102c-1.885.21-3.39 1.102-4.497 2.623C.082 8.606-.231 10.684.152 12.85c.403 2.284 1.569 4.175 3.36 5.653 1.858 1.533 3.997 2.284 6.438 2.14 1.482-.085 3.133-.284 4.994-1.86.47.234.962.327 1.78.397.63.059 1.236-.03 1.705-.128.735-.156.684-.837.419-.961-2.155-1.004-1.682-.595-2.113-.926 1.096-1.296 2.746-2.642 3.392-7.003.05-.347.007-.565 0-.845-.004-.17.035-.237.23-.256a4.173 4.173 0 001.545-.475c1.396-.763 1.96-2.015 2.093-3.517.02-.23-.004-.467-.247-.588zM11.581 18c-2.089-1.642-3.102-2.183-3.52-2.16-.392.024-.321.471-.235.763.09.288.207.486.371.739.114.167.192.416-.113.603-.673.416-1.842-.14-1.897-.167-1.361-.802-2.5-1.86-3.301-3.307-.774-1.393-1.224-2.887-1.298-4.482-.02-.386.093-.522.477-.592a4.696 4.696 0 011.529-.039c2.132.312 3.946 1.265 5.468 2.774.868.86 1.525 1.887 2.202 2.891.72 1.066 1.494 2.082 2.48 2.914.348.292.625.514.891.677-.802.09-2.14.11-3.054-.614zm1-6.44a.306.306 0 01.415-.287.302.302 0 01.2.288.306.306 0 01-.31.307.303.303 0 01-.304-.308zm3.11 1.596c-.2.081-.399.151-.59.16a1.245 1.245 0 01-.798-.254c-.274-.23-.47-.358-.552-.758a1.73 1.73 0 01.016-.588c.07-.327-.008-.537-.239-.727-.187-.156-.426-.199-.688-.199a.559.559 0 01-.254-.078c-.11-.054-.2-.19-.114-.358.028-.054.16-.186.192-.21.356-.202.767-.136 1.146.016.352.144.618.408 1.001.782.391.451.462.576.685.914.176.265.336.537.445.848.067.195-.019.354-.25.452z",fill:"#4D6BFE"})]}),c5=({height:n})=>s("svg",{fill:"var(--ac-global-text-color-900)",fillRule:"evenodd",viewBox:"0 0 24 24",width:n,height:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"xAI"}),e("path",{d:"M6.469 8.776L16.512 23h-4.464L2.005 8.776H6.47zm-.004 7.9l2.233 3.164L6.467 23H2l4.465-6.324zM22 2.582V23h-3.659V7.764L22 2.582zM22 1l-9.952 14.095-2.233-3.163L17.533 1H22z"})]}),d5=({height:n})=>s("svg",{fill:"currentColor",fillRule:"evenodd",height:n,style:{flex:"none",lineHeight:1},viewBox:"0 0 24 24",width:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"Ollama"}),e("path",{d:"M7.905 1.09c.216.085.411.225.588.41.295.306.544.744.734 1.263.191.522.315 1.1.362 1.68a5.054 5.054 0 012.049-.636l.051-.004c.87-.07 1.73.087 2.48.474.101.053.2.11.297.17.05-.569.172-1.134.36-1.644.19-.52.439-.957.733-1.264a1.67 1.67 0 01.589-.41c.257-.1.53-.118.796-.042.401.114.745.368 1.016.737.248.337.434.769.561 1.287.23.934.27 2.163.115 3.645l.053.04.026.019c.757.576 1.284 1.397 1.563 2.35.435 1.487.216 3.155-.534 4.088l-.018.021.002.003c.417.762.67 1.567.724 2.4l.002.03c.064 1.065-.2 2.137-.814 3.19l-.007.01.01.024c.472 1.157.62 2.322.438 3.486l-.006.039a.651.651 0 01-.747.536.648.648 0 01-.54-.742c.167-1.033.01-2.069-.48-3.123a.643.643 0 01.04-.617l.004-.006c.604-.924.854-1.83.8-2.72-.046-.779-.325-1.544-.8-2.273a.644.644 0 01.18-.886l.009-.006c.243-.159.467-.565.58-1.12a4.229 4.229 0 00-.095-1.974c-.205-.7-.58-1.284-1.105-1.683-.595-.454-1.383-.673-2.38-.61a.653.653 0 01-.632-.371c-.314-.665-.772-1.141-1.343-1.436a3.288 3.288 0 00-1.772-.332c-1.245.099-2.343.801-2.67 1.686a.652.652 0 01-.61.425c-1.067.002-1.893.252-2.497.703-.522.39-.878.935-1.066 1.588a4.07 4.07 0 00-.068 1.886c.112.558.331 1.02.582 1.269l.008.007c.212.207.257.53.109.785-.36.622-.629 1.549-.673 2.44-.05 1.018.186 1.902.719 2.536l.016.019a.643.643 0 01.095.69c-.576 1.236-.753 2.252-.562 3.052a.652.652 0 01-1.269.298c-.243-1.018-.078-2.184.473-3.498l.014-.035-.008-.012a4.339 4.339 0 01-.598-1.309l-.005-.019a5.764 5.764 0 01-.177-1.785c.044-.91.278-1.842.622-2.59l.012-.026-.002-.002c-.293-.418-.51-.953-.63-1.545l-.005-.024a5.352 5.352 0 01.093-2.49c.262-.915.777-1.701 1.536-2.269.06-.045.123-.09.186-.132-.159-1.493-.119-2.73.112-3.67.127-.518.314-.95.562-1.287.27-.368.614-.622 1.015-.737.266-.076.54-.059.797.042zm4.116 9.09c.936 0 1.8.313 2.446.855.63.527 1.005 1.235 1.005 1.94 0 .888-.406 1.58-1.133 2.022-.62.375-1.451.557-2.403.557-1.009 0-1.871-.259-2.493-.734-.617-.47-.963-1.13-.963-1.845 0-.707.398-1.417 1.056-1.946.668-.537 1.55-.849 2.485-.849zm0 .896a3.07 3.07 0 00-1.916.65c-.461.37-.722.835-.722 1.25 0 .428.21.829.61 1.134.455.347 1.124.548 1.943.548.799 0 1.473-.147 1.932-.426.463-.28.7-.686.7-1.257 0-.423-.246-.89-.683-1.256-.484-.405-1.14-.643-1.864-.643zm.662 1.21l.004.004c.12.151.095.37-.056.49l-.292.23v.446a.375.375 0 01-.376.373.375.375 0 01-.376-.373v-.46l-.271-.218a.347.347 0 01-.052-.49.353.353 0 01.494-.051l.215.172.22-.174a.353.353 0 01.49.051zm-5.04-1.919c.478 0 .867.39.867.871a.87.87 0 01-.868.871.87.87 0 01-.867-.87.87.87 0 01.867-.872zm8.706 0c.48 0 .868.39.868.871a.87.87 0 01-.868.871.87.87 0 01-.867-.87.87.87 0 01.867-.872zM7.44 2.3l-.003.002a.659.659 0 00-.285.238l-.005.006c-.138.189-.258.467-.348.832-.17.692-.216 1.631-.124 2.782.43-.128.899-.208 1.404-.237l.01-.001.019-.034c.046-.082.095-.161.148-.239.123-.771.022-1.692-.253-2.444-.134-.364-.297-.65-.453-.813a.628.628 0 00-.107-.09L7.44 2.3zm9.174.04l-.002.001a.628.628 0 00-.107.09c-.156.163-.32.45-.453.814-.29.794-.387 1.776-.23 2.572l.058.097.008.014h.03a5.184 5.184 0 011.466.212c.086-1.124.038-2.043-.128-2.722-.09-.365-.21-.643-.349-.832l-.004-.006a.659.659 0 00-.285-.239h-.004z"})]}),u5=({height:n})=>s("svg",{height:n,style:{flex:"none",lineHeight:1},viewBox:"0 0 24 24",width:n,xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"Bedrock"}),e("defs",{children:s("linearGradient",{id:"lobe-icons-bedrock-fill",x1:"80%",x2:"20%",y1:"20%",y2:"80%",children:[e("stop",{offset:"0%",stopColor:"#6350FB"}),e("stop",{offset:"50%",stopColor:"#3D8FFF"}),e("stop",{offset:"100%",stopColor:"#9AD8F8"})]})}),e("path",{d:"M13.05 15.513h3.08c.214 0 .389.177.389.394v1.82a1.704 1.704 0 011.296 1.661c0 .943-.755 1.708-1.685 1.708-.931 0-1.686-.765-1.686-1.708 0-.807.554-1.484 1.297-1.662v-1.425h-2.69v4.663a.395.395 0 01-.188.338l-2.69 1.641a.385.385 0 01-.405-.002l-4.926-3.086a.395.395 0 01-.185-.336V16.3L2.196 14.87A.395.395 0 012 14.555L2 14.528V9.406c0-.14.073-.27.192-.34l2.465-1.462V4.448c0-.129.062-.249.165-.322l.021-.014L9.77 1.058a.385.385 0 01.407 0l2.69 1.675a.395.395 0 01.185.336V7.6h3.856V5.683a1.704 1.704 0 01-1.296-1.662c0-.943.755-1.708 1.685-1.708.931 0 1.685.765 1.685 1.708 0 .807-.553 1.484-1.296 1.662v2.311a.391.391 0 01-.389.394h-4.245v1.806h6.624a1.69 1.69 0 011.64-1.313c.93 0 1.685.764 1.685 1.707 0 .943-.754 1.708-1.685 1.708a1.69 1.69 0 01-1.64-1.314H13.05v1.937h4.953l.915 1.18a1.66 1.66 0 01.84-.227c.931 0 1.685.764 1.685 1.707 0 .943-.754 1.708-1.685 1.708-.93 0-1.685-.765-1.685-1.708 0-.346.102-.668.276-.937l-.724-.935H13.05v1.806zM9.973 1.856L7.93 3.122V6.09h-.778V3.604L5.435 4.669v2.945l2.11 1.36L9.712 7.61V5.334h.778V7.83c0 .136-.07.263-.184.335L7.963 9.638v2.081l1.422 1.009-.446.646-1.406-.998-1.53 1.005-.423-.66 1.605-1.055v-1.99L5.038 8.29l-2.26 1.34v1.676l1.972-1.189.398.677-2.37 1.429V14.3l2.166 1.258 2.27-1.368.397.677-2.176 1.311V19.3l1.876 1.175 2.365-1.426.398.678-2.017 1.216 1.918 1.201 2.298-1.403v-5.78l-4.758 2.893-.4-.675 5.158-3.136V3.289L9.972 1.856zM16.13 18.47a.913.913 0 00-.908.92c0 .507.406.918.908.918a.913.913 0 00.907-.919.913.913 0 00-.907-.92zm3.63-3.81a.913.913 0 00-.908.92c0 .508.406.92.907.92a.913.913 0 00.908-.92.913.913 0 00-.908-.92zm1.555-4.99a.913.913 0 00-.908.92c0 .507.407.918.908.918a.913.913 0 00.907-.919.913.913 0 00-.907-.92zM17.296 3.1a.913.913 0 00-.907.92c0 .508.406.92.907.92a.913.913 0 00.908-.92.913.913 0 00-.908-.92z",fill:"url(#lobe-icons-bedrock-fill)",fillRule:"nonzero"})]}),m5={AZURE_OPENAI:l5,GOOGLE:i5,OPENAI:r5,ANTHROPIC:o5,DEEPSEEK:s5,XAI:c5,OLLAMA:d5,AWS:u5};function cp({provider:n,height:a=18}){return m5[n]({height:a})}const fl=p`
  // fixes table row sizing issues with full height cell children
  // this enables features like hovering anywhere on a cell to display controls
  height: fit-content;
  font-size: var(--ac-global-font-size-s);
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  thead {
    position: sticky;
    top: 0;
    z-index: 1;
    tr {
      th {
        padding: var(--ac-global-dimension-size-100)
          var(--ac-global-dimension-size-200);
        background-color: var(--ac-global-color-grey-100);
        position: relative;
        text-align: left;
        user-select: none;
        vertical-align: top;
        font-weight: 600;
        font-size: var(--ac-global-font-size-s);
        line-height: var(--ac-global-line-height-s);
        border-bottom: 1px solid var(--ac-global-border-color-default);
        &:not(:last-of-type) {
          border-right: 1px solid var(--ac-global-border-color-default);
        }
        .sort {
          /* The sortable part of the header */
          cursor: pointer;
          display: flex;
          flex-direction: row;
          align-items: center;

          gap: var(--ac-global-dimension-size-50);
        }
        .sort-icon {
          margin-left: var(--ac-global-dimension-size-50);
          font-size: var(--ac-global-font-size-xs);
          vertical-align: middle;
          display: inline-block;
        }
        &:hover .resizer {
          background: var(--ac-global-color-grey-300);
        }
        div.resizer {
          display: inline-block;

          width: 2px;
          height: 100%;
          position: absolute;
          right: 0;
          top: 0;
          cursor: grab;
          z-index: 4;
          touch-action: none;
          &.isResizing,
          &:hover {
            background: var(--ac-global-color-primary);
          }
        }
        // Style action menu buttons in the header
        .ac-button[data-size="compact"][data-childless="true"] {
          padding: 0;
          border: none;
          background-color: transparent;
        }
      }
    }
  }
  tbody:not(.is-empty) {
    tr {
      // when paired with table.height:fit-content, allows table cells and their children to fill entire row height
      height: 100%;
      &:not(:last-of-type) {
        & > td {
          border-bottom: 1px solid var(--ac-global-color-grey-200);
        }
      }
      & > td {
        padding: var(--ac-global-dimension-size-100)
          var(--ac-global-dimension-size-200);
      }
      &[data-selected="true"] {
        background-color: var(--ac-global-color-primary-100);
      }
    }
  }
`,dp=p`
  tbody:not(.is-empty) {
    tr {
      & > td {
        border-bottom: 1px solid var(--ac-global-color-grey-100);
      }
      & > td:not(:last-of-type) {
        border-right: 1px solid var(--ac-global-color-grey-100);
      }
    }
  }
`,g5=p`
  tbody:not(.is-empty) {
    tr {
      &:hover {
        background-color: var(--ac-hover-background);
      }
    }
  }
`,up=p(fl,g5,p`
    tbody:not(.is-empty) {
      tr {
        cursor: pointer;
      }
    }
  `),p5=p`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: var(--ac-global-dimension-size-100);
  gap: var(--ac-global-dimension-size-50);
  border-top: 1px solid var(--ac-global-color-grey-300);
`;function mp(n){const a=n.getIsPinned(),t=a==="left"&&n.getIsLastColumn("left"),l=a==="right"&&n.getIsFirstColumn("right");return{boxShadow:t?"-8px 0 8px -8px var(--ac-global-color-grey-200) inset":l?"8px 0 8px -8px var(--ac-global-color-grey-200) inset":void 0,left:a==="left"?`${n.getStart("left")}px`:void 0,right:a==="right"?`${n.getAfter("right")}px`:void 0,opacity:a?.95:1,position:a?"sticky":"relative",width:n.getSize(),zIndex:a?1:0,backgroundColor:a?"var(--ac-global-color-grey-100)":void 0}}const si=.05,h5=({word:n,theme:a})=>{const t=n.charCodeAt(0);let l=ji(t%26/26);const i=a==="light"?3:5,r=a==="light"?"#fdfdfd":"#0E0E0E";let o=Dl(l,r);for(;o<i;)l=a==="light"?Bs(si,l):Zi(si,l),o=Dl(l,r);return l},bl=n=>{const{theme:a}=de();return g.useMemo(()=>h5({word:n,theme:a}),[n,a])};function ba({annotationName:n,...a}){const t=bl(n);return e(U,{color:t,...a})}const _t=1e3,Vt=60*_t,Pt=60*Vt,f5=24*Pt,gp=30*f5,pp=3600*24*365,hp=3600*24*30,fp=3600*24*7,bp=3600*24,yp=3600;function to(n){return Math.abs(n)<1e6?be(",")(n):be("0.2s")(n).replace("G","B").replace("k","K")}function b5(n){return be("0.2s")(n).replace("G","B").replace("k","K")}function bn(n){const a=Math.abs(n);if(a===0)return"0.00";if(a<.01)return be(".2e")(n);if(a<1){const t=x5(n,2);return be("0.2f")(t)}else if(a<1e3)return be("0.2f")(n);return be("0.2s")(n)}function y5(n){const a=Math.abs(n);return a===0?"0.00":a<.01?be(".2e")(n):a<1e3?be("0.2f")(n):be("0.2s")(n).replace("G","B").replace("k","K")}function v5(n){return be(".2f")(n)+"%"}function la(n){return Number.isInteger(n)?to(n):bn(n)}function C5(n){return n===0?"$0":n<.01?"<$0.01":n<100?`$${be("0.2f")(n)}`:n<1e4?`$${be(",")(n)}`:`$${be("0.2s")(n).replace("G","B").replace("k","K")}`}function k5(n){const a=Math.floor(n/Pt),t=Math.floor(n%Pt/Vt),l=Math.floor(n%Vt/_t),i=Math.floor(n%_t);if(a>0)return`${a}h${t?` ${t}m`:""}${l?` ${l}s`:""}`;if(t>0)return`${t}m${l?` ${l}s`:""}`;if(l>0){const r=Math.floor(i/100);return`${l}${r>0?`.${r.toFixed(0)}`:""}s`}return`${i.toFixed(0)}ms`}function ln(n){return a=>typeof a!="number"?"--":n(a)}const L5=ln(to),vp=ln(b5),Cp=ln(y5),Ja=ln(bn),ci=ln(la),S5=ln(v5),lo=ln(C5),w5=ln(k5);function x5(n,a){const t=n.toString().split(".");return t.length<2?n:+(t[0]+"."+t[1].substring(0,a))}const di=p`
  display: flex;
  align-items: center;
  .ac-text {
    display: inline-block;
    max-width: 9rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`,T5=({annotation:n,displayPreference:a})=>{switch(a){case"label":return n.label||typeof n.score=="number"&&bn(n.score)||"n/a";case"score":return typeof n.score=="number"&&bn(n.score)||n.label||"n/a";case"none":return"";default:N()}};function io({annotation:n,displayPreference:a,size:t}){const l=T5({annotation:n,displayPreference:a});return s(S,{direction:"row",gap:"size-100",alignItems:"center",className:"annotation-name-and-value",children:[e(ba,{annotationName:n.name}),e("div",{css:p(di,{minWidth:"5rem"}),children:e(C,{weight:"heavy",size:t,color:"inherit",children:n.name})}),l&&e("div",{css:p(di,p`
              margin-left: var(--ac-global-dimension-100);
            `),children:e(C,{fontFamily:"mono",children:l})})]})}const I5=p`
  border-radius: var(--ac-global-dimension-size-50);
  border: 1px solid var(--ac-global-color-grey-400);
  padding: var(--ac-global-dimension-size-50)
    var(--ac-global-dimension-size-100);
  transition: background-color 0.2s;
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-size-50);
  &[data-clickable="true"] {
    cursor: pointer;
    &:hover {
      background-color: var(--ac-global-color-grey-300);
    }
  }
  .ac-icon-wrap {
    font-size: 12px;
  }
`;function ro({annotation:n,onClick:a,annotationDisplayPreference:t="score",className:l,children:i,clickable:r}){const o=r??typeof a=="function";return s("div",{role:o?"button":void 0,"data-clickable":o,className:l,css:p(I5),"aria-label":o?"Click to view the annotation trace":`Annotation: ${n.name}`,onClick:c=>{a&&(c.stopPropagation(),c.preventDefault(),a())},children:[e(io,{annotation:n,displayPreference:t}),i]})}const z5=p`
  margin: 0;
  white-space: pre-wrap;
  word-wrap: break-word;
`;function ui(n,a){return n.length>a?`${n.slice(0,a)}...`:n}function oo({json:n,maxLength:a,space:t=0,disableTitle:l=!1,collapseSingleKey:i=!0}){const r=typeof a=="number",o=g.useMemo(()=>JSON.stringify(n,null,t),[n,t]),c=g.useMemo(()=>JSON.stringify(n,null,2),[n]),d=l?void 0:c;if(!Le(n))return console.warn("JSONText component received a non-object value",n),e("span",{title:d,className:"font-mono",children:String(n)});const u=n;if(Object.keys(u).length===0)return e("span",{title:d,children:"--"});if(Object.keys(u).length===1&&i){const f=Object.keys(u)[0],y=u[f];if(typeof y=="string"){const v=r?ui(y,a):y;return e("span",{title:d,className:"font-mono",children:v})}}const m=r?ui(o,a):o;return e(r?"span":"pre",{title:d,css:r?void 0:z5,children:m})}const A5=p`
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
`,ye=({children:n,maxWidth:a,title:t})=>e("div",{css:A5,style:{maxWidth:a},title:t,children:n});function so({annotation:n}){return e(S,{direction:"column",gap:"size-100",height:"100%",justifyContent:"space-between",children:s(w,{children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e(ba,{annotationName:n.name}),e(C,{weight:"heavy",color:"inherit",size:"L",elementType:"h3",children:n.name})]}),s(w,{paddingTop:"size-100",minWidth:"150px",children:[s(S,{direction:"row",justifyContent:"space-between",children:[e(C,{weight:"heavy",color:"inherit",children:"label"}),e(C,{color:"inherit",title:n.label??void 0,children:e(ye,{maxWidth:"200px",children:n.label||"--"})})]}),s(S,{direction:"row",justifyContent:"space-between",children:[e(C,{weight:"heavy",color:"inherit",children:"score"}),e(C,{color:"inherit",fontFamily:"mono",children:Ja(n.score)})]}),n.annotatorKind?s(S,{direction:"row",justifyContent:"space-between",children:[e(C,{weight:"heavy",color:"inherit",children:"annotator kind"}),e(C,{color:"inherit",children:n.annotatorKind})]}):null]}),n.explanation?e(w,{paddingTop:"size-50",children:s(S,{direction:"column",children:[e(C,{weight:"heavy",color:"inherit",children:"explanation"}),e(w,{maxHeight:"300px",overflow:"auto",children:e(C,{color:"inherit",children:n.explanation})})]})}):null,n.metadata&&Object.keys(n.metadata).length>0?e(w,{paddingTop:"size-50",children:s(S,{direction:"column",children:[e(C,{weight:"heavy",color:"inherit",children:"metadata"}),e(w,{maxHeight:"300px",overflow:"auto",children:e(oo,{json:n.metadata,space:2,disableTitle:!0})})]})}):null,n.createdAt?s(S,{direction:"row",justifyContent:"space-between",wrap:"wrap",gap:"size-100",children:[e(C,{weight:"heavy",color:"inherit",children:"created at"}),e(C,{color:"inherit",children:new Date(n.createdAt).toLocaleString().split(",").join(`,
`)})]}):null]})})}function kp({annotation:n,children:a}){return s(j,{delay:500,children:[e(eo,{children:a}),e(ge,{offset:3,children:e(so,{annotation:n})})]})}function Lp(n){const a=g.useRef(null),[t,l]=g.useState(!1),{isSelected:i,onChange:r}=n;return e("div",{onClick:o=>{o.stopPropagation(),r==null||r(!i)},onMouseEnter:()=>l(!0),onMouseLeave:()=>l(!1),css:p`
        cursor: pointer;
        padding: var(--ac-global-dimension-size-25);
      `,children:e(fn,{inputRef:a,isHovered:t,...n})})}function M5(n){const{children:a}=n;return e("tbody",{className:"is-empty",children:e("tr",{children:e("td",{colSpan:100,css:p`
            text-align: center;
            padding: var(--ac-global-dimension-size-300)
              var(--ac-global-dimension-size-300) !important;
          `,children:a})})})}function F5(n){const{message:a="No Data"}=n;return e(M5,{children:e(C,{children:a})})}const D5=n=>typeof n=="object"&&n!==null&&typeof n.message=="string",E5=/["]message["]:\s*["]([^""]+)["]/g,yn=n=>{if(!D5(n))return null;const a=n.message;if(typeof a!="string")return null;const t=[...a.matchAll(E5)].map(l=>l[1]);return t.length>0?t:null},K5=n=>{const a=n;return typeof a=="object"&&a!==null&&typeof a.source=="object"&&a.source!==null&&Array.isArray(a.source.errors)&&a.source.errors.every(t=>typeof t=="object"&&t!==null&&typeof t.message=="string")},_5=n=>Array.isArray(n)&&n.every(a=>typeof a=="object"&&a!==null&&typeof a.message=="string"),Sp=n=>K5(n)?n.source.errors.map(a=>a.message):_5(n)?n.map(a=>a.message):null;function wp(n){const{isCommitting:a,onSubmit:t,defaultName:l}=n,{control:i,handleSubmit:r,formState:{isDirty:o,isValid:c}}=Oe({defaultValues:{name:l??"New Key",description:"",expiresAt:null}});return e(me,{children:({close:d})=>s(Ve,{children:[s(Pe,{children:[e(Re,{children:"Create an API Key"}),e(hn,{children:e(Ue,{slot:"close"})})]}),s(Hs,{onSubmit:r(u=>t(u,d)),children:[s(w,{padding:"size-200",children:[e(Z,{name:"name",control:i,rules:{required:"System key name is required"},render:({field:{onChange:u,onBlur:m,value:h},fieldState:{invalid:b,error:f}})=>s(ee,{isInvalid:b,onChange:u,onBlur:m,value:h.toString(),size:"S",children:[e(P,{children:"Name"}),e(W,{}),f!=null&&f.message?e(ae,{children:f.message}):e(C,{slot:"description",children:"A name to identify the key"})]})}),e(Z,{name:"description",control:i,render:({field:{onChange:u,onBlur:m,value:h},fieldState:{invalid:b,error:f}})=>s(ee,{isInvalid:b,onChange:u,onBlur:m,value:h==null?void 0:h.toString(),size:"S",children:[e(P,{children:"Description"}),e(oa,{}),f!=null&&f.message?e(ae,{children:f.message}):e(C,{slot:"description",children:"A description of the system key"})]})}),e(Z,{name:"expiresAt",control:i,rules:{validate:u=>u&&u.toDate(Ni())<new Date?"Date must be in the future":!0},render:({field:{name:u,onChange:m,onBlur:h,value:b},fieldState:{invalid:f,error:y}})=>s(Kt,{isInvalid:f,onChange:m,onBlur:h,value:b,name:u,granularity:"minute",css:p`
                      .react-aria-DateInput {
                        width: 100%;
                      }
                    `,children:[e(P,{children:"Expires At"}),e(wt,{children:v=>e(xt,{segment:v})}),y!=null&&y.message?e(ae,{children:y.message}):e(C,{slot:"description",children:"The date at which the key will expire. Optional"})]})})]}),e(w,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderColor:"dark",borderTopWidth:"thin",children:e(S,{direction:"row",gap:"size-100",justifyContent:"end",children:e(D,{variant:o?"primary":"default",type:"submit",size:"S",isDisabled:!c||a,children:a?"Creating...":"Create Key"})})})]})]})})}function V5(n){var m;const{theme:a}=de(),{jsonSchema:t,optionalLint:l,basicSetup:i,...r}=n,o=a==="light"?sa:ca,c=(m=n.value)==null?void 0:m.length,d=!l||c&&c>0,u=g.useMemo(()=>{const h=[Xi(),Zt.lineWrapping,Yi.of([...Ji.filter(b=>b.key!=="Mod-Enter")])];return d&&h.push(It(er())),t&&h.push(It(Ec(),{needsRefresh:Nc}),Kc.data.of({autocomplete:_c()}),Vc(Pc()),Rc(t)),h},[t,d]);return e(da,{value:n.value,extensions:u,editable:!0,theme:o,basicSetup:{...i,defaultKeymap:!1},...r})}function yl(n){const{basicSetup:a,...t}=n,{theme:l}=de(),i=l==="light"?sa:ca,r=g.useMemo(()=>{const o={lineNumbers:!0,foldGutter:!0,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1};return a?{...o,...a}:o},[a]);return e(da,{value:n.value,extensions:[Xi(),Zt.lineWrapping,It(er())],editable:!1,theme:i,...t,basicSetup:r})}function P5(n){const{theme:a}=de(),t=a==="light"?sa:ca,{basicSetup:l={}}=n,i=g.useMemo(()=>({lineNumbers:!1,foldGutter:!0,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1,...l}),[l]);return e(da,{value:n.value,extensions:[Oc()],editable:!1,theme:t,...n,basicSetup:i})}const co=p`
  position: relative;
  --code-block-min-height: 40px;
  min-height: var(--code-block-min-height);
  display: flex;
  flex-direction: row;
  align-items: center;
  .cm-theme,
  .cm-editor {
    width: 100%;
    min-height: var(--code-block-min-height);
  }
  .cm-editor {
    padding-top: var(--ac-global-dimension-size-100);
    padding-bottom: var(--ac-global-dimension-size-100);
  }
  .cm-gutters,
  .cm-gutters * {
    background: none;
    background-color: transparent !important;
    border-right: none;
  }
  .copy-to-clipboard-button {
    position: absolute;
    top: var(--ac-global-dimension-size-100);
    right: var(--ac-global-dimension-size-100);
    z-index: 1;
  }
`;function De(n){const{value:a}=n;return s("div",{className:"python-code-block",css:co,children:[e(pa,{text:a}),e(P5,{value:a})]})}function ke({children:n,...a}){return e(w,{borderColor:"light",borderWidth:"thin",borderRadius:"small",...a,children:n})}function R5(n){const{theme:a}=de(),t=a==="light"?sa:ca,{basicSetup:l}=n,i=g.useMemo(()=>({lineNumbers:!1,foldGutter:!0,bracketMatching:!0,syntaxHighlighting:!0,highlightActiveLine:!1,highlightActiveLineGutter:!1,...l}),[l]);return e(da,{value:n.value,extensions:[$c({typescript:!0})],editable:!1,theme:t,...n,basicSetup:i})}const N5=p`
  &.is-hovered {
    border: 1px solid var(--ac-global-input-field-border-color-active);
  }
  &.is-focused {
    border: 1px solid var(--ac-global-input-field-border-color-active);
  }
  &.is-invalid {
    border: 1px solid var(--ac-global-color-danger);
  }
  border-radius: var(--ac-global-rounding-small);
  border: 1px solid var(--ac-global-input-field-border-color);
  width: 100%;
  .cm-content,
  .cm-editor {
    border-radius: var(--ac-global-rounding-small);
  }
  box-sizing: border-box;
  .cm-focused {
    outline: none;
  }
  transition: all 0.2s ease-in-out;
`;function O5({children:n,label:a,errorMessage:t,description:l}){const[i,r]=g.useState(!1),[o,c]=g.useState(!1);return s("div",{css:Te,children:[e(P,{children:a}),e("div",{className:$("json-editor-wrap",{"is-hovered":o,"is-focused":i,"is-invalid":!!t}),onFocus:()=>r(!0),onBlur:()=>r(!1),onMouseEnter:()=>c(!0),onMouseLeave:()=>c(!1),css:N5,children:n}),t?e(C,{slot:"errorMessage",color:"danger",children:t}):null,l&&!t?e(C,{slot:"description",children:l}):null]})}const $5=["Python","TypeScript"];function B5(n){return typeof n=="string"&&$5.includes(n)}function xp({language:n,onChange:a,size:t}){return s(fa,{size:t,selectedKeys:[n],"aria-label":"Code Language",onSelectionChange:l=>{if(l.size===0)return;const i=l.keys().next().value;if(B5(i))a(i);else throw new Error(`Unknown language: ${i}`)},children:[e(Ae,{"aria-label":"Python",id:"Python",children:"Python"}),e(Ae,{"aria-label":"TypeScript",id:"TypeScript",children:"TypeScript"})]})}function Tp(n){const{jwt:a}=n;return e(me,{children:s(Ve,{children:[s(Pe,{children:[e(Re,{children:"New API Key Created"}),e(hn,{children:e(Ue,{slot:"close"})})]}),e(On,{variant:"success",banner:!0,children:"You have successfully created a new API key. The API key will only be displayed once below. Please copy and save it in a secure location."}),s("div",{css:p`
            .ac-field {
              width: 100%;
            }
          `,children:[e(w,{padding:"size-200",children:s(S,{direction:"row",gap:"size-100",alignItems:"end",children:[s(ee,{isReadOnly:!0,value:a,children:[e(P,{children:"API Key"}),e(W,{})]}),e(pa,{text:a,size:"M"})]})}),s(w,{padding:"size-200",borderTopColor:"light",borderTopWidth:"thin",children:[e(Q,{level:2,weight:"heavy",children:"How to Use the API Key"}),e(w,{paddingBottom:"size-100",paddingTop:"size-100",children:e(C,{children:"When interacting with Phoenix clients and OTEL SDKs, set the environment variable"})}),e(ke,{children:e(De,{value:`PHOENIX_API_KEY=${a}`})}),e(w,{paddingBottom:"size-100",paddingTop:"size-100",children:e(C,{children:"When using OpenTelemetry SDKs pass the API key in the headers"})}),e(ke,{children:e(De,{value:`OTEL_EXPORTER_OTLP_HEADERS='Authorization=Bearer ${a}'`})}),e(w,{paddingBottom:"size-100",paddingTop:"size-100",children:s(C,{children:["When using the Phoenix REST and GraphQL APIs, pass the API key as a"," ",e(fe,{href:"https://swagger.io/docs/specification/authentication/bearer-authentication/",children:"bearer token"}),"."]})}),e(ke,{children:e(De,{value:`Authorization: Bearer ${a}`})})]}),e(w,{padding:"size-200",borderTopColor:"light",borderTopWidth:"thin",children:e(S,{direction:"row",justifyContent:"end",children:e(D,{variant:"primary","aria-label":"dismiss",slot:"close",children:"Close"})})})]})]})})}function Ip({handleDelete:n}){return s(we,{children:[e(D,{variant:"danger",size:"S",leadingVisual:e(x,{svg:e(gl,{})}),"aria-label":"Delete System Key"}),e(pn,{isDismissable:!0,children:e(gn,{children:e(me,{children:({close:a})=>s(Ve,{children:[s(Pe,{children:[e(Re,{children:"Delete API Key"}),e(hn,{children:e(Ue,{slot:"close"})})]}),e(w,{padding:"size-200",children:e(C,{color:"danger",children:"Are you sure you want to delete this key? This cannot be undone and will disable all uses of this key."})}),e(w,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:s(S,{direction:"row",justifyContent:"end",gap:"size-100",children:[e(D,{slot:"close",size:"S",children:"Cancel"}),e(D,{variant:"danger",onPress:()=>{a(),n()},size:"S",children:"Delete Key"})]})})]})})})})]})}function H5(n){const{fallback:a=null,children:t}=n,{viewer:l}=kn();return l?t:e(B,{children:a})}function uo(n){const{fallback:a=null,children:t}=n,{viewer:l}=kn();return!l||l.role.name!=="ADMIN"?e(B,{children:a}):t}function zp(n){const{fallback:a=null,children:t}=n;return dd()?t:e(B,{children:a})}function Ap(n){const{fallback:a=null,children:t}=n;return ud()?t:e(B,{children:a})}function vl({children:n}){return e("div",{style:{display:"contents"},onClick:a=>a.stopPropagation(),onKeyDown:a=>a.stopPropagation(),onMouseDown:a=>a.stopPropagation(),onPointerDown:a=>a.stopPropagation(),children:n})}function mo({columns:n,data:a}){"use no memo";const t=js({columns:n,data:a,getCoreRowModel:Gs(),getPaginationRowModel:Us(),getSortedRowModel:Zs()}),l=t.getRowModel().rows,r=l.length>0?e("tbody",{children:l.map(o=>e("tr",{children:o.getVisibleCells().map(c=>e("td",{children:El(c.column.columnDef.cell,c.getContext())},c.id))},o.id))}):e(F5,{});return s(B,{children:[s("table",{css:fl,children:[e("thead",{children:t.getHeaderGroups().map(o=>e("tr",{children:o.headers.map(c=>e("th",{colSpan:c.colSpan,children:c.isPlaceholder?null:e("div",{children:El(c.column.columnDef.header,c.getContext())})},c.id))},o.id))}),r]}),s("div",{css:p5,children:[e(D,{variant:"default",size:"S",onPress:t.previousPage,isDisabled:!t.getCanPreviousPage(),"aria-label":"Previous Page",leadingVisual:e(x,{svg:e(X0,{})})}),e(D,{size:"S",onPress:t.nextPage,isDisabled:!t.getCanNextPage(),"aria-label":"Next Page",leadingVisual:e(x,{svg:e(_r,{})})})]})]})}const j5=p`
  float: right;
`;function Xn({getValue:n}){const a=n();if(!Ut(a))throw new Error("IntCell only supports number or null values.");return e("span",{title:a!=null?String(a):"",className:"font-mono",css:j5,children:Ja(a)})}const Z5=p`
  float: right;
`;function U5({getValue:n}){const a=n();if(!Ut(a))throw new Error("IntCell only supports number or null values.");return e("span",{title:a!=null?String(a):"",className:"font-mono",css:Z5,children:L5(a)})}function G5({getValue:n}){const a=n();if(!Ut(a))throw new Error("IntCell only supports number or null values.");return e("span",{title:a!=null?String(a):"",children:S5(a)})}const mi=100;function W5(n){return n.length>mi?`${n.slice(0,mi)}...`:n}function Mp({getValue:n}){const a=n(),t=a!=null&&typeof a=="string"?W5(a):"--";return e("span",{children:t})}function Fp({getValue:n}){const a=n(),t=a!=null&&typeof a=="string"?a:"--";return e("pre",{style:{whiteSpace:"pre-wrap"},children:t})}const Q5=100;function Dp({getValue:n}){const a=n();return e(oo,{json:a,maxLength:Q5})}p`
  position: relative;
  height: 100%;
  min-height: 100%;
  .controls {
    transition: opacity 0.2s ease-in-out;
    opacity: 0;
    display: none;
    z-index: 1;
  }
  &:hover .controls {
    opacity: 1;
    display: flex;
    // make them stand out
    button {
      border-color: var(--ac-global-color-primary);
    }
  }
`;p`
  position: absolute;
  top: calc(-1 * var(--ac-global-dimension-static-size-200));
  right: var(--ac-global-dimension-static-size-200);
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-100);
`;const q5=p`
  border-radius: 16px;
  padding: var(--ac-global-dimension-size-50)
    var(--ac-global-dimension-size-200) !important;
`,X5=({onLoadMore:n,isLoadingNext:a,buttonProps:t})=>e(D,{onPress:()=>{n()},size:"S",css:q5,isDisabled:a,leadingVisual:a?e(x,{svg:e(Br,{})}):void 0,...t,children:a?"Loading...":"Load More"}),Y5=p`
  position: relative;
`,J5=p`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
`;function Ep({onLoadMore:n,isLoadingNext:a}){return e("tr",{css:Y5,children:e("td",{colSpan:100,css:J5,children:e(X5,{onLoadMore:n,isLoadingNext:a})})})}function Kp({children:n,extra:a}){return s("div",{css:e4,children:[e("div",{css:n4,children:n}),e("div",{css:a4,children:a})]})}const e4=p`
  padding: 0 var(--ac-global-dimension-static-size-100) 0
    var(--ac-global-dimension-static-size-200);
  border-bottom: var(--ac-global-border-size-thin) solid
    var(--ac-global-color-grey-100);
  background-color: var(--ac-global-color-grey-50);
  min-height: 39px;
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-100);
  align-items: center;
  justify-content: space-between;
  min-width: 0;
  flex: none;
`,n4=p`
  height: 100%;
  min-width: 0;
  flex: 1 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: flex;
  align-items: center;
`,a4=p`
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-50);
  align-items: center;
  flex: none;
`;function _p({getValue:n}){const{fullTimeFormatter:a}=Bn(),t=n();if(!Jc(t))throw new Error("TimestampCell only supports string, null, or undefined values.");const l=t!=null?a(new Date(t)):"--";return e("time",{title:t!=null?String(t):"",children:l})}function Vp(n){return e("div",{css:p`
        background-color: var(--ac-global-color-grey-200);
        border: 1px solid var(--ac-global-color-grey-300);
        padding: var(--ac-global-dimension-static-size-100);
        border-radius: var(--ac-global-rounding-medium);
        display: flex;
        flex-direction: column;
        gap: var(--ac-global-dimension-static-size-50);
        min-width: 200px;
        box-shadow: 0 8px 8px rgba(0, 0, 0, 0.1);
      `,children:n.children})}function Pp(n){return s("div",{css:p`
        display: flex;
        flex-direction: row;
        justify-content: space-between;
      `,children:[s("div",{css:p`
          display: flex;
          flex-direction: row;
          gap: var(--ac-global-dimension-static-size-100);
          align-items: center;
        `,children:[e(l4,{color:n.color,shape:n.shape??"line"}),e(C,{title:n.name,children:e(ye,{maxWidth:"120px",children:n.name})})]}),e(C,{children:n.value})]})}function Rp(){return e("div",{css:p`
        height: 1px;
        background-color: var(--ac-global-color-grey-300);
        width: 100%;
      `})}const t4=n=>{if(n==="line")return p`
      width: 8px;
      height: 2px;
    `;if(n==="circle")return p`
      width: 8px;
      height: 8px;
      border-radius: 50%;
    `;if(n==="square")return p`
      width: 8px;
      height: 8px;
    `};function l4({color:n,shape:a="line"}){return e("div",{css:p(t4(a),p`
          background-color: ${n};
          flex: none;
        `)})}const Np={dataKey:"timestamp",stroke:"var(--ac-global-colo-grey-400)",style:{fill:"var(--ac-global-text-color-700)"},scale:"time",type:"number",domain:["auto","auto"],padding:"gap"},Op={stroke:"var(--ac-global-color-grey-900)"},$p={value:"▼",position:"top",style:{fill:"#fabe32",fontSize:"var(--ac-global-font-size-xs)"}},Bp={cursor:{fill:"var(--ac-global-color-grey-300)"}},Hp={strokeDasharray:"4 4",stroke:"var(--chart-cartesian-grid-stroke-color)"},jp={stroke:"var(--chart-axis-stroke-color)",style:{fill:"var(--chart-axis-text-color)"}},Zp={stroke:"var(--chart-axis-stroke-color)",style:{fill:"var(--chart-axis-text-color)"}},Up={align:"right",formatter:n=>e("span",{style:{color:"var(--chart-legend-text-color)"},children:n})},ia=60,ra=ia*24,bt=2*ra;function Gp(n){const{start:a,end:t}=n,l=Math.floor((t.valueOf()-a.valueOf())/1e3/60/60);return l<=1?{evaluationWindowMinutes:1,samplingIntervalMinutes:1}:l<=24?{evaluationWindowMinutes:ia,samplingIntervalMinutes:ia}:{evaluationWindowMinutes:ra,samplingIntervalMinutes:ra}}function Wp(n){const{start:a,end:t}=n,l=Math.floor((t.valueOf()-a.valueOf())/1e3/60/60);return l<=1?{evaluationWindowMinutes:bt,samplingIntervalMinutes:1}:l<=24?{evaluationWindowMinutes:bt,samplingIntervalMinutes:ia}:{evaluationWindowMinutes:bt,samplingIntervalMinutes:ra}}function i4({samplingIntervalMinutes:n,locale:a=Xe(),timeZone:t}){return n<ia?Ee(a,{hour:"2-digit",minute:"2-digit",hour12:!0,timeZone:t}):n<ra?Ee(a,{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:!0,timeZone:t}):Ee(a,{month:"numeric",day:"numeric",timeZone:t})}function Qp({samplingIntervalMinutes:n,locale:a}){const t=Me(i=>i.displayTimezone);return g.useMemo(()=>i4({samplingIntervalMinutes:n,locale:a,timeZone:t}),[n,a,t])}function qp({scale:n}){const a=Me(t=>t.displayTimezone);return g.useMemo(()=>{const t=Xe();switch(n){case"YEAR":return Ee(t,{year:"numeric",timeZone:a});case"MONTH":return Ee(t,{month:"short",year:"numeric",timeZone:a});case"WEEK":case"DAY":return Ee(t,{month:"numeric",day:"numeric",timeZone:a});case"HOUR":return Ee(t,{hour:"2-digit",minute:"2-digit",hour12:!1,timeZone:a});case"MINUTE":return Ee(t,{hour:"2-digit",minute:"2-digit",hour12:!1,timeZone:a});default:N()}},[n,a])}const z=n=>`var(${n})`,r4=Object.freeze({blue100:z("--ac-global-color-blue-200"),blue200:z("--ac-global-color-blue-300"),blue300:z("--ac-global-color-blue-400"),blue400:z("--ac-global-color-blue-500"),blue500:z("--ac-global-color-blue-600"),blue600:z("--ac-global-color-blue-700"),blue700:z("--ac-global-color-blue-800"),blue800:z("--ac-global-color-blue-900"),blue900:z("--ac-global-color-blue-1000"),orange100:z("--ac-global-color-orange-500"),orange200:z("--ac-global-color-orange-600"),orange300:z("--ac-global-color-orange-700"),orange400:z("--ac-global-color-orange-800"),orange500:z("--ac-global-color-orange-900"),purple100:z("--ac-global-color-purple-100"),purple200:z("--ac-global-color-purple-200"),purple300:z("--ac-global-color-purple-300"),purple400:z("--ac-global-color-purple-400"),purple500:z("--ac-global-color-purple-500"),magenta100:z("--ac-global-color-magenta-200"),magenta200:z("--ac-global-color-magenta-300"),magenta300:z("--ac-global-color-magenta-400"),magenta400:z("--ac-global-color-magenta-500"),magenta500:z("--ac-global-color-magenta-600"),red100:z("--ac-global-color-red-200"),red200:z("--ac-global-color-red-300"),red300:z("--ac-global-color-red-400"),red400:z("--ac-global-color-red-500"),red500:z("--ac-global-color-red-600"),grey100:z("--ac-global-color-grey-100"),grey200:z("--ac-global-color-grey-200"),grey300:z("--ac-global-color-grey-300"),grey400:z("--ac-global-color-grey-400"),grey500:z("--ac-global-color-grey-500"),grey600:z("--ac-global-color-grey-600"),grey700:z("--ac-global-color-grey-700"),default:z("--ac-global-text-color-900"),primary:z("--px-primary-color"),reference:z("--px-reference-color")}),o4=Object.freeze({blue100:z("--ac-global-color-blue-200"),blue200:z("--ac-global-color-blue-300"),blue300:z("--ac-global-color-blue-400"),blue400:z("--ac-global-color-blue-500"),blue500:z("--ac-global-color-blue-600"),blue600:z("--ac-global-color-blue-700"),blue700:z("--ac-global-color-blue-800"),blue800:z("--ac-global-color-blue-900"),blue900:z("--ac-global-color-blue-1000"),orange100:z("--ac-global-color-orange-500"),orange200:z("--ac-global-color-orange-600"),orange300:z("--ac-global-color-orange-700"),orange400:z("--ac-global-color-orange-800"),orange500:z("--ac-global-color-orange-900"),purple100:z("--ac-global-color-purple-100"),purple200:z("--ac-global-color-purple-200"),purple300:z("--ac-global-color-purple-300"),purple400:z("--ac-global-color-purple-400"),purple500:z("--ac-global-color-purple-500"),magenta100:z("--ac-global-color-magenta-200"),magenta200:z("--ac-global-color-magenta-300"),magenta300:z("--ac-global-color-magenta-400"),magenta400:z("--ac-global-color-magenta-500"),magenta500:z("--ac-global-color-magenta-600"),red100:z("--ac-global-color-red-200"),red200:z("--ac-global-color-red-300"),red300:z("--ac-global-color-red-400"),red400:z("--ac-global-color-red-500"),red500:z("--ac-global-color-red-600"),grey100:z("--ac-global-color-grey-100"),grey200:z("--ac-global-color-grey-200"),grey300:z("--ac-global-color-grey-300"),grey400:z("--ac-global-color-grey-400"),grey500:z("--ac-global-color-grey-500"),grey600:z("--ac-global-color-grey-600"),grey700:z("--ac-global-color-grey-700"),default:z("--ac-global-text-color-900"),primary:z("--px-primary-color"),reference:z("--px-reference-color")}),s4=()=>{const{theme:n}=de();return g.useMemo(()=>n==="dark"?r4:o4,[n])},c4=(n,a)=>{const t=[["blue",5],["orange",5],["purple",5],["pink",5],["gray",5]],l=t.length,i=n%l,r=Math.floor(n/l),[o,c]=t[i],d=500-100*(r%c),u=`${o}${d}`;return a[u]||a.default},d4={danger:"var(--ac-global-color-red-700)",success:"var(--ac-global-color-celery-700)",warning:"var(--ac-global-color-orange-700)",info:"var(--ac-global-color-blue-700)"},u4={danger:"var(--ac-global-color-red-700)",success:"var(--ac-global-color-celery-700)",warning:"var(--ac-global-color-orange-700)",info:"var(--ac-global-color-blue-700)"},Xp=()=>{const{theme:n}=de();return g.useMemo(()=>n==="dark"?u4:d4,[n])},m4={category1:"var(--ac-global-color-blue-700)",category2:"var(--ac-global-color-purple-900)",category3:"var(--ac-global-color-magenta-600)",category4:"var(--ac-global-color-indigo-600)",category5:"var(--ac-global-color-blue-900)",category6:"var(--ac-global-color-indigo-1100)",category7:"var(--ac-global-color-orange-600)",category8:"var(--ac-global-color-celery-400)",category9:"var(--ac-global-color-seafoam-600)",category10:"var(--ac-global-color-green-1000)",category11:"var(--ac-global-color-yellow-400)",category12:"var(--ac-global-color-red-1100)"},g4={category1:"var(--ac-global-color-blue-700)",category2:"var(--ac-global-color-purple-800)",category3:"var(--ac-global-color-magenta-800)",category4:"var(--ac-global-color-indigo-600)",category5:"var(--ac-global-color-blue-900)",category6:"var(--ac-global-color-indigo-1100)",category7:"var(--ac-global-color-orange-600)",category8:"var(--ac-global-color-celery-400)",category9:"var(--ac-global-color-seafoam-600)",category10:"var(--ac-global-color-green-1000)",category11:"var(--ac-global-color-yellow-400)",category12:"var(--ac-global-color-red-1100)"},p4=()=>{const{theme:n}=de();return g.useMemo(()=>n==="dark"?g4:m4,[n])};function Yp(n){switch(n.__typename){case"NominalBin":return n.name;case"IntervalBin":return`${la(n.range.start)} - ${la(n.range.end)}`;case"MissingValueBin":return"(empty)";case"%other":throw new Error("Unexpected bin type %other");default:N()}}function Jp({scale:n}){return g.useMemo(()=>{switch(n){case"YEAR":return 1;case"MONTH":return 1;case"WEEK":case"DAY":return 1;case"HOUR":return 1;case"MINUTE":return 5;default:N()}},[n])}var ya=(n=>(n.ADMIN="ADMIN",n.MEMBER="MEMBER",n.VIEWER="VIEWER",n))(ya||{});function h4(n){return n.toLocaleLowerCase()}function f4(n){return typeof n=="string"&&n in ya}const yt=2147483647,eh=[{name:"production",description:"The version deployed to production"},{name:"staging",description:"The version deployed to staging"},{name:"development",description:"The version deployed for development"}],b4=Object.values(ya),y4=p`
  .ac-field-label {
    display: none;
  }
`;function go({onChange:n,role:a,includeLabel:t=!0,errorMessage:l,isInvalid:i=!1,size:r="M",...o}){return s(We,{css:t?void 0:y4,className:"role-select",size:r,value:a??void 0,"aria-label":"User Role",isInvalid:i,onChange:c=>{f4(c)&&n(c)},...o,children:[t&&e(P,{children:"Role"}),s(D,{children:[e(Ge,{}),e(ze,{})]}),e(le,{children:e(Ie,{children:b4.map(c=>e(oe,{id:c,children:h4(c)},c))})}),e(ae,{children:l})]})}function nh({onSubmit:n,email:a,username:t,role:l,isSubmitting:i}){const{control:r,handleSubmit:o,formState:{isDirty:c}}=Oe({defaultValues:{email:a??"",username:t??"",role:l??ya.MEMBER}}),d=u=>{const m={...u,email:u.email.trim().toLowerCase()};n(m)};return e("div",{css:p`
        .role-select {
          width: 100%;
          .ac-dropdown--picker,
          .ac-dropdown-button {
            width: 100%;
          }
        }
      `,children:s(an,{onSubmit:o(d),children:[e(w,{padding:"size-200",children:s(S,{direction:"column",gap:"size-100",children:[e(Z,{name:"email",control:r,rules:{required:"Email is required",pattern:{value:/^[^@\s]+@[^@\s]+[.][^@\s]+$/,message:"Invalid email format"}},render:({field:{name:u,onChange:m,onBlur:h,value:b},fieldState:{error:f,invalid:y}})=>s(ee,{type:"email",name:u,isRequired:!0,onChange:m,isInvalid:y,onBlur:h,value:b,children:[e(P,{children:"Email"}),e(W,{}),f?e(ae,{children:f==null?void 0:f.message}):e(C,{slot:"description",children:"The user's email address. Must be unique."})]})}),e(Z,{name:"username",control:r,rules:{required:"Username is required"},render:({field:{name:u,onChange:m,onBlur:h,value:b},fieldState:{error:f,invalid:y}})=>s(ee,{name:u,isRequired:!0,onChange:m,isInvalid:y,onBlur:h,value:b,children:[e(P,{children:"Username"}),e(W,{}),f?e(ae,{children:f==null?void 0:f.message}):e(C,{slot:"description",children:"A unique username."})]})}),e(Z,{name:"role",control:r,render:({field:{onChange:u,value:m},fieldState:{error:h}})=>e(go,{onChange:u,role:m,errorMessage:h==null?void 0:h.message})})]})}),e(w,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderColor:"dark",borderTopWidth:"thin",children:e(S,{direction:"row",gap:"size-100",justifyContent:"end",children:e(D,{variant:c?"primary":"default",type:"submit",size:"S",isDisabled:i,children:i?"Adding...":"Add User"})})})]})})}const Ca=4;function ah({onSubmit:n,email:a,username:t,password:l,role:i,isSubmitting:r}){const{control:o,handleSubmit:c,formState:{isDirty:d}}=Oe({defaultValues:{email:a??"",username:t??"",password:l??void 0,confirmPassword:void 0,role:i??ya.MEMBER}}),u=m=>{const h={...m,email:m.email.trim().toLowerCase()};n(h)};return e("div",{css:p`
        .role-select {
          width: 100%;
          .ac-dropdown--picker,
          .ac-dropdown-button {
            width: 100%;
          }
        }
      `,children:s(an,{onSubmit:c(u),children:[e(w,{padding:"size-200",children:s(S,{direction:"column",gap:"size-100",children:[e(Z,{name:"email",control:o,rules:{required:"Email is required",pattern:{value:/^[^@\s]+@[^@\s]+[.][^@\s]+$/,message:"Invalid email format"}},render:({field:{name:m,onChange:h,onBlur:b,value:f},fieldState:{invalid:y,error:v}})=>s(ee,{type:"email",name:m,isRequired:!0,onChange:h,isInvalid:y,onBlur:b,value:f,children:[e(P,{children:"Email"}),e(W,{}),v?e(ae,{children:v==null?void 0:v.message}):e(C,{slot:"description",children:"The user's email address. Must be unique."})]})}),e(Z,{name:"username",control:o,rules:{required:"Username is required"},render:({field:{name:m,onChange:h,onBlur:b,value:f},fieldState:{invalid:y,error:v}})=>s(ee,{name:m,isRequired:!0,onChange:h,isInvalid:y,onBlur:b,value:f,children:[e(P,{children:"Username"}),e(W,{}),v?e(ae,{children:v==null?void 0:v.message}):e(C,{slot:"description",children:"A unique username."})]})}),s(B,{children:[e(Z,{name:"password",control:o,rules:{required:"Password is required",minLength:{value:Ca,message:`Password must be at least ${Ca} characters`}},render:({field:{name:m,onChange:h,onBlur:b,value:f},fieldState:{invalid:y,error:v}})=>s(ee,{type:"password",isRequired:!0,name:m,isInvalid:y,onChange:h,onBlur:b,value:f||"",autoComplete:"new-password",children:[e(P,{children:"Password"}),e(W,{}),v?e(ae,{children:v==null?void 0:v.message}):e(C,{slot:"description",children:"Password must be at least 4 characters"})]})}),e(Z,{name:"confirmPassword",control:o,rules:{required:"Please confirm your password",minLength:{value:Ca,message:`Password must be at least ${Ca} characters`},validate:(m,h)=>m===h.password||"Passwords do not match"},render:({field:{name:m,onChange:h,onBlur:b,value:f},fieldState:{invalid:y,error:v}})=>s(ee,{isRequired:!0,type:"password",name:m,isInvalid:y,onChange:h,onBlur:b,value:f||"",autoComplete:"new-password",children:[e(P,{children:"Confirm Password"}),e(W,{}),v?e(ae,{children:v==null?void 0:v.message}):e(C,{slot:"description",children:"Confirm the new password"})]})})]}),e(Z,{name:"role",control:o,render:({field:{onChange:m,value:h},fieldState:{error:b,invalid:f}})=>e(go,{onChange:m,role:h,errorMessage:b==null?void 0:b.message,isInvalid:f})})]})}),e(w,{paddingStart:"size-200",paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderColor:"dark",borderTopWidth:"thin",children:e(S,{direction:"row",gap:"size-100",justifyContent:"end",children:e(D,{variant:d?"primary":"default",type:"submit",size:"S",isDisabled:r,children:r?"Adding...":"Add User"})})})]})})}function po({name:n="system",profilePictureUrl:a,size:t=75}){const l=n.length?n[0].toUpperCase():"?",i=bl(n),{theme:r}=de(),o=g.useMemo(()=>p`
      width: ${t}px;
      height: ${t}px;
      border-radius: 50%;
      font-size: ${Math.floor(t/2)}px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      flex: none;
      overflow: hidden;
      --ac-internal-avatar-color: ${i};

      &[data-theme="light"] {
        background: var(--ac-internal-avatar-color);
        border: 1px solid
          lch(from var(--ac-internal-avatar-color) calc(l * infinity) c h / 0.3);
        color: lch(
          from var(--ac-internal-avatar-color) calc((50 - l) * infinity) 0 0
        );
      }

      &[data-theme="dark"] {
        --scoped-avatar-dark-bg: lch(
          from var(--ac-internal-avatar-color) calc(l * 0.7) c h
        );
        background: linear-gradient(
          120deg,
          var(--scoped-avatar-dark-bg),
          lch(from var(--scoped-avatar-dark-bg) calc(l * 0.6) c h)
        );
        border: 1px solid
          lch(from var(--scoped-avatar-dark-bg) calc(l * infinity) c h / 0.2);
        color: lch(from var(--scoped-avatar-dark-bg) calc(l * infinity) c h);
      }

      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    `,[t,i]);return e("div",{css:o,"data-theme":r,children:a?e("img",{src:a}):l})}const ho=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"regex",variableName:"input"}],concreteType:"ValidationResult",kind:"LinkedField",name:"validateRegularExpression",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"isValid",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"errorMessage",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"RegexFieldQuery",selections:a,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"RegexFieldQuery",selections:a},params:{cacheID:"a194706b4bec602eb34e8e12671ec9b7",id:null,metadata:{},name:"RegexFieldQuery",operationKind:"query",text:`query RegexFieldQuery(
  $input: String!
) {
  validateRegularExpression(regex: $input) {
    isValid
    errorMessage
  }
}
`}}})();ho.hash="588f0ae4347a5d65fd17babc2d6be11f";const th=({value:n,onChange:a,error:t,isInvalid:l,description:i,label:r,ariaLabel:o,placeholder:c,...d})=>s(ee,{isInvalid:l,"aria-label":o||r,value:n,onChange:a,...d,children:[r&&e(P,{children:r}),e(W,{placeholder:c}),!t&&i&&e(C,{slot:"description",children:i}),t&&e(ae,{children:t}),l&&n&&e(x,{style:{color:"var(--ac-global-color-danger)"},svg:e(c2,{})}),!l&&n&&e(x,{style:{color:"var(--ac-global-color-success)"},svg:e(ul,{})})]}),v4=ho,lh=({initialValue:n}={initialValue:""})=>{const[a,t]=g.useState(n),[l,i]=g.useState(a),[r,o]=g.useState(void 0),c=F.useRelayEnvironment(),d=g.useMemo(()=>Nn.debounce(u=>{i(u)},500),[]);return g.useEffect(()=>{d(a)},[a,d]),g.useEffect(()=>{if(!l){o(void 0);return}const m=F.fetchQuery(c,v4,{input:l}).subscribe({next:h=>{h.validateRegularExpression.isValid?o(void 0):o(h.validateRegularExpression.errorMessage??"Regular expression is invalid")}});return()=>{m.unsubscribe()}},[l,c]),{value:a,onChange:t,isInvalid:r!=null,error:r}};function C4(){const[n,a]=g.useState("--");return g.useEffect(()=>{fetch("https://api.github.com/repos/Arize-ai/phoenix").then(t=>t.json()).then(t=>{a(be(".2s")(t.stargazers_count))})},[]),e(qu,{children:n})}function k4(n){const{size:a=34}=n;return s("svg",{xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",viewBox:"0 0 305.92 350.13",width:a,height:a,css:p`
        .cls-1 {
          fill: url(#linear-gradient);
        }

        .cls-2 {
          fill: url(#Fade_to_Black_2-2);
        }

        .cls-2,
        .cls-3 {
          opacity: 0.5;
        }

        .cls-4 {
          fill: #fedbb5;
        }

        .cls-5 {
          fill: #e5b4a6;
        }

        .cls-6 {
          fill: url(#Fade_to_Black_2);
        }

        .cls-6,
        .cls-7,
        .cls-8,
        .cls-9,
        .cls-10,
        .cls-11,
        .cls-12,
        .cls-13,
        .cls-14 {
          opacity: 0.4;
        }

        .cls-3 {
          fill: url(#linear-gradient-10);
        }

        .cls-7 {
          fill: url(#linear-gradient-6);
        }

        .cls-8 {
          fill: url(#linear-gradient-3);
        }

        .cls-9 {
          fill: url(#linear-gradient-4);
        }

        .cls-10 {
          fill: url(#linear-gradient-2);
        }

        .cls-11 {
          fill: url(#linear-gradient-7);
        }

        .cls-12 {
          fill: url(#linear-gradient-5);
        }

        .cls-13 {
          fill: url(#linear-gradient-8);
        }

        .cls-14 {
          fill: url(#linear-gradient-9);
        }
      `,children:[s("defs",{children:[s("linearGradient",{id:"linear-gradient",x1:"45.77",y1:"21.43",x2:"201.89",y2:"291.83",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#18bab6"}),e("stop",{offset:".5",stopColor:"#00adee"}),e("stop",{offset:"1",stopColor:"#0095c4"})]}),s("linearGradient",{id:"linear-gradient-2",x1:"197.65",y1:"237.84",x2:"65.97",y2:"9.77",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#fdfdfe",stopOpacity:"0"}),e("stop",{offset:".11",stopColor:"#fdfdfe",stopOpacity:".17"}),e("stop",{offset:".3",stopColor:"#fdfdfe",stopOpacity:".42"}),e("stop",{offset:".47",stopColor:"#fdfdfe",stopOpacity:".63"}),e("stop",{offset:".64",stopColor:"#fdfdfe",stopOpacity:".79"}),e("stop",{offset:".78",stopColor:"#fdfdfe",stopOpacity:".9"}),e("stop",{offset:".91",stopColor:"#fdfdfe",stopOpacity:".97"}),e("stop",{offset:"1",stopColor:"#fdfdfe"})]}),e("linearGradient",{id:"linear-gradient-3",x1:"158.8",y1:"236.43",x2:"63.93",y2:"72.09",xlinkHref:"#linear-gradient-2"}),e("linearGradient",{id:"linear-gradient-4",x1:"145.73",y1:"248.43",x2:"92.77",y2:"156.7",xlinkHref:"#linear-gradient-2"}),e("linearGradient",{id:"linear-gradient-5",x1:"147.93",y1:"266.95",x2:"114.95",y2:"209.83",xlinkHref:"#linear-gradient-2"}),s("linearGradient",{id:"linear-gradient-6",x1:"92.25",y1:"261.75",x2:"92.25",y2:"321.91",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".03",stopColor:"#231f20",stopOpacity:".9"}),e("stop",{offset:".22",stopColor:"#231f20",stopOpacity:".4"}),e("stop",{offset:".42",stopColor:"#231f20",stopOpacity:".1"}),e("stop",{offset:".65",stopColor:"#231f20",stopOpacity:"0"})]}),s("linearGradient",{id:"Fade_to_Black_2","data-name":"Fade to Black 2",x1:"159.88",y1:"256.07",x2:"159.88",y2:"286.75",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:"1",stopColor:"#231f20",stopOpacity:"0"})]}),s("linearGradient",{id:"linear-gradient-7",x1:"174.69",y1:"176.58",x2:"174.69",y2:"151.5",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".03",stopColor:"#231f20",stopOpacity:".95"}),e("stop",{offset:".51",stopColor:"#231f20",stopOpacity:".26"}),e("stop",{offset:".81",stopColor:"#231f20",stopOpacity:"0"})]}),s("linearGradient",{id:"linear-gradient-8",x1:"229.53",y1:"195.1",x2:"229.53",y2:"134.41",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".18",stopColor:"#231f20",stopOpacity:".48"}),e("stop",{offset:".38",stopColor:"#231f20",stopOpacity:".12"}),e("stop",{offset:".58",stopColor:"#231f20",stopOpacity:"0"})]}),e("linearGradient",{id:"Fade_to_Black_2-2","data-name":"Fade to Black 2",x1:"286",y1:"242.89",x2:"265.05",y2:"206.61",xlinkHref:"#Fade_to_Black_2"}),e("linearGradient",{id:"linear-gradient-9",x1:"302.87",y1:"232.93",x2:"271.49",y2:"178.58",xlinkHref:"#linear-gradient-2"}),s("linearGradient",{id:"linear-gradient-10",x1:"221.39",y1:"223.73",x2:"267.07",y2:"197.36",gradientUnits:"userSpaceOnUse",children:[e("stop",{offset:"0",stopColor:"#231f20"}),e("stop",{offset:".31",stopColor:"#231f20",stopOpacity:".5"}),e("stop",{offset:".67",stopColor:"#231f20",stopOpacity:".13"}),e("stop",{offset:"1",stopColor:"#231f20",stopOpacity:"0"})]})]}),s("g",{id:"Layer_1-2","data-name":"Layer 1",children:[e("path",{className:"cls-1",d:"m305.42,218.76c-.9-4.06-2.96-7.8-6.14-11.13-1.22-1.28-2.59-2.48-4.07-3.58-.72-.53-1.48-1.03-2.26-1.52-.97-.6-1.98-1.19-3.07-1.75-4.05-2.08-7.5-4.17-10.53-6.41-1.23-.91-2.42-1.86-3.53-2.83-2.71-2.37-4.53-4.38-5.88-6.53-.44-.69-.83-1.44-1.2-2.14-.16-.31-.39-.57-.66-.77-.49-.36-1.12-.52-1.75-.4-.97.18-1.72.97-1.83,1.96-.09.76-.08,1.57.02,2.41.06.5-.2.96-.66,1.17-.11.05-.22.08-.33.09-.64.08-1.23.43-1.6.96-.37.54-.48,1.2-.33,1.83.14.55.32.93.48,1.24l.14.28c.1.19.2.39.31.58.3.57.62,1.15,1,1.71.71,1.04,1.52,2.07,2.46,3.18.3.35.35.86.13,1.27-.22.41-.68.64-1.14.58-5.37-.73-10.17-1.93-14.65-3.59-.51-.19-1.03-.37-1.53-.57-4.02-1.69,3.23-8.92,6.55-14.03,14.55-22.37,17.56-48,17.68-73.93.12-25.07-2.59-49.78-7.57-74.18v-.04c-3.25-20.44-6.01-28.12-7.74-30.97-.37-.76-.78-1.22-1.21-1.45-.48-.32-.73-.17-.73-.17-.93.03-2.01.87-3.3,2.22-5.42,5.71-5.12,12.49-3.62,19.58,6.85,32.22,12.01,64.63,9.66,97.75-1.61,22.83-5.87,44.82-21.82,62.69-.96,1.08-1.99,2.08-3.02,3.1-1.2,1.17-3.04,3.46-4.42,2.51-1.84-1.28-.2-3.9.37-5.25,9.35-21.89,12.04-44.77,10.6-68.36-.03-.55-.09-1.09-.13-1.63l.02-.03c-.04-.44-.08-.85-.12-1.28-.24-3.12-.53-6.23-.92-9.33-4.02-37.42-8.84-39.84-8.84-39.84h0c-.32-.28-.72-.51-1.25-.62-2.53-.53-3.92,1.7-5.04,3.39-5.07,7.6-2.83,15.67-1.19,23.67,5.73,28.01,5.82,55.75-4.02,83-.9,2.48-1.98,4.9-3.12,7.28-1.2,2.53-1.99,5.7-6.12,4.34-3.86-1.28-2.78-4.2-2.27-6.87,1.29-6.79,2.33-13.59,2.98-20.42l.02.04c.06-.67.1-1.32.16-1.98.1-1.18.17-2.36.24-3.54.06-.99.11-1.96.15-2.91.02-.49.04-.97.06-1.46.78-21.63-2.85-31.46-4.23-34.37-.15-.36-.32-.68-.51-.97h0s0,0,0,0c-1.43-2.14-3.8-1.89-5.84.13-3.76,3.72-5.84,8.1-4.88,13.62,2.8,16.09,1.16,32.03-1.84,47.9-.41,2.13-1.36,6-5.9,5.01-3.09-.68-3.81-2.01-3.99-4.69.03-2.03.01-4.05-.06-6.08,0-.05,0-.1,0-.15h0c-.01-.29-.03-.57-.04-.86v-.02c0-.14,0-.27-.02-.4-.13-2.76-.36-5.53-.7-8.3-.03-.27-.08-.53-.12-.79-1.74-15.62-4-17.13-4-17.13-1.45-1.88-3.71-1.57-5.67.38-3.76,3.72-5.67,8.08-4.88,13.62.57,4.06.43,2.81.84,6.34.33,1.82.66,5.13.69,6.19-.09.94-.32,1.76-.9,2.37-1.92,2.07-5.02-.05-7.37-1.02-45.52-18.84-84.49-45.28-118.5-78.71C29.51,74.47,6.74,46.89,6.74,46.89h0c-.84-.99-1.91-1.55-3.53-.85C.24,47.32.33,51.13.06,54.33c-.54,6.41,2.88,11.07,6.62,15.42,51.36,59.92,114.05,102.98,189.7,124.51l13.61,3.61c.16.04.32.08.48.12.03,0,.05.02.07.02l11.72,3.11.32.08c-.38.11-.82.2-1.28.28-12.9,2.55-38.42-2.14-58.91-6.92-10.15-2.13-20.1-4.71-29.85-7.79-.45-.13-.69-.2-.69-.2v-.02c-37.88-12.05-72.58-31.59-102.92-61.4-2.87-2.82-5.54-5.86-8.15-8.95-2.41-2.86-7.36-8.84-9.06-10.89-.19-.27-.39-.51-.6-.73h0s0,0,0,0c-.52-.53-1.14-.87-2.03-.66-2.12.49-2.72,2.67-3.11,4.51-1.55,7.39.8,13.59,5.76,19.15,31.09,34.84,70.09,57.1,113.9,71.7,24.88,8.29,50.46,13.32,76.57,16.54-15.56,5.04-31.58,6.57-47.72,6.17-31.26-.78-60.57-8.29-88.12-21.68-10.16-5.22-19.62-11.05-22.11-12.6-1.43-.98-2.9-1.57-4.36-.45-2.74,2.12-.85,5.85.03,8.76,1.69,5.6,5.58,9.47,10.63,12.14,44.88,23.74,92.26,33.22,142.71,24.8,5.11-.85,9.95-1.79,15.29-3.59-8.43,7.3-18.2,12.06-28.47,15.82-31.59,11.56-62.98,11.09-94.25,3.27-10.03-2.69-21.68-7.05-21.68-7.05h0c-1.68-.73-3.34-.99-4.64.87-2.28,3.27-.29,6.66,1.68,9.74,4.67,7.27,13.68,7.98,20.81,10.44,2.44.77-4.2,5.21-6.34,6.84-10.34,7.91-20.46,15.14-30.76,22.8l-6.74,4.97h0c-1.16.8-2.18,1.69-1.64,3.37.61,1.88,2.57,2.22,4.47,2.62,7.37,1.53,13.66-.92,19.48-5.27,12.48-9.35,25.18-18.41,37.39-28.11,4.64-3.7,8.86-3.39,15.21-1.74-15.88,11.97-30.73,23.17-45.6,34.36-15.08,11.35-30.18,22.7-45.28,34.03l-9.98,7.38c-.15.1-.29.21-.43.32l-.15.11h0c-.85.68-1.48,1.44-1.3,2.44.4,2.25,3.05,2.81,5.21,3.18,8.92,1.54,14.44-1.82,20.54-6.39,30.5-22.9,61.12-45.64,91.44-68.76,6.8-5.18,13.79-8.11,23.61-7.01-8.36,6.25-16.38,12.24-24.3,18.16l-21.51,15.92c-.15.11-.3.22-.45.33h-.02c-1.14.9-1.94,1.96-1.49,3.53.82,2.84,4.24,3.18,7.15,3.62,5.34.8,9.87-1.09,14.06-4.21,2.41-1.8,4.84-3.57,7.28-5.33h0s32.84-26.08,32.84-26.08c0,0,7.76-5.54,16.74-10.64.8-.5,1.61-1,2.41-1.49.34-.15,1.2-.54,2.48-1.16.97-.5,1.93-.99,2.89-1.44,1.41-.72,3.05-1.59,4.88-2.59,5.3-2.2,20.44-9.27,32.98-22.62,5.96-4.6,14.34-10.6,20.87-13.49h0s.04-.02.04-.02c.5-.22.98-.42,1.46-.6h0s.03,0,.06-.02c.32-.12.63-.23.93-.33l.84-.33c2.36-.67,6.22-.92,6.71,4.29.09,1.28.06,2.59-.08,3.97-.11,1.04-.3,2.14-.46,3.02-.15.85.2,1.71.88,2.21.11.08.22.15.34.21.9.44,1.99.24,2.66-.51.25-.28.51-.55.77-.83,3.22-3.38,6.47-5.73,9.95-7.16,5.07-2.1,10.2-2.11,15.68-.02,2.6.99,5.05,2.34,7.48,4.14,1.03.76,2.08,1.62,3.11,2.55.61.56,1.22,1.18,1.76,1.72l.09.09.44.45c.08.08.17.16.26.22.52.38,1.18.53,1.82.39.75-.16,1.37-.69,1.63-1.41.05-.14.1-.28.15-.41,1.56-4.59,1.87-8.82.97-12.93Z"}),e("path",{className:"cls-4",d:"m208.42,169.5c-.37,2.28-.76,4.55-1.19,6.82.43-2.27.82-4.55,1.19-6.82h0Z"}),e("path",{className:"cls-4",d:"m248.79,194.81c.16.07.33.13.5.19-.17-.06-.33-.13-.5-.19"}),e("path",{className:"cls-4",d:"m230.37,180.81s0,0,0,.01c0,0,0,0,0-.01"}),e("path",{className:"cls-4",d:"m230.5,180.5s-.03.06-.04.1c.01-.03.03-.07.04-.1"}),e("path",{className:"cls-4",d:"m255.55,180.46s-.05.08-.08.13c.03-.04.05-.08.08-.13"}),e("path",{className:"cls-4",d:"m215.62,178.85c-.28.59-.54,1.22-.82,1.82.28-.59.54-1.22.82-1.82"}),e("path",{className:"cls-4",d:"m188.53,177.51s.01,0,.02,0c0,0-.01,0-.02,0"}),e("polyline",{className:"cls-4",points:"184.47 175.68 184.47 175.69 184.47 175.68"}),e("polyline",{className:"cls-4",points:"184.45 175.66 184.46 175.66 184.45 175.66"}),e("polyline",{className:"cls-4",points:"184.43 175.62 184.44 175.64 184.43 175.62"}),e("path",{className:"cls-4",d:"m184.42,175.6s0,0,0,.01c0,0,0,0,0-.01"}),e("path",{className:"cls-4",d:"m184.39,175.57s.01.02.02.03c0-.01-.01-.02-.02-.03"}),e("path",{className:"cls-4",d:"m183.65,172.72s0,.01,0,.02c0,0,0-.01,0-.02"}),e("path",{className:"cls-4",d:"m193.79,171c-.08.46-.17.91-.26,1.37.09-.46.17-.91.26-1.37"}),e("path",{className:"cls-4",d:"m168.79,167.86c-.3.32-.63.54-.99.68.35-.14.68-.36.99-.68"}),e("path",{className:"cls-5",d:"m184.47,175.69c.25.35.57.64.99.9h0c-.42-.25-.74-.55-.99-.9m-.02-.03s0,.01.01.02c0,0,0-.01-.01-.02m-.02-.02v.02s0-.01,0-.02m-.01-.02s0,0,0,0c0,0,0,0,0,0m-.01-.01s0,0,0,0c0,0,0,0,0,0m-.02-.04s0,0,0,0c0,0,0,0,0,0m-.74-2.82s0,.01,0,.01c0,0,0,0,0-.01m0-.06h0s0,.03,0,.04c0-.01,0-.02,0-.04m-19.74-4.71s.03.01.04.02c.95.41,1.9.74,2.79.74.37,0,.73-.06,1.06-.19-.34.13-.69.19-1.06.19-.9,0-1.87-.34-2.83-.75m19.61-2.97s0,.01,0,.02c0,0,0-.01,0-.02"}),e("path",{className:"cls-5",d:"m249.29,195c.08.03.16.06.24.09h0c-.08-.03-.16-.06-.24-.09m-18.14-7.32s0,0-.01,0c0,0,.01,0,.01,0m-2.75-1.47c0,.64.22,1.23.85,1.66.23.16.47.23.71.23.38,0,.77-.16,1.17-.41-.4.25-.79.41-1.17.41-.25,0-.49-.07-.72-.23-.63-.43-.85-1.02-.85-1.66m1.33-3.84c-.04.08-.07.17-.11.25.04-.08.07-.17.11-.25m.64-1.54c-.21.51-.42,1.02-.64,1.53.22-.51.43-1.02.64-1.53m.09-.23c-.03.07-.06.14-.09.22.03-.07.06-.14.09-.22m25.01-.01s-.01.02-.02.03c0-.01.01-.02.02-.03m.1-.16s-.01.02-.02.03c0-.01.01-.02.02-.03m-25.03-.01s-.03.06-.04.09c.01-.03.02-.06.04-.09m-23.84-.69c0,1.46.59,2.74,2.81,3.47.68.23,1.28.33,1.8.33,1.87,0,2.77-1.32,3.5-2.85-.73,1.53-1.62,2.85-3.5,2.85-.52,0-1.11-.1-1.8-.33-2.22-.73-2.8-2.01-2.81-3.47m-18.18-2.21h.01-.01m3.63-1.49c-.67.87-1.65,1.51-3.14,1.51-.15,0-.3,0-.46-.02.16.01.31.02.46.02,1.48,0,2.47-.63,3.14-1.51m28.75-10.95s-.01,0-.02,0c-.66,2.17-1.35,4.33-2.13,6.49-.9,2.48-1.98,4.9-3.12,7.28h0c1.13-2.38,2.22-4.8,3.12-7.28.78-2.16,1.5-4.33,2.16-6.49m-25.9-1.2c-.36,2.38-.76,4.75-1.2,7.12.44-2.37.84-4.75,1.2-7.12h0m58.07-11.39s0,0,0,0c-3.26,10.69-8.32,20.76-16.37,29.77-.96,1.08-1.99,2.08-3.02,3.1h0c1.03-1.01,2.06-2.02,3.02-3.1,8.05-9.02,13.12-19.09,16.38-29.78"}),e("path",{className:"cls-10",d:"m4.56,45.73c-.4,0-.85.09-1.34.31-2.11.91-2.68,3.11-2.93,5.45,11.33,14.85,56.07,69.62,126.46,107.18,0,0,68.91,36.38,138.24,40.31-5.37-.73-10.17-1.93-14.65-3.59-.26-.1-.53-.19-.8-.29h0c-25.19-5.44-46.66-12.25-61.84-17.7.29.06.57.1.84.13-.28-.03-.57-.07-.88-.14-.92-.2-1.62-.46-2.17-.79-12.01-4.39-19.66-7.76-21.51-8.59-.88-.38-1.75-.83-2.53-1.15-45.52-18.84-84.49-45.28-118.5-78.71C29.51,74.47,6.74,46.89,6.74,46.89h0c-.58-.68-1.28-1.16-2.18-1.16"}),e("path",{className:"cls-8",d:"m9.57,103.87c-.16,0-.33.02-.51.06-2.12.49-2.72,2.67-3.11,4.51-.07.33-.13.66-.18.99,35.19,47.67,82.41,67.15,82.41,67.15,47.15,22.21,85.84,26.69,109.4,26.69,9.75,0,16.91-.77,21.01-1.37-1.87.21-3.93.31-6.14.31-13.81,0-33.56-3.79-50.06-7.64-10.15-2.13-20.1-4.71-29.85-7.79-.45-.13-.69-.2-.69-.2v-.02c-37.88-12.05-72.58-31.59-102.92-61.4-2.87-2.82-5.54-5.86-8.15-8.95-2.41-2.86-7.36-8.84-9.06-10.89-.19-.27-.39-.51-.6-.73h0s0,0,0,0c-.41-.42-.9-.72-1.53-.72"}),e("path",{className:"cls-9",d:"m41.57,186.66c-.56,0-1.13.18-1.69.61-2.39,1.85-1.26,4.91-.35,7.6,17.64,10.71,58.1,31.53,106.02,31.53,18.09,0,37.24-2.97,56.64-10.57-14,4.54-28.37,6.23-42.87,6.23-1.61,0-3.23-.02-4.85-.06-31.26-.78-60.57-8.29-88.12-21.68-10.16-5.22-19.62-11.05-22.11-12.6-.88-.6-1.78-1.06-2.68-1.06"}),e("path",{className:"cls-12",d:"m205.41,231.93c-7.68,5.89-16.32,9.97-25.34,13.27-16.95,6.2-33.84,8.94-50.68,8.94-14.56,0-29.08-2.05-43.57-5.67-10.03-2.69-21.68-7.05-21.68-7.05h0c-.74-.32-1.47-.55-2.17-.55-.9,0-1.74.38-2.47,1.42-1.06,1.52-1.2,3.07-.85,4.6,11.13,5.17,35,14.36,64.11,14.36,25.24,0,54.41-6.9,82.66-29.31"}),e("path",{className:"cls-7",d:"m130.35,268.02c-27.34,0-48.01-5.54-50.62-6.27.77.23,1.52.46,2.26.71,2.44.77-4.2,5.21-6.34,6.84-7.65,5.85-15.17,11.32-22.73,16.88h23.2c7.31-5.4,14.6-10.84,21.72-16.5,2.65-2.11,5.15-2.91,7.99-2.91,2.15,0,4.48.46,7.22,1.17-15.88,11.97-30.73,23.17-45.6,34.36-8.69,6.54-17.39,13.07-26.09,19.61h23.34c20.99-15.71,41.97-31.42,62.82-47.32,4.81-3.67,9.71-6.2,15.64-6.98-4.39.29-8.67.41-12.8.41Z"}),e("path",{className:"cls-6",d:"m125.47,286.75h22.55l16.66-13.24s7.76-5.54,16.74-10.64c.8-.5,1.61-1,2.41-1.49.34-.15,1.2-.54,2.48-1.16.97-.5,1.93-.99,2.89-1.44,1.46-.75,3.18-1.65,5.09-2.71-16.08,6.73-32.54,10.02-47.79,11.29.21,0,.42,0,.63,0,1.28,0,2.61.07,3.99.23-8.36,6.25-16.38,12.24-24.3,18.16l-1.36,1Z"}),e("path",{className:"cls-11",d:"m183.65,172.69c.03-2.03.01-4.05-.06-6.08v-.15s0,0,0,0c-.01-.29-.03-.57-.04-.86v-.02s-.02-.4-.02-.4c-.08-1.7-.21-3.41-.37-5.12-5.38-2.26-10.45-5.15-15.12-8.56.03.48.05.96.12,1.46.57,4.06.43,2.81.84,6.34.33,1.82.66,5.13.69,6.19-.09.94-.32,1.76-.9,2.37-.59.63-1.29.87-2.05.87-.9,0-1.87-.34-2.83-.75,1.78.8,9.45,4.19,21.55,8.61-1.3-.79-1.69-2.01-1.81-3.9Z"}),e("path",{className:"cls-13",d:"m271.38,134.41c-5.03,7.01-11.24,13.15-18.32,18.08-3.26,10.69-8.32,20.76-16.37,29.77-.96,1.08-1.99,2.08-3.02,3.1-1,.97-2.45,2.73-3.7,2.73-.25,0-.49-.07-.72-.23-1.84-1.28-.2-3.9.37-5.25,3.02-7.06,5.33-14.23,7.04-21.49-5.04,1.89-10.33,3.22-15.79,3.96-.66,2.17-1.35,4.33-2.13,6.49-.9,2.48-1.98,4.9-3.12,7.28-1,2.11-1.72,4.67-4.32,4.67-.52,0-1.11-.1-1.8-.33-3.86-1.28-2.78-4.2-2.27-6.87.67-3.54,1.27-7.08,1.79-10.63-4.8-.15-9.49-.77-14.03-1.82-.43,2.83-.92,5.67-1.46,8.49-.36,1.89-1.16,5.17-4.53,5.17-.4,0-.85-.05-1.33-.15,15.19,5.45,36.66,12.26,61.84,17.71h0c-.25-.1-.5-.19-.74-.29-4.02-1.69,3.23-8.92,6.55-14.03,9.35-14.37,13.92-30.09,16.03-46.36Z"}),e("path",{className:"cls-2",d:"m267.61,212.35c-3.15,0-6.32.3-9.44.88-.59.11-1.17.16-1.72.16-.89,0-1.72-.13-2.5-.37.13.16.25.3.37.47,1.37,1.9,2.08,3.98,2.35,6.14.34.37.63.84.86,1.43h0s0,.02.01.03c0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,0,0,.01,0,0,0,0,0,.01,0,0,0,.01,0,.01,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,0,0,0v.02s0,0,0,.01c0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.02,0,.02,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,0,0,.01,0,.02,0,.03,0,0,0,0,0,0,0,0,0,0,0,.01t0,0s0,.02,0,.03c0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,0,0,.02,0,0,0,.01,0,.02,0,0,0,.01,0,.01,0,0,0,.01,0,.01,0,0,0,.01,0,.02,0,0,0,.01,0,.01,0,0,0,0,0,.02s0,.01,0,.02c0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,.01,0,.01s0,.01,0,.01c0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,.01,0,0,0,.01,0,.02,0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.02,0,0,0,0,0,0,0,.01,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.03,0,0,0,0,0,0,0,0,0,.02,0,.03h0s0,.03,0,.04h0s0,.02,0,.03h0s0,.03,0,.03h0s0,.03,0,.04h0s0,.02,0,.03h0s0,.02,0,.03h0s0,.02,0,.03h0s0,.02,0,.04c0,0,0,0,0,0,0,.03.01.07.01.1h0s0,.03,0,.04h0s0,.07.01.11h0s0,.02,0,.04h0s0,.03,0,.04h0s0,.05,0,.07h0s0,.02,0,.04h0s0,.03,0,.04h0s0,.03,0,.04h0c.03.5.05,1,.05,1.52,0,.8-.04,1.61-.13,2.46-.11,1.04-.3,2.14-.46,3.02-.02.13-.04.27-.04.4,0,.71.34,1.39.92,1.81l.34.21c.32.16.66.23,1,.23.62,0,1.23-.26,1.67-.74.25-.28.51-.55.77-.83,3.22-3.38,6.47-5.73,9.95-7.16,2.54-1.05,5.1-1.58,7.71-1.58s5.24.52,7.96,1.56c2.6.99,5.05,2.34,7.48,4.14,1.03.76,2.08,1.62,3.11,2.55.61.56,1.22,1.18,1.76,1.72l.09.09.44.45.26.22c.38.28.83.43,1.3.44-2.15-4.61-4.88-8.9-8.73-12.24-7.28-6.31-16.46-8.98-25.8-8.98"}),e("path",{className:"cls-14",d:"m266.74,181.67l-.41.04c-.97.18-1.72.97-1.83,1.96-.09.76-.08,1.57.02,2.41.03.26-.03.52-.16.73,3.89,5.78,12.33,16.03,25.15,19.91,0,0,19.81,10.36,14.8,25.38h0l.15-.41c1.56-4.59,1.87-8.82.97-12.93-.9-4.06-2.96-7.8-6.14-11.13-1.22-1.28-2.59-2.48-4.07-3.58-.72-.53-1.48-1.03-2.26-1.52-.97-.6-1.98-1.19-3.07-1.75-4.05-2.08-7.5-4.17-10.53-6.41-1.23-.91-2.42-1.86-3.53-2.83-2.71-2.37-4.53-4.38-5.88-6.53-.44-.69-.83-1.44-1.2-2.14-.16-.31-.39-.57-.66-.77-.38-.28-.85-.44-1.34-.44"}),e("path",{className:"cls-3",d:"m241.61,223.53l4.01-2.33,16.87-22.61s-9.24-1.75-13.7-3.78c0,0-4.64,21.12-21.73,38.76l6.3-4.67c2.51-1.76,4.79-3.29,8.24-5.37Z"})]})]})}function L4({className:n}){return e("svg",{width:"90",height:"30",viewBox:"0 0 50 13",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:n,children:e("path",{d:"M3.25 0.582999C4.12267 0.582999 4.82533 0.900333 5.358 1.535C5.902 2.15833 6.174 2.98 6.174 4C6.174 4.99733 5.91333 5.802 5.392 6.414C4.87067 7.026 4.185 7.332 3.335 7.332H1.737C1.69167 7.332 1.669 7.35467 1.669 7.4V12.33C1.669 12.4433 1.61233 12.5 1.499 12.5H0.207C0.0936667 12.5 0.0370001 12.4433 0.0370001 12.33V0.752999C0.0370001 0.639666 0.0936667 0.582999 0.207 0.582999H3.25ZM2.995 6.023C3.45967 6.023 3.83367 5.84733 4.117 5.496C4.40033 5.13333 4.542 4.646 4.542 4.034C4.542 3.41067 4.40033 2.91767 4.117 2.555C3.83367 2.181 3.45967 1.994 2.995 1.994H1.737C1.69167 1.994 1.669 2.01667 1.669 2.062V5.955C1.669 6.00033 1.69167 6.023 1.737 6.023H2.995ZM12.0589 0.769999C12.0589 0.656666 12.1156 0.599999 12.2289 0.599999H13.5209C13.6343 0.599999 13.6909 0.656666 13.6909 0.769999V12.33C13.6909 12.4433 13.6343 12.5 13.5209 12.5H12.2289C12.1156 12.5 12.0589 12.4433 12.0589 12.33V7.315C12.0589 7.26967 12.0363 7.247 11.9909 7.247H9.42392C9.37859 7.247 9.35592 7.26967 9.35592 7.315V12.33C9.35592 12.4433 9.29926 12.5 9.18592 12.5H7.89392C7.78059 12.5 7.72392 12.4433 7.72392 12.33V0.769999C7.72392 0.656666 7.78059 0.599999 7.89392 0.599999H9.18592C9.29926 0.599999 9.35592 0.656666 9.35592 0.769999V5.768C9.35592 5.81333 9.37859 5.836 9.42392 5.836H11.9909C12.0363 5.836 12.0589 5.81333 12.0589 5.768V0.769999ZM18.6483 12.636C17.7189 12.636 16.9709 12.3527 16.4043 11.786C15.8376 11.2193 15.5543 10.4657 15.5543 9.525V3.592C15.5543 2.65133 15.8376 1.89767 16.4043 1.331C16.9709 0.753 17.7189 0.464 18.6483 0.464C19.5889 0.464 20.3426 0.753 20.9093 1.331C21.4873 1.89767 21.7763 2.65133 21.7763 3.592V9.525C21.7763 10.4657 21.4873 11.2193 20.9093 11.786C20.3426 12.3527 19.5889 12.636 18.6483 12.636ZM18.6483 11.225C19.1016 11.225 19.4643 11.0777 19.7363 10.783C20.0083 10.477 20.1443 10.0803 20.1443 9.593V3.507C20.1443 3.01967 20.0083 2.62867 19.7363 2.334C19.4643 2.028 19.1016 1.875 18.6483 1.875C18.2063 1.875 17.8493 2.028 17.5773 2.334C17.3166 2.62867 17.1863 3.01967 17.1863 3.507V9.593C17.1863 10.0803 17.3166 10.477 17.5773 10.783C17.8493 11.0777 18.2063 11.225 18.6483 11.225ZM29.3398 1.841C29.3398 1.95433 29.2832 2.011 29.1698 2.011H25.3448C25.2995 2.011 25.2768 2.03367 25.2768 2.079V5.768C25.2768 5.81333 25.2995 5.836 25.3448 5.836H27.6908C27.8042 5.836 27.8608 5.89267 27.8608 6.006V7.077C27.8608 7.19033 27.8042 7.247 27.6908 7.247H25.3448C25.2995 7.247 25.2768 7.26967 25.2768 7.315V11.021C25.2768 11.0663 25.2995 11.089 25.3448 11.089H29.1698C29.2832 11.089 29.3398 11.1457 29.3398 11.259V12.33C29.3398 12.4433 29.2832 12.5 29.1698 12.5H23.8148C23.7015 12.5 23.6448 12.4433 23.6448 12.33V0.769999C23.6448 0.656666 23.7015 0.599999 23.8148 0.599999H29.1698C29.2832 0.599999 29.3398 0.656666 29.3398 0.769999V1.841ZM35.7767 0.769999C35.7767 0.656666 35.8334 0.599999 35.9467 0.599999H37.2217C37.335 0.599999 37.3917 0.656666 37.3917 0.769999V12.33C37.3917 12.4433 37.335 12.5 37.2217 12.5H35.7597C35.669 12.5 35.6067 12.4547 35.5727 12.364L32.6827 4.595C32.6714 4.57233 32.6544 4.56667 32.6317 4.578C32.609 4.578 32.5977 4.58933 32.5977 4.612L32.6147 12.33C32.6147 12.4433 32.558 12.5 32.4447 12.5H31.1527C31.0394 12.5 30.9827 12.4433 30.9827 12.33V0.769999C30.9827 0.656666 31.0394 0.599999 31.1527 0.599999H32.5977C32.6884 0.599999 32.7507 0.645333 32.7847 0.735999L35.6917 8.505C35.703 8.539 35.72 8.556 35.7427 8.556C35.7654 8.54467 35.7767 8.522 35.7767 8.488V0.769999ZM39.6693 12.5C39.556 12.5 39.4993 12.4433 39.4993 12.33V0.769999C39.4993 0.656666 39.556 0.599999 39.6693 0.599999H40.9613C41.0746 0.599999 41.1313 0.656666 41.1313 0.769999V12.33C41.1313 12.4433 41.0746 12.5 40.9613 12.5H39.6693ZM42.8947 12.5C42.838 12.5 42.7927 12.483 42.7587 12.449C42.736 12.4037 42.736 12.3527 42.7587 12.296L45.1217 6.601C45.1443 6.567 45.1443 6.533 45.1217 6.499L42.7587 0.804L42.7417 0.735999C42.7417 0.645333 42.7927 0.599999 42.8947 0.599999H44.2207C44.3113 0.599999 44.3737 0.645333 44.4077 0.735999L45.9547 4.833C45.966 4.867 45.983 4.884 46.0057 4.884C46.0283 4.884 46.0453 4.867 46.0567 4.833L47.5867 0.735999C47.6207 0.645333 47.683 0.599999 47.7737 0.599999H49.0997C49.1563 0.599999 49.196 0.622666 49.2187 0.667999C49.2527 0.702 49.2583 0.747333 49.2357 0.804L46.8727 6.516C46.8613 6.55 46.8613 6.584 46.8727 6.618L49.2357 12.296L49.2527 12.364C49.2527 12.4547 49.2017 12.5 49.0997 12.5H47.7907C47.7 12.5 47.6377 12.4547 47.6037 12.364L46.0567 8.284C46.0453 8.25 46.0283 8.233 46.0057 8.233C45.983 8.233 45.966 8.25 45.9547 8.284L44.4077 12.364C44.3737 12.4547 44.3113 12.5 44.2207 12.5H42.8947Z",fill:"var(--ac-global-text-color-900)"})})}const S4=p`
  padding: var(--ac-global-dimension-static-size-100);
  background-color: var(--ac-global-color-grey-100);
  flex: none;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  gap: var(--ac-global-dimension-static-size-100);
`,w4=p`
  padding: var(--ac-global-dimension-static-size-200)
    var(--ac-global-dimension-static-size-100);
  background-color: var(--ac-global-color-grey-100);
  flex: none;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  height: 100vh;
  width: var(--px-nav-collapsed-width);
  transition: width 0.15s cubic-bezier(0, 0.57, 0.21, 0.99);
  &[data-expanded="true"] {
    width: var(--px-nav-expanded-width);
  }
  &[data-expanded="false"] {
    .brand-text-wrap {
      opacity: 0;
    }
  }
`,et=p`
  width: 100%;
  color: var(--ac-global-color-grey-500);
  background-color: transparent;
  border-radius: var(--ac-global-rounding-small);
  display: flex;
  flex-direction: row;
  align-items: center;
  overflow: hidden;
  transition:
    color 0.2s ease-in-out,
    background-color 0.2s ease-in-out;
  text-decoration: none;
  cursor: pointer;

  &.active {
    color: var(--ac-global-text-color-900);
    background-color: var(--ac-global-color-grey-200);
  }
  &:hover:not(.active) {
    color: var(--ac-global-text-color-900);
    background-color: var(--ac-global-color-grey-200);
  }
  & > .ac-icon-wrap {
    padding: var(--ac-global-dimension-size-100);
    display: inline-block;
  }
  .ac-text {
    padding-inline-start: var(--ac-global-dimension-size-50);
    padding-inline-end: var(--ac-global-dimension-size-100);
    white-space: nowrap;
  }
`,x4=p`
  color: var(--ac-global-text-color-900);
  font-size: var(--ac-global-font-size-xl);
  text-decoration: none;
  margin: 0 0 var(--ac-global-dimension-static-size-200) 0;
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: var(--ac-global-dimension-static-size-150);
  overflow: hidden;
  & > * {
    flex: none;
  }
  .brand-text-wrap {
    opacity: 1;
    transition: all 0.8s ease-in-out;
    display: flex;
    flex-direction: row;
    align-items: center;
  }
`;function Cl(n){return s(j,{delay:0,isDisabled:n.isExpanded,children:[e(se,{children:s("a",{href:n.href,target:n.replaceTab?void 0:"_blank",css:et,rel:"noreferrer",role:"button",children:[n.leadingVisual,e(C,{children:n.text}),n.trailingVisual]})}),e(xe,{placement:"right",offset:10,children:n.text})]})}function ih({isExpanded:n}){return e(Cl,{href:"https://arize.com/docs/phoenix",leadingVisual:e(x,{svg:e(a2,{})}),text:"Documentation",isExpanded:n})}function rh({isExpanded:n}){return e(Cl,{href:"https://github.com/Arize-ai/phoenix",leadingVisual:e(x,{svg:e(g2,{})}),trailingVisual:e(C4,{}),text:"Star on GitHub",isExpanded:n})}function oh({isExpanded:n}){const{theme:a,systemTheme:t,themeMode:l,setThemeMode:i}=de(),{themeText:r,themeIcon:o}=g.useMemo(()=>{let c,d;switch(l){case"light":c=e(Jl,{}),d="Light";break;case"dark":c=e(Xl,{}),d="Dark";break;case"system":c=e(Ql,{}),d=`${a==="light"?"Light":"Dark"} (auto)`;break;default:N()}return{themeIcon:c,themeText:d}},[a,l]);return s(j,{delay:0,isDisabled:n,children:[s(Ya,{children:[s(nn,{css:et,className:"button--reset",children:[e(x,{svg:o}),e(C,{children:r})]}),s(le,{placement:"right top",children:[e(tn,{}),s(ta,{"aria-label":"Theme selection",selectedKeys:new Set([l]),selectionMode:"single",onSelectionChange:c=>{const d=c instanceof Set?Array.from(c)[0]:null;d&&or(d)&&i(d)},children:[e(Ke,{id:"system",children:s(S,{direction:"row",gap:"size-100",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(Ql,{})}),e(C,{children:`Auto (${t})`})]})}),e(Ke,{id:"dark",children:s(S,{direction:"row",gap:"size-100",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(Xl,{})}),e(C,{children:"Dark"})]})}),e(Ke,{id:"light",children:s(S,{direction:"row",gap:"size-100",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(Jl,{})}),e(C,{children:"Light"})]})})]})]})]}),e(xe,{placement:"right",offset:10,children:r})]})}function sh(){return s(Da,{to:"/",css:x4,title:`version: ${window.Config.platformVersion}`,children:[e(k4,{}),e("div",{className:"brand-text-wrap",children:e(L4,{className:"brand-text"})})]})}function ch({children:n}){return e("nav",{css:S4,children:n})}function dh({children:n,isExpanded:a}){return e("nav",{"data-expanded":a,css:w4,children:n})}function uh(n){return s(j,{delay:0,isDisabled:n.isExpanded,children:[e(se,{children:e("div",{role:"button",children:s(Ws,{to:n.to,css:et,children:[n.leadingVisual,e(C,{children:n.text})]})})}),e(xe,{placement:"right",offset:10,children:n.text})]})}function mh(n){return s("button",{className:"button--reset",css:et,onClick:n.onClick,children:[n.leadingVisual,e(C,{children:n.text})]})}const gh=({isExpanded:n})=>{const{viewer:a}=kn();return a!=null&&a.isManagementUser&&window.Config.managementUrl?e("li",{children:e(Cl,{href:window.Config.managementUrl,leadingVisual:e(x,{svg:e(w2,{})}),text:"Management Console",replaceTab:!0,isExpanded:n})},"management"):null};function T4(n){var a;return typeof n.handle=="object"&&typeof((a=n.handle)==null?void 0:a.crumb)=="function"}const fo=()=>Qs().filter(T4);function ph(){const n=fo();return e(T3,{size:"L",children:n.map((a,t)=>e(S3,{children:e(Da,{to:a.pathname,children:a.handle.crumb(a.loaderData)})},t))})}function hh(){const{isSideNavExpanded:n,setIsSideNavExpanded:a}=Me(t=>({isSideNavExpanded:t.isSideNavExpanded,setIsSideNavExpanded:t.setIsSideNavExpanded}));return s(j,{children:[e($n,{size:"S",onPress:()=>a(!n),"aria-label":n?"Collapse side":"Expand side",children:e(x,{svg:n?e(Zr,{}):e(Ur,{})})}),e(xe,{placement:"bottom",offset:10,children:n?"Collapse":"Expand"})]})}function fh(){const n=fo(),a=g.useMemo(()=>n.map(t=>t.handle.crumb(t.loaderData)).reverse().join(" - ")||"Phoenix",[n]);return e("title",{children:a})}const bo=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"maxCount",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"maxDays",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"ProjectTraceRetentionPolicySelectFragment",selections:[{alias:null,args:null,concreteType:"ProjectTraceRetentionPolicyConnection",kind:"LinkedField",name:"projectTraceRetentionPolicies",plural:!1,selections:[{alias:null,args:null,concreteType:"ProjectTraceRetentionPolicyEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"ProjectTraceRetentionPolicy",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cronExpression",storageKey:null},{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"rule",plural:!1,selections:[{kind:"InlineFragment",selections:[n],type:"TraceRetentionRuleMaxCount",abstractKey:null},{kind:"InlineFragment",selections:[a],type:"TraceRetentionRuleMaxDays",abstractKey:null},{kind:"InlineFragment",selections:[a,n],type:"TraceRetentionRuleMaxDaysOrCount",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null}})();bo.hash="319a452afbbe089cfba02eaf9722b595";function bh({defaultValue:n,onChange:a,query:t,isDisabled:l}){const r=F.useFragment(bo,t).projectTraceRetentionPolicies.edges.map(o=>o.node);return s(We,{size:"S",defaultValue:n,onChange:o=>{o&&(a==null||a(o.toString()))},isDisabled:l,children:[e(P,{children:"Retention Policy"}),s(D,{children:[e(Ge,{}),e(ze,{})]}),e(le,{children:e(Ie,{children:r.map(o=>e(oe,{id:o.id,children:o.name},o.id))})})]})}const yo=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"connections"},a={defaultValue:null,kind:"LocalArgument",name:"label"},t=[{kind:"Variable",name:"input",variableName:"label"}],l={alias:null,args:null,concreteType:"PromptLabel",kind:"LinkedField",name:"promptLabels",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"NewPromptLabelDialogMutation",selections:[{alias:null,args:t,concreteType:"PromptLabelMutationPayload",kind:"LinkedField",name:"createPromptLabel",plural:!1,selections:[l],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"NewPromptLabelDialogMutation",selections:[{alias:null,args:t,concreteType:"PromptLabelMutationPayload",kind:"LinkedField",name:"createPromptLabel",plural:!1,selections:[l,{alias:null,args:null,filters:null,handle:"prependNode",key:"",kind:"LinkedHandle",name:"promptLabels",handleArgs:[{kind:"Variable",name:"connections",variableName:"connections"},{kind:"Literal",name:"edgeTypeName",value:"PromptLabelEdge"}]}],storageKey:null}]},params:{cacheID:"c61bebc2bf20d8cf12760e79bfd8205b",id:null,metadata:{},name:"NewPromptLabelDialogMutation",operationKind:"mutation",text:`mutation NewPromptLabelDialogMutation(
  $label: CreatePromptLabelInput!
) {
  createPromptLabel(input: $label) {
    promptLabels {
      id
      name
      color
    }
  }
}
`}}})();yo.hash="ddbd14ff91d53dfbceede5ee349cb9ab";const I4=g.forwardRef((n,a)=>e(qs,{...n,ref:a}));I4.displayName="ColorField";const z4=p`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: var(--ac-global-dimension-size-100);
  flex-wrap: wrap;

  .react-aria-ColorSwatchPickerItem {
    position: relative;
    outline: none;
    width: fit-content;
    height: fit-content;
    forced-color-adjust: none;
    display: inline-flex;

    &[data-focus-visible] {
      outline: 2px solid var(--focus-ring-color);
      outline-offset: 2px;
    }

    &[data-selected]::after {
      content: "";
      position: absolute;
      inset: 0;
      border: 2px solid var(--ac-global-text-color-900);
      outline-offset: -4px;
      border-radius: inherit;
    }
  }
`,kl=g.forwardRef((n,a)=>e(Xs,{css:z4,...n,ref:a}));kl.displayName="ColorSwatchPicker";function Ll({onSubmit:n,isSubmitting:a}){"use no memo";const{control:t,handleSubmit:l,watch:i,formState:{isDirty:r}}=Oe({defaultValues:{name:"",description:"",color:"#33c5e8"}});return s(an,{onSubmit:l(n),children:[s(w,{padding:"size-200",children:[e(w,{paddingY:"size-300",children:e(S,{direction:"row",alignItems:"center",justifyContent:"center",width:"100%",children:e(Se,{color:i("color"),children:i("name")||"label preview"})})}),s(S,{direction:"column",gap:"size-200",children:[e(Z,{name:"name",control:t,rules:{required:"label name is required",minLength:{value:1,message:"label name must be at least 1 character long"},maxLength:{value:30,message:"label name must be less than 30 characters long"}},render:({field:{onChange:o,onBlur:c,value:d},fieldState:{invalid:u,error:m}})=>s(ee,{isInvalid:u,onChange:o,onBlur:c,value:d.toString(),children:[e(P,{children:"Label Name"}),e(W,{placeholder:"e.g., classifier"}),(m==null?void 0:m.message)&&e(ae,{children:m.message})]})}),e(Z,{name:"description",control:t,render:({field:{onChange:o,onBlur:c,value:d},fieldState:{invalid:u,error:m}})=>s(ee,{isInvalid:u,onChange:o,onBlur:c,value:d.toString(),children:[e(P,{children:"Description"}),e(oa,{placeholder:"A short description"}),(m==null?void 0:m.message)&&e(ae,{children:m.message})]})}),e(Z,{name:"color",control:t,render:({field:{onChange:o,value:c}})=>s("div",{css:Te,children:[e(P,{children:"Color"}),s(kl,{value:c,onChange:d=>o(d.toString()),children:[e(te,{color:"#ff9b88",children:e(U,{size:"L"})}),e(te,{color:"#ffa037",children:e(U,{size:"L"})}),e(te,{color:"#d7b300",children:e(U,{size:"L"})}),e(te,{color:"#98c50a",children:e(U,{size:"L"})}),e(te,{color:"#4ecf50",children:e(U,{size:"L"})}),e(te,{color:"#49cc93",children:e(U,{size:"L"})}),e(te,{color:"#33c5e8",children:e(U,{size:"L"})}),e(te,{color:"#78bbfa",children:e(U,{size:"L"})}),e(te,{color:"#acafff",children:e(U,{size:"L"})}),e(te,{color:"#cca4fd",children:e(U,{size:"L"})}),e(te,{color:"#f592f3",children:e(U,{size:"L"})}),e(te,{color:"#ff95bd",children:e(U,{size:"L"})})]})]})})]})]}),e(w,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-200",children:e(S,{direction:"row",justifyContent:"end",children:e(D,{isDisabled:a,variant:r?"primary":"default",size:"M",type:"submit",children:"Create Label"})})})]})}function A4(n){const[a,t]=g.useState(""),{onCompleted:l}=n,[i,r]=F.useMutation(yo);return e(me,{children:s(Ve,{children:[s(Pe,{children:[e(Re,{children:"New Prompt Label"}),e(Ue,{})]}),a?e(On,{banner:!0,variant:"danger",children:a}):null,e(Ll,{onSubmit:c=>{const d=[F.ConnectionHandler.getConnectionID("client:root","PromptLabelConfigButtonAllLabels_promptLabels"),F.ConnectionHandler.getConnectionID("client:root","PromptLabelsTable__promptLabels")];i({variables:{label:c,connections:d},onCompleted:l,onError:u=>{const m=yn(u);t((m==null?void 0:m[0])??u.message)}})},isSubmitting:r})]})})}const M4={lineNumbers:!0,highlightActiveLine:!1,foldGutter:!1,highlightActiveLineGutter:!1,bracketMatching:!1,defaultKeymap:!1},F4=[Zt.lineWrapping,Yi.of([...Ji.filter(n=>n.key!=="Mod-Enter")])],yh=({templateFormat:n,defaultValue:a,readOnly:t,...l})=>{const[i,r]=g.useState(()=>a),{theme:o}=de(),c=o==="light"?sa:ca,d=g.useMemo(()=>{const u=[...F4];switch(n){case Je.FString:u.push(Rd());break;case Je.Mustache:u.push(Bd());break;case Je.NONE:break;default:N()}return u},[n]);return g.useEffect(()=>{t&&r(a)},[t,a]),e(da,{theme:c,extensions:d,basicSetup:M4,readOnly:t,...l,value:i})},vh=({readOnly:n,children:a})=>e("div",{css:p`
        & .cm-editor,
        & .cm-gutters {
          background-color: ${n?"transparent !important":"auto"};
        }
        & .cm-gutters {
          border-right: none !important;
        }
        & .cm-content {
          padding: var(--ac-global-dimension-size-100)
            var(--ac-global-dimension-size-250);
        }
        & .cm-gutter,
        & .cm-content {
          min-height: ${n?"100%":"75px"};
        }
        & .cm-line {
          padding-left: 0;
          padding-right: 0;
        }
        & .cm-cursor {
          display: ${n?"none !important":"auto"};
        }
      `,children:a});function Ch(n,a){const t=g.useRef(null);g.useEffect(()=>{t.current=n},[n]),g.useEffect(()=>{function l(){t.current&&t.current()}{const i=setInterval(l,a);return()=>clearInterval(i)}},[a])}function kh(){const{locale:n}=Ai();return g.useMemo(()=>xu(n),[n])}const Lh=n=>{const[a,t]=g.useState(null);return g.useEffect(()=>{if(!n.current)return;const l=new ResizeObserver(i=>{if(!i||i.length===0)return;const{width:r,height:o}=i[0].contentRect;t({width:r,height:o})});return l.observe(n.current),()=>{l.disconnect()}},[n]),a};function Sh(n={}){const{updateIntervalMs:a=null}=n,[t,l]=g.useState(()=>Date.now());return g.useEffect(()=>{if(typeof a!="number")return;const i=setInterval(()=>{l(Date.now())},a);return()=>clearInterval(i)},[a]),{nowEpochMs:t}}function D4({blocker:n}){return e(w,{padding:"size-100",borderTopColor:"dark",borderTopWidth:"thin",children:s(S,{justifyContent:"end",gap:"size-100",children:[e(D,{onPress:()=>n.reset&&n.reset(),size:"S",children:"Cancel"}),e(D,{variant:"primary",onPress:()=>n.proceed&&n.proceed(),size:"S",children:"Confirm"})]})})}function wh({blocker:n,message:a="Are you sure you want to leave the page? Some changes may not be saved."}){return e(pn,{isDismissable:!1,isOpen:n.state==="blocked",children:e(gn,{size:"S",children:e(me,{children:s(Ve,{children:[s(Pe,{children:[e(Re,{children:"Confirm Navigation"}),e(hn,{children:e(Ue,{close:()=>{var t;return(t=n.reset)==null?void 0:t.call(n)}})})]}),e(w,{padding:"size-200",children:e(C,{children:a})}),e(D4,{blocker:n})]})})})})}const E4=p`
  transition: 250ms linear all;
  background-color: var(--ac-global-color-grey-200);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1.8px;
  --px-resize-handle-size: 8px;
  --px-resize-icon-width: 24px;
  --px-resize-icon-height: 2px;
  outline: none;
  &[data-panel-group-direction="vertical"] {
    height: var(--px-resize-handle-size);
    flex-direction: column;
    &:before,
    &:after {
      width: var(--px-resize-icon-width);
      height: var(--px-resize-icon-height);
    }
  }
  &[data-panel-group-direction="horizontal"] {
    width: var(--px-resize-handle-size);
    flex-direction: row;
    &:before,
    &:after {
      width: var(--px-resize-icon-height);
      height: var(--px-resize-icon-width);
    }
  }

  &:hover {
    background-color: var(--ac-global-color-grey-300);
    border-radius: 4px;
    &:before,
    &:after {
      background-color: var(--ac-global-color-primary);
    }
  }

  &:before,
  &:after {
    content: "";
    color: var(--color-solid-resize-bar);
    flex: 0 0 1rem;
    border-radius: 6px;
    background-color: var(--ac-global-color-grey-300);
    flex: none;
  }
`,vo=p`
  transition: 250ms linear all;
  background-color: var(--ac-global-color-grey-200);
  --px-resize-handle-size: 4px;
  outline: none;
  &[data-panel-group-direction="vertical"] {
    height: var(--px-resize-handle-size);
  }
  &[data-panel-group-direction="horizontal"] {
    width: var(--px-resize-handle-size);
  }

  &:hover {
    background-color: var(--ac-global-color-primary);
  }
`;function xh({onSubmit:n,isSubmitting:a}){"use no memo";const{control:t,handleSubmit:l,watch:i,formState:{isDirty:r}}=Oe({defaultValues:{name:"",description:"",color:"#33c5e8"},mode:"onChange"});return s(an,{onSubmit:l(n),children:[s(w,{padding:"size-200",children:[e(w,{paddingY:"size-300",children:e(S,{direction:"row",alignItems:"center",justifyContent:"center",width:"100%",children:e(Se,{color:i("color"),children:i("name")||"split preview"})})}),e(Z,{name:"name",control:t,rules:{required:"split name is required",minLength:{value:1,message:"split name must be at least 1 character long"},maxLength:{value:30,message:"split name must be less than 30 characters long"}},render:({field:{onChange:o,onBlur:c,value:d},fieldState:{invalid:u,error:m}})=>s(ee,{isInvalid:u,onChange:o,onBlur:c,value:d.toString(),children:[e(P,{children:"Split Name"}),e(W,{placeholder:"e.g. test"}),(m==null?void 0:m.message)&&e(ae,{children:m.message})]})}),e(Z,{name:"description",control:t,render:({field:{onChange:o,onBlur:c,value:d},fieldState:{invalid:u,error:m}})=>s(ee,{isInvalid:u,onChange:o,onBlur:c,value:d.toString(),children:[e(P,{children:"Description"}),e(oa,{placeholder:"e.g. a test split"}),(m==null?void 0:m.message)&&e(ae,{children:m.message})]})}),e(Z,{name:"color",control:t,render:({field:{onChange:o,value:c}})=>s("div",{css:Te,children:[e(P,{children:"Color"}),s(kl,{value:c,onChange:d=>o(d.toString()),children:[e(te,{color:"#ff9b88",children:e(U,{size:"L"})}),e(te,{color:"#ffa037",children:e(U,{size:"L"})}),e(te,{color:"#d7b300",children:e(U,{size:"L"})}),e(te,{color:"#98c50a",children:e(U,{size:"L"})}),e(te,{color:"#4ecf50",children:e(U,{size:"L"})}),e(te,{color:"#49cc93",children:e(U,{size:"L"})}),e(te,{color:"#33c5e8",children:e(U,{size:"L"})}),e(te,{color:"#78bbfa",children:e(U,{size:"L"})}),e(te,{color:"#acafff",children:e(U,{size:"L"})}),e(te,{color:"#cca4fd",children:e(U,{size:"L"})}),e(te,{color:"#f592f3",children:e(U,{size:"L"})}),e(te,{color:"#ff95bd",children:e(U,{size:"L"})})]})]})})]}),e(w,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-200",children:e(S,{direction:"row",justifyContent:"end",children:e(D,{isDisabled:a,variant:r?"primary":"default",size:"M",type:"submit",children:"Create Split"})})})]})}const Co=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"connections"},a={defaultValue:null,kind:"LocalArgument",name:"input"},t=[{kind:"Variable",name:"input",variableName:"input"}],l={alias:null,args:null,concreteType:"DatasetSplit",kind:"LinkedField",name:"datasetSplit",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"useDatasetSplitMutationsCreateSplitMutation",selections:[{alias:null,args:t,concreteType:"DatasetSplitMutationPayload",kind:"LinkedField",name:"createDatasetSplit",plural:!1,selections:[l],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"useDatasetSplitMutationsCreateSplitMutation",selections:[{alias:null,args:t,concreteType:"DatasetSplitMutationPayload",kind:"LinkedField",name:"createDatasetSplit",plural:!1,selections:[l,{alias:null,args:null,filters:null,handle:"prependNode",key:"",kind:"LinkedHandle",name:"datasetSplit",handleArgs:[{kind:"Variable",name:"connections",variableName:"connections"},{kind:"Literal",name:"edgeTypeName",value:"DatasetSplitEdge"}]}],storageKey:null}]},params:{cacheID:"614b8f50f0634f0646415cdf91f55159",id:null,metadata:{},name:"useDatasetSplitMutationsCreateSplitMutation",operationKind:"mutation",text:`mutation useDatasetSplitMutationsCreateSplitMutation(
  $input: CreateDatasetSplitInput!
) {
  createDatasetSplit(input: $input) {
    datasetSplit {
      id
      name
    }
  }
}
`}}})();Co.hash="41e5c0b6cd08b3a04564ba121785a0e3";const ko=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"connections"},a={defaultValue:null,kind:"LocalArgument",name:"input"},t=[{kind:"Variable",name:"input",variableName:"input"}],l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},r={alias:null,args:null,concreteType:"DatasetSplit",kind:"LinkedField",name:"datasetSplit",plural:!1,selections:[l,i],storageKey:null},o={alias:null,args:null,concreteType:"DatasetExample",kind:"LinkedField",name:"examples",plural:!0,selections:[l,{alias:null,args:null,concreteType:"DatasetSplit",kind:"LinkedField",name:"datasetSplits",plural:!0,selections:[l,i,{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null}],storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"useDatasetSplitMutationsCreateSplitWithExamplesMutation",selections:[{alias:null,args:t,concreteType:"DatasetSplitMutationPayloadWithExamples",kind:"LinkedField",name:"createDatasetSplitWithExamples",plural:!1,selections:[r,o],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"useDatasetSplitMutationsCreateSplitWithExamplesMutation",selections:[{alias:null,args:t,concreteType:"DatasetSplitMutationPayloadWithExamples",kind:"LinkedField",name:"createDatasetSplitWithExamples",plural:!1,selections:[r,{alias:null,args:null,filters:null,handle:"prependNode",key:"",kind:"LinkedHandle",name:"datasetSplit",handleArgs:[{kind:"Variable",name:"connections",variableName:"connections"},{kind:"Literal",name:"edgeTypeName",value:"DatasetSplitEdge"}]},o],storageKey:null}]},params:{cacheID:"c8665c4dd2f7851812b54ed8dbcd0a38",id:null,metadata:{},name:"useDatasetSplitMutationsCreateSplitWithExamplesMutation",operationKind:"mutation",text:`mutation useDatasetSplitMutationsCreateSplitWithExamplesMutation(
  $input: CreateDatasetSplitWithExamplesInput!
) {
  createDatasetSplitWithExamples(input: $input) {
    datasetSplit {
      id
      name
    }
    examples {
      id
      datasetSplits {
        id
        name
        color
      }
    }
  }
}
`}}})();ko.hash="236b3fe8835732cd2ace26b5b29df384";const Th=({onCompleted:n,exampleIds:a})=>{const t=_a(),l=Va(),[i,r]=F.useMutation(ko),[o,c]=F.useMutation(Co);return{onSubmit:g.useCallback(u=>{const m=u.name.trim(),h=[F.ConnectionHandler.getConnectionID("client:root","ManageDatasetSplitsDialog_datasetSplits")];m&&(a?i({variables:{connections:h,input:{name:m,description:u.description||null,color:u.color,metadata:null,exampleIds:a}},onCompleted:()=>{n==null||n()},onError:b=>{const f=yn(b);l({title:"Failed to create split",message:(f==null?void 0:f[0])??b.message})}}):o({variables:{connections:h,input:{name:m,description:u.description||null,color:u.color,metadata:null}},onCompleted:()=>{t({title:"Split created",message:`Created split "${m}"`}),n==null||n()},onError:b=>{const f=yn(b);l({title:"Failed to create split",message:(f==null?void 0:f[0])??b.message})}}))},[i,o,a,n,l,t]),isCreatingDatasetSplit:r||c}};function Sl({latencyMs:n,size:a="M",showIcon:t=!0,latencyThresholds:l}){const i=g.useMemo(()=>l&&n!==null?n<l.fast?"success":n<l.moderate?"warning":"danger":"text-900",[n,l]),r=g.useMemo(()=>w5(n),[n]);return s(S,{direction:"row",alignItems:"center",justifyContent:"start",gap:"size-50",className:"latency-text",children:[t?e(C,{color:i,size:a,children:e(x,{svg:e(s2,{}),css:p`
              font-size: 1.1em;
            `})}):null,e(C,{color:i,size:a,fontFamily:"mono",children:r})]})}const K4=p`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  gap: var(--ac-global-dimension-size-50);
`;function Ih({labels:n}){return!n||n.length===0?e(B,{}):e("ul",{css:K4,children:n.map(t=>e("li",{children:e(Se,{size:"M",color:t.color??void 0,children:e(ye,{maxWidth:200,title:t.name,children:t.name})})},`${t.name}-${t.color??"none"}`))})}function _4(n){const a=65+n;return String.fromCharCode(a)}function zh({index:n}){const a=g.useMemo(()=>_4(n),[n]),t=g.useMemo(()=>Ys[n%8],[n]),l=g.useMemo(()=>Ht(.8,t),[t]);return e("div",{css:p`
        color: ${t};
        background-color: ${l};
        width: 24px;
        height: 24px;
        min-width: 24px;
        min-height: 24px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        border-radius: var(--ac-global-rounding-small);
      `,children:a})}function Lo({spanKind:n}){const{theme:a}=de(),t=a==="dark";let l=t?"--ac-global-color-grey-600":"--ac-global-color-grey-200";switch(n){case"llm":l=t?"--ac-global-color-orange-1000":"--ac-global-color-orange-500";break;case"chain":l=t?"--ac-global-color-blue-1000":"--ac-global-color-blue-500";break;case"retriever":l=t?"--ac-global-color-seafoam-1000":"--ac-global-color-seafoam-500";break;case"embedding":l=t?"--ac-global-color-indigo-1000":"--ac-global-color-indigo-500";break;case"agent":l=t?"--ac-global-color-grey-600":"--ac-global-color-grey-300";break;case"tool":l=t?"--ac-global-color-yellow-1200":"--ac-global-color-yellow-500";break;case"reranker":l=t?"--ac-global-color-celery-1000":"--ac-global-color-celery-500";break;case"evaluator":l=t?"--ac-global-color-indigo-1000":"--ac-global-color-indigo-500";break;case"guardrail":l=t?"--ac-global-color-fuchsia-1200":"--ac-global-color-fuchsia-500";break}return`var(${l})`}const V4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("mask",{id:"path-2-inside-1_33_16916",fill:"currentColor",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M13 8C13 8.64491 12.8779 9.2613 12.6556 9.82732L17.1924 14.3641L14.364 17.1926L9.82706 12.6557C9.26111 12.8779 8.64481 13 8 13C5.23858 13 3 10.7614 3 8C3 7.13361 3.22036 6.31869 3.60809 5.60822L6 8L7.5 7.50016L8 6.00016L5.60803 3.60819C6.31854 3.2204 7.13353 3 8 3C10.7614 3 13 5.23858 13 8Z"})}),e("path",{d:"M12.6556 9.82732L11.7248 9.46171L11.4853 10.0713L11.9485 10.5344L12.6556 9.82732ZM17.1924 14.3641L17.8995 15.0713L18.6066 14.3641L17.8995 13.657L17.1924 14.3641ZM14.364 17.1926L13.6569 17.8997L14.364 18.6068L15.0711 17.8997L14.364 17.1926ZM9.82706 12.6557L10.5342 11.9486L10.0711 11.4855L9.4615 11.7249L9.82706 12.6557ZM3.60809 5.60822L4.31518 4.90109L3.37037 3.95634L2.7303 5.12917L3.60809 5.60822ZM6 8L5.29291 8.70713L5.72988 9.14407L6.31613 8.94871L6 8ZM7.5 7.50016L7.81614 8.44888L8.29055 8.29079L8.44869 7.81639L7.5 7.50016ZM8 6.00016L8.94869 6.31639L9.14413 5.73007L8.70711 5.29306L8 6.00016ZM5.60803 3.60819L5.12895 2.73042L3.95616 3.37053L4.90093 4.3153L5.60803 3.60819ZM13.5863 10.1929C13.8537 9.51235 14 8.77206 14 8H12C12 8.51776 11.9021 9.01026 11.7248 9.46171L13.5863 10.1929ZM17.8995 13.657L13.3627 9.12022L11.9485 10.5344L16.4853 15.0713L17.8995 13.657ZM15.0711 17.8997L17.8995 15.0713L16.4853 13.657L13.6569 16.4855L15.0711 17.8997ZM9.11995 13.3628L13.6569 17.8997L15.0711 16.4855L10.5342 11.9486L9.11995 13.3628ZM8 14C8.77194 14 9.51211 13.8537 10.1926 13.5865L9.4615 11.7249C9.0101 11.9022 8.51768 12 8 12V14ZM2 8C2 11.3137 4.68629 14 8 14V12C5.79086 12 4 10.2091 4 8H2ZM2.7303 5.12917C2.2644 5.98288 2 6.96206 2 8H4C4 7.30516 4.17633 6.65449 4.48588 6.08727L2.7303 5.12917ZM6.70709 7.29287L4.31518 4.90109L2.901 6.31535L5.29291 8.70713L6.70709 7.29287ZM7.18387 6.55145L5.68387 7.05129L6.31613 8.94871L7.81614 8.44888L7.18387 6.55145ZM7.05132 5.68394L6.55132 7.18394L8.44869 7.81639L8.94869 6.31639L7.05132 5.68394ZM4.90093 4.3153L7.2929 6.70727L8.70711 5.29306L6.31514 2.90109L4.90093 4.3153ZM8 2C6.96197 2 5.98271 2.26444 5.12895 2.73042L6.08712 4.48596C6.65437 4.17636 7.3051 4 8 4V2ZM14 8C14 4.68629 11.3137 2 8 2V4C10.2091 4 12 5.79086 12 8H14Z",fill:"currentColor",fillOpacity:"0.9",mask:"url(#path-2-inside-1_33_16916)"})]}),P4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("mask",{id:"path-2-inside-1_2321_643",fill:"white",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M13 8C13 8.64491 12.8779 9.2613 12.6556 9.82732L17.1924 14.3641L14.364 17.1926L9.82706 12.6557C9.26111 12.8779 8.64481 13 8 13C5.23858 13 3 10.7614 3 8C3 7.13361 3.22036 6.31869 3.60809 5.60822L6 8L7.5 7.50016L8 6.00016L5.60803 3.60819C6.31854 3.2204 7.13353 3 8 3C10.7614 3 13 5.23858 13 8Z"})}),e("path",{d:"M12.6556 9.82732L11.7248 9.46171L11.4853 10.0713L11.9485 10.5344L12.6556 9.82732ZM17.1924 14.3641L17.8995 15.0713L18.6066 14.3641L17.8995 13.657L17.1924 14.3641ZM14.364 17.1926L13.6569 17.8997L14.364 18.6068L15.0711 17.8997L14.364 17.1926ZM9.82706 12.6557L10.5342 11.9486L10.0711 11.4855L9.4615 11.7249L9.82706 12.6557ZM3.60809 5.60822L4.31518 4.90109L3.37037 3.95634L2.7303 5.12917L3.60809 5.60822ZM6 8L5.29291 8.70713L5.72988 9.14407L6.31613 8.94871L6 8ZM7.5 7.50016L7.81614 8.44888L8.29055 8.29079L8.44869 7.81639L7.5 7.50016ZM8 6.00016L8.94869 6.31639L9.14413 5.73007L8.70711 5.29306L8 6.00016ZM5.60803 3.60819L5.12895 2.73042L3.95616 3.37053L4.90093 4.3153L5.60803 3.60819ZM13.5863 10.1929C13.8537 9.51235 14 8.77206 14 8H12C12 8.51776 11.9021 9.01026 11.7248 9.46171L13.5863 10.1929ZM17.8995 13.657L13.3627 9.12022L11.9485 10.5344L16.4853 15.0713L17.8995 13.657ZM15.0711 17.8997L17.8995 15.0713L16.4853 13.657L13.6569 16.4855L15.0711 17.8997ZM9.11995 13.3628L13.6569 17.8997L15.0711 16.4855L10.5342 11.9486L9.11995 13.3628ZM8 14C8.77194 14 9.51211 13.8537 10.1926 13.5865L9.4615 11.7249C9.0101 11.9022 8.51768 12 8 12V14ZM2 8C2 11.3137 4.68629 14 8 14V12C5.79086 12 4 10.2091 4 8H2ZM2.7303 5.12917C2.2644 5.98288 2 6.96206 2 8H4C4 7.30516 4.17633 6.65449 4.48588 6.08727L2.7303 5.12917ZM6.70709 7.29287L4.31518 4.90109L2.901 6.31535L5.29291 8.70713L6.70709 7.29287ZM7.18387 6.55145L5.68387 7.05129L6.31613 8.94871L7.81614 8.44888L7.18387 6.55145ZM7.05132 5.68394L6.55132 7.18394L8.44869 7.81639L8.94869 6.31639L7.05132 5.68394ZM4.90093 4.3153L7.2929 6.70727L8.70711 5.29306L6.31514 2.90109L4.90093 4.3153ZM8 2C6.96197 2 5.98271 2.26444 5.12895 2.73042L6.08712 4.48596C6.65437 4.17636 7.3051 4 8 4V2ZM14 8C14 4.68629 11.3137 2 8 2V4C10.2091 4 12 5.79086 12 8H14Z",fill:"black",mask:"url(#path-2-inside-1_2321_643)"})]}),R4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{d:"M4.43782 6.78868L10 3.57735L15.5622 6.78868V13.2113L10 16.4226L4.43782 13.2113V6.78868Z",stroke:"currentColor",strokeOpacity:"0.9"})]}),N4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M4.43782 6.78868L10 3.57735L15.5622 6.78868V13.2113L10 16.4226L4.43782 13.2113V6.78868Z",stroke:"black"})]}),O4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{d:"M5 16C5 16 5 11 10 11C15 11 15 16 15 16",stroke:"currentColor",strokeOpacity:"0.9"}),e("rect",{x:"6.5",y:"4.5",width:"7",height:"5",rx:"0.5",stroke:"currentColor",strokeOpacity:"0.9"})]}),$4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{width:"20",height:"20",rx:"4",fill:"currentColor"}),e("path",{d:"M10 11C5 11 5 16 5 16H15C15 16 15 11 10 11Z",stroke:"black"}),e("rect",{x:"6.5",y:"4.5",width:"7",height:"5",rx:"0.5",stroke:"black"})]}),B4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 6C10 7.10457 9.10457 8 8 8C6.89543 8 6 7.10457 6 6C6 4.89543 6.89543 4 8 4C9.10457 4 10 4.89543 10 6ZM10.0558 8.18487C9.51887 8.6903 8.7956 9 8 9C7.91155 9 7.824 8.99617 7.7375 8.98867L7.10304 11.2093C8.21409 11.6488 9 12.7326 9 14C9 15.6569 7.65685 17 6 17C4.34315 17 3 15.6569 3 14C3 12.3431 4.34315 11 6 11C6.0409 11 6.08161 11.0008 6.12212 11.0024L6.76944 8.73682C5.72625 8.26703 5 7.21833 5 6C5 4.34315 6.34315 3 8 3C9.65685 3 11 4.34315 11 6C11 6.50075 10.8773 6.97285 10.6604 7.38788L12.1873 8.6094C12.6908 8.22697 13.3189 8 14 8C15.6569 8 17 9.34315 17 11C17 12.6569 15.6569 14 14 14C12.3431 14 11 12.6569 11 11C11 10.3864 11.1842 9.81579 11.5004 9.34053L10.0558 8.18487ZM16 11C16 12.1046 15.1046 13 14 13C12.8954 13 12 12.1046 12 11C12 9.89543 12.8954 9 14 9C15.1046 9 16 9.89543 16 11ZM6 16C7.10457 16 8 15.1046 8 14C8 12.8954 7.10457 12 6 12C4.89543 12 4 12.8954 4 14C4 15.1046 4.89543 16 6 16Z",fill:"currentColor",fillOpacity:"0.9"})]}),H4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 6.00003C10 7.1046 9.10457 8.00003 8 8.00003C6.89543 8.00003 6 7.1046 6 6.00003C6 4.89546 6.89543 4.00003 8 4.00003C9.10457 4.00003 10 4.89546 10 6.00003ZM10.0558 8.1849C9.51887 8.69033 8.7956 9.00003 8 9.00003C7.91155 9.00003 7.824 8.9962 7.7375 8.9887L7.10304 11.2093C8.21409 11.6488 9 12.7326 9 14C9 15.6569 7.65685 17 6 17C4.34315 17 3 15.6569 3 14C3 12.3432 4.34315 11 6 11C6.0409 11 6.08161 11.0008 6.12212 11.0025L6.76944 8.73685C5.72625 8.26706 5 7.21836 5 6.00003C5 4.34318 6.34315 3.00003 8 3.00003C9.65685 3.00003 11 4.34318 11 6.00003C11 6.50078 10.8773 6.97288 10.6604 7.38791L12.1873 8.60943C12.6908 8.227 13.3189 8.00003 14 8.00003C15.6569 8.00003 17 9.34318 17 11C17 12.6569 15.6569 14 14 14C12.3431 14 11 12.6569 11 11C11 10.3864 11.1842 9.81582 11.5004 9.34056L10.0558 8.1849ZM16 11C16 12.1046 15.1046 13 14 13C12.8954 13 12 12.1046 12 11C12 9.89546 12.8954 9.00003 14 9.00003C15.1046 9.00003 16 9.89546 16 11ZM6 16C7.10457 16 8 15.1046 8 14C8 12.8955 7.10457 12 6 12C4.89543 12 4 12.8955 4 14C4 15.1046 4.89543 16 6 16Z",fill:"black"})]}),j4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{d:"M14.65 6.5C14.65 6.98637 14.2466 7.52091 13.379 7.95472C12.5323 8.37806 11.3382 8.65 10 8.65C8.66184 8.65 7.46767 8.37806 6.62099 7.95472C5.75338 7.52091 5.35 6.98637 5.35 6.5C5.35 6.01363 5.75338 5.47909 6.62099 5.04528C7.46767 4.62194 8.66184 4.35 10 4.35C11.3382 4.35 12.5323 4.62194 13.379 5.04528C14.2466 5.47909 14.65 6.01363 14.65 6.5Z",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"}),e("path",{d:"M14.6875 6.83482V9.62479C14.6875 9.62479 13.0769 11.1873 10 11.1873C6.92308 11.1873 5.3125 9.62479 5.3125 9.62479V6.7437",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"}),e("path",{d:"M14.6875 9.625V12.125C14.6875 12.125 13.0769 13.6875 10 13.6875C6.92308 13.6875 5.3125 12.125 5.3125 12.125V9.625",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"}),e("path",{d:"M14.6875 12.125V14.625C14.6875 14.625 13.0769 16.1875 10 16.1875C6.92308 16.1875 5.3125 14.625 5.3125 14.625V12.125",stroke:"currentColor",strokeOpacity:"0.9",strokeWidth:"0.7"})]}),Z4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M14.65 6.5C14.65 6.98637 14.2466 7.52091 13.379 7.95472C12.5323 8.37806 11.3382 8.65 10 8.65C8.66184 8.65 7.46767 8.37806 6.62099 7.95472C5.75338 7.52091 5.35 6.98637 5.35 6.5C5.35 6.01363 5.75338 5.47909 6.62099 5.04528C7.46767 4.62194 8.66184 4.35 10 4.35C11.3382 4.35 12.5323 4.62194 13.379 5.04528C14.2466 5.47909 14.65 6.01363 14.65 6.5Z",stroke:"black",strokeWidth:"0.7"}),e("path",{d:"M14.6875 6.83504V9.625C14.6875 9.625 13.0769 11.1875 10 11.1875C6.92308 11.1875 5.3125 9.625 5.3125 9.625V6.74392",stroke:"black",strokeWidth:"0.7"}),e("path",{d:"M14.6875 9.625V12.125C14.6875 12.125 13.0769 13.6875 10 13.6875C6.92308 13.6875 5.3125 12.125 5.3125 12.125V9.625",stroke:"black",strokeWidth:"0.7"}),e("path",{d:"M14.6875 12.125V14.625C14.6875 14.625 13.0769 16.1875 10 16.1875C6.92308 16.1875 5.3125 14.625 5.3125 14.625V12.125",stroke:"black",strokeWidth:"0.7"})]}),U4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor"}),e("path",{d:"M4.5359 10L8 4L11.4641 10H4.5359Z",stroke:"currentColor"}),e("path",{d:"M8.5359 10L12 16L15.4641 10H8.5359Z",stroke:"currentColor"})]}),G4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M4.5359 10L8 4L11.4641 10H4.5359Z",stroke:"black"}),e("path",{d:"M8.5359 10L12 16L15.4641 10H8.5359Z",stroke:"black"})]}),W4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 15C12.7614 15 15 12.7614 15 10C15 7.23858 12.7614 5 10 5C7.23858 5 5 7.23858 5 10C5 12.7614 7.23858 15 10 15ZM10 16C13.3137 16 16 13.3137 16 10C16 6.68629 13.3137 4 10 4C6.68629 4 4 6.68629 4 10C4 13.3137 6.68629 16 10 16Z",fill:"currentColor",fillOpacity:"0.9"})]}),Q4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 15C12.7614 15 15 12.7614 15 10C15 7.23858 12.7614 5 10 5C7.23858 5 5 7.23858 5 10C5 12.7614 7.23858 15 10 15ZM10 16C13.3137 16 16 13.3137 16 10C16 6.68629 13.3137 4 10 4C6.68629 4 4 6.68629 4 10C4 13.3137 6.68629 16 10 16Z",fill:"black"})]}),q4=()=>e("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor",strokeOpacity:"0.9"})}),X4=()=>e("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"})}),Y4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor"}),e("path",{d:"M14.4254 5.58523L15.744 6.87427L15.7249 6.89333L15.7043 6.91394L15.6837 6.93453L15.6631 6.95509L15.6425 6.97562L15.622 6.99612L15.6015 7.01659L15.581 7.03703L15.5606 7.05745L15.5402 7.07783L15.5198 7.09819L15.4995 7.11852L15.4791 7.13882L15.4588 7.15909L15.4386 7.17934L15.4183 7.19956L15.3981 7.21974L15.3779 7.23991L15.3578 7.26004L15.3377 7.28015L15.3176 7.30022L15.2975 7.32028L15.2774 7.3403L15.2574 7.3603L15.2374 7.38027L15.2175 7.40021L15.1975 7.42013L15.1776 7.44002L15.1577 7.45988L15.1379 7.47972L15.118 7.49953L15.0982 7.51931L15.0784 7.53907L15.0587 7.5588L15.0389 7.57851L15.0192 7.59819L14.9996 7.61785L14.9799 7.63748L14.9603 7.65708L14.9407 7.67666L14.9211 7.69621L14.9016 7.71574L14.882 7.73524L14.8625 7.75472L14.8431 7.77417L14.8236 7.7936L14.8042 7.81301L14.7848 7.83239L14.7654 7.85174L14.746 7.87107L14.7267 7.89038L14.7074 7.90966L14.6881 7.92892L14.6689 7.94815L14.6496 7.96736L14.6304 7.98655L14.6113 8.00571L14.5921 8.02485L14.573 8.04397L14.5538 8.06306L14.5347 8.08213L14.5157 8.10118L14.4966 8.1202L14.4776 8.1392L14.4586 8.15818L14.4396 8.17714L14.4207 8.19607L14.4017 8.21498L14.3828 8.23387L14.3639 8.25274L14.3451 8.27158L14.3262 8.2904L14.3074 8.3092L14.2886 8.32798L14.2698 8.34674L14.2511 8.36547L14.2323 8.38418L14.2136 8.40288L14.1949 8.42155L14.1763 8.4402L14.1576 8.45883L14.139 8.47743L14.1204 8.49602L14.1018 8.51459L14.0832 8.53313L14.0647 8.55166L14.0462 8.57016L14.0277 8.58864L14.0092 8.60711L13.9907 8.62555L13.9723 8.64397L13.9538 8.66238L13.9354 8.68076L13.917 8.69913L13.8987 8.71747L13.8803 8.73579L13.862 8.7541L13.8437 8.77239L13.8254 8.79065L13.8071 8.8089L13.7889 8.82713L13.7707 8.84534L13.7524 8.86353L13.7343 8.8817L13.7161 8.89986L13.6979 8.91799L13.6798 8.93611L13.6617 8.95421L13.6436 8.97229L13.6255 8.99036L13.6074 9.0084L13.5894 9.02643L13.5713 9.04444L13.5533 9.06243L13.5353 9.0804L13.5173 9.09836L13.4994 9.1163L13.4814 9.13422L13.4635 9.15213L13.4456 9.17002L13.4277 9.18789L13.4098 9.20574L13.392 9.22358L13.3741 9.2414L13.3563 9.25921L13.3385 9.277L13.3207 9.29477L13.3029 9.31253L13.2852 9.33027L13.2674 9.34799L13.2497 9.3657L13.232 9.38339L13.2143 9.40107L13.1966 9.41873L13.1789 9.43638L13.1613 9.45401L13.1436 9.47163L13.126 9.48923L13.1084 9.50681L13.0908 9.52438L13.0733 9.54194L13.0557 9.55948L13.0381 9.57701L13.0206 9.59452L13.0031 9.61202L12.9856 9.6295L12.9681 9.64697L12.9506 9.66443L12.9332 9.68187L12.9157 9.6993L12.8983 9.71671L12.8809 9.73412L12.8634 9.7515L12.8461 9.76888L12.8287 9.78624L12.8113 9.80358L12.794 9.82092L12.7766 9.83824L12.7593 9.85555L12.742 9.87284L12.7247 9.89013L12.7074 9.9074L12.6901 9.92466L12.6728 9.9419L12.6556 9.95913L12.6383 9.97636L12.6211 9.99356L12.6039 10.0108L12.5867 10.0279L12.5695 10.0451L12.5523 10.0623L12.5351 10.0794L12.518 10.0966L12.5008 10.1137L12.4837 10.1308L12.4666 10.1479L12.4495 10.165L12.4324 10.1821L12.4153 10.1992L12.3982 10.2162L12.3811 10.2333L12.364 10.2503L12.347 10.2674L12.33 10.2844L12.3129 10.3014L12.2959 10.3184L12.2789 10.3354L12.2619 10.3524L12.2449 10.3693L12.2279 10.3863L12.211 10.4032L12.194 10.4202L12.177 10.4371L12.1601 10.454L12.1432 10.471L12.1262 10.4879L12.1093 10.5048L12.0924 10.5216L12.0755 10.5385L12.0586 10.5554L12.0417 10.5723L12.0249 10.5891L12.008 10.606L11.9911 10.6228L11.9743 10.6396L11.9575 10.6565L11.9406 10.6733L11.9238 10.6901L11.907 10.7069L11.8902 10.7237L11.8734 10.7404L11.8566 10.7572L11.8398 10.774L11.823 10.7907L11.8062 10.8075L11.7895 10.8243L11.7727 10.841L11.7559 10.8577L11.7392 10.8745L11.7225 10.8912L11.7057 10.9079L11.689 10.9246L11.6723 10.9413L11.6556 10.958L11.6389 10.9747L11.6221 10.9914L11.6054 11.0081L11.5888 11.0247L11.5721 11.0414L11.5554 11.0581L11.5387 11.0747L11.522 11.0914L11.5054 11.108L11.4887 11.1247L11.4721 11.1413L11.4554 11.1579L11.4388 11.1746L11.4221 11.1912L11.4055 11.2078L11.3888 11.2244L11.3722 11.241L11.3556 11.2576L11.339 11.2742L11.3224 11.2908L11.3057 11.3074L11.2891 11.324L11.2725 11.3406L11.2559 11.3572L11.2393 11.3738L11.2227 11.3903L11.2061 11.4069L11.1895 11.4235L11.173 11.44L11.1564 11.4566L11.1398 11.4732L11.1232 11.4897L11.1066 11.5063L11.0901 11.5228L11.0735 11.5394L11.0569 11.5559L11.0404 11.5725L11.0238 11.589L11.0072 11.6056L10.9907 11.6221L10.9741 11.6386L10.9576 11.6552L10.941 11.6717L10.9245 11.6883L10.9079 11.7048L10.8914 11.7213L10.8748 11.7378L10.8583 11.7544L10.8417 11.7709L10.8252 11.7874L10.8086 11.804L10.7921 11.8205L10.7755 11.837L10.759 11.8535L10.7424 11.8701L10.7259 11.8866L10.7094 11.9031L10.6928 11.9196L10.6763 11.9362L10.6597 11.9527L10.6432 11.9692L10.6266 11.9857L10.6101 12.0023L10.5935 12.0188L10.577 12.0353L10.5604 12.0519L10.5439 12.0684L10.5273 12.0849L10.5108 12.1015L10.4942 12.118L10.4777 12.1345L10.4611 12.1511L10.4446 12.1676L10.428 12.1841L10.4114 12.2007L10.3949 12.2172L10.3783 12.2338L10.3618 12.2503L10.3452 12.2669L10.3286 12.2834L10.312 12.3L10.2955 12.3165L10.2789 12.3331L10.2623 12.3497L10.2457 12.3662L10.2291 12.3828L10.2125 12.3994L10.1959 12.4159L10.1793 12.4325L10.1627 12.4491L10.1461 12.4657L10.1295 12.4823L10.1129 12.4989L10.0963 12.5155L10.0797 12.5321L10.0631 12.5487L10.0464 12.5653L10.0298 12.5819L10.0132 12.5985L9.99652 12.6151L9.97987 12.6318L9.96322 12.6484L9.94657 12.665L9.92991 12.6817L9.91324 12.6983L9.89657 12.715L9.87989 12.7316L9.86321 12.7483L9.84653 12.7649L9.82984 12.7816L9.81314 12.7983L9.79644 12.815L9.77973 12.8317L9.76301 12.8484L9.74629 12.8651L9.72957 12.8818L9.71283 12.8985L9.69609 12.9152L9.67935 12.9319L9.6626 12.9487L9.64584 12.9654L9.62907 12.9822L9.6123 12.9989L9.59552 13.0157L9.57873 13.0324L9.56194 13.0492L9.54514 13.066L9.52833 13.0828L9.51151 13.0996L9.49469 13.1164L9.47786 13.1332L9.46102 13.15L9.44417 13.1668L9.42732 13.1837L9.41045 13.2005L9.39358 13.2174L9.3767 13.2342L9.35981 13.2511L9.34292 13.268L9.32601 13.2849L9.3091 13.3018L9.29217 13.3187L9.27524 13.3356L9.2583 13.3525L9.24135 13.3694L9.22439 13.3864L9.20742 13.4033L9.19044 13.4203L9.17345 13.4372L9.15645 13.4542L9.13945 13.4712L9.12243 13.4882L9.1054 13.5052L9.08836 13.5222L9.07131 13.5393L9.05426 13.5563L9.03719 13.5734L9.02011 13.5904L9.00302 13.6075L8.98592 13.6246L8.9688 13.6417L8.95168 13.6588L8.93455 13.6759L8.9174 13.693L8.90024 13.7101L8.88308 13.7273L8.8659 13.7444L8.84871 13.7616L8.8315 13.7788L8.81429 13.796L8.79706 13.8132L8.77983 13.8304L8.76257 13.8477L8.74531 13.8649L8.72804 13.8821L8.71075 13.8994L8.69345 13.9167L8.67614 13.934L8.65881 13.9513L8.64147 13.9686L8.62412 13.9859L8.60676 14.0033L8.58938 14.0206L8.57199 14.038L8.55458 14.0554L8.53716 14.0728L8.51973 14.0902L8.50229 14.1076L8.48483 14.1251L8.46736 14.1425L8.44987 14.16L8.43237 14.1775L8.41485 14.195L8.39732 14.2125L8.37978 14.23L8.36222 14.2475L8.34465 14.2651L8.32706 14.2827L8.30945 14.3002L8.29184 14.3178L8.2742 14.3355L8.25656 14.3531L8.23889 14.3707L8.22121 14.3884L8.20352 14.4061L8.18581 14.4238L8.16808 14.4415L8.15034 14.4592L8.13258 14.4769L8.11481 14.4947L8.09702 14.5124L8.07921 14.5302L8.06139 14.548L8.04355 14.5658L8.0257 14.5837L8.00783 14.6015L7.98994 14.6194L7.97203 14.6373L7.95411 14.6552L7.93617 14.6731L7.91821 14.691L7.90024 14.709L7.88225 14.727L7.86424 14.7449L7.84621 14.763L7.82817 14.781L7.81011 14.799L7.79203 14.8171L7.77393 14.8352L7.75581 14.8533L7.73768 14.8714L7.71952 14.8895L7.70135 14.9076L7.68316 14.9258L7.66495 14.944L7.64673 14.9622L7.62848 14.9804L7.61022 14.9987L7.59193 15.0169L7.57363 15.0352L7.55531 15.0535L7.53697 15.0718L7.5186 15.0902L7.50022 15.1085L7.48182 15.1269L7.4634 15.1453L7.44496 15.1637L7.4265 15.1822L7.40802 15.2006L7.38952 15.2191L7.371 15.2376L7.35246 15.2561L7.33389 15.2747L7.31531 15.2932L7.29671 15.3118L7.27808 15.3304L7.25944 15.3491L7.24077 15.3677L7.22208 15.3864L7.20337 15.4051L7.18464 15.4238L7.16589 15.4425L7.14712 15.4612L7.12832 15.48L7.10951 15.4988L7.09067 15.5176L7.07181 15.5365L7.05292 15.5553L7.03402 15.5742L7.01509 15.5931L6.99614 15.612C6.27167 16.3357 5.09652 16.3361 4.37259 15.613C3.64838 14.8896 3.64838 13.7168 4.37259 12.9935L13.1214 4.2547L14.4178 5.57764L14.4177 5.57772L14.4254 5.58523Z",stroke:"currentColor"}),e("path",{d:"M12.5299 10.2848L7.32791 15.5545C7.12956 15.7555 6.88934 15.9156 6.62689 16.0225C6.08679 16.2424 5.46752 16.2239 4.94171 15.972L4.77945 16.31L4.94171 15.972C4.6339 15.8246 4.36574 15.6007 4.16736 15.3245L4.02179 15.1219C3.60142 14.5367 3.60138 13.749 4.02169 13.1637C4.12291 13.0228 4.24539 12.8984 4.38476 12.7949L5.72374 11.8006L5.76816 11.7676L5.80115 11.7232L5.91056 11.576C6.30572 11.0443 6.96187 10.4244 7.58765 10.0864C7.90229 9.91646 8.17215 9.83813 8.37711 9.84461C8.55555 9.85025 8.69852 9.9179 8.81563 10.1071C8.88186 10.2141 8.92418 10.3701 8.97238 10.5823C8.97507 10.5942 8.9778 10.6063 8.98058 10.6186C9.00013 10.7052 9.02201 10.8022 9.04751 10.8896C9.07575 10.9865 9.11828 11.1086 9.19239 11.2146C9.29475 11.361 9.4504 11.4075 9.53763 11.4247C9.63768 11.4444 9.74477 11.4446 9.84616 11.436C10.0516 11.4187 10.299 11.3594 10.5607 11.2642C11.0498 11.0864 11.6345 10.7668 12.1516 10.2848L12.5299 10.2848Z",stroke:"currentColor",strokeWidth:"0.75"})]}),J4=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M14.4254 5.58523L15.744 6.87427L15.7249 6.89333L15.7043 6.91394L15.6837 6.93453L15.6631 6.95509L15.6425 6.97562L15.622 6.99612L15.6015 7.01659L15.581 7.03703L15.5606 7.05745L15.5402 7.07783L15.5198 7.09819L15.4995 7.11852L15.4791 7.13882L15.4588 7.15909L15.4386 7.17934L15.4183 7.19956L15.3981 7.21974L15.3779 7.23991L15.3578 7.26004L15.3377 7.28015L15.3176 7.30022L15.2975 7.32028L15.2774 7.3403L15.2574 7.3603L15.2374 7.38027L15.2175 7.40021L15.1975 7.42013L15.1776 7.44002L15.1577 7.45988L15.1379 7.47972L15.118 7.49953L15.0982 7.51931L15.0784 7.53907L15.0587 7.5588L15.0389 7.57851L15.0192 7.59819L14.9996 7.61785L14.9799 7.63748L14.9603 7.65708L14.9407 7.67666L14.9211 7.69621L14.9016 7.71574L14.882 7.73524L14.8625 7.75472L14.8431 7.77417L14.8236 7.7936L14.8042 7.81301L14.7848 7.83239L14.7654 7.85174L14.746 7.87107L14.7267 7.89038L14.7074 7.90966L14.6881 7.92892L14.6689 7.94815L14.6496 7.96736L14.6304 7.98655L14.6113 8.00571L14.5921 8.02485L14.573 8.04397L14.5538 8.06306L14.5347 8.08213L14.5157 8.10118L14.4966 8.1202L14.4776 8.1392L14.4586 8.15818L14.4396 8.17714L14.4207 8.19607L14.4017 8.21498L14.3828 8.23387L14.3639 8.25274L14.3451 8.27158L14.3262 8.2904L14.3074 8.3092L14.2886 8.32798L14.2698 8.34674L14.2511 8.36547L14.2323 8.38418L14.2136 8.40288L14.1949 8.42155L14.1763 8.4402L14.1576 8.45883L14.139 8.47743L14.1204 8.49602L14.1018 8.51459L14.0832 8.53313L14.0647 8.55166L14.0462 8.57016L14.0277 8.58864L14.0092 8.60711L13.9907 8.62555L13.9723 8.64397L13.9538 8.66238L13.9354 8.68076L13.917 8.69913L13.8987 8.71747L13.8803 8.73579L13.862 8.7541L13.8437 8.77239L13.8254 8.79065L13.8071 8.8089L13.7889 8.82713L13.7707 8.84534L13.7524 8.86353L13.7343 8.8817L13.7161 8.89986L13.6979 8.91799L13.6798 8.93611L13.6617 8.95421L13.6436 8.97229L13.6255 8.99036L13.6074 9.0084L13.5894 9.02643L13.5713 9.04444L13.5533 9.06243L13.5353 9.0804L13.5173 9.09836L13.4994 9.1163L13.4814 9.13422L13.4635 9.15213L13.4456 9.17002L13.4277 9.18789L13.4098 9.20574L13.392 9.22358L13.3741 9.2414L13.3563 9.25921L13.3385 9.277L13.3207 9.29477L13.3029 9.31253L13.2852 9.33027L13.2674 9.34799L13.2497 9.3657L13.232 9.38339L13.2143 9.40107L13.1966 9.41873L13.1789 9.43638L13.1613 9.45401L13.1436 9.47163L13.126 9.48923L13.1084 9.50681L13.0908 9.52438L13.0733 9.54194L13.0557 9.55948L13.0381 9.57701L13.0206 9.59452L13.0031 9.61202L12.9856 9.6295L12.9681 9.64697L12.9506 9.66443L12.9332 9.68187L12.9157 9.6993L12.8983 9.71671L12.8809 9.73412L12.8634 9.7515L12.8461 9.76888L12.8287 9.78624L12.8113 9.80358L12.794 9.82092L12.7766 9.83824L12.7593 9.85555L12.742 9.87284L12.7247 9.89013L12.7074 9.9074L12.6901 9.92466L12.6728 9.9419L12.6556 9.95913L12.6383 9.97636L12.6211 9.99356L12.6039 10.0108L12.5867 10.0279L12.5695 10.0451L12.5523 10.0623L12.5351 10.0794L12.518 10.0966L12.5008 10.1137L12.4837 10.1308L12.4666 10.1479L12.4495 10.165L12.4324 10.1821L12.4153 10.1992L12.3982 10.2162L12.3811 10.2333L12.364 10.2503L12.347 10.2674L12.33 10.2844L12.3129 10.3014L12.2959 10.3184L12.2789 10.3354L12.2619 10.3524L12.2449 10.3693L12.2279 10.3863L12.211 10.4032L12.194 10.4202L12.177 10.4371L12.1601 10.454L12.1432 10.471L12.1262 10.4879L12.1093 10.5048L12.0924 10.5216L12.0755 10.5385L12.0586 10.5554L12.0417 10.5723L12.0249 10.5891L12.008 10.606L11.9911 10.6228L11.9743 10.6396L11.9575 10.6565L11.9406 10.6733L11.9238 10.6901L11.907 10.7069L11.8902 10.7237L11.8734 10.7404L11.8566 10.7572L11.8398 10.774L11.823 10.7907L11.8062 10.8075L11.7895 10.8243L11.7727 10.841L11.7559 10.8577L11.7392 10.8745L11.7225 10.8912L11.7057 10.9079L11.689 10.9246L11.6723 10.9413L11.6556 10.958L11.6389 10.9747L11.6221 10.9914L11.6054 11.0081L11.5888 11.0247L11.5721 11.0414L11.5554 11.0581L11.5387 11.0747L11.522 11.0914L11.5054 11.108L11.4887 11.1247L11.4721 11.1413L11.4554 11.1579L11.4388 11.1746L11.4221 11.1912L11.4055 11.2078L11.3888 11.2244L11.3722 11.241L11.3556 11.2576L11.339 11.2742L11.3224 11.2908L11.3057 11.3074L11.2891 11.324L11.2725 11.3406L11.2559 11.3572L11.2393 11.3738L11.2227 11.3903L11.2061 11.4069L11.1895 11.4235L11.173 11.44L11.1564 11.4566L11.1398 11.4732L11.1232 11.4897L11.1066 11.5063L11.0901 11.5228L11.0735 11.5394L11.0569 11.5559L11.0404 11.5725L11.0238 11.589L11.0072 11.6056L10.9907 11.6221L10.9741 11.6386L10.9576 11.6552L10.941 11.6717L10.9245 11.6883L10.9079 11.7048L10.8914 11.7213L10.8748 11.7378L10.8583 11.7544L10.8417 11.7709L10.8252 11.7874L10.8086 11.804L10.7921 11.8205L10.7755 11.837L10.759 11.8535L10.7424 11.8701L10.7259 11.8866L10.7094 11.9031L10.6928 11.9196L10.6763 11.9362L10.6597 11.9527L10.6432 11.9692L10.6266 11.9857L10.6101 12.0023L10.5935 12.0188L10.577 12.0353L10.5604 12.0519L10.5439 12.0684L10.5273 12.0849L10.5108 12.1015L10.4942 12.118L10.4777 12.1345L10.4611 12.1511L10.4446 12.1676L10.428 12.1841L10.4114 12.2007L10.3949 12.2172L10.3783 12.2338L10.3618 12.2503L10.3452 12.2669L10.3286 12.2834L10.312 12.3L10.2955 12.3165L10.2789 12.3331L10.2623 12.3497L10.2457 12.3662L10.2291 12.3828L10.2125 12.3994L10.1959 12.4159L10.1793 12.4325L10.1627 12.4491L10.1461 12.4657L10.1295 12.4823L10.1129 12.4989L10.0963 12.5155L10.0797 12.5321L10.0631 12.5487L10.0464 12.5653L10.0298 12.5819L10.0132 12.5985L9.99652 12.6151L9.97987 12.6318L9.96322 12.6484L9.94657 12.665L9.92991 12.6817L9.91324 12.6983L9.89657 12.715L9.87989 12.7316L9.86321 12.7483L9.84653 12.7649L9.82984 12.7816L9.81314 12.7983L9.79644 12.815L9.77973 12.8317L9.76301 12.8484L9.74629 12.8651L9.72957 12.8818L9.71283 12.8985L9.69609 12.9152L9.67935 12.9319L9.6626 12.9487L9.64584 12.9654L9.62907 12.9822L9.6123 12.9989L9.59552 13.0157L9.57873 13.0324L9.56194 13.0492L9.54514 13.066L9.52833 13.0828L9.51151 13.0996L9.49469 13.1164L9.47786 13.1332L9.46102 13.15L9.44417 13.1668L9.42732 13.1837L9.41045 13.2005L9.39358 13.2174L9.3767 13.2342L9.35981 13.2511L9.34292 13.268L9.32601 13.2849L9.3091 13.3018L9.29217 13.3187L9.27524 13.3356L9.2583 13.3525L9.24135 13.3694L9.22439 13.3864L9.20742 13.4033L9.19044 13.4203L9.17345 13.4372L9.15645 13.4542L9.13945 13.4712L9.12243 13.4882L9.1054 13.5052L9.08836 13.5222L9.07131 13.5393L9.05426 13.5563L9.03719 13.5734L9.02011 13.5904L9.00302 13.6075L8.98592 13.6246L8.9688 13.6417L8.95168 13.6588L8.93455 13.6759L8.9174 13.693L8.90024 13.7101L8.88308 13.7273L8.8659 13.7444L8.84871 13.7616L8.8315 13.7788L8.81429 13.796L8.79706 13.8132L8.77983 13.8304L8.76257 13.8477L8.74531 13.8649L8.72804 13.8821L8.71075 13.8994L8.69345 13.9167L8.67614 13.934L8.65881 13.9513L8.64147 13.9686L8.62412 13.9859L8.60676 14.0033L8.58938 14.0206L8.57199 14.038L8.55458 14.0554L8.53716 14.0728L8.51973 14.0902L8.50229 14.1076L8.48483 14.1251L8.46736 14.1425L8.44987 14.16L8.43237 14.1775L8.41485 14.195L8.39732 14.2125L8.37978 14.23L8.36222 14.2475L8.34465 14.2651L8.32706 14.2827L8.30945 14.3002L8.29184 14.3178L8.2742 14.3355L8.25656 14.3531L8.23889 14.3707L8.22121 14.3884L8.20352 14.4061L8.18581 14.4238L8.16808 14.4415L8.15034 14.4592L8.13258 14.4769L8.11481 14.4947L8.09702 14.5124L8.07921 14.5302L8.06139 14.548L8.04355 14.5658L8.0257 14.5837L8.00783 14.6015L7.98994 14.6194L7.97203 14.6373L7.95411 14.6552L7.93617 14.6731L7.91821 14.691L7.90024 14.709L7.88225 14.727L7.86424 14.7449L7.84621 14.763L7.82817 14.781L7.81011 14.799L7.79203 14.8171L7.77393 14.8352L7.75581 14.8533L7.73768 14.8714L7.71952 14.8895L7.70135 14.9076L7.68316 14.9258L7.66495 14.944L7.64673 14.9622L7.62848 14.9804L7.61022 14.9987L7.59193 15.0169L7.57363 15.0352L7.55531 15.0535L7.53697 15.0718L7.5186 15.0902L7.50022 15.1085L7.48182 15.1269L7.4634 15.1453L7.44496 15.1637L7.4265 15.1822L7.40802 15.2006L7.38952 15.2191L7.371 15.2376L7.35246 15.2561L7.33389 15.2747L7.31531 15.2932L7.29671 15.3118L7.27808 15.3304L7.25944 15.3491L7.24077 15.3677L7.22208 15.3864L7.20337 15.4051L7.18464 15.4238L7.16589 15.4425L7.14712 15.4612L7.12832 15.48L7.10951 15.4988L7.09067 15.5176L7.07181 15.5365L7.05292 15.5553L7.03402 15.5742L7.01509 15.5931L6.99614 15.612C6.27167 16.3357 5.09652 16.3361 4.37259 15.613C3.64838 14.8896 3.64838 13.7168 4.37259 12.9935L13.1214 4.2547L14.4178 5.57764L14.4177 5.57772L14.4254 5.58523Z",stroke:"black"}),e("path",{d:"M12.5299 10.2849L7.32791 15.5546C7.12956 15.7556 6.88934 15.9156 6.62689 16.0225C6.08679 16.2425 5.46752 16.224 4.94171 15.9721L4.77945 16.31L4.94171 15.9721C4.6339 15.8246 4.36574 15.6008 4.16736 15.3246L4.02179 15.122C3.60142 14.5368 3.60138 13.749 4.02169 13.1638C4.12291 13.0229 4.24539 12.8984 4.38476 12.795L5.72374 11.8006L5.76816 11.7677L5.80115 11.7233L5.91056 11.5761C6.30572 11.0444 6.96187 10.4244 7.58765 10.0865C7.90229 9.91653 8.17215 9.83821 8.37711 9.84469C8.55555 9.85033 8.69852 9.91798 8.81563 10.1072C8.88186 10.2142 8.92418 10.3701 8.97238 10.5824C8.97507 10.5942 8.9778 10.6063 8.98058 10.6187C9.00013 10.7053 9.02201 10.8022 9.04751 10.8897C9.07575 10.9866 9.11828 11.1087 9.19239 11.2147C9.29475 11.3611 9.4504 11.4075 9.53763 11.4247C9.63768 11.4445 9.74477 11.4447 9.84616 11.4361C10.0516 11.4187 10.299 11.3594 10.5607 11.2643C11.0498 11.0864 11.6345 10.7669 12.1516 10.2849L12.5299 10.2849Z",stroke:"black",strokeWidth:"0.75"})]}),e9=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",stroke:"currentColor"}),e("path",{d:"M15.4237 6.90042C15.5191 6.92315 15.6152 6.94413 15.7074 6.96092C15.7135 7.05035 15.7162 7.16454 15.7138 7.30375C15.7056 7.77188 15.6408 8.43317 15.515 9.1653C15.2592 10.6537 14.774 12.3014 14.1 13.2C13.4011 14.1319 12.332 14.9694 11.4101 15.584C10.9538 15.8882 10.5429 16.1317 10.2465 16.2989C10.1617 16.3467 10.0865 16.3882 10.0224 16.423C9.97538 16.3925 9.92211 16.3576 9.86327 16.3183C9.61299 16.1515 9.26304 15.908 8.86735 15.6037C8.07099 14.9911 7.11105 14.148 6.4 13.2C5.71286 12.2838 5.10686 10.6159 4.73507 9.12872C4.55136 8.39389 4.4322 7.73262 4.38844 7.26582C4.37726 7.14653 4.37171 7.04688 4.37029 6.96627C4.68202 6.91822 5.07002 6.82212 5.46167 6.6997C6.04643 6.51692 6.71066 6.25305 7.25513 5.93001C7.78069 5.61819 8.40348 5.00685 8.92133 4.49851C8.96063 4.45994 8.99932 4.42196 9.03732 4.38474C9.32127 4.10667 9.57222 3.86458 9.78023 3.69195C9.86978 3.61763 9.94141 3.56465 9.99619 3.52986C10.0511 3.56629 10.1228 3.62162 10.2126 3.69902C10.4221 3.8796 10.6732 4.13028 10.9589 4.41605L10.9643 4.42138C11.2419 4.69905 11.5471 5.00425 11.8469 5.27159C12.1431 5.53579 12.4648 5.79139 12.7764 5.94721C13.307 6.2125 13.989 6.47149 14.5895 6.66369C14.8912 6.76025 15.179 6.8421 15.4237 6.90042ZM9.92522 3.48908C9.92521 3.48905 9.92594 3.48931 9.92744 3.48994C9.92598 3.48943 9.92523 3.48911 9.92522 3.48908Z",stroke:"currentColor"})]}),n9=()=>s("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"currentColor",stroke:"currentColor"}),e("path",{d:"M9.92516 3.4891C9.92515 3.48907 9.92588 3.48933 9.92738 3.48997C9.92592 3.48946 9.92517 3.48914 9.92516 3.4891ZM9.99613 3.52989C10.051 3.56631 10.1227 3.62164 10.2125 3.69904C10.422 3.87963 10.6731 4.1303 10.9589 4.41608L10.9642 4.4214C11.2419 4.69907 11.5471 5.00428 11.8468 5.27161C12.1431 5.53582 12.4647 5.79142 12.7763 5.94724C13.3069 6.21253 13.9889 6.47151 14.5894 6.66371C14.8911 6.76027 15.179 6.84213 15.4236 6.90044C15.519 6.92317 15.6151 6.94416 15.7074 6.96095C15.7134 7.05037 15.7162 7.16456 15.7137 7.30377C15.7056 7.7719 15.6407 8.4332 15.5149 9.16533C15.2592 10.6537 14.7739 12.3014 14.0999 13.2C13.401 14.1319 12.3319 14.9694 11.4101 15.584C10.9538 15.8882 10.5428 16.1317 10.2465 16.2989C10.1617 16.3467 10.0864 16.3882 10.0223 16.423C9.97532 16.3925 9.92205 16.3576 9.86321 16.3184C9.61293 16.1515 9.26298 15.9081 8.86729 15.6037C8.07092 14.9911 7.11099 14.1481 6.39994 13.2C5.7128 12.2838 5.10679 10.6159 4.73501 9.12874C4.5513 8.39391 4.43214 7.73264 4.38838 7.26584C4.3772 7.14656 4.37164 7.0469 4.37023 6.9663C4.68196 6.91824 5.06996 6.82215 5.46161 6.69972C6.04637 6.51694 6.7106 6.25307 7.25507 5.93003C7.78063 5.61822 8.40342 5.00687 8.92127 4.49853C8.96057 4.45996 8.99926 4.42198 9.03726 4.38477C9.32121 4.1067 9.57216 3.8646 9.78016 3.69197C9.86972 3.61765 9.94135 3.56467 9.99613 3.52989Z",stroke:"black"})]});function a9({spanKind:n,variant:a="fill"}){const t=a==="fill";let l=t?e(X4,{}):e(q4,{});const i=Lo({spanKind:n});switch(n){case"llm":l=t?e(N4,{}):e(R4,{});break;case"chain":l=t?e(Q4,{}):e(W4,{});break;case"retriever":l=t?e(Z4,{}):e(j4,{});break;case"embedding":l=t?e(H4,{}):e(B4,{});break;case"agent":l=t?e($4,{}):e(O4,{});break;case"tool":l=t?e(P4,{}):e(V4,{});break;case"reranker":l=t?e(G4,{}):e(U4,{});break;case"evaluator":l=t?e(J4,{}):e(Y4,{});break;case"guardrail":l=t?e(n9,{}):e(e9,{});break}return e("div",{css:p`
        color: ${i};
        width: 20px;
        height: 20px;
      `,title:n,children:l})}const So=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"TokenUsage",kind:"LinkedField",name:"tokenUsage",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"prompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"completion",storageKey:null}],storageKey:null}],type:"ProjectSession",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SessionTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SessionTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"5df073c3f0f20378aed5118f6f0d2f4b",id:null,metadata:{},name:"SessionTokenCountDetailsQuery",operationKind:"query",text:`query SessionTokenCountDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on ProjectSession {
      tokenUsage {
        prompt
        completion
      }
    }
    id
  }
}
`}}})();So.hash="da1b954f5615c67f552ece1b8b3478b5";const t9=p`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-static-size-50);
`,l9=p`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: var(--ac-global-dimension-static-size-100);
`,i9=p`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: var(--ac-global-dimension-static-size-25);
`,r9=p`
  margin-top: var(--ac-global-dimension-static-size-100);
  margin-bottom: var(--ac-global-dimension-static-size-25);
`;function Zn({label:n,count:a,isTotal:t=!1,isSubItem:l=!1}){const i=typeof a=="number"?la(a):"--";return s("div",{css:l9,children:[e(C,{size:l?"XS":"S",color:l?"text-500":t?"text-900":"text-700",weight:t?"heavy":"normal",children:n}),e("div",{css:i9,children:s(C,{size:l?"XS":"S",color:"text-700",children:[i,"t"]})})]})}function gi({children:n}){return e(C,{size:"XS",color:"text-700",weight:"heavy",css:r9,children:n})}function rn({total:n,prompt:a,completion:t,promptDetails:l,completionDetails:i,label:r="Total"}){const o=l&&Object.entries(l).some(([,d])=>d!=null&&d>0),c=i&&Object.entries(i).some(([,d])=>d!=null&&d>0);return s("div",{css:t9,children:[n!=null&&e(Zn,{label:r,count:n,isTotal:!0}),a!=null&&e(Zn,{label:"Prompt",count:a}),t!=null&&e(Zn,{label:"Completion",count:t}),o&&s(B,{children:[e(gi,{children:"Prompt Details"}),l&&Object.entries(l).map(([d,u])=>u!=null&&u>0?e(Zn,{label:d.charAt(0).toUpperCase()+d.slice(1),count:u,isSubItem:!0},`prompt-${d}`):null)]}),c&&s(B,{children:[e(gi,{children:"Completion Details"}),i&&Object.entries(i).map(([d,u])=>u!=null&&u>0?e(Zn,{label:d.charAt(0).toUpperCase()+d.slice(1),count:u,isSubItem:!0},`completion-${d}`):null)]})]})}function o9(n){const a=F.useLazyLoadQuery(So,{nodeId:n.sessionNodeId}),t=g.useMemo(()=>{if(a.node.__typename==="ProjectSession"){const l=a.node.tokenUsage.prompt,i=a.node.tokenUsage.completion;return{total:l+i,prompt:l,completion:i}}return{total:null,prompt:null,completion:null}},[a.node]);return e(rn,{...t})}const s9=p`
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-50);
  align-items: center;

  &[data-size="S"] {
    font-size: var(--ac-global-font-size-s);
  }
  &[data-size="M"] {
    font-size: var(--ac-global-font-size-m);
  }
`;function c9(n,a){const{children:t,size:l="M",...i}=n,r=typeof t=="number"?la(t):"--";return s("div",{className:"token-count-item","data-size":l,css:s9,ref:a,...i,children:[e(x,{svg:e(z2,{}),css:p`
          color: var(--ac-global-text-color-900);
        `}),e(C,{size:n.size,fontFamily:"mono",children:r})]})}const Fe=g.forwardRef(c9);function Ah(n){return s(j,{children:[e(se,{children:e(Fe,{size:n.size,role:"button",children:n.tokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(o9,{sessionNodeId:n.nodeId})})]})]})}const wo=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountPrompt",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountCompletion",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"TraceTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"rootSpan",plural:!1,selections:[l,i],storageKey:null}],type:"Trace",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"TraceTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Span",kind:"LinkedField",name:"rootSpan",plural:!1,selections:[l,i,r],storageKey:null}],type:"Trace",abstractKey:null},r],storageKey:null}]},params:{cacheID:"e9131ab8a67b6b79dc9995bb3ce0cb55",id:null,metadata:{},name:"TraceTokenCountDetailsQuery",operationKind:"query",text:`query TraceTokenCountDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on Trace {
      rootSpan {
        cumulativeTokenCountPrompt
        cumulativeTokenCountCompletion
        id
      }
    }
    id
  }
}
`}}})();wo.hash="c0178c78b8c3bb146caa2579d6bc75c4";function d9(n){const a=F.useLazyLoadQuery(wo,{nodeId:n.traceNodeId}),t=g.useMemo(()=>{var l,i;if(a.node.__typename==="Trace"){const r=((l=a.node.rootSpan)==null?void 0:l.cumulativeTokenCountPrompt)??0,o=((i=a.node.rootSpan)==null?void 0:i.cumulativeTokenCountCompletion)??0;return{total:r+o,prompt:r,completion:o}}return{total:null,prompt:null,completion:null}},[a.node]);return e(rn,{...t})}function Mh(n){return s(j,{children:[e(se,{children:e(Fe,{size:n.size,role:"button",children:n.tokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(d9,{traceNodeId:n.nodeId})})]})]})}const xo=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"tokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokenCountCompletion",storageKey:null},{alias:null,args:null,concreteType:"TokenCountPromptDetails",kind:"LinkedField",name:"tokenPromptDetails",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"audio",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cacheRead",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cacheWrite",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"fc6d8104f9bf9481330b8b879b7c8e8e",id:null,metadata:{},name:"SpanTokenCountDetailsQuery",operationKind:"query",text:`query SpanTokenCountDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on Span {
      tokenCountTotal
      tokenCountPrompt
      tokenCountCompletion
      tokenPromptDetails {
        audio
        cacheRead
        cacheWrite
      }
    }
    id
  }
}
`}}})();xo.hash="2f53943dbe7d189d4126be701a017818";function u9(n){const a=F.useLazyLoadQuery(xo,{nodeId:n.spanNodeId}),t=g.useMemo(()=>{var l,i,r;if(a.node.__typename==="Span"){const o=a.node.tokenCountPrompt??0,c=a.node.tokenCountCompletion??0,d=a.node.tokenCountTotal??0,u={};return(l=a.node.tokenPromptDetails)!=null&&l.audio&&(u.audio=a.node.tokenPromptDetails.audio),(i=a.node.tokenPromptDetails)!=null&&i.cacheRead&&(u["cache read"]=a.node.tokenPromptDetails.cacheRead),(r=a.node.tokenPromptDetails)!=null&&r.cacheWrite&&(u["cache write"]=a.node.tokenPromptDetails.cacheWrite),{total:d,prompt:o,completion:c,promptDetails:Object.keys(u).length>0?u:void 0}}return{total:0,prompt:0,completion:0}},[a.node]);return e(rn,{...t})}function m9(n){const a=g.useCallback(t=>{t.continuePropagation()},[]);return s(j,{children:[e(se,{onPress:a,children:e(Fe,{size:n.size,role:"button",children:n.tokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(u9,{spanNodeId:n.nodeId})})]})]})}const To=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountTotal",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountPrompt",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cumulativeTokenCountCompletion",storageKey:null}],type:"Span",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanCumulativeTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanCumulativeTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"c1da825bac7aac7aafa07638290f6f1d",id:null,metadata:{},name:"SpanCumulativeTokenCountDetailsQuery",operationKind:"query",text:`query SpanCumulativeTokenCountDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on Span {
      cumulativeTokenCountTotal
      cumulativeTokenCountPrompt
      cumulativeTokenCountCompletion
    }
    id
  }
}
`}}})();To.hash="f7a968d87890a07d6e1dd6f06bad6b51";function g9(n){const a=F.useLazyLoadQuery(To,{nodeId:n.spanNodeId}),t=g.useMemo(()=>{if(a.node.__typename==="Span"){const l=a.node.cumulativeTokenCountPrompt??0,i=a.node.cumulativeTokenCountCompletion??0;return{total:a.node.cumulativeTokenCountTotal??0,prompt:l,completion:i}}return{total:null,prompt:null,completion:null}},[a.node]);return e(rn,{...t})}function Fh(n){return s(j,{children:[e(se,{children:e(Fe,{size:n.size,role:"button",children:n.tokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(g9,{spanNodeId:n.nodeId})})]})]})}const p9=p`
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-50);
  align-items: center;

  &[data-size="S"] {
    font-size: var(--ac-global-font-size-s);
  }
  &[data-size="M"] {
    font-size: var(--ac-global-font-size-m);
  }
`;function h9(n,a){const{children:t,size:l="M",...i}=n,r=typeof t=="number"?lo(t):"--";return s("div",{className:"token-costs-item","data-size":l,css:p9,ref:a,...i,children:[e(x,{svg:e(jr,{}),css:p`
          color: var(--ac-global-text-color-900);
        `}),e(C,{size:n.size,fontFamily:"mono",children:r})]})}const on=g.forwardRef(h9),f9=p`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-static-size-100);
  min-width: 200px;
`,b9=p`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: var(--ac-global-dimension-static-size-200);

  &[data-is-total="true"] {
    font-weight: var(--ac-global-font-weight-heavy);
  }

  &[data-is-sub-item="true"] {
    margin-left: var(--ac-global-dimension-static-size-200);
    color: var(--ac-global-text-color-500);
    font-size: var(--ac-global-font-size-xs);
  }
`,y9=p`
  font-weight: var(--ac-global-font-weight-heavy);
  font-size: var(--ac-global-font-size-xs);
  color: var(--ac-global-text-color-700);
  margin-top: var(--ac-global-dimension-static-size-100);
`;function Un({label:n,cost:a,isTotal:t,isSubItem:l}){return s("div",{css:b9,"data-is-total":t,"data-is-sub-item":l,children:[e(C,{size:l?"XS":"S",weight:t?"heavy":"normal",color:l?"text-500":t?"text-900":"text-700",children:n}),e(C,{size:l?"XS":"S",color:l?"text-500":"text-700",children:lo(a)})]})}function pi({children:n}){return e("div",{css:y9,children:e(C,{size:"XS",weight:"heavy",color:"text-700",children:n})})}function Sn({total:n,prompt:a,completion:t,promptDetails:l,completionDetails:i,label:r="Total"}){const o=l&&Object.entries(l).some(([,d])=>d!=null&&d>0),c=i&&Object.entries(i).some(([,d])=>d!=null&&d>0);return s("div",{css:f9,children:[n!=null&&e(Un,{label:r,cost:n,isTotal:!0}),a!=null&&e(Un,{label:"Prompt",cost:a}),t!=null&&e(Un,{label:"Completion",cost:t}),o&&s(B,{children:[e(pi,{children:"Prompt Details"}),l&&Object.entries(l).map(([d,u])=>u!=null&&u>0?e(Un,{label:d.charAt(0).toUpperCase()+d.slice(1),cost:u,isSubItem:!0},`prompt-${d}`):null)]}),c&&s(B,{children:[e(pi,{children:"Completion Details"}),i&&Object.entries(i).map(([d,u])=>u!=null&&u>0?e(Un,{label:d.charAt(0).toUpperCase()+d.slice(1),cost:u,isSubItem:!0},`completion-${d}`):null)]})]})}const Io=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null},i=[l],r={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:i,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanCostDetailSummaryEntry",kind:"LinkedField",name:"costDetailSummaryEntries",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"tokenType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"isPrompt",storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"value",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],storageKey:null}],storageKey:null}],type:"Span",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"76a8269902195041de07d13cdf853e14",id:null,metadata:{},name:"SpanTokenCostsDetailsQuery",operationKind:"query",text:`query SpanTokenCostsDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on Span {
      costSummary {
        total {
          cost
        }
        prompt {
          cost
        }
        completion {
          cost
        }
      }
      costDetailSummaryEntries {
        tokenType
        isPrompt
        value {
          cost
          tokens
        }
      }
    }
    id
  }
}
`}}})();Io.hash="2b8791832440bdad2d98eb3b3a168fd7";function v9(n){const a=F.useLazyLoadQuery(Io,{nodeId:n.spanNodeId}),t=g.useMemo(()=>{var l,i,r,o,c,d;if(a.node.__typename==="Span"){const u=a.node.costDetailSummaryEntries;if(!u)return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null};const m=u.filter(k=>k.isPrompt),h=u.filter(k=>!k.isPrompt),b=((i=(l=a.node.costSummary)==null?void 0:l.total)==null?void 0:i.cost)??0,f=((o=(r=a.node.costSummary)==null?void 0:r.prompt)==null?void 0:o.cost)??0,y=((d=(c=a.node.costSummary)==null?void 0:c.completion)==null?void 0:d.cost)??0,v={};m.forEach(k=>{k.value.cost!=null&&(v[k.tokenType]=k.value.cost)});const L={};return h.forEach(k=>{k.value.cost!=null&&(L[k.tokenType]=k.value.cost)}),{total:b,prompt:f,completion:y,promptDetails:Object.keys(v).length>0?v:null,completionDetails:Object.keys(L).length>0?L:null}}return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null}},[a.node]);return e(Sn,{...t})}function Dh(n){return s(j,{children:[e(se,{children:e(on,{size:n.size,role:"button",children:n.totalCost})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(v9,{spanNodeId:n.spanNodeId})})]})]})}const zo=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null},i=[l],r={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:i,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanCostDetailSummaryEntry",kind:"LinkedField",name:"costDetailSummaryEntries",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"tokenType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"isPrompt",storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"value",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],storageKey:null}],storageKey:null}],type:"Trace",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"TraceTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"TraceTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"0aa2a06633664f6e538e638254144b69",id:null,metadata:{},name:"TraceTokenCostsDetailsQuery",operationKind:"query",text:`query TraceTokenCostsDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on Trace {
      costSummary {
        total {
          cost
        }
        prompt {
          cost
        }
        completion {
          cost
        }
      }
      costDetailSummaryEntries {
        tokenType
        isPrompt
        value {
          cost
          tokens
        }
      }
    }
    id
  }
}
`}}})();zo.hash="508fdb06371456b54b7317143a9fabf4";function C9(n){const a=F.useLazyLoadQuery(zo,{nodeId:n.traceNodeId}),t=g.useMemo(()=>{var l,i,r,o,c,d;if(a.node.__typename==="Trace"){const u=a.node.costDetailSummaryEntries;if(!u)return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null};const m=u.filter(k=>k.isPrompt),h=u.filter(k=>!k.isPrompt),b=((i=(l=a.node.costSummary)==null?void 0:l.total)==null?void 0:i.cost)??0,f=((o=(r=a.node.costSummary)==null?void 0:r.prompt)==null?void 0:o.cost)??0,y=((d=(c=a.node.costSummary)==null?void 0:c.completion)==null?void 0:d.cost)??0,v={};m.forEach(k=>{k.value.cost!=null&&(v[k.tokenType]=k.value.cost)});const L={};return h.forEach(k=>{k.value.cost!=null&&(L[k.tokenType]=k.value.cost)}),{total:b,prompt:f,completion:y,promptDetails:Object.keys(v).length>0?v:null,completionDetails:Object.keys(L).length>0?L:null}}return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null}},[a.node]);return e(Sn,{...t})}function Eh(n){return s(j,{children:[e(se,{children:e(on,{size:n.size,role:"button",tabIndex:0,children:n.totalCost})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(C9,{traceNodeId:n.nodeId})})]})]})}const Ao=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostDetailSummaryEntry",kind:"LinkedField",name:"costDetailSummaryEntries",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"tokenType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"isPrompt",storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"value",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],storageKey:null}],storageKey:null}],type:"ProjectSession",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SessionTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SessionTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,l,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"5c5cd200597f3c5c5415851c9d8a52fd",id:null,metadata:{},name:"SessionTokenCostsDetailsQuery",operationKind:"query",text:`query SessionTokenCostsDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on ProjectSession {
      costDetailSummaryEntries {
        tokenType
        isPrompt
        value {
          cost
          tokens
        }
      }
    }
    id
  }
}
`}}})();Ao.hash="4ff1881d1c2662709204991c58108dcb";function k9(n){const a=F.useLazyLoadQuery(Ao,{nodeId:n.sessionNodeId}),t=g.useMemo(()=>{if(a.node.__typename==="ProjectSession"){const l=a.node.costDetailSummaryEntries;if(!l)return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null};const i=l.filter(m=>m.isPrompt),r=l.filter(m=>!m.isPrompt),o=i.reduce((m,h)=>m+(h.value.cost||0),0),c=r.reduce((m,h)=>m+(h.value.cost||0),0),d={};i.forEach(m=>{m.value.cost!=null&&(d[m.tokenType]=m.value.cost)});const u={};return r.forEach(m=>{m.value.cost!=null&&(u[m.tokenType]=m.value.cost)}),{total:o+c,prompt:o>0?o:null,completion:c>0?c:null,promptDetails:Object.keys(d).length>0?d:null,completionDetails:Object.keys(u).length>0?u:null}}return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null}},[a.node]);return e(Sn,{...t})}function Kh(n){return s(j,{children:[e(se,{children:e(on,{size:n.size,role:"button",children:n.totalCost})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(k9,{sessionNodeId:n.nodeId})})]})]})}const Mo=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"datasetExampleId"},a={defaultValue:null,kind:"LocalArgument",name:"datasetId"},t={defaultValue:null,kind:"LocalArgument",name:"datasetVersionId"},l={defaultValue:null,kind:"LocalArgument",name:"experimentIds"},i=[{kind:"Variable",name:"id",variableName:"datasetExampleId"}],r={alias:null,args:[{kind:"Variable",name:"datasetVersionId",variableName:"datasetVersionId"}],concreteType:"DatasetExampleRevision",kind:"LinkedField",name:"revision",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"input",storageKey:null},{alias:"referenceOutput",args:null,kind:"ScalarField",name:"output",storageKey:null}],storageKey:null},o=[{kind:"Variable",name:"experimentIds",variableName:"experimentIds"},{kind:"Literal",name:"first",value:120}],c={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},d={alias:null,args:null,kind:"ScalarField",name:"repetitionNumber",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"latencyMs",storageKey:null},m={alias:null,args:null,kind:"ScalarField",name:"experimentId",storageKey:null},h={alias:null,args:null,kind:"ScalarField",name:"output",storageKey:null},b={alias:null,args:null,kind:"ScalarField",name:"error",storageKey:null},f={alias:null,args:null,kind:"ScalarField",name:"traceId",storageKey:null},y={alias:null,args:null,kind:"ScalarField",name:"projectId",storageKey:null},v={alias:null,args:null,concreteType:"Trace",kind:"LinkedField",name:"trace",plural:!1,selections:[f,y],storageKey:null},L={alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],storageKey:null}],storageKey:null},k={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},T={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},I={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},V={alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},M=[{kind:"Variable",name:"id",variableName:"datasetId"}],_={kind:"InlineFragment",selections:[{alias:null,args:[{kind:"Variable",name:"filterIds",variableName:"experimentIds"}],concreteType:"ExperimentConnection",kind:"LinkedField",name:"experiments",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"experiment",args:null,concreteType:"Experiment",kind:"LinkedField",name:"node",plural:!1,selections:[c,k,{alias:null,args:null,kind:"ScalarField",name:"repetitions",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"DatasetExperimentAnnotationSummary",kind:"LinkedField",name:"experimentAnnotationSummaries",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"annotationName",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"minScore",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"maxScore",storageKey:null}],storageKey:null}],type:"Dataset",abstractKey:null},H={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},K={alias:null,args:null,concreteType:"Trace",kind:"LinkedField",name:"trace",plural:!1,selections:[f,y,c],storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l],kind:"Fragment",metadata:null,name:"ExperimentCompareDetailsQuery",selections:[{alias:"example",args:i,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[r,{alias:null,args:o,concreteType:"ExperimentRunConnection",kind:"LinkedField",name:"experimentRuns",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"run",args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[c,d,u,m,h,b,v,L,{alias:null,args:null,concreteType:"ExperimentRunAnnotationConnection",kind:"LinkedField",name:"annotations",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunAnnotationEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"annotation",args:null,concreteType:"ExperimentRunAnnotation",kind:"LinkedField",name:"node",plural:!1,selections:[c,k,T,I,V,v],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"DatasetExample",abstractKey:null}],storageKey:null},{alias:"dataset",args:M,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[_],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n,t,l],kind:"Operation",name:"ExperimentCompareDetailsQuery",selections:[{alias:"example",args:i,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[H,{kind:"InlineFragment",selections:[r,{alias:null,args:o,concreteType:"ExperimentRunConnection",kind:"LinkedField",name:"experimentRuns",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"run",args:null,concreteType:"ExperimentRun",kind:"LinkedField",name:"node",plural:!1,selections:[c,d,u,m,h,b,K,L,{alias:null,args:null,concreteType:"ExperimentRunAnnotationConnection",kind:"LinkedField",name:"annotations",plural:!1,selections:[{alias:null,args:null,concreteType:"ExperimentRunAnnotationEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"annotation",args:null,concreteType:"ExperimentRunAnnotation",kind:"LinkedField",name:"node",plural:!1,selections:[c,k,T,I,V,K],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"DatasetExample",abstractKey:null},c],storageKey:null},{alias:"dataset",args:M,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[H,_,c],storageKey:null}]},params:{cacheID:"9dc32d9095b770a435e3b4a4d98cb772",id:null,metadata:{},name:"ExperimentCompareDetailsQuery",operationKind:"query",text:`query ExperimentCompareDetailsQuery(
  $datasetId: ID!
  $datasetExampleId: ID!
  $datasetVersionId: ID!
  $experimentIds: [ID!]!
) {
  example: node(id: $datasetExampleId) {
    __typename
    ... on DatasetExample {
      revision(datasetVersionId: $datasetVersionId) {
        input
        referenceOutput: output
      }
      experimentRuns(experimentIds: $experimentIds, first: 120) {
        edges {
          run: node {
            id
            repetitionNumber
            latencyMs
            experimentId
            output
            error
            trace {
              traceId
              projectId
              id
            }
            costSummary {
              total {
                cost
                tokens
              }
            }
            annotations {
              edges {
                annotation: node {
                  id
                  name
                  label
                  score
                  metadata
                  trace {
                    traceId
                    projectId
                    id
                  }
                }
              }
            }
          }
        }
      }
    }
    id
  }
  dataset: node(id: $datasetId) {
    __typename
    ... on Dataset {
      experiments(filterIds: $experimentIds) {
        edges {
          experiment: node {
            id
            name
            repetitions
          }
        }
      }
      experimentAnnotationSummaries {
        annotationName
        minScore
        maxScore
      }
    }
    id
  }
}
`}}})();Mo.hash="adc8627f202c5b26488d24e4282770d6";function Fo(){const n=p4();return{getExperimentColor:g.useCallback(t=>{const l=Object.values(n),i=l.length;return l[t%i]},[n]),baseExperimentColor:"var(--ac-global-color-grey-500)"}}function _h({sequenceNumber:n}){return s(Se,{color:"var(--ac-global-color-yellow-500)",size:"S",children:["#",n]})}const Do=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l=[{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],i={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:l,storageKey:null}],storageKey:null}],type:"ExperimentRun",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentRunTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentRunTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"bb25f38a892f4b257794b8e43b04f835",id:null,metadata:{},name:"ExperimentRunTokenCountDetailsQuery",operationKind:"query",text:`query ExperimentRunTokenCountDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on ExperimentRun {
      costSummary {
        total {
          tokens
        }
        prompt {
          tokens
        }
        completion {
          tokens
        }
      }
    }
    id
  }
}
`}}})();Do.hash="0de1caa674a484b1e5d1449743805823";function L9(n){const a=F.useLazyLoadQuery(Do,{nodeId:n.experimentRunId}),t=g.useMemo(()=>{var l,i,r,o,c,d;if(a.node.__typename==="ExperimentRun"){const u=((i=(l=a.node.costSummary)==null?void 0:l.prompt)==null?void 0:i.tokens)??0,m=((o=(r=a.node.costSummary)==null?void 0:r.completion)==null?void 0:o.tokens)??0;return{total:((d=(c=a.node.costSummary)==null?void 0:c.total)==null?void 0:d.tokens)??0,prompt:u,completion:m}}return{total:null,prompt:null,completion:null}},[a.node]);return e(rn,{...t})}function S9(n){return s(j,{isDisabled:n.tokenCountTotal==null,children:[e(se,{children:e(Fe,{size:n.size,role:"button",children:n.tokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(L9,{experimentRunId:n.experimentRunId})})]})]})}const Eo=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l=[{alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null}],i={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:l,storageKey:null}],storageKey:null}],type:"ExperimentRun",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentRunTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentRunTokenCostsDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"56ebff6ade8d9718931af681ea77b06a",id:null,metadata:{},name:"ExperimentRunTokenCostsDetailsQuery",operationKind:"query",text:`query ExperimentRunTokenCostsDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on ExperimentRun {
      costSummary {
        total {
          cost
        }
        prompt {
          cost
        }
        completion {
          cost
        }
      }
    }
    id
  }
}
`}}})();Eo.hash="f99884bcc09d854081aeba2247d70dde";function w9(n){const a=F.useLazyLoadQuery(Eo,{nodeId:n.experimentRunId}),t=g.useMemo(()=>{var l,i,r,o,c,d;if(a.node.__typename==="ExperimentRun"){const u=((i=(l=a.node.costSummary)==null?void 0:l.prompt)==null?void 0:i.cost)??0,m=((o=(r=a.node.costSummary)==null?void 0:r.completion)==null?void 0:o.cost)??0;return{total:((d=(c=a.node.costSummary)==null?void 0:c.total)==null?void 0:d.cost)??0,prompt:u,completion:m}}return{total:null,prompt:null,completion:null}},[a.node]);return e(Sn,{...t})}function x9(n){return s(j,{isDisabled:n.costTotal==null,children:[e(se,{children:e(on,{size:n.size,"aria-role":"button",children:n.costTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(w9,{experimentRunId:n.experimentRunId})})]})]})}const Ko=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l=[{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],i={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:l,storageKey:null}],storageKey:null}],type:"Experiment",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"3b40ee1d5d53511d1e5a6ff31b52cd01",id:null,metadata:{},name:"ExperimentTokenCountDetailsQuery",operationKind:"query",text:`query ExperimentTokenCountDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on Experiment {
      costSummary {
        total {
          tokens
        }
        prompt {
          tokens
        }
        completion {
          tokens
        }
      }
    }
    id
  }
}
`}}})();Ko.hash="0946f26e471401c182db5b8107b9c3dd";function T9(n){const a=F.useLazyLoadQuery(Ko,{nodeId:n.experimentId}),t=g.useMemo(()=>{var l,i,r,o,c,d;if(a.node.__typename==="Experiment"){const u=((i=(l=a.node.costSummary)==null?void 0:l.prompt)==null?void 0:i.tokens)??0,m=((o=(r=a.node.costSummary)==null?void 0:r.completion)==null?void 0:o.tokens)??0;return{total:((d=(c=a.node.costSummary)==null?void 0:c.total)==null?void 0:d.tokens)??0,prompt:u,completion:m}}return{total:null,prompt:null,completion:null}},[a.node]);return e(rn,{...t})}function Vh(n){return n.tokenCountTotal==null?e(Fe,{size:n.size,children:null}):s(j,{children:[e(se,{children:e(Fe,{size:n.size,role:"button",children:n.tokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(T9,{experimentId:n.experimentId})})]})]})}const _o=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"experimentId"}],a=[{kind:"Variable",name:"id",variableName:"experimentId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null},i=[l],r={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:i,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanCostDetailSummaryEntry",kind:"LinkedField",name:"costDetailSummaryEntries",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"tokenType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"isPrompt",storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"value",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"runCount",storageKey:null}],type:"Experiment",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentAverageRunTokenCostsDetailsQuery",selections:[{alias:"experiment",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentAverageRunTokenCostsDetailsQuery",selections:[{alias:"experiment",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"84d979fc0c4a2f43c63f82ffdb4d77be",id:null,metadata:{},name:"ExperimentAverageRunTokenCostsDetailsQuery",operationKind:"query",text:`query ExperimentAverageRunTokenCostsDetailsQuery(
  $experimentId: ID!
) {
  experiment: node(id: $experimentId) {
    __typename
    ... on Experiment {
      costSummary {
        total {
          cost
        }
        prompt {
          cost
        }
        completion {
          cost
        }
      }
      costDetailSummaryEntries {
        tokenType
        isPrompt
        value {
          cost
          tokens
        }
      }
      runCount
    }
    id
  }
}
`}}})();_o.hash="77037c928e3745c36b74597c172eb5ee";function I9({experimentId:n}){const a=F.useLazyLoadQuery(_o,{experimentId:n}),t=g.useMemo(()=>{if(a.experiment.__typename==="Experiment"){const l=a.experiment.costDetailSummaryEntries;if(!l)return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null};const i=l.filter(v=>v.isPrompt),r=l.filter(v=>!v.isPrompt),o=a.experiment.costSummary.total.cost,c=a.experiment.costSummary.prompt.cost,d=a.experiment.costSummary.completion.cost,u=a.experiment.runCount,m=o==null||u==0?null:o/u,h=c==null||u==0?null:c/u,b=d==null||u==0?null:d/u,f={};i.forEach(v=>{v.value.cost!=null&&(f[v.tokenType]=v.value.cost)});const y={};return r.forEach(v=>{v.value.cost!=null&&(y[v.tokenType]=v.value.cost)}),{total:m,prompt:h,completion:b,promptDetails:Object.keys(f).length>0?f:null,completionDetails:Object.keys(y).length>0?y:null}}return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null}},[a.experiment]);return e(Sn,{...t,label:"Average"})}function Ph(n){return s(j,{children:[e(se,{children:e(on,{size:n.size,role:"button",children:n.averageRunCostTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(I9,{experimentId:n.experimentId})})]})]})}function z9(){return s(S,{direction:"row",gap:"size-100",children:[e(Sl,{size:"S",latencyMs:null}),e(Fe,{size:"S",children:null}),e(on,{size:"S",children:null})]})}const A9=n=>p`
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: ${n};
  overflow: hidden;
  text-overflow: ellipsis;
`;function M9({children:n,lines:a}){return e("div",{css:A9(a),children:n})}const Vo=g.createContext(null);function F9({children:n,baseExperimentId:a,compareExperimentIds:t,experimentsById:l,experimentRepetitionsByExperimentId:i,annotationSummaries:r,referenceOutput:o,includeRepetitions:c,openTraceDialog:d,defaultSelectedRepetitionNumber:u}){const m=g.useMemo(()=>[a,...t],[a,t]),[h,b]=g.useState(()=>D9(m,a,l,u)),[f,y]=g.useState(!0),v=g.useCallback(()=>{y(R=>!R)},[]),L=g.useCallback((R,q)=>{b(X=>X.map($e=>$e.experimentId===R?{...$e,selected:q}:$e))},[]),k=g.useCallback((R,q,X)=>{b($e=>$e.map(wn=>wn.experimentId===R&&wn.repetitionNumber===q?{...wn,selected:X}:wn))},[]),T=g.useCallback(R=>{b(q=>q.map(X=>({...X,selected:R}))),y(R)},[]),[I,V]=g.useState(null),[M,_]=g.useState("asc"),H=g.useCallback(()=>{_(R=>R==="asc"?"desc":"asc")},[]),K=g.useMemo(()=>{if(!c){const R=Object.values(i).flat();return(I?hi(R,I,M):R).map(X=>({experimentId:X.experimentId,experimentRepetitions:[X]}))}return m.map(R=>{const q=i[R],X=I?hi(q,I,M):q;return{experimentId:R,experimentRepetitions:X}})},[m,i,I,c,M]),A=g.useMemo(()=>h.every(X=>!X.selected)&&(!o||!f),[h,o,f]),O={baseExperimentId:a,compareExperimentIds:t,experimentsById:l,experimentRepetitionsByExperimentId:i,annotationSummaries:r,referenceOutput:o,includeRepetitions:c,openTraceDialog:d,selectedExperimentRepetitions:h,referenceOutputSelected:f,toggleReferenceOutputSelected:v,updateExperimentSelection:L,updateRepetitionSelection:k,toggleAllRepetitionsSelection:T,selectedAnnotation:I,setSelectedAnnotation:V,sortDirection:M,toggleSortDirection:H,sortedExperimentRepetitions:K,noRunsSelected:A};return e(Vo.Provider,{value:O,children:n})}function Qe(){const n=g.useContext(Vo);if(!n)throw new Error("useExperimentCompareDetailsContext must be used within ExperimentCompareDetailsProvider");return n}function D9(n,a,t,l){return n.flatMap(i=>{const r=t[i];return Nn.range(r.repetitions).map(o=>{const c=o+1;return{experimentId:i,repetitionNumber:c,selected:i===a&&l!==void 0?c===l:!0}})})}function wl(n,a){var t,l;return((l=(t=n.experimentRun)==null?void 0:t.annotations.edges.find(i=>i.annotation.name===a))==null?void 0:l.annotation)??null}function hi(n,a,t){return Nn.orderBy(n,l=>{const i=wl(l,a);return[i==null?void 0:i.score,i==null?void 0:i.label,l.repetitionNumber]},t)}function E9(n,a){return a.filter(t=>t.experimentId===n).every(t=>t.selected)}function K9(n,a){return a.filter(t=>t.experimentId===n).some(t=>t.selected)}function _9({latencyMs:n}){return n===null?null:e(Sl,{size:"S",latencyMs:n})}function V9(n){const{id:a,latencyMs:t,costSummary:l}=n,i=l.total.tokens,r=l.total.cost;return s(S,{direction:"row",gap:"size-100",children:[e(_9,{latencyMs:t}),i!=null&&a?e(S9,{tokenCountTotal:i,experimentRunId:a,size:"S"}):e(Fe,{size:"S",children:i}),r!=null&&a?e(x9,{costTotal:r,experimentRunId:a,size:"S"}):null]})}const vt=25;function Rh({datasetId:n,datasetExampleId:a,datasetVersionId:t,baseExperimentId:l,compareExperimentIds:i,defaultSelectedRepetitionNumber:r,openTraceDialog:o}){var k,T,I,V;const c=g.useRef(null),d=g.useMemo(()=>[l,...i],[l,i]),u=F.useLazyLoadQuery(Mo,{datasetId:n,datasetExampleId:a,datasetVersionId:t,experimentIds:d}),m=(k=u.example.revision)==null?void 0:k.input,h=(T=u.example.revision)==null?void 0:T.referenceOutput,b=(I=u.example.experimentRuns)==null?void 0:I.edges,f=(V=u.dataset.experiments)==null?void 0:V.edges,y=g.useMemo(()=>{var M;return((M=u.dataset.experimentAnnotationSummaries)==null?void 0:M.filter(_=>b==null?void 0:b.some(H=>{var K;return(K=H.run.annotations)==null?void 0:K.edges.some(A=>A.annotation.name===_.annotationName)})))??[]},[u.dataset.experimentAnnotationSummaries,b]),v=g.useMemo(()=>{const M={};return f==null||f.forEach(_=>{M[_.experiment.id]=_.experiment}),M},[f]),L=g.useMemo(()=>{const M={};return d.forEach(_=>{M[_]=[];const H=v[_];H&&Nn.range(H.repetitions).forEach(K=>{const A=K+1,O=b==null?void 0:b.find(R=>R.run.experimentId===_&&R.run.repetitionNumber===A);O?M[_].push({experimentId:_,repetitionNumber:A,experimentRun:O.run}):M[_].push({experimentId:_,repetitionNumber:A})})}),M},[b,d,v]);return s(Ui,{direction:"vertical",autoSaveId:"example-compare-panel-group",children:[e(ea,{defaultSize:35,ref:c,style:{minHeight:78},children:e("div",{css:p`
            height: 100%;
          `,children:e(w,{overflow:"hidden",padding:"size-200",height:"100%",children:e(ao,{title:"Input",extra:e(pa,{text:JSON.stringify(m)}),height:"100%",scrollBody:!0,collapsible:!0,onCollapseChange:M=>{const _=c.current;_&&(M?_.resize(0):_.resize(35))},children:e(xl,{value:JSON.stringify(m,null,2)})})})})}),e(jt,{css:E4}),e(ea,{defaultSize:65,children:e("div",{css:p`
            overflow-y: auto;
            height: 100%;
            box-sizing: border-box;
          `,children:e(F9,{baseExperimentId:l,compareExperimentIds:i,experimentsById:v,experimentRepetitionsByExperimentId:L,annotationSummaries:y,referenceOutput:h,includeRepetitions:Object.values(v).some(M=>M.repetitions>1),openTraceDialog:o,defaultSelectedRepetitionNumber:r,children:e(P9,{})})})})]})}function P9(){const{sortedExperimentRepetitions:n,noRunsSelected:a,experimentsById:t,baseExperimentId:l,compareExperimentIds:i,referenceOutput:r,referenceOutputSelected:o}=Qe(),c=g.useMemo(()=>[l,...i],[l,i]),[d,u]=g.useState(!0),m=g.useRef(null);return s(Ui,{direction:"horizontal",children:[d?e(ea,{defaultSize:vt,ref:m,collapsible:!0,id:"experiment-compare-details-outputs-sidebar-panel",order:1,onCollapse:()=>u(!1),style:{minWidth:300},children:e(N9,{})}):null,d?e(jt,{css:vo}):null,e(ea,{id:"experiment-compare-details-outputs-main-panel",order:2,children:s(S,{direction:"column",height:"100%",children:[e(w,{paddingX:"size-200",paddingY:"size-100",borderBottomColor:"dark",borderBottomWidth:"thin",flex:"none",children:s(S,{direction:"row",gap:"size-200",alignItems:"center",children:[e($n,{size:"S","aria-label":"Toggle side bar",onPress:()=>{u(!d);const h=m.current;h&&h.getSize()<vt&&h.resize(vt)},children:e(x,{svg:d?e(Zr,{}):e(Ur,{})})}),e(Q,{children:"Experiment Runs"})]})}),a&&e(sl,{message:"No runs selected"}),s("ul",{css:p`
              flex: 1;
              overflow: auto;
              display: grid;
              grid-auto-flow: column;
              align-items: stretch;
              gap: var(--ac-global-dimension-static-size-200);
              padding: var(--ac-global-dimension-static-size-200);
            `,children:[r&&o&&e("li",{css:p`
                  flex: none;
                `,children:e(H9,{})}),n.map(({experimentId:h,experimentRepetitions:b})=>{const f=t[h],y=c.indexOf(h);return f?b.map(v=>e(R9,{experiment:f,experimentRepetition:v,experimentIndex:y},`${h}-${v.repetitionNumber}`)):null})]})]})})]})}const R9=({experiment:n,experimentRepetition:a,experimentIndex:t})=>{const{selectedExperimentRepetitions:l}=Qe();return g.useMemo(()=>l.some(r=>r.experimentId===n.id&&r.repetitionNumber===a.repetitionNumber&&r.selected),[l,n.id,a.repetitionNumber])?e("li",{css:p`
        flex: none;
      `,children:e(B9,{experiment:n,experimentRepetition:a,experimentIndex:t})}):null};function N9(){const{experimentsById:n,annotationSummaries:a,baseExperimentId:t,compareExperimentIds:l,sortedExperimentRepetitions:i,selectedExperimentRepetitions:r,toggleAllRepetitionsSelection:o,selectedAnnotation:c,setSelectedAnnotation:d,toggleSortDirection:u,includeRepetitions:m,referenceOutput:h,referenceOutputSelected:b,toggleReferenceOutputSelected:f}=Qe(),y=g.useMemo(()=>[t,...l],[t,l]),v=g.useMemo(()=>r.every(k=>k.selected),[r]),L=g.useMemo(()=>r.some(k=>k.selected),[r]);return s("div",{css:p`
        flex: none;
        font-size: var(--ac-global-dimension-static-font-size-100);
        color: var(--ac-global-color-grey-700);
        padding: var(--ac-global-dimension-static-size-200);
        overflow: auto;
        height: 100%;
        box-sizing: border-box;
      `,children:[s(w,{paddingStart:m?"size-85":0,children:[s(S,{direction:"row",gap:"size-200",alignItems:"center",justifyContent:"space-between",children:[e(fn,{isSelected:v,isIndeterminate:L&&!v,onChange:k=>o(k),children:e(C,{children:e(ye,{maxWidth:"100%",children:"Select all"})})}),a.length>0&&s(S,{direction:"row",alignItems:"center",css:p`
                overflow: hidden;
                padding: var(--ac-global-dimension-size-25);
              `,children:[s(Ya,{children:[s(D,{variant:"quiet",size:"S",css:p`
                    min-width: 100px;
                    flex: 0 1 auto;
                  `,children:[c?e(ye,{maxWidth:"100%",children:e(C,{children:c})}):e(n5,{children:"Sort by annotation"}),e(ze,{})]}),e(le,{children:e(ta,{items:a,selectionMode:"single",selectedKeys:c?[c]:[],onSelectionChange:k=>{k!=="all"&&d(k.values().next().value)},css:p`
                      font-size: var(--ac-global-font-size-s);
                    `,children:k=>e(Ke,{id:k.annotationName,children:k.annotationName},k.annotationName)})})]}),c&&e($n,{size:"S","aria-label":"Change sort direction",onPress:u,css:p`
                    flex: none;
                  `,children:e(x,{svg:e(Y0,{})})})]})]}),h&&e(fn,{isSelected:b,onChange:f,children:e(S,{minHeight:30,alignItems:"center",children:e(C,{children:"reference output"})})})]}),i.map(({experimentId:k,experimentRepetitions:T})=>{const I=n[k],V=y.indexOf(k);return e(O9,{experiment:I,experimentIndex:V,experimentRepetitions:T},k)})]})}function O9({experiment:n,experimentIndex:a,experimentRepetitions:t}){const{selectedExperimentRepetitions:l,selectedAnnotation:i,includeRepetitions:r,updateExperimentSelection:o,updateRepetitionSelection:c}=Qe(),{baseExperimentColor:d,getExperimentColor:u}=Fo(),[m,h]=g.useState(!1),b=E9(n.id,l),f=K9(n.id,l),y=i?wl(t[0],i):null;return s(B,{children:[s(S,{direction:"row",gap:"size-75",alignItems:"center",children:[r&&e($n,{size:"S","aria-label":"Collapse experiment",onPress:()=>h(!m),css:p`
              flex: none;
              .ac-icon-wrap {
                transform: ${m?"rotate(0deg)":"rotate(90deg)"};
                transition: all 0.1s ease-in-out;
              }
            `,children:e(x,{svg:e(Za,{})})}),e(fn,{isSelected:b,isIndeterminate:f&&!b,onChange:v=>o(n.id,v),children:s(S,{direction:"row",gap:"size-200",alignItems:"center",justifyContent:"space-between",width:"100%",minHeight:30,marginY:"size-25",css:p`
              overflow: hidden;
            `,children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e("span",{css:p`
                  flex: none;
                  padding-left: var(--ac-global-dimension-size-50);
                `,children:e(U,{color:a===0?d:u(a-1),shape:"circle"})}),e(M9,{lines:2,children:n.name})]}),!r&&i&&e(C,{fontFamily:"mono",css:p`
                  overflow: hidden;
                  max-width: 50%;
                `,children:e(ye,{maxWidth:"100%",children:(y==null?void 0:y.score)!=null?Ja(y.score):(y==null?void 0:y.label)||"--"})})]})})]}),!m&&r&&e($9,{experiment:n,experimentRepetitions:t,updateRepetitionSelection:(v,L)=>c(n.id,v,L)})]})}function $9({experiment:n,experimentRepetitions:a,updateRepetitionSelection:t}){const{selectedExperimentRepetitions:l,selectedAnnotation:i}=Qe();return e(w,{paddingStart:"size-750",children:e(S,{direction:"column",children:a.map(r=>{var d;const o=i?wl(r,i):null,c=!r.experimentRun;return e(fn,{isSelected:(d=l.find(u=>u.experimentId===n.id&&u.repetitionNumber===r.repetitionNumber))==null?void 0:d.selected,onChange:u=>t(r.repetitionNumber,u),children:s(S,{direction:"row",gap:"size-200",alignItems:"center",justifyContent:"space-between",width:"100%",minHeight:30,css:p`
                  overflow: hidden;
                  color: ${c?"var(--ac-global-color-grey-500)":"inherit"};
                `,children:[s(C,{children:["repetition ",r.repetitionNumber]}),i&&e(C,{fontFamily:"mono",minWidth:0,color:c?"grey-500":"inherit",children:c?"Not run":e(ye,{maxWidth:"100%",children:(o==null?void 0:o.score)!=null?Ja(o.score):(o==null?void 0:o.label)||"--"})})]})},r.repetitionNumber)})})})}const Po=p`
  border: 1px solid var(--ac-global-border-color-dark);
  border-radius: var(--ac-global-rounding-medium);
  box-shadow: 0px 8px 8px rgba(0 0 0 / 0.05);
  width: var(--ac-global-dimension-static-size-6000);
  overflow: hidden;
  height: 100%;
`;function Ro({children:n,onTraceClick:a,copyText:t}){return e(w,{paddingX:"size-200",paddingTop:"size-200",flex:"none",children:s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[n,e("div",{css:p`
            margin-left: auto;
            padding-left: var(--ac-global-dimension-size-100);
          `,children:s(S,{direction:"row",gap:"size-100",children:[a&&s(j,{children:[e($n,{size:"S","aria-label":"View run trace",onPress:a,children:e(x,{svg:e(ml,{})})}),e(xe,{children:"View run trace"})]}),t&&e(pa,{text:t})]})})]})})}function No({experimentRun:n}){return e(w,{paddingX:"size-200",paddingTop:"size-100",paddingBottom:"size-100",flex:"none",children:e("div",{css:p`
          opacity: ${n?1:.25};
        `,children:n?e(V9,{...n}):e(z9,{})})})}function Oo({experimentRun:n}){return e(w,{paddingX:"size-100",paddingBottom:"size-100",borderBottomColor:"grey-300",borderBottomWidth:"thin",children:e(j9,{experimentRun:n})})}function B9({experiment:n,experimentRepetition:a,experimentIndex:t}){var y,v,L,k,T;const{includeRepetitions:l,openTraceDialog:i}=Qe(),{baseExperimentColor:r,getExperimentColor:o}=Fo(),c=t===0?r:o(t-1),d=g.useMemo(()=>a.experimentRun?JSON.stringify(a.experimentRun.output,null,2):void 0,[a]),u=(v=(y=a==null?void 0:a.experimentRun)==null?void 0:y.trace)==null?void 0:v.traceId,m=(k=(L=a==null?void 0:a.experimentRun)==null?void 0:L.trace)==null?void 0:k.projectId,b=u!=null&&m!=null?()=>i(u,m,"Experiment Run Trace"):void 0,f=d&&!((T=a.experimentRun)!=null&&T.error)?d:void 0;return e("div",{css:Po,children:s(S,{direction:"column",height:"100%",children:[s(Ro,{onTraceClick:b,copyText:f,children:[e("span",{css:p`
              flex: none;
            `,children:e(U,{color:c,shape:"circle"})}),e(Q,{weight:"heavy",level:3,css:p`
              min-width: 0;
            `,children:e(ye,{maxWidth:"100%",children:(n==null?void 0:n.name)??""})}),l&&s(B,{children:[e(x,{svg:e(Za,{})}),s(Q,{weight:"heavy",level:3,children:["repetition ",a.repetitionNumber]})]})]}),a!=null&&a.experimentRun?s(B,{children:[e(No,{experimentRun:a.experimentRun}),e(Oo,{experimentRun:a.experimentRun}),e(w,{flex:1,children:a.experimentRun.error?e(w,{padding:"size-200",children:a.experimentRun.error}):e(xl,{value:d??""})})]}):e(sl,{message:"Did not run"})]})})}function H9(){const{referenceOutput:n}=Qe(),a=g.useMemo(()=>JSON.stringify(n,null,2),[n]);return e("div",{css:Po,children:s(S,{direction:"column",height:"100%",children:[e(Ro,{copyText:a,children:e(Q,{weight:"heavy",level:3,children:"Reference Output"})}),e(No,{}),e(Oo,{}),e(w,{flex:1,children:e(xl,{value:a})})]})})}function xl({value:n}){return e("div",{css:p`
        height: 100%;
        width: 100%;
        & .cm-theme, // CodeMirror wrapper component
        & .cm-editor {
          height: 100%;
          width: 100%;
        }
      `,children:e(yl,{value:n})})}function j9({experimentRun:n}){const{annotationSummaries:a}=Qe();return e("ul",{css:p`
        display: grid;
        grid-template-columns:
          minmax(100px, max-content) minmax(32px, max-content)
          minmax(150px, 1fr) min-content;
        column-gap: var(--ac-global-dimension-size-100);
      `,children:a.map(t=>{var i,r;const l=(r=(i=n==null?void 0:n.annotations)==null?void 0:i.edges.find(o=>o.annotation.name===t.annotationName))==null?void 0:r.annotation;return e("li",{css:p`
              height: var(--ac-global-dimension-size-350);
              display: grid;
              grid-template-columns: subgrid;
              grid-column: 1 / -1;
            `,children:e(Z9,{annotation:l??null,annotationSummary:t})},t.annotationName)})})}function fi({annotation:n,annotationSummary:a}){const t=bl(a.annotationName),l=(n==null?void 0:n.score)!=null?bn(n==null?void 0:n.score):(n==null?void 0:n.label)||"--",i=n?nn:"div",r=p`
    opacity: 0.25;
    pointer-events: none;
  `;return s(i,{className:"button--reset",css:[p`
          cursor: pointer;
          padding: var(--ac-global-dimension-size-50)
            var(--ac-global-dimension-size-100);
          border-radius: var(--ac-global-rounding-small);
          width: 100%;
          display: grid;
          grid-template-columns: subgrid;
          grid-column: 1 / -2;
          &:hover {
            background-color: var(--ac-global-color-grey-200);
          }
        `,!n&&r],children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",justifySelf:"start",minWidth:0,maxWidth:"100%",children:[e("span",{css:p`
            flex: none;
          `,children:e(ba,{annotationName:a.annotationName})}),e(C,{color:"inherit",minWidth:0,children:e(ye,{maxWidth:"100%",children:a.annotationName})})]}),e(C,{fontFamily:"mono",justifySelf:"start",maxWidth:"100%",children:e(ye,{maxWidth:"100%",children:l})}),e(E3,{css:p`
          align-self: center;
          --mod-barloader-fill-color: ${t};
        `,value:Ic((n==null?void 0:n.score)??0,a.minScore,a.maxScore),height:"var(--ac-global-dimension-size-50)",width:"100%","aria-label":`${a.annotationName} score`})]})}function Z9({annotation:n,annotationSummary:a}){var o,c;const{openTraceDialog:t}=Qe(),l=(o=n==null?void 0:n.trace)==null?void 0:o.traceId,i=(c=n==null?void 0:n.trace)==null?void 0:c.projectId,r=l!=null&&i!=null;return s(B,{children:[n?s(we,{children:[e(fi,{annotation:n,annotationSummary:a}),s(le,{placement:"top",children:[e(tn,{}),e(me,{style:{width:400},children:e(w,{padding:"size-200",children:e(so,{annotation:n})})})]})]}):e(fi,{annotation:n,annotationSummary:a}),s(j,{children:[e($n,{size:"S",isDisabled:!r,"aria-label":"View evaluation trace",onPress:()=>{r&&t(l,i,`Evaluator Trace: ${a.annotationName}`)},children:e(x,{svg:e(ml,{})})}),e(xe,{children:"View evaluation trace"})]})]})}function U9(n){switch(n){case"OK":return"success";case"ERROR":return"danger";case"UNSET":return"grey-500";default:N()}}function G9({statusCode:n,...a}){let t=e(ql,{});const l=U9(n);switch(n){case"OK":t=e(Rr,{});break;case"ERROR":t=e(cl,{});break;case"UNSET":t=e(ql,{});break;default:N()}return e(x,{svg:t,color:l,"aria-label":n,...a})}const W9=p`
  width: 100%;
  display: flex;
  flex-direction: row;
  overflow: hidden;
  border-radius: 8px;
  gap: 2px;
`,Q9=p`
  height: 100%;
  flex-shrink: 0;
  flex-grow: 0;
`,q9=({height:n=6,segments:a,totalValue:t})=>{const l=t??a.reduce((i,r)=>i+r.value,0);return e("div",{style:{height:`${n}px`},css:W9,children:a.map(i=>{const r=l>0?i.value/l*100:0,o=i.color;return e("div",{css:Q9,style:{width:`${r}%`,backgroundColor:o}},i.name)})})};function Nh({valueLabel:n,totalValue:a,formatter:t,segments:l}){const i=s4(),r=l.map((o,c)=>({...o,color:o.color||c4(c,i)}));return s(S,{direction:"column",gap:"size-150",children:[s(S,{direction:"row",gap:"size-200",justifyContent:"space-between",children:[s(C,{weight:"heavy",children:["Total ",n]}),e(S,{direction:"row",gap:"size-400",children:e(C,{weight:"heavy",children:t(a)})})]}),e(q9,{height:6,totalValue:a,segments:r}),e(S,{direction:"column",gap:"size-100",children:r.map(o=>s(S,{direction:"row",gap:"size-200",justifyContent:"space-between",children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e("div",{style:{backgroundColor:o.color,width:8,height:8,borderRadius:"100%"}}),e(C,{weight:"heavy",children:o.name})]}),e(S,{direction:"row",gap:"size-400",children:e(C,{weight:"heavy",children:t(o.value)})})]},o.name))})]})}const X9=p`
  height: var(--ac-global-dimension-size-75);
  border-radius: 3px;
  background-color: var(--ac-global-color-grey-300);
  width: 100%;
  position: relative;
  overflow: hidden;
`,Y9=p`
  position: absolute;
  top: 0;
  bottom: 0;
`;function J9({color:n,overallTimeRange:a,spanTimeRange:t,...l}){const[i,r]=g.useMemo(()=>{const o=a.end.valueOf()-a.start.valueOf(),c=(t.start.valueOf()-a.start.valueOf())/o*100,d=(t.end.valueOf()-a.start.valueOf())/o*100;return[c,d]},[a,t]);return e("div",{className:"timeline-bar timeline-bar__track",css:X9,title:`${a.start.toLocaleString()} - ${a.end.toLocaleString()}`,...l,children:e("div",{className:"timeline-bar__bar",css:Y9,title:`${t.start.toLocaleString()} - ${t.end.toLocaleString()}`,"data-start-percentage":i,"data-end-percentage":r,style:{backgroundColor:n,left:`${i}%`,right:`${100-r}%`}})})}const $o=g.createContext(null);function Bo(){const n=g.useContext($o);if(n===null)throw new Error("useTraceTree must be used within a TraceTreeProvider");return n}function e6(n){const[a,t]=g.useState(!1),l=g.useCallback(i=>{g.startTransition(()=>{t(i)})},[]);return e($o.Provider,{value:{isCollapsed:a,setIsCollapsed:l},children:n.children})}function n6(n){const a=n.reduce((l,i)=>(l.set(i.spanId,{span:i,children:[]}),l),new Map),t=[];for(const l of n){const i=a.get(l.spanId);if(l.parentId===null||!a.has(l.parentId))t.push(i);else{const r=a.get(l.parentId);r&&r.children.push(i)}}for(const l of a.values())l.children.sort((i,r)=>new Date(i.span.startTime).valueOf()-new Date(r.span.startTime).valueOf());return t.sort((l,i)=>new Date(l.span.startTime).valueOf()-new Date(i.span.startTime).valueOf()),t}const Tl=25,Ho="300px",a6="500px",t6="800px";function Oh(n){const{spans:a,onSpanClick:t,selectedSpanNodeId:l}=n,i=n6(a),r=i[0].span,o={start:new Date(r.startTime),end:r.endTime?new Date(r.endTime):new Date};return e(e6,{children:s("div",{css:p`
          display: flex;
          flex-direction: column;
          overflow: hidden;
          height: 100%;
          align-items: stretch;
          container-type: inline-size;
        `,children:[e(l6,{}),e("ul",{css:p`
            flex: 1 1 auto;
            display: flex;
            flex-direction: column;
            width: 100%;
            overflow: auto;
            --trace-tree-nesting-indent: ${Tl}px;
            @container (width < ${Ho}) {
              --trace-tree-nesting-indent: 0;
              // Hide the collapse button
              .span-controls,
              .latency-text,
              .token-count-item,
              .span-tree-edge-connector,
              .span-tree-edge,
              .span-tree-timing {
                display: none;
                visibility: hidden;
                width: 0;
              }
              .span-node-wrap {
                padding-left: var(--ac-global-dimension-static-size-200);
              }
            }
            @container (width < ${a6}) {
              .span-tree-timing {
                display: none;
                visibility: hidden;
                width: 0;
              }
            }
            @container (width > ${t6}) {
              .span-tree-timing {
                width: 33%;
              }
            }
          `,"data-testid":"trace-tree",children:i.map(c=>e(jo,{node:c,overallTimeRange:o,onSpanClick:t,selectedSpanNodeId:l},c.span.id))})]})})}function l6(){const n=Me(i=>i.showMetricsInTraceTree),a=Me(i=>i.setShowMetricsInTraceTree),{isCollapsed:t,setIsCollapsed:l}=Bo();return e("div",{className:"trace-tree-toolbar",css:p`
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        box-sizing: border-box;
        width: 100%;
        align-items: center;
        padding: var(--ac-global-dimension-size-100);
        border-bottom: 1px solid var(--ac-global-color-grey-300);
        height: var(--ac-global-dimension-size-600);
        @container (width < ${Ho}) {
          button {
            display: none;
          }
        }
      `,children:s(S,{direction:"row",justifyContent:"space-between",alignItems:"center",flex:"none",gap:"size-100",width:"100%",children:[e(Q,{level:3,children:"Trace"}),s(S,{direction:"row",gap:"size-100",className:"trace-tree-controls",children:[s(j,{children:[e(D,{variant:"default",size:"S","aria-label":t?"Expand all":"Collapse all",onPress:()=>{l(!t)},leadingVisual:e(x,{svg:t?e(k2,{}):e(L2,{})})}),s(xe,{offset:-5,children:[e(ce,{}),t?"Expand all nested spans":"Collapse all nested spans"]})]}),s(j,{children:[e(D,{size:"S","aria-label":n?"Hide metrics in trace tree":"Show metrics in trace tree",onPress:()=>{a(!n)},leadingVisual:e(x,{svg:n?e(T2,{}):e(I2,{})})}),s(xe,{offset:-5,children:[e(ce,{}),n?"Hide metrics in trace tree":"Show metrics in trace tree"]})]})]})]})})}const i6=p`
  font-weight: 500;
  color: var(--ac-global-text-color-900);
  display: inline-block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;function jo(n){const{node:a,selectedSpanNodeId:t,onSpanClick:l,nestingLevel:i=0,overallTimeRange:r}=n,o=a.children,[c,d]=g.useState(!1),{isCollapsed:u}=Bo(),m=o.length>0,h=Me(T=>T.showMetricsInTraceTree),b=t===a.span.id,f=g.useRef(null);g.useEffect(()=>{b&&f.current&&f.current.scrollIntoView({behavior:"smooth",block:"nearest"})},[b]),g.useEffect(()=>{d(u)},[u]);const{name:y,latencyMs:v,statusCode:L,tokenCountTotal:k}=a.span;return s("div",{ref:f,children:[e("div",{role:"button",tabIndex:0,css:p`
          width: 100%;
          overflow: hidden;
          cursor: pointer;
        `,onClick:()=>{g.startTransition(()=>{l&&l(a.span)})},children:s(r6,{isSelected:t===a.span.id,nestingLevel:i,children:[s(S,{direction:"row",gap:"size-100",justifyContent:"start",alignItems:"center",flex:"1 1 auto",minWidth:0,css:p`
              overflow: hidden;
            `,children:[e(a9,{spanKind:a.span.spanKind}),e("span",{css:i6,title:y,children:y}),L==="ERROR"?e(G9,{statusCode:"ERROR",css:p`
                  font-size: var(--ac-global-font-size-m);
                `}):null,typeof k=="number"&&k>0&&h?e(m9,{tokenCountTotal:k,nodeId:a.span.id}):null]}),h?s("div",{css:d6,className:"span-tree-timing",children:[v!=null?e(Sl,{latencyMs:v,showIcon:!1,size:"XS"}):null,e(g6,{spanKind:a.span.spanKind,overallTimeRange:r,spanTimeRange:{start:new Date(a.span.startTime),end:a.span.endTime?new Date(a.span.endTime):new Date}})]}):null,e("div",{css:c6,"data-testid":"span-controls",className:"span-controls",children:m?e(m6,{isCollapsed:c,onClick:()=>{d(!c)}}):null})]})}),o.length?e("ul",{css:p`
            display: ${c?"none":"flex"};
            flex-direction: column;
          `,children:o.map((T,I)=>{const V=o[I+1];return s("li",{css:p`
                  position: relative;
                `,children:[V?e(o6,{...V.span,nestingLevel:i}):null,e(s6,{...T.span,nestingLevel:i}),e(jo,{node:T,overallTimeRange:r,onSpanClick:l,selectedSpanNodeId:t,nestingLevel:i+1})]},T.span.spanId)})}):null]})}function r6(n){return e("div",{className:$("span-node-wrap",{"is-selected":n.isSelected}),css:p`
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        gap: var(--ac-global-dimension-static-size-100);
        padding-right: var(--ac-global-dimension-static-size-100);
        padding-top: var(--ac-global-dimension-static-size-100);
        padding-bottom: var(--ac-global-dimension-static-size-100);
        border-left: 4px solid transparent;
        box-sizing: border-box;
        &:hover {
          background-color: var(--ac-global-color-grey-200);
        }
        &.is-selected {
          background-color: var(--ac-global-color-primary-100);
          border-color: var(--ac-global-color-primary-200);
        }
        & > *:first-of-type {
          margin-left: calc(
            (${n.nestingLevel} * var(--trace-tree-nesting-indent)) + 16px
          );
        }
      `,children:n.children})}function o6({statusCode:n,nestingLevel:a}){const t=n==="ERROR";return e("div",{"aria-hidden":"true","data-testid":"span-tree-edge-connector",className:"span-tree-edge-connector","data-status-code":n,css:p`
        position: absolute;
        border-left: 1px solid
          ${t?"var(--ac-global-color-danger)":"var(--ac-global-color-grey-500)"};
        z-index: ${t?1:0};
        top: 0;
        left: ${a*Tl+29}px;
        width: 42px;
        bottom: 0;
        z-index: 1;
      `})}function s6({nestingLevel:n,statusCode:a}){const t=a==="ERROR",l=t?"var(--ac-global-color-danger)":"var(--ac-global-color-grey-500)";return e("div",{"aria-hidden":"true",className:"span-tree-edge",css:p`
        position: absolute;
        border-left: 1px solid ${l};
        border-bottom: 1px solid ${l};
        z-index: ${t?1:0};
        border-radius: 0 0 0 11px;
        top: -5px;
        left: ${n*Tl+29}px;
        width: 11px;
        height: 22px;
      `})}const c6=p`
  width: 20px;
  flex: none;
`,d6=p`
  gap: var(--ac-global-dimension-static-size-100);
  width: 150px;
  transition: all 0.2s ease-in-out;
  flex: none;
  display: flex;
  flex-direction: row;
  align-items: center;
  .latency-text {
    justify-content: end !important;
    min-width: 2.5rem;
    float: right;
  }
`,u6=p`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border: none;
  background: none;
  cursor: pointer;
  color: var(--ac-global-text-color-900);
  border-radius: 4px;
  transition: transform 0.2s;
  transition: background-color 0.5s;
  flex: none;
  background-color: rgba(0, 0, 0, 0.1);
  &:hover {
    background-color: rgba(0, 0, 0, 0.3);
  }
  &.is-collapsed {
    transform: rotate(-90deg);
  }
`;function m6({isCollapsed:n,onClick:a}){return e("button",{onClick:t=>{t.stopPropagation(),t.preventDefault(),a()},className:$("button--reset collapse-toggle-button",{"is-collapsed":n}),css:u6,children:e(x,{svg:e(Kr,{})})})}function g6({spanKind:n,...a}){const t=Lo({spanKind:n});return e(J9,{color:t,...a})}function p6(n){return g.useMemo(()=>{try{const a=JSON.parse(n);return{text:JSON.stringify(a,null,2),textType:"json"}}catch{return{text:n,textType:"string"}}},[n])}function h6({children:n,preCSS:a}){const{text:t,textType:l}=p6(n);if(l==="string")return e("pre",{css:p`
          white-space: pre-wrap;
          text-wrap: wrap;
          overflow-wrap: anywhere;
          font-size: var(--ac-global-font-size-s);
          margin: 0;
          ${a}
        `,children:t});if(l==="json")return e(yl,{value:t});N()}const Zo=g.createContext(null);function Uo(){let n=g.useContext(Zo);return n===null&&(console.warn("useMarkdownMode must be used within a MarkdownDisplayProvider"),n={mode:"text",setMode:()=>{}}),n}function $h(n){const a=Me(i=>i.markdownDisplayMode),t=Me(i=>i.setMarkdownDisplayMode),l=g.useCallback(i=>{g.startTransition(()=>{t(i)})},[t]);return e(Zo.Provider,{value:{mode:a,setMode:l},children:n.children})}const f6=p`
  a {
    color: var(--ac-global-link-color);
    &:visited {
      color: var(--ac-global-link-color-visited);
    }
  }
  /* Remove the margin on the first and last paragraph */
  p:first-of-type {
    margin-top: 0;
  }
  p:last-of-type {
    margin-bottom: 0;
  }
  code {
    text-wrap: wrap;
  }
`;function b6({children:n,mode:a,margin:t="default"}){const l=t==="none"?p`
          margin: 0;
        `:p`
          margin: var(--ac-global-dimension-static-size-200);
        `;return a==="markdown"?e("div",{css:f6,children:e(Js,{remarkPlugins:[ec],css:l,children:n})}):e(h6,{preCSS:l,children:n})}function Bh({children:n,margin:a="default"}){const{mode:t}=Uo();return e(b6,{mode:t,margin:a,children:n})}const y6=["text","markdown"];function v6(n){return typeof n=="string"&&y6.includes(n)}function C6({mode:n,onModeChange:a}){return s(We,{"aria-label":"Markdown Mode",value:n,css:p`
        button {
          width: 140px;
          min-width: 140px;
        }
      `,size:"S",onChange:t=>{if(v6(t))a(t);else throw new Error(`Unknown markdown mode: ${t}`)},children:[s(D,{children:[e(Ge,{}),e(ze,{})]}),e(le,{children:s(Ie,{children:[e(oe,{id:"text",children:"Text"},"text"),e(oe,{id:"markdown",children:"Markdown"},"markdown")]})})]})}function Hh(){const{mode:n,setMode:a}=Uo();return e(C6,{mode:n,onModeChange:a})}function jh(n){const{spanKind:a,size:t="M"}=n,l=g.useMemo(()=>{let i="var(--ac-global-color-grey-300)";switch(a){case"llm":i="var(--ac-global-color-orange-500)";break;case"chain":i="var(--ac-global-color-blue-500)";break;case"retriever":i="var(--ac-global-color-seafoam-500)";break;case"reranker":i="var(--ac-global-color-celery-500)";break;case"embedding":i="var(--ac-global-color-indigo-500)";break;case"agent":i="var(--ac-global-color-grey-500)";break;case"tool":i="var(--ac-global-color-yellow-500)";break;case"evaluator":i="var(--ac-global-color-indigo-500)";break;case"guardrail":i="var(--ac-global-color-fuchsia-500)";break}return i},[a]);return e(Se,{color:l,size:t,children:a})}const Go=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"AnnotationSummaryGroup",selections:[{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[n,{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null}],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},{kind:"InlineFragment",selections:[n,a,{alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null},{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[t,l],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[n,a,t,l,{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummaries",plural:!0,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null},t],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null},a],storageKey:null}],type:"Span",abstractKey:null}})();Go.hash="1bfa3a69e85bd44da68677f8f467150a";const k6=({value:n,fallback:a="--",...t})=>n==null||typeof n!="number"||isNaN(n)?e(C,{...t,fontFamily:"mono",children:a}):s(C,{...t,children:[e("span",{"aria-label":"mean score",children:"μ "}),e("span",{className:"font-mono",children:`${bn(n)}`})]}),L6=p`
  & thead tr th {
    background-color: transparent;
  }
`;function Wo({annotations:n,children:a,width:t,meanScore:l,showFilterActions:i}){const r=g.useMemo(()=>n.filter(c=>c.label!=null||c.score!=null),[n]),o=r[0];return o?s(we,{children:[e(se,{children:e("span",{role:"button",children:a})}),e(vl,{children:s(le,{shouldCloseOnInteractOutside:()=>!0,isKeyboardDismissDisabled:!1,style:{minWidth:t},children:[e(tn,{}),e(me,{css:p`
              border-radius: var(--ac-global-radius-200);
            `,children:e(Ea,{autoFocus:!0,contain:!0,restoreFocus:!0,children:e(w,{children:s(S,{direction:"column",children:[e(w,{borderBottomWidth:"thin",borderColor:"dark",paddingX:"size-200",paddingY:"size-100",children:s(S,{width:"100%",justifyContent:"space-between",children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e(ba,{size:"M",annotationName:o.name}),e(C,{weight:"heavy",title:o.name,size:"M",children:e(ye,{maxWidth:"300px",children:o.name})})]}),s(j,{delay:0,children:[e(eo,{children:e(k6,{size:"L",value:l,fallback:null})}),s(xe,{placement:"top",children:[e(ce,{}),e(C,{children:"Mean Score"})]})]})]})}),e(w,{overflow:"auto",maxHeight:"300px",position:"relative",children:s("table",{css:p(fl,L6),children:[e("thead",{children:s("tr",{children:[e("th",{children:"author"}),e("th",{children:"label"}),e("th",{children:"score"}),i?e("th",{children:"filters"}):null]})}),e("tbody",{children:r.map(c=>{var d,u,m;return s("tr",{css:p`
                              padding-left: var(ac-global-dimensions-size-200);
                            `,children:[e("td",{children:s(S,{wrap:"nowrap",gap:"size-100",alignItems:"center",children:[e(po,{name:(d=c==null?void 0:c.user)==null?void 0:d.username,profilePictureUrl:(u=c==null?void 0:c.user)==null?void 0:u.profilePictureUrl,size:16}),e(C,{children:((m=c==null?void 0:c.user)==null?void 0:m.username)??"system"})]})}),e("td",{children:c.label?e(C,{title:c.label,children:e(ye,{maxWidth:i?"150px":"200px",children:c.label})}):"--"}),e("td",{children:c.score!=null?bn(c.score):"--"}),i?e("td",{children:e(S,{justifyContent:"end",flexGrow:1,children:e(zc,{annotation:c})})}):null]},c.id)})})]})})]})})})})]})})]}):null}const Qo=n=>{const a=F.useFragment(Go,n),{spanAnnotations:t,spanAnnotationSummaries:l}=a,i=g.useMemo(()=>l.filter(c=>c.name!=="note").sort((c,d)=>c.name.localeCompare(d.name)),[l]),r=g.useMemo(()=>t.reduce((c,d)=>(d.label==null&&d.score==null||(c[d.name]?c[d.name]=[d,...c[d.name]].sort((u,m)=>new Date(m.createdAt).getTime()-new Date(u.createdAt).getTime()):c[d.name]=[d]),c),{}),[t]),o=g.useMemo(()=>a.project.annotationConfigs.edges.reduce((c,d)=>{const u=d.node.name;return u&&d.node.annotationType==="CATEGORICAL"&&(c[u]=d.node),c},{}),[a.project.annotationConfigs]);return{sortedSummariesByName:i,annotationsByName:r,categoricalAnnotationConfigsByName:o}},S6=p`
  min-height: 20px;
  align-items: center;
  justify-content: center;
  display: flex;
`,Zh=({span:n,showFilterActions:a=!1,renderEmptyState:t})=>{const{sortedSummariesByName:l,annotationsByName:i,categoricalAnnotationConfigsByName:r}=Qo(n);return l.length===0&&t?t():e(S,{direction:"row",gap:"size-50",wrap:"wrap",children:l.map(o=>{var u;const c=(u=i[o.name])==null?void 0:u[0],d=o==null?void 0:o.meanScore;return c?e(Wo,{annotations:i[o.name],width:"500px",meanScore:d,showFilterActions:a,children:e(ro,{annotation:c,annotationDisplayPreference:"none",css:S6,clickable:!0,children:d!=null?e(Wi,{name:c.name,meanScore:d,size:"S",disableAnimation:!0,annotationConfig:r[c.name]}):null})},c.id):null})})},Uh=({span:n,renderEmptyState:a})=>{const{sortedSummariesByName:t,annotationsByName:l,categoricalAnnotationConfigsByName:i}=Qo(n);return t.length===0&&a?a():e(S,{direction:"row",gap:"size-400",children:t.map(r=>{var c;const o=(c=l[r.name])==null?void 0:c[0];return o?e(Ac,{name:o.name,children:e(Mc,{name:o.name,meanScore:r.meanScore,labelFractions:r.labelFractions,annotationConfig:i[o.name]})},o.id):null})})},w6=({hotkey:n,accept:a})=>{const t=nc();return ac(n,()=>{t==null||t.focusFirst({accept:a})},{preventDefault:!0}),null},x6=g.forwardRef(({children:n,title:a,panelProps:t,panelResizeHandleProps:l,resizable:i=!1,bordered:r=!0,disabled:o},c)=>{const d=g.useRef(null);g.useImperativeHandle(c,()=>d.current);const[u,m]=g.useState(!1),h=()=>{const b=d.current;b!=null&&b.isCollapsed()?b==null||b.expand():b==null||b.collapse()};return s(B,{children:[i&&e(jt,{...l,"data-bordered":r,css:p(vo,p`
                border-radius: var(--ac-global-rounding-small);
                opacity: 1;
                background-color: unset;
                &[data-bordered="true"] {
                  background-color: var(--ac-global-border-color-default);
                }
                &[data-panel-group-direction="vertical"] {
                  height: 1px;
                }
                &:hover,
                &:focus,
                &:active,
                &:focus-visible {
                  // Make hover target bigger
                  background-color: var(--ac-global-color-primary);
                }
                &:not([data-resize-handle-state="drag"]) ~ [data-panel] {
                  // transition: flex 0.2s ease-in-out;
                }
              `)}),e(I6,{onClick:h,collapsed:u,bordered:r,disabled:o,children:a}),e(ea,{maxSize:100,...t,ref:d,collapsible:!0,onCollapse:()=>{var b;m(!0),(b=t==null?void 0:t.onCollapse)==null||b.call(t)},onExpand:()=>{var b;m(!1),(b=t==null?void 0:t.onExpand)==null||b.call(t)},children:n})]})});x6.displayName="TitledPanel";const T6=p`
  all: unset;
  width: 100%;
  &:hover {
    cursor: pointer;
    background-color: var(--ac-global-input-field-background-color-active);
  }
  &:hover[disabled] {
    cursor: default;
    background-color: unset;
  }
  &[disabled] {
    opacity: var(--ac-opacity-disabled);
  }
  display: flex;
  align-items: center;
  gap: var(--ac-global-dimension-size-100);
  padding: var(--ac-global-dimension-size-100)
    var(--ac-global-dimension-size-50);
  font-weight: var(--px-font-weight-heavy);
  font-size: var(--ac-global-font-size-s);
  &[data-bordered="true"] {
    border-bottom: 1px solid var(--ac-global-border-color-default);
  }
  &[data-collapsed="true"] {
    border-bottom: none;
  }
`,I6=({children:n,collapsed:a,bordered:t,disabled:l,...i})=>s("button",{...i,type:"button","data-collapsed":a,"data-bordered":t,css:T6,disabled:a===void 0||l,children:[a!==void 0&&e(x,{"data-collapsed":a,svg:e(Kr,{}),css:p`
            transition: transform 0.2s ease-in-out;
            &[data-collapsed="true"] {
              transform: rotate(-90deg);
            }
          `}),n]}),qo=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"filterUserIds"},a={defaultValue:null,kind:"LocalArgument",name:"input"},t={defaultValue:null,kind:"LocalArgument",name:"name"},l={defaultValue:null,kind:"LocalArgument",name:"projectId"},i={defaultValue:null,kind:"LocalArgument",name:"spanId"},r={defaultValue:null,kind:"LocalArgument",name:"timeRange"},o=[{items:[{kind:"Variable",name:"input.0",variableName:"input"}],kind:"ListValue",name:"input"}],c=[{kind:"Variable",name:"id",variableName:"projectId"}],d=[{kind:"Variable",name:"annotationName",variableName:"name"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],u=[{kind:"Variable",name:"id",variableName:"spanId"}],m={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},h={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},b={alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null},f={kind:"InlineFragment",selections:[b],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},y={alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null},v={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},L={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},k={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},T={alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[L,k],storageKey:null},I={kind:"InlineFragment",selections:[h],type:"Node",abstractKey:"__isNode"},V={alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null},M={alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null},_={alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},H={alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},K={alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l,i,r],kind:"Fragment",metadata:null,name:"SpanAnnotationsEditorCreateAnnotationMutation",selections:[{alias:null,args:o,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"createSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"project",args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:d,kind:"FragmentSpread",name:"AnnotationSummaryValueFragment"}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:u,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"AnnotationSummaryGroup"},{args:null,kind:"FragmentSpread",name:"TraceHeaderRootSpanAnnotationsFragment"},{args:[{kind:"Variable",name:"filterUserIds",variableName:"filterUserIds"}],kind:"FragmentSpread",name:"SpanAnnotationsEditor_spanAnnotations"},{args:null,kind:"FragmentSpread",name:"SpanAsideAnnotationList_span"},{args:null,kind:"FragmentSpread",name:"SpanFeedback_annotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,a,i,n,r,l],kind:"Operation",name:"SpanAnnotationsEditorCreateAnnotationMutation",selections:[{alias:null,args:o,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"createSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"project",args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[m,h,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[m,f,{kind:"InlineFragment",selections:[b,h,y,v,T],type:"CategoricalAnnotationConfig",abstractKey:null},I],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:d,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummary",plural:!1,selections:[v,{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[L,V],storageKey:null},M],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:u,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[m,h,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[h,{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[m,f,{kind:"InlineFragment",selections:[h,v,y,T],type:"CategoricalAnnotationConfig",abstractKey:null},I],storageKey:null}],storageKey:null},{alias:"configs",args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"config",args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[m,I,{kind:"InlineFragment",selections:[v],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[h,v,L,k,_,H,{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},h],storageKey:null},K,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"identifier",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"source",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"updatedAt",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummaries",plural:!0,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[V,L],storageKey:null},M,v],storageKey:null},{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Variable",name:"userIds",variableName:"filterUserIds"}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[h,v,_,k,L,K,H],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"fe4bd60106516a1dd9a0d9b6b9d705cb",id:null,metadata:{},name:"SpanAnnotationsEditorCreateAnnotationMutation",operationKind:"mutation",text:`mutation SpanAnnotationsEditorCreateAnnotationMutation(
  $name: String!
  $input: CreateSpanAnnotationInput!
  $spanId: ID!
  $filterUserIds: [ID]
  $timeRange: TimeRange!
  $projectId: ID!
) {
  createSpanAnnotations(input: [$input]) {
    query {
      project: node(id: $projectId) {
        __typename
        ... on Project {
          ...AnnotationSummaryValueFragment_20r1YH
        }
        id
      }
      node(id: $spanId) {
        __typename
        ... on Span {
          ...AnnotationSummaryGroup
          ...TraceHeaderRootSpanAnnotationsFragment
          ...SpanAnnotationsEditor_spanAnnotations_3lpqY
          ...SpanAsideAnnotationList_span
          ...SpanFeedback_annotations
        }
        id
      }
    }
  }
}

fragment AnnotationSummaryGroup on Span {
  project {
    id
    annotationConfigs {
      edges {
        node {
          __typename
          ... on AnnotationConfigBase {
            __isAnnotationConfigBase: __typename
            annotationType
          }
          ... on CategoricalAnnotationConfig {
            id
            name
            optimizationDirection
            values {
              label
              score
            }
          }
          ... on Node {
            __isNode: __typename
            id
          }
        }
      }
    }
  }
  spanAnnotations {
    id
    name
    label
    score
    annotatorKind
    createdAt
    user {
      username
      profilePictureUrl
      id
    }
  }
  spanAnnotationSummaries {
    labelFractions {
      fraction
      label
    }
    meanScore
    name
  }
}

fragment AnnotationSummaryValueFragment_20r1YH on Project {
  annotationConfigs {
    edges {
      node {
        __typename
        ... on AnnotationConfigBase {
          __isAnnotationConfigBase: __typename
          annotationType
        }
        ... on CategoricalAnnotationConfig {
          annotationType
          id
          optimizationDirection
          name
          values {
            label
            score
          }
        }
        ... on Node {
          __isNode: __typename
          id
        }
      }
    }
  }
  spanAnnotationSummary(annotationName: $name, timeRange: $timeRange) {
    name
    labelFractions {
      label
      fraction
    }
    meanScore
  }
  id
}

fragment SpanAnnotationsEditor_spanAnnotations_3lpqY on Span {
  id
  filteredSpanAnnotations: spanAnnotations(filter: {exclude: {names: ["note"]}, include: {userIds: $filterUserIds}}) {
    id
    name
    annotatorKind
    score
    label
    explanation
    createdAt
  }
}

fragment SpanAsideAnnotationList_span on Span {
  project {
    id
    annotationConfigs {
      configs: edges {
        config: node {
          __typename
          ... on Node {
            __isNode: __typename
            id
          }
          ... on AnnotationConfigBase {
            __isAnnotationConfigBase: __typename
            name
          }
        }
      }
    }
  }
  spanAnnotations {
    id
  }
  ...AnnotationSummaryGroup
}

fragment SpanFeedback_annotations on Span {
  id
  spanAnnotations {
    id
    name
    label
    score
    explanation
    metadata
    annotatorKind
    identifier
    source
    createdAt
    updatedAt
    user {
      id
      username
      profilePictureUrl
    }
  }
}

fragment TraceHeaderRootSpanAnnotationsFragment on Span {
  ...AnnotationSummaryGroup
}
`}}})();qo.hash="470188a966012ed4819c3644e1463a4f";const Xo=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"annotationId"},a={defaultValue:null,kind:"LocalArgument",name:"explanation"},t={defaultValue:null,kind:"LocalArgument",name:"filterUserIds"},l={defaultValue:null,kind:"LocalArgument",name:"label"},i={defaultValue:null,kind:"LocalArgument",name:"name"},r={defaultValue:null,kind:"LocalArgument",name:"projectId"},o={defaultValue:null,kind:"LocalArgument",name:"score"},c={defaultValue:null,kind:"LocalArgument",name:"spanId"},d={defaultValue:null,kind:"LocalArgument",name:"timeRange"},u=[{items:[{fields:[{kind:"Variable",name:"annotationId",variableName:"annotationId"},{kind:"Literal",name:"annotatorKind",value:"HUMAN"},{kind:"Variable",name:"explanation",variableName:"explanation"},{kind:"Variable",name:"label",variableName:"label"},{kind:"Variable",name:"name",variableName:"name"},{kind:"Variable",name:"score",variableName:"score"},{kind:"Literal",name:"source",value:"APP"}],kind:"ObjectValue",name:"input.0"}],kind:"ListValue",name:"input"}],m=[{kind:"Variable",name:"id",variableName:"projectId"}],h=[{kind:"Variable",name:"annotationName",variableName:"name"},{kind:"Variable",name:"timeRange",variableName:"timeRange"}],b=[{kind:"Variable",name:"id",variableName:"spanId"}],f={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},y={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},v={alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null},L={kind:"InlineFragment",selections:[v],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},k={alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null},T={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},I={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},V={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},M={alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[I,V],storageKey:null},_={kind:"InlineFragment",selections:[y],type:"Node",abstractKey:"__isNode"},H={alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null},K={alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null},A={alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},O={alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},R={alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l,i,r,o,c,d],kind:"Fragment",metadata:null,name:"SpanAnnotationsEditorEditAnnotationMutation",selections:[{alias:null,args:u,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"patchSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"project",args:m,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:h,kind:"FragmentSpread",name:"AnnotationSummaryValueFragment"}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:b,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"AnnotationSummaryGroup"},{args:null,kind:"FragmentSpread",name:"TraceHeaderRootSpanAnnotationsFragment"},{args:[{kind:"Variable",name:"filterUserIds",variableName:"filterUserIds"}],kind:"FragmentSpread",name:"SpanAnnotationsEditor_spanAnnotations"},{args:null,kind:"FragmentSpread",name:"SpanAsideAnnotationList_span"},{args:null,kind:"FragmentSpread",name:"SpanFeedback_annotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[c,n,i,l,o,a,t,d,r],kind:"Operation",name:"SpanAnnotationsEditorEditAnnotationMutation",selections:[{alias:null,args:u,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"patchSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"project",args:m,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[f,y,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[f,L,{kind:"InlineFragment",selections:[v,y,k,T,M],type:"CategoricalAnnotationConfig",abstractKey:null},_],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:h,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummary",plural:!1,selections:[T,{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[I,H],storageKey:null},K],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:b,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[f,y,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[y,{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[f,L,{kind:"InlineFragment",selections:[y,T,k,M],type:"CategoricalAnnotationConfig",abstractKey:null},_],storageKey:null}],storageKey:null},{alias:"configs",args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"config",args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[f,_,{kind:"InlineFragment",selections:[T],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[y,T,I,V,A,O,{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},y],storageKey:null},R,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"identifier",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"source",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"updatedAt",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummaries",plural:!0,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[H,I],storageKey:null},K,T],storageKey:null},{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Variable",name:"userIds",variableName:"filterUserIds"}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[y,T,A,V,I,R,O],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"21f32f0823e2e9f883d1c332004c1559",id:null,metadata:{},name:"SpanAnnotationsEditorEditAnnotationMutation",operationKind:"mutation",text:`mutation SpanAnnotationsEditorEditAnnotationMutation(
  $spanId: ID!
  $annotationId: ID!
  $name: String!
  $label: String
  $score: Float
  $explanation: String
  $filterUserIds: [ID]
  $timeRange: TimeRange!
  $projectId: ID!
) {
  patchSpanAnnotations(input: [{annotationId: $annotationId, name: $name, label: $label, score: $score, explanation: $explanation, annotatorKind: HUMAN, source: APP}]) {
    query {
      project: node(id: $projectId) {
        __typename
        ... on Project {
          ...AnnotationSummaryValueFragment_20r1YH
        }
        id
      }
      node(id: $spanId) {
        __typename
        ... on Span {
          ...AnnotationSummaryGroup
          ...TraceHeaderRootSpanAnnotationsFragment
          ...SpanAnnotationsEditor_spanAnnotations_3lpqY
          ...SpanAsideAnnotationList_span
          ...SpanFeedback_annotations
        }
        id
      }
    }
  }
}

fragment AnnotationSummaryGroup on Span {
  project {
    id
    annotationConfigs {
      edges {
        node {
          __typename
          ... on AnnotationConfigBase {
            __isAnnotationConfigBase: __typename
            annotationType
          }
          ... on CategoricalAnnotationConfig {
            id
            name
            optimizationDirection
            values {
              label
              score
            }
          }
          ... on Node {
            __isNode: __typename
            id
          }
        }
      }
    }
  }
  spanAnnotations {
    id
    name
    label
    score
    annotatorKind
    createdAt
    user {
      username
      profilePictureUrl
      id
    }
  }
  spanAnnotationSummaries {
    labelFractions {
      fraction
      label
    }
    meanScore
    name
  }
}

fragment AnnotationSummaryValueFragment_20r1YH on Project {
  annotationConfigs {
    edges {
      node {
        __typename
        ... on AnnotationConfigBase {
          __isAnnotationConfigBase: __typename
          annotationType
        }
        ... on CategoricalAnnotationConfig {
          annotationType
          id
          optimizationDirection
          name
          values {
            label
            score
          }
        }
        ... on Node {
          __isNode: __typename
          id
        }
      }
    }
  }
  spanAnnotationSummary(annotationName: $name, timeRange: $timeRange) {
    name
    labelFractions {
      label
      fraction
    }
    meanScore
  }
  id
}

fragment SpanAnnotationsEditor_spanAnnotations_3lpqY on Span {
  id
  filteredSpanAnnotations: spanAnnotations(filter: {exclude: {names: ["note"]}, include: {userIds: $filterUserIds}}) {
    id
    name
    annotatorKind
    score
    label
    explanation
    createdAt
  }
}

fragment SpanAsideAnnotationList_span on Span {
  project {
    id
    annotationConfigs {
      configs: edges {
        config: node {
          __typename
          ... on Node {
            __isNode: __typename
            id
          }
          ... on AnnotationConfigBase {
            __isAnnotationConfigBase: __typename
            name
          }
        }
      }
    }
  }
  spanAnnotations {
    id
  }
  ...AnnotationSummaryGroup
}

fragment SpanFeedback_annotations on Span {
  id
  spanAnnotations {
    id
    name
    label
    score
    explanation
    metadata
    annotatorKind
    identifier
    source
    createdAt
    updatedAt
    user {
      id
      username
      profilePictureUrl
    }
  }
}

fragment TraceHeaderRootSpanAnnotationsFragment on Span {
  ...AnnotationSummaryGroup
}
`}}})();Xo.hash="2e32eb892ace0745b83b66da87e6e76e";const Yo=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"annotationIds"},a={defaultValue:null,kind:"LocalArgument",name:"filterUserIds"},t={defaultValue:null,kind:"LocalArgument",name:"projectId"},l={defaultValue:null,kind:"LocalArgument",name:"spanId"},i={defaultValue:null,kind:"LocalArgument",name:"timeRange"},r=[{fields:[{kind:"Variable",name:"annotationIds",variableName:"annotationIds"}],kind:"ObjectValue",name:"input"}],o=[{kind:"Variable",name:"id",variableName:"projectId"}],c=[{kind:"Variable",name:"id",variableName:"spanId"}],d={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},m={kind:"Variable",name:"timeRange",variableName:"timeRange"},h=[m],b=[{alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null}],f={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},y={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},v={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},L={kind:"InlineFragment",selections:[u],type:"Node",abstractKey:"__isNode"},k={alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},T={alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null},I={alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l,i],kind:"Fragment",metadata:null,name:"SpanAnnotationsEditorDeleteAnnotationMutation",selections:[{alias:null,args:r,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"deleteSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"project",args:o,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"ProjectPageHeader_stats"}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"AnnotationSummaryGroup"},{args:null,kind:"FragmentSpread",name:"TraceHeaderRootSpanAnnotationsFragment"},{args:[{kind:"Variable",name:"filterUserIds",variableName:"filterUserIds"}],kind:"FragmentSpread",name:"SpanAnnotationsEditor_spanAnnotations"},{args:null,kind:"FragmentSpread",name:"SpanAsideAnnotationList_span"},{args:null,kind:"FragmentSpread",name:"SpanFeedback_annotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[l,n,i,t,a],kind:"Operation",name:"SpanAnnotationsEditorDeleteAnnotationMutation",selections:[{alias:null,args:r,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"deleteSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"project",args:o,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,u,{kind:"InlineFragment",selections:[{alias:null,args:h,kind:"ScalarField",name:"traceCount",storageKey:null},{alias:null,args:h,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:b,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:b,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:b,storageKey:null}],storageKey:null},{alias:"latencyMsP50",args:[{kind:"Literal",name:"probability",value:.5},m],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:"latencyMsP99",args:[{kind:"Literal",name:"probability",value:.99},m],kind:"ScalarField",name:"latencyMsQuantile",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"spanAnnotationNames",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"documentEvaluationNames",storageKey:null}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,u,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[u,{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null}],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},{kind:"InlineFragment",selections:[u,f,{alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null},{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[y,v],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null},L],storageKey:null}],storageKey:null},{alias:"configs",args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"config",args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,L,{kind:"InlineFragment",selections:[f],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[u,f,y,v,k,T,{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null},u],storageKey:null},I,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"identifier",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"source",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"updatedAt",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"AnnotationSummary",kind:"LinkedField",name:"spanAnnotationSummaries",plural:!0,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null},y],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null},f],storageKey:null},{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Variable",name:"userIds",variableName:"filterUserIds"}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[u,f,k,v,y,I,T],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"dee76f16722e918832123373a1155240",id:null,metadata:{},name:"SpanAnnotationsEditorDeleteAnnotationMutation",operationKind:"mutation",text:`mutation SpanAnnotationsEditorDeleteAnnotationMutation(
  $spanId: ID!
  $annotationIds: [ID!]!
  $timeRange: TimeRange!
  $projectId: ID!
  $filterUserIds: [ID]
) {
  deleteSpanAnnotations(input: {annotationIds: $annotationIds}) {
    query {
      project: node(id: $projectId) {
        __typename
        ... on Project {
          ...ProjectPageHeader_stats
        }
        id
      }
      node(id: $spanId) {
        __typename
        ... on Span {
          ...AnnotationSummaryGroup
          ...TraceHeaderRootSpanAnnotationsFragment
          ...SpanAnnotationsEditor_spanAnnotations_3lpqY
          ...SpanAsideAnnotationList_span
          ...SpanFeedback_annotations
        }
        id
      }
    }
  }
}

fragment AnnotationSummaryGroup on Span {
  project {
    id
    annotationConfigs {
      edges {
        node {
          __typename
          ... on AnnotationConfigBase {
            __isAnnotationConfigBase: __typename
            annotationType
          }
          ... on CategoricalAnnotationConfig {
            id
            name
            optimizationDirection
            values {
              label
              score
            }
          }
          ... on Node {
            __isNode: __typename
            id
          }
        }
      }
    }
  }
  spanAnnotations {
    id
    name
    label
    score
    annotatorKind
    createdAt
    user {
      username
      profilePictureUrl
      id
    }
  }
  spanAnnotationSummaries {
    labelFractions {
      fraction
      label
    }
    meanScore
    name
  }
}

fragment ProjectPageHeader_stats on Project {
  traceCount(timeRange: $timeRange)
  costSummary(timeRange: $timeRange) {
    total {
      cost
    }
    prompt {
      cost
    }
    completion {
      cost
    }
  }
  latencyMsP50: latencyMsQuantile(probability: 0.5, timeRange: $timeRange)
  latencyMsP99: latencyMsQuantile(probability: 0.99, timeRange: $timeRange)
  spanAnnotationNames
  documentEvaluationNames
  id
}

fragment SpanAnnotationsEditor_spanAnnotations_3lpqY on Span {
  id
  filteredSpanAnnotations: spanAnnotations(filter: {exclude: {names: ["note"]}, include: {userIds: $filterUserIds}}) {
    id
    name
    annotatorKind
    score
    label
    explanation
    createdAt
  }
}

fragment SpanAsideAnnotationList_span on Span {
  project {
    id
    annotationConfigs {
      configs: edges {
        config: node {
          __typename
          ... on Node {
            __isNode: __typename
            id
          }
          ... on AnnotationConfigBase {
            __isAnnotationConfigBase: __typename
            name
          }
        }
      }
    }
  }
  spanAnnotations {
    id
  }
  ...AnnotationSummaryGroup
}

fragment SpanFeedback_annotations on Span {
  id
  spanAnnotations {
    id
    name
    label
    score
    explanation
    metadata
    annotatorKind
    identifier
    source
    createdAt
    updatedAt
    user {
      id
      username
      profilePictureUrl
    }
  }
}

fragment TraceHeaderRootSpanAnnotationsFragment on Span {
  ...AnnotationSummaryGroup
}
`}}})();Yo.hash="91b4801afce840fdac7250d2c84eff21";const Jo=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[{defaultValue:null,kind:"LocalArgument",name:"filterUserIds"}],kind:"Fragment",metadata:null,name:"SpanAnnotationsEditor_spanAnnotations",selections:[n,{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Variable",name:"userIds",variableName:"filterUserIds"}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[n,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}})();Jo.hash="e1133bf8aec8eadedaa01c3c4170bfe9";const e1=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"filterUserIds"},a={defaultValue:null,kind:"LocalArgument",name:"projectId"},t={defaultValue:null,kind:"LocalArgument",name:"spanId"},l=[{kind:"Variable",name:"id",variableName:"projectId"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},o={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},c={alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null},d={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},m={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:"configs",args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"config",args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[r,{kind:"InlineFragment",selections:[i],type:"Node",abstractKey:"__isNode"},{kind:"InlineFragment",selections:[o,{alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null}],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},{kind:"InlineFragment",selections:[c,{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[d,u],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"lowerBound",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"upperBound",storageKey:null},c],type:"ContinuousAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[o],type:"FreeformAnnotationConfig",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Project",abstractKey:null},h=[{kind:"Variable",name:"id",variableName:"spanId"}];return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"SpanAnnotationsEditorSpanAnnotationsListQuery",selections:[{alias:"project",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,m],storageKey:null},{alias:"span",args:h,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,{kind:"InlineFragment",selections:[{args:[{kind:"Variable",name:"filterUserIds",variableName:"filterUserIds"}],kind:"FragmentSpread",name:"SpanAnnotationsEditor_spanAnnotations"}],type:"Span",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,t,n],kind:"Operation",name:"SpanAnnotationsEditorSpanAnnotationsListQuery",selections:[{alias:"project",args:l,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[r,i,m],storageKey:null},{alias:"span",args:h,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[r,i,{kind:"InlineFragment",selections:[{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Variable",name:"userIds",variableName:"filterUserIds"}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[i,o,{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},u,d,{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}]},params:{cacheID:"c19b9cff9a85b67ea4db4f43b28d1fd3",id:null,metadata:{},name:"SpanAnnotationsEditorSpanAnnotationsListQuery",operationKind:"query",text:`query SpanAnnotationsEditorSpanAnnotationsListQuery(
  $projectId: ID!
  $spanId: ID!
  $filterUserIds: [ID]
) {
  project: node(id: $projectId) {
    __typename
    id
    ... on Project {
      annotationConfigs {
        configs: edges {
          config: node {
            __typename
            ... on Node {
              __isNode: __typename
              id
            }
            ... on AnnotationConfigBase {
              __isAnnotationConfigBase: __typename
              name
              annotationType
              description
            }
            ... on CategoricalAnnotationConfig {
              optimizationDirection
              values {
                label
                score
              }
            }
            ... on ContinuousAnnotationConfig {
              lowerBound
              upperBound
              optimizationDirection
            }
            ... on FreeformAnnotationConfig {
              name
            }
          }
        }
      }
    }
  }
  span: node(id: $spanId) {
    __typename
    id
    ... on Span {
      ...SpanAnnotationsEditor_spanAnnotations_3lpqY
    }
  }
}

fragment SpanAnnotationsEditor_spanAnnotations_3lpqY on Span {
  id
  filteredSpanAnnotations: spanAnnotations(filter: {exclude: {names: ["note"]}, include: {userIds: $filterUserIds}}) {
    id
    name
    annotatorKind
    score
    label
    explanation
    createdAt
  }
}
`}}})();e1.hash="ab94a265160b38df3c4310317a5ca86b";const n1=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"annotationConfigId"},a={defaultValue:null,kind:"LocalArgument",name:"filterUserIds"},t={defaultValue:null,kind:"LocalArgument",name:"projectId"},l={defaultValue:null,kind:"LocalArgument",name:"spanId"},i=[{fields:[{kind:"Variable",name:"annotationConfigId",variableName:"annotationConfigId"},{kind:"Variable",name:"projectId",variableName:"projectId"}],kind:"ObjectValue",name:"input"}],r=[{kind:"Variable",name:"id",variableName:"projectId"}],o={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},c=[{kind:"Variable",name:"id",variableName:"spanId"}],d={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},m={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},h={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l],kind:"Fragment",metadata:null,name:"AnnotationConfigListRemoveAnnotationConfigFromProjectMutation",selections:[{alias:null,args:i,concreteType:"RemoveAnnotationConfigFromProjectPayload",kind:"LinkedField",name:"removeAnnotationConfigFromProject",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"projectNode",args:r,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[o,{args:null,kind:"FragmentSpread",name:"AnnotationConfigListProjectAnnotationConfigFragment"}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[o,{args:[{kind:"Variable",name:"filterUserIds",variableName:"filterUserIds"}],kind:"FragmentSpread",name:"SpanAnnotationsEditor_spanAnnotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,n,l,a],kind:"Operation",name:"AnnotationConfigListRemoveAnnotationConfigFromProjectMutation",selections:[{alias:null,args:i,concreteType:"RemoveAnnotationConfigFromProjectPayload",kind:"LinkedField",name:"removeAnnotationConfigFromProject",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"projectNode",args:r,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,o,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,{kind:"InlineFragment",selections:[o],type:"Node",abstractKey:"__isNode"},{kind:"InlineFragment",selections:[u,{alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null}],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[m,h],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"lowerBound",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"upperBound",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null}],type:"ContinuousAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[u],type:"FreeformAnnotationConfig",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,o,{kind:"InlineFragment",selections:[{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Variable",name:"userIds",variableName:"filterUserIds"}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[o,u,{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},h,m,{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"ac0ee63febc8956acc1d1b43505591c3",id:null,metadata:{},name:"AnnotationConfigListRemoveAnnotationConfigFromProjectMutation",operationKind:"mutation",text:`mutation AnnotationConfigListRemoveAnnotationConfigFromProjectMutation(
  $projectId: ID!
  $annotationConfigId: ID!
  $spanId: ID!
  $filterUserIds: [ID!]
) {
  removeAnnotationConfigFromProject(input: {projectId: $projectId, annotationConfigId: $annotationConfigId}) {
    query {
      projectNode: node(id: $projectId) {
        __typename
        ... on Project {
          id
          ...AnnotationConfigListProjectAnnotationConfigFragment
        }
        id
      }
      node(id: $spanId) {
        __typename
        ... on Span {
          id
          ...SpanAnnotationsEditor_spanAnnotations_3lpqY
        }
        id
      }
    }
  }
}

fragment AnnotationConfigListProjectAnnotationConfigFragment on Project {
  annotationConfigs {
    edges {
      node {
        __typename
        ... on Node {
          __isNode: __typename
          id
        }
        ... on AnnotationConfigBase {
          __isAnnotationConfigBase: __typename
          name
          annotationType
          description
        }
        ... on CategoricalAnnotationConfig {
          values {
            label
            score
          }
        }
        ... on ContinuousAnnotationConfig {
          lowerBound
          upperBound
          optimizationDirection
        }
        ... on FreeformAnnotationConfig {
          name
        }
      }
    }
  }
}

fragment SpanAnnotationsEditor_spanAnnotations_3lpqY on Span {
  id
  filteredSpanAnnotations: spanAnnotations(filter: {exclude: {names: ["note"]}, include: {userIds: $filterUserIds}}) {
    id
    name
    annotatorKind
    score
    label
    explanation
    createdAt
  }
}
`}}})();n1.hash="95e97ce45fd2d56bb67fbdb8fd683092";const a1=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"annotationConfigId"},a={defaultValue:null,kind:"LocalArgument",name:"filterUserIds"},t={defaultValue:null,kind:"LocalArgument",name:"projectId"},l={defaultValue:null,kind:"LocalArgument",name:"spanId"},i=[{fields:[{kind:"Variable",name:"annotationConfigId",variableName:"annotationConfigId"},{kind:"Variable",name:"projectId",variableName:"projectId"}],kind:"ObjectValue",name:"input"}],r=[{kind:"Variable",name:"id",variableName:"projectId"}],o={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},c=[{kind:"Variable",name:"id",variableName:"spanId"}],d={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},m={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},h={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l],kind:"Fragment",metadata:null,name:"AnnotationConfigListAssociateAnnotationConfigWithProjectMutation",selections:[{alias:null,args:i,concreteType:"AddAnnotationConfigToProjectPayload",kind:"LinkedField",name:"addAnnotationConfigToProject",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"projectNode",args:r,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[o,{args:null,kind:"FragmentSpread",name:"AnnotationConfigListProjectAnnotationConfigFragment"}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[o,{args:[{kind:"Variable",name:"filterUserIds",variableName:"filterUserIds"}],kind:"FragmentSpread",name:"SpanAnnotationsEditor_spanAnnotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,n,l,a],kind:"Operation",name:"AnnotationConfigListAssociateAnnotationConfigWithProjectMutation",selections:[{alias:null,args:i,concreteType:"AddAnnotationConfigToProjectPayload",kind:"LinkedField",name:"addAnnotationConfigToProject",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:"projectNode",args:r,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,o,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,{kind:"InlineFragment",selections:[o],type:"Node",abstractKey:"__isNode"},{kind:"InlineFragment",selections:[u,{alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null}],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[m,h],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"lowerBound",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"upperBound",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null}],type:"ContinuousAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[u],type:"FreeformAnnotationConfig",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Project",abstractKey:null}],storageKey:null},{alias:null,args:c,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[d,o,{kind:"InlineFragment",selections:[{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Variable",name:"userIds",variableName:"filterUserIds"}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[o,u,{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},h,m,{alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"d50c07c47d622752dd477d5d58dcab08",id:null,metadata:{},name:"AnnotationConfigListAssociateAnnotationConfigWithProjectMutation",operationKind:"mutation",text:`mutation AnnotationConfigListAssociateAnnotationConfigWithProjectMutation(
  $projectId: ID!
  $annotationConfigId: ID!
  $spanId: ID!
  $filterUserIds: [ID!]
) {
  addAnnotationConfigToProject(input: {projectId: $projectId, annotationConfigId: $annotationConfigId}) {
    query {
      projectNode: node(id: $projectId) {
        __typename
        ... on Project {
          id
          ...AnnotationConfigListProjectAnnotationConfigFragment
        }
        id
      }
      node(id: $spanId) {
        __typename
        ... on Span {
          id
          ...SpanAnnotationsEditor_spanAnnotations_3lpqY
        }
        id
      }
    }
  }
}

fragment AnnotationConfigListProjectAnnotationConfigFragment on Project {
  annotationConfigs {
    edges {
      node {
        __typename
        ... on Node {
          __isNode: __typename
          id
        }
        ... on AnnotationConfigBase {
          __isAnnotationConfigBase: __typename
          name
          annotationType
          description
        }
        ... on CategoricalAnnotationConfig {
          values {
            label
            score
          }
        }
        ... on ContinuousAnnotationConfig {
          lowerBound
          upperBound
          optimizationDirection
        }
        ... on FreeformAnnotationConfig {
          name
        }
      }
    }
  }
}

fragment SpanAnnotationsEditor_spanAnnotations_3lpqY on Span {
  id
  filteredSpanAnnotations: spanAnnotations(filter: {exclude: {names: ["note"]}, include: {userIds: $filterUserIds}}) {
    id
    name
    annotatorKind
    score
    label
    explanation
    createdAt
  }
}
`}}})();a1.hash="c0bef9fb6b65e0bb572ed9c7d42a0905";const t1=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"AnnotationConfigListProjectAnnotationConfigFragment",selections:[{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],type:"Node",abstractKey:"__isNode"},{kind:"InlineFragment",selections:[n,{alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null}],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null}],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"lowerBound",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"upperBound",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null}],type:"ContinuousAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[n],type:"FreeformAnnotationConfig",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Project",abstractKey:null}})();t1.hash="7bed597e9a0dc874ed67506a8a4f870c";const l1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"projectId"}],a=[{kind:"Variable",name:"id",variableName:"projectId"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={kind:"InlineFragment",selections:[t],type:"Node",abstractKey:"__isNode"},i={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},o={alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null},c={kind:"InlineFragment",selections:[i,r,o],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},d={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null}],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null},u={alias:null,args:null,kind:"ScalarField",name:"lowerBound",storageKey:null},m={alias:null,args:null,kind:"ScalarField",name:"upperBound",storageKey:null},h={kind:"InlineFragment",selections:[u,m],type:"ContinuousAnnotationConfig",abstractKey:null},b={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"AnnotationConfigListQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"AnnotationConfigListProjectAnnotationConfigFragment"}],type:"Project",abstractKey:null}],storageKey:null},{alias:"allAnnotationConfigs",args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[l,c,d,h],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"AnnotationConfigListQuery",selections:[{alias:"project",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[b,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[b,l,{kind:"InlineFragment",selections:[i,o,r],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},d,{kind:"InlineFragment",selections:[u,m,{alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null}],type:"ContinuousAnnotationConfig",abstractKey:null},{kind:"InlineFragment",selections:[i],type:"FreeformAnnotationConfig",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Project",abstractKey:null},t],storageKey:null},{alias:"allAnnotationConfigs",args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[b,l,c,d,h],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"1a712d6939eff6b3fc74c42fdf542bda",id:null,metadata:{},name:"AnnotationConfigListQuery",operationKind:"query",text:`query AnnotationConfigListQuery(
  $projectId: ID!
) {
  project: node(id: $projectId) {
    __typename
    ... on Project {
      ...AnnotationConfigListProjectAnnotationConfigFragment
    }
    id
  }
  allAnnotationConfigs: annotationConfigs {
    edges {
      node {
        __typename
        ... on Node {
          __isNode: __typename
          id
        }
        ... on AnnotationConfigBase {
          __isAnnotationConfigBase: __typename
          name
          description
          annotationType
        }
        ... on CategoricalAnnotationConfig {
          values {
            label
            score
          }
        }
        ... on ContinuousAnnotationConfig {
          lowerBound
          upperBound
        }
      }
    }
  }
}

fragment AnnotationConfigListProjectAnnotationConfigFragment on Project {
  annotationConfigs {
    edges {
      node {
        __typename
        ... on Node {
          __isNode: __typename
          id
        }
        ... on AnnotationConfigBase {
          __isAnnotationConfigBase: __typename
          name
          annotationType
          description
        }
        ... on CategoricalAnnotationConfig {
          values {
            label
            score
          }
        }
        ... on ContinuousAnnotationConfig {
          lowerBound
          upperBound
          optimizationDirection
        }
        ... on FreeformAnnotationConfig {
          name
        }
      }
    }
  }
}
`}}})();l1.hash="17e291625e2df97c80e95916c0df269d";const z6=p`
  height: 300px;
  width: 320px;
  overflow-y: auto;
`;function A6(n){const{projectId:a,spanId:t}=n,[l,i]=g.useState(""),{viewer:r}=kn(),o=r==null?void 0:r.id,c=F.useLazyLoadQuery(l1,{projectId:a}),d=F.useFragment(t1,c.project),[u]=F.useMutation(a1),[m]=F.useMutation(n1),h=g.useCallback(T=>{g.startTransition(()=>{u({variables:{projectId:a,annotationConfigId:T,spanId:t,filterUserIds:o?[o]:null}})})},[a,u,t,o]),b=g.useCallback(T=>{m({variables:{projectId:a,annotationConfigId:T,spanId:t,filterUserIds:o?[o]:null}})},[a,m,t,o]),f=c.allAnnotationConfigs.edges,y=g.useMemo(()=>{var T;return((T=d.annotationConfigs)==null?void 0:T.edges)||[]},[d]),v=g.useMemo(()=>{const T=y.map(I=>I.node.id).filter(Nn.isString);return new Set(T)},[y]),L=g.useMemo(()=>f.filter(T=>{var I;return(I=T.node.name)==null?void 0:I.toLowerCase().includes(l.toLowerCase())}),[f,l]),k=g.useCallback(T=>{L.forEach(I=>{I.node.id&&(T.has(I.node.id)&&!v.has(I.node.id)?h(I.node.id):!T.has(I.node.id)&&v.has(I.node.id)&&b(I.node.id))})},[L,h,b,v]);return e(Ea,{autoFocus:!0,contain:!0,children:e(w,{padding:"size-100",minWidth:300,children:s(S,{direction:"column",gap:"size-100",children:[s(S,{direction:"column",gap:"size-100",children:[e(Q,{level:4,weight:"heavy",children:"Add Annotations"}),e(hl,{"aria-label":"Search annotation configs",onChange:i,placeholder:"Search annotation configs"})]}),e(Ie,{css:z6,selectionMode:"multiple",selectionBehavior:"toggle","aria-label":"Annotation Configs",selectedKeys:v,renderEmptyState:()=>e(w,{width:"100%",height:"100%",paddingBottom:"size-100",children:e(S,{direction:"column",alignItems:"center",justifyContent:"center",children:l?s(C,{color:"text-700",style:{whiteSpace:"pre-wrap",textAlign:"center",padding:0},children:['No annotation configs found for "',l,'"']}):e(ja,{to:"/settings/annotations",children:"Configure Annotation Configs"})})}),onSelectionChange:T=>{const I=Array.from(T);k(new Set(I))},children:L.map(T=>e(Ze,{id:T.node.id,textValue:T.node.name,children:({isSelected:I})=>{var V;return s(S,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e(ba,{annotationName:T.node.name||""}),e(C,{children:T.node.name}),e(Se,{size:"S",children:(V=T.node.annotationType)==null?void 0:V.toLocaleLowerCase()})]}),I?e(x,{svg:e(Ua,{})}):null]})}},T.node.id))})]})})})}const M6=({annotation:n,annotationConfig:a,currentAnnotationIDs:t,onCreate:l,onUpdate:i,onDelete:r,children:o,onSuccess:c,onError:d})=>{const u=a.name;$t(u);const m=a.annotationType,h=g.useMemo(()=>n||{name:u,label:null,score:null,explanation:null},[n,u]),b=Oe({defaultValues:{[u]:h}}),f=b.setError,y=g.useCallback(async V=>{const M={...V[u],id:n==null?void 0:n.id};if(!M)return;let _;M.id&&m!=="FREEFORM"&&M.score==null&&!M.label||M.id&&m!=="FREEFORM"&&isNaN(M.score)&&!M.label||M.id&&m==="FREEFORM"&&!M.explanation?_="delete":M.id&&t.has(M.id)?_="update":_="create";let H;switch(_){case"create":{H=await l(M);break}case"update":{H=await i(M);break}case"delete":{H=await r(M);break}}H.success?c==null||c(M):(f("root",{message:H.error}),d==null||d(M,H.error))},[n,u,m,t,f,l,r,d,c,i]),v=b.handleSubmit,L=g.useMemo(()=>Nn.debounce(v(y),500),[v,y]),k=g.useRef(L);g.useEffect(()=>{k.current=L},[L]);const T=g.useRef(null),I=tc({control:b.control,name:u,exact:!0});return g.useEffect(()=>{if(!T.current){T.current=I;return}I!==T.current&&(T.current=I,k.current())},[I]),e(lc,{...b,children:o})},i1="44px",F6=`calc(100% - ${i1})`,r1=({annotation:n,onSubmit:a})=>{const t=n!=null&&n.name?`${n.name}.explanation`:"explanation";return s(we,{children:[e(nn,{excludeFromTabOrder:!0,type:"button",isDisabled:!(n!=null&&n.id),className:"annotation-input-explanation",css:p`
          position: absolute;
          top: 6px;
          right: 0;
          width: ${i1};
          font-size: var(--ac-global-dimension-static-font-size-75);
          background: none;
          border: none;
          padding: 0 !important;
          line-height: unset;
          color: var(--ac-global-link-color);
          &:disabled {
            cursor: default;
            opacity: var(--ac-opacity-disabled);
            color: var(--ac-global-text-color-900);
          }
          &:hover:not(:disabled) {
            text-decoration: underline;
            cursor: pointer;
            background: none;
          }
        `,children:"explain"}),s(le,{placement:"bottom end",children:[e(tn,{}),e(me,{children:({close:l})=>e(Ea,{autoFocus:!0,contain:!0,restoreFocus:!0,children:e(w,{padding:"size-100",children:e("form",{onSubmit:i=>{i.preventDefault();const o=new FormData(i.target).get(t);typeof o=="string"&&(a==null||a(o)),l()},children:s(S,{direction:"column",gap:"size-100",children:[s(ee,{name:t,defaultValue:(n==null?void 0:n.explanation)??"",css:{minWidth:"300px"},children:[e(P,{children:"Explanation"}),e(W,{}),e(C,{slot:"description",children:"Why did you give this score?"})]}),e(D,{type:"submit",variant:"primary",size:"S",children:"Save"})]})})})})})]})]})},Il=n=>e(P,{className:$("react-aria-Label",n.className),css:p`
        max-width: ${F6};
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      `,...n}),o1=g.forwardRef(({annotationConfig:n,annotation:a,onSubmitExplanation:t,...l},i)=>{var r;return s(S,{gap:"size-50",alignItems:"center",position:"relative",children:[e(r1,{annotation:a,onSubmit:t}),s(We,{id:n.id,name:n.name,defaultValue:(a==null?void 0:a.label)??void 0,size:"S",...l,css:p`
          width: 100%;
        `,children:[e(Il,{children:n.name}),s(D,{ref:i,children:[e(Ge,{}),e(ze,{})]}),e(C,{slot:"description",children:n.description}),e(le,{children:e(Ie,{style:{minHeight:"auto"},children:(r=n.values)==null?void 0:r.map(o=>e(oe,{id:o.label,children:o.label},o.label))})})]})]})});o1.displayName="CategoricalAnnotationInput";const s1=g.forwardRef(({annotationConfig:n,annotation:a,onSubmitExplanation:t,...l},i)=>s(S,{gap:"size-50",alignItems:"center",position:"relative",children:[e(r1,{annotation:a,onSubmit:t}),s(Wr,{defaultValue:(a==null?void 0:a.score)??void 0,...l,ref:i,size:"S",minValue:(n==null?void 0:n.lowerBound)??0,maxValue:(n==null?void 0:n.upperBound)??1,css:{width:"100%"},children:[e(Il,{children:n.name}),e(W,{placeholder:(n==null?void 0:n.optimizationDirection)==="MAXIMIZE"?`e.g. ${n.upperBound}`:`e.g. ${n.lowerBound}`}),s(C,{slot:"description",children:["from ",n.lowerBound," to ",n.upperBound]})]})]}));s1.displayName="ContinuousAnnotationInput";const c1=g.forwardRef(({annotationConfig:n,annotation:a,...t},l)=>e(S,{gap:"size-50",alignItems:"center",position:"relative",children:s(ee,{id:n.id,name:n.name,defaultValue:(a==null?void 0:a.explanation)??void 0,...t,ref:l,css:{width:"100%"},children:[e(Il,{children:n.name}),e(oa,{}),e(C,{slot:"description",children:n.description})]})}));c1.displayName="FreeformAnnotationInput";function D6(n){const{annotationConfig:a,annotation:t}=n,{control:l}=ic();return s("div",{children:[a.annotationType==="CATEGORICAL"&&e(Z,{control:l,name:a.name,render:({field:{value:i,...r}})=>e(o1,{annotationConfig:a,annotation:t,...r,selectedKey:i==null?void 0:i.label,onSubmitExplanation:o=>{t!=null&&t.id&&r.onChange({...t,name:a.name,explanation:o})},onSelectionChange:o=>{var d,u;let c=o;if(c===(i==null?void 0:i.label)&&(c=null),typeof c=="string"&&c!=null){const m={...t,id:t==null?void 0:t.id,name:a.name,label:c,score:((u=(d=a.values)==null?void 0:d.find(h=>h.label===c))==null?void 0:u.score)??null};r.onChange(m)}else r.onChange({...t,id:t==null?void 0:t.id,name:a.name,label:null,score:null})}})}),a.annotationType==="CONTINUOUS"&&e(Z,{control:l,name:a.name,render:({field:{value:i,...r}})=>e(s1,{annotationConfig:a,annotation:t,...r,onSubmitExplanation:o=>{t!=null&&t.id&&r.onChange({...t,name:a.name,explanation:o})},value:(i==null?void 0:i.score)??void 0,onChange:o=>{r.onChange({...t,id:t==null?void 0:t.id,name:a.name,score:o})}})}),a.annotationType==="FREEFORM"&&e(Z,{control:l,name:a.name,render:({field:{value:i,...r}})=>e(c1,{annotationConfig:a,annotation:t,...r,value:(i==null?void 0:i.explanation)??"",onChange:o=>{r.onChange({...t,id:t==null?void 0:t.id,name:a.name,explanation:o})}})})]})}const E6="e";function K6(n){const{projectId:a,spanNodeId:t}=n,[l,i]=g.useState(null);return e(w,{height:"100%",maxHeight:"100%",overflow:"auto",children:s(S,{direction:"column",height:"100%",children:[e(w,{paddingY:"size-100",paddingX:"size-100",borderBottomWidth:"thin",borderColor:"dark",width:"100%",flex:"none",children:e(S,{direction:"row",alignItems:"center",justifyContent:"end",width:"100%",children:e(_6,{projectId:a,spanNodeId:t,disabled:l!==null,onAnnotationNameSelect:i})})}),e(g.Suspense,{children:e(R6,{spanId:t,projectId:a})})]})})}function _6(n){const{projectId:a,disabled:t=!1,spanNodeId:l,onAnnotationNameSelect:i}=n;return e(B,{children:s(we,{children:[e(D,{variant:t?"default":"primary",isDisabled:t,size:"S",leadingVisual:e(x,{svg:e(Qa,{})}),"aria-label":"Add Annotation",children:"Annotation"}),s(le,{placement:"bottom end",children:[e(tn,{}),e(me,{children:e(g.Suspense,{fallback:e(ue,{}),children:e(V6,{projectId:a,spanNodeId:l,onAnnotationNameSelect:r=>{i(r)}})})})]})]})})}function V6(n){const{projectId:a,spanNodeId:t}=n,{contains:l}=Gi({sensitivity:"base"});return s(Tt,{filter:l,children:[e(A6,{projectId:a,spanId:t}),e(w,{padding:"size-100",borderTopWidth:"thin",borderTopColor:"dark",children:e(pl,{variant:"quiet",to:"/settings/annotations",size:"S",children:"Edit Annotation Configs"})})]})}const P6=n=>!n.matches("button.annotation-input-explanation");function R6(n){var H,K;const{spanId:a,projectId:t,extraAnnotationCards:l}=n,{viewer:i}=kn(),r=Va(),o=g.useMemo(()=>i?[i.id]:[null],[i]),c=F.useLazyLoadQuery(e1,{projectId:t,spanId:a,filterUserIds:o}),d=F.useFragment(Jo,c.span),u=c.span.id,m=d.filteredSpanAnnotations,h=g.useMemo(()=>Fc(m),[m]),b=g.useMemo(()=>new Set(h.map(A=>A.id)),[h]),f=(K=(H=c.project)==null?void 0:H.annotationConfigs)==null?void 0:K.configs,y=(f==null?void 0:f.length)??0,v=qr(),L=v==null?void 0:v.timeRange,[k]=F.useMutation(Yo),T=g.useCallback(A=>new Promise(O=>{var R,q;A.id?k({variables:{spanId:u,annotationIds:[A.id],timeRange:{start:(R=L==null?void 0:L.start)==null?void 0:R.toISOString(),end:(q=L==null?void 0:L.end)==null?void 0:q.toISOString()},projectId:t,filterUserIds:o},onCompleted:()=>{O({success:!0})},onError:X=>{O({success:!1,error:X.message}),r({title:"Error deleting annotation",message:X.message})}}):O({success:!0})}),[k,u,L,t,r,o]),[I]=F.useMutation(Xo),V=g.useCallback(A=>new Promise(O=>{const R=A.id;R&&g.startTransition(()=>{var q,X;I({variables:{annotationId:R,spanId:u,name:A.name,label:A.label,score:A.score,explanation:A.explanation||null,filterUserIds:o,timeRange:{start:(q=L==null?void 0:L.start)==null?void 0:q.toISOString(),end:(X=L==null?void 0:L.end)==null?void 0:X.toISOString()},projectId:t},onCompleted:()=>{O({success:!0})},onError:$e=>{O({success:!1,error:$e.message}),r({title:"Error editing annotation",message:$e.message})}})})}),[I,u,o,L,t,r]),[M]=F.useMutation(qo),_=g.useCallback(A=>new Promise(O=>{var R,q;M({variables:{input:{...A,spanId:u,annotatorKind:"HUMAN",explanation:A.explanation||null,source:"APP"},name:A.name,spanId:u,filterUserIds:o,timeRange:{start:(R=L==null?void 0:L.start)==null?void 0:R.toISOString(),end:(q=L==null?void 0:L.end)==null?void 0:q.toISOString()},projectId:t},onCompleted:()=>{O({success:!0})},onError:X=>{O({success:!1,error:X.message}),r({title:"Error creating annotation",message:X.message})}})}),[M,u,L,t,r,o]);return s(w,{height:"100%",maxHeight:"100%",overflow:"auto",width:"100%",padding:"size-200",children:[!y&&!l&&s(S,{direction:"column",alignItems:"center",justifyContent:"center",height:"100%",children:[e(sl,{message:"No annotation configurations for this project"}),e(ja,{to:"/settings/annotations",children:"Configure Annotation Configs"})]}),!!y&&s(Ea,{children:[e(w6,{hotkey:E6,accept:P6}),f==null?void 0:f.map((A,O)=>{const R=h.find(q=>q.name===A.config.name);return e(M6,{annotationConfig:A.config,currentAnnotationIDs:b,annotation:R,onCreate:_,onUpdate:V,onDelete:T,children:e(D6,{annotation:R,annotationConfig:A.config})},`${O}_${A.config.name}_form`)})]})]})}const d1=p`
  display: flex;
  flex-direction: column;
  gap: var(--ac-global-dimension-size-50);
  width: 100%;
  &[data-outgoing="true"] {
    align-self: flex-end;
  }
  &[data-outgoing="false"] {
    align-self: flex-start;
  }
`,u1=p`
  display: flex;
  gap: var(--ac-global-dimension-size-100);
  width: 80%;
  align-items: flex-end;
  &[data-outgoing="true"] {
    flex-direction: row-reverse;
    align-self: flex-end;
  }
`,Rt=24,N6=p`
  padding: var(--ac-global-dimension-size-100)
    var(--ac-global-dimension-size-150);
  font-size: var(--ac-global-font-size-s);
  line-height: var(--ac-global-line-height-s);
  word-wrap: break-word;
  &[data-outgoing="true"] {
    background-color: var(--ac-global-color-primary);
    color: var(--ac-global-color-grey-50);
    border-radius: var(--ac-global-rounding-large)
      var(--ac-global-rounding-large) 0 var(--ac-global-rounding-large);
  }
  &[data-outgoing="false"] {
    background-color: var(--ac-global-background-color-light);
    color: var(--ac-global-text-color-900);
    border-radius: var(--ac-global-rounding-large)
      var(--ac-global-rounding-large) var(--ac-global-rounding-large) 0;
  }
`,O6=p`
  font-size: var(--ac-global-font-size-xs);
  color: var(--ac-global-text-color-500);
  padding-left: calc(
    ${Rt}px + var(--ac-global-dimension-size-100)
  );
  &[data-outgoing="true"] {
    text-align: right;
    padding-left: 0;
    padding-right: calc(
      ${Rt}px + var(--ac-global-dimension-size-100)
    );
  }
`;function Gh({text:n,timestamp:a,isOutgoing:t=!1,userName:l,userPicture:i=null}){const{shortDateTimeFormatter:r}=Bn();return s("div",{css:d1,"data-outgoing":t,children:[s("div",{css:u1,"data-outgoing":t,children:[e(po,{name:l,profilePictureUrl:i,size:Rt}),e("div",{css:N6,"data-outgoing":t,children:n})]}),e("div",{css:O6,"data-outgoing":t,children:e("time",{dateTime:a.toISOString(),children:r(a)})})]})}function Wh({onSendMessage:n,isSending:a=!1,placeholder:t="Type a message"}){const[l,i]=g.useState(""),r=()=>{l.trim()&&(n&&n(l.trim()),i(""))};return e(w,{padding:"size-100",width:"100%",flex:"none",children:s(S,{direction:"row",gap:"size-100",children:[e(ee,{size:"M",value:l,onChange:i,onKeyDown:c=>{c.key==="Enter"&&!c.shiftKey&&(c.preventDefault(),r())},"aria-label":"Message input",isDisabled:a,children:e(W,{placeholder:t})}),e(D,{size:"M",variant:"primary",isDisabled:!l.trim()||a,onPress:r,"aria-label":a?"Sending message...":"Send",leadingVisual:a?e(x,{svg:e(Br,{})}):e(x,{svg:e(y2,{})})})]})})}const bi=24,$6=p`
  flex: none;
`,B6=p`
  width: 100%;
`,H6=p`
  width: 100%;
`,j6=p`
  &[data-outgoing="true"] {
    border-radius: var(--ac-global-rounding-large)
      var(--ac-global-rounding-large) 0 var(--ac-global-rounding-large);
  }
  &[data-outgoing="false"] {
    border-radius: var(--ac-global-rounding-large)
      var(--ac-global-rounding-large) var(--ac-global-rounding-large) 0;
  }
`;function Qh({isOutgoing:n=!1,height:a=80}){return e("div",{css:p(d1,H6),"data-outgoing":n,"data-testid":"message-container",children:s("div",{css:p(u1,B6),"data-outgoing":n,children:[e(En,{width:bi,height:bi,borderRadius:"circle",animation:"pulse",css:$6}),e(En,{"data-outgoing":n,height:a,animation:"wave","data-testid":"message-bubble-skeleton",css:j6})]})})}function qh(n){const{kind:a}=n;return e(Se,{size:"S",color:a==="HUMAN"?"var(--ac-global-color-blue-500)":"var(--ac-global-color-orange-500)",children:a})}const m1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"annotationId"},{defaultValue:null,kind:"LocalArgument",name:"spanId"}],a=[{fields:[{items:[{kind:"Variable",name:"annotationIds.0",variableName:"annotationId"}],kind:"ListValue",name:"annotationIds"}],kind:"ObjectValue",name:"input"}],t=[{kind:"Variable",name:"id",variableName:"spanId"}],l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},o={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null},c={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},d={alias:null,args:null,kind:"ScalarField",name:"explanation",storageKey:null},u={alias:null,args:null,kind:"ScalarField",name:"createdAt",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"SpanAnnotationActionMenuDeleteMutation",selections:[{alias:null,args:a,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"deleteSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"SpanAnnotationsEditor_spanAnnotations"},{args:null,kind:"FragmentSpread",name:"SpanFeedback_annotations"}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"SpanAnnotationActionMenuDeleteMutation",selections:[{alias:null,args:a,concreteType:"SpanAnnotationMutationPayload",kind:"LinkedField",name:"deleteSpanAnnotations",plural:!1,selections:[{alias:null,args:null,concreteType:"Query",kind:"LinkedField",name:"query",plural:!1,selections:[{alias:null,args:t,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l,{kind:"InlineFragment",selections:[{alias:"filteredSpanAnnotations",args:[{fields:[{kind:"Literal",name:"exclude",value:{names:["note"]}},{fields:[{kind:"Literal",name:"userIds",value:null}],kind:"ObjectValue",name:"include"}],kind:"ObjectValue",name:"filter"}],concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[l,i,r,o,c,d,u],storageKey:'spanAnnotations(filter:{"exclude":{"names":["note"]},"include":{"userIds":null}})'},{alias:null,args:null,concreteType:"SpanAnnotation",kind:"LinkedField",name:"spanAnnotations",plural:!0,selections:[l,i,c,o,d,{alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null},r,{alias:null,args:null,kind:"ScalarField",name:"identifier",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"source",storageKey:null},u,{alias:null,args:null,kind:"ScalarField",name:"updatedAt",storageKey:null},{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null}],storageKey:null}],storageKey:null}],type:"Span",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"bcdc8dccf3bfa49b8aa7960710a4deed",id:null,metadata:{},name:"SpanAnnotationActionMenuDeleteMutation",operationKind:"mutation",text:`mutation SpanAnnotationActionMenuDeleteMutation(
  $annotationId: ID!
  $spanId: ID!
) {
  deleteSpanAnnotations(input: {annotationIds: [$annotationId]}) {
    query {
      node(id: $spanId) {
        __typename
        ... on Span {
          ...SpanAnnotationsEditor_spanAnnotations
          ...SpanFeedback_annotations
        }
        id
      }
    }
  }
}

fragment SpanAnnotationsEditor_spanAnnotations on Span {
  id
  filteredSpanAnnotations: spanAnnotations(filter: {exclude: {names: ["note"]}, include: {}}) {
    id
    name
    annotatorKind
    score
    label
    explanation
    createdAt
  }
}

fragment SpanFeedback_annotations on Span {
  id
  spanAnnotations {
    id
    name
    label
    score
    explanation
    metadata
    annotatorKind
    identifier
    source
    createdAt
    updatedAt
    user {
      id
      username
      profilePictureUrl
    }
  }
}
`}}})();m1.hash="436457e2120f7750037b024a1b96e214";function Xh(n){const{annotationId:a,spanNodeId:t,annotationName:l,onSpanAnnotationActionSuccess:i,onSpanAnnotationActionError:r,buttonVariant:o,buttonSize:c}=n,[d,u]=g.useState(!1),[m]=F.useMutation(m1),h=g.useCallback(()=>{g.startTransition(()=>{m({variables:{annotationId:a,spanId:t},onCompleted:()=>{i({title:"Annotation Deleted",message:`Annotation ${l} has been deleted.`}),u(!1)},onError:f=>{r(f)}})})},[m,a,t,i,l,r]),b=g.useRef(null);return s(B,{children:[s(we,{children:[e(D,{ref:b,size:c,variant:o,leadingVisual:e(x,{svg:e(Hr,{})})}),e(le,{children:e(me,{children:({close:f})=>e(Ie,{style:{minHeight:"auto"},children:e(Ze,{id:"deleteAnnotation",onAction:()=>{u(!0),f()},children:s(S,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(gl,{})}),e(C,{children:"Delete"})]})})})})})]}),e(we,{isOpen:d,onOpenChange:u,children:e(pn,{children:e(gn,{children:e(me,{children:({close:f})=>s(Ve,{children:[e(Pe,{children:e(Re,{children:"Delete Annotation"})}),e(w,{padding:"size-200",children:e(C,{color:"danger",children:`Are you sure you want to delete annotation ${l}? This cannot be undone.`})}),e(w,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:s(S,{direction:"row",justifyContent:"end",gap:"size-200",children:[e(vl,{children:e(D,{onPress:f,children:"Cancel"})}),e(D,{variant:"danger",onPress:()=>{h()},children:"Delete Annotation"})]})})]})})})})})]})}const g1=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"description"},a={defaultValue:null,kind:"LocalArgument",name:"metadata"},t={defaultValue:null,kind:"LocalArgument",name:"name"},l=[{fields:[{kind:"Variable",name:"description",variableName:"description"},{kind:"Variable",name:"metadata",variableName:"metadata"},{kind:"Variable",name:"name",variableName:"name"}],kind:"ObjectValue",name:"input"}],i={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},r={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},o=[i,r,{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"labels",plural:!0,selections:[i,r,{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[n,a,t],kind:"Fragment",metadata:null,name:"CreateDatasetFormMutation",selections:[{alias:null,args:l,concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"createDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[i,r,{kind:"InlineDataFragmentSpread",name:"DatasetSelect_dataset",selections:o,args:null,argumentDefinitions:[]}],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[t,n,a],kind:"Operation",name:"CreateDatasetFormMutation",selections:[{alias:null,args:l,concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"createDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:o,storageKey:null}],storageKey:null}]},params:{cacheID:"e795a4b8ebb795f93dea507cba2eef83",id:null,metadata:{},name:"CreateDatasetFormMutation",operationKind:"mutation",text:`mutation CreateDatasetFormMutation(
  $name: String!
  $description: String = null
  $metadata: JSON = null
) {
  createDataset(input: {name: $name, description: $description, metadata: $metadata}) {
    dataset {
      id
      name
      ...DatasetSelect_dataset
    }
  }
}

fragment DatasetSelect_dataset on Dataset {
  id
  name
  exampleCount
  labels {
    id
    name
    color
  }
}
`}}})();g1.hash="1948aa8344d9c6feab99a0c18f2a6988";function p1({datasetName:n,datasetDescription:a,datasetMetadata:t,onSubmit:l,isSubmitting:i,submitButtonText:r,formMode:o}){const{control:c,handleSubmit:d,formState:{isDirty:u}}=Oe({defaultValues:{name:n??"Dataset "+new Date().toISOString(),description:a??"",metadata:JSON.stringify(t,null,2)??"{}"}});return s(an,{children:[s(w,{padding:"size-200",children:[e(Z,{name:"name",control:c,rules:{required:"Dataset name is required"},render:({field:{onChange:m,onBlur:h,value:b},fieldState:{invalid:f,error:y}})=>s(ee,{isInvalid:f,onChange:m,onBlur:h,value:b.toString(),children:[e(P,{children:"Dataset Name"}),e(W,{placeholder:"e.x. Golden Dataset"}),y!=null&&y.message?e(ae,{children:y.message}):e(C,{slot:"description",children:"The name of the dataset"})]})}),e(Z,{name:"description",control:c,render:({field:{onChange:m,onBlur:h,value:b},fieldState:{invalid:f,error:y}})=>s(ee,{isInvalid:f,onChange:m,onBlur:h,value:b.toString(),children:[e(P,{children:"Description"}),e(oa,{placeholder:"e.x. A golden dataset for structured data extraction"}),y!=null&&y.message?e(ae,{children:y.message}):e(C,{slot:"description",children:"The description of the dataset"})]})}),e(Z,{name:"metadata",control:c,rules:{validate:m=>qd(m)?!0:"metadata must be a valid JSON object"},render:({field:{onChange:m,onBlur:h,value:b},fieldState:{error:f}})=>e(O5,{label:"metadata",errorMessage:f==null?void 0:f.message,description:"A JSON object containing metadata for the dataset",children:e(V5,{value:b,onChange:m,onBlur:h})})})]}),e(w,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:e(S,{direction:"row",justifyContent:"end",children:e(D,{isDisabled:(o==="edit"?!u:!1)||i,variant:u?"primary":"default",size:"S",onPress:()=>{d(l)()},children:r})})})]})}function Z6(n){const{onDatasetCreated:a,onDatasetCreateError:t}=n,[l,i]=F.useMutation(g1),r=g.useCallback(o=>{l({variables:{...o,metadata:JSON.parse(o.metadata)},onCompleted:c=>{a(c.createDataset.dataset)},updater:c=>{const d=F.ConnectionHandler.getConnectionID("client:root","DatasetPicker__datasets"),m=c.getRootField("createDataset").getLinkedRecord("dataset"),h=c.get(d);if(h&&m){const b=F.ConnectionHandler.createEdge(c,h,m,"DatasetEdge");F.ConnectionHandler.insertEdgeAfter(h,b)}},onError:c=>{t(c)}})},[l,a,t]);return e(p1,{isSubmitting:i,onSubmit:r,submitButtonText:i?"Creating...":"Create Dataset",formMode:"create"})}const h1=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"datasetId"},a={defaultValue:null,kind:"LocalArgument",name:"description"},t={defaultValue:null,kind:"LocalArgument",name:"metadata"},l={defaultValue:null,kind:"LocalArgument",name:"name"},i=[{fields:[{kind:"Variable",name:"datasetId",variableName:"datasetId"},{kind:"Variable",name:"description",variableName:"description"},{kind:"Variable",name:"metadata",variableName:"metadata"},{kind:"Variable",name:"name",variableName:"name"}],kind:"ObjectValue",name:"input"}],r={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},o={alias:null,args:null,kind:"ScalarField",name:"description",storageKey:null},c={alias:null,args:null,kind:"ScalarField",name:"metadata",storageKey:null};return{fragment:{argumentDefinitions:[n,a,t,l],kind:"Fragment",metadata:null,name:"EditDatasetFormMutation",selections:[{alias:null,args:i,concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"patchDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[r,o,c],storageKey:null}],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[n,l,a,t],kind:"Operation",name:"EditDatasetFormMutation",selections:[{alias:null,args:i,concreteType:"DatasetMutationPayload",kind:"LinkedField",name:"patchDataset",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[r,o,c,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}],storageKey:null}]},params:{cacheID:"24675cd487da4f57f6aa04d850e65ad3",id:null,metadata:{},name:"EditDatasetFormMutation",operationKind:"mutation",text:`mutation EditDatasetFormMutation(
  $datasetId: ID!
  $name: String!
  $description: String = null
  $metadata: JSON = null
) {
  patchDataset(input: {datasetId: $datasetId, name: $name, description: $description, metadata: $metadata}) {
    dataset {
      name
      description
      metadata
      id
    }
  }
}
`}}})();h1.hash="e952d9cbc840dd6cd447b3024178aab4";function Yh({datasetName:n,datasetId:a,datasetDescription:t,onDatasetEdited:l,onDatasetEditError:i,datasetMetadata:r}){const[o,c]=F.useMutation(h1);return e(p1,{datasetName:n,datasetDescription:t,datasetMetadata:r,onSubmit:u=>{o({variables:{datasetId:a,...u,metadata:JSON.parse(u.metadata)},onCompleted:()=>{l()},onError:m=>{i(m)}})},isSubmitting:c,submitButtonText:c?"Saving...":"Save",formMode:"edit"})}const f1=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},t=[n,a,{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"labels",plural:!0,selections:[n,a,{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null}],storageKey:null}],l={alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},r={alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null},o=[{kind:"Literal",name:"first",value:100}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetSelectQuery",selections:[{alias:"datasets",args:null,concreteType:"DatasetConnection",kind:"LinkedField",name:"__DatasetPicker__datasets_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dataset",args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineDataFragmentSpread",name:"DatasetSelect_dataset",selections:t,args:null,argumentDefinitions:[]}],storageKey:null},l,{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[i],storageKey:null}],storageKey:null},r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DatasetSelectQuery",selections:[{alias:null,args:o,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dataset",args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:t,storageKey:null},l,{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[i,n],storageKey:null}],storageKey:null},r],storageKey:"datasets(first:100)"},{alias:null,args:o,filters:null,handle:"connection",key:"DatasetPicker__datasets",kind:"LinkedHandle",name:"datasets"}]},params:{cacheID:"fff04130b98b951a22dd558022ce4745",id:null,metadata:{connection:[{count:null,cursor:null,direction:"forward",path:["datasets"]}]},name:"DatasetSelectQuery",operationKind:"query",text:`query DatasetSelectQuery {
  datasets(first: 100) {
    edges {
      dataset: node {
        ...DatasetSelect_dataset
        id
      }
      cursor
      node {
        __typename
        id
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}

fragment DatasetSelect_dataset on Dataset {
  id
  name
  exampleCount
  labels {
    id
    name
    color
  }
}
`}}})();f1.hash="c50a9ca70f0f2beee00480213fef8b58";const b1={kind:"InlineDataFragment",name:"DatasetSelect_dataset"};b1.hash="e5a0b1650426283637ea59a109398aa9";const U6=b1;function Jh(n){const a=F.useLazyLoadQuery(f1,{},{fetchPolicy:"store-and-network"}),t=g.useMemo(()=>a.datasets.edges.map(({dataset:l})=>F.readInlineData(U6,l)),[a]);return s(We,{"data-testid":"dataset-picker",size:n.size,className:"dataset-picker","aria-label":"select a dataset",onChange:l=>{var i;l&&((i=n.onChange)==null||i.call(n,l.toString()))},placeholder:n.placeholder??"Select a dataset",onBlur:n.onBlur,isRequired:n.isRequired,value:n.value,children:[n.label&&e(P,{children:n.label}),s(D,{className:"dataset-picker-button",children:[e(Ge,{}),e(ze,{})]}),n.errorMessage&&e(C,{slot:"errorMessage",children:n.errorMessage}),e(le,{children:s(Ie,{css:p`
            min-height: auto;
          `,children:[t.map(l=>e(oe,{id:l.id,children:s(S,{direction:"column",gap:"size-100",width:"100%",children:[s(S,{direction:"row",alignItems:"center",gap:"size-200",justifyContent:"space-between",width:"100%",children:[e(C,{children:l.name}),s(C,{color:"text-700",size:"XS",children:[l.exampleCount," examples"]})]}),l.labels.length>0&&e("ul",{css:p`
                        display: flex;
                        flex-direction: row;
                        gap: var(--ac-global-dimension-size-50);
                        min-width: 0;
                        flex-wrap: wrap;
                      `,children:l.labels.map(i=>e("li",{children:e(Se,{color:i.color,children:e(ye,{maxWidth:150,title:i.name,children:i.name})})},i.id))})]})},l.id)),e(Ze,{href:"/datasets",style:{textDecoration:"none"},children:"Go to Datasets"})]})})]})}const y1=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},t={alias:"dataset",args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[n,a,{alias:null,args:null,kind:"ScalarField",name:"exampleCount",storageKey:null},{alias:null,args:null,concreteType:"DatasetSplit",kind:"LinkedField",name:"splits",plural:!0,selections:[n,a],storageKey:null},{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"labels",plural:!0,selections:[n,a,{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null}],storageKey:null}],storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},r={alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null},o=[{kind:"Literal",name:"first",value:100}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetSelectWithSplitsQuery",selections:[{alias:"datasets",args:null,concreteType:"DatasetConnection",kind:"LinkedField",name:"__DatasetPickerWithSplits__datasets_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[t,l,{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[i],storageKey:null}],storageKey:null},r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DatasetSelectWithSplitsQuery",selections:[{alias:null,args:o,concreteType:"DatasetConnection",kind:"LinkedField",name:"datasets",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[t,l,{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"node",plural:!1,selections:[i,n],storageKey:null}],storageKey:null},r],storageKey:"datasets(first:100)"},{alias:null,args:o,filters:null,handle:"connection",key:"DatasetPickerWithSplits__datasets",kind:"LinkedHandle",name:"datasets"}]},params:{cacheID:"a1b63e1121cafd04473227264161a3fd",id:null,metadata:{connection:[{count:null,cursor:null,direction:"forward",path:["datasets"]}]},name:"DatasetSelectWithSplitsQuery",operationKind:"query",text:`query DatasetSelectWithSplitsQuery {
  datasets(first: 100) {
    edges {
      dataset: node {
        id
        name
        exampleCount
        splits {
          id
          name
        }
        labels {
          id
          name
          color
        }
      }
      cursor
      node {
        __typename
        id
      }
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
`}}})();y1.hash="7c2425f980a39012f8ca7f865ed9a4b9";function ef(n){const{datasetId:a,splitIds:t=[]}=n.value||{},l=F.useLazyLoadQuery(y1,{},{fetchPolicy:"store-and-network"}),{contains:i}=Gi({sensitivity:"base"}),r=g.useMemo(()=>l.datasets.edges.map(({dataset:m})=>({id:m.id,name:m.name,exampleCount:m.exampleCount,splits:m.splits.map(h=>({id:h.id,name:h.name})),labels:m.labels.map(h=>({id:h.id,name:h.name,color:h.color})),isSelected:m.id===a,selectedSplitIds:m.id===a?t:[]})),[l,a,t]),o=g.useMemo(()=>{if(a)return r.find(m=>m.id===a)},[r,a]),c=g.useMemo(()=>o&&t.length>0?o.splits.filter(m=>t.includes(m.id)):[],[o,t]),d=a?[a]:void 0,u=g.useMemo(()=>r.some(m=>m.splits.length>0),[r]);return s(Ya,{children:[e(D,{"data-testid":"dataset-picker",className:"dataset-picker-button",trailingVisual:e(ze,{}),size:n.size??"S",children:o?s(S,{alignItems:"center",children:[e(C,{children:o.name}),c.length>0?s(C,{color:"text-300",children:[" /"," ",c.length===1?c[0].name:`${c.length} splits`]}):e(C,{color:"text-300",children:" / All Examples"})]}):e(C,{color:"text-300",children:n.placeholder??"Select a dataset"})}),s(ii,{children:[s(Tt,{filter:i,children:[e(ri,{children:e(Ft,{"aria-label":"Search",autoFocus:!0,children:e(W,{placeholder:"Search datasets"})})}),e(ta,{selectionMode:"single",selectedKeys:d,items:r,renderEmptyState:()=>e(w,{padding:"size-100",children:e(C,{color:"grey-300",size:"S",children:"No datasets found"})}),children:({id:m,name:h,exampleCount:b,splits:f,labels:y,isSelected:v,selectedSplitIds:L})=>{const k=b===0;return f.length>0?s(rc,{children:[e(Ke,{textValue:h,isDisabled:k,children:s(S,{direction:"column",gap:"size-100",width:"100%",children:[s(S,{direction:"row",alignItems:"center",gap:"size-200",justifyContent:"space-between",width:"100%",css:p`
                          opacity: ${k?"var(--ac-global-opacity-disabled)":1};
                        `,children:[e(C,{children:h}),s(C,{color:"text-700",size:"XS",children:[b," ",b===1?"example":"examples"]})]}),y.length>0&&e("ul",{css:p`
                            display: flex;
                            flex-direction: row;
                            gap: var(--ac-global-dimension-size-50);
                            min-width: 0;
                            flex-wrap: wrap;
                          `,children:y.map(I=>e("li",{children:e(Se,{color:I.color,children:e(ye,{maxWidth:150,title:I.name,children:I.name})})},I.id))})]})}),e(ii,{placement:"end top",children:s(Tt,{filter:i,children:[e(ri,{children:e(Ft,{"aria-label":"Search",autoFocus:!0,children:e(W,{placeholder:"Search splits"})})}),e(ta,{items:[{id:"all-examples",name:"All examples",isAllExamples:!0},...f.map(I=>({...I,isAllExamples:!1}))],selectionMode:"multiple",selectedKeys:v&&L.length===0?["all-examples"]:v?L:[],onSelectionChange:I=>{var V,M,_,H,K,A;if(I==="all")(V=n.onSelectionChange)==null||V.call(n,{datasetId:m,splitIds:f.map(O=>O.id)});else{const O=Array.from(I),R=L.length===0?["all-examples"]:L,q=O.includes("all-examples"),X=O.filter(wn=>wn!=="all-examples");q&&!R.includes("all-examples")?(M=n.onSelectionChange)==null||M.call(n,{datasetId:m,splitIds:[]}):q&&X.length>0?(_=n.onSelectionChange)==null||_.call(n,{datasetId:m,splitIds:X}):q&&X.length===0?(H=n.onSelectionChange)==null||H.call(n,{datasetId:m,splitIds:[]}):!q&&X.length>0?(K=n.onSelectionChange)==null||K.call(n,{datasetId:m,splitIds:X}):(A=n.onSelectionChange)==null||A.call(n,{datasetId:m,splitIds:[]})}},children:({id:I,name:V,isAllExamples:M})=>e(Ke,{id:I,textValue:V,css:M?p`
                                    border-bottom: 1px solid
                                      var(--ac-global-color-grey-200);
                                  `:void 0,children:e(C,{children:V})})})]})})]}):e(Ke,{textValue:h,isDisabled:k,onAction:()=>{var I;(I=n.onSelectionChange)==null||I.call(n,{datasetId:m,splitIds:[]})},children:s(S,{direction:"column",gap:"size-100",width:"100%",children:[s(S,{direction:"row",alignItems:"center",gap:"size-200",justifyContent:"space-between",width:"100%",css:p`
                          opacity: ${k?"var(--ac-global-opacity-disabled)":1};
                          padding-right: ${u?"28px":void 0}; // right align the examples text if a submenu chevron is present
                        `,children:[e(C,{children:h}),s(C,{color:"text-700",size:"XS",children:[b," ",b===1?"example":"examples"]})]}),y.length>0&&e("ul",{css:p`
                            display: flex;
                            flex-direction: row;
                            gap: var(--ac-global-dimension-size-50);
                            min-width: 0;
                            flex-wrap: wrap;
                          `,children:y.map(I=>e("li",{children:e(Se,{color:I.color,children:e(ye,{maxWidth:150,title:I.name,children:I.name})})},I.id))})]})})}})]}),e(e5,{children:e(pl,{to:"/datasets",children:"Go to Datasets"})})]})]})}const v1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"datasetId"},{defaultValue:null,kind:"LocalArgument",name:"datasetLabelIds"}],a={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},t=[{alias:null,args:[{fields:[{kind:"Variable",name:"datasetId",variableName:"datasetId"},{kind:"Variable",name:"datasetLabelIds",variableName:"datasetLabelIds"}],kind:"ObjectValue",name:"input"}],concreteType:"SetDatasetLabelsMutationPayload",kind:"LinkedField",name:"setDatasetLabels",plural:!1,selections:[{alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"dataset",plural:!1,selections:[a,{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"labels",plural:!0,selections:[a,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DatasetLabelConfigButtonSetLabelsMutation",selections:t,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DatasetLabelConfigButtonSetLabelsMutation",selections:t},params:{cacheID:"2578453afc9307312ce6d800e272e7fd",id:null,metadata:{},name:"DatasetLabelConfigButtonSetLabelsMutation",operationKind:"mutation",text:`mutation DatasetLabelConfigButtonSetLabelsMutation(
  $datasetId: ID!
  $datasetLabelIds: [ID!]!
) {
  setDatasetLabels(input: {datasetId: $datasetId, datasetLabelIds: $datasetLabelIds}) {
    dataset {
      id
      labels {
        id
        name
        color
      }
    }
  }
}
`}}})();v1.hash="c3b75ee3be0ec65cbebd4a7b7a9b770c";const C1={argumentDefinitions:[{defaultValue:100,kind:"LocalArgument",name:"first"}],kind:"Fragment",metadata:{connection:[{count:"first",cursor:null,direction:"forward",path:["datasetLabels"]}]},name:"DatasetLabelConfigButton_allLabels",selections:[{alias:"datasetLabels",args:null,concreteType:"DatasetLabelConnection",kind:"LinkedField",name:"__DatasetLabelConfigButtonAllLabels_datasetLabels_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetLabelEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null};C1.hash="345a43f8cc3fa08109d2cc1d3dd6bb9b";const k1=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetLabelConfigButton_datasetLabels",selections:[n,{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"labels",plural:!0,selections:[n],storageKey:null}],type:"Dataset",abstractKey:null}})();k1.hash="379d5b11b6b9a7cb01deea2bcec9e022";const L1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"datasetId"}],a=[{kind:"Variable",name:"id",variableName:"datasetId"}],t=[{kind:"Literal",name:"first",value:100}],l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"DatasetLabelConfigButtonQuery",selections:[{args:null,kind:"FragmentSpread",name:"DatasetLabelConfigButton_allLabels"},{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{args:null,kind:"FragmentSpread",name:"DatasetLabelConfigButton_datasetLabels"}],type:"Dataset",abstractKey:null}],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"DatasetLabelConfigButtonQuery",selections:[{alias:null,args:t,concreteType:"DatasetLabelConnection",kind:"LinkedField",name:"datasetLabels",plural:!1,selections:[{alias:null,args:null,concreteType:"DatasetLabelEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"node",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null},i],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:"datasetLabels(first:100)"},{alias:null,args:t,filters:null,handle:"connection",key:"DatasetLabelConfigButtonAllLabels_datasetLabels",kind:"LinkedHandle",name:"datasetLabels"},{alias:"dataset",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[i,l,{kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"labels",plural:!0,selections:[l],storageKey:null}],type:"Dataset",abstractKey:null}],storageKey:null}]},params:{cacheID:"8439cb639233813ad16096d7abf8b164",id:null,metadata:{},name:"DatasetLabelConfigButtonQuery",operationKind:"query",text:`query DatasetLabelConfigButtonQuery(
  $datasetId: ID!
) {
  ...DatasetLabelConfigButton_allLabels
  dataset: node(id: $datasetId) {
    __typename
    ... on Dataset {
      ...DatasetLabelConfigButton_datasetLabels
    }
    id
  }
}

fragment DatasetLabelConfigButton_allLabels on Query {
  datasetLabels(first: 100) {
    edges {
      node {
        id
        name
        color
        __typename
      }
      cursor
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}

fragment DatasetLabelConfigButton_datasetLabels on Dataset {
  id
  labels {
    id
  }
}
`}}})();L1.hash="db621714d07a0ae581155c099d7e2788";const S1=(function(){var n={defaultValue:null,kind:"LocalArgument",name:"connections"},a={defaultValue:null,kind:"LocalArgument",name:"input"},t=[{kind:"Variable",name:"input",variableName:"input"}],l={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},i=[l,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null}],r={alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"datasetLabel",plural:!1,selections:i,storageKey:null},o={alias:null,args:null,concreteType:"Dataset",kind:"LinkedField",name:"datasets",plural:!0,selections:[l,{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"labels",plural:!0,selections:i,storageKey:null}],storageKey:null};return{fragment:{argumentDefinitions:[n,a],kind:"Fragment",metadata:null,name:"useDatasetLabelMutationsAddLabelMutation",selections:[{alias:null,args:t,concreteType:"CreateDatasetLabelMutationPayload",kind:"LinkedField",name:"createDatasetLabel",plural:!1,selections:[r,o],storageKey:null}],type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[a,n],kind:"Operation",name:"useDatasetLabelMutationsAddLabelMutation",selections:[{alias:null,args:t,concreteType:"CreateDatasetLabelMutationPayload",kind:"LinkedField",name:"createDatasetLabel",plural:!1,selections:[r,{alias:null,args:null,filters:null,handle:"prependNode",key:"",kind:"LinkedHandle",name:"datasetLabel",handleArgs:[{kind:"Variable",name:"connections",variableName:"connections"},{kind:"Literal",name:"edgeTypeName",value:"DatasetLabelEdge"}]},o],storageKey:null}]},params:{cacheID:"2ef998561a150eeacbaffdebc07bc94a",id:null,metadata:{},name:"useDatasetLabelMutationsAddLabelMutation",operationKind:"mutation",text:`mutation useDatasetLabelMutationsAddLabelMutation(
  $input: CreateDatasetLabelInput!
) {
  createDatasetLabel(input: $input) {
    datasetLabel {
      id
      name
      color
    }
    datasets {
      id
      labels {
        id
        name
        color
      }
    }
  }
}
`}}})();S1.hash="0ea9c100ed6c060e7fc59b9c9f4e9db1";const w1=({updateConnectionIds:n,datasetId:a})=>{const[t,l]=g.useState(""),[i,r]=F.useMutation(S1);return{addLabelMutation:g.useCallback((c,d)=>{i({variables:{input:{...c,color:(m=>{if(m.startsWith("#"))return m;const h=m.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*[\d.]+)?\)/);if(h){const[,b,f,y]=h;return"#"+[b,f,y].map(L=>parseInt(L).toString(16).padStart(2,"0")).join("")}return m})(c.color),datasetIds:a?[a]:void 0},connections:n??[]},onCompleted:()=>{d==null||d()},onError:m=>{const h=yn(m);l((h==null?void 0:h[0])??m.message)}})},[i,n,a]),isSubmitting:r,error:t}};function nf(n){const{datasetId:a,variant:t="default"}=n;return s(we,{children:[e(D,{variant:t,size:"S",leadingVisual:e(x,{svg:e(jr,{})}),"aria-label":"Configure dataset labels",children:"Label"}),s(le,{placement:"bottom start",shouldCloseOnInteractOutside:()=>!0,children:[e(tn,{}),e(me,{children:e(g.Suspense,{fallback:e(ue,{}),children:e(G6,{datasetId:a})})})]})]})}function G6(n){const{datasetId:a}=n,t=F.useLazyLoadQuery(L1,{datasetId:a});return e(W6,{query:t,dataset:t.dataset,...n})}function W6({query:n,dataset:a}){const[t,l]=g.useState("apply"),i=Va(),r=F.useFragment(k1,a),o=F.useFragment(C1,n),c=g.useMemo(()=>{var y;return((y=r==null?void 0:r.labels)==null?void 0:y.map(v=>v.id))||[]},[r==null?void 0:r.labels]),[d,u]=g.useState(""),m=g.useMemo(()=>new Set(c),[c]),[h]=F.useMutation(v1),b=o.datasetLabels.edges.map(y=>y.node).filter(y=>y.name.toLowerCase().includes(d.toLowerCase()));return s(B,{children:[e(w,{padding:"size-100",paddingTop:"size-50",borderBottomWidth:"thin",borderColor:"dark",minWidth:300,children:s(S,{direction:"column",gap:"size-50",children:[s(S,{direction:"row",justifyContent:"space-between",alignItems:"center",children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[t==="create"&&e(D,{variant:"quiet",size:"S",leadingVisual:e(x,{svg:e(i2,{})}),onPress:()=>l("apply")}),e(Q,{level:4,weight:"heavy",children:t==="create"?"Create New Label for this dataset":"Assign labels to this dataset"})]}),t==="apply"&&e(D,{variant:"quiet",size:"S",leadingVisual:e(x,{svg:e(Qa,{})}),onPress:()=>l("create")})]}),t==="apply"&&e(hl,{autoFocus:!0,"aria-label":"Search labels",placeholder:"Search labels...",onChange:u})]})}),t==="apply"&&s(B,{children:[e(Ie,{"aria-label":"labels",items:b,selectionMode:"multiple",selectedKeys:m,onSelectionChange:y=>{if(y==="all")return;const v=[...y];ed(v)&&h({variables:{datasetId:r.id,datasetLabelIds:v},onError:L=>{const k=yn(L);i({title:"Failed to save label changes",message:(k==null?void 0:k[0])??L.message})}})},css:p`
              height: 300px;
            `,renderEmptyState:()=>"No labels found",children:y=>e(Q6,{item:y},y.id)}),e(w,{padding:"size-100",borderTopColor:"dark",borderTopWidth:"thin",children:e(pl,{variant:"quiet",size:"S",to:"/settings/datasets",children:"Edit Labels"})})]}),t==="create"&&e(q6,{onCompleted:()=>l("apply"),updateConnectionIds:[F.ConnectionHandler.getConnectionID("client:root","DatasetLabelConfigButtonAllLabels_datasetLabels")],datasetId:r.id})]})}function Q6({item:n}){return e(Ze,{id:n.id,children:({isSelected:a})=>s(S,{direction:"row",justifyContent:"space-between",children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e(U,{color:n.color,size:"M",shape:"circle"}),n.name]}),a?e(x,{svg:e(Ua,{})}):null]})},n.id)}function q6({updateConnectionIds:n,datasetId:a,onCompleted:t}){const{addLabelMutation:l,isSubmitting:i,error:r}=w1({updateConnectionIds:n,datasetId:a}),o=g.useCallback(c=>{l(c,t)},[l,t]);return s(B,{children:[!!r&&e(On,{banner:!0,variant:"danger",children:r}),e(Ll,{onSubmit:o,isSubmitting:i})]})}function af({onDatasetCreated:n}){const[a,t]=g.useState(null),[l,i]=g.useState(!1),r=_a();return s(we,{isOpen:l,onOpenChange:o=>{t(null),i(o)},children:[e(D,{variant:"default",leadingVisual:e(x,{svg:e(v2,{})}),"aria-label":"Create a new dataset",onPress:()=>{t(null),i(!0)}}),e(le,{placement:"bottom right",css:p`
          border: none;
        `,children:e(ao,{title:"Create New Dataset",borderColor:"light",backgroundColor:"light",children:s(w,{width:"500px",children:[a?e(On,{variant:"danger",children:a}):null,e(Z6,{onDatasetCreateError:o=>{const c=yn(o);t((c==null?void 0:c[0])??o.message)},onDatasetCreated:({id:o,name:c})=>{t(null),i(!1),n&&n(o),r({title:"Dataset Created",message:`Dataset "${c}" created successfully`})}})]})})})]})}const tf=({buttonText:n,successText:a,tooltipText:t="Copy link to clipboard",preserveSearchParams:l=!1})=>{const i=oc(),r=_a();return s(j,{delay:200,children:[e(D,{size:"S",leadingVisual:e(x,{svg:e(x2,{})}),onPress:()=>{const o=new URL(pd(i.pathname),window.location.origin);l&&(o.search=i.search),navigator.clipboard.writeText(o.toString()),r({title:a??"Link copied to clipboard",expireMs:1e3})},children:n}),e(Bt,{offset:10,children:e(w,{padding:"size-100",backgroundColor:"light",borderColor:"dark",borderWidth:"thin",borderRadius:"small",children:e(C,{children:t})})})]})};function lf(n){return s(me,{children:[s(Pe,{children:[e(Re,{children:"Annotate"}),e(hn,{children:e(Ue,{slot:"close"})})]}),e(Ve,{children:e(K6,{...n})})]})}function X6({listeners:n,attributes:a},t){return e("button",{ref:t,...n,...a,"aria-roledescription":"draggable","aria-pressed":"false","aria-disabled":"false",className:"button--reset",css:p`
        cursor: grab;
        background-color: var(--ac-global-color-grey-200);
        border: 1px solid var(--ac-global-color-grey-400);
        color: var(--ac-global-text-color-900);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: var(--ac-global-dimension-size-100)
          var(--ac-global-dimension-size-50);
        border-radius: var(--ac-global-rounding-small);
        overflow: hidden;
      `,children:e("svg",{viewBox:"0 0 20 20",width:"12",fill:"currentColor",children:e("path",{d:"M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z"})})})}const rf=vn.forwardRef(X6);function of({preInitializationMinHeight:n,children:a}){const[t,l]=g.useState(!1),[i,r]=g.useState(!1),o=g.useRef(null);return g.useEffect(()=>{const c=new IntersectionObserver(([u])=>{l(u.isIntersecting)});o.current&&c.observe(o.current);const d=o.current;return()=>{d&&c.unobserve(d)}},[]),g.useLayoutEffect(()=>{t&&!i&&r(!0)},[i,t]),e("div",{ref:o,css:p`
        min-height: ${i?"auto":`${n}px`};
      `,children:a})}function sf(n){return Object.values(Je).includes(n)}function cf(n){return s("div",{role:"toolbar",css:p`
        padding: var(--ac-global-dimension-static-size-50)
          var(--ac-global-dimension-static-size-200);
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        gap: var(--ac-global-dimension-static-size-100);
        border-bottom: 1px solid var(--ac-global-border-color-dark);
        flex: none;
        min-height: 29px;
        .toolbar__main {
          display: flex;
          flex-direction: row;
          gap: var(--ac-global-dimension-static-size-100);
        }
      `,children:[e("div",{"data-testid":"toolbar-main",className:"toolbar__main",children:n.children}),n.extra?e("div",{"data-testid":"toolbar-extra",children:n.extra}):null]})}const Y6=p`
  /* Align with other toolbar components */
  .react-aria-Button {
    height: 30px;
    min-height: 30px;
  }

  .react-aria-Label {
    padding: 5px 0;
    display: inline-block;
    font-size: var(--ac-global-dimension-static-font-size-75);
    font-weight: var(--px-font-weight-heavy);
  }
`,J6=p`
  /* Target the button element specifically */
  button[aria-haspopup="listbox"] {
    border-radius: var(--ac-global-rounding-small) !important;

    &:hover {
      border-color: white !important;
    }
  }
`;function df(n){const{timeRange:a,timePreset:t,setTimePreset:l}=ad(),{primaryInferences:{name:i}}=Ka(),{fullTimeFormatter:r}=Bn(),o=i.slice(0,10);return e("div",{css:J6,children:s(j,{children:[s(We,{size:"S",value:t,"data-testid":"inferences-time-range","aria-label":"Time range for the primary inferences",onChange:c=>{c!==t&&l(c)},css:Y6,children:[s(P,{children:[o," inferences"]}),s(D,{children:[e(Ge,{}),e(ze,{})]}),e(C,{slot:"description",children:""}),e(le,{children:s(Ie,{children:[e(oe,{id:re.all,children:"All"},re.all),e(oe,{id:re.last_hour,children:"Last Hour"},re.last_hour),e(oe,{id:re.last_day,children:"Last Day"},re.last_day),e(oe,{id:re.last_week,children:"Last Week"},re.last_week),e(oe,{id:re.last_month,children:"Last Month"},re.last_month),e(oe,{id:re.last_3_months,children:"Last 3 Months"},re.last_3_months),e(oe,{id:re.first_hour,children:"First Hour"},re.first_hour),e(oe,{id:re.first_day,children:"First Day"},re.first_day),e(oe,{id:re.first_week,children:"First Week"},re.first_week),e(oe,{id:re.first_month,children:"First Month"},re.first_month)]})})]}),e(ge,{children:s("section",{css:p`
              h4 {
                margin-bottom: 0.5rem;
              }
            `,children:[e(Q,{level:4,children:"primary inferences time range"}),s("div",{children:["start: ",r(a.start)]}),s("div",{children:["end: ",r(a.end)]})]})})]})})}function uf({timeRange:n}){const{referenceInferences:a}=Ka(),{fullTimeFormatter:t}=Bn(),i=((a==null?void 0:a.name)??"reference").slice(0,10);return e("div",{css:p`
        .ac-textfield {
          min-width: 365px;
        }
      `,children:s(j,{children:[s(ee,{size:"S",isReadOnly:!0,"aria-label":"reference inferences time range",value:`${t(n.start)} - ${t(n.end)}`,children:[e(P,{children:`${i} inferences`}),e(W,{})]}),s(xe,{children:[e(ce,{}),"The static time range of the reference inferences"]})]})})}const x1=(function(){var n=[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],a=[{kind:"Variable",name:"after",variableName:"cursor"},{kind:"Variable",name:"first",variableName:"count"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},l={fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ModelSchemaTableDimensionsQuery",selections:[{args:[{kind:"Variable",name:"count",variableName:"count"},{kind:"Variable",name:"cursor",variableName:"cursor"},{kind:"Variable",name:"endTime",variableName:"endTime"},{kind:"Variable",name:"startTime",variableName:"startTime"}],kind:"FragmentSpread",name:"ModelSchemaTable_dimensions"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ModelSchemaTableDimensionsQuery",selections:[{alias:null,args:null,concreteType:"InferenceModel",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:a,concreteType:"DimensionConnection",kind:"LinkedField",name:"dimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dimension",args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null},{alias:"cardinality",args:[{kind:"Literal",name:"metric",value:"cardinality"},l],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"percentEmpty",args:[{kind:"Literal",name:"metric",value:"percentEmpty"},l],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"min",args:[{kind:"Literal",name:"metric",value:"min"},l],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"mean",args:[{kind:"Literal",name:"metric",value:"mean"},l],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"max",args:[{kind:"Literal",name:"metric",value:"max"},l],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"psi",args:[{kind:"Literal",name:"metric",value:"psi"},l],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:a,filters:null,handle:"connection",key:"ModelSchemaTable_dimensions",kind:"LinkedHandle",name:"dimensions"}],storageKey:null}]},params:{cacheID:"c622a7e3a3aa7a2463ab98779e6499a9",id:null,metadata:{},name:"ModelSchemaTableDimensionsQuery",operationKind:"query",text:`query ModelSchemaTableDimensionsQuery(
  $count: Int = 50
  $cursor: String = null
  $endTime: DateTime!
  $startTime: DateTime!
) {
  ...ModelSchemaTable_dimensions_4sIU9C
}

fragment ModelSchemaTable_dimensions_4sIU9C on Query {
  model {
    dimensions(first: $count, after: $cursor) {
      edges {
        dimension: node {
          id
          name
          type
          dataType
          cardinality: dataQualityMetric(metric: cardinality, timeRange: {start: $startTime, end: $endTime})
          percentEmpty: dataQualityMetric(metric: percentEmpty, timeRange: {start: $startTime, end: $endTime})
          min: dataQualityMetric(metric: min, timeRange: {start: $startTime, end: $endTime})
          mean: dataQualityMetric(metric: mean, timeRange: {start: $startTime, end: $endTime})
          max: dataQualityMetric(metric: max, timeRange: {start: $startTime, end: $endTime})
          psi: driftMetric(metric: psi, timeRange: {start: $startTime, end: $endTime})
        }
        cursor
        node {
          __typename
          id
        }
      }
      pageInfo {
        endCursor
        hasNextPage
      }
    }
  }
}
`}}})();x1.hash="fb4c57e0ea77548c4e96ceb418e06614";const T1=(function(){var n=["model","dimensions"],a={fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"};return{argumentDefinitions:[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],kind:"Fragment",metadata:{connection:[{count:"count",cursor:"cursor",direction:"forward",path:n}],refetch:{connection:{forward:{count:"count",cursor:"cursor"},backward:null,path:n},fragmentPathInResult:[],operation:x1}},name:"ModelSchemaTable_dimensions",selections:[{alias:null,args:null,concreteType:"InferenceModel",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:"dimensions",args:null,concreteType:"DimensionConnection",kind:"LinkedField",name:"__ModelSchemaTable_dimensions_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"dimension",args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null},{alias:"cardinality",args:[{kind:"Literal",name:"metric",value:"cardinality"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"percentEmpty",args:[{kind:"Literal",name:"metric",value:"percentEmpty"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"min",args:[{kind:"Literal",name:"metric",value:"min"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"mean",args:[{kind:"Literal",name:"metric",value:"mean"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"max",args:[{kind:"Literal",name:"metric",value:"max"},a],kind:"ScalarField",name:"dataQualityMetric",storageKey:null},{alias:"psi",args:[{kind:"Literal",name:"metric",value:"psi"},a],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null}})();T1.hash="fb4c57e0ea77548c4e96ceb418e06614";function mf(n){const{data:a}=F.usePaginationFragment(T1,n.model),t=g.useMemo(()=>a.model.dimensions.edges.map(({dimension:i})=>({...i})),[a]),l=vn.useMemo(()=>[{header:"name",accessorKey:"name",cell:r=>e(ja,{to:`dimensions/${r.row.original.id}`,children:r.renderValue()})},{header:"type",accessorKey:"type"},{header:"data type",accessorKey:"dataType"},{header:"cardinality",accessorKey:"cardinality",cell:U5},{header:"% empty",accessorKey:"percentEmpty",cell:G5},{header:"min",accessorKey:"min",cell:Xn},{header:"mean",accessorKey:"mean",cell:Xn},{header:"max",accessorKey:"max",cell:Xn},{header:"PSI",accessorKey:"psi",cell:Xn}],[]);return e(mo,{columns:l,data:t})}const I1=(function(){var n=[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],a=[{kind:"Variable",name:"after",variableName:"cursor"},{kind:"Variable",name:"first",variableName:"count"}],t={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ModelEmbeddingsTableEmbeddingDimensionsQuery",selections:[{args:[{kind:"Variable",name:"count",variableName:"count"},{kind:"Variable",name:"cursor",variableName:"cursor"},{kind:"Variable",name:"endTime",variableName:"endTime"},{kind:"Variable",name:"startTime",variableName:"startTime"}],kind:"FragmentSpread",name:"ModelEmbeddingsTable_embeddingDimensions"}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ModelEmbeddingsTableEmbeddingDimensionsQuery",selections:[{alias:null,args:null,concreteType:"InferenceModel",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:a,concreteType:"EmbeddingDimensionConnection",kind:"LinkedField",name:"embeddingDimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"EmbeddingDimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"embedding",args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[t,{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:"euclideanDistance",args:[{kind:"Literal",name:"metric",value:"euclideanDistance"},{fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"}],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},t],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:a,filters:null,handle:"connection",key:"ModelEmbeddingsTable_embeddingDimensions",kind:"LinkedHandle",name:"embeddingDimensions"}],storageKey:null}]},params:{cacheID:"fd1226f3c603a0c90b1c1657a894e691",id:null,metadata:{},name:"ModelEmbeddingsTableEmbeddingDimensionsQuery",operationKind:"query",text:`query ModelEmbeddingsTableEmbeddingDimensionsQuery(
  $count: Int = 50
  $cursor: String = null
  $endTime: DateTime!
  $startTime: DateTime!
) {
  ...ModelEmbeddingsTable_embeddingDimensions_4sIU9C
}

fragment ModelEmbeddingsTable_embeddingDimensions_4sIU9C on Query {
  model {
    embeddingDimensions(first: $count, after: $cursor) {
      edges {
        embedding: node {
          id
          name
          euclideanDistance: driftMetric(metric: euclideanDistance, timeRange: {start: $startTime, end: $endTime})
        }
        cursor
        node {
          __typename
          id
        }
      }
      pageInfo {
        endCursor
        hasNextPage
      }
    }
  }
}
`}}})();I1.hash="fb7f125f75d1d33a555c16e198dbcbf8";const z1=(function(){var n=["model","embeddingDimensions"];return{argumentDefinitions:[{defaultValue:50,kind:"LocalArgument",name:"count"},{defaultValue:null,kind:"LocalArgument",name:"cursor"},{defaultValue:null,kind:"LocalArgument",name:"endTime"},{defaultValue:null,kind:"LocalArgument",name:"startTime"}],kind:"Fragment",metadata:{connection:[{count:"count",cursor:"cursor",direction:"forward",path:n}],refetch:{connection:{forward:{count:"count",cursor:"cursor"},backward:null,path:n},fragmentPathInResult:[],operation:I1}},name:"ModelEmbeddingsTable_embeddingDimensions",selections:[{alias:null,args:null,concreteType:"InferenceModel",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:"embeddingDimensions",args:null,concreteType:"EmbeddingDimensionConnection",kind:"LinkedField",name:"__ModelEmbeddingsTable_embeddingDimensions_connection",plural:!1,selections:[{alias:null,args:null,concreteType:"EmbeddingDimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:"embedding",args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:"euclideanDistance",args:[{kind:"Literal",name:"metric",value:"euclideanDistance"},{fields:[{kind:"Variable",name:"end",variableName:"endTime"},{kind:"Variable",name:"start",variableName:"startTime"}],kind:"ObjectValue",name:"timeRange"}],kind:"ScalarField",name:"driftMetric",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null},{alias:null,args:null,concreteType:"EmbeddingDimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],type:"Query",abstractKey:null}})();z1.hash="fb7f125f75d1d33a555c16e198dbcbf8";function gf(n){const{data:a}=F.usePaginationFragment(z1,n.model),t=g.useMemo(()=>a.model.embeddingDimensions.edges.map(({embedding:i})=>({...i})),[a]),l=vn.useMemo(()=>[{header:"name",accessorKey:"name",cell:({row:r,renderValue:o})=>e(ja,{to:`embeddings/${r.original.id}`,children:o()})},{header:"euclidean distance",accessorKey:"euclideanDistance",cell:Xn}],[]);return e(mo,{columns:l,data:t})}const A1=g.createContext(null),e7=()=>{const n=g.useContext(A1);if(n===null)throw new Error("useTimeSlice must be used within a TimeSliceProvider");return n},pf=({initialTimestamp:n,children:a})=>{const[t,l]=g.useState(n),i=r=>{g.startTransition(()=>{l(r)})};return e(A1.Provider,{value:{selectedTimestamp:t,setSelectedTimestamp:i},children:a})};function n7(){const n=E(t=>t.setPointSizeScale),a=E(t=>t.pointSizeScale);return s(we,{children:[e(D,{variant:"default",size:"S",leadingVisual:e(x,{svg:e(b2,{})}),"aria-label":"Display Settings"}),e(le,{children:e(me,{children:e(w,{padding:"size-100",children:e(S,{direction:"column",gap:"size-100",children:e(Gu,{label:"Point Scale",minValue:0,maxValue:3,step:.1,value:a,onChange:n})})})})})]})}const yi=p`
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-static-size-50);
  align-items: center;
`;function a7(n){return typeof n=="string"&&n in _n}function t7(n){return s(fa,{selectedKeys:[n.mode],"aria-label":"Canvas Mode",size:"S",onSelectionChange:a=>{if(a.size===0)return;const t=a.keys().next().value;if(a7(t))n.onChange(t);else throw new Error(`Unknown canvas mode: ${a}`)},children:[s(j,{delay:0,children:[e(Ae,{"aria-label":"Move",id:_n.move,children:s("div",{css:yi,children:[e(x,{svg:e(f2,{})})," Move"]})}),e(xe,{placement:"top",offset:10,children:"Move around the canvas using orbital controls"})]}),s(j,{delay:0,children:[e(Ae,{"aria-label":"Select",id:_n.select,children:s("div",{css:yi,children:[e(x,{svg:e(h2,{})})," Select"]})}),e(xe,{placement:"top",offset:10,children:"Select points using the lasso tool"})]})]})}function l7({radius:n}){const a=E(d=>d.eventIdToDataMap),t=E(d=>d.highlightedClusterId),l=E(d=>d.selectedClusterId),i=E(d=>d.clusters),{theme:r}=de(),o=E(d=>d.clusterColorMode),c=g.useMemo(()=>i.map(d=>{const{eventIds:u}=d,m=u.map(h=>{var f;return{position:(f=a.get(h))==null?void 0:f.position}}).filter(h=>h.position!==null);return{...d,data:m}}).filter(d=>d.data.length>0),[i,a]);return e(B,{children:c.map((d,u)=>{const m=r7({selected:d.id===l,highlighted:d.id===t,clusterColorMode:o});return e(sc,{data:d.data,opacity:m,wireframe:!0,pointRadius:n,color:i7({theme:r,clusterColorMode:o,index:u,clusterCount:c.length})},`${d.id}__opacity_${String(m)}`)})})}function i7({theme:n,clusterColorMode:a,index:t,clusterCount:l}){return a===Jt.default?n==="dark"?"#999999":"#bbbbbb":ji(t/l)}function r7({selected:n,highlighted:a,clusterColorMode:t}){return t===Jt.highlight?1:n?.7:a?.5:0}const o7=2;function s7({pointRadius:n}){const a=E(u=>u.hoveredEventId),t=E(u=>u.pointSizeScale),l=E(u=>u.eventIdToDataMap),i=E(u=>u.pointGroupColors),r=E(u=>u.eventIdToGroup);if(a==null||l==null)return null;const o=l.get(a),c=r[a],d=i[c];return o==null?null:e(cc,{position:o.position,args:[n*o7],scale:[t,t,t],children:e("meshMatcapMaterial",{color:d,opacity:.7,transparent:!0})})}const vi=1;function c7(){const n=E(i=>i.hoveredEventId),a=E(i=>i.eventIdToDataMap),t=g.useRef(null);dc((i,r)=>{t.current&&t.current.children.forEach(o=>o.children[0].material.uniforms.dashOffset.value-=r*5)});const l=g.useMemo(()=>{if(n==null)return[];const i=a.get(n);if(i==null)return[];const r=i.retrievals??[];return(r==null?void 0:r.length)===0?[]:r.map(c=>{const d=a.get(c.documentId);return d==null?null:[i.position,d.position]}).filter(c=>c!=null)},[a,n]);return e("group",{ref:t,children:l.map((i,r)=>s("group",{children:[e(Kl,{start:i[0],end:i[1],color:16777215,opacity:1,transparent:!0,dashed:!0,dashScale:50,gapSize:20,linewidth:vi}),e(Kl,{start:i[0],end:i[1],color:16777215,linewidth:vi/2,transparent:!0,opacity:.8})]},r))})}const d7=.5,u7=.5,m7=100,Ci=1.7;function ki(n,a){return typeof a=="function"?a(n):a}function g7({primaryData:n,referenceData:a,corpusData:t,color:l,radius:i}){const r=E(K=>K.inferencesVisibility),o=E(K=>K.coloringStrategy),{theme:c}=de(),d=E(K=>K.setSelectedEventIds),u=E(K=>K.selectedEventIds),m=E(K=>K.setSelectedClusterId),h=E(K=>K.setHoveredEventId),b=E(K=>K.pointSizeScale),f=g.useMemo(()=>Vi(h,m7),[h]),y=g.useMemo(()=>o!==Y.inferences?"cube":"sphere",[o]),v=g.useMemo(()=>o!==Y.inferences?"octahedron":"sphere",[o]),L=g.useMemo(()=>c==="dark"?uc(d7):Zi(u7),[c]),k=g.useMemo(()=>typeof l=="function"?K=>L(l(K)):L(l),[l,L]),T=g.useCallback(K=>!u.has(K.metaData.id)&&u.size>0?ki(K,k):ki(K,l),[u,l,k]),I=r.reference&&a,V=r.corpus&&t,M=g.useCallback(K=>{g.startTransition(()=>{d(new Set([K.metaData.id])),m(null)})},[m,d]),_=g.useCallback(K=>{K==null||K.metaData==null||f(K.metaData.id)},[f]),H=g.useCallback(()=>{f(null)},[f]);return s(B,{children:[r.primary?e(tt,{data:n,pointProps:{color:T,radius:i,scale:b},onPointClicked:M,onPointHovered:_,onPointerLeave:H}):null,I?e(tt,{data:a,pointProps:{color:T,radius:i,size:i?i*Ci:void 0,scale:b},onPointHovered:_,onPointerLeave:H,pointShape:y,onPointClicked:M}):null,V?e(tt,{data:t,pointProps:{color:T,radius:i,size:i?i*Ci:void 0,scale:b},onPointHovered:_,onPointerLeave:H,pointShape:v,onPointClicked:M}):null]})}const p7=/\.(mp4|mov|webm|ogg)(\?|$)/i,h7=/\.(mp3|wav)(\?|$)/i;function f7(n){return p7.test(n)}function b7(n){return h7.test(n)}var dn=(n=>(n.square="square",n.circle="circle",n.diamond="diamond",n))(dn||{});const y7=()=>e("svg",{width:"12px",height:"12px",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("rect",{width:"12",height:"12",rx:"1",fill:"currentColor"})}),v7=()=>e("svg",{width:"12px",height:"12px",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("circle",{cx:"6",cy:"6",r:"6",fill:"currentColor"})}),C7=()=>e("svg",{width:"12px",height:"12px",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M6 0L12 6L6 12L0 6L6 0Z",fill:"currentColor"})});function M1(n){const{shape:a,color:t}=n,l=g.useMemo(()=>{switch(a){case"square":return e(y7,{});case"circle":return e(v7,{});case"diamond":return e(C7,{});default:N()}},[a]);return e("i",{className:"shape-icon",style:{color:t},css:p`
        display: flex;
        flex-direction: row;
        align-items: center;
      `,"aria-hidden":!0,children:l})}function k7(n){const{rawData:a,linkToData:t,promptAndResponse:l,documentText:i}=n;return i!=null?"document":l!=null?"prompt_response":t!=null?f7(t)?"video":b7(t)?"audio":"image":a!=null?"raw":"event_metadata"}function L7(n,a){const{rawData:t}=a;switch(n){case"document":return null;case"prompt_response":return null;case"image":return t!=null?"raw":null;case"video":return t!=null?"raw":null;case"audio":return t!=null?"raw":null;case"raw":return"event_metadata";case"event_metadata":return null;default:N()}}function S7(n){const{onClick:a,onMouseOver:t,onMouseOut:l,color:i,size:r,inferencesName:o,group:c}=n,d=k7(n),u=r==="large"?L7(d,n):null;return s("div",{"data-testid":"event-item",role:"button","data-size":r,css:p`
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        border-style: solid;
        border-radius: 4px;
        overflow: hidden;

        display: flex;
        flex-direction: column;
        cursor: pointer;
        overflow: hidden;

        border-width: 1px;
        border-color: ${i};
        border-radius: var(--ac-global-rounding-medium);
        transition: border-color 0.2s ease-in-out;
        transition: transform 0.2s ease-in-out;
        &:hover {
          transform: scale(1.04);
        }
        &[data-size="small"] {
          border-width: 2px;
        }
      `,onClick:a,onMouseOver:t,onMouseOut:l,children:[s("div",{className:"event-item__preview-wrap","data-size":r,css:p`
          display: flex;
          flex-direction: row;
          flex: 1 1 auto;
          overflow: hidden;
          & > *:nth-child(1) {
            flex: 1 1 auto;
            overflow: hidden;
          }
          & > *:nth-child(2) {
            flex: none;
            width: 43%;
          }
          &[data-size="large"] {
            & > *:nth-child(1) {
              margin: var(--ac-global-dimension-static-size-100);
              border-radius: 8px;
            }
          }
        `,children:[e(Li,{previewType:d,...n}),u!=null&&e(Li,{previewType:u,...n})]}),r!=="small"&&e(F7,{color:i,group:c,inferencesName:o,showInferences:r==="large"})]})}function Li(n){const{previewType:a}=n;let t=null;switch(a){case"document":{t=e(z7,{...n});break}case"prompt_response":{t=e(I7,{...n});break}case"image":{t=e(w7,{...n});break}case"video":{t=e(x7,{...n});break}case"audio":{t=e(T7,{...n});break}case"raw":{t=e(A7,{...n});break}case"event_metadata":{t=e(M7,{...n});break}default:N()}return t}function w7(n){return e("img",{src:n.linkToData||"[error] unexpected missing url",css:p`
        min-height: 0;
        // Maintain aspect ratio while having normalized height
        object-fit: contain;
        transition: background-color 0.2s ease-in-out;
        background-color: ${Ht(.85,n.color)};
      `})}function x7(n){return e("video",{src:n.linkToData||"[error] unexpected missing url",css:p`
        min-height: 0;
        // Maintain aspect ratio while having normalized height
        object-fit: contain;
        transition: background-color 0.2s ease-in-out;
        background-color: ${Ht(.85,n.color)};
      `})}function T7(n){return e("audio",{src:n.linkToData||"[error] unexpected missing url",autoPlay:n.autoPlay,controls:!0})}function I7(n){var a,t;return s("div",{"data-size":n.size,css:p`
        --prompt-response-preview-background-color: var(
          --ac-global-color-grey-200
        );
        background-color: var(--prompt-response-preview-background-color);
        &[data-size="small"] {
          display: flex;
          flex-direction: column;
          padding: var(--ac-global-dimension-static-size-50);
          font-size: var(--ac-global-dimension-static-font-size-75);
          section {
            flex: 1 1 0;
            overflow: hidden;
            header {
              display: none;
            }
          }
        }
        &[data-size="medium"] {
          display: flex;
          flex-direction: column;
          gap: var(--ac-global-dimension-static-size-50);
          padding: var(--ac-global-dimension-static-size-100);
          section {
            flex: 1 1 0;
            overflow: hidden;
          }
        }
        &[data-size="large"] {
          display: flex;
          flex-direction: row;
          section {
            padding: var(--ac-global-dimension-static-size-50);
            flex: 1 1 0;
          }
        }
        & > section {
          position: relative;

          header {
            font-weight: bold;
            margin-bottom: var(--ac-global-dimension-static-size-50);
          }
          &:before {
            content: "";
            width: 100%;
            height: 100%;
            position: absolute;
            left: 0;
            top: 0;
            background: linear-gradient(
              transparent 80%,
              var(--prompt-response-preview-background-color) 100%
            );
          }
        }
      `,children:[s("section",{children:[e("header",{children:"prompt"}),(a=n.promptAndResponse)==null?void 0:a.prompt]}),s("section",{children:[e("header",{children:"response"}),(t=n.promptAndResponse)==null?void 0:t.response]})]})}function z7(n){return e("p",{"data-size":n.size,css:p`
        flex: 1 1 auto;
        padding: var(--ac-global-dimension-static-size-100);
        margin-block-start: 0;
        margin-block-end: 0;
        position: relative;
        --text-preview-background-color: var(--ac-global-color-grey-100);
        background-color: var(--text-preview-background-color);

        &[data-size="small"] {
          padding: var(--ac-global-dimension-static-size-50);
          box-sizing: border-box;
        }
        &:before {
          content: "";
          width: 100%;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          background: linear-gradient(
            transparent 90%,
            var(--text-preview-background-color) 98%,
            var(--text-preview-background-color) 100%
          );
        }
      `,children:n.documentText})}function A7(n){return e("p",{"data-size":n.size,css:p`
        flex: 1 1 auto;
        padding: var(--ac-global-dimension-static-size-100);
        margin-block-start: 0;
        margin-block-end: 0;
        position: relative;
        --text-preview-background-color: var(--ac-background-color-light);
        background-color: var(--text-preview-background-color);

        &[data-size="small"] {
          padding: var(--ac-global-dimension-static-size-50);
          font-size: var(--ac-global-color-gray-600);
          box-sizing: border-box;
        }
        &:before {
          content: "";
          width: 100%;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          background: linear-gradient(
            transparent 90%,
            var(--text-preview-background-color) 98%,
            var(--text-preview-background-color) 100%
          );
        }
      `,children:n.rawData})}function M7(n){return s("dl",{css:p`
        margin: 0;
        padding: var(--ac-global-dimension-static-size-200);
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: var(--ac-global-dimension-static-size-100);

        dt {
          font-weight: bold;
        }
        dd {
          margin-inline-start: var(--ac-global-dimension-static-size-100);
        }
      `,children:[s("div",{children:[e("dt",{children:"prediction label"}),e("dd",{children:n.predictionLabel||"--"})]}),s("div",{children:[e("dt",{children:"actual label"}),e("dd",{children:n.actualLabel||"--"})]})]})}function F7({color:n,group:a,showInferences:t,inferencesName:l}){return s("footer",{css:p`
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        padding: var(--ac-global-dimension-static-size-50)
          var(--ac-global-dimension-static-size-100)
          var(--ac-global-dimension-static-size-50) 7px;
        border-top: 1px solid var(--ac-global-border-color-dark);
      `,children:[s("div",{css:p`
          display: flex;
          flex-direction: row;
          align-items: center;
          gap: var(--ac-global-dimension-static-size-50);
        `,children:[e(M1,{shape:dn.circle,color:n}),a]}),t?e("div",{title:"the inferences the point belongs to",children:l}):null]})}const Gn=200,ka=10,D7=new Bc,E7=()=>{const{getInferencesNameByRole:n}=Ka(),a=E(b=>b.hoveredEventId),t=E(b=>b.eventIdToDataMap),l=E(b=>b.pointData),i=E(b=>b.pointGroupColors),r=E(b=>b.eventIdToGroup);if(a==null||l==null||l==null)return null;const o=t.get(a),c=l[a];if(o==null||c==null)return null;const d=r[a],u=i[r[a]],m=kr(a),h=n(m);return e(mc,{position:o.position,pointerEvents:"none",zIndexRange:[0,1],calculatePosition:(b,f,y)=>{const v=D7.setFromMatrixPosition(b.matrixWorld);v.project(f);const L=y.width/2,k=y.height/2;return[Math.min(y.width-Gn-ka,Math.max(0,v.x*L+L+ka)),Math.min(y.height-Gn-ka,Math.max(0,-(v.y*k)+k+ka))]},children:e("div",{css:p`
          --grid-item-min-width: ${Gn}px;
          width: ${Gn}px;
          height: ${Gn}px;
          background-color: var(--ac-global-background-color-dark);
          border-radius: var(--ac-global-rounding-medium);
        `,children:e(S7,{rawData:o.embeddingMetadata.rawData,linkToData:o.embeddingMetadata.linkToData,predictionLabel:o.eventMetadata.predictionLabel,actualLabel:o.eventMetadata.actualLabel,promptAndResponse:c.promptAndResponse,documentText:c.documentText,inferencesName:h,group:d,color:u,size:"medium",autoPlay:!0})})})},K7=300,_7=3,V7=.2,P7=function(){const{selectedTimestamp:a}=e7(),{fullTimeFormatter:t}=Bn(),l=E(u=>u.points),i=E(u=>u.hdbscanParameters),r=E(u=>u.umapParameters),[o,c,d]=g.useMemo(()=>{const{primaryEventIds:u,referenceEventIds:m,corpusEventIds:h}=Yt(l.map(b=>b.eventId));return[u.length,m.length,h.length]},[l]);return a?s("section",{css:p`
        width: 300px;
      `,children:[e(Q,{level:2,weight:"heavy",style:{marginBottom:8},children:"Point Cloud Summary"}),s("dl",{css:Ct,children:[s("div",{children:[e("dt",{children:"Timestamp"}),e("dd",{children:t(a)})]}),s("div",{children:[e("dt",{children:"primary points"}),e("dd",{children:o})]}),c>0?s("div",{children:[e("dt",{children:"reference points"}),e("dd",{children:c})]}):null,d>0?s("div",{children:[e("dt",{children:"corpus points"}),e("dd",{children:d})]}):null]}),e("br",{}),e(Q,{level:4,weight:"heavy",children:"Clustering Parameters"}),s("dl",{css:Ct,children:[s("div",{children:[e("dt",{children:"min cluster size"}),e("dd",{children:i.minClusterSize})]}),s("div",{children:[e("dt",{children:"cluster min samples"}),e("dd",{children:i.clusterMinSamples})]}),s("div",{children:[e("dt",{children:"cluster selection epsilon"}),e("dd",{children:i.clusterSelectionEpsilon})]})]}),e("br",{}),e(Q,{level:4,weight:"heavy",children:"UMAP Parameters"}),s("dl",{css:Ct,children:[s("div",{children:[e("dt",{children:"min distance"}),e("dd",{children:r.minDist})]}),s("div",{children:[e("dt",{children:"n neighbors"}),e("dd",{children:r.nNeighbors})]}),s("div",{children:[e("dt",{children:"n samples per inferences"}),e("dd",{children:r.nSamples})]})]})]}):null},Ct=p`
  margin: 0;
  padding: 0;
  div {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: var(--ac-global-dimension-static-size-50);
  }
`;function R7(){const n=E(t=>t.canvasMode),a=E(t=>t.setCanvasMode);return s("div",{css:p`
        position: absolute;
        left: var(--ac-global-dimension-static-size-100);
        top: var(--ac-global-dimension-static-size-100);
        z-index: 1;
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: var(--ac-global-dimension-static-size-100);
      `,children:[e(t7,{mode:n,onChange:a}),e(n7,{}),e(N7,{})]})}function N7(){return s(j,{delay:0,children:[e(D,{size:"S",leadingVisual:e(x,{svg:e(Wa,{})}),"aria-label":"Information bout the point-cloud display"}),e(ge,{placement:"bottom left",children:e(P7,{})})]})}function O7({children:n}){const{theme:a}=de();return e("div",{css:p`
        flex: 1 1 auto;
        height: 100%;
        position: relative;
        &[data-theme="dark"] {
          background: linear-gradient(
            rgb(21, 25, 31) 11.4%,
            rgb(11, 12, 14) 70.2%
          );
        }
        &[data-theme="light"] {
          background: linear-gradient(#f2f6fd 0%, #dbe6fc 74%);
        }
      `,"data-theme":a,children:n})}function hf(){return s(O7,{children:[e(R7,{},"canvas-tools"),e($7,{},"projection")]})}const $7=g.memo(function(){const a=E(A=>A.points),t=E(A=>A.canvasMode),l=E(A=>A.setSelectedEventIds),i=E(A=>A.setSelectedClusterId),r=E(A=>A.pointGroupColors),o=E(A=>A.pointGroupVisibility),{theme:c}=de(),d=E(A=>A.inferencesVisibility),[u,m]=g.useState(!0),h=g.useMemo(()=>gc(a.map(A=>A.position)),[a]),b=(h.maxX-h.minX+(h.maxY-h.minY))/2/K7,f=b*_7,y=t===_n.move,v=E(A=>A.eventIdToGroup),L=g.useCallback(A=>{const O=v[A.metaData.id]||"unknown";return r[O]||In},[r,v]),k=g.useMemo(()=>a.filter(A=>A.eventId.includes("PRIMARY")),[a]),T=g.useMemo(()=>a.filter(A=>A.eventId.includes("REFERENCE")),[a]),I=g.useMemo(()=>a.filter(A=>A.eventId.includes("CORPUS")),[a]),V=g.useMemo(()=>k.filter(A=>{const O=v[A.eventId];return o[O]}),[k,v,o]),M=g.useMemo(()=>!T||T.length===0?null:T.filter(A=>{const O=v[A.eventId];return o[O]}),[T,v,o]),_=g.useMemo(()=>I.filter(A=>{const O=v[A.eventId];return o[O]}),[I,v,o]),H=g.useMemo(()=>{const A=d.primary?V:[],O=d.reference?M:[],R=d.corpus?_:[];return[...A,...O||[],...R||[]]},[V,M,_,d]),K=pc(Wt,Gt,Cc,qt);return e(vc,{camera:{position:[3,3,3]},children:s(K,{children:[e(hc,{autoRotate:u,autoRotateSpeed:2,enableRotate:y,enablePan:y,onEnd:()=>{m(!1)}}),s(fc,{bounds:h,boundsZoomPaddingFactor:V7,children:[e(bc,{points:H,onChange:A=>{l(new Set(A.map(O=>O.metaData.id))),i(null)},enabled:t===_n.select}),e(yc,{size:(h.maxX-h.minX)/4,color:c=="dark"?"#fff":"#505050"}),e(g7,{primaryData:V,referenceData:M,corpusData:_,color:L,radius:b}),e(l7,{radius:f}),e(E7,{}),e(s7,{pointRadius:b}),e(c7,{})]})]})})}),F1=(function(){var n=[{alias:null,args:null,concreteType:"InferenceModel",kind:"LinkedField",name:"model",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionConnection",kind:"LinkedField",name:"dimensions",plural:!1,selections:[{alias:null,args:null,concreteType:"DimensionEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"Dimension",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"type",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"dataType",storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DimensionPickerQuery",selections:n,type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DimensionPickerQuery",selections:n},params:{cacheID:"56e356d226d322dabfd9db8010884e4f",id:null,metadata:{},name:"DimensionPickerQuery",operationKind:"query",text:`query DimensionPickerQuery {
  model {
    dimensions {
      edges {
        node {
          id
          name
          type
          dataType
        }
      }
    }
  }
}
`}}})();F1.hash="747256fac1de97803ae6f96e3cb58d98";function B7(n){const{type:a}=n;let t="gray",l="";switch(a){case"feature":t="blue",l="FEA";break;case"tag":t="purple",l="TAG";break;case"prediction":t="white",l="PRE";break;case"actual":t="orange",l="ACT";break;default:N()}return e(Se,{color:t,"aria-Token":a,title:"type",children:l})}const H7=s(Q0,{children:[e(Q,{weight:"heavy",level:4,children:"Model Dimension"}),e(C,{children:"A dimension is a feature, tag, prediction, or actual value that is associated with a model inference. Features represent inputs, tags represent metadata, predictions represent outputs, and actuals represent ground truth."})]});function j7(n){const{selectedDimension:a,dimensions:t,onChange:l,isLoading:i}=n;return s("div",{children:[s(S,{direction:"row",alignItems:"center",gap:"size-25",children:[e(P,{children:"Dimension"}),H7]}),s(We,{defaultValue:a?a.name:void 0,"aria-label":"Select a dimension",onChange:r=>{const o=t.find(c=>c.name===r);o&&g.startTransition(()=>l(o))},isDisabled:i,"data-testid":"dimension-picker",children:[s(D,{children:[e(Ge,{}),e(ze,{})]}),e(le,{children:e(Ie,{children:t.map(r=>e(oe,{id:r.name,children:s(S,{direction:"row",alignItems:"center",gap:"size-100",children:[e(B7,{type:r.type}),r.name]})},r.name))})})]})]})}function Z7(n){const[a,t]=g.useState([]),[l,i]=g.useState(!0),{selectedDimension:r,onChange:o}=n;return g.useEffect(()=>{F.fetchQuery(ua,F1,{},{fetchPolicy:"store-or-network"}).toPromise().then(c=>{const d=(c==null?void 0:c.model.dimensions.edges.map(u=>u.node))??[];t(d),i(!1)})},[]),e(j7,{onChange:o,dimensions:a,selectedDimension:r,isLoading:l})}function U7(n){return typeof n=="string"&&n in Y}const G7=Object.values(Y);function W7(n){const{strategy:a,onChange:t}=n;return s(We,{defaultValue:a,"aria-label":"Coloring strategy",onChange:l=>{U7(l)&&t(l)},children:[e(P,{children:"Color By"}),s(D,{children:[e(Ge,{}),e(ze,{})]}),e(C,{slot:"description",children:""}),e(le,{children:e(Ie,{children:G7.map(l=>e(oe,{id:l,children:l},l))})})]})}function La(n){const{name:a,checked:t,onChange:l,color:i,iconShape:r=dn.circle}=n;return s(fn,{isSelected:t,name:a,onChange:l,children:[e(M1,{shape:r,color:i}),a]},a)}function Q7({hasReference:n,hasCorpus:a}){const t=E(b=>b.inferencesVisibility),l=E(b=>b.setInferencesVisibility),i=E(b=>b.coloringStrategy),r=g.useCallback((b,f)=>{l({...t,[f]:b})},[t,l]),o=Dc(),c=g.useMemo(()=>{switch(i){case Y.inferences:return o[0];case Y.correctness:case Y.dimension:return Ye;default:N()}},[i,o]),d=g.useMemo(()=>{switch(i){case Y.inferences:return o[1];case Y.correctness:case Y.dimension:return Ye;default:N()}},[i,o]),u=Ye,m=i===Y.inferences?dn.circle:dn.square,h=i===Y.inferences?dn.circle:dn.diamond;return s("form",{css:p`
        display: flex;
        flex-direction: column;
        gap: var(--ac-global-dimension-static-size-50);
        padding: var(--ac-global-dimension-static-size-100);
      `,children:[e(La,{checked:t.primary,name:"primary",color:c,onChange:b=>r(b,"primary")}),n?e(La,{checked:t.reference,name:"reference",onChange:b=>r(b,"reference"),color:d,iconShape:m}):null,a?e(La,{checked:t.corpus,name:"corpus",onChange:b=>r(b,"corpus"),color:u,iconShape:h}):null]})}function q7(){const n=E(r=>r.pointGroupVisibility),a=E(r=>r.setPointGroupVisibility),t=E(r=>r.pointGroupColors),l=g.useMemo(()=>Object.keys(n),[n]),i=g.useCallback((r,o)=>{a({...n,[o]:r})},[n,a]);return s("form",{css:p`
        display: flex;
        flex-direction: column;
      `,children:[e(X7,{}),e("div",{css:p`
          padding: var(--ac-global-dimension-static-size-100);
          display: flex;
          flex-direction: column;
          gap: var(--ac-global-dimension-static-size-50);
        `,children:l.map(r=>{const o=n[r],c=t[r];return e(La,{name:r,checked:o,color:c,onChange:d=>i(d,r)},r)})})]})}function X7(){const n=E(r=>r.pointGroupVisibility),a=E(r=>r.setPointGroupVisibility),t=E(r=>r.coloringStrategy),l=g.useMemo(()=>Object.values(n).every(r=>!r),[n]),i=g.useCallback(r=>{const o=Object.keys(n).reduce((c,d)=>(c[d]=r,c),{});a(o)},[n,a]);return e("div",{css:p`
        padding: var(--ac-global-dimension-static-size-50)
          var(--ac-global-dimension-static-size-100);
        background-color: var(--ac-global-background-color-light);
      `,children:e(fn,{isSelected:!l,name:"pointGroup",onChange:i,children:`${t}`})})}function ff(){const{referenceInferences:n,corpusInferences:a}=Ka(),t=E(h=>h.coloringStrategy),l=E(h=>h.setColoringStrategy),i=E(h=>h.dimension),r=E(h=>h.dimensionMetadata),o=E(h=>h.setDimension),c=n!=null||a!=null,d=t===Y.dimension&&i==null,u=t===Y.dimension&&i!=null&&r==null,m=t!==Y.inferences&&!d&&!u;return s("section",{css:p`
        padding: var(--ac-global-dimension-static-size-100)
          var(--ac-global-dimension-static-size-100) 0
          var(--ac-global-dimension-static-size-100);
        & > .ac-alert {
          margin: var(--ac-global-dimension-static-size-100);
        }
      `,children:[e(W7,{strategy:t,onChange:l}),t===Y.dimension?e(Z7,{selectedDimension:null,onChange:h=>{o(h)}}):null,c?e(Q7,{hasReference:n!=null,hasCorpus:a!=null}):null,m?e(q7,{}):null,d?e(On,{variant:"info",showIcon:!1,children:"Please select a dimension to color the point cloud by"}):null,u?e("div",{css:p`
            padding: var(--ac-global-dimension-static-size-100);
            min-height: 100px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
          `,children:e(ue,{message:"Calculating point colors"})}):null]})}function Y7(n){return typeof n=="string"&&n in Kn}function bf(n){return s(fa,{selectedKeys:[n.mode],size:"S",onSelectionChange:a=>{if(a.size===0)return;const t=a.keys().next().value;if(Y7(t))n.onChange(t);else throw new Error(`Unknown view mode: ${t}`)},children:[e(Ae,{"aria-label":"List",id:Kn.list,children:e(x,{svg:e($r,{})})}),e(Ae,{"aria-label":"Grid",id:Kn.gallery,children:e(x,{svg:e(Or,{})})})]})}function yf(n){const{driftRatio:a,primaryToCorpusRatio:t,clusterId:l,isSelected:i,onClick:r,onMouseEnter:o,onMouseLeave:c,metricName:d,primaryMetricValue:u,referenceMetricValue:m,hideReference:h}=n,{percentage:b,comparisonInferencesRole:f}=g.useMemo(()=>typeof t=="number"?{percentage:(t+1)/2*100,comparisonInferencesRole:_e.corpus}:typeof a=="number"?{percentage:(a+1)/2*100,comparisonInferencesRole:_e.reference}:{percentage:100,comparisonInferencesRole:null},[a,t]);return s("div",{css:p`
        border: 1px solid var(--ac-global-border-color-light);
        border-radius: var(--ac-global-rounding-medium);
        overflow: hidden;
        transition: background-color 0.2s ease-in-out;
        cursor: pointer;
        &:hover {
          background-color: var(--ac-global-color-primary-700);
          border-color: var(--ac-global-color-primary);
        }
        &.is-selected {
          border-color: var(--ac-global-color-primary);
          background-color: var(--ac-global-color-primary-700);
        }
      `,className:i?"is-selected":"",role:"button",onClick:r,onMouseEnter:o,onMouseLeave:c,children:[s("div",{css:p`
          padding: var(--ac-global-dimension-static-size-100);
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
        `,children:[e(S,{"data-testid":"cluster-description",direction:"column",gap:"size-50",alignItems:"start",children:s(S,{direction:"column",alignItems:"start",children:[e(Q,{level:3,children:`Cluster ${l}`}),e(C,{color:"text-700",size:"XS",children:`${n.numPoints} points`})]})}),s("div",{"data-testid":"cluster-metric",css:p`
            display: flex;
            flex-direction: column;
            align-items: end;
          `,children:[e(C,{color:"text-700",size:"XS",children:d}),e(C,{color:"text-900",size:"S",children:ci(u)}),h?null:e(C,{color:"purple-800",size:"XS",children:ci(m)})]})]}),e(J7,{primaryPercentage:b,comparisonInferencesRole:f})]})}function J7({primaryPercentage:n,comparisonInferencesRole:a}){return s("div",{"data-testid":"inferences-distribution",css:p`
        display: flex;
        flex-direction: row;
      `,children:[e("div",{"data-testid":"primary-distribution",css:p`
          background-image: linear-gradient(
            to right,
            var(--px-primary-color--transparent) 0%,
            var(--px-primary-color)
          );
          height: var(--px-gradient-bar-height);
          width: ${n}%;
        `}),e("div",{"data-testid":"reference-distribution","data-reference-inferences-role":`${a??"none"}`,css:p`
          &[data-reference-inferences-role="reference"] {
            background-image: linear-gradient(
              to right,
              var(--px-reference-color) 0%,
              var(--px-reference-color--transparent)
            );
          }
          &[data-reference-inferences-role="corpus"] {
            background-image: linear-gradient(
              to right,
              var(--px-corpus-color) 0%,
              var(--px-corpus-color--transparent)
            );
          }

          height: var(--px-gradient-bar-height);
          width: ${100-n}%;
        `})]})}function vf(){const n=E(d=>d.umapParameters),a=E(d=>d.setUMAPParameters),{handleSubmit:t,control:l,setError:i,formState:{isDirty:r,isValid:o}}=Oe({reValidateMode:"onChange",defaultValues:n}),c=g.useCallback(d=>{const u=parseFloat(d.minDist);if(u<rt||u>ot){i("minDist",{message:`must be between ${rt} and ${ot}`});return}a({minDist:u,nNeighbors:parseInt(d.nNeighbors,10),nSamples:parseInt(d.nSamples,10)})},[a,i]);return e("section",{css:p`
        & > .ac-form {
          padding: var(--ac-global-dimension-static-size-100)
            var(--ac-global-dimension-static-size-100) 0
            var(--ac-global-dimension-static-size-100);
        }
      `,children:e(an,{onSubmit:t(c),children:s(w,{padding:"size-100",children:[e(Z,{name:"minDist",control:l,rules:{required:"field is required"},render:({field:{onChange:d,onBlur:u,value:m},fieldState:{invalid:h,error:b}})=>s(ee,{type:"number",isInvalid:h,onChange:f=>d(parseFloat(f)),onBlur:u,value:m.toString(),size:"S",children:[e(P,{children:"min distance"}),e(W,{step:.01,min:rt,max:ot}),b?e(ae,{children:b.message}):e(C,{slot:"description",children:"how tightly to pack points"})]})}),e(Z,{name:"nNeighbors",control:l,rules:{required:"n neighbors is required",min:{value:lt,message:`greater than or equal to ${lt}`},max:{value:it,message:`less than or equal to ${it}`}},render:({field:d,fieldState:{invalid:u,error:m}})=>s(ee,{type:"number",isInvalid:u,...d,value:d.value,size:"S",children:[e(P,{children:"n neighbors"}),e(W,{step:.01,min:lt,max:it}),m?e(ae,{children:m.message}):e(C,{slot:"description",children:"Balances local versus global structure"})]})}),e(Z,{name:"nSamples",control:l,rules:{required:"n samples is required",max:{value:Pl,message:`must be below ${Pl}`},min:{value:Vl,message:`must be above ${Vl}`}},render:({field:{onChange:d,onBlur:u,value:m},fieldState:{invalid:h,error:b}})=>s(ee,{type:"number",isInvalid:h,onChange:f=>d(parseInt(f,10)),onBlur:u,value:m.toString(),size:"S",children:[e(P,{children:"n samples"}),e(W,{}),b?e(ae,{children:b.message}):e(C,{slot:"description",children:"number of points to use per inferences"})]})}),e(D,{variant:r?"primary":"default",type:"submit",isDisabled:!o,css:p`
              width: 100%;
              margin-top: var(--ac-global-dimension-static-size-100);
            `,children:"Apply UMAP Parameters"})]})})})}function Cf(){const n=E(u=>u.hdbscanParameters),a=E(u=>u.setHDBSCANParameters),t=E(u=>u.clustersLoading),{control:l,handleSubmit:i,formState:{isDirty:r,isValid:o},reset:c}=Oe({defaultValues:n}),d=g.useCallback(u=>{const m={minClusterSize:parseInt(u.minClusterSize,10),clusterMinSamples:parseInt(u.clusterMinSamples,10),clusterSelectionEpsilon:parseFloat(u.clusterSelectionEpsilon)};a(m),c(m)},[a,c]);return e("section",{css:p`
        & > .ac-form {
          padding: var(--ac-global-dimension-static-size-100)
            var(--ac-global-dimension-static-size-100) 0
            var(--ac-global-dimension-static-size-100);
        }
      `,children:e(an,{onSubmit:i(d),children:s(w,{padding:"size-100",children:[e(Z,{name:"minClusterSize",control:l,rules:{required:"field is required",min:{value:Gc,message:"must be greater than 1"},max:{value:yt,message:"must be less than 2,147,483,647"}},render:({field:{onChange:u,onBlur:m,value:h},fieldState:{invalid:b,error:f}})=>s(ee,{type:"number",isInvalid:b,onChange:y=>u(parseInt(y,10)),onBlur:m,value:h.toString(),size:"S",children:[e(P,{children:"Min Cluster Size"}),e(W,{}),f?e(ae,{children:f.message}):e(C,{slot:"description",children:"The smallest size for a cluster."})]})}),e(Z,{name:"clusterMinSamples",control:l,rules:{required:"field is required",min:{value:Rl,message:`must be greater than ${Rl}`},max:{value:yt,message:"must be less than 2,147,483,647"}},render:({field:{onBlur:u,onChange:m,value:h},fieldState:{invalid:b,error:f}})=>s(ee,{type:"number",isInvalid:b,onChange:y=>m(parseInt(y,10)),onBlur:u,value:h.toString(),size:"S",children:[e(P,{children:"Cluster Minimum Samples"}),e(W,{}),f?e(ae,{children:f.message}):e(C,{slot:"description",children:"Determines if a point is a core point"})]})}),e(Z,{name:"clusterSelectionEpsilon",control:l,rules:{required:"field is required",min:{value:0,message:"must be a non-negative number"},max:{value:yt,message:"must be less than 2,147,483,647"}},render:({field:{onBlur:u,onChange:m,value:h},fieldState:{invalid:b,error:f}})=>s(ee,{type:"number",isInvalid:b,onChange:y=>m(parseInt(y,10)),onBlur:u,value:h.toString(),size:"S",children:[e(P,{children:"Cluster Selection Epsilon"}),e(W,{}),f?e(ae,{children:f.message}):e(C,{slot:"description",children:"A distance threshold"})]})}),e(D,{variant:r?"primary":"default",type:"submit",isDisabled:!o||t,css:p`
              width: 100%;
              margin-top: var(--ac-global-dimension-static-size-100);
            `,children:t?"Applying...":"Apply Clustering Config"})]})})})}function e8(n){return typeof n=="string"&&n in Mn}function kf(n){return s(fa,{selectedKeys:[n.size],size:"S","aria-label":"Selection Grid Size",onSelectionChange:a=>{if(a.size===0)return;const t=a.keys().next().value;if(e8(t))n.onChange(t);else throw new Error(`Unknown grid size: ${t}`)},children:[e(Ae,{"aria-label":"Small",id:Mn.small,children:"S"}),e(Ae,{"aria-label":"Medium",id:Mn.medium,children:"M"}),e(Ae,{"aria-label":"Large",id:Mn.large,children:"L"})]})}const D1=(function(){var n={alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},a={alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},t={alias:null,args:null,kind:"ScalarField",name:"label",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"score",storageKey:null};return{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"SessionAnnotationSummaryGroup",selections:[{alias:null,args:null,concreteType:"Project",kind:"LinkedField",name:"project",plural:!1,selections:[n,{alias:null,args:null,concreteType:"AnnotationConfigConnection",kind:"LinkedField",name:"annotationConfigs",plural:!1,selections:[{alias:null,args:null,concreteType:"AnnotationConfigEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[{kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"annotationType",storageKey:null}],type:"AnnotationConfigBase",abstractKey:"__isAnnotationConfigBase"},{kind:"InlineFragment",selections:[n,a,{alias:null,args:null,kind:"ScalarField",name:"optimizationDirection",storageKey:null},{alias:null,args:null,concreteType:"CategoricalAnnotationValue",kind:"LinkedField",name:"values",plural:!0,selections:[t,l],storageKey:null}],type:"CategoricalAnnotationConfig",abstractKey:null}],storageKey:null}],storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"ProjectSessionAnnotation",kind:"LinkedField",name:"sessionAnnotations",plural:!0,selections:[n,a,t,l,{alias:null,args:null,kind:"ScalarField",name:"annotatorKind",storageKey:null},{alias:null,args:null,concreteType:"User",kind:"LinkedField",name:"user",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"username",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"profilePictureUrl",storageKey:null}],storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"AnnotationSummary",kind:"LinkedField",name:"sessionAnnotationSummaries",plural:!0,selections:[{alias:null,args:null,concreteType:"LabelFraction",kind:"LinkedField",name:"labelFractions",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"fraction",storageKey:null},t],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"meanScore",storageKey:null},a],storageKey:null}],type:"ProjectSession",abstractKey:null}})();D1.hash="f72bdfeda277b4656199eb3c48d958ce";const n8=n=>{const a=F.useFragment(D1,n),{sessionAnnotations:t,sessionAnnotationSummaries:l}=a,i=g.useMemo(()=>l.filter(c=>c.name!=="note").sort((c,d)=>c.name.localeCompare(d.name)),[l]),r=g.useMemo(()=>t.reduce((c,d)=>(d.label==null&&d.score==null||(c[d.name]?c[d.name]=[d,...c[d.name]]:c[d.name]=[d]),c),{}),[t]),o=g.useMemo(()=>a.project.annotationConfigs.edges.reduce((c,d)=>{const u=d.node.name;return u&&d.node.annotationType==="CATEGORICAL"&&(c[u]=d.node),c},{}),[a.project.annotationConfigs]);return{sortedSummariesByName:i,annotationsByName:r,categoricalAnnotationConfigsByName:o}},a8=p`
  min-height: 20px;
  align-items: center;
  justify-content: center;
  display: flex;
`,Lf=({session:n,showFilterActions:a=!1,renderEmptyState:t})=>{const{sortedSummariesByName:l,annotationsByName:i,categoricalAnnotationConfigsByName:r}=n8(n);return l.length===0&&t?t():e(S,{direction:"row",gap:"size-50",wrap:"wrap",children:l.map(o=>{var u;const c=(u=i[o.name])==null?void 0:u[0],d=o==null?void 0:o.meanScore;return c?e(Wo,{annotations:i[o.name],width:"500px",meanScore:d,showFilterActions:a,children:e(ro,{annotation:c,annotationDisplayPreference:"none",css:a8,clickable:!0,children:d!=null?e(Wi,{name:c.name,meanScore:d,size:"S",disableAnimation:!0,annotationConfig:r[c.name]}):null})},c.id):null})})};function kt(n){const{value:a}=n;return s("div",{className:"typescript-code-block",css:co,children:[e(pa,{text:a}),e(R5,{value:a})]})}const zl="https://app.phoenix.arize.com",t8="https://llamatrace.com",l8=[zl,t8],i8=l8.includes(Ln),Nt=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.25",y:"0.25",width:"31.5",height:"31.5"}),e("g",{mask:"url(#mask0_1112_37116)",children:e("path",{d:"M26.2795 13.8229C26.824 12.1886 26.6365 10.3984 25.7657 8.91186C24.4562 6.63186 21.8237 5.45886 19.2527 6.01086C18.109 4.72236 16.4657 3.98961 14.743 4.00011C12.115 3.99411 9.78324 5.68611 8.97474 8.18661C7.28649 8.53236 5.82924 9.58911 4.97649 11.0869C3.65724 13.3609 3.95799 16.2274 5.72049 18.1774C5.17599 19.8116 5.36349 21.6019 6.23424 23.0884C7.54374 25.3684 10.1762 26.5414 12.7472 25.9894C13.8902 27.2779 15.5342 28.0106 17.257 27.9994C19.8865 28.0061 22.219 26.3126 23.0275 23.8099C24.7157 23.4641 26.173 22.4074 27.0257 20.9096C28.3435 18.6356 28.042 15.7714 26.2802 13.8214L26.2795 13.8229ZM17.2585 26.4311C16.2062 26.4326 15.187 26.0644 14.3792 25.3901C14.416 25.3706 14.4797 25.3354 14.521 25.3099L19.3 22.5499C19.5445 22.4111 19.6945 22.1509 19.693 21.8696V15.1324L21.7127 16.2986C21.7345 16.3091 21.7487 16.3301 21.7517 16.3541V21.9334C21.7487 24.4144 19.7395 26.4259 17.2585 26.4311ZM7.59549 22.3039C7.06824 21.3934 6.87849 20.3261 7.05924 19.2904C7.09449 19.3114 7.15674 19.3496 7.20099 19.3751L11.98 22.1351C12.2222 22.2769 12.5222 22.2769 12.7652 22.1351L18.5995 18.7661V21.0986C18.601 21.1226 18.5897 21.1459 18.571 21.1609L13.7402 23.9501C11.5885 25.1891 8.84049 24.4526 7.59624 22.3039H7.59549ZM6.33774 11.8721C6.86274 10.9601 7.69149 10.2626 8.67849 9.90036C8.67849 9.94161 8.67624 10.0144 8.67624 10.0654V15.5861C8.67474 15.8666 8.82474 16.1269 9.06849 16.2656L14.9027 19.6339L12.883 20.8001C12.8627 20.8136 12.8372 20.8159 12.8147 20.8061L7.98324 18.0146C5.83599 16.7711 5.09949 14.0239 6.33699 11.8729L6.33774 11.8721ZM22.9322 15.7339L17.098 12.3649L19.1177 11.1994C19.138 11.1859 19.1635 11.1836 19.186 11.1934L24.0175 13.9826C26.1685 15.2254 26.9057 17.9771 25.663 20.1281C25.1372 21.0386 24.3092 21.7361 23.323 22.0991V16.4134C23.3252 16.1329 23.176 15.8734 22.933 15.7339H22.9322ZM24.9422 12.7084C24.907 12.6866 24.8447 12.6491 24.8005 12.6236L20.0215 9.86361C19.7792 9.72186 19.4792 9.72186 19.2362 9.86361L13.402 13.2326V10.9001C13.4005 10.8761 13.4117 10.8529 13.4305 10.8379L18.2612 8.05086C20.413 6.80961 23.164 7.54836 24.4045 9.70086C24.9287 10.6099 25.1185 11.6741 24.9407 12.7084H24.9422ZM12.304 16.8656L10.2835 15.6994C10.2617 15.6889 10.2475 15.6679 10.2445 15.6439V10.0646C10.246 7.58061 12.2612 5.56761 14.7452 5.56911C15.796 5.56911 16.813 5.93811 17.6207 6.61011C17.584 6.62961 17.521 6.66486 17.479 6.69036L12.7 9.45036C12.4555 9.58911 12.3055 9.84861 12.307 10.1299L12.304 16.8641V16.8656ZM13.4012 14.5001L16 12.9994L18.5987 14.4994V17.5001L16 19.0001L13.4012 17.5001V14.5001Z",fill:"var(--ac-global-text-color-900)"})})]}),r8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M24.3968 1.6001H7.60314C4.28768 1.6001 1.59998 4.28781 1.59998 7.60326V24.3969C1.59998 27.7124 4.28768 30.4001 7.60314 30.4001H24.3968C27.7123 30.4001 30.4 27.7124 30.4 24.3969V7.60326C30.4 4.28781 27.7123 1.6001 24.3968 1.6001Z",fill:"black"}),e("path",{d:"M20.4595 22.9326C20.3942 22.8597 20.3287 22.7869 20.2634 22.7142C19.8027 22.2107 19.5742 21.6292 19.7557 20.8584C18.0112 21.4241 16.3359 21.5521 14.6059 21.1564C14.5605 21.6739 14.5424 22.1469 14.4722 22.6121C14.3864 23.1814 14.2552 23.7437 14.1477 24.3097C14.1102 24.5069 14.069 24.7054 14.0567 24.9049C14.02 25.4989 14.0332 26.0987 13.9532 26.6862C13.912 26.9884 13.7144 27.2694 13.5982 27.535H12.303L12.31 27.5189C12.3792 27.3307 12.4482 27.1426 12.5174 26.9544L12.5139 26.9589C12.5839 26.8887 12.6537 26.8184 12.7237 26.7482L12.7192 26.7527C12.7545 26.7172 12.7899 26.6819 12.8252 26.6464L13.0159 26.6244C13.0344 26.3096 13.0315 26.4252 13.0344 26.3096C13.0482 25.7476 13.04 25.184 13.0099 24.6227C12.9987 24.4167 12.9055 24.215 12.8499 24.0114C12.8112 24.0124 12.7725 24.0134 12.7339 24.0144C12.5274 24.7594 12.3209 25.5046 12.1144 26.2496L12.1235 26.2456C11.9757 26.5136 11.7677 27.0334 11.6199 27.3014C11.436 27.318 10.9177 27.2861 10.4885 27.2886C10.5235 26.9346 10.6549 26.7491 10.878 26.5487C11.3579 26.118 11.487 25.4862 11.4852 24.8812C11.4827 24.0362 11.3699 23.1917 11.3042 22.3469C11.3974 22.1771 11.4514 21.9604 11.5899 21.8451C12.5272 21.0642 13.2919 20.1312 14.0057 19.1537C14.6967 18.2074 15.3922 17.2629 16.0434 16.2891C16.7605 15.2164 17.5035 14.1457 17.668 12.8106C18.8827 12.9386 20.0424 13.2344 21.131 13.8176C21.4637 13.9957 21.8812 14.0157 22.2597 14.1082C22.4 14.2166 22.608 14.2959 22.6692 14.4382C22.9775 15.1554 23.2792 15.8786 23.523 16.6194C23.8229 17.5306 23.903 18.4651 23.748 19.4289C23.5624 20.5829 23.0542 21.576 22.3997 22.5182C22.2909 22.675 22.2555 22.8829 22.1862 23.0672L22.1887 23.0642C22.075 23.1445 21.9549 23.2172 21.849 23.3065C21.5627 23.548 21.4935 24.0167 21.0379 24.0824C21.0317 24.0576 21.0287 24.0326 21.0292 24.0069C21.0052 23.9615 20.9814 23.9164 20.9574 23.8711C20.7914 23.5582 20.6252 23.2456 20.4592 22.9327L20.4595 22.9326ZM8.62136 9.51022C8.44703 9.50288 8.26653 9.63839 8.08886 9.70789C8.08886 9.70789 7.92619 11.0549 7.92619 11.7327C7.92619 12.4106 8.15803 12.9852 8.19736 13.6229C8.22536 14.0771 8.24753 14.5626 8.42353 14.9684C8.63486 15.4552 8.7267 15.9257 8.70036 16.4434C8.62736 17.8817 9.37319 18.8549 10.5164 19.5961C11.0305 19.0374 11.5887 18.5127 12.0495 17.9131C12.9719 16.7127 13.7595 15.4267 14.1932 13.9569C14.2835 13.6507 14.343 13.3357 14.4312 12.9639C14.4792 12.9149 14.5777 12.8141 14.6762 12.7132L12.3105 12.7066C12.2757 12.6751 12.2514 12.6529 12.2165 12.6214L11.9172 9.70205C10.8187 9.63455 9.72053 9.55639 8.62103 9.51005L8.62136 9.51022ZM11.0974 6.03072C10.7014 5.23139 10.1199 4.61372 9.23886 4.26172C9.22486 4.50289 9.21353 4.69605 9.2012 4.90972C8.90686 4.69755 8.64653 4.51005 8.31036 4.26772C8.35336 4.70072 8.39503 5.00289 8.41103 5.30655C8.44253 5.90689 8.18469 6.20839 7.58003 6.29239C7.46219 6.30872 7.33986 6.29239 7.22136 6.30622C6.86669 6.34722 6.67719 6.54672 6.62953 6.90005C6.56719 7.36139 6.80303 7.66355 7.18053 7.84722C7.57336 8.03839 7.99219 8.17639 8.47136 8.36605C8.40119 8.60255 8.32986 8.83639 8.26286 9.07139C8.20253 9.28289 8.14703 9.49572 8.08936 9.70805C8.26703 9.63855 8.44736 9.50305 8.62186 9.51039C9.72136 9.55672 10.8195 9.63472 11.918 9.70238C11.856 8.43122 11.6695 7.18522 11.0977 6.03105L11.0974 6.03072ZM22.7327 23.7432C22.7654 23.7774 22.7979 23.8114 22.8305 23.8456C22.8647 23.8799 22.8989 23.9142 22.933 23.9484C22.967 23.9811 23.0009 24.0137 23.0349 24.0464C23.1599 24.1296 23.2849 24.2129 23.4097 24.2961C23.4704 23.9702 23.8405 23.5016 24.1502 23.2742C24.278 23.1804 24.3344 22.9924 24.4334 22.8546C24.4887 22.7776 24.5649 22.7156 24.6317 22.6469C24.6047 22.4296 24.5622 22.2131 24.5539 21.9951C24.53 21.3696 24.5692 20.7522 24.3732 20.1277C24.1377 19.3777 24.2292 18.5857 24.2729 17.7916C24.9915 17.6471 25.2974 17.1784 25.3377 16.5476C25.3864 15.7856 25.2435 15.0506 24.7662 14.4271C24.424 13.9802 23.9605 13.7294 23.3855 13.8199C23.0047 13.8797 22.6349 14.0094 22.26 14.1079C22.4004 14.2162 22.6084 14.2956 22.6695 14.4379C22.9779 15.1551 23.2795 15.8782 23.5234 16.6191C23.8232 17.5302 23.9034 18.4647 23.7484 19.4286C23.5627 20.5826 23.0545 21.5757 22.4 22.5179C22.2912 22.6747 22.2559 22.8826 22.1865 23.0669C22.3687 23.2924 22.5507 23.5177 22.7329 23.7432H22.7327ZM16.429 12.7566C16.3242 14.1091 15.68 15.2467 14.965 16.3461C14.3355 17.3139 13.7025 18.2844 12.9959 19.1956C12.4884 19.8499 11.857 20.4084 11.2809 21.0096C11.2887 21.4552 11.2965 21.9011 11.3044 22.3467C11.3975 22.1769 11.4515 21.9602 11.59 21.8449C12.5274 21.0641 13.292 20.1311 14.0059 19.1536C14.6969 18.2072 15.3924 17.2627 16.0435 16.2889C16.7607 15.2162 17.5037 14.1456 17.6682 12.8104C17.2552 12.7924 16.8422 12.7746 16.4292 12.7566H16.429ZM11.0757 19.9797C11.6089 19.3922 12.2085 18.8511 12.6599 18.2062C13.3574 17.2101 13.9809 16.1586 14.582 15.1002C14.923 14.5001 15.171 13.8462 15.203 13.1314C15.2087 13.0027 15.3402 12.8799 15.4135 12.7542C15.3532 12.7559 15.293 12.7576 15.2327 12.7592C15.1554 12.7434 15.078 12.7274 15.0009 12.7116C14.8927 12.7122 14.7847 12.7127 14.6765 12.7134C14.578 12.8142 14.4794 12.9151 14.4315 12.9641C14.3434 13.3357 14.2837 13.6509 14.1935 13.9571C13.7599 15.4269 12.9722 16.7129 12.0499 17.9132C11.589 18.5129 11.0309 19.0376 10.5167 19.5962C10.703 19.7241 10.8894 19.8519 11.0757 19.9799V19.9797ZM15.712 12.7541C15.752 13.8777 15.2507 14.8322 14.7135 15.7546C14.1947 16.6451 13.6115 17.5002 13.0197 18.3452C12.6715 18.8424 12.2557 19.2926 11.8627 19.7576C11.6777 19.9764 11.4749 20.1802 11.28 20.3907C11.2804 20.5971 11.2805 20.8032 11.2809 21.0096C11.857 20.4084 12.4884 19.8499 12.9959 19.1956C13.7025 18.2846 14.3357 17.3141 14.965 16.3461C15.68 15.2467 16.3242 14.1091 16.429 12.7566C16.19 12.7557 15.951 12.7549 15.7119 12.7541H15.712ZM23.4289 24.3776C23.5199 24.5641 23.6867 24.7499 23.6879 24.9369C23.692 25.6002 23.6439 26.2644 23.6017 26.9272C23.598 26.9859 23.4942 27.0382 23.4369 27.0935C23.3985 27.1222 23.36 27.1509 23.3217 27.1796C23.2885 27.2149 23.2554 27.2502 23.2222 27.2854C23.186 27.3172 23.1497 27.3489 23.1135 27.3807C23.1704 27.4447 23.2244 27.5609 23.2844 27.564C23.6212 27.582 23.9594 27.5727 24.3122 27.5727C24.6089 26.8482 24.7105 26.1406 24.6009 25.4002C24.5792 25.2536 24.5384 25.0701 24.6017 24.9571C25.0337 24.1864 24.9189 23.4202 24.6317 22.6467C24.5649 22.7154 24.4887 22.7774 24.4334 22.8544C24.3344 22.9922 24.278 23.1802 24.1502 23.2741C23.8405 23.5014 23.4704 23.9701 23.4097 24.2959C23.4145 24.3234 23.4209 24.3505 23.4289 24.3774V24.3776ZM15.4137 12.7541C15.3404 12.8796 15.2089 13.0026 15.2032 13.1312C15.1712 13.8461 14.9232 14.4999 14.5822 15.1001C13.9809 16.1586 13.3575 17.2101 12.66 18.2061C12.2085 18.8509 11.609 19.3919 11.0759 19.9796C11.144 20.1166 11.212 20.2536 11.2802 20.3906C11.475 20.1799 11.6779 19.9762 11.8629 19.7574C12.2559 19.2926 12.6717 18.8422 13.0199 18.345C13.6115 17.5001 14.1949 16.6449 14.7137 15.7544C15.2509 14.8321 15.7522 13.8776 15.7122 12.7539C15.6127 12.7539 15.5134 12.7539 15.4139 12.7539L15.4137 12.7541ZM15.0009 12.7114C15.0782 12.7272 15.1555 12.7432 15.2327 12.7591C15.1554 12.7432 15.078 12.7272 15.0009 12.7114ZM12.2212 12.6641C12.251 12.6782 12.281 12.6924 12.3109 12.7066C12.2842 12.6857 12.2542 12.6716 12.2212 12.6641ZM20.2559 26.4779C20.1152 26.5756 19.9745 26.6732 19.8339 26.7709C19.8065 26.9284 19.7792 27.0859 19.7505 27.2509H20.9545C20.9545 27.0077 20.9384 26.7889 20.9602 26.5741C20.9747 26.4314 21.0054 26.2596 21.0949 26.1604C21.8912 25.2774 22.2055 24.2307 22.189 23.064C22.0754 23.1444 21.9552 23.2171 21.8494 23.3064C21.563 23.5479 21.4939 24.0166 21.0382 24.0822C21.0512 24.9702 20.7829 25.7662 20.256 26.4779H20.2559Z",fill:"url(#paint0_linear_1119_37286)"}),e("defs",{children:s("linearGradient",{id:"paint0_linear_1119_37286",x1:"3.72803",y1:"12.2264",x2:"26.5747",y2:"25.3626",gradientUnits:"userSpaceOnUse",children:[e("stop",{stopColor:"#F6DDD7"}),e("stop",{offset:"0.25",stopColor:"#FCABE6"}),e("stop",{offset:"0.3",stopColor:"#F3ADE6"}),e("stop",{offset:"0.38",stopColor:"#DDB3E8"}),e("stop",{offset:"0.48",stopColor:"#B8BCEC"}),e("stop",{offset:"0.59",stopColor:"#85CAF1"}),e("stop",{offset:"0.7",stopColor:"#50D8F6"}),e("stop",{offset:"0.76",stopColor:"#50D8F6"}),e("stop",{offset:"0.86",stopColor:"#B58FE8"})]})})]}),E1=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("rect",{x:"0.25",y:"0.25",width:"31.5",height:"31.5"}),e("path",{d:"M24.0371 13.2112C24.5781 13.7522 24.5781 14.6325 24.0371 15.1734L22.8253 16.3657L22.813 16.2974C22.7245 15.8074 22.4915 15.3627 22.1398 15.011C21.875 14.7467 21.5619 14.5513 21.2091 14.4303C20.9902 14.6504 20.8698 14.9388 20.8698 15.2423C20.8698 15.3039 20.8754 15.3678 20.8866 15.4316C21.0809 15.5016 21.2528 15.6097 21.3973 15.7542C21.9382 16.2951 21.9382 17.1754 21.3973 17.7164L20.3422 18.7714C20.0718 19.0419 19.7167 19.1769 19.3611 19.1769C19.0055 19.1769 18.6505 19.0419 18.38 18.7714C17.839 18.2305 17.839 17.3502 18.38 16.8092L19.5918 15.6175L19.6042 15.6858C19.6921 16.1747 19.925 16.6194 20.2778 16.9716C20.5433 17.237 20.8373 17.4134 21.1895 17.5338L21.2545 17.4689C21.4516 17.2718 21.5597 17.0097 21.5597 16.7302C21.5597 16.6681 21.5541 16.6059 21.5434 16.5449C21.3402 16.4777 21.1727 16.3819 21.0204 16.2296C20.8009 16.0101 20.6642 15.7295 20.6262 15.4187C20.6234 15.3963 20.6217 15.3745 20.6194 15.3521C20.5892 14.9472 20.7354 14.5518 21.0204 14.2674L22.0754 13.2123C22.337 12.9508 22.6853 12.8063 23.0566 12.8063C23.4278 12.8063 23.7762 12.9502 24.0377 13.2123L24.0371 13.2112ZM29.5464 16C29.5464 19.8601 26.4059 23 22.5464 23H9C5.14048 23 2 19.8601 2 16C2 12.1399 5.14048 9 9 9H22.5464C26.4065 9 29.5464 12.1405 29.5464 16ZM15.4904 19.5106C15.6007 19.3768 15.0911 18.9999 14.987 18.8616C14.7753 18.632 14.7742 18.3016 14.6314 18.0334C14.2819 17.2236 13.8804 16.42 13.3187 15.7346C12.7251 14.9847 11.9926 14.3642 11.3492 13.6603C10.8715 13.1692 10.7438 12.4698 10.3222 11.9417C9.74088 11.0832 7.90296 10.8491 7.6336 12.0615C7.63472 12.0996 7.62296 12.1237 7.58992 12.1478C7.44096 12.2558 7.30824 12.3796 7.1968 12.5291C6.92408 12.9088 6.88208 13.5528 7.22256 13.8938C7.23376 13.7141 7.23992 13.5444 7.38216 13.4156C7.64536 13.6413 8.04296 13.7214 8.34816 13.5528C9.0224 14.5154 8.8544 15.8471 9.38976 16.8842C9.5376 17.1295 9.68656 17.3798 9.8764 17.5949C10.0304 17.8346 10.5624 18.1174 10.5938 18.3391C10.5994 18.7199 10.5546 19.136 10.8043 19.4546C10.9219 19.6932 10.633 19.9329 10.4 19.9032C10.0976 19.9446 9.72856 19.6999 9.46368 19.8506C9.37016 19.9519 9.18704 19.8399 9.1064 19.9805C9.0784 20.0533 8.9272 20.1558 9.01736 20.2258C9.1176 20.1496 9.21056 20.0701 9.34552 20.1154C9.32536 20.2252 9.41216 20.2409 9.48104 20.2728C9.4788 20.3473 9.43512 20.4234 9.49224 20.4867C9.55888 20.4195 9.59864 20.3243 9.70448 20.2963C10.0562 20.765 10.414 19.822 11.175 20.2465C11.0205 20.2386 10.8833 20.2582 10.7791 20.3854C10.7534 20.4139 10.7315 20.4475 10.7769 20.4845C11.1874 20.2196 11.1851 20.5752 11.4517 20.466C11.6566 20.359 11.8605 20.2252 12.1041 20.2633C11.8672 20.3316 11.8577 20.522 11.7188 20.6827C11.6953 20.7074 11.6841 20.7354 11.7115 20.7762C12.2032 20.7348 12.2435 20.5713 12.6406 20.3708C12.9368 20.1899 13.2319 20.6284 13.4884 20.3786C13.545 20.3243 13.6222 20.3428 13.6922 20.3355C13.6026 19.8578 12.6176 20.4229 12.6333 19.7822C12.9502 19.5666 12.8774 19.1539 12.8987 18.8207C13.2633 19.0229 13.6687 19.1405 14.026 19.3337C14.2063 19.6249 14.4891 20.0096 14.866 19.9844C14.8761 19.9553 14.885 19.9295 14.8957 19.8998C15.0099 19.9194 15.1566 19.995 15.2194 19.8506C15.3902 20.0292 15.641 20.0202 15.8645 19.9743C16.0297 19.8399 15.5537 19.6484 15.4898 19.5101L15.4904 19.5106ZM25.4926 14.1923C25.4926 13.5405 25.2394 12.9284 24.7797 12.4686C24.3199 12.0089 23.7078 11.7558 23.0554 11.7558C22.403 11.7558 21.791 12.0089 21.3312 12.4686L20.2762 13.5237C20.0298 13.7701 19.8427 14.0596 19.7201 14.3838L19.7128 14.4023L19.6938 14.4079C19.3107 14.5261 18.973 14.7288 18.6902 15.0116L17.6352 16.0666C16.6849 17.0175 16.6849 18.5642 17.6352 19.5146C18.095 19.9743 18.707 20.2274 19.3589 20.2274C20.0107 20.2274 20.6234 19.9743 21.0831 19.5146L22.1382 18.4595C22.3834 18.2142 22.5694 17.9258 22.692 17.6022L22.6993 17.5837L22.7183 17.5775C23.0946 17.4622 23.4418 17.2527 23.7235 16.9716L24.7786 15.9166C25.2383 15.4568 25.4914 14.8447 25.4914 14.1923H25.4926ZM11.6533 18.7216C11.5626 19.0755 11.5329 19.6786 11.0726 19.696C11.0345 19.9004 11.2142 19.9771 11.3772 19.9116C11.539 19.8371 11.6158 19.9704 11.6701 20.1031C11.9198 20.1395 12.2894 20.0197 12.3034 19.724C11.9305 19.509 11.8151 19.1002 11.6527 18.7216H11.6533Z",fill:"var(--ac-global-text-color-900)"})]}),o8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M29.5341 0H2.46593C1.10403 0 0 1.10403 0 2.46593V29.5341C0 30.896 1.10403 32 2.46593 32H29.5341C30.896 32 32 30.896 32 29.5341V2.46593C32 1.10403 30.896 0 29.5341 0Z",fill:"#0EAF9C"}),e("path",{d:"M24.1471 21.3058C24.1471 21.4934 23.9942 21.6447 23.806 21.6447C22.1086 21.6447 20.7328 20.2777 20.7328 18.5913V13.1026C20.7328 10.6667 18.7453 8.69255 16.2944 8.69255C13.8435 8.69255 11.9651 10.6674 11.9651 13.1026V15.1358C11.9611 15.3197 12.1082 15.4716 12.2925 15.4749C12.2951 15.4749 12.2971 15.4749 12.2997 15.4749H14.2389C14.4271 15.4787 14.5833 15.33 14.5872 15.1424C14.5872 15.1398 14.5872 15.1378 14.5872 15.1352V13.0201C14.5872 12.083 15.3513 11.3239 16.2944 11.3239C17.2375 11.3239 18.0016 12.083 18.0016 13.0201V25.7697C17.9976 25.9606 17.8388 26.1126 17.6466 26.1086C15.9571 26.1086 14.5872 24.7475 14.5872 23.0689C14.5872 23.0643 14.5872 23.0597 14.5872 23.0552V18.9842C14.5833 18.7958 14.4284 18.6451 14.2389 18.6451H12.2997C12.1147 18.6451 11.9651 18.7939 11.9651 18.9776C11.9651 18.9802 11.9651 18.9822 11.9651 18.9848V20.342C11.9651 22.0285 10.4801 23.3955 8.78276 23.3955C8.59391 23.3955 8.44165 23.2436 8.44165 23.0565V13.1033C8.44165 8.79386 11.9572 5.30078 16.2944 5.30078C20.6315 5.30078 24.1471 8.79386 24.1471 13.1033V21.3058Z",fill:"white"})]}),s8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[s("g",{clipPath:"url(#clip0_1112_37203)",children:[e("path",{d:"M29.0909 0H23.2727V6.39251H29.0909V0Z",fill:"black"}),e("path",{d:"M32 0H26.1818V6.39251H32V0Z",fill:"#F7D046"}),e("path",{d:"M5.81818 0H0V6.39251H5.81818V0Z",fill:"black"}),e("path",{d:"M5.81818 6.39258H0V12.7851H5.81818V6.39258Z",fill:"black"}),e("path",{d:"M5.81818 12.7852H0V19.1777H5.81818V12.7852Z",fill:"black"}),e("path",{d:"M5.81818 19.1777H0V25.5702H5.81818V19.1777Z",fill:"black"}),e("path",{d:"M5.81818 25.5698H0V31.9623H5.81818V25.5698Z",fill:"black"}),e("path",{d:"M8.7273 0H2.90912V6.39251H8.7273V0Z",fill:"#F7D046"}),e("path",{d:"M32 6.39258H26.1818V12.7851H32V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M8.7273 6.39258H2.90912V12.7851H8.7273V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M23.2727 6.39258H17.4545V12.7851H23.2727V6.39258Z",fill:"black"}),e("path",{d:"M26.1818 6.39258H20.3636V12.7851H26.1818V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M14.5455 6.39258H8.72729V12.7851H14.5455V6.39258Z",fill:"#F2A73B"}),e("path",{d:"M20.3637 12.7852H14.5455V19.1777H20.3637V12.7852Z",fill:"#EE792F"}),e("path",{d:"M26.1818 12.7852H20.3636V19.1777H26.1818V12.7852Z",fill:"#EE792F"}),e("path",{d:"M14.5455 12.7852H8.72729V19.1777H14.5455V12.7852Z",fill:"#EE792F"}),e("path",{d:"M17.4545 19.1777H11.6364V25.5702H17.4545V19.1777Z",fill:"black"}),e("path",{d:"M20.3637 19.1777H14.5455V25.5702H20.3637V19.1777Z",fill:"#EB5829"}),e("path",{d:"M32 12.7852H26.1818V19.1777H32V12.7852Z",fill:"#EE792F"}),e("path",{d:"M8.7273 12.7852H2.90912V19.1777H8.7273V12.7852Z",fill:"#EE792F"}),e("path",{d:"M29.0909 19.1777H23.2727V25.5702H29.0909V19.1777Z",fill:"black"}),e("path",{d:"M32 19.1777H26.1818V25.5702H32V19.1777Z",fill:"#EB5829"}),e("path",{d:"M29.0909 25.5698H23.2727V31.9623H29.0909V25.5698Z",fill:"black"}),e("path",{d:"M8.7273 19.1777H2.90912V25.5702H8.7273V19.1777Z",fill:"#EB5829"}),e("path",{d:"M32 25.5698H26.1818V31.9623H32V25.5698Z",fill:"#EA3326"}),e("path",{d:"M8.7273 25.5698H2.90912V31.9623H8.7273V25.5698Z",fill:"#EA3326"})]}),e("defs",{children:e("clipPath",{id:"clip0_1112_37203",children:e("rect",{width:"32",height:"32",fill:"white"})})})]}),c8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M26.6667 18.52C26.5078 18.3292 26.2852 18.2025 26.04 18.1633C25.7949 18.1241 25.5438 18.175 25.3333 18.3067L16 25.16V25.4533C16.1347 25.4374 16.2712 25.4501 16.4005 25.4908C16.5299 25.5314 16.6492 25.5989 16.7506 25.689C16.852 25.7791 16.9331 25.8896 16.9887 26.0133C17.0442 26.137 17.0729 26.2711 17.0729 26.4067C17.0729 26.5423 17.0442 26.6763 16.9887 26.8C16.9331 26.9237 16.852 27.0342 16.7506 27.1243C16.6492 27.2144 16.5299 27.2819 16.4005 27.3226C16.2712 27.3632 16.1347 27.3759 16 27.36C16.2165 27.361 16.4274 27.2907 16.6 27.16L26.48 19.8667C26.6725 19.7053 26.7982 19.4781 26.8327 19.2293C26.8672 18.9804 26.808 18.7277 26.6667 18.52Z",fill:"#669DF6"}),e("path",{d:"M16 27.3598C15.7666 27.3322 15.5514 27.2198 15.3953 27.0441C15.2392 26.8684 15.153 26.6415 15.153 26.4065C15.153 26.1714 15.2392 25.9446 15.3953 25.7689C15.5514 25.5931 15.7666 25.4808 16 25.4532V25.1598L6.66669 18.3065C6.45707 18.172 6.20525 18.1194 5.95931 18.1587C5.71337 18.1981 5.49054 18.3266 5.33335 18.5198C5.19277 18.7276 5.13659 18.981 5.17621 19.2287C5.21584 19.4764 5.34831 19.6997 5.54669 19.8532L15.4267 27.1465C15.5952 27.2753 15.8012 27.3455 16.0134 27.3465L16 27.3598Z",fill:"#AECBFA"}),e("path",{d:"M16 24.4531C15.6123 24.4531 15.2334 24.5681 14.9111 24.7834C14.5887 24.9988 14.3375 25.3049 14.1892 25.6631C14.0408 26.0212 14.002 26.4153 14.0776 26.7955C14.1533 27.1757 14.3399 27.5249 14.614 27.7991C14.8882 28.0732 15.2374 28.2598 15.6176 28.3355C15.9978 28.4111 16.3919 28.3723 16.75 28.2239C17.1082 28.0756 17.4143 27.8244 17.6297 27.502C17.845 27.1797 17.96 26.8008 17.96 26.4131C17.96 25.8933 17.7535 25.3948 17.3859 25.0272C17.0183 24.6596 16.5198 24.4531 16 24.4531ZM16 27.3598C15.8095 27.3598 15.6234 27.3031 15.4653 27.197C15.3071 27.0909 15.1841 26.9402 15.1119 26.764C15.0396 26.5878 15.0214 26.3941 15.0595 26.2075C15.0977 26.021 15.1904 25.85 15.326 25.7162C15.4616 25.5825 15.6339 25.4922 15.821 25.4566C16.0081 25.4211 16.2015 25.442 16.3767 25.5168C16.5519 25.5915 16.7008 25.7166 16.8047 25.8762C16.9086 26.0358 16.9626 26.2227 16.96 26.4131C16.96 26.5386 16.9351 26.6628 16.8867 26.7785C16.8383 26.8942 16.7673 26.9992 16.678 27.0873C16.5887 27.1754 16.4827 27.2448 16.3663 27.2916C16.25 27.3384 16.1254 27.3616 16 27.3598Z",fill:"#4285F4"}),e("path",{d:"M8.00001 8.14679C7.73587 8.14333 7.48352 8.03687 7.29673 7.85008C7.10993 7.66328 7.00347 7.41093 7.00001 7.14679V4.64012C6.98365 4.4982 6.99749 4.35441 7.04061 4.21821C7.08373 4.08201 7.15517 3.95647 7.25023 3.84982C7.34529 3.74317 7.46183 3.65782 7.5922 3.59939C7.72256 3.54095 7.86382 3.51074 8.00668 3.51074C8.14955 3.51074 8.2908 3.54095 8.42117 3.59939C8.55153 3.65782 8.66807 3.74317 8.76313 3.84982C8.85819 3.95647 8.92963 4.08201 8.97275 4.21821C9.01587 4.35441 9.02971 4.4982 9.01335 4.64012V7.14679C9.00984 7.41322 8.90153 7.66756 8.71188 7.85472C8.52222 8.04188 8.26647 8.14681 8.00001 8.14679Z",fill:"#AECBFA"}),e("path",{d:"M7.97336 17.0135C8.533 17.0135 8.98669 16.5598 8.98669 16.0002C8.98669 15.4405 8.533 14.9868 7.97336 14.9868C7.41371 14.9868 6.96002 15.4405 6.96002 16.0002C6.96002 16.5598 7.41371 17.0135 7.97336 17.0135Z",fill:"#AECBFA"}),e("path",{d:"M7.97336 14.0667C8.533 14.0667 8.98669 13.613 8.98669 13.0534C8.98669 12.4937 8.533 12.04 7.97336 12.04C7.41371 12.04 6.96002 12.4937 6.96002 13.0534C6.96002 13.613 7.41371 14.0667 7.97336 14.0667Z",fill:"#AECBFA"}),e("path",{d:"M7.97336 11.1067C8.533 11.1067 8.98669 10.6531 8.98669 10.0934C8.98669 9.53376 8.533 9.08008 7.97336 9.08008C7.41371 9.08008 6.96002 9.53376 6.96002 10.0934C6.96002 10.6531 7.41371 11.1067 7.97336 11.1067Z",fill:"#AECBFA"}),e("path",{d:"M24 11.0801C23.7336 11.0766 23.4792 10.9682 23.2921 10.7786C23.1049 10.5889 23 10.3332 23 10.0667V7.56006C23 7.29484 23.1054 7.04049 23.2929 6.85295C23.4804 6.66542 23.7348 6.56006 24 6.56006C24.2652 6.56006 24.5196 6.66542 24.7071 6.85295C24.8946 7.04049 25 7.29484 25 7.56006V10.0667C25.0018 10.1992 24.9772 10.3306 24.9277 10.4535C24.8783 10.5764 24.8049 10.6882 24.7119 10.7825C24.6188 10.8767 24.508 10.9516 24.3858 11.0027C24.2636 11.0538 24.1325 11.0801 24 11.0801Z",fill:"#4285F4"}),e("path",{d:"M24.0266 17.0267C24.5863 17.0267 25.04 16.573 25.04 16.0133C25.04 15.4537 24.5863 15 24.0266 15C23.467 15 23.0133 15.4537 23.0133 16.0133C23.0133 16.573 23.467 17.0267 24.0266 17.0267Z",fill:"#4285F4"}),e("path",{d:"M24.0266 14.0267C24.5863 14.0267 25.04 13.573 25.04 13.0133C25.04 12.4537 24.5863 12 24.0266 12C23.467 12 23.0133 12.4537 23.0133 13.0133C23.0133 13.573 23.467 14.0267 24.0266 14.0267Z",fill:"#4285F4"}),e("path",{d:"M24.0266 5.65313C24.5863 5.65313 25.04 5.19945 25.04 4.6398C25.04 4.08015 24.5863 3.62646 24.0266 3.62646C23.467 3.62646 23.0133 4.08015 23.0133 4.6398C23.0133 5.19945 23.467 5.65313 24.0266 5.65313Z",fill:"#4285F4"}),e("path",{d:"M16 20.0001C15.7359 19.9967 15.4835 19.8902 15.2967 19.7034C15.1099 19.5166 15.0035 19.2642 15 19.0001V16.4534C15.0285 16.2064 15.1468 15.9785 15.3324 15.813C15.518 15.6476 15.758 15.5562 16.0067 15.5562C16.2553 15.5562 16.4953 15.6476 16.6809 15.813C16.8665 15.9785 16.9849 16.2064 17.0133 16.4534V18.9734C17.0151 19.1076 16.9902 19.2408 16.9401 19.3653C16.8899 19.4898 16.8156 19.6031 16.7213 19.6986C16.627 19.7941 16.5147 19.87 16.3909 19.9217C16.2671 19.9735 16.1342 20.0001 16 20.0001Z",fill:"#669DF6"}),e("path",{d:"M16 22.9466C16.5597 22.9466 17.0134 22.4929 17.0134 21.9333C17.0134 21.3736 16.5597 20.9199 16 20.9199C15.4404 20.9199 14.9867 21.3736 14.9867 21.9333C14.9867 22.4929 15.4404 22.9466 16 22.9466Z",fill:"#669DF6"}),e("path",{d:"M16 14.5335C16.5597 14.5335 17.0134 14.0798 17.0134 13.5202C17.0134 12.9605 16.5597 12.5068 16 12.5068C15.4404 12.5068 14.9867 12.9605 14.9867 13.5202C14.9867 14.0798 15.4404 14.5335 16 14.5335Z",fill:"#669DF6"}),e("path",{d:"M16 11.5735C16.5597 11.5735 17.0134 11.1199 17.0134 10.5602C17.0134 10.0006 16.5597 9.54688 16 9.54688C15.4404 9.54688 14.9867 10.0006 14.9867 10.5602C14.9867 11.1199 15.4404 11.5735 16 11.5735Z",fill:"#669DF6"}),e("path",{d:"M20 14.0535C19.7359 14.0501 19.4835 13.9436 19.2967 13.7568C19.1099 13.57 19.0035 13.3177 19 13.0535V10.5469C18.9837 10.4049 18.9975 10.2612 19.0406 10.125C19.0837 9.98875 19.1552 9.8632 19.2502 9.75655C19.3453 9.64991 19.4618 9.56456 19.5922 9.50613C19.7226 9.44769 19.8638 9.41748 20.0067 9.41748C20.1495 9.41748 20.2908 9.44769 20.4212 9.50613C20.5515 9.56456 20.6681 9.64991 20.7631 9.75655C20.8582 9.8632 20.9296 9.98875 20.9728 10.125C21.0159 10.2612 21.0297 10.4049 21.0133 10.5469V13.0535C21.0098 13.32 20.9015 13.5743 20.7119 13.7615C20.5222 13.9486 20.2665 14.0535 20 14.0535Z",fill:"#4285F4"}),e("path",{d:"M20.0133 8.59991C20.573 8.59991 21.0267 8.14622 21.0267 7.58658C21.0267 7.02693 20.573 6.57324 20.0133 6.57324C19.4537 6.57324 19 7.02693 19 7.58658C19 8.14622 19.4537 8.59991 20.0133 8.59991Z",fill:"#4285F4"}),e("path",{d:"M20.0133 19.9334C20.573 19.9334 21.0267 19.4797 21.0267 18.9201C21.0267 18.3604 20.573 17.9067 20.0133 17.9067C19.4537 17.9067 19 18.3604 19 18.9201C19 19.4797 19.4537 19.9334 20.0133 19.9334Z",fill:"#4285F4"}),e("path",{d:"M20.0133 16.9734C20.573 16.9734 21.0267 16.5198 21.0267 15.9601C21.0267 15.4005 20.573 14.9468 20.0133 14.9468C19.4537 14.9468 19 15.4005 19 15.9601C19 16.5198 19.4537 16.9734 20.0133 16.9734Z",fill:"#4285F4"}),e("path",{d:"M11.9867 19.9334C12.5463 19.9334 13 19.4797 13 18.9201C13 18.3604 12.5463 17.9067 11.9867 17.9067C11.427 17.9067 10.9733 18.3604 10.9733 18.9201C10.9733 19.4797 11.427 19.9334 11.9867 19.9334Z",fill:"#AECBFA"}),e("path",{d:"M11.9867 11.5735C12.5463 11.5735 13 11.1199 13 10.5602C13 10.0006 12.5463 9.54688 11.9867 9.54688C11.427 9.54688 10.9733 10.0006 10.9733 10.5602C10.9733 11.1199 11.427 11.5735 11.9867 11.5735Z",fill:"#AECBFA"}),e("path",{d:"M11.9867 8.59991C12.5463 8.59991 13 8.14622 13 7.58658C13 7.02693 12.5463 6.57324 11.9867 6.57324C11.427 6.57324 10.9733 7.02693 10.9733 7.58658C10.9733 8.14622 11.427 8.59991 11.9867 8.59991Z",fill:"#AECBFA"}),e("path",{d:"M12 16.9735C11.7381 16.9737 11.4862 16.8724 11.2973 16.6909C11.1083 16.5095 10.997 16.2619 10.9867 16.0001V13.4668C10.9867 13.2016 11.0921 12.9472 11.2796 12.7597C11.4671 12.5722 11.7215 12.4668 11.9867 12.4668C12.2519 12.4668 12.5063 12.5722 12.6938 12.7597C12.8813 12.9472 12.9867 13.2016 12.9867 13.4668V16.0001C12.9798 16.2584 12.8733 16.504 12.6893 16.6854C12.5054 16.8669 12.2584 16.9701 12 16.9735Z",fill:"#AECBFA"})]}),d8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("g",{clipPath:"url(#clip0_1148_5989)",children:e("path",{d:"M1.96742 0.421623C1.1852 0.496042 0.711124 0.64488 0.616309 0.868135C0.379272 1.5379 0.189642 30.6108 0.42668 30.9829C0.592605 31.2309 1.75409 31.3798 4.64594 31.5286C9.88446 31.8511 30.9571 31.7022 31.2652 31.3798C31.4074 31.2309 31.5259 25.7239 31.5733 16.1736C31.6445 2.15806 31.6208 1.19061 31.2415 0.892941C31.0045 0.719297 29.9852 0.496042 28.9896 0.421623C27.1171 0.24798 4.21927 0.272786 1.96742 0.421623ZM15.7867 2.10844C15.8815 2.3317 15.8578 3.10069 15.763 3.84488C15.6208 5.18441 15.5971 5.20922 14.8385 5.20922C11.6148 5.20922 11.5674 11.386 14.7911 11.4852C15.2652 11.51 15.6445 11.6092 15.6445 11.7332C15.6445 11.8325 15.5259 12.7255 15.36 13.6929L15.0993 15.4294L14.0089 15.2805C10.8326 14.8092 10.2874 14.8092 9.86075 15.2557C9.60001 15.5286 9.5052 15.9007 9.57631 16.2232C10.1452 18.2573 9.83705 18.8526 8.29631 18.8526C6.58964 18.8526 6.3052 18.4061 6.92149 16.6201C7.15853 15.8759 7.13483 15.7519 6.63705 15.3301C6.21038 14.9581 5.6889 14.8836 3.84001 14.8836H1.58816L1.73038 12.8247C1.8252 11.7084 1.89631 8.80612 1.89631 6.39992V2.00922L2.56001 1.91C2.91557 1.86038 5.99705 1.78596 9.43409 1.76116C14.7911 1.73635 15.6682 1.78596 15.7867 2.10844ZM30.0326 2.05883C30.1985 2.23248 30.1985 15.3798 30.0326 15.5286C30.0089 15.5534 29.1556 15.6278 28.1363 15.6774L26.2874 15.8015L26.4296 15.2061C26.643 14.2387 26.1215 12.9488 25.363 12.527C24.4859 12.0557 22.5185 12.0557 21.4519 12.5022C20.4326 12.9488 20.0771 13.6681 20.1956 15.0325L20.2667 16.0991L19.2 15.9751C16.6163 15.6774 16.5452 15.6526 16.6874 15.0325C16.7585 14.71 16.9482 13.5937 17.0904 12.5519C17.3274 10.865 17.3274 10.5922 16.9719 10.1953C16.6637 9.82317 16.3556 9.74875 15.6208 9.84798C14.4593 10.0216 13.9852 9.62472 13.9852 8.50844C13.9852 7.04488 14.3171 6.67279 15.5971 6.7472C16.5452 6.82162 16.7111 6.7472 16.9956 6.20147C17.1615 5.85418 17.3037 4.7379 17.3037 3.64643V1.68674L23.5615 1.78596C26.9985 1.81077 29.9141 1.95961 30.0326 2.05883ZM24.4385 13.9162C24.8415 14.1395 24.8889 14.3875 24.8415 15.7022L24.7704 17.2402L27.4963 17.1906L30.2222 17.1658L30.1985 18.679C30.1748 19.5224 30.1511 22.4743 30.1274 25.2278L30.1037 30.2635H23.2296H16.3556V28.527V26.8154L17.5408 26.9643C18.6548 27.0883 18.7496 27.0635 19.5793 26.1953C20.4326 25.3022 20.4326 25.2774 20.3378 23.541C20.2667 21.9534 20.1719 21.7053 19.5556 21.1596C18.963 20.6139 18.7022 20.5395 17.4696 20.6387L16.0711 20.7379L16.2133 20.0185C16.2845 19.6216 16.3556 18.8278 16.3556 18.2325V17.1906L17.4933 17.3891C18.1096 17.4883 19.2711 17.5875 20.0533 17.5875C21.9259 17.6123 22.2104 17.3146 21.8311 15.7519C21.6889 15.1069 21.6178 14.4867 21.7126 14.3627C22.0919 13.7177 23.6563 13.4697 24.4385 13.9162ZM5.09631 17.6371C5.12001 19.1751 5.6889 19.9937 6.92149 20.341C8.34372 20.7627 9.88446 20.4402 10.7141 19.5968C11.2593 19.0263 11.3778 18.679 11.3778 17.7115V16.5457L12.4682 16.7193C13.0845 16.7937 13.8193 16.8681 14.1274 16.8681C14.6963 16.8681 14.6963 16.9177 14.6963 19.3488C14.6963 21.4573 14.7674 21.9038 15.1467 22.3007C15.5971 22.772 15.6682 22.772 16.7822 22.3999C17.4222 22.1767 18.1096 22.0774 18.323 22.1519C18.7971 22.3255 19.0341 23.8387 18.7259 24.6821C18.4889 25.3022 18.3941 25.3519 17.4696 25.2278C16.9245 25.1782 16.3082 25.0294 16.1185 24.955C15.9052 24.8557 15.5496 24.955 15.2889 25.1534C14.8859 25.4511 14.7911 25.8728 14.7437 27.8821L14.6489 30.2635H11.7571C10.1452 30.2635 7.22964 30.1891 5.26224 30.0898L1.65927 29.941V23.1441V16.3472L3.38964 16.4216L5.09631 16.496V17.6371Z",fill:"#EF4036"})}),e("defs",{children:e("clipPath",{id:"clip0_1148_5989",children:e("rect",{width:"32",height:"32",fill:"transparent"})})})]}),u8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M18.2835 6L26.4963 26.5994H31L22.7873 6H18.2835Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M8.75587 18.4479L11.566 11.2087L14.3762 18.4479H8.75587ZM9.21147 6L1 26.5994H5.59136L7.27074 22.2735H15.8616L17.5407 26.5994H22.132L13.9206 6H9.21147Z",fill:"var(--ac-global-text-color-900)"})]}),m8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("path",{d:"M18.9623 11.0195C16.8877 11.0195 15.208 12.6992 15.208 14.7739C15.208 16.8485 16.8877 18.5282 18.9623 18.5282C21.037 18.5282 22.7167 16.8485 22.7167 14.7739C22.7167 12.6992 21.0332 11.0195 18.9623 11.0195ZM18.9623 17.1208C17.6662 17.1208 16.6154 16.07 16.6154 14.7739C16.6154 13.4777 17.6662 12.4269 18.9623 12.4269C20.2585 12.4269 21.3093 13.4777 21.3093 14.7739C21.3093 16.07 20.2585 17.1208 18.9623 17.1208Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M13.7781 11.0308C13.6515 11.0155 13.5212 11.0078 13.3908 11.0078C13.3256 11.0078 13.2642 11.0078 13.2029 11.0078C13.1415 11.0078 13.0763 11.0155 13.015 11.0193C12.7619 11.0385 12.5126 11.0807 12.2672 11.1459C11.7648 11.2801 11.2969 11.514 10.8904 11.84C10.4763 12.1736 10.1426 12.5954 9.91639 13.0786C9.80518 13.3202 9.72081 13.5733 9.67096 13.8341C9.64411 13.9607 9.62494 14.091 9.61343 14.2214C9.6096 14.2866 9.60193 14.348 9.60193 14.417V14.5129V14.6011V15.8589L9.6096 17.1167L9.61727 18.3746H11.0247L11.0323 17.1167V15.8589L11.04 14.6011V14.4707C11.04 14.4323 11.0477 14.3902 11.0515 14.3518C11.0592 14.2751 11.0707 14.1946 11.086 14.1179C11.1167 13.9683 11.1666 13.8188 11.2317 13.6807C11.3621 13.4008 11.5539 13.1553 11.7955 12.9598C12.0486 12.7603 12.3362 12.6108 12.6468 12.5264C12.8079 12.4842 12.9689 12.4536 13.1377 12.4382C13.1798 12.4382 13.222 12.4305 13.2642 12.4305C13.3064 12.4305 13.3486 12.4305 13.3908 12.4305C13.4713 12.4305 13.5518 12.4344 13.6324 12.442C13.9545 12.4727 14.2651 12.5724 14.5451 12.7297L15.2468 11.5102C14.7982 11.2494 14.2996 11.0845 13.7858 11.027L13.7781 11.0308Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M4.789 11.0002C2.71434 10.981 1.01934 12.6453 1.00016 14.72C0.98099 16.7946 2.64532 18.4896 4.71997 18.5088H6.02383V17.1014H4.789C3.49282 17.1168 2.43057 16.0775 2.41523 14.7813C2.39989 13.4852 3.43913 12.4229 4.73531 12.4076H4.789C6.08518 12.4076 7.13593 13.4583 7.13977 14.7545V18.2135C7.13977 19.4982 6.09285 20.5451 4.81201 20.5605C4.19843 20.5566 3.6117 20.3074 3.17836 19.874L2.1813 20.8711C2.87157 21.5652 3.80728 21.9602 4.78517 21.9717H4.83502C6.88283 21.941 8.52799 20.2805 8.53949 18.2327V14.6663C8.48964 12.6261 6.82531 11.0002 4.789 11.0002Z",fill:"var(--ac-global-text-color-900)"}),e("path",{d:"M27.2533 11.0195C25.1787 11.0195 23.499 12.6992 23.499 14.7739C23.499 16.8485 25.1787 18.5282 27.2533 18.5282H28.538V17.1208H27.2533C25.9572 17.1208 24.9064 16.07 24.9064 14.7739C24.9064 13.4777 25.9572 12.4269 27.2533 12.4269C28.469 12.4269 29.4852 13.3588 29.5926 14.5706V21.7801H31V14.7739C30.9962 12.703 29.3242 11.0195 27.2533 11.0195Z",fill:"var(--ac-global-text-color-900)"})]}),g8=()=>e("svg",{version:"1.1",id:"Layer_1",xmlns:"http://www.w3.org/2000/svg",x:"0px",y:"0px",width:"32",height:"32",viewBox:"0 0 400 400",enableBackground:"new 0 0 400 400",xmlSpace:"preserve",children:e("path",{fill:"var(--ac-global-text-color-900)",stroke:"none",d:`
M108.357758,374.748016
	C68.931068,356.066071 45.775341,325.019348 36.873970,283.154297
	C30.389435,252.656082 33.336266,222.467133 42.685719,193.016541
	C58.768898,142.354813 85.827126,98.280418 124.748680,61.938580
	C145.764755,42.315449 169.544373,26.902735 197.551865,18.696321
	C233.877899,8.052515 266.357330,15.785578 295.642151,38.813885
	C311.787628,51.509991 325.734741,66.145889 333.571045,85.621201
	C340.671906,103.268669 340.516388,121.362411 336.592682,139.643417
	C333.681305,153.207916 328.341309,165.942825 322.998566,178.398621
	C323.824585,180.318497 325.412994,180.144730 326.588379,180.303497
	C348.189026,183.221146 362.405640,201.825790 365.324188,224.059479
	C369.047516,252.424057 359.334717,276.863831 342.760071,298.986633
	C309.078064,343.943359 264.191742,371.643372 209.528900,383.468353
	C175.162979,390.902557 141.349426,389.043335 108.357758,374.748016
M271.080261,209.564880
	C276.822632,194.262497 283.971436,179.601944 291.199829,164.964279
	C296.215637,154.807129 300.561798,144.335480 303.180573,133.260727
	C307.179047,116.351280 306.355347,100.337906 294.874695,86.023811
	C283.959991,72.415321 271.036224,61.444416 255.257523,53.889622
	C243.448471,48.235489 231.098053,46.722847 218.275681,48.963493
	C190.663696,53.788551 168.189636,68.463501 148.031158,86.866074
	C121.336411,111.235603 101.638069,140.797668 86.485901,173.465500
	C72.204773,204.255356 64.520126,236.334229 69.392883,270.412170
	C73.207108,297.087158 84.966972,319.501312 107.685608,335.065063
	C135.185516,353.904266 165.862350,356.662231 197.639496,351.232513
	C226.848587,346.241608 253.160049,333.984497 277.058044,316.581299
	C297.531555,301.671906 314.873077,283.874969 325.936218,260.777405
	C331.523773,249.111649 333.769897,236.736618 330.307495,223.889450
	C329.156708,219.619415 327.376648,215.425262 322.397522,214.499054
	C317.326202,213.555649 314.021484,216.935379 310.871582,220.215073
	C310.074585,221.044922 309.510468,222.103455 308.867737,223.075668
	C300.009247,236.475174 289.673126,248.552429 277.708557,259.333801
	C249.653473,284.614502 216.635345,296.440063 179.132095,296.318329
	C161.393463,296.260742 149.833130,287.682251 145.810806,270.539856
	C140.823715,249.285797 142.451172,227.976303 150.218277,207.764145
	C164.287735,171.151611 185.422729,138.726166 211.975861,109.887596
	C218.737091,102.544426 225.840866,95.432785 234.904358,90.815033
	C237.647705,89.417328 240.608063,87.398354 243.710663,89.989059
	C247.025345,92.756889 246.760300,96.405632 245.685867,100.093086
	C244.092072,105.562981 241.271606,110.502014 238.899857,115.639061
	C231.912460,130.773315 225.552048,146.141083 222.041946,162.530533
	C217.079269,185.702393 230.538971,209.662094 252.994049,217.609100
	C261.908478,220.763977 266.484222,218.869110 271.080261,209.564880
z`})}),p8=()=>e("svg",{fill:"var(--ac-global-text-color-900)",width:"32",height:"32",viewBox:"0 0 32 32",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M 15.994141 3 C 15.629141 3 15.264219 3.0895313 14.949219 3.2695312 L 5.0390625 8.9902344 C 4.3990625 9.3602344 4 10.060781 4 10.800781 L 4 21.179688 C 4 21.929688 4.3990625 22.620234 5.0390625 22.990234 L 7.640625 24.490234 C 8.900625 25.110234 9.3499219 25.109375 9.9199219 25.109375 C 11.789922 25.109375 12.859375 23.979531 12.859375 22.019531 L 12.859375 11.310547 C 12.859375 11.150547 12.730312 11.019531 12.570312 11.019531 L 11.320312 11.019531 C 11.150313 11.019531 11.029297 11.150547 11.029297 11.310547 L 11.029297 22.009766 C 11.029297 22.889766 10.120391 23.749531 8.6503906 23.019531 L 5.9296875 21.449219 C 5.8296875 21.399219 5.7695313 21.289687 5.7695312 21.179688 L 5.7695312 10.810547 C 5.7695312 10.690547 5.8296875 10.589297 5.9296875 10.529297 L 15.839844 4.8105469 C 15.929844 4.7505469 16.050391 4.7505469 16.150391 4.8105469 L 26.060547 10.529297 C 26.160547 10.589297 26.220703 10.690781 26.220703 10.800781 L 26.220703 21.179688 C 26.220703 21.289687 26.160313 21.399219 26.070312 21.449219 L 16.150391 27.179688 C 16.060391 27.229688 15.929844 27.229688 15.839844 27.179688 L 13.289062 25.669922 C 13.219062 25.619922 13.120781 25.610391 13.050781 25.650391 C 12.340781 26.050391 12.210781 26.100078 11.550781 26.330078 C 11.390781 26.380078 11.140625 26.479766 11.640625 26.759766 L 14.949219 28.720703 C 15.269219 28.900703 15.630234 29 15.990234 29 C 16.360234 29 16.719062 28.900703 17.039062 28.720703 L 26.960938 22.990234 C 27.600938 22.620234 28 21.929688 28 21.179688 L 28 10.810547 C 28 10.060547 27.600938 9.37 26.960938 9 L 17.039062 3.2695312 C 16.724063 3.0895313 16.359141 3 15.994141 3 z M 18.660156 11.005859 C 15.830156 11.005859 14.140625 12.205078 14.140625 14.205078 C 14.140625 16.375078 15.819062 16.974141 18.539062 17.244141 C 21.789062 17.564141 22.039062 18.045547 22.039062 18.685547 C 22.039062 19.785547 21.150547 20.255859 19.060547 20.255859 C 16.430547 20.255859 15.850156 19.594922 15.660156 18.294922 C 15.640156 18.154922 15.520859 18.054688 15.380859 18.054688 L 14.089844 18.054688 C 13.929844 18.054688 13.810547 18.185938 13.810547 18.335938 C 13.810547 20.005937 14.720547 21.994141 19.060547 21.994141 C 22.200547 21.994141 24 20.755703 24 18.595703 C 24 16.455703 22.549766 15.884609 19.509766 15.474609 C 16.419766 15.074609 16.109375 14.864531 16.109375 14.144531 C 16.109375 13.544531 16.380156 12.755859 18.660156 12.755859 C 20.690156 12.755859 21.449766 13.194453 21.759766 14.564453 C 21.789766 14.694453 21.899062 14.794922 22.039062 14.794922 L 23.330078 14.794922 C 23.410078 14.794922 23.479063 14.755313 23.539062 14.695312 C 23.589062 14.645313 23.619375 14.564609 23.609375 14.474609 C 23.409375 12.114609 21.840156 11.005859 18.660156 11.005859 z"})}),K1=()=>e("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{d:"M15.357 4L26.714 27H4L15.357 4Z",fill:"var(--ac-global-text-color-900)"})}),h8=()=>e("svg",{width:"32",height:"32",viewBox:"0 0 40 40",version:"1.1",xmlns:"http://www.w3.org/2000/svg",children:s("g",{stroke:"none",strokeWidth:"1",fill:"none",fillRule:"evenodd",children:[e("g",{id:"Icon-Architecture-BG/32/Machine-Learning",fill:"#01A88D",children:e("rect",{id:"Rectangle",x:"0",y:"0",width:"40",height:"40"})}),e("g",{id:"Icon-Service/32/Amazon-Bedrock_32",transform:"translate(6.000000, 6.000000)",fill:"#FFFFFF",children:e("path",{d:"M10.516,26.9332116 L8.293,25.6632116 L11.724,23.9472116 L11.277,23.0532116 L7.277,25.0532116 L7.297,25.0942116 L4,23.2102116 L4,19.8092116 L7.724,17.9472116 L7.277,17.0532116 L3.536,18.9232116 L1,17.2322116 L1,14.8092116 L4.724,12.9472116 L4.277,12.0532116 L1,13.6912116 L1,10.7672116 L3.523,9.08621158 L7,11.0382116 L7,14.1912116 L5.277,15.0532116 L5.724,15.9472116 L7.5,15.0592116 L9.277,15.9472116 L9.724,15.0532116 L8,14.1912116 L8,10.7672116 L10.778,8.91621158 C10.916,8.82321158 11,8.66721158 11,8.50021158 L11,5.00021158 L10,5.00021158 L10,8.23221158 L7.278,10.0472116 L4,8.20721158 L4,4.03521158 L7,2.65721158 L7,7.00021158 L8,7.00021158 L8,2.19821158 L10.492,1.05421158 L14,2.80921158 L14,17.1912116 L6.277,21.0532116 L6.724,21.9472116 L14,18.3092116 L14,25.1912116 L10.516,26.9332116 Z M25.5,19.5002116 C25.5,20.0512116 25.052,20.5002116 24.5,20.5002116 C23.949,20.5002116 23.5,20.0512116 23.5,19.5002116 C23.5,18.9492116 23.949,18.5002116 24.5,18.5002116 C25.052,18.5002116 25.5,18.9492116 25.5,19.5002116 L25.5,19.5002116 Z M20.5,24.0002116 C20.5,24.5512116 20.052,25.0002116 19.5,25.0002116 C18.949,25.0002116 18.5,24.5512116 18.5,24.0002116 C18.5,23.4492116 18.949,23.0002116 19.5,23.0002116 C20.052,23.0002116 20.5,23.4492116 20.5,24.0002116 L20.5,24.0002116 Z M19.5,4.00021158 C19.5,3.44921158 19.949,3.00021158 20.5,3.00021158 C21.052,3.00021158 21.5,3.44921158 21.5,4.00021158 C21.5,4.55121158 21.052,5.00021158 20.5,5.00021158 C19.949,5.00021158 19.5,4.55121158 19.5,4.00021158 L19.5,4.00021158 Z M26,11.5002116 C26.552,11.5002116 27,11.9492116 27,12.5002116 C27,13.0512116 26.552,13.5002116 26,13.5002116 C25.449,13.5002116 25,13.0512116 25,12.5002116 C25,11.9492116 25.449,11.5002116 26,11.5002116 L26,11.5002116 Z M24.071,13.0002116 C24.295,13.8602116 25.071,14.5002116 26,14.5002116 C27.103,14.5002116 28,13.6032116 28,12.5002116 C28,11.3972116 27.103,10.5002116 26,10.5002116 C25.071,10.5002116 24.295,11.1402116 24.071,12.0002116 L15,12.0002116 L15,9.00021158 L20.5,9.00021158 C20.777,9.00021158 21,8.77621158 21,8.50021158 L21,5.92921158 C21.86,5.70521158 22.5,4.92921158 22.5,4.00021158 C22.5,2.89721158 21.603,2.00021158 20.5,2.00021158 C19.398,2.00021158 18.5,2.89721158 18.5,4.00021158 C18.5,4.92921158 19.14,5.70521158 20,5.92921158 L20,8.00021158 L15,8.00021158 L15,2.50021158 C15,2.31021158 14.893,2.13821158 14.724,2.05321158 L10.724,0.0532115843 C10.588,-0.0147884157 10.43,-0.0177884157 10.291,0.0452115843 L3.291,3.26021158 C3.115,3.34121158 3,3.51921158 3,3.71421158 L3,8.23221158 L0.223,10.0842116 C0.084,10.1772116 0,10.3332116 0,10.5002116 L0,17.5002116 C0,17.6672116 0.084,17.8232116 0.223,17.9162116 L3,19.7672116 L3,23.5002116 C3,23.6792116 3.096,23.8452116 3.252,23.9342116 L10.252,27.9342116 C10.329,27.9782116 10.414,28.0002116 10.5,28.0002116 C10.577,28.0002116 10.654,27.9822116 10.724,27.9472116 L14.724,25.9472116 C14.893,25.8622116 15,25.6892116 15,25.5002116 L15,21.0002116 L19,21.0002116 L19,22.0712116 C18.14,22.2952116 17.5,23.0712116 17.5,24.0002116 C17.5,25.1032116 18.398,26.0002116 19.5,26.0002116 C20.603,26.0002116 21.5,25.1032116 21.5,24.0002116 C21.5,23.0712116 20.86,22.2952116 20,22.0712116 L20,20.5002116 C20,20.2242116 19.777,20.0002116 19.5,20.0002116 L15,20.0002116 L15,17.0002116 L21.293,17.0002116 L22.784,18.4902116 C22.608,18.7882116 22.5,19.1302116 22.5,19.5002116 C22.5,20.6032116 23.398,21.5002116 24.5,21.5002116 C25.603,21.5002116 26.5,20.6032116 26.5,19.5002116 C26.5,18.3972116 25.603,17.5002116 24.5,17.5002116 C24.131,17.5002116 23.788,17.6082116 23.491,17.7832116 L21.854,16.1462116 C21.76,16.0532116 21.633,16.0002116 21.5,16.0002116 L15,16.0002116 L15,13.0002116 L24.071,13.0002116 Z",id:"Fill-5"})})]})}),f8=()=>s("svg",{width:"32",height:"32",style:{flex:"none",lineHeight:"1"},viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"HuggingFace"}),s("g",{fill:"none",fillRule:"nonzero",children:[e("path",{d:"M2.25 11.535c0-3.407 1.847-6.554 4.844-8.258a9.822 9.822 0 019.687 0c2.997 1.704 4.844 4.851 4.844 8.258 0 5.266-4.337 9.535-9.687 9.535S2.25 16.8 2.25 11.535z",fill:"#FF9D0B"}),e("path",{d:"M11.938 20.086c4.797 0 8.687-3.829 8.687-8.551 0-4.722-3.89-8.55-8.687-8.55-4.798 0-8.688 3.828-8.688 8.55 0 4.722 3.89 8.55 8.688 8.55z",fill:"#FFD21E"}),e("path",{d:"M11.875 15.113c2.457 0 3.25-2.156 3.25-3.263 0-.576-.393-.394-1.023-.089-.582.283-1.365.675-2.224.675-1.798 0-3.25-1.693-3.25-.586 0 1.107.79 3.263 3.25 3.263h-.003z",fill:"#FF323D"}),e("path",{d:"M14.76 9.21c.32.108.445.753.767.585.447-.233.707-.708.659-1.204a1.235 1.235 0 00-.879-1.059 1.262 1.262 0 00-1.33.394c-.322.384-.377.92-.14 1.36.153.283.638-.177.925-.079l-.002.003zm-5.887 0c-.32.108-.448.753-.768.585a1.226 1.226 0 01-.658-1.204c.048-.495.395-.913.878-1.059a1.262 1.262 0 011.33.394c.322.384.377.92.14 1.36-.152.283-.64-.177-.925-.079l.003.003zm1.12 5.34a2.166 2.166 0 011.325-1.106c.07-.02.144.06.219.171l.192.306c.069.1.139.175.209.175.074 0 .15-.074.223-.172l.205-.302c.08-.11.157-.188.234-.165.537.168.986.536 1.25 1.026.932-.724 1.275-1.905 1.275-2.633 0-.508-.306-.426-.81-.19l-.616.296c-.52.24-1.148.48-1.824.48-.676 0-1.302-.24-1.823-.48l-.589-.283c-.52-.248-.838-.342-.838.177 0 .703.32 1.831 1.187 2.56l.18.14z",fill:"#3A3B45"}),e("path",{d:"M17.812 10.366a.806.806 0 00.813-.8c0-.441-.364-.8-.813-.8a.806.806 0 00-.812.8c0 .442.364.8.812.8zm-11.624 0a.806.806 0 00.812-.8c0-.441-.364-.8-.812-.8a.806.806 0 00-.813.8c0 .442.364.8.813.8zM4.515 13.073c-.405 0-.765.162-1.017.46a1.455 1.455 0 00-.333.925 1.801 1.801 0 00-.485-.074c-.387 0-.737.146-.985.409a1.41 1.41 0 00-.2 1.722 1.302 1.302 0 00-.447.694c-.06.222-.12.69.2 1.166a1.267 1.267 0 00-.093 1.236c.238.533.81.958 1.89 1.405l.24.096c.768.3 1.473.492 1.478.494.89.243 1.808.375 2.732.394 1.465 0 2.513-.443 3.115-1.314.93-1.342.842-2.575-.274-3.763l-.151-.154c-.692-.684-1.155-1.69-1.25-1.912-.195-.655-.71-1.383-1.562-1.383-.46.007-.889.233-1.15.605-.25-.31-.495-.553-.715-.694a1.87 1.87 0 00-.993-.312zm14.97 0c.405 0 .767.162 1.017.46.216.262.333.588.333.925.158-.047.322-.071.487-.074.388 0 .738.146.985.409a1.41 1.41 0 01.2 1.722c.22.178.377.422.445.694.06.222.12.69-.2 1.166.244.37.279.836.093 1.236-.238.533-.81.958-1.889 1.405l-.239.096c-.77.3-1.475.492-1.48.494-.89.243-1.808.375-2.732.394-1.465 0-2.513-.443-3.115-1.314-.93-1.342-.842-2.575.274-3.763l.151-.154c.695-.684 1.157-1.69 1.252-1.912.195-.655.708-1.383 1.56-1.383.46.007.889.233 1.15.605.25-.31.495-.553.718-.694.244-.162.523-.265.814-.3l.176-.012z",fill:"#FF9D0B"}),e("path",{d:"M9.785 20.132c.688-.994.638-1.74-.305-2.667-.945-.928-1.495-2.288-1.495-2.288s-.205-.788-.672-.714c-.468.074-.81 1.25.17 1.971.977.721-.195 1.21-.573.534-.375-.677-1.405-2.416-1.94-2.751-.532-.332-.907-.148-.782.541.125.687 2.357 2.35 2.14 2.707-.218.362-.983-.42-.983-.42S2.953 14.9 2.43 15.46c-.52.558.398 1.026 1.7 1.803 1.308.778 1.41.985 1.225 1.28-.187.295-3.07-2.1-3.34-1.083-.27 1.011 2.943 1.304 2.745 2.006-.2.7-2.265-1.324-2.685-.537-.425.79 2.913 1.718 2.94 1.725 1.075.276 3.813.859 4.77-.522zm4.432 0c-.687-.994-.64-1.74.305-2.667.943-.928 1.493-2.288 1.493-2.288s.205-.788.675-.714c.465.074.807 1.25-.17 1.971-.98.721.195 1.21.57.534.377-.677 1.407-2.416 1.94-2.751.532-.332.91-.148.782.541-.125.687-2.355 2.35-2.137 2.707.215.362.98-.42.98-.42S21.05 14.9 21.57 15.46c.52.558-.395 1.026-1.7 1.803-1.308.778-1.408.985-1.225 1.28.187.295 3.07-2.1 3.34-1.083.27 1.011-2.94 1.304-2.743 2.006.2.7 2.263-1.324 2.685-.537.423.79-2.912 1.718-2.94 1.725-1.077.276-3.815.859-4.77-.522z",fill:"#FFD21E"})]})]}),b8=()=>e("svg",{width:"32",height:"32",viewBox:"0 0 27.82 27.83",fill:"var(--ac-global-text-color-900)",xmlns:"http://www.w3.org/2000/svg",children:e("g",{id:"icons",children:s("g",{children:[e("path",{d:"m16.02,27.83h0c-1.48,0-2.97-.57-4.1-1.7-2.26-2.26-2.26-5.94,0-8.2l9.9-9.9v14c0,1.6-.65,3.05-1.7,4.1h0c-.56.56-1.2.98-1.88,1.26-.68.28-1.43.44-2.22.44Z"}),e("path",{d:"m5.8,17.61c-1.48,0-2.97-.57-4.1-1.7C.57,14.78,0,13.3,0,11.82h0c0-.76.15-1.49.42-2.16.28-.71.71-1.37,1.28-1.94h0c1.05-1.05,2.5-1.7,4.1-1.7h14s-9.9,9.89-9.9,9.89c-1.13,1.13-2.61,1.7-4.1,1.7Z"}),e("path",{d:"m24.41,8.44c-.78-.78-.78-2.05,0-2.83s2.05-.78,2.83,0,.78,2.05,0,2.83-2.05.78-2.83,0Z"}),e("path",{d:"m19.39,3.42c-.78-.78-.78-2.05,0-2.83s2.05-.78,2.83,0,.78,2.05,0,2.83-2.05.78-2.83,0Z"})]})})}),Si=()=>e("svg",{width:"32",height:"32",viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M19.2593 6.61905C19.0126 7.16696 18.7815 8.04669 18.5292 9.00706C18.4235 9.40941 18.3141 9.82591 18.1982 10.2381H23.1482C23.7004 10.2381 24.1482 10.6858 24.1482 11.2381V17.0307C24.5195 16.902 24.8948 16.7804 25.2572 16.663C26.122 16.383 26.9141 16.1264 27.4074 15.8525C29.0175 14.9587 30.6667 17.4728 30.6667 19.4716C30.6667 21.4703 29.0371 23.9954 27.4074 23.0906C26.914 22.8166 26.1217 22.56 25.2569 22.2799L25.2568 22.2799C24.8945 22.1625 24.5194 22.041 24.1482 21.9124V27.3333C24.1482 27.8856 23.7004 28.3333 23.1482 28.3333H8.85186C8.29957 28.3333 7.85186 27.8856 7.85186 27.3333V21.9159C7.48052 22.0446 7.10529 22.1662 6.74283 22.2836C5.8781 22.5636 5.086 22.8202 4.59263 23.0941C2.98259 23.9879 1.33337 21.4738 1.33337 19.475C1.33337 17.4763 2.963 14.9511 4.59263 15.856C5.08608 16.13 5.87835 16.3866 6.74324 16.6667C7.10558 16.7841 7.48066 16.9056 7.85186 17.0342V11.2381C7.85186 10.6858 8.29957 10.2381 8.85186 10.2381H13.8018C13.686 9.82578 13.5765 9.40914 13.4708 9.00667L13.4708 9.00661L13.4708 9.00659L13.4707 9.00657L13.4707 9.00656C13.2185 8.04639 12.9875 7.16687 12.7408 6.61905C11.9359 4.83128 14.2 3 16.0001 3C17.8001 3 20.0742 4.80952 19.2593 6.61905ZM12.2564 21.0247C11.9603 21.3049 11.5203 21.259 11.2731 20.9233C11.0258 20.5877 11.0663 20.0881 11.3625 19.8087L15.5529 15.8503C15.5746 15.8294 15.5991 15.8157 15.6237 15.8019C15.6363 15.7949 15.6489 15.7879 15.6611 15.7799C15.6701 15.7739 15.6788 15.7676 15.6874 15.7614C15.7062 15.7477 15.7248 15.7342 15.7464 15.7245C15.8281 15.688 15.9133 15.6667 15.9999 15.6667C16.0865 15.6667 16.1717 15.688 16.2534 15.7245C16.275 15.7342 16.2936 15.7478 16.3124 15.7614C16.321 15.7676 16.3296 15.7739 16.3386 15.7799C16.3509 15.7879 16.3635 15.7949 16.376 15.8019C16.4006 15.8157 16.4251 15.8294 16.4469 15.8503L20.6373 19.8087C20.9341 20.0881 20.9739 20.5877 20.7267 20.9233C20.4801 21.259 20.0402 21.3049 19.7433 21.0247L16.6983 18.1485V28.3333H15.9999H15.1852L15.3015 18.1485L12.2564 21.0247Z",fill:"var(--ac-global-text-color-900)"})}),y8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("g",{clipPath:"url(#clip0_2815_4632)",children:e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.7469 1.84196C16.0957 2.52647 16.0957 3.42256 16.0957 5.21473V10.9752C16.0957 12.7674 16.0957 13.6634 15.7469 14.348C15.4401 14.9501 14.9506 15.4396 14.3485 15.7464C13.6639 16.0952 12.7679 16.0952 10.9757 16.0952H5.21522C3.42305 16.0952 2.52696 16.0952 1.84245 15.7464C1.24033 15.4396 0.750789 14.9501 0.443994 14.348C0.0952148 13.6634 0.0952148 12.7674 0.0952148 10.9752V5.21473C0.0952148 3.42256 0.0952148 2.52647 0.443994 1.84196C0.750789 1.23984 1.24033 0.7503 1.84245 0.443506C2.52696 0.0947266 3.42305 0.0947266 5.21521 0.0947266H10.9757C12.7678 0.0947266 13.6639 0.0947266 14.3485 0.443506C14.9506 0.7503 15.4401 1.23984 15.7469 1.84196ZM5.27398 3.77524H9.3046L12.594 12.0905H10.9168L8.32056 5.18973H5.27398V3.77524ZM2.99402 10.676H7.12113V12.0905H2.99402V10.676Z",fill:"#FF4017"})}),e("defs",{children:e("clipPath",{id:"clip0_2815_4632",children:e("rect",{width:"16",height:"16",fill:"white"})})})]}),_1=()=>s("svg",{width:"32",height:"32",fill:"currentColor",fillRule:"evenodd",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"ModelContextProtocol"}),e("path",{d:"M15.688 2.343a2.588 2.588 0 00-3.61 0l-9.626 9.44a.863.863 0 01-1.203 0 .823.823 0 010-1.18l9.626-9.44a4.313 4.313 0 016.016 0 4.116 4.116 0 011.204 3.54 4.3 4.3 0 013.609 1.18l.05.05a4.115 4.115 0 010 5.9l-8.706 8.537a.274.274 0 000 .393l1.788 1.754a.823.823 0 010 1.18.863.863 0 01-1.203 0l-1.788-1.753a1.92 1.92 0 010-2.754l8.706-8.538a2.47 2.47 0 000-3.54l-.05-.049a2.588 2.588 0 00-3.607-.003l-7.172 7.034-.002.002-.098.097a.863.863 0 01-1.204 0 .823.823 0 010-1.18l7.273-7.133a2.47 2.47 0 00-.003-3.537z"}),e("path",{d:"M14.485 4.703a.823.823 0 000-1.18.863.863 0 00-1.204 0l-7.119 6.982a4.115 4.115 0 000 5.9 4.314 4.314 0 006.016 0l7.12-6.982a.823.823 0 000-1.18.863.863 0 00-1.204 0l-7.119 6.982a2.588 2.588 0 01-3.61 0 2.47 2.47 0 010-3.54l7.12-6.982z"})]}),v8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",children:[e("title",{children:"Gemini"}),e("defs",{children:s("linearGradient",{id:"lobe-icons-gemini-fill",x1:"0%",x2:"68.73%",y1:"100%",y2:"30.395%",children:[e("stop",{offset:"0%",stopColor:"#1C7DFF"}),e("stop",{offset:"52.021%",stopColor:"#1C69FF"}),e("stop",{offset:"100%",stopColor:"#F0DCD6"})]})}),e("path",{d:"M12 24A14.304 14.304 0 000 12 14.304 14.304 0 0012 0a14.305 14.305 0 0012 12 14.305 14.305 0 00-12 12",fill:"url(#lobe-icons-gemini-fill)",fillRule:"nonzero"})]}),C8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 115 115",xmlns:"http://www.w3.org/2000/svg","aria-hidden":"true",focusable:"false",children:[e("path",{fill:"#FFBDDB",d:"M62.3737 105.707C59.5781 109.547 53.8509 109.547 51.0553 105.707L27.7796 73.7344C25.0105 69.9307 26.7073 64.5329 31.1546 62.9977L54.4303 54.9628C55.9102 54.4519 57.5187 54.4519 58.9987 54.9628L82.2744 62.9977C86.7217 64.533 88.4184 69.9307 85.6494 73.7344L62.3737 105.707ZM56.7145 99.8879L78.3862 70.1187L56.7145 62.6375L35.0428 70.1187L56.7145 99.8879Z"}),e("path",{fill:"#FFBDDB",d:"M110.86 62.2624C113.648 66.1079 111.878 71.5547 107.362 73.0268L69.7621 85.2833C65.2889 86.7414 60.6796 83.4597 60.5938 78.7556L60.1447 54.1362C60.1162 52.5708 60.6132 51.0411 61.5564 49.7914L76.3907 30.1379C79.2251 26.3826 84.883 26.4369 87.6448 30.2459L110.86 62.2624ZM103.577 65.8465L81.9617 36.0363L68.1497 54.3355L68.5678 77.2583L103.577 65.8465Z"}),e("path",{fill:"#FFBDDB",d:"M84.5326 2.75877C89.0515 1.29523 93.6849 4.66159 93.6894 9.41158L93.7269 48.9589C93.7314 53.6638 89.1859 57.0333 84.6856 55.6613L61.1323 48.4806C59.6347 48.024 58.3334 47.0786 57.4364 45.7954L43.3288 25.6139C40.6333 21.7577 42.4333 16.3935 46.9092 14.9439L84.5326 2.75877ZM85.6907 10.7928L50.6601 22.1382L63.7955 40.929L85.7256 47.6148L85.6907 10.7928Z"}),e("path",{fill:"#FFBDDB",d:"M28.9346 2.77586C24.4156 1.31232 19.7823 4.67868 19.7778 9.42867L19.7402 48.976C19.7358 53.6809 24.2812 57.0504 28.7816 55.6784L52.3348 48.4977C53.8324 48.0411 55.1337 47.0957 56.0307 45.8125L70.1383 25.6309C72.8339 21.7748 71.0339 16.4106 66.5579 14.961L28.9346 2.77586ZM27.7765 10.8099L62.8071 22.1553L49.6717 40.9461L27.7415 47.6319L27.7765 10.8099Z"}),e("path",{fill:"#FFBDDB",d:"M2.58066 62.2555C-0.20768 66.101 1.56213 71.5479 6.07825 73.02L43.6784 85.2765C48.1516 86.7346 52.7608 83.4529 52.8467 78.7488L53.2958 54.1294C53.3243 52.564 52.8273 51.0342 51.8841 49.7846L37.0498 30.131C34.2154 26.3758 28.5575 26.4301 25.7956 30.239L2.58066 62.2555ZM9.8636 65.8396L31.4788 36.0294L45.2908 54.3286L44.8726 77.2515L9.8636 65.8396Z"}),e("path",{fill:"white",d:"M79.5687 82.0867L85.6488 73.7348C86.1993 72.9787 86.5733 72.1596 86.7842 71.3204L74.626 75.2836L67.1038 85.6164C67.9705 85.6767 68.8689 85.5745 69.7619 85.2835L79.5687 82.0867Z"}),e("path",{fill:"white",d:"M60.167 55.3667L60.3224 63.8836L68.3744 66.6632L68.219 58.1463L60.167 55.3667Z"}),e("path",{fill:"white",d:"M93.7166 38.62L87.6446 30.2459C87.0975 29.4914 86.4368 28.8842 85.7069 28.4248L85.7191 41.2186L93.2279 51.5742C93.5492 50.7726 93.7273 49.8919 93.7264 48.9587L93.7166 38.62Z"}),e("path",{fill:"white",d:"M70.4293 51.3149L62.2812 48.8308L67.413 42.0318L75.5611 44.5159L70.4293 51.3149Z"}),e("path",{fill:"white",d:"M56.7395 44.7982L61.6199 37.8166L56.7395 30.8349L51.859 37.8166L56.7395 44.7982Z"}),e("path",{fill:"white",d:"M44.5547 16.2438C45.2222 15.6823 46.012 15.2344 46.9092 14.9438L56.7071 11.7705L66.5577 14.9608C67.4418 15.2472 68.2215 15.6862 68.8828 16.2363L56.7071 20.1796L44.5547 16.2438Z"}),e("path",{fill:"white",d:"M51.1787 48.8499L46.0469 42.0509L37.8988 44.535L43.0306 51.334L51.1787 48.8499Z"}),e("path",{fill:"white",d:"M20.2233 51.5523L27.7476 41.1752L27.7598 28.4014C27.0194 28.8627 26.3494 29.4754 25.7957 30.239L19.7501 38.5767L19.7402 48.9757C19.7394 49.8938 19.9118 50.7611 20.2233 51.5523Z"}),e("path",{fill:"white",d:"M53.2727 55.3623L45.2207 58.1419L45.0653 66.6588L53.1174 63.8792L53.2727 55.3623Z"}),e("path",{fill:"white",d:"M46.3199 85.6104L38.7916 75.2693L26.6406 71.3084C26.8511 72.1518 27.226 72.9749 27.779 73.7346L33.8488 82.0724L43.6778 85.2763C44.5653 85.5656 45.4581 85.6683 46.3199 85.6104Z"})]}),k8=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[s("g",{clipPath:"url(#clip0_756_3354)",children:[e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.69139 10.1458C8.89799 10.3937 8.8645 10.7622 8.61657 10.9688L7.07351 12.2547L8.61657 13.5406C8.8645 13.7472 8.89799 14.1157 8.69139 14.3636C8.48478 14.6115 8.11631 14.645 7.86838 14.4384L5.82029 12.7317C5.52243 12.4834 5.52242 12.026 5.82029 11.7777L7.86838 10.071C8.11631 9.86438 8.48478 9.89788 8.69139 10.1458Z",fill:"#EA4335"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M11.4459 10.1458C11.2393 10.3937 11.2728 10.7622 11.5207 10.9688L13.0638 12.2547L11.5207 13.5406C11.2728 13.7472 11.2393 14.1157 11.4459 14.3636C11.6525 14.6115 12.021 14.645 12.2689 14.4384L14.317 12.7317C14.6149 12.4834 14.6149 12.026 14.317 11.7777L12.2689 10.071C12.021 9.86438 11.6525 9.89788 11.4459 10.1458Z",fill:"#EA4335"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M5.94165 2.19288C4.44903 2.19288 3.23902 3.40289 3.23902 4.89551C3.23902 6.38813 4.44903 7.59814 5.94165 7.59814H8.60776V8.76685H5.94165C3.80357 8.76685 2.07031 7.03359 2.07031 4.89551C2.07031 2.75743 3.80357 1.02417 5.94165 1.02417H9.73995C10.0627 1.02417 10.3243 1.28579 10.3243 1.60852C10.3243 1.93125 10.0627 2.19288 9.73995 2.19288H5.94165Z",fill:"#4285F4"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10.6895 2.19288C12.1821 2.19288 13.3922 3.40289 13.3922 4.89551C13.3922 6.38813 12.1821 7.59814 10.6895 7.59814H6.89123C6.5685 7.59814 6.30687 7.85977 6.30687 8.1825C6.30687 8.50523 6.5685 8.76685 6.89123 8.76685H10.6895C12.8276 8.76685 14.5609 7.03359 14.5609 4.89551C14.5609 2.75743 12.8276 1.02417 10.6895 1.02417H6.89123C6.5685 1.02417 6.30687 1.28579 6.30687 1.60852C6.30687 1.93125 6.5685 2.19288 6.89123 2.19288H10.6895Z",fill:"#34A853"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.23902 10.739H4.18859C4.51132 10.739 4.77295 10.4774 4.77295 10.1547C4.77295 9.83196 4.51132 9.57033 4.18859 9.57033H3.01989C2.49545 9.57033 2.07031 9.99547 2.07031 10.5199V14.026C2.07031 14.5505 2.49545 14.9756 3.01989 14.9756H4.18859C4.51132 14.9756 4.77295 14.714 4.77295 14.3912C4.77295 14.0685 4.51132 13.8069 4.18859 13.8069H3.23902V10.739Z",fill:"#FBBC04"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10.9452 8.1825C10.9452 7.85977 10.6836 7.59814 10.3608 7.59814H6.89123C6.5685 7.59814 6.30687 7.85977 6.30687 8.1825C6.30687 8.50523 6.5685 8.76685 6.89123 8.76685H10.3608C10.6836 8.76685 10.9452 8.50523 10.9452 8.1825Z",fill:"#4285F4"}),e("path",{d:"M6.74514 4.89551C6.74514 5.25858 6.45081 5.55291 6.08774 5.55291C5.72467 5.55291 5.43034 5.25858 5.43034 4.89551C5.43034 4.53244 5.72467 4.23811 6.08774 4.23811C6.45081 4.23811 6.74514 4.53244 6.74514 4.89551Z",fill:"#4285F4"}),e("path",{d:"M11.2739 4.89551C11.2739 5.25858 10.9795 5.55291 10.6165 5.55291C10.2534 5.55291 9.95908 5.25858 9.95908 4.89551C9.95908 4.53244 10.2534 4.23811 10.6165 4.23811C10.9795 4.23811 11.2739 4.53244 11.2739 4.89551Z",fill:"#4285F4"})]}),e("defs",{children:e("clipPath",{id:"clip0_756_3354",children:e("rect",{width:"12.6294",height:"14",fill:"white",transform:"translate(2 1)"})})})]}),V1=()=>s("svg",{width:"32",height:"32",viewBox:"0 0 34 34",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e("circle",{cx:"16.6532",cy:"16.9999",r:"14.0966",stroke:"currentColor",strokeWidth:"1.16026"}),e("ellipse",{cx:"16.6533",cy:"17",rx:"14.0966",ry:"9.45478",transform:"rotate(45 16.6533 17)",stroke:"currentColor",strokeWidth:"1.16026"}),e("path",{d:"M10.8984 17.0508H22.483",stroke:"currentColor",strokeWidth:"1.16026"}),e("path",{d:"M13.748 19.9932L19.6339 14.1074",stroke:"currentColor",strokeWidth:"1.16026"}),e("path",{d:"M19.6328 19.9932L13.747 14.1074",stroke:"currentColor",strokeWidth:"1.16026"}),e("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M7.00863 10.796C4.56184 12.4371 3.13683 14.6416 3.13683 16.9998C3.13683 19.3579 4.56184 21.5624 7.00863 23.2035C9.45169 24.8421 12.8599 25.8744 16.6533 25.8744C20.4467 25.8744 23.8548 24.8421 26.2979 23.2035C28.7447 21.5624 30.1697 19.3579 30.1697 16.9998C30.1697 14.6416 28.7447 12.4371 26.2979 10.796C23.8548 9.15742 20.4467 8.12511 16.6533 8.12511C12.8599 8.12511 9.45169 9.15742 7.00863 10.796ZM6.36234 9.83242C9.02124 8.04906 12.6613 6.96484 16.6533 6.96484C20.6452 6.96484 24.2853 8.04906 26.9442 9.83242C29.5994 11.6133 31.33 14.1362 31.33 16.9998C31.33 19.8633 29.5994 22.3862 26.9442 24.1671C24.2853 25.9505 20.6452 27.0347 16.6533 27.0347C12.6613 27.0347 9.02124 25.9505 6.36234 24.1671C3.70718 22.3862 1.97656 19.8633 1.97656 16.9998C1.97656 14.1362 3.70718 11.6133 6.36234 9.83242Z",fill:"currentColor"})]}),L8=p`
  border-radius: var(--ac-global-rounding-medium);
  border: 1px solid var(--ac-global-color-grey-400);
  padding: var(--ac-global-dimension-size-100)
    var(--ac-global-dimension-size-150);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: var(--ac-global-dimension-size-100);
  transition:
    background-color 0.2s ease-in-out,
    border-color 0.2s ease-in-out;
  &:hover {
    background-color: var(--ac-global-color-grey-100);
    border-color: var(--ac-global-color-primary);
  }
  min-width: 230px;
  .integration__main-link {
    flex: 1 1 auto;
    color: var(--ac-global-text-color-900);
    text-decoration: none;
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: var(--ac-global-dimension-size-150);
  }
  .integration__github-link {
    color: var(--ac-global-color-grey-500);
    transition: color 0.2s ease-in-out;
    display: flex;
    align-items: center;
    &:hover {
      color: var(--ac-global-color-grey-700);
    }
  }
`;function Al({docsHref:n,githubHref:a,icon:t,name:l}){return s("div",{css:L8,children:[s("a",{href:n,className:"integration__main-link",target:"_blank",rel:"noreferrer",children:[t,l]}),e("div",{children:e("a",{href:a,target:"_blank",rel:"noreferrer",className:"integration__github-link","aria-label":"GitHub link",children:e(A8,{})})})]})}const S8=[{name:"OpenAI",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/openai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-openai",icon:e(Nt,{})},{name:"LlamaIndex",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-llama-index",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/llamaindex",icon:e(r8,{})},{name:"LangChain",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/langchain",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-langchain",icon:e(E1,{})},{name:"Haystack",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/haystack",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-haystack",icon:e(o8,{})},{name:"Vertex AI",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/vertex",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-vertexai",icon:e(c8,{})},{name:"Mistral AI",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/mistralai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-mistralai",icon:e(s8,{})},{name:"DSPy",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/dspy",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-dspy",icon:e(d8,{})},{name:"Anthropic",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/anthropic",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-anthropic",icon:e(u8,{})},{name:"Smolagents",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/hfsmolagents",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-smolagents",icon:e(f8,{})},{name:"OpenAI Agents",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/openai-agents-sdk",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-openai-agents",icon:e(Nt,{})},{name:"Agno",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/agno",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-agno",icon:e(y8,{})},{name:"Bedrock",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/bedrock",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-bedrock",icon:e(h8,{})},{name:"Google GenAI",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/google-genai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-google-genai",icon:e(v8,{})},{name:"Google ADK",docsHref:"https://arize.com/docs/phoenix/integrations/llm-providers/google-gen-ai/google-adk-tracing",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-google-adk",icon:e(k8,{})},{name:"Groq",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/groq",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-groq",icon:e(m8,{})},{name:"CrewAI",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/crewai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-crewai",icon:e(g8,{})},{name:"Pydantic AI",docsHref:"https://arize.com/docs/phoenix/integrations/pydantic/pydantic-tracing",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-pydantic-ai",icon:e(C8,{})},{name:"LiteLLM",docsHref:"https://arize.com/docs/phoenix/integrations/llm-providers/litellm",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-litellm",icon:e(Si,{})},{name:"PortKey",docsHref:"https://arize.com/docs/phoenix/integrations/portkey",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-portkey",icon:e(Si,{})},{name:"MCP",docsHref:"https://arize.com/docs/phoenix/integrations/model-context-protocol/mcp-tracing",githubHref:"https://github.com/Arize-ai/openinference/tree/main/python/instrumentation/openinference-instrumentation-mcp",icon:e(_1,{})}],Ml=p`
  width: 100%;
  display: flex;
  flex-direction: row;
  gap: var(--ac-global-dimension-size-100);
  flex-wrap: wrap;
`;function w8(){return e("ul",{css:Ml,children:S8.map(n=>e("li",{children:e(Al,{...n},n.name)},n.name))})}const x8=[{name:"Node",docsHref:"https://opentelemetry.io/docs/languages/js/getting-started/nodejs/",githubHref:"https://github.com/open-telemetry/opentelemetry-js",icon:e(p8,{})},{name:"Vercel",docsHref:"https://vercel.com/docs/observability/otel-overview",githubHref:"https://github.com/vercel/otel",icon:e(K1,{})},{name:"Mastra",docsHref:"https://mastra.ai/docs/observability/ai-tracing/exporters/arize",githubHref:"https://github.com/mastra-ai/mastra/tree/main/observability/arize",icon:e(V1,{})}];function T8(){return e("ul",{css:Ml,children:x8.map(n=>e("li",{children:e(Al,{...n},n.name)},n.name))})}const I8=[{name:"OpenAI NodeJS SDK",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/openai-node-sdk",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-vercel",icon:e(Nt,{})},{name:"LangChain.js",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/langchain.js",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-instrumentation-langchain",icon:e(E1,{})},{name:"Vercel AI SDK",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/vercel-ai-sdk",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-vercel",icon:e(K1,{})},{name:"Mastra",docsHref:"https://arize.com/docs/phoenix/integrations/typescript/mastra/mastra-tracing",githubHref:"https://github.com/mastra-ai/mastra",icon:e(V1,{})},{name:"BeeAI",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/beeai",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-instrumentation-beeai",icon:e(b8,{})},{name:"MCP",docsHref:"https://arize.com/docs/phoenix/tracing/integrations-tracing/model-context-protocol-mcp",githubHref:"https://github.com/Arize-ai/openinference/tree/main/js/packages/openinference-instrumentation-mcp",icon:e(_1,{})}];function z8(){return e("ul",{css:Ml,children:I8.map(n=>e("li",{children:e(Al,{...n},n.name)},n.name))})}const A8=()=>e("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"20",viewBox:"0 0 24 24",children:s("g",{"data-name":"Layer 2",children:[e("rect",{width:"24",height:"24",transform:"rotate(180 12 12)",opacity:"0"}),e("path",{d:"M12 1A10.89 10.89 0 0 0 1 11.77 10.79 10.79 0 0 0 8.52 22c.55.1.75-.23.75-.52v-1.83c-3.06.65-3.71-1.44-3.71-1.44a2.86 2.86 0 0 0-1.22-1.58c-1-.66.08-.65.08-.65a2.31 2.31 0 0 1 1.68 1.11 2.37 2.37 0 0 0 3.2.89 2.33 2.33 0 0 1 .7-1.44c-2.44-.27-5-1.19-5-5.32a4.15 4.15 0 0 1 1.11-2.91 3.78 3.78 0 0 1 .11-2.84s.93-.29 3 1.1a10.68 10.68 0 0 1 5.5 0c2.1-1.39 3-1.1 3-1.1a3.78 3.78 0 0 1 .11 2.84A4.15 4.15 0 0 1 19 11.2c0 4.14-2.58 5.05-5 5.32a2.5 2.5 0 0 1 .75 2v2.95c0 .35.2.63.75.52A10.8 10.8 0 0 0 23 11.77 10.89 10.89 0 0 0 12 1","data-name":"github",fill:"currentColor"})]})}),M8="https://arize.com/docs/phoenix/tracing/how-to-tracing/setup-tracing",F8="https://arize.com/docs/phoenix/tracing/how-to-tracing/setup-tracing/setup-tracing-python/using-otel-python-directly",D8="https://arize.com/docs/phoenix/setup/configuration",E8="pip install arize-phoenix-otel",K8="pip install openinference-instrumentation-openai openai";function _8({isAuthEnabled:n,isHosted:a}){return a?`PHOENIX_CLIENT_HEADERS='api_key=<your-api-key>'
PHOENIX_COLLECTOR_ENDPOINT='${zl}'`:n?"PHOENIX_API_KEY='<your-api-key>'":`PHOENIX_COLLECTOR_ENDPOINT='${Ln}'`}const V8=`from openinference.instrumentation.openai import OpenAIInstrumentor

OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)`,P8=`import os
from openai import OpenAI

client = OpenAI(
    # This is the default and can be omitted
    api_key=os.environ.get("OPENAI_API_KEY"),
)

chat_completion = client.chat.completions.create(
    messages=[
        {
            "role": "user",
            "content": "Say this is a test",
        }
    ],
    model="gpt-3.5-turbo",
)`,R8=({isHosted:n,projectName:a})=>`from phoenix.otel import register

tracer_provider = register(
  project_name="${a}",
  endpoint="${(n?zl:Ln)+"/v1/traces"}",
  auto_instrument=True
)`;function Sf(n){const a=i8,t=window.Config.authenticationEnabled,l=_8({isAuthEnabled:t,isHosted:a}),i=n.projectName||"your-next-llm-project";return s("div",{children:[e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Install Dependencies"})}),e(w,{paddingBottom:"size-100",children:s(C,{children:["Use the Phoenix OTEL or"," ",e(fe,{href:F8,children:"OpenTelemetry"})," to configure your application to send traces to Phoenix."]})}),e(ke,{children:e(De,{value:E8})}),e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Setup your Environment"})}),e(w,{paddingBottom:"size-100",children:s(C,{children:[e("b",{children:"arize-phoenix-otel"})," automatically picks up your configuration from"," ",e(fe,{href:D8,children:"environment variables"})]})}),e(ke,{children:e(De,{value:l})}),t?e(w,{paddingBottom:"size-100",paddingTop:"size-100",children:e(uo,{fallback:s(C,{children:["Personal API keys can be created and managed on your"," ",e(fe,{href:"/profile",children:"Profile"})]}),children:s(C,{children:["System API keys can be created and managed in"," ",e(fe,{href:"/settings/general",children:"Settings"})]})})}):null,e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Setup OpenTelemetry"})}),e(w,{paddingBottom:"size-100",children:s(C,{children:["Register your application to send traces to this project. The code below should be added ",e("b",{children:"BEFORE"})," any code execution."]})}),e(w,{paddingBottom:"size-100",children:e(ke,{children:e(De,{value:R8({projectName:i,isHosted:a})})})}),a?null:e(w,{paddingBottom:"size-100",children:s(C,{children:["To configure gRPC and batching, see our"," ",e(fe,{href:M8,children:"setup guide"}),"."]})}),e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Setup Instrumentation"})}),e(w,{paddingBottom:"size-100",children:e(C,{children:"Add instrumentation to your application so that your application code is traces."})}),e(w,{borderColor:"dark",borderWidth:"thin",borderRadius:"medium",children:s(Yr,{children:[s(Jr,{children:[e(Yn,{id:"instrumentation",children:"Instrumentation"}),e(Yn,{id:"openai-example",children:"OpenAI Example"})]}),e(Dn,{id:"instrumentation",children:s(w,{padding:"size-200",children:[s(C,{children:["Trace your application using"," ",e(fe,{href:"https://github.com/Arize-ai/openinference",children:"OpenInference"})," ","instrumentation and OpenTelemetry"]}),e(w,{paddingTop:"size-200",paddingBottom:"size-200",children:e(w8,{})}),s(C,{children:["For more integrations, checkout our"," ",e(fe,{href:"https://arize.com/docs/phoenix/tracing/integrations-tracing",children:"comprehensive guide"})]})]})}),e(Dn,{id:"openai-example",children:s(w,{padding:"size-200",children:[s("p",{children:["Install"," ",e(fe,{href:"https://github.com/Arize-ai/openinference",children:"OpenInference"})," ","instrumentation as well as ",e("b",{children:"openai"})]}),e(ke,{children:e(De,{value:K8})}),s("p",{children:["Instrument ",e("b",{children:"openai"})," at the beginning of your code"]}),e(w,{paddingBottom:"size-50",children:e(ke,{children:e(De,{value:V8})})}),s("p",{children:["Use ",e("b",{children:"openai"})," as you normally and traces will be sent to Phoenix"]}),e(w,{paddingBottom:"size-50",children:e(ke,{children:e(De,{value:P8})})})]})})]})})]})}const N8="https://arize.com/docs/phoenix/tracing/how-to-tracing/setup-tracing",O8=n=>`import { register } from '@arizeai/phoenix-otel';

register({
  projectName: '${n}',
  url: '${Ln}',
  apiKey: process.env.PHOENIX_API_KEY,
});`,$8=n=>`import { register } from '@arizeai/phoenix-otel';
import { OpenAIInstrumentation } from '@arizeai/openinference-instrumentation-openai';

register({
  projectName: '${n}',
  instrumentations: [
    new OpenAIInstrumentation(),
  ],
});`,B8=n=>`// instrumentation.ts
import { register, registerInstrumentations } from '@arizeai/phoenix-otel';
import OpenAI from 'openai';
import { OpenAIInstrumentation } from '@arizeai/openinference-instrumentation-openai';

register({
  projectName: '${n}',
});

// Manual instrumentation for ESM
const instrumentation = new OpenAIInstrumentation();
instrumentation.manuallyInstrument(OpenAI);

registerInstrumentations({
  instrumentations: [instrumentation],
});`,H8=[`export PHOENIX_COLLECTOR_ENDPOINT="${Ln}"`,'export PHOENIX_API_KEY="your-api-key"'].join(`
`);function wf(n){const t=n.projectName||"your-next-llm-project";return s("div",{children:[e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Install Phoenix OpenTelemetry"})}),e(w,{paddingBottom:"size-100",children:s(C,{children:["Install the"," ",e(fe,{href:"https://www.npmjs.com/package/@arizeai/phoenix-otel",children:"@arizeai/phoenix-otel"})," ","package, a lightweight wrapper around"," ",e(fe,{href:N8,children:"OpenTelemetry"})," ","that simplifies sending traces to Phoenix."]})}),e(ke,{children:e(De,{value:"npm install @arizeai/phoenix-otel"})}),e(w,{paddingY:"size-100",children:s(C,{children:["alternatively, you may want to use a platform or integration specific setup:"," "]})}),e(w,{paddingBottom:"size-100",children:e(T8,{})}),e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Quick Start"})}),e(w,{paddingBottom:"size-100",children:e(C,{children:"Use the register function to set up tracing"})}),e(ke,{children:e(kt,{value:O8(t)})}),e(H5,{children:e(w,{paddingBottom:"size-100",paddingTop:"size-100",children:e(uo,{fallback:s(C,{children:["Your personal API keys can be created and managed on your"," ",e(fe,{href:"/profile",children:"Profile"})]}),children:s(C,{children:["System API keys can be created and managed in"," ",e(fe,{href:"/settings/general",children:"Settings"})]})})})}),e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Environment Variables"})}),e(w,{paddingBottom:"size-100",children:e(C,{children:"Alternatively, you can configure Phoenix using environment variables:"})}),e(ke,{children:e(De,{value:H8})}),e(w,{paddingTop:"size-200",paddingBottom:"size-100",children:e(Q,{level:2,weight:"heavy",children:"Setup Instrumentation"})}),e(w,{paddingBottom:"size-100",children:e(C,{children:"Add instrumentation to your application so that your application code is traced."})}),e(w,{borderColor:"dark",borderWidth:"thin",borderRadius:"medium",children:s(Yr,{children:[s(Jr,{children:[e(Yn,{id:"integrations",children:"Integrations"}),e(Yn,{id:"commonjs",children:"CommonJS"}),e(Yn,{id:"esm",children:"ESM"})]}),e(Dn,{id:"integrations",children:s(w,{padding:"size-200",children:[e(C,{children:"Browse our integrations for popular frameworks and libraries:"}),e(w,{paddingTop:"size-200",paddingBottom:"size-200",children:e(z8,{})}),s(C,{children:["For more integrations, checkout our"," ",e(fe,{href:"https://arize.com/docs/phoenix/tracing/integrations-tracing",children:"comprehensive guide"})]})]})}),e(Dn,{id:"commonjs",children:s(w,{padding:"size-200",children:[s(C,{children:["For CommonJS projects, you can automatically instrument libraries using the ",e("b",{children:"instrumentations"})," parameter:"]}),e(w,{paddingTop:"size-200",children:e(ke,{children:e(kt,{value:$8(t)})})})]})}),e(Dn,{id:"esm",children:s(w,{padding:"size-200",children:[e(C,{children:"For ESM projects, manually instrument libraries. Here's an example with OpenAI:"}),e(w,{paddingTop:"size-200",children:e(ke,{children:e(kt,{value:B8(t)})})})]})})]})})]})}function xf(n){return e("button",{className:"button--reset",onClick:a=>{a.stopPropagation(),n.onClick(a)},"aria-label":n["aria-label"],css:p`
        color: var(--ac-global-text-color-white-900);
        .ac-icon-wrap {
          font-size: 1.2rem;
        }

        &:hover {
          color: var(--ac-global-color-primary);
        }
      `,children:e(x,{svg:n.isExpanded?e(o2,{}):e(r2,{})})})}function j8({gradientStartColor:n,gradientEndColor:a,size:t=32}){return e("div",{css:p`
        border-radius: 50%;
        width: ${t}px;
        height: ${t}px;
        background: linear-gradient(
          136.27deg,
          ${n} 14.03%,
          ${a} 84.38%
        );
        flex-shrink: 0;
      `})}const Z8=p`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--ac-global-dimension-size-50);
  padding: var(--ac-global-dimension-size-100);
  border: 2px solid transparent;
  border-radius: var(--ac-global-rounding-medium);
  cursor: pointer;
  transition: all 200ms ease;
  position: relative;
  background: transparent;

  /* Hover state */
  &[data-hovered]:not([data-disabled]):not([data-selected]) {
    border-color: var(--ac-global-color-grey-200);
  }

  /* Selected state */
  &[data-selected] {
    background-color: var(--ac-global-color-primary-50);
    border-color: var(--ac-global-color-primary);
  }

  /* Pressed state */
  &[data-pressed] {
    transform: scale(0.98);
  }

  /* Focus visible state */
  &[data-focus-visible] {
    outline: 2px solid var(--ac-global-color-primary);
    outline-offset: 2px;
  }

  /* Disabled state */
  &[data-disabled] {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* Label text styling */
  .gradient-circle-radio__label {
    font-size: var(--ac-global-dimension-static-font-size-75);
    color: var(--ac-global-text-color-700);
    text-align: center;
    font-weight: 500;
  }

  &[data-selected] .gradient-circle-radio__label {
    color: var(--ac-global-color-primary);
    font-weight: 600;
  }
`;function Tf({gradientStartColor:n,gradientEndColor:a,label:t,size:l=32,className:i,css:r,...o}){return s($i,{className:$("gradient-circle-radio",i),css:p(Z8,r),...o,children:[e(j8,{gradientStartColor:n,gradientEndColor:a,size:l}),t&&e("span",{className:"gradient-circle-radio__label",children:t})]})}const U8=p`
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  width: fit-content;
  gap: var(--ac-global-dimension-size-100);
  font-size: var(--ac-global-dimension-static-font-size-100);

  &[data-direction="row"] {
    flex-direction: row;
    flex-wrap: wrap;

    .react-aria-Label {
      flex-basis: 100%;
      margin-bottom: var(--ac-global-dimension-size-100);
    }

    [slot="description"] {
      flex-basis: 100%;
      margin-top: var(--ac-global-dimension-size-50);
    }
  }

  &[data-direction="column"] {
    flex-direction: column;
    align-items: flex-start;
  }

  &[data-disabled] {
    opacity: 0.5;
  }

  &[data-readonly] {
    .gradient-circle-radio {
      opacity: 0.7;
      cursor: default;
    }
  }

  &:has(.gradient-circle-radio[data-focus-visible]) {
    border-radius: var(--ac-global-rounding-small);
    outline: 1px solid var(--ac-global-color-primary);
    outline-offset: var(--ac-global-dimension-size-50);
  }
`;function If({css:n,className:a,direction:t="row",...l}){return e(Oi,{"data-direction":t,className:$("gradient-circle-radio-group",a),css:p(Te,U8,n),...l})}const P1=(function(){var n=[{alias:null,args:null,concreteType:"DatasetLabelEdge",kind:"LinkedField",name:"edges",plural:!0,selections:[{alias:null,args:null,concreteType:"DatasetLabel",kind:"LinkedField",name:"node",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"name",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"color",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"cursor",storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"PageInfo",kind:"LinkedField",name:"pageInfo",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"endCursor",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"hasNextPage",storageKey:null}],storageKey:null}],a=[{kind:"Literal",name:"first",value:100}];return{fragment:{argumentDefinitions:[],kind:"Fragment",metadata:null,name:"DatasetLabelFilterButtonQuery",selections:[{alias:"datasetLabels",args:null,concreteType:"DatasetLabelConnection",kind:"LinkedField",name:"__DatasetLabelFilterButton_datasetLabels_connection",plural:!1,selections:n,storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:[],kind:"Operation",name:"DatasetLabelFilterButtonQuery",selections:[{alias:null,args:a,concreteType:"DatasetLabelConnection",kind:"LinkedField",name:"datasetLabels",plural:!1,selections:n,storageKey:"datasetLabels(first:100)"},{alias:null,args:a,filters:null,handle:"connection",key:"DatasetLabelFilterButton_datasetLabels",kind:"LinkedHandle",name:"datasetLabels"}]},params:{cacheID:"d5b1149b8f992f9a1912e2f0ca116e04",id:null,metadata:{connection:[{count:null,cursor:null,direction:"forward",path:["datasetLabels"]}]},name:"DatasetLabelFilterButtonQuery",operationKind:"query",text:`query DatasetLabelFilterButtonQuery {
  datasetLabels(first: 100) {
    edges {
      node {
        id
        name
        color
        __typename
      }
      cursor
    }
    pageInfo {
      endCursor
      hasNextPage
    }
  }
}
`}}})();P1.hash="903bc82a627cc1c790b5e1a086026e31";function zf(n){const{selectedLabelIds:a,onSelectionChange:t}=n,l=a.length>0?`Labels (${a.length})`:"Labels";return s(we,{children:[e(D,{variant:"default",size:"M",trailingVisual:e(x,{svg:e(Pr,{})}),children:l}),e(le,{placement:"bottom end",children:e(g.Suspense,{fallback:e(ue,{}),children:e(G8,{selectedLabelIds:a,onSelectionChange:t})})})]})}function G8({selectedLabelIds:n,onSelectionChange:a}){const t=F.useLazyLoadQuery(P1,{},{fetchPolicy:"store-and-network"}),[l,i]=g.useState(""),r=t.datasetLabels.edges.map(d=>d.node).filter(d=>d.name.toLowerCase().includes(l.toLowerCase())),o=d=>{if(d==="all")return;const u=[...d];a(u)},c=()=>{a([])};return e(w,{padding:"size-200",children:s(S,{direction:"column",gap:"size-100",children:[e(hl,{autoFocus:!0,"aria-label":"Search labels",placeholder:"Search labels...",onChange:i}),e(Ie,{"aria-label":"labels",items:r,selectionMode:"multiple",selectedKeys:n,onSelectionChange:o,css:p`
            height: 300px;
            width: 320px;
          `,renderEmptyState:()=>"No labels found",children:d=>e(W8,{item:d},d.id)}),e(S,{direction:"row",justifyContent:"end",alignItems:"center",children:e(D,{variant:"quiet",size:"S",onPress:c,children:"Clear All"})})]})})}function W8({item:n}){return e(Ze,{id:n.id,children:({isSelected:a})=>s(S,{direction:"row",justifyContent:"space-between",children:[s(S,{direction:"row",gap:"size-100",alignItems:"center",children:[e(U,{color:n.color,size:"M",shape:"circle"}),n.name]}),a?e(x,{svg:e(Ua,{})}):null]})},n.id)}const R1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"input"}],a=[{alias:null,args:[{kind:"Variable",name:"input",variableName:"input"}],concreteType:"ExperimentMutationPayload",kind:"LinkedField",name:"deleteExperiments",plural:!1,selections:[{alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null}],storageKey:null}];return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentActionMenuDeleteExperimentMutation",selections:a,type:"Mutation",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentActionMenuDeleteExperimentMutation",selections:a},params:{cacheID:"7fcd7830853f4b8f55b104d75dc5312b",id:null,metadata:{},name:"ExperimentActionMenuDeleteExperimentMutation",operationKind:"mutation",text:`mutation ExperimentActionMenuDeleteExperimentMutation(
  $input: DeleteExperimentsInput!
) {
  deleteExperiments(input: $input) {
    __typename
  }
}
`}}})();R1.hash="c7f4f68f0256356c77264cc16b83e638";function Af(n){const[a,t]=F.useMutation(R1),{projectId:l}=n,i=kc(),[r,o]=g.useState(!1),[c,d]=g.useState(!1),u=_a(),m=Va(),h=n.onExperimentDeleted,b=g.useCallback(y=>{a({variables:{input:{experimentIds:[y]}},onCompleted:()=>{u({title:"Experiment deleted",message:"The experiment has been deleted."})},onError:v=>{const L=yn(v);m({title:"An error occurred",message:`Failed to delete experiment: ${(L==null?void 0:L[0])??v.message}`})}}),h==null||h(),o(!1)},[a,u,m,h]),f=[e(Ke,{id:"GO_TO_EXPERIMENT_RUN_TRACES",children:s(S,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(ml,{})}),e(C,{children:"View run traces"})]})},"GO_TO_EXPERIMENT_RUN_TRACES"),e(Ke,{id:"VIEW_METADATA",children:s(S,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(Wa,{})}),e(C,{children:"View metadata"})]})},"VIEW_METADATA"),e(Ke,{id:"COPY_EXPERIMENT_ID",children:s(S,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(Nr,{})}),e(C,{children:"Copy experiment ID"})]})},"COPY_EXPERIMENT_ID")];return n.canDeleteExperiment&&f.push(e(Ke,{id:"DELETE_EXPERIMENT",children:s(S,{direction:"row",gap:"size-75",justifyContent:"start",alignItems:"center",children:[e(x,{svg:e(gl,{})}),e(C,{children:t?"Deleting...":"Delete"})]})},"DELETE_EXPERIMENT")),s(vl,{children:[s(Ya,{children:[e(D,{"aria-label":"Experiment action menu",leadingVisual:e(x,{svg:e(Hr,{})}),size:"S"}),e(le,{children:e(ta,{disabledKeys:l?[]:["GO_TO_EXPERIMENT_RUN_TRACES"],onAction:y=>{switch(y){case"GO_TO_EXPERIMENT_RUN_TRACES":return i(`/projects/${l}`);case"VIEW_METADATA":{d(!0);break}case"COPY_EXPERIMENT_ID":{zi(n.experimentId),u({title:"Copied",message:"The experiment ID has been copied to your clipboard"});break}case"DELETE_EXPERIMENT":{o(!0);break}default:N()}},children:f})})]}),e(pn,{isDismissable:!0,isOpen:r,onOpenChange:o,children:e(gn,{size:"S",children:e(me,{children:s(Ve,{children:[s(Pe,{children:[e(Re,{children:"Delete Experiment"}),e(hn,{children:e(Ue,{slot:"close"})})]}),e(w,{padding:"size-200",children:e(C,{color:"danger",children:"Are you sure you want to delete this experiment and its annotations and traces?"})}),e(w,{paddingEnd:"size-200",paddingTop:"size-100",paddingBottom:"size-100",borderTopColor:"light",borderTopWidth:"thin",children:s(S,{direction:"row",justifyContent:"end",gap:"size-100",children:[e(D,{size:"S",onPress:()=>o(!1),children:"Cancel"}),e(D,{variant:"danger",size:"S",onPress:()=>b(n.experimentId),children:"Delete Experiment"})]})})]})})})}),e(pn,{isDismissable:!0,isOpen:c,onOpenChange:d,children:e(gn,{size:"S",children:e(me,{children:s(Ve,{children:[s(Pe,{children:[e(Re,{children:"Metadata"}),e(hn,{children:e(Ue,{slot:"close"})})]}),e(yl,{value:JSON.stringify(n.metadata,null,2)})]})})})})]})}const N1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"experimentId"}],a=[{kind:"Variable",name:"id",variableName:"experimentId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l={alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null},i=[l],r={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:i,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:i,storageKey:null}],storageKey:null},{alias:null,args:null,concreteType:"SpanCostDetailSummaryEntry",kind:"LinkedField",name:"costDetailSummaryEntries",plural:!0,selections:[{alias:null,args:null,kind:"ScalarField",name:"tokenType",storageKey:null},{alias:null,args:null,kind:"ScalarField",name:"isPrompt",storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"value",plural:!1,selections:[l,{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],storageKey:null}],storageKey:null}],type:"Experiment",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentTokenCostsDetailsQuery",selections:[{alias:"experiment",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentTokenCostsDetailsQuery",selections:[{alias:"experiment",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,r,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"3b4a585ebf1e46fed5f48bb8d74eec68",id:null,metadata:{},name:"ExperimentTokenCostsDetailsQuery",operationKind:"query",text:`query ExperimentTokenCostsDetailsQuery(
  $experimentId: ID!
) {
  experiment: node(id: $experimentId) {
    __typename
    ... on Experiment {
      costSummary {
        total {
          cost
        }
        prompt {
          cost
        }
        completion {
          cost
        }
      }
      costDetailSummaryEntries {
        tokenType
        isPrompt
        value {
          cost
          tokens
        }
      }
    }
    id
  }
}
`}}})();N1.hash="2101043bf625b3499039a269191c9269";function Q8({experimentId:n}){const a=F.useLazyLoadQuery(N1,{experimentId:n}),t=g.useMemo(()=>{var l,i,r,o,c,d;if(a.experiment.__typename==="Experiment"){const u=a.experiment.costDetailSummaryEntries;if(!u)return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null};const m=u.filter(k=>k.isPrompt),h=u.filter(k=>!k.isPrompt),b=((i=(l=a.experiment.costSummary)==null?void 0:l.total)==null?void 0:i.cost)??0,f=((o=(r=a.experiment.costSummary)==null?void 0:r.prompt)==null?void 0:o.cost)??0,y=((d=(c=a.experiment.costSummary)==null?void 0:c.completion)==null?void 0:d.cost)??0,v={};m.forEach(k=>{k.value.cost!=null&&(v[k.tokenType]=k.value.cost)});const L={};return h.forEach(k=>{k.value.cost!=null&&(L[k.tokenType]=k.value.cost)}),{total:b,prompt:f,completion:y,promptDetails:Object.keys(v).length>0?v:null,completionDetails:Object.keys(L).length>0?L:null}}return{total:null,prompt:null,completion:null,promptDetails:null,completionDetails:null}},[a.experiment]);return e(Sn,{...t})}function Mf(n){return s(j,{children:[e(se,{children:e(on,{size:n.size,role:"button",children:n.totalCost})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(Q8,{experimentId:n.experimentId})})]})]})}function q8(n){return typeof n=="string"&&["grid","list","metrics"].includes(n)}function Ff({viewMode:n,onViewModeChange:a}){return s(fa,{selectedKeys:[n],selectionMode:"single",onSelectionChange:t=>{if(t.size===0)return;const l=t.keys().next().value;q8(l)?a(l):a("grid")},size:"S",children:[e(Ae,{id:"grid",leadingVisual:e(x,{svg:e(Or,{})}),children:"Grid"}),e(Ae,{id:"list",leadingVisual:e(x,{svg:e($r,{})}),children:"List"}),e(Ae,{id:"metrics",leadingVisual:e(x,{svg:e(n2,{})}),children:"Metrics"})]})}function Df({annotation:n,extra:a}){return e(se,{children:e("button",{className:"button--reset",css:p`
          cursor: pointer;
          padding: var(--ac-global-dimension-size-50)
            var(--ac-global-dimension-size-100);
          flex: 1 1 auto;
          border-radius: var(--ac-global-rounding-small);
          width: 100%;
          &:hover {
            background-color: var(--ac-global-color-grey-200);
          }
        `,children:s(S,{direction:"row",gap:"size-100",alignItems:"center",justifyContent:"space-between",children:[e(io,{annotation:n,displayPreference:"score"}),a]})})})}const O1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"experimentId"}],a=[{kind:"Variable",name:"id",variableName:"experimentId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l=[{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],i={kind:"InlineFragment",selections:[{alias:null,args:null,kind:"ScalarField",name:"runCount",storageKey:null},{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:l,storageKey:null}],storageKey:null}],type:"Experiment",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentAverageRunTokenCountDetailsQuery",selections:[{alias:"experiment",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentAverageRunTokenCountDetailsQuery",selections:[{alias:"experiment",args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"0e70281a4361949908af5866b8aa6c4e",id:null,metadata:{},name:"ExperimentAverageRunTokenCountDetailsQuery",operationKind:"query",text:`query ExperimentAverageRunTokenCountDetailsQuery(
  $experimentId: ID!
) {
  experiment: node(id: $experimentId) {
    __typename
    ... on Experiment {
      runCount
      costSummary {
        total {
          tokens
        }
        prompt {
          tokens
        }
        completion {
          tokens
        }
      }
    }
    id
  }
}
`}}})();O1.hash="7772e95d9d4cf1f8435cb8fcf8e77081";function X8({experimentId:n}){const a=F.useLazyLoadQuery(O1,{experimentId:n}),t=g.useMemo(()=>{if(a.experiment.__typename==="Experiment"){const l=a.experiment.costSummary.prompt.tokens,i=a.experiment.costSummary.completion.tokens,r=a.experiment.costSummary.total.tokens,o=a.experiment.runCount,c=r==null||o==0?null:r/o,d=l==null||o==0?null:l/o,u=i==null||o==0?null:i/o;return{total:c,prompt:d,completion:u}}return{total:null,prompt:null,completion:null}},[a.experiment]);return e(rn,{...t,label:"Average"})}function Ef(n){return n.averageRunTokenCountTotal==null?e(Fe,{size:n.size,children:null}):s(j,{children:[e(se,{children:e(Fe,{size:n.size,role:"button",children:n.averageRunTokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(X8,{experimentId:n.experimentId})})]})]})}const $1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l=[{alias:null,args:null,kind:"ScalarField",name:"cost",storageKey:null}],i={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:l,storageKey:null}],storageKey:null}],type:"ExperimentRepeatedRunGroup",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentRepeatedRunGroupTokenCostDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentRepeatedRunGroupTokenCostDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"43099aa66474f4d3fa7cd9dc3f04ccf2",id:null,metadata:{},name:"ExperimentRepeatedRunGroupTokenCostDetailsQuery",operationKind:"query",text:`query ExperimentRepeatedRunGroupTokenCostDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on ExperimentRepeatedRunGroup {
      costSummary {
        total {
          cost
        }
        prompt {
          cost
        }
        completion {
          cost
        }
      }
    }
    id
  }
}
`}}})();$1.hash="125a71d4c6f856ce5da6d344cac839e8";function Y8(n){const a=F.useLazyLoadQuery($1,{nodeId:n.experimentRepeatedRunGroupId}),t=g.useMemo(()=>{if(a.node.__typename==="ExperimentRepeatedRunGroup"){const l=a.node.costSummary.prompt.cost,i=a.node.costSummary.completion.cost;return{total:a.node.costSummary.total.cost,prompt:l,completion:i}}return{total:null,prompt:null,completion:null}},[a.node]);return e(Sn,{...t})}function Kf(n){return s(j,{isDisabled:n.costTotal==null,children:[e(se,{children:e(on,{size:n.size,"aria-role":"button",children:n.costTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(Y8,{experimentRepeatedRunGroupId:n.experimentRepeatedRunGroupId})})]})]})}const B1=(function(){var n=[{defaultValue:null,kind:"LocalArgument",name:"nodeId"}],a=[{kind:"Variable",name:"id",variableName:"nodeId"}],t={alias:null,args:null,kind:"ScalarField",name:"__typename",storageKey:null},l=[{alias:null,args:null,kind:"ScalarField",name:"tokens",storageKey:null}],i={kind:"InlineFragment",selections:[{alias:null,args:null,concreteType:"SpanCostSummary",kind:"LinkedField",name:"costSummary",plural:!1,selections:[{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"total",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"prompt",plural:!1,selections:l,storageKey:null},{alias:null,args:null,concreteType:"CostBreakdown",kind:"LinkedField",name:"completion",plural:!1,selections:l,storageKey:null}],storageKey:null}],type:"ExperimentRepeatedRunGroup",abstractKey:null};return{fragment:{argumentDefinitions:n,kind:"Fragment",metadata:null,name:"ExperimentRepeatedRunGroupTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i],storageKey:null}],type:"Query",abstractKey:null},kind:"Request",operation:{argumentDefinitions:n,kind:"Operation",name:"ExperimentRepeatedRunGroupTokenCountDetailsQuery",selections:[{alias:null,args:a,concreteType:null,kind:"LinkedField",name:"node",plural:!1,selections:[t,i,{alias:null,args:null,kind:"ScalarField",name:"id",storageKey:null}],storageKey:null}]},params:{cacheID:"17535680d5a7af6fa77466bf5134c3e0",id:null,metadata:{},name:"ExperimentRepeatedRunGroupTokenCountDetailsQuery",operationKind:"query",text:`query ExperimentRepeatedRunGroupTokenCountDetailsQuery(
  $nodeId: ID!
) {
  node(id: $nodeId) {
    __typename
    ... on ExperimentRepeatedRunGroup {
      costSummary {
        total {
          tokens
        }
        prompt {
          tokens
        }
        completion {
          tokens
        }
      }
    }
    id
  }
}
`}}})();B1.hash="fc023fee63f29794e61517820b6c9313";function J8(n){const a=F.useLazyLoadQuery(B1,{nodeId:n.experimentRepeatedRunGroupId}),t=g.useMemo(()=>{if(a.node.__typename==="ExperimentRepeatedRunGroup"){const l=a.node.costSummary.prompt.tokens,i=a.node.costSummary.completion.tokens;return{total:a.node.costSummary.total.tokens,prompt:l,completion:i}}return{total:null,prompt:null,completion:null}},[a.node]);return e(rn,{...t})}function _f(n){return s(j,{isDisabled:n.tokenCountTotal==null,children:[e(se,{children:e(Fe,{size:n.size,role:"button",children:n.tokenCountTotal})}),s(ge,{children:[e(ce,{}),e(g.Suspense,{fallback:e(ue,{}),children:e(J8,{experimentRepeatedRunGroupId:n.experimentRepeatedRunGroupId})})]})]})}function Vf(){const[n,a]=g.useState(!1);return s(we,{children:[e(D,{size:"S",variant:"primary",leadingVisual:e(x,{svg:e(Qa,{})}),onPress:()=>a(!0),children:"New Label"}),e(pn,{isOpen:n,onOpenChange:a,children:e(gn,{size:"S",children:e(A4,{onCompleted:()=>a(!1)})})})]})}function em(n){const{updateConnectionIds:a,datasetId:t,onCompleted:l}=n,{addLabelMutation:i,isSubmitting:r,error:o}=w1({updateConnectionIds:a,datasetId:t});return e(me,{children:({close:c})=>s(Ve,{children:[s(Pe,{children:[e(Re,{children:"New Dataset Label"}),e(Ue,{})]}),o?e(On,{banner:!0,variant:"danger",children:o}):null,e(Ll,{onSubmit:d=>{i(d,()=>{l(),c()})},isSubmitting:r})]})})}function Pf(n){const[a,t]=g.useState(!1);return s(we,{children:[e(D,{size:"S",variant:"primary",leadingVisual:e(x,{svg:e(Qa,{})}),onPress:()=>t(!0),children:"New Label"}),e(pn,{isOpen:a,onOpenChange:t,children:e(gn,{size:"S",children:e(em,{updateConnectionIds:n.updateConnectionIds,onCompleted:()=>t(!1)})})})]})}export{Qg as $,Re as A,hn as B,Sm as C,xr as D,Ue as E,w as F,lp as G,pn as H,rp as I,cp as J,S as K,C as L,D as M,x as N,Cg as O,At as P,fl as Q,ua as R,ao as S,Je as T,x0 as U,Zg as V,Ug as W,Va as X,_a as Y,ee as Z,gn as _,Oa as a,ge as a$,qg as a0,Wr as a1,gl as a2,Qa as a3,sg as a4,ig as a5,F5 as a6,Lp as a7,ro as a8,ye as a9,Yr as aA,S5 as aB,Pp as aC,Vp as aD,nh as aE,ah as aF,Yl as aG,h4 as aH,kn as aI,po as aJ,f4 as aK,go as aL,Ln as aM,pm as aN,uo as aO,pa as aP,Hg as aQ,Bg as aR,Gm as aS,Wm as aT,lh as aU,th as aV,Kt as aW,On as aX,vg as aY,mp as aZ,$n as a_,Se as aa,eo as ab,xe as ac,ce as ad,yn as ae,Q as af,Ya as ag,Hr as ah,ta as ai,Ke as aj,le as ak,ue as al,Br as am,vl as an,ud as ao,ja as ap,Ap as aq,Mp as ar,_p as as,Ip as at,v2 as au,wp as av,Tp as aw,Jr as ax,Yn as ay,Yg as az,zr as b,t0 as b$,lo as b0,hl as b1,We as b2,ze as b3,Ie as b4,oe as b5,fh as b6,ch as b7,hh as b8,ph as b9,qd as bA,tn as bB,A4 as bC,pl as bD,U as bE,Ua as bF,ap as bG,np as bH,$g as bI,km as bJ,Og as bK,Ng as bL,yl as bM,Dm as bN,Fm as bO,Jm as bP,Rg as bQ,$m as bR,Bm as bS,Hm as bT,vh as bU,yh as bV,Rm as bW,ga as bX,$a as bY,Ba as bZ,Jd as b_,Me as ba,pd as bb,sh as bc,uh as bd,pg as be,xg as bf,bg,Mg as bh,zg as bi,gg as bj,rh as bk,Kg as bl,ih as bm,Tg as bn,oh as bo,Ag as bp,gh as bq,mh as br,Ig as bs,dh as bt,Jg as bu,bh as bv,um as bw,dm as bx,O5 as by,V5 as bz,al as c,qh as c$,xp as c0,R5 as c1,P5 as c2,Sh as c3,qu as c4,L0 as c5,Ed as c6,Um as c7,jr as c8,ii as c9,cl as cA,Oh as cB,bn as cC,I5 as cD,Bn as cE,jh as cF,G9 as cG,m9 as cH,Dh as cI,Nr as cJ,ku as cK,v5 as cL,Rp as cM,k6 as cN,s4 as cO,bl as cP,Gh as cQ,w6 as cR,Wh as cS,Qh as cT,E6 as cU,K6 as cV,x6 as cW,Zh as cX,jg as cY,kg as cZ,Fp as c_,ri as ca,ip as cb,Ft as cc,Th as cd,i2 as ce,xh as cf,fn as cg,Eg as ch,up as ci,Sl as cj,kp as ck,Wa as cl,ml as cm,E4 as cn,sl as co,b2 as cp,Gu as cq,Xg as cr,Pr as cs,fe as ct,og as cu,ag as cv,rg as cw,Rh as cx,Fg as cy,Za as cz,im as d,ad as d$,oo as d0,Xh as d1,fg as d2,Lg as d3,Jh as d4,af as d5,Lh as d6,Ae as d7,j0 as d8,eg as d9,Ih as dA,Sg as dB,ef as dC,Ga as dD,Te as dE,ke as dF,h0 as dG,Ym as dH,Lm as dI,Qd as dJ,Vm as dK,Pm as dL,_m as dM,fa as dN,Zm as dO,of as dP,Im as dQ,Tm as dR,xm as dS,g0 as dT,op as dU,sp as dV,rf as dW,sf as dX,wh as dY,eh as dZ,Ka as d_,vo as da,Q0 as db,de as dc,J0 as dd,ed as de,$h as df,Hh as dg,Bh as dh,ci as di,wg as dj,a9 as dk,Uh as dl,U9 as dm,Nh as dn,tf as dp,lf as dq,_r as dr,Fh as ds,Eh as dt,Ah as du,i0 as dv,Kp as dw,zh as dx,dp as dy,Sp as dz,Em as e,$3 as e$,cf as e0,df as e1,uf as e2,gf as e3,mf as e4,Xc as e5,qc as e6,E as e7,e7 as e8,Gp as e9,ff as eA,vf as eB,hf as eC,L5 as eD,Bp as eE,Yp as eF,Ja as eG,Xm as eH,p4 as eI,ng as eJ,Ch as eK,Wg as eL,Cm as eM,ug as eN,S2 as eO,hg as eP,De as eQ,kt as eR,Lf as eS,U5 as eT,Kh as eU,Km as eV,Sf as eW,wf as eX,mg as eY,Y2 as eZ,Z6 as e_,Wp as ea,Qp as eb,Np as ec,Op as ed,$p as ee,f7 as ef,b7 as eg,yg as eh,kr as ei,S7 as ej,Xn as ek,dn as el,M1 as em,Dn as en,Kn as eo,kf as ep,bf as eq,Jt as er,yf as es,Cf as et,ym as eu,bm as ev,vm as ew,om as ex,pf as ey,qm as ez,S0 as f,z2 as f$,tp as f0,Ep as f1,n6 as f2,xf as f3,Mh as f4,Hp as f5,jp as f6,Zp as f7,Up as f8,pp as f9,a2 as fA,Dg as fB,Dp as fC,M5 as fD,zf as fE,H5 as fF,nf as fG,h5 as fH,_h as fI,dg as fJ,lg as fK,ba as fL,E3 as fM,Mf as fN,Vh as fO,Af as fP,_f as fQ,Kf as fR,Fo as fS,Ef as fT,Ph as fU,Df as fV,so as fW,j3 as fX,w5 as fY,M9 as fZ,s2 as f_,hp as fa,fp as fb,bp as fc,yp as fd,qp as fe,Jp as ff,Xp as fg,vp as fh,Cp as fi,gp as fj,sm as fk,rm as fl,Gg as fm,Or as fn,$r as fo,j8 as fp,If as fq,Tf as fr,kh as fs,En as ft,zp as fu,X5 as fv,dd as fw,Yh as fx,G6 as fy,ep as fz,Ta as g,Vg as g0,Pg as g1,dl as g2,o3 as g3,q8 as g4,Ff as g5,Vf as g6,Pf as g7,p2 as g8,fm as g9,hm as ga,sd as gb,Xe as gc,ai as gd,tg as ge,gm as gf,cg as gg,g2 as gh,_g as gi,cm as gj,mm as gk,jm as h,Le as i,xa as j,Kd as k,l0 as l,N as m,wm as n,m0 as o,Nm as p,Om as q,zm as r,nd as s,Mm as t,Am as u,Wd as v,Qm as w,me as x,Ve as y,Pe as z};
