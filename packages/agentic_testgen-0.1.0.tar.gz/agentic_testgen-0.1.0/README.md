# UnitTGS

Test Generation System

---

## Overview

UnitTGS is an agentic, modular system for automated unit test generation, execution, and logging for JavaScript/React projects. It detects code changes, generates tests using AI (OpenAI GPT-3.5), runs them with Jest and React Testing Library, and logs results for continuous improvement.

---

## Project Structure & File/Folder Descriptions

```
UnitTGS/
│
├── api/                # Flask APIs and orchestration
│   ├── __init__.py           # Marks api/ as a Python package
│   ├── app.py                # Main Flask orchestrator: detects changes, triggers test generation, runs tests, logs results
│   └── test_generation_api.py# API endpoint for generating tests (mock or real)
│
├── src/                # Core business logic and utilities
│   ├── __init__.py           # Marks src/ as a Python package
│   ├── core_logic.py         # Core logic for test generation and agentic feedback
│   ├── test_utils.py         # Utilities for file operations, change detection, and path normalization
│   └── agentic_logger.py     # Handles logging of test generation attempts and results
│
├── scripts/            # Runners and setup scripts
│   ├── run_jest_test.py      # Script to run a generated Jest test and show results in terminal
│   ├── test_runner.py        # Logic to run tests (pytest or Jest) programmatically
│   └── setup_jest.sh         # Shell script to set up Jest and React Testing Library
│
├── tests/              # All test files
│   ├── __init__.py           # Marks tests/ as a Python package
│   ├── python/               # Python unit tests for business logic
│   │   └── test_*.py
│   └── js/                   # Jest/React tests for JS/React components
│       └── test_*.js
│
├── config/             # Config files
│   └── jest.config.js        # Configuration for Jest test runner
│
├── requirements.txt         # Python dependencies
├── package.json             # Node.js dependencies for JS/React testing
├── README.md                # Project documentation (this file)
├── agentic_log.json         # Log file for all test generation attempts and results
└── .gitignore               # Git ignore rules
```

---

## File/Folder Details

### api/

- **app.py**: Main entrypoint for the orchestrator. Detects staged changes, calls the test generation API, runs tests, and logs results. Implements the agentic feedback loop.
- **test_generation_api.py**: Flask API for generating tests. Can return mock tests or use OpenAI for real test generation.
- \***\*init**.py\*\*: Marks the folder as a Python package.

### src/

- **core_logic.py**: Contains the main logic for generating tests, retrying on failure, and agentic improvements.
- **test_utils.py**: Utility functions for reading files, detecting changes, and normalizing paths.
- **agentic_logger.py**: Handles logging of all test generation attempts and results to `agentic_log.json`.
- \***\*init**.py\*\*: Exposes key functions for easy import.

### scripts/

- **run_jest_test.py**: Prompts for a JS/JSX file, runs the corresponding Jest test, and prints results in the terminal.
- **test_runner.py**: Contains logic to run tests using Jest for JS/React and return pass/fail status.
- **setup_jest.sh**: Automates installation and configuration of Jest and React Testing Library.
- **pr_test_generator.py**: Generates tests for files changed in Pull Requests.
- **run_pr_tests.py**: Runs all generated PR tests with coverage reporting.

### tests/

- \***\*tests**/\*\*: All Jest/React tests for JS/JSX files, organized by module.
- Test files follow the pattern: `test_<filename>.js` or `test_<filename>.jsx`

### config/

- **jest.config.js**: Central Jest configuration for JS/React test discovery and running.

### Root Files

- **requirements.txt**: Lists all Python dependencies for the project.
- **package.json**: Lists all Node.js dependencies for JS/React testing.
- **agentic_log.json**: Stores logs of all test generation and execution attempts for agentic memory and debugging.
- **README.md**: This documentation file.
- **.gitignore**: Specifies files and folders to be ignored by git.

---

## How It Works

1. **Detect Changes**: The orchestrator (`app.py`) detects staged JS/JSX files using git.
2. **Generate Tests**: For each changed file, it calls the test generation API (`api/test_generation_api.py`), which uses OpenAI GPT-3.5 to generate comprehensive tests with Jest and React Testing Library.
3. **Save & Run Tests**: The generated test is saved in a `__tests__` directory next to the source file. The test runner runs tests using Jest.
4. **Jest Watcher**: An automated watcher monitors the `__tests__` directory and runs new tests automatically with coverage reporting.
5. **PR Integration**: GitHub Actions workflow automatically generates and runs tests for files changed in Pull Requests.

---

## Setup & Usage

- See the main documentation above for setup, installation, and usage instructions.
- All code is modular and can be extended for new languages, test runners, or agentic improvements.

---

## Quickstart

1. **Clone and set up the project:**

   ```sh
   git clone <repo-url>
   cd UnitTGS
   python3.10 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   npm install --legacy-peer-deps
   ```

2. **Configure OpenAI API Key:**

   ```sh
   # Create .env file
   echo "OPENAI_API_KEY=your-api-key-here" > .env
   echo "TEST_API_MODE=real" >> .env
   ```

3. **Start the system:**

   ```sh
   # Terminal 1: Start test generation API
   python -m api.test_generation_api

   # Terminal 2: Start main orchestrator (includes Jest watcher)
   python -m app
   ```

4. **Generate tests for JS/JSX files:**

   ```sh
   # Stage JS/JSX files
   git add src/utils/myUtil.js

   # Generate tests
   curl -X POST http://localhost:5000/generate-tests -H "Content-Type: application/json" -d '{}'
   ```

5. **Manually run a Jest test:**
   ```sh
   python scripts/run_jest_test.py
   ```

---

````

# Agentic Test Generation System

A modular, agentic, multi-language PR auto test generation system. Supports adapters for Jest (JavaScript), Pytest (Python), and NUnit (C#).

## Features
- Adapter pattern for easy extension to new languages/frameworks
- CLI and Python API
- Plug-and-play in any project
- PyPI-ready packaging

## Installation

From PyPI (after publishing):

```bash
pip install agentic_testgen
````

From source (local):

```bash
git clone https://github.com/sede-test/UnitTestGenerationSystem.git
cd UnitTestGenerationSystem/UnitTestGenerationSystem
pip install -e .
```

## Usage

### CLI

```bash
agentic-testgen --help
```

### Python API

```python
from agentic_testgen.main import AgenticPRTestGenerator


- Test file: `src/components/__tests__/test_Button.jsx`
```

## Extending

Add new adapters in `agentic_testgen/adapters/` and register in `adapter_factory.py`.

## Publishing to PyPI

1. Build the package:

```bash
python setup.py sdist bdist_wheel
```

2. Upload to PyPI:

```bash
twine upload dist/*
```

## License

MIT

- Status: Passed
- Coverage:
  - Statements: 95.5%
  - Branches: 87.5%
  - Functions: 100.0%

#### ✅ `src/utils/helpers.js`

- Test file: `src/utils/__tests__/test_helpers.js`
- Status: Passed
- Coverage:
  - Statements: 92.3%
  - Branches: 83.3%
  - Functions: 100.0%

#### ❌ `src/api/client.js`

- Test file: `src/api/__tests__/test_client.js`
- Status: Failed
- Coverage:
  - Statements: 78.2%
  - Branches: 66.7%
  - Functions: 85.7%

````

### Configuration

- **File Patterns**: Workflow monitors `.js`, `.jsx`, and `.py` files
- **Exclusions**: Automatically skips config files, test files, and dependencies
- **Auto-commit**: Generated tests are automatically committed to the PR branch
- **Coverage**: Full coverage reporting included in results

---

## Example API Request/Response

**Request:**

```sh
curl -X POST http://localhost:7072/api/HttpTrigger \
     -H "Content-Type: application/json" \
     -d '{"file_path": "src/MyComponent.jsx", "content": "...file contents..."}'
````

**Response (mock):**

```json
{
  "test_code": "test('add function', () => {\n  expect(add(1, 2)).toBe(3);\n});"
}
```

---

## Sample Agentic Log Entry

```json
[
  {
    "file": "src/MyComponent.jsx",
    "attempt": 1,
    "generation_result": { "test_code": "..." },
    "test_passed": true
  },
  {
    "file": "src/MyComponent.jsx",
    "attempt": 2,
    "generation_result": { "test_code": "..." },
    "test_passed": false
  }
]
```

---

## Agentic Feedback Loop Diagram

```
[Detect Changes] -> [Generate Test] -> [Run Test] --(fail)--> [Retry/Regenerate] --(fail)--> [Log & Notify]
                                 |--(pass)--------------------------------------> [Log Success]
```

---

## Extending the System

- Add new test generators in `src/core_logic.py` and expose via the API.
- Add new runners in `scripts/` and update `test_utils.py` for more languages.
- Integrate with CI/CD by using the orchestrator as a pre-commit or CI hook.
- Enhance agentic logic for smarter retries and learning.

---

## License

MIT
