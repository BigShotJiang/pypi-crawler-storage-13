import argparse
import os
from .main import main

def cli():
    parser = argparse.ArgumentParser(description="Agentic Auto Test Generation System")
    parser.add_argument("--project-root", type=str, required=True, help="Root directory of the project")
    parser.add_argument("--files", nargs="+", required=True, help="List of changed source files")
    args = parser.parse_args()
    main(args.project_root, args.files)

if __name__ == "__main__":
    cli()
