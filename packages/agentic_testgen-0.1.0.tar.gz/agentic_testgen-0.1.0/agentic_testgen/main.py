import os
from .adapters.adapter_factory import get_adapter
from .agents.orchestrator_agent import OrchestratorAgent

class AgenticPRTestGenerator:
    def __init__(self, project_root, max_retries=3, min_coverage=70):
        self.project_root = project_root
        self.max_retries = max_retries
        self.min_coverage = min_coverage
        self.orchestrator = OrchestratorAgent(max_attempts=max_retries, min_coverage=min_coverage)

    def detect_project_type(self, file_path):
        if file_path.endswith(('.js', '.jsx', '.ts', '.tsx')):
            return "js"
        elif file_path.endswith('.py'):
            return "py"
        elif file_path.endswith(('.cs', '.csproj')):
            return "cs"
        else:
            return "js"

    def process_changed_files(self, changed_files):
        for file_path in changed_files:
            project_type = self.detect_project_type(file_path)
            adapter = get_adapter(project_type)
            # Generate tests
            source_code = open(os.path.join(self.project_root, file_path)).read()
            test_code = adapter.generate_tests(file_path, source_code)
            # Save test file
            test_file_path = os.path.join(self.project_root, os.path.dirname(file_path), "__tests__", os.path.basename(file_path).replace(".jsx", ".test.jsx"))
            os.makedirs(os.path.dirname(test_file_path), exist_ok=True)
            with open(test_file_path, "w") as f:
                f.write(test_code)
            # Run tests and collect coverage
            adapter.run_tests([test_file_path])
            coverage = adapter.collect_coverage()
            print(f"Coverage for {file_path}: {coverage}")

def main(project_root, changed_files):
    generator = AgenticPRTestGenerator(project_root)
    generator.process_changed_files(changed_files)
