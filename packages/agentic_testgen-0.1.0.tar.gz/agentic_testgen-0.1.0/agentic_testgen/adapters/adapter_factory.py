from .jest_adapter import JestAdapter
from .pytest_adapter import PytestAdapter
from .nunit_adapter import NUnitAdapter

def get_adapter(project_type):
    if project_type == "js":
        return JestAdapter()
    elif project_type == "py":
        return PytestAdapter()
    elif project_type == "cs":
        return NUnitAdapter()
    else:
        raise ValueError(f"Unsupported project type: {project_type}")
