import subprocess
import os
import json
from .adapter_interface import TestFrameworkAdapter

class JestAdapter(TestFrameworkAdapter):
    def generate_tests(self, source_file, source_code):
        # Placeholder: Call LLM or agentic system to generate Jest tests
        return f"// Jest test code for {source_file}\n"

    def run_tests(self, test_files):
        cmd = ["npx", "jest", "--coverage"] + test_files
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result

    def collect_coverage(self):
        coverage_file = os.path.join("coverage", "coverage-summary.json")
        if os.path.exists(coverage_file):
            with open(coverage_file) as f:
                return json.load(f)
        return None
