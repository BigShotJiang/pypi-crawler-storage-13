from abc import ABC, abstractmethod

class TestFrameworkAdapter(ABC):
    @abstractmethod
    def generate_tests(self, source_file, source_code):
        pass

    @abstractmethod
    def run_tests(self, test_files):
        pass

    @abstractmethod
    def collect_coverage(self):
        pass
