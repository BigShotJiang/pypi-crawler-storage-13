from setuptools import setup, find_packages
import os

def readme():
    with open(os.path.join(os.path.dirname(__file__), "README.md"), encoding="utf-8") as f:
        return f.read()

setup(
    name="agentic_testgen",
    version="0.1.0",
    description="Agentic Auto Test Generation System (modular, multi-language)",
    long_description=readme(),
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your@email.com",
    url="https://github.com/sede-test/UnitTestGenerationSystem",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'agentic-testgen=agentic_testgen.cli:cli',
        ],
    },
    python_requires='>=3.7',
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
