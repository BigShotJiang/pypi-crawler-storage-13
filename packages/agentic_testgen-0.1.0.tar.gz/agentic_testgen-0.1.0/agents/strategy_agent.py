"""
Strategy Agent
Selects optimal retry strategies based on error analysis and attempt history

CURRENT MODEL: gpt-3.5-turbo (single model for all agents)
FUTURE MODEL: GPT-4 - Superior strategic reasoning and planning
    - Best at analyzing complex patterns and making strategic decisions
    - Better at weighing trade-offs between different approaches
    - Cost: $0.03/1K tokens (worth it for critical decision-making)
    - Use medium temperature (0.5) for balanced creativity/consistency
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List
from enum import Enum


class RetryStrategy(Enum):
    """Available retry strategies."""
    SIMPLE_REGENERATE = "simple_regenerate"  # Just regenerate with error feedback
    TARGETED_FIX = "targeted_fix"  # Focus on specific error component
    ALTERNATIVE_APPROACH = "alternative_approach"  # Try completely different test style
    TEMPLATE_BASED = "template_based"  # Use proven template for similar cases
    INCREMENTAL_BUILD = "incremental_build"  # Build test incrementally
    MOCK_HEAVY = "mock_heavy"  # Add more mocks to isolate component
    INTEGRATION_STYLE = "integration_style"  # Reduce mocks, test more integrated
    GIVE_UP = "give_up"  # Stop retrying


class StrategyAgent(BaseAgent):
    """
    Agent that selects optimal retry strategies based on error analysis.
    
    TODO: When implementing multi-model architecture:
    - Switch to GPT-4 for superior strategic reasoning
    - Keep GPT-3.5-turbo as fallback for cost savings
    - Use temperature 0.5 for balanced decision making
    """
    
    def __init__(self):
        super().__init__(name="StrategySelector", model="gpt-3.5-turbo")
        self.system_message = """You are a strategic test generation advisor.
        Based on error patterns and attempt history, you select the most effective
        retry strategy to generate working tests efficiently."""
    
    def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Select optimal retry strategy.
        
        Args:
            context: {
                "error_analysis": dict,  # From ErrorAnalyzerAgent
                "attempt_number": int,
                "error_history": list,
                "source_file_type": str,  # "react", "javascript", etc.
                "previous_strategy": str (optional)
            }
            
        Returns:
            {
                "strategy": str,
                "reasoning": str,
                "prompt_modifications": dict,
                "max_additional_attempts": int,
                "confidence": float
            }
        """
        self.log("Selecting retry strategy...")
        
        error_analysis = context.get("error_analysis")
        attempt = context.get("attempt_number", 1)
        error_history = context.get("error_history", [])
        file_type = context.get("source_file_type", "javascript")
        previous_strategy = context.get("previous_strategy")
        
        # First attempt (no error yet) - use initial generation strategy
        if attempt == 1 and not error_analysis:
            self.log("First attempt - using initial generation strategy")
            return {
                "strategy": RetryStrategy.SIMPLE_REGENERATE.value,
                "reasoning": "Initial test generation with best practices",
                "prompt_modifications": {
                    "focus": "comprehensive coverage",
                    "style": "best practices"
                },
                "max_additional_attempts": 2,
                "confidence": 0.8
            }
        
        # For simple cases with errors, use rule-based selection (faster)
        if attempt <= 2 and error_analysis:
            quick_strategy = self._quick_strategy_selection(
                error_analysis, attempt, error_history, previous_strategy
            )
            if quick_strategy:
                return quick_strategy
        
        # Use LLM for complex decision making
        prompt = self._build_strategy_prompt(
            error_analysis, attempt, error_history, file_type, previous_strategy
        )
        
        llm_response = self._call_llm(prompt, self.system_message, temperature=0.3)
        
        strategy = self._parse_strategy_response(llm_response, attempt)
        
        self.log(f"Selected strategy: {strategy['strategy']} (confidence: {strategy['confidence']})")
        
        return strategy
    
    def _quick_strategy_selection(
        self,
        error_analysis: Dict[str, Any],
        attempt: int,
        error_history: List[Dict],
        previous_strategy: str
    ) -> Dict[str, Any]:
        """Quick rule-based strategy selection for common scenarios."""
        
        # Safety check - should not be called without error analysis
        if not error_analysis:
            return None
        
        category = error_analysis.get("error_category", "UNKNOWN_ERROR")
        severity = error_analysis.get("severity", "MEDIUM")
        
        # First attempt - always simple regenerate with error feedback
        if attempt == 1:
            return {
                "strategy": RetryStrategy.SIMPLE_REGENERATE.value,
                "reasoning": "First retry - provide error feedback to LLM",
                "prompt_modifications": {
                    "add_error_context": True,
                    "emphasize_imports": category == "IMPORT_ERROR",
                    "emphasize_matchers": category == "MATCHER_ERROR"
                },
                "max_additional_attempts": 2,
                "confidence": 0.9
            }
        
        # Import errors - targeted fix
        if category == "IMPORT_ERROR":
            return {
                "strategy": RetryStrategy.TARGETED_FIX.value,
                "reasoning": "Import error requires specific path correction",
                "prompt_modifications": {
                    "critical_import_rules": True,
                    "show_correct_import_example": True,
                    "validate_import_syntax": True
                },
                "max_additional_attempts": 1,
                "confidence": 0.85
            }
        
        # Matcher errors - add setup requirements
        if category == "MATCHER_ERROR":
            return {
                "strategy": RetryStrategy.TARGETED_FIX.value,
                "reasoning": "Matcher error - ensure proper setup and imports",
                "prompt_modifications": {
                    "require_testing_library_import": True,
                    "use_standard_matchers_only": True,
                    "add_setup_instructions": True
                },
                "max_additional_attempts": 1,
                "confidence": 0.85
            }
        
        # Coverage errors - incremental build
        if category == "COVERAGE_ERROR":
            return {
                "strategy": RetryStrategy.INCREMENTAL_BUILD.value,
                "reasoning": "Low coverage - add more test cases incrementally",
                "prompt_modifications": {
                    "request_edge_cases": True,
                    "request_error_scenarios": True,
                    "request_conditional_tests": True
                },
                "max_additional_attempts": 1,
                "confidence": 0.8
            }
        
        # Repeating same error
        if len(error_history) >= 2:
            recent_categories = [e.get("error_category") for e in error_history[-2:]]
            if len(set(recent_categories)) == 1:
                return {
                    "strategy": RetryStrategy.ALTERNATIVE_APPROACH.value,
                    "reasoning": "Same error repeating - need different approach",
                    "prompt_modifications": {
                        "change_test_style": True,
                        "use_different_queries": True,
                        "simplify_assertions": True
                    },
                    "max_additional_attempts": 1,
                    "confidence": 0.75
                }
        
        # Too many attempts
        if attempt >= 3:
            return {
                "strategy": RetryStrategy.GIVE_UP.value,
                "reasoning": "Maximum retry attempts reached",
                "prompt_modifications": {},
                "max_additional_attempts": 0,
                "confidence": 1.0
            }
        
        return None  # Fall back to LLM decision
    
    def _build_strategy_prompt(
        self,
        error_analysis: Dict[str, Any],
        attempt: int,
        error_history: List[Dict],
        file_type: str,
        previous_strategy: str
    ) -> str:
        """Build prompt for LLM strategy selection."""
        
        # Handle first attempt (no error analysis yet)
        if not error_analysis:
            return f"""Select the initial strategy for test generation:

CURRENT SITUATION:
- Attempt Number: {attempt}
- File Type: {file_type}
- First generation attempt (no previous errors)

Recommend the best approach for initial test generation.

Respond in JSON format:
{{
    "strategy": "SIMPLE_REGENERATE",
    "reasoning": "your reasoning",
    "prompt_modifications": {{}},
    "max_additional_attempts": 2,
    "confidence": 0.0-1.0
}}"""
        
        prompt = f"""Select the best retry strategy for test generation:

CURRENT SITUATION:
- Attempt Number: {attempt}
- File Type: {file_type}
- Error Category: {error_analysis.get('error_category', 'UNKNOWN')}
- Error Severity: {error_analysis.get('severity', 'MEDIUM')}
- Root Cause: {error_analysis.get('root_cause', 'Unknown')}
"""
        
        if previous_strategy:
            prompt += f"- Previous Strategy: {previous_strategy}\n"
        
        if error_history:
            prompt += f"\nERROR HISTORY ({len(error_history)} previous attempts):\n"
            for i, err in enumerate(error_history[-3:], 1):
                prompt += f"  {i}. {err.get('error_category')} - {err.get('root_cause', 'Unknown')}\n"
        
        prompt += f"""
AVAILABLE STRATEGIES:
1. SIMPLE_REGENERATE - Regenerate with error feedback
2. TARGETED_FIX - Focus on specific error component
3. ALTERNATIVE_APPROACH - Try completely different test style
4. TEMPLATE_BASED - Use proven template
5. INCREMENTAL_BUILD - Build test step by step
6. MOCK_HEAVY - Add more mocks
7. INTEGRATION_STYLE - Reduce mocks
8. GIVE_UP - Stop trying

Respond in JSON format:
{{
    "strategy": "chosen_strategy",
    "reasoning": "Brief explanation",
    "prompt_modifications": {{
        "key1": "instruction1",
        "key2": "instruction2"
    }},
    "max_additional_attempts": 1,
    "confidence": 0.85
}}
"""
        return prompt
    
    def _parse_strategy_response(self, response: str, attempt: int) -> Dict[str, Any]:
        """Parse LLM strategy response."""
        try:
            strategy = self._parse_json_response(response)
            
            # Validate strategy
            if strategy.get("strategy") not in [s.value for s in RetryStrategy]:
                self.log(f"Invalid strategy from LLM: {strategy.get('strategy')}", "WARNING")
                strategy["strategy"] = RetryStrategy.SIMPLE_REGENERATE.value
            
            # Ensure max attempts is reasonable
            if strategy.get("max_additional_attempts", 0) > 2:
                strategy["max_additional_attempts"] = 2
            
            return strategy
            
        except Exception as e:
            self.log(f"Failed to parse strategy response: {e}", "WARNING")
            
            # Fallback strategy
            return {
                "strategy": RetryStrategy.SIMPLE_REGENERATE.value if attempt < 3 else RetryStrategy.GIVE_UP.value,
                "reasoning": "Fallback strategy due to parsing error",
                "prompt_modifications": {},
                "max_additional_attempts": 1 if attempt < 3 else 0,
                "confidence": 0.5
            }
    
    def get_prompt_enhancements(
        self, 
        strategy: str, 
        modifications: Dict[str, Any],
        error_analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate specific prompt enhancements based on strategy.
        
        Returns:
            {
                "additional_instructions": str,
                "examples_to_include": list,
                "constraints": list,
                "emphasis_points": list
            }
        """
        enhancements = {
            "additional_instructions": "",
            "examples_to_include": [],
            "constraints": [],
            "emphasis_points": []
        }
        
        # Add instructions based on modifications
        if modifications.get("critical_import_rules"):
            enhancements["additional_instructions"] += "\nCRITICAL - Import paths must be relative from __tests__ folder (e.g., '../component')\n"
            enhancements["constraints"].append("Use '../filename' for imports, NOT '../src/filename'")
        
        if modifications.get("require_testing_library_import"):
            enhancements["additional_instructions"] += "\nImport: import '@testing-library/jest-dom';\n"
            enhancements["examples_to_include"].append("import '@testing-library/jest-dom';")
        
        if modifications.get("request_edge_cases"):
            enhancements["additional_instructions"] += "\nInclude tests for edge cases, error scenarios, and boundary conditions.\n"
            enhancements["emphasis_points"].append("Test edge cases thoroughly")
        
        if modifications.get("simplify_assertions"):
            enhancements["constraints"].append("Use simple, standard Jest matchers only")
            enhancements["constraints"].append("Avoid complex custom matchers")
        
        # Add fix recommendations from error analysis
        if error_analysis.get("fix_recommendations"):
            enhancements["emphasis_points"].extend(error_analysis["fix_recommendations"][:3])
        
        if error_analysis.get("quick_fixes"):
            enhancements["examples_to_include"].extend(error_analysis["quick_fixes"][:2])
        
        return enhancements
