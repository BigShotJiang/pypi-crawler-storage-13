"""
Test Generator Agent
Intelligent test code generation with context awareness and adaptive prompting

CURRENT MODEL: gpt-3.5-turbo (single model for all agents)
FUTURE MODEL: Claude 3.5 Sonnet - Superior code generation
    - Excels at writing clean, idiomatic test code
    - Better understanding of React patterns and Jest syntax
    - More reliable at following test structure guidelines
    - Cost: $0.015/1K tokens (half the cost of GPT-4, better code quality)
    - Use temperature 0.7 for creative yet maintainable test generation
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List, Optional
import re
from pathlib import Path


class TestGeneratorAgent(BaseAgent):
    """
    Agent specialized in generating high-quality test code.
    
    TODO: When implementing multi-model architecture:
    - Switch to Claude 3.5 Sonnet for superior code generation
    - Add fallback to GPT-4 for consistency
    - Use higher temperature (0.7) for diverse test approaches
    - Track generation quality metrics per model
    """
    
    def __init__(self):
        super().__init__(name="TestGenerator", model="gpt-3.5-turbo")
        self.system_message = """You are an expert test engineer specializing in Jest and React Testing Library.
        You write clean, comprehensive, and maintainable unit tests.
        You follow best practices and adapt your approach based on feedback."""
    
    def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate test code based on context and strategy.
        
        Args:
            context: {
                "source_code": str,
                "source_file_path": str,
                "file_type": str,  # "react", "javascript"
                "strategy": dict,  # From StrategyAgent
                "error_analysis": dict (optional),  # From ErrorAnalyzerAgent
                "previous_test_code": str (optional),
                "coverage_gaps": list (optional)
            }
            
        Returns:
            {
                "test_code": str,
                "confidence": float,
                "coverage_targets": list,
                "approach": str
            }
        """
        self.log("Generating test code...")
        
        source_code = context.get("source_code", "")
        file_path = context.get("source_file_path", "")
        file_type = context.get("file_type", "javascript")
        strategy = context.get("strategy", {})
        error_analysis = context.get("error_analysis")
        previous_test = context.get("previous_test_code")
        coverage_gaps = context.get("coverage_gaps", [])
        
        # Build adaptive prompt
        prompt = self._build_generation_prompt(
            source_code,
            file_path,
            file_type,
            strategy,
            error_analysis,
            previous_test,
            coverage_gaps
        )
        
        # Generate test code
        test_code = self._call_llm(
            prompt, 
            self.system_message,
            temperature=0.2,
            max_tokens=2500
        )
        
        # Clean and validate generated code
        test_code = self._clean_generated_code(test_code)
        
        confidence = self._estimate_confidence(test_code, strategy)
        
        self.log(f"Generated {len(test_code)} characters of test code (confidence: {confidence})")
        
        return {
            "test_code": test_code,
            "confidence": confidence,
            "coverage_targets": self._extract_coverage_targets(source_code),
            "approach": strategy.get("strategy", "standard")
        }
    
    def _build_generation_prompt(
        self,
        source_code: str,
        file_path: str,
        file_type: str,
        strategy: Dict[str, Any],
        error_analysis: Optional[Dict[str, Any]],
        previous_test: Optional[str],
        coverage_gaps: List[str]
    ) -> str:
        """Build adaptive prompt based on strategy and context."""
        
        # Calculate import path
        path_obj = Path(file_path)
        file_name = path_obj.stem
        import_path = f"../{file_name}"
        
        # Base prompt
        prompt = f"""Generate a comprehensive Jest test file for the following code:

SOURCE FILE: {file_path}
FILE TYPE: {file_type}

SOURCE CODE:
```javascript
{source_code[:2000]}
```

"""
        
        # Add error context if available
        if error_analysis:
            prompt += f"""
PREVIOUS ATTEMPT HAD ERRORS:
Error Category: {error_analysis.get('error_category')}
Root Cause: {error_analysis.get('root_cause')}

FIX RECOMMENDATIONS:
"""
            for i, rec in enumerate(error_analysis.get('fix_recommendations', [])[:3], 1):
                prompt += f"{i}. {rec}\n"
            
            for fix in error_analysis.get('quick_fixes', [])[:2]:
                prompt += f"- {fix}\n"
        
        # Add strategy-specific instructions
        strategy_name = strategy.get("strategy", "simple_regenerate")
        prompt += f"\nSTRATEGY: {strategy_name}\n"
        
        modifications = strategy.get("prompt_modifications", {})
        
        if modifications.get("critical_import_rules") or error_analysis and error_analysis.get("error_category") == "IMPORT_ERROR":
            prompt += f"""
CRITICAL - IMPORT RULES (MUST FOLLOW):
1. Import path MUST be: import ComponentName from '{import_path}';
2. Import is relative from __tests__ folder: '../' goes up to parent directory
3. DO NOT use '../src/{file_name}' or absolute paths
4. Test file location: {path_obj.parent}/__tests__/{path_obj.name}

CORRECT IMPORT EXAMPLE:
```javascript
import {file_name} from '{import_path}';
```
"""
        
        if modifications.get("require_testing_library_import"):
            prompt += """
REQUIRED SETUP:
```javascript
import '@testing-library/jest-dom';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
```
"""
        
        if modifications.get("use_standard_matchers_only"):
            prompt += """
USE ONLY STANDARD JEST MATCHERS:
- .toBe() for primitive values
- .toEqual() for objects/arrays
- .toBeTruthy() / .toBeFalsy()
- .toHaveLength()
- .toContain()
DO NOT use custom matchers like .toBeInTheDocument() unless you've imported jest-dom
"""
        
        if modifications.get("request_edge_cases"):
            prompt += """
INCLUDE COMPREHENSIVE TEST COVERAGE:
1. Happy path scenarios
2. Edge cases (empty inputs, null, undefined)
3. Error scenarios
4. Boundary conditions
5. Different input combinations
"""
        
        # Coverage gaps
        if coverage_gaps:
            prompt += "\nCOVERAGE GAPS TO ADDRESS:\n"
            for gap in coverage_gaps:
                prompt += f"- {gap}\n"
        
        # Previous test context
        if previous_test and strategy_name == "incremental_build":
            prompt += f"""
PREVIOUS TEST (BUILD ON THIS):
```javascript
{previous_test[:800]}
```
Add more test cases to improve coverage.
"""
        
        # Strategy-specific instructions
        if strategy_name == "alternative_approach":
            prompt += """
IMPORTANT: Use a DIFFERENT testing approach than before:
- Try different query methods (getByRole vs getByText vs getByTestId)
- Use different assertion styles
- Simplify or elaborate tests as needed
"""
        
        if strategy_name == "mock_heavy":
            prompt += """
USE EXTENSIVE MOCKING:
- Mock all external dependencies
- Mock API calls and async operations
- Use jest.fn() for callbacks
- Mock complex child components
"""
        
        if strategy_name == "integration_style":
            prompt += """
INTEGRATION TESTING APPROACH:
- Minimize mocking
- Test component interactions
- Test with real child components where possible
- Focus on user-facing behavior
"""
        
        # React-specific instructions
        if file_type == "react":
            prompt += """
REACT TESTING BEST PRACTICES:
1. Use render() from @testing-library/react
2. Use screen queries for finding elements
3. Test user interactions with fireEvent or userEvent
4. Wait for async updates with waitFor()
5. Test component behavior, not implementation
"""
        
        # Final requirements
        prompt += f"""
REQUIREMENTS:
- Generate ONLY the test code, no explanations
- Use describe() blocks for organization
- Include multiple test() or it() blocks
- Use proper assertions with expect()
- Import statement: import ... from '{import_path}';
- Handle async operations properly
- Clean, readable code with good naming

Generate the complete test file now:
"""
        
        return prompt
    
    def _clean_generated_code(self, code: str) -> str:
        """Clean generated code by removing markdown and extra formatting."""
        if not code:
            return code
        
        # Remove markdown code fences
        code = re.sub(r'^```[\w]*\n', '', code, flags=re.MULTILINE)
        code = re.sub(r'\n```$', '', code, flags=re.MULTILINE)
        code = re.sub(r'^```\n', '', code, flags=re.MULTILINE)
        code = re.sub(r'\n```$', '', code, flags=re.MULTILINE)
        
        # Remove any explanation text before the code
        # Look for first import statement
        import_match = re.search(r'^(import\s+)', code, re.MULTILINE)
        if import_match:
            code = code[import_match.start():]
        
        return code.strip()
    
    def _estimate_confidence(self, test_code: str, strategy: Dict[str, Any]) -> float:
        """Estimate confidence in generated test quality."""
        confidence = 0.7  # Base confidence
        
        # Check for essential patterns
        has_describe = 'describe(' in test_code
        has_test = 'test(' in test_code or 'it(' in test_code
        has_expect = 'expect(' in test_code
        has_import = 'import' in test_code
        
        if has_describe and has_test and has_expect and has_import:
            confidence += 0.15
        
        # Count test cases
        test_count = test_code.count('test(') + test_code.count('it(')
        if test_count >= 3:
            confidence += 0.1
        elif test_count >= 5:
            confidence += 0.15
        
        # Strategy confidence
        strategy_confidence = strategy.get("confidence", 0.5)
        confidence = (confidence + strategy_confidence) / 2
        
        # Code length check
        if len(test_code) < 100:
            confidence -= 0.3
        
        return min(max(confidence, 0.1), 0.99)
    
    def _extract_coverage_targets(self, source_code: str) -> List[str]:
        """Extract key functions/components that should be covered."""
        targets = []
        
        # Extract function names
        func_pattern = r'(?:function|const|let|var)\s+(\w+)\s*=?\s*(?:\([^)]*\)|async)'
        functions = re.findall(func_pattern, source_code)
        targets.extend(functions[:5])  # Top 5 functions
        
        # Extract React component name
        component_pattern = r'(?:export\s+default\s+)?(?:function|const)\s+(\w+)\s*=?\s*\([^)]*\)\s*(?:=>)?\s*{'
        components = re.findall(component_pattern, source_code)
        targets.extend(components[:2])  # Top 2 components
        
        return list(set(targets))  # Remove duplicates
    
    def refine_test(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Refine existing test based on specific feedback.
        
        Args:
            context: {
                "current_test": str,
                "refinement_request": str,
                "error_details": dict
            }
        """
        current_test = context.get("current_test", "")
        request = context.get("refinement_request", "")
        error_details = context.get("error_details", {})
        
        prompt = f"""Refine this test code:

CURRENT TEST:
```javascript
{current_test}
```

REFINEMENT REQUEST:
{request}

ERROR DETAILS:
{error_details.get('error_message', 'N/A')}

Provide the complete refined test code:
"""
        
        refined_code = self._call_llm(prompt, self.system_message, temperature=0.2)
        refined_code = self._clean_generated_code(refined_code)
        
        return {
            "test_code": refined_code,
            "confidence": self._estimate_confidence(refined_code, {})
        }
