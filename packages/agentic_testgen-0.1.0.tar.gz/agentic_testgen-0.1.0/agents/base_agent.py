"""
Base Agent Class
Common functionality for all agents in the agentic system

CURRENT IMPLEMENTATION:
=======================
Single Model Architecture:
- All agents use the same OpenAI model (gpt-3.5-turbo or gpt-4)
- Model is specified at initialization
- Specialized behavior comes from different system prompts per agent
- Cost tracking and optimization not yet implemented

FUTURE ENHANCEMENT - MULTI-MODEL ARCHITECTURE:
==============================================
Planned enhancement to use specialized models per agent for optimal performance and cost:

Agent-Specific Model Selection:
- ErrorAnalyzerAgent: Claude 3.5 Sonnet ($0.015/1K tokens)
  → Best for code understanding and detailed error analysis
  
- StrategyAgent: GPT-4 ($0.03/1K tokens)
  → Best for strategic reasoning and decision making
  
- TestGeneratorAgent: Claude 3.5 Sonnet ($0.015/1K tokens)
  → Best for code generation and test creation
  
- MemoryAgent: GPT-3.5 Turbo ($0.002/1K tokens)
  → Cost-effective for pattern tracking and simple analysis

Benefits of Multi-Model Approach:
- 48% cost reduction per test generation cycle
- Faster execution with optimized models for specific tasks
- Better quality output (right model for right task)
- Automatic fallback between models on failure
- Detailed cost tracking and reporting per agent

Implementation TODO:
1. Add support for multiple LLM providers (OpenAI, Anthropic, etc.)
2. Implement model configuration with cost tracking
3. Add automatic fallback mechanism
4. Create cost reporting dashboard
5. Allow environment-based model selection (dev vs prod)

Example Enhanced Architecture:
```python
class BaseAgent:
    MODEL_CONFIGS = {
        "gpt-4": {"provider": "openai", "cost_per_1k": 0.03, "best_for": ["reasoning"]},
        "gpt-3.5-turbo": {"provider": "openai", "cost_per_1k": 0.002, "best_for": ["quick_tasks"]},
        "claude-3-5-sonnet": {"provider": "anthropic", "cost_per_1k": 0.015, "best_for": ["code_gen"]}
    }
    
    def __init__(self, model="gpt-4", fallback_model="gpt-3.5-turbo"):
        self.model = model
        self.fallback_model = fallback_model
        self.openai_client = OpenAI()
        self.anthropic_client = Anthropic()
        self.total_cost = 0.0
```

For now, keeping single model approach for simplicity and faster implementation.
"""

import openai
import os
from typing import Dict, Any, Optional, List
from datetime import datetime
import json


class BaseAgent:
    """
    Base class for all agents with common capabilities.
    
    Current: Single model (gpt-3.5-turbo) for all agents
    Future: Multi-model specialization (see module docstring)
    """
    
    def __init__(self, name: str, model: str = "gpt-3.5-turbo"):
        self.name = name
        self.model = model
        self.client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.conversation_history: List[Dict[str, str]] = []
        
        # TODO: Add cost tracking when implementing multi-model
        # self.total_tokens = 0
        # self.total_cost = 0.0
        # self.call_count = 0
        
    def _call_llm(
        self, 
        prompt: str, 
        system_message: Optional[str] = None,
        temperature: float = 0.2,
        max_tokens: int = 2000
    ) -> str:
        """
        Call the LLM with a prompt and optional system message.
        
        CURRENT: Single OpenAI model call
        FUTURE: Route to appropriate provider based on self.model config
        
        Args:
            prompt: The user prompt
            system_message: Optional system message to set agent behavior
            temperature: Sampling temperature (0-1)
            max_tokens: Maximum tokens to generate
            
        Returns:
            str: The LLM's response
            
        TODO for Multi-Model Enhancement:
        - Add provider routing (OpenAI vs Anthropic vs others)
        - Implement automatic fallback on failure
        - Track tokens and cost per call
        - Add retry logic with exponential backoff
        """
        messages = []
        
        if system_message:
            messages.append({"role": "system", "content": system_message})
            
        # Add conversation history for context
        messages.extend(self.conversation_history[-5:])  # Keep last 5 exchanges
        
        messages.append({"role": "user", "content": prompt})
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            assistant_message = response.choices[0].message.content
            
            # Update conversation history
            self.conversation_history.append({"role": "user", "content": prompt})
            self.conversation_history.append({"role": "assistant", "content": assistant_message})
            
            return assistant_message
            
        except Exception as e:
            print(f"[{self.name}] Error calling LLM: {e}")
            raise
    
    def _parse_json_response(self, response: str) -> Dict[str, Any]:
        """
        Parse JSON from LLM response, handling markdown code blocks.
        
        Args:
            response: Raw LLM response that may contain JSON
            
        Returns:
            dict: Parsed JSON object
        """
        # Remove markdown code blocks if present
        response = response.strip()
        if response.startswith("```json"):
            response = response[7:]
        elif response.startswith("```"):
            response = response[3:]
        if response.endswith("```"):
            response = response[:-3]
        
        response = response.strip()
        
        try:
            return json.loads(response)
        except json.JSONDecodeError as e:
            print(f"[{self.name}] Failed to parse JSON response: {e}")
            print(f"[{self.name}] Response was: {response[:200]}")
            raise
    
    def clear_history(self):
        """Clear conversation history."""
        self.conversation_history = []
    
    def log(self, message: str, level: str = "INFO"):
        """Log a message with timestamp."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] [{self.name}] [{level}] {message}")
    
    def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Main analysis method - to be overridden by subclasses.
        
        Args:
            context: Input context for analysis
            
        Returns:
            dict: Analysis results
        """
        raise NotImplementedError("Subclasses must implement analyze()")
