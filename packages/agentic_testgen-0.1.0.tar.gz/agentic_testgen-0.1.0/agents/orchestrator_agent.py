"""
Orchestrator Agent
Coordinates all agents and manages the intelligent test generation workflow

CURRENT ARCHITECTURE: Single Model (gpt-3.5-turbo)
======================================================
All agents use the same model with different system prompts.

FUTURE ARCHITECTURE: Multi-Model Specialization
======================================================
When implementing multi-model support, each agent will use optimal model:

Agent Coordination Flow:
1. Memory Agent (GPT-3.5 Turbo) - Retrieve historical patterns
2. Test Generator (Claude 3.5 Sonnet) - Generate initial test
3. [Execute test]
4. Error Analyzer (Claude 3.5 Sonnet) - Analyze failure
5. Strategy Agent (GPT-4) - Select retry strategy
6. Test Generator (Claude 3.5 Sonnet) - Regenerate with strategy
7. Memory Agent (GPT-3.5 Turbo) - Record attempt

Cost Comparison per Test Generation:
- Current (all GPT-3.5): ~$0.05-0.10
- Future Multi-Model: ~$0.03-0.06 (40% reduction)
- Future with GPT-4 everywhere: ~$0.15-0.30 (3x more expensive)

Benefits of Multi-Model:
- 40-50% cost reduction
- Better quality output per specialized task
- Faster execution (optimized models)
- Automatic fallback on failure
- Detailed cost tracking per agent

TODO: Add get_total_cost_report() method for transparency
"""

from .base_agent import BaseAgent
from .error_analyzer_agent import ErrorAnalyzerAgent
from .strategy_agent import StrategyAgent
from .test_generator_agent import TestGeneratorAgent
from .memory_agent import MemoryAgent

from typing import Dict, Any, List, Optional
import time
from datetime import datetime


class OrchestratorAgent(BaseAgent):
    """
    Master agent that coordinates all other agents.
    
    TODO: When implementing multi-model architecture:
    - Add cost aggregation across all agents
    - Implement parallel agent calls where possible
    - Add circuit breaker for expensive model failures
    - Create cost reporting dashboard
    """
    
    def __init__(self, max_attempts: int = 3, min_coverage: float = 70.0):
        super().__init__(name="Orchestrator", model="gpt-3.5-turbo")
        
        # Initialize all sub-agents
        # FUTURE: Each will use specialized model
        self.error_analyzer = ErrorAnalyzerAgent()      # → Claude 3.5 Sonnet
        self.strategy_selector = StrategyAgent()         # → GPT-4
        self.test_generator = TestGeneratorAgent()       # → Claude 3.5 Sonnet
        self.memory = MemoryAgent()                      # → GPT-3.5 Turbo
        
        self.max_attempts = max_attempts
        self.min_coverage = min_coverage
        
        self.log("Agentic test generation system initialized")
    
    def generate_test_with_intelligence(
        self,
        source_code: str,
        file_path: str,
        file_type: str = "javascript"
    ) -> Dict[str, Any]:
        """
        Main entry point for intelligent test generation.
        
        Args:
            source_code: The source code to test
            file_path: Path to the source file
            file_type: Type of file ("react", "javascript", etc.)
            
        Returns:
            {
                "success": bool,
                "test_code": str,
                "attempts": int,
                "final_strategy": str,
                "coverage": dict,
                "error_history": list,
                "insights": dict
            }
        """
        self.log(f"Starting intelligent test generation for {file_path}")
        start_time = time.time()
        
        # Get historical context
        historical_context = self.memory.get_context_for_generation(file_path, file_type)
        self.log(f"Historical context: {historical_context.get('previous_attempts', 0)} previous attempts")
        
        # Initialize tracking
        attempt_number = 0
        error_history = []
        test_code = None
        success = False
        coverage_data = None
        current_strategy = None
        
        # Main generation loop
        while attempt_number < self.max_attempts:
            attempt_number += 1
            self.log(f"=== Attempt {attempt_number}/{self.max_attempts} ===")
            
            # Step 1: Analyze previous error (if any)
            error_analysis = None
            if error_history:
                self.log("Analyzing previous error...")
                error_analysis = self.error_analyzer.analyze({
                    "error_message": error_history[-1].get("error_message", ""),
                    "test_code": test_code,
                    "source_code": source_code,
                    "attempt_number": attempt_number,
                    "coverage_data": coverage_data
                })
                
                # Check error patterns
                pattern_analysis = self.error_analyzer.get_error_history_analysis(error_history)
                if pattern_analysis.get("should_escalate"):
                    self.log(f"Pattern detected: {pattern_analysis.get('pattern')} - {pattern_analysis.get('recommendation')}", "WARNING")
            
            # Step 2: Select strategy
            self.log("Selecting retry strategy...")
            strategy = self.strategy_selector.analyze({
                "error_analysis": error_analysis,
                "attempt_number": attempt_number,
                "error_history": error_history,
                "source_file_type": file_type,
                "previous_strategy": current_strategy
            })
            
            current_strategy = strategy.get("strategy")
            self.log(f"Strategy selected: {current_strategy} (confidence: {strategy.get('confidence')})")
            
            # Check if we should give up
            if current_strategy == "give_up":
                self.log("Strategy recommends stopping - maximum attempts reached", "WARNING")
                break
            
            # Step 3: Generate test code
            self.log("Generating test code...")
            generation_result = self.test_generator.analyze({
                "source_code": source_code,
                "source_file_path": file_path,
                "file_type": file_type,
                "strategy": strategy,
                "error_analysis": error_analysis,
                "previous_test_code": test_code,
                "coverage_gaps": self._identify_coverage_gaps(coverage_data) if coverage_data else []
            })
            
            test_code = generation_result.get("test_code")
            self.log(f"Test code generated (confidence: {generation_result.get('confidence')})")
            
            # Step 4: Validate test code (basic validation)
            validation_result = self._validate_test_code(test_code)
            if not validation_result["valid"]:
                self.log(f"Test validation failed: {validation_result['error']}", "WARNING")
                
                error_history.append({
                    "attempt": attempt_number,
                    "error_category": "VALIDATION_ERROR",
                    "error_message": validation_result["error"],
                    "strategy": current_strategy
                })
                
                # Record failed attempt
                self.memory.record_attempt({
                    "file_path": file_path,
                    "file_type": file_type,
                    "attempt_number": attempt_number,
                    "strategy": current_strategy,
                    "error_category": "VALIDATION_ERROR",
                    "success": False,
                    "duration": time.time() - start_time
                })
                
                continue
            
            # At this point, test code is generated and passes basic validation
            # The caller (pr_test_generator.py) will execute the test and provide results
            success = True
            break
        
        # Calculate duration
        duration = time.time() - start_time
        
        # Get final insights
        insights = self._generate_final_insights(
            attempt_number,
            error_history,
            current_strategy,
            success
        )
        
        # Record final result (caller will update with execution results)
        result = {
            "success": success,
            "test_code": test_code,
            "attempts": attempt_number,
            "final_strategy": current_strategy,
            "coverage": coverage_data,
            "error_history": error_history,
            "insights": insights,
            "duration": duration
        }
        
        self.log(f"Generation completed: {'SUCCESS' if success else 'FAILED'} after {attempt_number} attempts ({duration:.2f}s)")
        
        return result
    
    def process_execution_result(
        self,
        generation_result: Dict[str, Any],
        execution_result: Dict[str, Any],
        file_path: str,
        file_type: str
    ) -> Dict[str, Any]:
        """
        Process test execution results and decide whether to retry.
        
        Args:
            generation_result: Result from generate_test_with_intelligence()
            execution_result: {
                "passed": bool,
                "error": str (optional),
                "coverage": dict (optional)
            }
            file_path: Path to source file
            file_type: Type of file
            
        Returns:
            Updated result with retry decision
        """
        attempt_number = generation_result["attempts"]
        test_code = generation_result["test_code"]
        error_history = generation_result["error_history"]
        
        # Update with execution results
        passed = execution_result.get("passed", False)
        error = execution_result.get("error")
        coverage = execution_result.get("coverage")
        
        if passed:
            # Check coverage
            if coverage:
                avg_coverage = (
                    coverage.get("statements", 0) + 
                    coverage.get("branches", 0) + 
                    coverage.get("functions", 0)
                ) / 3
                
                if avg_coverage < self.min_coverage and attempt_number < self.max_attempts:
                    self.log(f"Coverage {avg_coverage:.1f}% below minimum {self.min_coverage}%", "WARNING")
                    
                    # Analyze coverage gap as an error
                    error_analysis = self.error_analyzer.analyze({
                        "error_message": f"Coverage {avg_coverage:.1f}% is below minimum {self.min_coverage}%",
                        "test_code": test_code,
                        "source_code": "",  # Not needed for coverage analysis
                        "attempt_number": attempt_number,
                        "coverage_data": coverage
                    })
                    
                    error_history.append({
                        "attempt": attempt_number,
                        "error_category": "COVERAGE_ERROR",
                        "error_message": f"Coverage {avg_coverage:.1f}% below minimum",
                        "error_analysis": error_analysis
                    })
                    
                    # Record attempt
                    self.memory.record_attempt({
                        "file_path": file_path,
                        "file_type": file_type,
                        "attempt_number": attempt_number,
                        "strategy": generation_result["final_strategy"],
                        "error_category": "COVERAGE_ERROR",
                        "success": False,
                        "coverage": coverage,
                        "duration": generation_result["duration"]
                    })
                    
                    # Should retry
                    generation_result["should_retry"] = True
                    generation_result["coverage"] = coverage
                    return generation_result
            
            # Success!
            self.log("✓ Test execution successful!", "SUCCESS")
            
            # Record successful attempt
            self.memory.record_attempt({
                "file_path": file_path,
                "file_type": file_type,
                "attempt_number": attempt_number,
                "strategy": generation_result["final_strategy"],
                "success": True,
                "coverage": coverage,
                "duration": generation_result["duration"]
            })
            
            generation_result["success"] = True
            generation_result["coverage"] = coverage
            generation_result["should_retry"] = False
            return generation_result
        
        else:
            # Test failed
            self.log(f"✗ Test execution failed: {error[:100]}", "ERROR")
            
            # Analyze the execution error
            error_analysis = self.error_analyzer.analyze({
                "error_message": error or "Unknown execution error",
                "test_code": test_code,
                "source_code": "",
                "attempt_number": attempt_number,
                "coverage_data": coverage
            })
            
            error_history.append({
                "attempt": attempt_number,
                "error_category": error_analysis.get("error_category"),
                "error_message": error,
                "error_analysis": error_analysis
            })
            
            # Record failed attempt
            self.memory.record_attempt({
                "file_path": file_path,
                "file_type": file_type,
                "attempt_number": attempt_number,
                "strategy": generation_result["final_strategy"],
                "error_category": error_analysis.get("error_category"),
                "success": False,
                "coverage": coverage,
                "duration": generation_result["duration"]
            })
            
            # Should we retry?
            if attempt_number < self.max_attempts:
                self.log(f"Will retry (attempt {attempt_number + 1}/{self.max_attempts})")
                generation_result["should_retry"] = True
                generation_result["error_history"] = error_history
                return generation_result
            else:
                self.log("Maximum attempts reached - giving up", "WARNING")
                generation_result["success"] = False
                generation_result["should_retry"] = False
                return generation_result
    
    def _validate_test_code(self, test_code: str) -> Dict[str, Any]:
        """Basic validation of generated test code."""
        if not test_code or len(test_code) < 50:
            return {
                "valid": False,
                "error": "Test code too short or empty"
            }
        
        required_patterns = ['describe', 'expect']
        test_pattern = 'test(' in test_code or 'it(' in test_code
        
        missing = []
        for pattern in required_patterns:
            if pattern not in test_code:
                missing.append(pattern)
        
        if not test_pattern:
            missing.append('test() or it()')
        
        if missing:
            return {
                "valid": False,
                "error": f"Missing required patterns: {', '.join(missing)}"
            }
        
        return {"valid": True}
    
    def _identify_coverage_gaps(self, coverage_data: Dict[str, Any]) -> List[str]:
        """Identify specific coverage gaps to address."""
        gaps = []
        
        if not coverage_data:
            return gaps
        
        if coverage_data.get("statements", 100) < 80:
            gaps.append("Increase statement coverage - test more code paths")
        
        if coverage_data.get("branches", 100) < 70:
            gaps.append("Increase branch coverage - test conditional logic (if/else, switch)")
        
        if coverage_data.get("functions", 100) < 80:
            gaps.append("Increase function coverage - call more functions in tests")
        
        return gaps
    
    def _generate_final_insights(
        self,
        attempts: int,
        error_history: List[Dict],
        final_strategy: str,
        success: bool
    ) -> Dict[str, Any]:
        """Generate insights about the generation process."""
        insights = {
            "efficiency": "high" if attempts == 1 else "medium" if attempts == 2 else "low",
            "total_attempts": attempts,
            "unique_errors": len(set(e.get("error_category") for e in error_history)),
            "final_strategy": final_strategy,
            "outcome": "success" if success else "failed"
        }
        
        if error_history:
            insights["error_categories"] = [e.get("error_category") for e in error_history]
        
        return insights
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get status of the agentic system."""
        general_insights = self.memory.analyze({"query_type": "general_insights"})
        
        return {
            "status": "operational",
            "agents": {
                "error_analyzer": "active",
                "strategy_selector": "active",
                "test_generator": "active",
                "memory": "active"
            },
            "configuration": {
                "max_attempts": self.max_attempts,
                "min_coverage": self.min_coverage
            },
            "historical_performance": general_insights
        }
