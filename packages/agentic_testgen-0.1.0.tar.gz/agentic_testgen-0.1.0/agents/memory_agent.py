"""
Memory Agent
Tracks patterns, learns from successes/failures, and provides historical context

CURRENT MODEL: gpt-3.5-turbo (single model for all agents)
FUTURE MODEL: GPT-3.5 Turbo - Cost-effective pattern analysis
    - Sufficient for pattern matching and historical analysis
    - Fast and cheap for frequent memory operations
    - Cost: $0.002/1K tokens (75x cheaper than GPT-4!)
    - Use very low temperature (0.2) for consistent pattern recognition
    
Note: This agent does mostly data operations, LLM calls are minimal,
so keeping the cheapest model makes sense even in multi-model setup.
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List, Optional
import json
import os
from datetime import datetime
from pathlib import Path


class MemoryAgent(BaseAgent):
    """
    Agent that maintains memory of past attempts and learns patterns.
    
    TODO: When implementing multi-model architecture:
    - Keep GPT-3.5 Turbo as primary (cost-effective for pattern analysis)
    - Add GPT-4 fallback only for complex pattern inference
    - Use temperature 0.2 for consistent pattern recognition
    - Track memory access patterns for optimization
    """
    
    def __init__(self, memory_file: str = "src/logs/agent_memory.json"):
        super().__init__(name="Memory", model="gpt-3.5-turbo")
        self.memory_file = memory_file
        self.memory = self._load_memory()
        self.system_message = """You are a pattern recognition expert.
        You analyze historical data to identify trends, successful patterns, 
        and recurring issues in test generation."""
    
    def _load_memory(self) -> Dict[str, Any]:
        """Load memory from disk."""
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                self.log(f"Failed to load memory: {e}", "WARNING")
        
        # Initialize empty memory structure
        return {
            "test_attempts": [],
            "success_patterns": [],
            "failure_patterns": [],
            "error_statistics": {},
            "strategy_effectiveness": {},
            "file_type_insights": {},
            "last_updated": datetime.now().isoformat()
        }
    
    def _save_memory(self):
        """Save memory to disk."""
        try:
            os.makedirs(os.path.dirname(self.memory_file), exist_ok=True)
            self.memory["last_updated"] = datetime.now().isoformat()
            
            with open(self.memory_file, 'w') as f:
                json.dump(self.memory, f, indent=2)
            
            self.log("Memory saved successfully")
        except Exception as e:
            self.log(f"Failed to save memory: {e}", "ERROR")
    
    def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Retrieve relevant historical context.
        
        Args:
            context: {
                "query_type": str,  # "similar_errors", "similar_files", "strategy_history"
                "error_category": str (optional),
                "file_type": str (optional),
                "strategy": str (optional)
            }
            
        Returns:
            Historical insights and recommendations
        """
        query_type = context.get("query_type")
        
        if query_type == "similar_errors":
            return self._find_similar_errors(context.get("error_category"))
        
        elif query_type == "similar_files":
            return self._find_similar_files(context.get("file_type"))
        
        elif query_type == "strategy_history":
            return self._get_strategy_effectiveness(context.get("strategy"))
        
        elif query_type == "general_insights":
            return self._get_general_insights()
        
        return {"insights": [], "recommendations": []}
    
    def record_attempt(self, attempt_data: Dict[str, Any]):
        """
        Record a test generation attempt.
        
        Args:
            attempt_data: {
                "file_path": str,
                "file_type": str,
                "attempt_number": int,
                "strategy": str,
                "error_category": str (if failed),
                "success": bool,
                "coverage": dict (if available),
                "duration": float,
                "timestamp": str
            }
        """
        attempt_data["timestamp"] = datetime.now().isoformat()
        
        # Add to attempts history
        self.memory["test_attempts"].append(attempt_data)
        
        # Keep only last 100 attempts to prevent memory bloat
        if len(self.memory["test_attempts"]) > 100:
            self.memory["test_attempts"] = self.memory["test_attempts"][-100:]
        
        # Update statistics
        self._update_statistics(attempt_data)
        
        # Update patterns
        if attempt_data.get("success"):
            self._record_success_pattern(attempt_data)
        else:
            self._record_failure_pattern(attempt_data)
        
        self._save_memory()
        self.log(f"Recorded attempt for {attempt_data.get('file_path')}")
    
    def _update_statistics(self, attempt: Dict[str, Any]):
        """Update error and strategy statistics."""
        
        # Error statistics
        if not attempt.get("success"):
            error_cat = attempt.get("error_category", "UNKNOWN")
            if error_cat not in self.memory["error_statistics"]:
                self.memory["error_statistics"][error_cat] = {
                    "count": 0,
                    "resolved": 0,
                    "strategies_used": {}
                }
            
            self.memory["error_statistics"][error_cat]["count"] += 1
        
        # Strategy effectiveness
        strategy = attempt.get("strategy", "unknown")
        if strategy not in self.memory["strategy_effectiveness"]:
            self.memory["strategy_effectiveness"][strategy] = {
                "attempts": 0,
                "successes": 0,
                "failures": 0,
                "avg_attempt_number": 0
            }
        
        stats = self.memory["strategy_effectiveness"][strategy]
        stats["attempts"] += 1
        
        if attempt.get("success"):
            stats["successes"] += 1
        else:
            stats["failures"] += 1
        
        # Update average attempt number
        attempt_num = attempt.get("attempt_number", 1)
        stats["avg_attempt_number"] = (
            (stats["avg_attempt_number"] * (stats["attempts"] - 1) + attempt_num) 
            / stats["attempts"]
        )
        
        # File type insights
        file_type = attempt.get("file_type", "unknown")
        if file_type not in self.memory["file_type_insights"]:
            self.memory["file_type_insights"][file_type] = {
                "total": 0,
                "successful": 0,
                "common_errors": {}
            }
        
        self.memory["file_type_insights"][file_type]["total"] += 1
        if attempt.get("success"):
            self.memory["file_type_insights"][file_type]["successful"] += 1
    
    def _record_success_pattern(self, attempt: Dict[str, Any]):
        """Record patterns from successful attempts."""
        pattern = {
            "file_type": attempt.get("file_type"),
            "strategy": attempt.get("strategy"),
            "attempt_number": attempt.get("attempt_number"),
            "coverage": attempt.get("coverage"),
            "timestamp": attempt.get("timestamp")
        }
        
        self.memory["success_patterns"].append(pattern)
        
        # Keep only last 50 success patterns
        if len(self.memory["success_patterns"]) > 50:
            self.memory["success_patterns"] = self.memory["success_patterns"][-50:]
    
    def _record_failure_pattern(self, attempt: Dict[str, Any]):
        """Record patterns from failed attempts."""
        pattern = {
            "file_type": attempt.get("file_type"),
            "error_category": attempt.get("error_category"),
            "strategy": attempt.get("strategy"),
            "attempt_number": attempt.get("attempt_number"),
            "timestamp": attempt.get("timestamp")
        }
        
        self.memory["failure_patterns"].append(pattern)
        
        # Keep only last 50 failure patterns
        if len(self.memory["failure_patterns"]) > 50:
            self.memory["failure_patterns"] = self.memory["failure_patterns"][-50:]
    
    def _find_similar_errors(self, error_category: str) -> Dict[str, Any]:
        """Find similar error patterns and their resolutions."""
        if not error_category:
            return {"insights": [], "recommendations": []}
        
        insights = []
        recommendations = []
        
        # Get statistics for this error
        if error_category in self.memory["error_statistics"]:
            stats = self.memory["error_statistics"][error_category]
            insights.append(
                f"This error has occurred {stats['count']} times in history"
            )
            
            # Find successful strategies for this error
            successful_strategies = []
            for attempt in self.memory["test_attempts"]:
                if (attempt.get("error_category") == error_category and 
                    attempt.get("success")):
                    successful_strategies.append(attempt.get("strategy"))
            
            if successful_strategies:
                from collections import Counter
                most_common = Counter(successful_strategies).most_common(2)
                recommendations.append(
                    f"Most successful strategies: {', '.join([s[0] for s in most_common])}"
                )
        
        return {
            "insights": insights,
            "recommendations": recommendations,
            "similar_count": self.memory["error_statistics"].get(error_category, {}).get("count", 0)
        }
    
    def _find_similar_files(self, file_type: str) -> Dict[str, Any]:
        """Find insights from similar file types."""
        if not file_type or file_type not in self.memory["file_type_insights"]:
            return {"insights": [], "recommendations": []}
        
        insights_data = self.memory["file_type_insights"][file_type]
        success_rate = (
            insights_data["successful"] / insights_data["total"] 
            if insights_data["total"] > 0 else 0
        )
        
        insights = [
            f"File type '{file_type}': {success_rate:.1%} success rate across {insights_data['total']} attempts"
        ]
        
        recommendations = []
        if success_rate < 0.5:
            recommendations.append(
                f"File type '{file_type}' has low success rate - may need specialized approach"
            )
        
        return {
            "insights": insights,
            "recommendations": recommendations,
            "success_rate": success_rate
        }
    
    def _get_strategy_effectiveness(self, strategy: str) -> Dict[str, Any]:
        """Get effectiveness data for a strategy."""
        if not strategy or strategy not in self.memory["strategy_effectiveness"]:
            return {"effectiveness": 0, "insights": []}
        
        stats = self.memory["strategy_effectiveness"][strategy]
        effectiveness = (
            stats["successes"] / stats["attempts"] 
            if stats["attempts"] > 0 else 0
        )
        
        insights = [
            f"Strategy '{strategy}' has {effectiveness:.1%} success rate",
            f"Average attempt number: {stats['avg_attempt_number']:.1f}"
        ]
        
        return {
            "effectiveness": effectiveness,
            "insights": insights,
            "statistics": stats
        }
    
    def _get_general_insights(self) -> Dict[str, Any]:
        """Get general insights from all historical data."""
        total_attempts = len(self.memory["test_attempts"])
        successful = sum(1 for a in self.memory["test_attempts"] if a.get("success"))
        
        insights = []
        recommendations = []
        
        if total_attempts > 0:
            success_rate = successful / total_attempts
            insights.append(f"Overall success rate: {success_rate:.1%} ({successful}/{total_attempts})")
        
        # Most common errors
        if self.memory["error_statistics"]:
            top_errors = sorted(
                self.memory["error_statistics"].items(),
                key=lambda x: x[1]["count"],
                reverse=True
            )[:3]
            
            insights.append("Most common errors:")
            for error, stats in top_errors:
                insights.append(f"  - {error}: {stats['count']} occurrences")
        
        # Best performing strategies
        if self.memory["strategy_effectiveness"]:
            best_strategies = sorted(
                self.memory["strategy_effectiveness"].items(),
                key=lambda x: x[1]["successes"] / x[1]["attempts"] if x[1]["attempts"] > 0 else 0,
                reverse=True
            )[:3]
            
            recommendations.append("Most effective strategies:")
            for strategy, stats in best_strategies:
                if stats["attempts"] > 2:  # Only include strategies with enough data
                    effectiveness = stats["successes"] / stats["attempts"]
                    recommendations.append(f"  - {strategy}: {effectiveness:.1%}")
        
        return {
            "insights": insights,
            "recommendations": recommendations,
            "total_attempts": total_attempts,
            "success_rate": successful / total_attempts if total_attempts > 0 else 0
        }
    
    def get_context_for_generation(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """
        Get relevant historical context for test generation.
        
        Returns insights that can guide the generation process.
        """
        context = {
            "file_type_insights": self._find_similar_files(file_type),
            "general_insights": self._get_general_insights(),
            "recommendations": []
        }
        
        # Check if we've seen this exact file before
        previous_attempts = [
            a for a in self.memory["test_attempts"]
            if a.get("file_path") == file_path
        ]
        
        if previous_attempts:
            context["previous_attempts"] = len(previous_attempts)
            successful_prev = [a for a in previous_attempts if a.get("success")]
            if successful_prev:
                context["recommendations"].append(
                    f"File was successfully tested before using strategy: {successful_prev[-1].get('strategy')}"
                )
        
        return context
