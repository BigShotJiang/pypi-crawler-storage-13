"""
Error Analyzer Agent
Analyzes test failures and categorizes errors for targeted retry strategies

CURRENT MODEL: gpt-3.5-turbo (single model for all agents)
FUTURE MODEL: Claude 3.5 Sonnet - Superior code understanding and error analysis
    - Better at understanding complex error traces
    - More accurate error categorization
    - Cost: $0.015/1K tokens (cheaper than GPT-4, better than GPT-3.5 for code)
"""

from .base_agent import BaseAgent
from typing import Dict, Any, List
import re


class ErrorAnalyzerAgent(BaseAgent):
    """
    Agent specialized in analyzing test failures and extracting actionable insights.
    
    TODO: When implementing multi-model architecture:
    - Switch to Claude 3.5 Sonnet for superior error analysis
    - Add fallback to GPT-4 if Claude fails
    - Use low temperature (0.3) for consistent categorization
    """
    
    ERROR_CATEGORIES = {
        "IMPORT_ERROR": ["Cannot find module", "Module not found", "import", "require"],
        "SYNTAX_ERROR": ["SyntaxError", "Unexpected token", "Parse error"],
        "ASSERTION_ERROR": ["Expected", "Received", "toBe", "toEqual", "AssertionError"],
        "TIMEOUT_ERROR": ["Timeout", "exceeded", "took too long"],
        "MATCHER_ERROR": ["not a function", "is not defined", "matcher"],
        "COVERAGE_ERROR": ["coverage", "below minimum", "insufficient"],
        "SETUP_ERROR": ["beforeEach", "afterEach", "setup", "teardown"],
        "ASYNC_ERROR": ["Promise", "async", "await", "then", "catch"],
        "MOCK_ERROR": ["mock", "jest.fn", "mockImplementation"],
        "DOM_ERROR": ["document", "window", "DOM", "HTMLElement"],
    }
    
    def __init__(self):
        super().__init__(name="ErrorAnalyzer", model="gpt-3.5-turbo")
        self.system_message = """You are an expert test error analyzer. 
        Your job is to analyze test failures and extract:
        1. Root cause of the failure
        2. Specific code elements involved
        3. Actionable fix recommendations
        
        Provide concise, technical analysis."""
    
    def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze test error and provide categorization and insights.
        
        Args:
            context: {
                "error_message": str,
                "test_code": str (optional),
                "source_code": str (optional),
                "attempt_number": int,
                "coverage_data": dict (optional)
            }
            
        Returns:
            {
                "error_category": str,
                "severity": str (HIGH/MEDIUM/LOW),
                "root_cause": str,
                "affected_components": list,
                "fix_recommendations": list,
                "retry_suggested": bool,
                "confidence": float
            }
        """
        self.log("Analyzing test error...")
        
        error_message = context.get("error_message", "")
        test_code = context.get("test_code", "")
        source_code = context.get("source_code", "")
        attempt = context.get("attempt_number", 1)
        coverage = context.get("coverage_data")
        
        # Quick category classification
        category = self._categorize_error(error_message)
        
        # Use LLM for deeper analysis
        prompt = self._build_analysis_prompt(
            error_message, test_code, source_code, category, attempt, coverage
        )
        
        llm_response = self._call_llm(prompt, self.system_message, temperature=0.1)
        
        # Parse structured response
        analysis = self._parse_analysis_response(llm_response, category)
        
        # Add quick fixes based on patterns
        analysis["quick_fixes"] = self._get_quick_fixes(category, error_message)
        
        self.log(f"Error categorized as: {analysis['error_category']} (severity: {analysis['severity']})")
        
        return analysis
    
    def _categorize_error(self, error_message: str) -> str:
        """Quickly categorize error based on keywords."""
        error_lower = error_message.lower()
        
        for category, keywords in self.ERROR_CATEGORIES.items():
            if any(keyword.lower() in error_lower for keyword in keywords):
                return category
        
        return "UNKNOWN_ERROR"
    
    def _build_analysis_prompt(
        self, 
        error_msg: str, 
        test_code: str, 
        source_code: str,
        category: str,
        attempt: int,
        coverage: Dict
    ) -> str:
        """Build comprehensive analysis prompt."""
        
        prompt = f"""Analyze this test failure (Attempt #{attempt}):

ERROR MESSAGE:
{error_msg[:1000]}

ERROR CATEGORY: {category}
"""
        
        if test_code:
            prompt += f"\nGENERATED TEST CODE:\n```javascript\n{test_code[:800]}\n```\n"
        
        if source_code:
            prompt += f"\nSOURCE CODE:\n```javascript\n{source_code[:800]}\n```\n"
        
        if coverage:
            prompt += f"\nCOVERAGE DATA:\n{coverage}\n"
        
        prompt += """
Provide analysis in this JSON format:
{
    "root_cause": "Brief explanation of what went wrong",
    "severity": "HIGH|MEDIUM|LOW",
    "affected_components": ["component1", "component2"],
    "fix_recommendations": [
        "Specific action 1",
        "Specific action 2"
    ],
    "retry_suggested": true/false,
    "confidence": 0.95
}
"""
        return prompt
    
    def _parse_analysis_response(self, response: str, category: str) -> Dict[str, Any]:
        """Parse LLM analysis response."""
        try:
            analysis = self._parse_json_response(response)
            analysis["error_category"] = category
            return analysis
        except Exception as e:
            self.log(f"Failed to parse LLM response, using fallback: {e}", "WARNING")
            
            # Fallback analysis
            return {
                "error_category": category,
                "severity": "MEDIUM",
                "root_cause": "Unable to determine specific root cause",
                "affected_components": [],
                "fix_recommendations": ["Review error message and adjust test code"],
                "retry_suggested": True,
                "confidence": 0.5
            }
    
    def _get_quick_fixes(self, category: str, error_message: str) -> List[str]:
        """Provide quick fixes based on error category."""
        
        quick_fixes = {
            "IMPORT_ERROR": [
                "Verify import path is relative from __tests__ folder (e.g., '../component')",
                "Check that the module export matches the import statement",
                "Ensure file extension is omitted in import path"
            ],
            "MATCHER_ERROR": [
                "Import jest-dom matchers: import '@testing-library/jest-dom'",
                "Verify jest.setup.js is configured in jest.config.js",
                "Use standard Jest matchers like .toBe() instead of custom matchers"
            ],
            "SYNTAX_ERROR": [
                "Check for missing brackets, parentheses, or semicolons",
                "Verify JSX syntax is correct (use className not class)",
                "Ensure async/await syntax is used correctly"
            ],
            "ASSERTION_ERROR": [
                "Review expected vs received values",
                "Consider if component state changes are being awaited",
                "Check if mock implementations match actual behavior"
            ],
            "ASYNC_ERROR": [
                "Use async/await in test function",
                "Wait for async operations with waitFor() or findBy* queries",
                "Ensure promises are properly resolved"
            ],
            "DOM_ERROR": [
                "Setup JSDOM environment in Jest config",
                "Import necessary testing library utilities",
                "Use screen queries from @testing-library/react"
            ],
            "COVERAGE_ERROR": [
                "Add more test cases to cover edge cases",
                "Test error handling paths",
                "Test conditional branches and different input scenarios"
            ]
        }
        
        return quick_fixes.get(category, ["Review the error and adjust test accordingly"])
    
    def get_error_history_analysis(self, error_history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze patterns across multiple error attempts.
        
        Args:
            error_history: List of previous error analyses
            
        Returns:
            Pattern analysis and recommendations
        """
        if not error_history:
            return {"pattern": "NO_HISTORY", "recommendation": "Initial attempt"}
        
        # Count error categories
        categories = [err.get("error_category", "UNKNOWN") for err in error_history]
        
        if len(set(categories)) == 1:
            # Same error repeating
            return {
                "pattern": "REPEATING_ERROR",
                "recommendation": "Try alternative approach - current strategy not working",
                "should_escalate": True
            }
        
        if "IMPORT_ERROR" in categories and "SYNTAX_ERROR" in categories:
            return {
                "pattern": "CASCADING_ERRORS",
                "recommendation": "Fix import errors first, they may cause subsequent issues",
                "should_escalate": False
            }
        
        return {
            "pattern": "DIFFERENT_ERRORS",
            "recommendation": "Making progress - continue refining",
            "should_escalate": False
        }
