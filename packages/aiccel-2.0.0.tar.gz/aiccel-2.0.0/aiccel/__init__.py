from .embeddings import EmbeddingProvider, OpenAIEmbeddingProvider, GeminiEmbeddingProvider
from .providers import OpenAIProvider, GroqProvider, GeminiProvider, LLMProvider
from .tools import Tool, SearchTool, WeatherTool, ToolRegistry
from .base_custom_tool import BaseCustomTool
from .agent import Agent, ConversationMemory, init_tracing
from .manager import AgentManager
from .privacy import EntityMasker, mask_text, unmask_text
from .logger import AILogger
from .pdf_rag_tool import PDFRAGTool
from .encryption import (
    encrypt, decrypt,
    encrypt_file, decrypt_file,
    hash_password, verify_password,
    generate_key, generate_password,
    SecureVault, Encryptor, RSAEncryptor, HybridEncryptor,
    CryptoEngine, SecurityLevel,
    test_encryption
)



__version__ = "1.0.0"

__all__ = [
    # Core components
    'Agent', 'AgentManager', 'ConversationMemory', 'init_tracing',
    
    # Providers
    'LLMProvider', 'OpenAIProvider', 'GroqProvider', 'GeminiProvider',
    
    # Embeddings
    'EmbeddingProvider', 'OpenAIEmbeddingProvider', 'GeminiEmbeddingProvider',
    
    # Tools
    'Tool', 'SearchTool', 'WeatherTool', 'ToolRegistry', 'BaseCustomTool', 'PDFRAGTool',
    
    # Privacy
    'EntityMasker', 'mask_text', 'unmask_text',
    
    # Logging and Metrics
    'AILogger', 'MetricsCollector',
    
    # Configuration
    'Config',

    'AICCLException', 'ProviderException', 'ToolException', 'TracingException', 'ValidationException',
 

    'encrypt', 'decrypt',
    'encrypt_file', 'decrypt_file',
    'hash_password', 'verify_password',
    'generate_key', 'generate_password',
    'SecureVault', 'Encryptor', 'RSAEncryptor', 'HybridEncryptor',
    'CryptoEngine', 'SecurityLevel',
    'test_encryption',
    
    # Version
    '__version__'
]