# aiccel/agent.py
"""
Production-Ready Agent Implementation
=======================================

Refactored with:
- Clean separation of concerns
- Improved maintainability
- Better error handling
- Enhanced type safety
- Production-grade patterns

Fully backward compatible with existing API.
"""

import asyncio
import logging
import re
import time
from typing import Dict, Any, List, Optional, Tuple, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

import orjson
from cachetools import TTLCache
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from .conversation_memory import ConversationMemory
from .tools import ToolRegistry, Tool
from .providers import LLMProvider
from .logger import AILogger
from .constants import ToolTags, ErrorMessages, Limits, PromptTemplates
from .exceptions import (
    AgentException,
    ToolExecutionError,
    ToolNotFoundError,
    ValidationException,
    ProviderException
)
from .tracing import init_tracing, _tracing_config


logger = logging.getLogger(__name__)


# ============================================================================
# CONFIGURATION & DATA STRUCTURES
# ============================================================================

class ExecutionMode(Enum):
    """Agent execution modes"""
    NORMAL = "normal"
    THINKING = "thinking"
    STRICT_TOOLS = "strict_tools"
    NO_TOOLS = "no_tools"


@dataclass
class AgentConfig:
    """Configuration for agent behavior"""
    name: str = "Agent"
    description: str = "AI Agent"
    instructions: str = "You are a helpful AI assistant. Provide accurate and concise answers."
    memory_type: str = "buffer"
    max_memory_turns: int = Limits.MAX_MEMORY_TURNS
    max_memory_tokens: int = Limits.MAX_MEMORY_TOKENS
    strict_tool_usage: bool = False
    thinking_enabled: bool = False
    verbose: bool = False
    log_file: Optional[str] = None
    timeout: float = Limits.DEFAULT_TIMEOUT
    
    def validate(self) -> None:
        """Validate configuration parameters"""
        if self.max_memory_turns < 1:
            raise ValidationException("max_memory_turns", "Must be at least 1")
        if self.max_memory_tokens < 100:
            raise ValidationException("max_memory_tokens", "Must be at least 100")
        if self.timeout < 0:
            raise ValidationException("timeout", "Must be positive")


@dataclass
class AgentResponse:
    """Structured response from agent"""
    response: str
    thinking: Optional[str] = None
    tools_used: List[Tuple[str, Dict[str, Any]]] = field(default_factory=list)
    tool_outputs: List[Tuple[str, Dict[str, Any], str]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    execution_time: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "response": self.response,
            "thinking": self.thinking,
            "tools_used": self.tools_used,
            "tool_outputs": self.tool_outputs,
            "metadata": self.metadata,
            "execution_time": self.execution_time
        }


@dataclass
class ExecutionContext:
    """Context for agent execution"""
    query: str
    trace_id: int
    has_tools: bool
    relevant_tools: List[Tool]
    execution_mode: ExecutionMode
    start_time: float = field(default_factory=time.time)
    
    def get_duration(self) -> float:
        """Get execution duration in seconds"""
        return time.time() - self.start_time


# ============================================================================
# PROMPT BUILDER - Handles all prompt construction
# ============================================================================

class PromptBuilder:
    """
    Centralized prompt building with caching.
    Separates prompt logic from execution logic.
    """
    
    # Class-level cache for static prompts
    _prompt_cache = TTLCache(maxsize=100, ttl=3600)
    
    def __init__(self, config: AgentConfig, tool_registry: ToolRegistry):
        self.config = config
        self.tool_registry = tool_registry
    
    def build_main_prompt(
        self,
        query: str,
        relevant_tools: List[Tool],
        memory_context: str
    ) -> str:
        """
        Build main execution prompt with tools and context.
        
        Args:
            query: User query
            relevant_tools: List of relevant tools
            memory_context: Conversation history
        
        Returns:
            Complete prompt string
        """
        cache_key = self._get_prompt_cache_key(relevant_tools)
        
        if cache_key in self._prompt_cache:
            static_parts = self._prompt_cache[cache_key]
        else:
            static_parts = self._build_static_parts(relevant_tools)
            self._prompt_cache[cache_key] = static_parts
        
        return self._assemble_prompt(query, static_parts, memory_context, relevant_tools)
    
    def build_thinking_prompt(self, query: str, has_tools: bool) -> str:
        """Build prompt for thinking phase"""
        tool_info = self._get_tool_summary() if has_tools else "None"
        
        return (
            f"Instructions: {self.config.instructions}\n\n"
            f"Think step-by-step about how to answer this query: {query}\n\n"
            f"Available tools: {tool_info}\n\n"
            "Consider:\n"
            "1. What information is needed to answer this query?\n"
            "2. Can the available tools help gather this information?\n"
            "3. If multiple tools are needed, in what order should they be used?\n"
            "4. What is the most efficient approach?\n\n"
            "Provide your reasoning:"
        )
    
    def build_direct_tool_prompt(self, query: str, relevant_tools: List[Tool]) -> str:
        """Build prompt for direct tool selection"""
        tool_descriptions = self._format_tool_descriptions(relevant_tools, with_examples=True)
        
        return (
            f"Instructions: {self.config.instructions}\n\n"
            f"Query: {query}\n\n"
            f"This query requires using one or more tools. Select ALL appropriate tools from:\n"
            f"{tool_descriptions}\n\n"
            "Output ALL necessary tool calls, each in the format:\n"
            f"{ToolTags.TOOL_START}{{\"name\":\"tool_name\",\"args\":{{\"param\":\"value\"}}}}{ToolTags.TOOL_END}\n\n"
            "If multiple tools are needed, include multiple tags, one per tool.\n"
            "Response:"
        )
    
    def build_synthesis_prompt(
        self,
        query: str,
        tool_outputs: List[Tuple[str, Dict[str, Any], str]]
    ) -> str:
        """Build prompt for synthesizing tool outputs"""
        output_sections = []
        
        for tool_name, tool_args, tool_output in tool_outputs:
            output_sections.append(
                f"Tool: {tool_name}\n"
                f"Arguments: {tool_args}\n"
                f"Output:\n{tool_output}\n"
            )
        
        synthesis_instructions = (
            " You MUST NOT use any general knowledge beyond the tool outputs."
            if self.config.strict_tool_usage
            else " You may supplement with your knowledge if the tool outputs are insufficient."
        )
        
        return (
            f"Instructions: {self.config.instructions}\n\n"
            f"Original query: \"{query}\"\n\n"
            "Tool outputs:\n" + "\n".join(output_sections) + "\n\n"
            "Based on the tool outputs above, formulate a comprehensive answer to the original query."
            f"{synthesis_instructions}\n\n"
            "Integrate information from all tools and provide a clear, concise response.\n\n"
            "Response:"
        )
    
    def _build_static_parts(self, relevant_tools: List[Tool]) -> Dict[str, str]:
        """Build static parts of prompt (cached)"""
        has_tools = bool(self.tool_registry.get_all())
        
        parts = {
            "base": f"Instructions: {self.config.instructions}\n\n",
            "tools": "",
            "tool_usage": ""
        }
        
        if has_tools:
            all_tools = self.tool_registry.get_all()
            parts["tools"] = self._format_tool_descriptions(all_tools)
            parts["tool_usage"] = self._build_tool_usage_instructions(relevant_tools)
        else:
            parts["tools"] = "No tools are available.\n"
            parts["tool_usage"] = (
                "Answer the query directly using your knowledge."
                if not self.config.strict_tool_usage
                else f"{ToolTags.NO_TOOL_START}No tools available. Cannot answer.{ToolTags.NO_TOOL_END}"
            )
        
        return parts
    
    def _build_tool_usage_instructions(self, relevant_tools: List[Tool]) -> str:
        """Build instructions for tool usage"""
        base_instructions = (
            "Tool usage guidelines:\n"
            "1. Analyze if any tools can help answer the query\n"
            f"2. Use the EXACT format: {ToolTags.TOOL_START}{{\"name\":\"tool_name\",\"args\":{{\"param\":\"value\"}}}}{ToolTags.TOOL_END}\n"
            "3. Include ALL necessary tools if multiple are relevant\n"
        )
        
        if self.config.strict_tool_usage:
            base_instructions += (
                "4. You MUST use tools if available - do NOT answer without tools\n"
                f"5. If no appropriate tool exists, output: {ToolTags.NO_TOOL_START}Cannot answer without appropriate tools{ToolTags.NO_TOOL_END}\n"
            )
        else:
            base_instructions += (
                "4. If no tool is needed, provide a direct response\n"
                "5. If tools fail, explain what went wrong\n"
            )
        
        if relevant_tools:
            tool_names = ", ".join(t.name for t in relevant_tools)
            base_instructions += f"\nRelevant tools for this query: {tool_names}\n"
        
        return base_instructions
    
    def _assemble_prompt(
        self,
        query: str,
        static_parts: Dict[str, str],
        memory_context: str,
        relevant_tools: List[Tool]
    ) -> str:
        """Assemble final prompt from parts"""
        parts = [static_parts["base"]]
        
        if memory_context:
            parts.append(f"{memory_context}\n\n")
        
        parts.append(f"Current Query: {query[:Limits.MAX_PROMPT_LENGTH]}\n\n")
        
        if static_parts["tools"]:
            parts.append(f"Available tools:\n{static_parts['tools']}\n\n")
        
        parts.append(static_parts["tool_usage"])
        
        return "".join(parts)
    
    def _format_tool_descriptions(
        self,
        tools: List[Tool],
        with_examples: bool = False
    ) -> str:
        """Format tool descriptions"""
        descriptions = []
        
        for tool in tools:
            desc = f"- {tool.name}: {tool.description}"
            
            if with_examples and tool.example_usages:
                example = tool.example_usages[0]
                desc += f"\n  Example: {ToolTags.TOOL_START}{orjson.dumps(example).decode('utf-8')}{ToolTags.TOOL_END}"
            
            descriptions.append(desc)
        
        return "\n".join(descriptions)
    
    def _get_tool_summary(self) -> str:
        """Get summary of available tools"""
        tools = self.tool_registry.get_all()
        if not tools:
            return "None"
        return ", ".join(t.name for t in tools)
    
    def _get_prompt_cache_key(self, relevant_tools: List[Tool]) -> str:
        """Generate cache key for prompt"""
        tool_key = tuple(sorted(t.name for t in self.tool_registry.get_all()))
        relevant_key = tuple(sorted(t.name for t in relevant_tools))
        return f"{tool_key}:{relevant_key}:{self.config.strict_tool_usage}"


# ============================================================================
# TOOL EXECUTOR - Handles tool selection and execution
# ============================================================================

class AgentToolExecutor:
    """
    Handles tool selection, validation, and execution.
    Improved from original with better error handling and caching.
    """
    
    def __init__(
        self,
        tool_registry: ToolRegistry,
        llm_provider: LLMProvider,
        agent_logger: AILogger,
        strict_mode: bool = False
    ):
        self.tool_registry = tool_registry
        self.llm_provider = llm_provider
        self.logger = agent_logger
        self.strict_mode = strict_mode
        
        # Circuit breaker for failing tools
        self.tool_failure_count: Dict[str, int] = {}
        self.max_tool_failures = Limits.MAX_TOOL_RETRIES
        
        # Tool execution cache
        self.tool_cache = TTLCache(maxsize=Limits.CACHE_MAX_SIZE, ttl=Limits.CACHE_TTL)
        
        # Shared cache access (set by AgentManager if available)
        self._get_from_shared_cache: Optional[Callable] = None
        self._set_in_shared_cache: Optional[Callable] = None
    
    def find_relevant_tools(self, query: str) -> List[Tool]:
        """Find tools relevant to the query"""
        if not query or not query.strip():
            self.logger.warning("Empty query provided for tool selection")
            return []
        
        return self.tool_registry.find_relevant_tools(query)
    
    def should_skip_tool(self, tool_name: str) -> bool:
        """Check if tool should be skipped due to repeated failures"""
        failure_count = self.tool_failure_count.get(tool_name, 0)
        if failure_count >= self.max_tool_failures:
            self.logger.warning(
                f"Tool {tool_name} circuit breaker open (failures: {failure_count})",
                extra={"tool_name": tool_name, "failure_count": failure_count}
            )
            return True
        return False
    
    def record_tool_failure(self, tool_name: str) -> None:
        """Record a tool failure"""
        self.tool_failure_count[tool_name] = self.tool_failure_count.get(tool_name, 0) + 1
        self.logger.debug(
            f"Tool {tool_name} failure count: {self.tool_failure_count[tool_name]}",
            extra={"tool_name": tool_name, "failure_count": self.tool_failure_count[tool_name]}
        )
    
    def record_tool_success(self, tool_name: str) -> None:
        """Reset failure count on success"""
        if tool_name in self.tool_failure_count:
            del self.tool_failure_count[tool_name]
            self.logger.debug(f"Tool {tool_name} failure count reset")
    
    def generate_cache_key(self, tool_name: str, tool_args: Dict[str, Any]) -> str:
        """Generate consistent cache key for tool execution"""
        try:
            args_json = orjson.dumps(tool_args, option=orjson.OPT_SORT_KEYS).decode('utf-8')
            return f"{tool_name}:{args_json}"
        except Exception as e:
            self.logger.warning(f"Failed to generate cache key: {e}")
            return f"{tool_name}:{str(tool_args)}"
    
    def execute_tool_with_cache(
        self,
        tool_name: str,
        tool_args: Dict[str, Any],
        trace_id: int
    ) -> Tuple[str, bool]:
        """
        Execute tool with caching support.
        
        Args:
            tool_name: Name of the tool
            tool_args: Tool arguments
            trace_id: Trace ID for logging
        
        Returns:
            Tuple of (result, success)
        """
        # Generate cache key
        cache_key = self.generate_cache_key(tool_name, tool_args)
        
        # Try shared cache first
        if self._get_from_shared_cache:
            cached_result = self._get_from_shared_cache(cache_key)
            if cached_result is not None:
                self.logger.trace_step(trace_id, "shared_cache_hit", {
                    "tool": tool_name,
                    "cache_key": cache_key[:50]
                })
                self.record_tool_success(tool_name)
                return cached_result, True
        
        # Try local cache
        if cache_key in self.tool_cache:
            tool_output = self.tool_cache[cache_key]
            self.logger.trace_step(trace_id, "local_cache_hit", {
                "tool": tool_name,
                "output_preview": str(tool_output)[:100]
            })
            self.record_tool_success(tool_name)
            return tool_output, True
        
        # Execute tool
        tool = self.tool_registry.get(tool_name)
        if not tool:
            error_msg = ErrorMessages.TOOL_NOT_FOUND.format(tool_name=tool_name)
            self.logger.error(error_msg)
            raise ToolNotFoundError(tool_name, list(self.tool_registry.tools.keys()))
        
        self.logger.trace_step(trace_id, "execute_tool_start", {"tool": tool_name, "args": tool_args})
        
        # Auto-fill common missing parameters
        tool_args = self._fix_tool_args(tool_name, tool_args)
        
        try:
            tool_output = tool.execute(tool_args)
            
            # Check for errors in output
            if tool_output and isinstance(tool_output, str) and tool_output.startswith("Error"):
                self.record_tool_failure(tool_name)
                self.logger.error(f"Tool {tool_name} returned error: {tool_output[:100]}")
                return tool_output, False
            
            # Success - cache result
            self.record_tool_success(tool_name)
            
            # Store in local cache
            self.tool_cache[cache_key] = tool_output
            
            # Store in shared cache if available
            if self._set_in_shared_cache:
                self._set_in_shared_cache(cache_key, tool_output)
            
            self.logger.trace_step(trace_id, "execute_tool_complete", {
                "tool": tool_name,
                "output_preview": str(tool_output)[:100]
            })
            
            return tool_output, True
            
        except Exception as e:
            self.record_tool_failure(tool_name)
            error_msg = f"Error executing tool {tool_name}: {str(e)}"
            self.logger.trace_error(trace_id, e, error_msg)
            raise ToolExecutionError(tool_name, error_msg, e)
    
    def parse_tool_usage(
        self,
        response: str,
        original_query: str = ""
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """
        Parse tool usage from LLM response with strict validation.
        
        Args:
            response: LLM response text
            original_query: Original query for context
        
        Returns:
            List of (tool_name, tool_args) tuples
        """
        tool_calls = []
        
        # Step 1: Check for NO_TOOL tag
        no_tool_pattern = rf'\{ToolTags.NO_TOOL_START}(.*?)\{ToolTags.NO_TOOL_END}'
        no_tool_match = re.search(no_tool_pattern, response, re.DOTALL)
        if no_tool_match:
            self.logger.info("Parsed [NO_TOOL] tag")
            return []
        
        # Step 2: Parse [TOOL] tags
        tool_pattern = rf'\{ToolTags.TOOL_START}(.*?)\{ToolTags.TOOL_END}'
        matches = re.findall(tool_pattern, response, re.DOTALL)
        
        for match in matches:
            try:
                tool_json = match.strip()
                
                # Validate JSON structure
                if not tool_json.startswith('{') or not tool_json.endswith('}'):
                    self.logger.warning(f"Invalid JSON structure: {tool_json[:50]}")
                    continue
                
                # Parse JSON
                try:
                    tool_data = orjson.loads(tool_json)
                except orjson.JSONDecodeError as e:
                    self.logger.warning(f"JSON parsing failed: {e}, content: {match[:100]}")
                    continue
                
                # Validate structure
                if not self._validate_tool_call(tool_data):
                    self.logger.warning(f"Tool call validation failed: {tool_data}")
                    continue
                
                tool_name = tool_data.get("name")
                tool_args = tool_data.get("args", {})
                
                # Validate tool exists
                if not self.tool_registry.get(tool_name):
                    self.logger.warning(f"Tool '{tool_name}' not found, skipping")
                    continue
                
                # Validate and fix arguments
                if not self._validate_tool_args(tool_name, tool_args):
                    self.logger.warning(f"Invalid arguments for '{tool_name}': {tool_args}")
                    tool_args = self._fix_tool_args(tool_name, tool_args, original_query)
                
                tool_calls.append((tool_name, tool_args))
                self.logger.debug(f"Parsed tool call: {tool_name} with args: {tool_args}")
                
            except Exception as e:
                self.logger.error(f"Error parsing tool: {e}")
                continue
        
        # Step 3: Fallback patterns
        if not tool_calls and matches:
            self.logger.info("Primary parsing failed, trying alternate patterns")
            tool_calls = self._parse_alternate_patterns(response, original_query)
        
        return tool_calls
    
    def _validate_tool_call(self, tool_data: Any) -> bool:
        """Validate tool call structure"""
        if not isinstance(tool_data, dict):
            return False
        if "name" not in tool_data:
            return False
        if not isinstance(tool_data["name"], str):
            return False
        if "args" in tool_data and not isinstance(tool_data["args"], dict):
            return False
        return True
    
    def _validate_tool_args(self, tool_name: str, args: Dict[str, Any]) -> bool:
        """Validate tool arguments"""
        tool = self.tool_registry.get(tool_name)
        if not tool:
            return False
        
        # Special validation for known tools
        if tool_name == "search":
            return any(key in args for key in ["query", "q", "search", "text"])
        
        if tool_name == "get_weather":
            return any(key in args for key in ["location", "city", "place"])
        
        if tool_name == "pdf_rag":
            return "query" in args or len(args) == 0
        
        return isinstance(args, dict)
    
    def _fix_tool_args(
        self,
        tool_name: str,
        args: Dict[str, Any],
        original_query: str = ""
    ) -> Dict[str, Any]:
        """Attempt to fix common tool argument issues"""
        fixed_args = args.copy()
        
        # Fix pdf_rag missing query
        if tool_name == "pdf_rag" and "query" not in fixed_args and original_query:
            fixed_args["query"] = original_query
            self.logger.info(f"Auto-fixed pdf_rag query: {original_query[:50]}")
        
        # Fix search tool missing query
        if tool_name == "search" and not any(key in fixed_args for key in ["query", "q"]):
            if original_query:
                fixed_args["query"] = original_query
                self.logger.info(f"Auto-fixed search query: {original_query[:50]}")
        
        # Fix weather tool missing location
        if tool_name == "get_weather" and not any(key in fixed_args for key in ["location", "city"]):
            location_match = re.search(
                r'weather.*?(?:in|at|for)\s+([A-Za-z\s,]+)',
                original_query,
                re.IGNORECASE
            )
            if location_match:
                fixed_args["location"] = location_match.group(1).strip()
                self.logger.info(f"Auto-extracted location: {fixed_args['location']}")
        
        return fixed_args
    
    def _parse_alternate_patterns(
        self,
        response: str,
        original_query: str
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """Parse alternate tool call patterns"""
        tool_calls = []
        
        alt_patterns = [
            r'```json\n\s*{\s*"name":\s*"([^"]+)",\s*"args":\s*({.*?})\s*}\s*```',
            r'Tool:\s*([a-z_]+).*?Args:.*?({.*?})',
        ]
        
        for pattern in alt_patterns:
            alt_matches = re.findall(pattern, response, re.DOTALL)
            for alt_match in alt_matches:
                try:
                    if len(alt_match) >= 2:
                        tool_name = alt_match[0]
                        args_str = alt_match[1]
                        
                        # Validate tool exists
                        if not self.tool_registry.get(tool_name):
                            continue
                        
                        # Parse args
                        try:
                            tool_args = orjson.loads(args_str)
                        except:
                            tool_args = {"query": args_str.strip('" ')}
                        
                        # Validate and fix args
                        if not self._validate_tool_args(tool_name, tool_args):
                            tool_args = self._fix_tool_args(tool_name, tool_args, original_query)
                        
                        if self._validate_tool_args(tool_name, tool_args):
                            tool_calls.append((tool_name, tool_args))
                            self.logger.info(f"Parsed tool from alternate pattern: {tool_name}")
                
                except Exception as e:
                    self.logger.warning(f"Failed to parse alternate pattern: {e}")
                    continue
        
        return tool_calls


# ============================================================================
# EXECUTION ORCHESTRATOR - Handles execution flow
# ============================================================================

class ExecutionOrchestrator:
    """
    Orchestrates the execution flow of the agent.
    Handles thinking, tool execution, and response synthesis.
    """
    
    def __init__(
        self,
        llm_provider: LLMProvider,
        tool_executor: AgentToolExecutor,
        prompt_builder: PromptBuilder,
        memory: ConversationMemory,
        logger: AILogger,
        config: AgentConfig,
        fallback_providers: List[LLMProvider]
    ):
        self.llm_provider = llm_provider
        self.tool_executor = tool_executor
        self.prompt_builder = prompt_builder
        self.memory = memory
        self.logger = logger
        self.config = config
        self.fallback_providers = fallback_providers
    
    def execute_query(self, query: str, context: ExecutionContext) -> AgentResponse:
        """
        Execute query with full orchestration.
        
        Args:
            query: User query
            context: Execution context
        
        Returns:
            AgentResponse with results
        """
        # Step 1: Thinking phase (if enabled)
        thinking = None
        if self.config.thinking_enabled:
            thinking = self._execute_thinking_phase(query, context)
        
        # Step 2: Generate initial LLM response
        llm_response = self._generate_initial_response(query, context, thinking)
        
        # Step 3: Parse and execute tools
        final_response, tool_outputs = self._execute_tools_flow(
            query, llm_response, context
        )
        
        # Step 4: Build response
        response = AgentResponse(
            response=final_response,
            thinking=thinking,
            tools_used=[(name, args) for name, args, _ in tool_outputs],
            tool_outputs=tool_outputs,
            execution_time=context.get_duration(),
            metadata={
                "has_tools": context.has_tools,
                "relevant_tools": [t.name for t in context.relevant_tools],
                "execution_mode": context.execution_mode.value
            }
        )
        
        # Step 5: Update memory
        self._update_memory(query, response)
        
        return response
    
    async def execute_query_async(
        self,
        query: str,
        context: ExecutionContext
    ) -> AgentResponse:
        """Execute query asynchronously"""
        # Step 1: Thinking phase
        thinking = None
        if self.config.thinking_enabled:
            thinking = await self._execute_thinking_phase_async(query, context)
        
        # Step 2: Generate initial response
        llm_response = await self._generate_initial_response_async(query, context, thinking)
        
        # Step 3: Execute tools
        final_response, tool_outputs = await self._execute_tools_flow_async(
            query, llm_response, context
        )
        
        # Step 4: Build response
        response = AgentResponse(
            response=final_response,
            thinking=thinking,
            tools_used=[(name, args) for name, args, _ in tool_outputs],
            tool_outputs=tool_outputs,
            execution_time=context.get_duration(),
            metadata={
                "has_tools": context.has_tools,
                "relevant_tools": [t.name for t in context.relevant_tools],
                "execution_mode": context.execution_mode.value
            }
        )
        
        # Step 5: Update memory
        self._update_memory(query, response)
        
        return response
    
    def _execute_thinking_phase(self, query: str, context: ExecutionContext) -> str:
        """Execute thinking phase"""
        thinking_prompt = self.prompt_builder.build_thinking_prompt(query, context.has_tools)
        
        try:
            thinking = self._call_llm(thinking_prompt)
            self.logger.trace_step(context.trace_id, "thinking_complete", {
                "thinking": thinking[:200]
            })
            return thinking
        except Exception as e:
            self.logger.trace_error(context.trace_id, e, "Thinking phase failed")
            return "Thinking phase failed due to error."
    
    async def _execute_thinking_phase_async(
        self,
        query: str,
        context: ExecutionContext
    ) -> str:
        """Execute thinking phase asynchronously"""
        thinking_prompt = self.prompt_builder.build_thinking_prompt(query, context.has_tools)
        
        try:
            thinking = await self._call_llm_async(thinking_prompt)
            self.logger.trace_step(context.trace_id, "thinking_complete_async", {
                "thinking": thinking[:200]
            })
            return thinking
        except Exception as e:
            self.logger.trace_error(context.trace_id, e, "Async thinking phase failed")
            return "Async thinking phase failed due to error."
    
    def _generate_initial_response(
        self,
        query: str,
        context: ExecutionContext,
        thinking: Optional[str]
    ) -> str:
        """Generate initial LLM response"""
        memory_context = self.memory.get_context(max_context_turns=5)
        prompt = self.prompt_builder.build_main_prompt(query, context.relevant_tools, memory_context)
        
        self.logger.trace_step(context.trace_id, "build_prompt", {
            "prompt_summary": prompt[:300]
        })
        
        # Build messages
        messages = [{"role": "user", "content": prompt}]
        
        if thinking:
            messages.append({"role": "assistant", "content": f"Thinking: {thinking}"})
            messages.append({
                "role": "user",
                "content": "Now provide your final answer, using tools as specified."
            })
        
        self.logger.trace_step(context.trace_id, "generate_initial_response", {
            "messages_count": len(messages)
        })
        
        llm_response = self._call_llm_chat(messages)
        self.logger.debug(f"Initial LLM response: {llm_response[:200]}...")
        
        return llm_response
    
    async def _generate_initial_response_async(
        self,
        query: str,
        context: ExecutionContext,
        thinking: Optional[str]
    ) -> str:
        """Generate initial LLM response asynchronously"""
        memory_context = self.memory.get_context(max_context_turns=5)
        prompt = self.prompt_builder.build_main_prompt(query, context.relevant_tools, memory_context)
        
        self.logger.trace_step(context.trace_id, "build_prompt_async", {
            "prompt_summary": prompt[:300]
        })
        
        # Build messages
        messages = [{"role": "user", "content": prompt}]
        
        if thinking:
            messages.append({"role": "assistant", "content": f"Thinking: {thinking}"})
            messages.append({
                "role": "user",
                "content": "Now provide your final answer, using tools as specified."
            })
        
        self.logger.trace_step(context.trace_id, "generate_initial_response_async", {
            "messages_count": len(messages)
        })
        
        llm_response = await self._call_llm_chat_async(messages)
        self.logger.debug(f"Initial async LLM response: {llm_response[:200]}...")
        
        return llm_response
    
    def _execute_tools_flow(
        self,
        query: str,
        llm_response: str,
        context: ExecutionContext
    ) -> Tuple[str, List[Tuple[str, Dict[str, Any], str]]]:
        """
        Execute the full tool flow: parse, execute, synthesize.
        
        Returns:
            Tuple of (final_response, tool_outputs)
        """
        # Handle no tools scenario
        if not context.has_tools:
            if self.config.strict_tool_usage:
                return ErrorMessages.NO_TOOLS_AVAILABLE, []
            return llm_response, []
        
        # Parse tool calls from response
        tool_calls = self.tool_executor.parse_tool_usage(llm_response, query)
        
        # If no tools parsed in strict mode, try direct selection
        if not tool_calls and self.config.strict_tool_usage:
            self.logger.info("Strict mode: No tools parsed, attempting direct selection")
            tool_calls = self._attempt_direct_tool_selection(query, context)
        
        # Execute tools
        tool_outputs = []
        if tool_calls:
            tool_outputs = self._execute_tool_calls(tool_calls, context)
            
            # Check for failures in strict mode
            if self.config.strict_tool_usage and not self._all_tools_succeeded(tool_outputs):
                return self._build_tool_failure_response(tool_outputs), tool_outputs
            
            # Synthesize response from tool outputs
            if tool_outputs:
                final_response = self._synthesize_response(query, tool_outputs, context)
                return final_response, tool_outputs
        
        # Handle no tools used in strict mode
        if self.config.strict_tool_usage and not tool_outputs:
            self.logger.warning("Strict mode: No tools used")
            return (
                "I am configured to use specific tools, but could not identify or "
                "successfully use appropriate tools for your query.",
                []
            )
        
        # Default to LLM response
        return llm_response, []
    
    async def _execute_tools_flow_async(
        self,
        query: str,
        llm_response: str,
        context: ExecutionContext
    ) -> Tuple[str, List[Tuple[str, Dict[str, Any], str]]]:
        """Execute tool flow asynchronously"""
        # Handle no tools scenario
        if not context.has_tools:
            if self.config.strict_tool_usage:
                return ErrorMessages.NO_TOOLS_AVAILABLE, []
            return llm_response, []
        
        # Parse tool calls
        tool_calls = self.tool_executor.parse_tool_usage(llm_response, query)
        
        # Direct selection fallback
        if not tool_calls and self.config.strict_tool_usage:
            self.logger.info("Strict mode (async): Attempting direct selection")
            tool_calls = await self._attempt_direct_tool_selection_async(query, context)
        
        # Execute tools
        tool_outputs = []
        if tool_calls:
            tool_outputs = await self._execute_tool_calls_async(tool_calls, context)
            
            # Check for failures
            if self.config.strict_tool_usage and not self._all_tools_succeeded(tool_outputs):
                return self._build_tool_failure_response(tool_outputs), tool_outputs
            
            # Synthesize response
            if tool_outputs:
                final_response = await self._synthesize_response_async(
                    query, tool_outputs, context
                )
                return final_response, tool_outputs
        
        # Strict mode fallback
        if self.config.strict_tool_usage and not tool_outputs:
            self.logger.warning("Strict mode (async): No tools used")
            return (
                "I am configured to use specific tools, but could not identify or "
                "successfully use appropriate tools for your query.",
                []
            )
        
        return llm_response, []
    
    def _execute_tool_calls(
        self,
        tool_calls: List[Tuple[str, Dict[str, Any]]],
        context: ExecutionContext
    ) -> List[Tuple[str, Dict[str, Any], str]]:
        """Execute multiple tool calls"""
        tool_outputs = []
        
        for tool_name, tool_args in tool_calls:
            # Check circuit breaker
            if self.tool_executor.should_skip_tool(tool_name):
                error_output = f"Tool {tool_name} temporarily disabled due to failures"
                tool_outputs.append((tool_name, tool_args, error_output))
                continue
            
            # Execute tool
            try:
                output, success = self.tool_executor.execute_tool_with_cache(
                    tool_name, tool_args, context.trace_id
                )
                tool_outputs.append((tool_name, tool_args, output))
                
                # Stop on failure in strict mode
                if not success and self.config.strict_tool_usage:
                    break
                    
            except ToolNotFoundError as e:
                self.logger.error(f"Tool not found: {e}")
                error_output = f"Error: Tool '{tool_name}' is not available"
                tool_outputs.append((tool_name, tool_args, error_output))
                if self.config.strict_tool_usage:
                    break
                    
            except ToolExecutionError as e:
                self.logger.error(f"Tool execution error: {e}")
                error_output = f"Error: {e.message}"
                tool_outputs.append((tool_name, tool_args, error_output))
                if self.config.strict_tool_usage:
                    break
        
        return tool_outputs
    
    async def _execute_tool_calls_async(
        self,
        tool_calls: List[Tuple[str, Dict[str, Any]]],
        context: ExecutionContext
    ) -> List[Tuple[str, Dict[str, Any], str]]:
        """Execute multiple tool calls asynchronously"""
        tool_outputs = []
        
        for tool_name, tool_args in tool_calls:
            # Check circuit breaker
            if self.tool_executor.should_skip_tool(tool_name):
                error_output = f"Tool {tool_name} temporarily disabled due to failures"
                tool_outputs.append((tool_name, tool_args, error_output))
                continue
            
            # Execute tool in executor
            try:
                loop = asyncio.get_event_loop()
                output, success = await loop.run_in_executor(
                    None,
                    self.tool_executor.execute_tool_with_cache,
                    tool_name,
                    tool_args,
                    context.trace_id
                )
                tool_outputs.append((tool_name, tool_args, output))
                
                if not success and self.config.strict_tool_usage:
                    break
                    
            except ToolNotFoundError as e:
                self.logger.error(f"Tool not found (async): {e}")
                error_output = f"Error: Tool '{tool_name}' is not available"
                tool_outputs.append((tool_name, tool_args, error_output))
                if self.config.strict_tool_usage:
                    break
                    
            except ToolExecutionError as e:
                self.logger.error(f"Tool execution error (async): {e}")
                error_output = f"Error: {e.message}"
                tool_outputs.append((tool_name, tool_args, error_output))
                if self.config.strict_tool_usage:
                    break
        
        return tool_outputs
    
    def _attempt_direct_tool_selection(
        self,
        query: str,
        context: ExecutionContext
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """Attempt direct tool selection when parsing fails"""
        tools = context.relevant_tools if context.relevant_tools else self.tool_executor.tool_registry.get_all()
        if not tools:
            return []
        
        direct_prompt = self.prompt_builder.build_direct_tool_prompt(query, tools)
        self.logger.trace_step(context.trace_id, "direct_tool_selection", {
            "prompt_summary": direct_prompt[:200]
        })
        
        try:
            response = self._call_llm(direct_prompt)
            tool_calls = self.tool_executor.parse_tool_usage(response, query)
            
            if tool_calls:
                self.logger.info(f"Direct selection found: {[name for name, _ in tool_calls]}")
            else:
                self.logger.warning("Direct tool selection yielded no results")
            
            return tool_calls
            
        except Exception as e:
            self.logger.trace_error(context.trace_id, e, "Direct tool selection failed")
            return []
    
    async def _attempt_direct_tool_selection_async(
        self,
        query: str,
        context: ExecutionContext
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """Attempt direct tool selection asynchronously"""
        tools = context.relevant_tools if context.relevant_tools else self.tool_executor.tool_registry.get_all()
        if not tools:
            return []
        
        direct_prompt = self.prompt_builder.build_direct_tool_prompt(query, tools)
        self.logger.trace_step(context.trace_id, "direct_tool_selection_async", {
            "prompt_summary": direct_prompt[:200]
        })
        
        try:
            response = await self._call_llm_async(direct_prompt)
            tool_calls = self.tool_executor.parse_tool_usage(response, query)
            
            if tool_calls:
                self.logger.info(f"Direct selection (async) found: {[name for name, _ in tool_calls]}")
            else:
                self.logger.warning("Direct tool selection (async) yielded no results")
            
            return tool_calls
            
        except Exception as e:
            self.logger.trace_error(context.trace_id, e, "Direct tool selection (async) failed")
            return []
    
    def _synthesize_response(
        self,
        query: str,
        tool_outputs: List[Tuple[str, Dict[str, Any], str]],
        context: ExecutionContext
    ) -> str:
        """Synthesize final response from tool outputs"""
        synthesis_prompt = self.prompt_builder.build_synthesis_prompt(query, tool_outputs)
        
        self.logger.trace_step(context.trace_id, "synthesis_prompt", {
            "prompt_summary": synthesis_prompt[:300]
        })
        
        try:
            final_response = self._call_llm(synthesis_prompt)
            return final_response
            
        except Exception as e:
            self.logger.trace_error(context.trace_id, e, "Response synthesis failed")
            
            if self.config.strict_tool_usage:
                return (
                    f"Error processing results from tools: "
                    f"{', '.join([name for name, _, _ in tool_outputs])}"
                )
            else:
                # Fallback: concatenate tool outputs
                outputs = [f"{name}: {output[:200]}" for name, _, output in tool_outputs]
                return "\n\n".join(outputs)
    
    async def _synthesize_response_async(
        self,
        query: str,
        tool_outputs: List[Tuple[str, Dict[str, Any], str]],
        context: ExecutionContext
    ) -> str:
        """Synthesize final response asynchronously"""
        synthesis_prompt = self.prompt_builder.build_synthesis_prompt(query, tool_outputs)
        
        self.logger.trace_step(context.trace_id, "synthesis_prompt_async", {
            "prompt_summary": synthesis_prompt[:300]
        })
        
        try:
            final_response = await self._call_llm_async(synthesis_prompt)
            return final_response
            
        except Exception as e:
            self.logger.trace_error(context.trace_id, e, "Response synthesis (async) failed")
            
            if self.config.strict_tool_usage:
                return (
                    f"Error processing results from tools: "
                    f"{', '.join([name for name, _, _ in tool_outputs])}"
                )
            else:
                outputs = [f"{name}: {output[:200]}" for name, _, output in tool_outputs]
                return "\n\n".join(outputs)
    
    def _all_tools_succeeded(
        self,
        tool_outputs: List[Tuple[str, Dict[str, Any], str]]
    ) -> bool:
        """Check if all tool executions succeeded"""
        for _, _, output in tool_outputs:
            if isinstance(output, str) and output.startswith("Error"):
                return False
        return True
    
    def _build_tool_failure_response(
        self,
        tool_outputs: List[Tuple[str, Dict[str, Any], str]]
    ) -> str:
        """Build response for tool failures in strict mode"""
        failed_tools = [
            name for name, _, output in tool_outputs
            if isinstance(output, str) and output.startswith("Error")
        ]
        
        if failed_tools:
            return (
                f"Tool execution failed for: {', '.join(failed_tools)}. "
                "I cannot provide an answer without successful tool execution."
            )
        
        return "Tool execution encountered errors. Cannot complete request."
    
    def _update_memory(self, query: str, response: AgentResponse) -> None:
        """Update conversation memory"""
        tool_names = ", ".join([name for name, _ in response.tools_used]) if response.tools_used else None
        tool_outputs_str = "\n".join([
            str(output) for _, _, output in response.tool_outputs
        ]) if response.tool_outputs else None
        
        self.memory.add_turn(
            query=query,
            response=response.response,
            tool_used=tool_names,
            tool_output=tool_outputs_str
        )
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=2, max=8),
        retry=retry_if_exception_type((ProviderException,)),
        reraise=True
    )
    def _call_llm(self, prompt: str, **kwargs) -> str:
        """Call LLM with retry and fallback logic"""
        providers = [self.llm_provider] + self.fallback_providers
        
        for provider in providers:
            try:
                return provider.generate(prompt, **kwargs)
            except Exception as e:
                self.logger.warning(
                    f"Provider {type(provider).__name__} failed: {e}",
                    extra={"provider": type(provider).__name__, "error": str(e)}
                )
                if provider == providers[-1]:
                    raise ProviderException(f"All providers failed: {str(e)}")
        
        raise ProviderException("All providers failed")
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=2, max=8),
        retry=retry_if_exception_type((ProviderException,)),
        reraise=True
    )
    async def _call_llm_async(self, prompt: str, **kwargs) -> str:
        """Call LLM asynchronously with retry and fallback"""
        providers = [self.llm_provider] + self.fallback_providers
        
        for provider in providers:
            try:
                return await provider.generate_async(prompt, **kwargs)
            except Exception as e:
                self.logger.warning(
                    f"Provider {type(provider).__name__} failed (async): {e}",
                    extra={"provider": type(provider).__name__, "error": str(e)}
                )
                if provider == providers[-1]:
                    raise ProviderException(f"All providers failed: {str(e)}")
        
        raise ProviderException("All providers failed")
    
    def _call_llm_chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """Call LLM chat with fallback"""
        providers = [self.llm_provider] + self.fallback_providers
        
        for provider in providers:
            try:
                return provider.chat(messages, **kwargs)
            except Exception as e:
                self.logger.warning(f"Provider {type(provider).__name__} chat failed: {e}")
                if provider == providers[-1]:
                    raise ProviderException(f"All chat providers failed: {str(e)}")
        
        raise ProviderException("All chat providers failed")
    
    async def _call_llm_chat_async(
        self,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> str:
        """Call LLM chat asynchronously with fallback"""
        providers = [self.llm_provider] + self.fallback_providers
        
        for provider in providers:
            try:
                return await provider.chat_async(messages, **kwargs)
            except Exception as e:
                self.logger.warning(f"Provider {type(provider).__name__} chat failed (async): {e}")
                if provider == providers[-1]:
                    raise ProviderException(f"All async chat providers failed: {str(e)}")
        
        raise ProviderException("All async chat providers failed")


# ============================================================================
# MAIN AGENT CLASS - Clean Facade
# ============================================================================

class Agent:
    """
    Production-ready AI Agent with clean architecture.
    
    Features:
    - Clean separation of concerns (Prompt, Execution, Tools)
    - Improved error handling and logging
    - Better caching and performance
    - Full backward compatibility
    - Production-grade patterns
    
    Example:
        >>> from aiccel import Agent, OpenAIProvider
        >>> provider = OpenAIProvider(api_key="sk-...", model="gpt-4")
        >>> agent = Agent(provider=provider, verbose=True)
        >>> result = agent.run("What's the weather in London?")
        >>> print(result["response"])
    """
    
    def __init__(
        self,
        provider: LLMProvider,
        tools: Optional[Union[List[Tool], ToolRegistry]] = None,
        verbose: bool = False,
        name: Optional[str] = None,
        log_file: Optional[str] = None,
        instructions: Optional[str] = None,
        description: Optional[str] = None,
        memory_type: str = "buffer",
        max_memory_turns: int = Limits.MAX_MEMORY_TURNS,
        max_memory_tokens: int = Limits.MAX_MEMORY_TOKENS,
        strict_tool_usage: bool = False,
        fallback_providers: Optional[List[LLMProvider]] = None
    ):
        """
        Initialize Agent.
        
        Args:
            provider: Primary LLM provider
            tools: List of tools or ToolRegistry
            verbose: Enable verbose logging
            name: Agent name
            log_file: Log file path
            instructions: Agent instructions
            description: Agent description
            memory_type: Memory type ('buffer', 'window', 'summary')
            max_memory_turns: Maximum memory turns
            max_memory_tokens: Maximum memory tokens
            strict_tool_usage: Require tool usage for all queries
            fallback_providers: Fallback LLM providers
        """
        # Create and validate configuration
        self.config = AgentConfig(
            name=name or "Agent",
            description=description or "AI Agent",
            instructions=instructions or "You are a helpful AI assistant. Provide accurate and concise answers.",
            memory_type=memory_type,
            max_memory_turns=max_memory_turns,
            max_memory_tokens=max_memory_tokens,
            strict_tool_usage=strict_tool_usage,
            verbose=verbose,
            log_file=log_file
        )
        self.config.validate()
        
        # Initialize logger
        self.logger = AILogger(
            name=self.config.name,
            verbose=verbose,
            log_file=log_file,
            structured_logging=True
        )
        
        # Initialize tool registry
        self.tool_registry = self._initialize_tool_registry(provider, tools)
        
        # Initialize components
        self.tool_executor = AgentToolExecutor(
            tool_registry=self.tool_registry,
            llm_provider=provider,
            agent_logger=self.logger,
            strict_mode=strict_tool_usage
        )
        
        self.memory = ConversationMemory(
            memory_type=memory_type,
            max_turns=max_memory_turns,
            max_tokens=max_memory_tokens,
            llm_provider=provider
        )
        
        self.prompt_builder = PromptBuilder(
            config=self.config,
            tool_registry=self.tool_registry
        )
        
        self.orchestrator = ExecutionOrchestrator(
            llm_provider=provider,
            tool_executor=self.tool_executor,
            prompt_builder=self.prompt_builder,
            memory=self.memory,
            logger=self.logger,
            config=self.config,
            fallback_providers=fallback_providers or []
        )
        
        # Expose attributes for backward compatibility
        self.provider = provider
        self.name = self.config.name
        self.description = self.config.description
        self.instructions = self.config.instructions
        self.verbose = verbose
        self.thinking_enabled = self.config.thinking_enabled
        self.strict_tool_usage = strict_tool_usage
        
        # Log initialization
        if _tracing_config["enabled"]:
            self.logger.info(
                f"Tracing enabled: {_tracing_config['api_key'][:4]}... -> {_tracing_config['backend_url']}"
            )
        
        if self.verbose:
            self.logger.info(
                f"Agent '{self.name}' initialized with {len(self.tool_registry.get_all())} tools. "
                f"Strict mode: {strict_tool_usage}"
            )
    
    def _initialize_tool_registry(
        self,
        provider: LLMProvider,
        tools: Optional[Union[List[Tool], ToolRegistry]]
    ) -> ToolRegistry:
        """Initialize tool registry from various inputs"""
        if isinstance(tools, ToolRegistry):
            tools.llm_provider = provider
            return tools
        
        registry = ToolRegistry(llm_provider=provider)
        
        if isinstance(tools, list):
            registry.register_all(tools)
        
        return registry
    
    # ========================================================================
    # PUBLIC API - Main execution methods
    # ========================================================================
    
    def run(self, query: str) -> Dict[str, Any]:
        """
        Run agent with tool support.
        
        Args:
            query: User query
        
        Returns:
            Dict with response, thinking, tools_used, and tool_outputs
        
        Raises:
            ValidationException: If query is invalid
            AgentException: If agent execution fails
        """
        # Validate query
        if not query or not query.strip():
            raise ValidationException("query", ErrorMessages.INVALID_QUERY)
        
        trace_id = self.logger.trace_start("agent_run", {"query": query[:100]})
        
        try:
            # Build execution context
            context = self._build_execution_context(query, trace_id)
            
            # Execute query
            response = self.orchestrator.execute_query(query, context)
            
            # Log and return
            self.logger.trace_end(trace_id, response.to_dict())
            return response.to_dict()
            
        except Exception as e:
            self.logger.trace_error(trace_id, e, "Agent run failed")
            raise AgentException(f"Agent execution failed: {str(e)}")
    
    async def run_async(self, query: str) -> Dict[str, Any]:
        """
        Run agent asynchronously with tool support.
        
        Args:
            query: User query
        
        Returns:
            Dict with response, thinking, tools_used, and tool_outputs
        
        Raises:
            ValidationException: If query is invalid
            AgentException: If agent execution fails
        """
        # Validate query
        if not query or not query.strip():
            raise ValidationException("query", ErrorMessages.INVALID_QUERY)
        
        trace_id = self.logger.trace_start("agent_run_async", {"query": query[:100]})
        
        try:
            # Build execution context
            context = self._build_execution_context(query, trace_id)
            
            # Execute query asynchronously
            response = await self.orchestrator.execute_query_async(query, context)
            
            # Log and return
            self.logger.trace_end(trace_id, response.to_dict())
            return response.to_dict()
            
        except Exception as e:
            self.logger.trace_error(trace_id, e, "Agent async run failed")
            raise AgentException(f"Agent async execution failed: {str(e)}")
    
    def _build_execution_context(self, query: str, trace_id: int) -> ExecutionContext:
        """Build execution context for query"""
        has_tools = bool(self.tool_registry.get_all())
        relevant_tools = self.tool_executor.find_relevant_tools(query) if has_tools else []
        
        # Determine execution mode
        if not has_tools:
            mode = ExecutionMode.NO_TOOLS
        elif self.config.strict_tool_usage:
            mode = ExecutionMode.STRICT_TOOLS
        elif self.config.thinking_enabled:
            mode = ExecutionMode.THINKING
        else:
            mode = ExecutionMode.NORMAL
        
        return ExecutionContext(
            query=query,
            trace_id=trace_id,
            has_tools=has_tools,
            relevant_tools=relevant_tools,
            execution_mode=mode
        )
    
    # ========================================================================
    # FLUENT API - Chainable configuration methods
    # ========================================================================
    
    def set_verbose(self, verbose: bool = True) -> 'Agent':
        """Enable/disable verbose logging"""
        self.verbose = verbose
        self.logger.verbose = verbose
        self.config.verbose = verbose
        return self
    
    def set_instructions(self, instructions: str) -> 'Agent':
        """Set agent instructions"""
        self.instructions = instructions
        self.config.instructions = instructions
        if self.verbose:
            self.logger.info(f"Updated instructions: {instructions[:50]}...")
        return self
    
    def set_description(self, description: str) -> 'Agent':
        """Set agent description"""
        self.description = description
        self.config.description = description
        if self.verbose:
            self.logger.info(f"Updated description: {description[:50]}...")
        return self
    
    def with_tool(self, tool: Tool) -> 'Agent':
        """Add a tool to the agent"""
        self.tool_registry.register(tool)
        if self.verbose:
            self.logger.info(f"Added tool: {tool.name}")
        return self
    
    def with_tools(self, tools: List[Tool]) -> 'Agent':
        """Add multiple tools to the agent"""
        self.tool_registry.register_all(tools)
        if self.verbose:
            self.logger.info(f"Added {len(tools)} tools")
        return self
    
    def enable_thinking(self, enabled: bool = True) -> 'Agent':
        """Enable/disable thinking mode"""
        self.thinking_enabled = enabled
        self.config.thinking_enabled = enabled
        if enabled and self.verbose:
            self.logger.info("Thinking mode enabled")
        return self
    
    def clear_memory(self) -> 'Agent':
        """Clear conversation memory"""
        self.memory.clear()
        self.logger.info("Conversation memory cleared")
        return self
    
    def set_memory_type(self, memory_type: str) -> 'Agent':
        """Set memory type"""
        if memory_type not in ConversationMemory.VALID_MEMORY_TYPES:
            raise ValidationException(
                "memory_type",
                f"Invalid memory type. Must be one of: {ConversationMemory.VALID_MEMORY_TYPES}"
            )
        self.memory.memory_type = memory_type
        self.config.memory_type = memory_type
        self.logger.info(f"Memory type set to: {memory_type}")
        return self
    
    # ========================================================================
    # SIMPLE LLM CALLS - Direct LLM interaction without tools
    # ========================================================================
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=2, max=8),
        retry=retry_if_exception_type((Exception,)),
        reraise=True
    )
    def call(self, prompt: str, **kwargs) -> str:
        """Make a simple LLM call without tools"""
        trace_id = self.logger.trace_start("simple_call", {"prompt": prompt[:100]})
        
        self.logger.debug(f"Making simple call: {prompt[:50]}...")
        try:
            response = self.orchestrator._call_llm(prompt, **kwargs)
            self.logger.trace_end(trace_id, {"response": response[:100]})
            return response
        except Exception as e:
            self.logger.trace_error(trace_id, e, "Failed to generate response")
            raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=2, max=8),
        retry=retry_if_exception_type((Exception,)),
        reraise=True
    )
    async def call_async(self, prompt: str, **kwargs) -> str:
        """Make a simple async LLM call without tools"""
        trace_id = self.logger.trace_start("simple_call_async", {"prompt": prompt[:100]})
        
        self.logger.debug(f"Making async simple call: {prompt[:50]}...")
        try:
            response = await self.orchestrator._call_llm_async(prompt, **kwargs)
            self.logger.trace_end(trace_id, {"response": response[:100]})
            return response
        except Exception as e:
            self.logger.trace_error(trace_id, e, "Failed to generate async response")
            raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=2, max=8),
        retry=retry_if_exception_type((Exception,)),
        reraise=True
    )
    def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """Make a chat call"""
        trace_id = self.logger.trace_start("chat_call", {"messages_count": len(messages)})
        
        self.logger.debug(f"Making chat call with {len(messages)} messages")
        try:
            response = self.orchestrator._call_llm_chat(messages, **kwargs)
            self.logger.trace_end(trace_id, {"response": response[:100]})
            return response
        except Exception as e:
            self.logger.trace_error(trace_id, e, "Failed to process chat")
            raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=2, max=8),
        retry=retry_if_exception_type((Exception,)),
        reraise=True
    )
    async def chat_async(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """Make an async chat call"""
        trace_id = self.logger.trace_start("chat_call_async", {"messages_count": len(messages)})
        
        self.logger.debug(f"Making async chat call with {len(messages)} messages")
        try:
            response = await self.orchestrator._call_llm_chat_async(messages, **kwargs)
            self.logger.trace_end(trace_id, {"response": response[:100]})
            return response
        except Exception as e:
            self.logger.trace_error(trace_id, e, "Failed to process async chat")
            raise
    
    # ========================================================================
    # ADVANCED METHODS - Chain, batch, and multi-step reasoning
    # ========================================================================
    
    def chain(self, query: str, max_steps: int = 5) -> Dict[str, Any]:
        """
        Execute chain of reasoning with multiple steps.
        
        Args:
            query: Initial query
            max_steps: Maximum number of reasoning steps
        
        Returns:
            Dict with final response and step history
        """
        trace_id = self.logger.trace_start("agent_chain", {
            "query": query,
            "max_steps": max_steps
        })
        
        steps = []
        current_query = query
        
        for step in range(max_steps):
            self.logger.trace_step(trace_id, f"chain_step_{step+1}", {
                "current_query": current_query[:200]
            })
            
            try:
                result = self.run(current_query)
                steps.append(result)
                
                # Stop if no tools used (final answer reached)
                if not result.get("tools_used"):
                    self.logger.trace_step(trace_id, "chain_complete_no_tool", {
                        "step": step + 1,
                        "reason": "No tools used, final answer reached"
                    })
                    break
                
                # Stop if tool execution failed
                tool_outputs = result.get("tool_outputs", [])
                if not tool_outputs or any(
                    str(output).startswith("Error") for _, _, output in tool_outputs
                ):
                    self.logger.trace_step(trace_id, "chain_complete_tool_error", {
                        "step": step + 1,
                        "reason": "Tool errors encountered"
                    })
                    break
                
                # Continue reasoning with tool outputs
                output_summaries = [
                    f"{name}: {str(output)[:200]}" 
                    for name, _, output in tool_outputs
                ]
                current_query = (
                    f"Previous query: {current_query}\n"
                    f"Tool outputs: {'; '.join(output_summaries)}\n"
                    "Based on this information, provide the next step or final answer."
                )
                
                self.logger.trace_step(trace_id, f"updated_query_step_{step+1}", {
                    "updated_query": current_query[:200]
                })
            
            except Exception as e:
                self.logger.trace_error(trace_id, e, f"Chain step {step+1} failed")
                steps.append({"response": f"Error in chain step {step+1}: {str(e)}"})
                break
        
        final_result = {
            "response": steps[-1]["response"] if steps else "Error: No steps completed",
            "steps": steps,
            "num_steps": len(steps)
        }
        
        self.logger.trace_end(trace_id, {
            "final_response": final_result["response"][:100],
            "num_steps": len(steps)
        })
        
        return final_result
    
    async def chain_async(self, query: str, max_steps: int = 5) -> Dict[str, Any]:
        """
        Execute chain of reasoning with multiple steps asynchronously.
        
        Args:
            query: Initial query
            max_steps: Maximum number of reasoning steps
        
        Returns:
            Dict with final response and step history
        """
        trace_id = self.logger.trace_start("agent_chain_async", {
            "query": query,
            "max_steps": max_steps
        })
        
        steps = []
        current_query = query
        
        for step in range(max_steps):
            self.logger.trace_step(trace_id, f"chain_step_{step+1}_async", {
                "current_query": current_query[:200]
            })
            
            try:
                result = await self.run_async(current_query)
                steps.append(result)
                
                # Stop conditions
                if not result.get("tools_used"):
                    self.logger.trace_step(trace_id, "chain_complete_no_tool_async", {
                        "step": step + 1,
                        "reason": "No tools used"
                    })
                    break
                
                tool_outputs = result.get("tool_outputs", [])
                if not tool_outputs or any(
                    str(output).startswith("Error") for _, _, output in tool_outputs
                ):
                    self.logger.trace_step(trace_id, "chain_complete_tool_error_async", {
                        "step": step + 1,
                        "reason": "Tool errors"
                    })
                    break
                
                # Build next query
                output_summaries = [
                    f"{name}: {str(output)[:200]}" 
                    for name, _, output in tool_outputs
                ]
                current_query = (
                    f"Previous query: {current_query}\n"
                    f"Tool outputs: {'; '.join(output_summaries)}\n"
                    "Provide the next step or final answer."
                )
                
            except Exception as e:
                self.logger.trace_error(trace_id, e, f"Chain step {step+1} failed (async)")
                steps.append({"response": f"Error in chain step {step+1}: {str(e)}"})
                break
        
        final_result = {
            "response": steps[-1]["response"] if steps else "Error: No steps completed",
            "steps": steps,
            "num_steps": len(steps)
        }
        
        self.logger.trace_end(trace_id, {
            "final_response": final_result["response"][:100],
            "num_steps": len(steps)
        })
        
        return final_result
    
    def batch(self, queries: List[str]) -> List[Dict[str, Any]]:
        """
        Process multiple queries in batch.
        
        Args:
            queries: List of queries to process
        
        Returns:
            List of results
        """
        trace_id = self.logger.trace_start("batch_processing", {
            "num_queries": len(queries)
        })
        
        results = []
        for i, query in enumerate(queries):
            self.logger.trace_step(trace_id, f"batch_query_{i+1}", {"query": query[:100]})
            
            try:
                result = self.run(query)
                results.append(result)
                
                self.logger.trace_step(trace_id, f"batch_result_{i+1}", {
                    "response": result["response"][:100],
                    "tools_used": result.get("tools_used")
                })
            except Exception as e:
                self.logger.trace_error(trace_id, e, f"Batch query {i+1} failed")
                results.append({
                    "response": f"Error processing query: {str(e)}",
                    "error": str(e)
                })
        
        self.logger.trace_end(trace_id, {"num_results": len(results)})
        return results
    
    async def batch_async(self, queries: List[str]) -> List[Dict[str, Any]]:
        """
        Process multiple queries in batch asynchronously.
        
        Args:
            queries: List of queries to process
        
        Returns:
            List of results
        """
        trace_id = self.logger.trace_start("batch_processing_async", {
            "num_queries": len(queries)
        })
        
        # Create tasks for all queries
        tasks = [self.run_async(query) for query in queries]
        
        # Gather results
        results = []
        for i, task in enumerate(await asyncio.gather(*tasks, return_exceptions=True)):
            if isinstance(task, Exception):
                self.logger.trace_error(trace_id, task, f"Batch query {i+1} failed")
                results.append({
                    "response": f"Error processing query: {str(task)}",
                    "error": str(task)
                })
            else:
                results.append(task)
                self.logger.trace_step(trace_id, f"batch_result_{i+1}_async", {
                    "response": task["response"][:100],
                    "tools_used": task.get("tools_used")
                })
        
        self.logger.trace_end(trace_id, {"num_results": len(results)})
        return results
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def visualize_trace(self, trace_id: int) -> str:
        """
        Visualize a trace for debugging.
        
        Args:
            trace_id: ID of the trace to visualize
        
        Returns:
            Formatted trace string
        """
        trace = self.logger.get_trace(trace_id)
        if not trace:
            return f"Invalid trace ID: {trace_id}"
        
        output = [
            "=" * 80,
            f"Trace #{trace_id}: {trace['action']}",
            "=" * 80,
            f"Started: {trace['start_time']}",
            f"Duration: {trace.get('duration_ms', 0):.2f}ms",
            f"Errors: {len(trace.get('errors', []))}",
            "",
            "Inputs:",
            "-" * 80,
            orjson.dumps(trace['inputs'], option=orjson.OPT_INDENT_2).decode('utf-8'),
            "",
            "Execution Steps:",
            "-" * 80,
        ]
        
        for i, step in enumerate(trace.get('steps', []), 1):
            output.append(f"{i}. {step['name']} @ {step['time']}")
            if step.get('details'):
                details = orjson.dumps(step['details'], option=orjson.OPT_INDENT_2).decode('utf-8')
                output.append(f"   {details}")
        
        if trace.get("errors"):
            output.extend([
                "",
                "Errors:",
                "-" * 80,
            ])
            for i, error in enumerate(trace["errors"], 1):
                output.append(f"{i}. {error['context']} @ {error['time']}")
                output.append(f"   Type: {error['error_type']}")
                output.append(f"   Message: {error['error_message']}")
                if error.get('stack_trace'):
                    output.append(f"   Stack (first 5 lines):")
                    for line in error['stack_trace'][:5]:
                        output.append(f"      {line.strip()}")
        
        output.extend([
            "",
            "Outputs:",
            "-" * 80,
            orjson.dumps(trace.get('outputs', {}), option=orjson.OPT_INDENT_2).decode('utf-8'),
            "=" * 80
        ])
        
        return "\n".join(output)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get agent statistics"""
        return {
            "name": self.name,
            "description": self.description,
            "config": {
                "strict_tool_usage": self.config.strict_tool_usage,
                "thinking_enabled": self.config.thinking_enabled,
                "memory_type": self.config.memory_type,
                "max_memory_turns": self.config.max_memory_turns,
                "max_memory_tokens": self.config.max_memory_tokens,
            },
            "tools": {
                "count": len(self.tool_registry.get_all()),
                "names": [t.name for t in self.tool_registry.get_all()],
            },
            "memory": self.memory.get_stats(),
            "cache": {
                "tool_cache_size": len(self.tool_executor.tool_cache),
                "prompt_cache_size": len(self.prompt_builder._prompt_cache),
            },
            "failures": {
                "tool_failures": dict(self.tool_executor.tool_failure_count),
            }
        }
    
    def reset_tool_failures(self) -> None:
        """Reset all tool failure counters"""
        self.tool_executor.tool_failure_count.clear()
        self.logger.info("Reset all tool failure counters")
    
    def get_tool_info(self) -> List[Dict[str, Any]]:
        """Get information about all registered tools"""
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "examples": tool.example_usages,
                "failures": self.tool_executor.tool_failure_count.get(tool.name, 0),
            }
            for tool in self.tool_registry.get_all()
        ]
    
    # ========================================================================
    # FACTORY METHODS
    # ========================================================================
    
    @classmethod
    def from_provider(
        cls,
        provider: LLMProvider,
        name: Optional[str] = None,
        verbose: bool = False,
        log_file: Optional[str] = None,
        instructions: Optional[str] = None,
        description: Optional[str] = None,
        memory_type: str = "buffer",
        max_memory_turns: int = Limits.MAX_MEMORY_TURNS,
        max_memory_tokens: int = Limits.MAX_MEMORY_TOKENS,
        fallback_providers: Optional[List[LLMProvider]] = None
    ) -> 'Agent':
        """
        Create agent from provider without tools.
        
        Example:
            >>> provider = OpenAIProvider(api_key="sk-...", model="gpt-4")
            >>> agent = Agent.from_provider(provider, name="SimpleAgent")
        """
        return cls(
            provider=provider,
            tools=None,
            verbose=verbose,
            name=name,
            log_file=log_file,
            instructions=instructions,
            description=description,
            memory_type=memory_type,
            max_memory_turns=max_memory_turns,
            max_memory_tokens=max_memory_tokens,
            fallback_providers=fallback_providers
        )
    
    @classmethod
    def create_search_agent(
        cls,
        provider: LLMProvider,
        search_api_key: str,
        name: str = "SearchAgent",
        **kwargs
    ) -> 'Agent':
        """
        Create a pre-configured search agent.
        
        Example:
            >>> from aiccel import Agent, OpenAIProvider
            >>> from aiccel.tools import SearchTool
            >>> provider = OpenAIProvider(api_key="sk-...", model="gpt-4")
            >>> agent = Agent.create_search_agent(
            ...     provider=provider,
            ...     search_api_key="serper-key"
            ... )
        """
        from .tools import SearchTool
        
        search_tool = SearchTool(api_key=search_api_key)
        
        return cls(
            provider=provider,
            tools=[search_tool],
            name=name,
            instructions="You are a search agent. Use the search tool to find current information.",
            description="Agent specialized in web search and information retrieval",
            **kwargs
        )
    
    @classmethod
    def create_weather_agent(
        cls,
        provider: LLMProvider,
        weather_api_key: str,
        name: str = "WeatherAgent",
        **kwargs
    ) -> 'Agent':
        """
        Create a pre-configured weather agent.
        
        Example:
            >>> agent = Agent.create_weather_agent(
            ...     provider=provider,
            ...     weather_api_key="openweather-key"
            ... )
        """
        from .tools import WeatherTool
        
        weather_tool = WeatherTool(api_key=weather_api_key)
        
        return cls(
            provider=provider,
            tools=[weather_tool],
            name=name,
            instructions="You are a weather agent. Use the weather tool to provide weather information.",
            description="Agent specialized in weather forecasting",
            **kwargs
        )
    
    # ========================================================================
    # BACKWARD COMPATIBILITY METHODS
    # ========================================================================
    
    def log(self, message: str, exc_info: Optional[Exception] = None) -> None:
        """Log a message (backward compatibility)"""
        if exc_info:
            self.logger.error(message, exc_info=exc_info)
        else:
            self.logger.info(message)
    
    def sync_tools_to_registry(self) -> 'Agent':
        """Sync tools to registry (backward compatibility - no-op in new version)"""
        self.logger.info(
            f"Tool registry already synchronized with {len(self.tool_registry.get_all())} tools"
        )
        return self
    
    # ========================================================================
    # CONTEXT MANAGERS
    # ========================================================================
    
    def __enter__(self) -> 'Agent':
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit"""
        # Cleanup if needed
        pass
    
    async def __aenter__(self) -> 'Agent':
        """Async context manager entry"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit"""
        pass
    
    # ========================================================================
    # STRING REPRESENTATION
    # ========================================================================
    
    def __repr__(self) -> str:
        """String representation"""
        return (
            f"Agent(name='{self.name}', "
            f"tools={len(self.tool_registry.get_all())}, "
            f"strict_tool_usage={self.strict_tool_usage})"
        )
    
    def __str__(self) -> str:
        """Human-readable string"""
        tools_str = ", ".join(t.name for t in self.tool_registry.get_all()) or "None"
        return (
            f"Agent: {self.name}\n"
            f"Description: {self.description}\n"
            f"Tools: {tools_str}\n"
            f"Strict mode: {self.strict_tool_usage}\n"
            f"Memory: {self.config.memory_type} ({self.config.max_memory_turns} turns)"
        )


# ============================================================================
# EXPORTS
# ============================================================================

__all__ = [
    'Agent',
    'AgentConfig',
    'AgentResponse',
    'ExecutionContext',
    'ExecutionMode',
    'AgentToolExecutor',
    'PromptBuilder',
    'ExecutionOrchestrator',
    'init_tracing',
    'ConversationMemory',
]