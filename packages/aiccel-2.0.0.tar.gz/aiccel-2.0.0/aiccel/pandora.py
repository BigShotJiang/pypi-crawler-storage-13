import pandas as pd
import json
import numpy as np
import re
import ast
import traceback
import io
import contextlib
import random
import string
import datetime
import math
from typing import Union, Dict, Any, List, Optional
from pathlib import Path

from .providers import LLMProvider

class Pandora:
    def __init__(self, llm: LLMProvider, max_retries: int = 4, verbose: bool = True):
        self.llm = llm
        self.max_retries = max_retries
        self.verbose = verbose

    def do(
        self,
        source: Union[str, Path, pd.DataFrame],
        instruction: str,
        safe_mode: bool = False
    ) -> pd.DataFrame:
        """
        Executes instructions on a DataFrame.
        """
        # 1. Load Data
        try:
            df = source.copy() if isinstance(source, pd.DataFrame) else self._load(source)
        except Exception as e:
            if safe_mode:
                print(f"Pandora Load Error: {e}")
                return pd.DataFrame()
            raise e

        original_df = df.copy() # Keep backup

        # 2. Generate Rich Context
        profile = self._profile_data(df)
        
        last_error = None
        history = []
        last_code_output = ""

        for attempt in range(self.max_retries + 1):
            try:
                # 3. Construct Prompt
                if attempt == 0 or not history:
                    prompt = self._build_initial_prompt(profile, instruction)
                else:
                    prompt = self._build_repair_prompt(
                        instruction, 
                        history[-1], 
                        last_error, 
                        last_code_output
                    )

                # 4. LLM Generation
                if self.verbose:
                    print(f"--- Pandora Thinking (Attempt {attempt+1}/{self.max_retries+1}) ---")
                
                # Using a slightly longer context window just in case
                raw_response = self.llm.generate(prompt, temperature=0.0, max_tokens=6000)
                code = self._extract_code(raw_response)
                history.append(code)

                # 5. Syntax Check
                ast.parse(code) 

                # 6. Prepare Execution Environment
                output_buffer = io.StringIO()
                
                # CRITICAL FIX: These variables must be in the GLOBAL scope of the exec
                # for list comprehensions and functions to see them.
                execution_scope = {
                    "df": df.copy(), 
                    "pd": pd,
                    "np": np,
                    "re": re,
                    "random": random,
                    "string": string,
                    "datetime": datetime,
                    "math": math,
                    "json": json
                }

                # 7. Execute with Output Capture
                with contextlib.redirect_stdout(output_buffer):
                    # Pass execution_scope as GLOBALS (2nd arg), not LOCALS (3rd arg)
                    exec(code, execution_scope)
                
                # 8. Validation
                result_df = execution_scope.get("df")
                
                if not isinstance(result_df, pd.DataFrame):
                    raise ValueError("The code executed but `df` variable was lost or is no longer a DataFrame.")
                
                if self.verbose:
                    print("--- Pandora Success ---")
                
                return result_df

            except Exception as e:
                last_code_output = output_buffer.getvalue() if 'output_buffer' in locals() else ""
                
                last_error = f"{type(e).__name__}: {str(e)}"
                if not isinstance(e, SyntaxError):
                    tb = traceback.format_exc().split('\n')
                    last_error += "\n" + "\n".join(tb[-4:])
                
                if self.verbose:
                    print(f"Pandora Error (Attempt {attempt+1}): {last_error}")
                
                continue

        # Failure Handling
        msg = f"Pandora failed to transform data after {self.max_retries} attempts."
        if safe_mode:
            print(f"WARNING: {msg} Returning original DataFrame.")
            return original_df
        else:
            raise RuntimeError(f"{msg}\nLast Error: {last_error}")

    def _profile_data(self, df: pd.DataFrame) -> Dict:
        """Generates a concise statistical profile."""
        profile = {
            "shape": df.shape,
            "columns": {},
        }
        
        for col in df.columns[:20]: 
            dtype = str(df[col].dtype)
            col_info = {"dtype": dtype}
            try:
                col_info["samples"] = df[col].dropna().sample(min(3, len(df))).tolist()
            except:
                col_info["samples"] = df[col].head(3).tolist()

            if np.issubdtype(df[col].dtype, np.number):
                if not df[col].empty:
                    col_info["min"] = float(df[col].min())
                    col_info["max"] = float(df[col].max())
            elif df[col].dtype == 'object' or df[col].dtype.name == 'category':
                col_info["unique_count"] = int(df[col].nunique())
            
            profile["columns"][col] = col_info
        return profile

    def _build_initial_prompt(self, profile: Dict, instruction: str) -> str:
        return f"""
You are PANDORA, an elite Data Engineer AI.
Your goal: Transform the pandas DataFrame `df` based on the User Instruction.

DATA PROFILE:
{json.dumps(profile, indent=2, default=str)}

USER INSTRUCTION:
"{instruction}"

LIBRARIES AVAILABLE:
pandas (pd), numpy (np), re, random, string, datetime, math, json.

RULES:
1. The input dataframe is in the global variable `df`.
2. You MUST modify `df` in place or assign the result back to `df`.
3. Do NOT use markdown or ```python``` blocks. Just raw code.
4. If masking data, use `random` to ensure uniqueness if required.
5. Ensure `df` remains a pandas DataFrame at the end.

Start your code now:
"""

    def _build_repair_prompt(self, instruction, bad_code, error, output) -> str:
        return f"""
The previous code attempt failed.

USER INSTRUCTION: "{instruction}"

FAILED CODE:
{bad_code}

EXECUTION OUTPUT (STDOUT):
{output}

ERROR MESSAGE:
{error}

TASK:
Fix the code logic.
1. If NameError 'df' not defined: Ensure you aren't deleting it.
2. If IndexError: Check column names in Data Profile.
3. Return the FULL, CORRECTED Python script.
"""

    def _extract_code(self, text: str) -> str:
        text = text.strip()
        match = re.search(r"```(?:python)?\n(.*?)```", text, re.DOTALL)
        if match:
            return match.group(1)
        return text

    def _load(self, path):
        p = Path(path)
        if p.suffix == ".csv": return pd.read_csv(p)
        if p.suffix in [".xlsx", ".xls"]: return pd.read_excel(p)
        if p.suffix == ".parquet": return pd.read_parquet(p)
        if p.suffix == ".json": return pd.read_json(p)
        raise ValueError(f"Unsupported file format: {p}")