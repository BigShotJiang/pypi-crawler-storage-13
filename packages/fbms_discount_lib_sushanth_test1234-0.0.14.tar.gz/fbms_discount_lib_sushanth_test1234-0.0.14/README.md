# fbms_discount_lib_sushanth_test1234

A simple reusable Python library that:
- Calls AWS API Gateway to get active festival offers
- Calculates discounted prices

## Functions

### `OfferAPIClient()`
Fetches offer from API Gateway.

### `calculate_discount(price, festival)`
Applies discount for the provided festival.

