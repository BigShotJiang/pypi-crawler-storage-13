"""Festival-based discount calculator library"""

from .fest_discount import calculate_discount
from .api_gateway_client import OfferAPIClient

__version__ = "0.0.14"
__all__ = ["calculate_discount", "OfferAPIClient"]

