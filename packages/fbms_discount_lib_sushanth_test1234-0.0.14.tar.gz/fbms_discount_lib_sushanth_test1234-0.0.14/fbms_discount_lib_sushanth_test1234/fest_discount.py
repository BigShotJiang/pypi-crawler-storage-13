from decimal import Decimal, ROUND_HALF_UP

def calculate_discount(price, festival_name):
    """Return discounted price based on festival"""
    discounts = {
        "Diwali": Decimal("0.20"),
        "Christmas": Decimal("0.25"),
        "New Year": Decimal("0.30"),
        "Pongal": Decimal("0.15"),
        "Easter": Decimal("0.10"),
        "Valentine's Day": Decimal("0.12"),
        "Summer Sale": Decimal("0.18"),
        "Halloween": Decimal("0.10"),
        "Black Friday": Decimal("0.35"),
        "Cyber Monday": Decimal("0.28"),
        "Women's Day": Decimal("0.08"),
        "Bakery Anniversary Sale": Decimal("0.20"),
    }

    discount_rate = discounts.get(festival_name, Decimal("0"))
    price = Decimal(str(price))

    discounted_price = price - (price * discount_rate)

    return float(discounted_price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

