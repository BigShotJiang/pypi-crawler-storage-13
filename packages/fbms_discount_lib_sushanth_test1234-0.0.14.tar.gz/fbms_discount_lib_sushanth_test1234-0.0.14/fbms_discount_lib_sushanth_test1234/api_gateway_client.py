import requests

class OfferAPIClient:

    def __init__(self, api_gateway_url="https://at8ta159m3.execute-api.us-east-1.amazonaws.com/prod/offers"):
        self.api_gateway_url = api_gateway_url

    def get_offer(self, offer_name: str = None):
        """
        Fetch offer details using API Gateway.

        - If offer_name is provided → return that offer
        - If offer_name is missing → return active/default offer
        """
        try:
            params = {"name": offer_name} if offer_name else {}
            response = requests.get(self.api_gateway_url, params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

