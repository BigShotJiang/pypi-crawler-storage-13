# Contributing

Contributions are welcome, and they are greatly appreciated! Every little bit helps, and credit will always be given.

## Submit Feedback

If you are proposing a feature:

- Explain in detail how it would work.
- Keep the scope as narrow as possible, to make it easier to implement.

## Get Started

Ready to contribute? Here's how to set up `opsgenielib` for local development.

### 1. Clone the repository

```bash
git clone https://sbp.gitlab.schubergphilis.com/SaaS/opsgenielib
cd opsgenielib
```

### 2. Install dependencies

This project uses [uv](https://docs.astral.sh/uv/) for dependency management:

```bash
uv sync
```

### 3. Create a branch for local development

```bash
git checkout -b name-of-your-bugfix-or-feature
```

Now you can make your changes locally.

### 4. Test your changes

Run the test suite:

```bash
uv run pytest
```

Run linting:

```bash
uv run prospector
```

Make sure all tests pass and there are no linting errors.

### 5. Commit your changes

```bash
git add .
git commit -m "Your detailed description of your changes."
git push origin name-of-your-bugfix-or-feature
```

### 6. Submit a merge request

Go to the repository and create a merge request with your changes.

## Development Guidelines

- Write tests for new features
- Update documentation as needed
- Follow the existing code style
- Keep commits focused and atomic
- Write clear commit messages

## Code Style

This project uses:
- `prospector` for linting
- Python 3.8+ features
- Type hints where appropriate

Run linting before committing:

```bash
uv run prospector
```

## Testing

Run the full test suite:

```bash
uv run pytest
```

Run tests with coverage:

```bash
uv run pytest --cov=opsgenielib --cov-report=html
```

## Questions?

Feel free to open an issue if you have any questions!
