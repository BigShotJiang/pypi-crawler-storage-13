"""Cloud security modules"""
