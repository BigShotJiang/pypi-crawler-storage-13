# Changelog

## 0.1.1 (2025-11-12)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/botbrains-io/commerce-shopper-products/compare/v0.1.0...v0.1.1)

### Bug Fixes

* compat with Python 3.14 ([81d2bdf](https://github.com/botbrains-io/commerce-shopper-products/commit/81d2bdfe301de62331bc17f9eb9b0f2d9ebfe82f))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([97ef538](https://github.com/botbrains-io/commerce-shopper-products/commit/97ef538a8aa8b580b2191f89534719bc3f2597e3))


### Chores

* **package:** drop Python 3.8 support ([0c5bda5](https://github.com/botbrains-io/commerce-shopper-products/commit/0c5bda52a882c5cdc912bac87b7499567b066b8e))

## 0.1.0 (2025-11-07)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/botbrains-io/commerce-shopper-products/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([375d12f](https://github.com/botbrains-io/commerce-shopper-products/commit/375d12fd1e42807849a62341f3dd5184dd93b54b))
* **api:** manual updates ([a1d4f04](https://github.com/botbrains-io/commerce-shopper-products/commit/a1d4f0416d1bfba9b9cc8596393db6b19be17899))
* **api:** manual updates ([a0e43f1](https://github.com/botbrains-io/commerce-shopper-products/commit/a0e43f1160b4c2d70d6b922247af2b887a62c90e))


### Chores

* update SDK settings ([da78dbc](https://github.com/botbrains-io/commerce-shopper-products/commit/da78dbce4473fd24e1a8a7412a4b5ef94e0d649e))
* update SDK settings ([4556e46](https://github.com/botbrains-io/commerce-shopper-products/commit/4556e464355f61019a805fa814b317bb015a9c6a))
