from collections import defaultdict
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json, config
from intervaltree import IntervalTree

from ..common.wsclient.dataclasses_helpers import datetime_metadata
from .duration_hour_minute import DurationHourMinute

import datetime
import json


@dataclass_json
@dataclass
class OTMV(object):

    traffic_volume: str = field(metadata=config(field_name='trafficVolume'))
    duration_min: int = field(metadata=config(field_name='duration'))
    sustain: int = field(metadata=config(field_name='sustain'))
    peak: int = field(metadata=config(field_name='peak'))

    @property
    def duration(self) -> DurationHourMinute:
        return DurationHourMinute(minutes=self.duration_min)


@dataclass_json
@dataclass
class PlannedOTMV(object):

    applicability_unt : datetime.datetime = field(metadata=datetime_metadata(field_name='applicabilityUnt'))
    applicability_wef : datetime.datetime = field(metadata=datetime_metadata(field_name='applicabilityWef'))
    data_source : str = field(metadata=config(field_name='dataSource'))
    otmv_duration: str = field(metadata=config(field_name='otmvDuration'))
    peak: int
    plan_schedule: str = field(metadata=config(field_name='planSchedule'))
    sustained: int
    traffic_volume: str = field(metadata=config(field_name='trafficVolume'))
    
    @property
    def duration(self) -> DurationHourMinute:
        return DurationHourMinute.from_string(self.otmv_duration)

    @property
    def sustain(self) -> int:
        return self.sustained


class OTMVPlan(object):
    
    def __init__(self, planned_otmvs: list[PlannedOTMV]) -> None:
        self.__planned_otmvs = IntervalTree()
        for planned in planned_otmvs:
            wef = planned.applicability_wef.timestamp()
            unt = planned.applicability_unt.timestamp()
            overlaps = self.__planned_otmvs[wef:unt]
            if overlaps:
                raise ValueError(f"Overlapping detected for {planned}")
            self.__planned_otmvs[wef:unt] = planned

    def get(self, dt: datetime.datetime) -> PlannedOTMV | None:
        timestamp = dt.timestamp()
        matches = self.__planned_otmvs[timestamp]
        if not matches:
            return None
        return next(iter(matches)).data

class OTMVPlans(object):

    def __init__(self, dict: dict[str, list[PlannedOTMV]]) -> None:
        self.otmv_plans = {
            tv: OTMVPlan(planned_otmvs)
            for tv, planned_otmvs in dict.items()
        }
    
    def __getitem__(self, tv: str) -> OTMVPlan:
        return self.otmv_plans[tv]


def dump_otmvs_to_json(file, otmvs) -> None:
    file.write(OTMV.schema().dumps(otmvs, many=True, indent=4)) # type: ignore

def load_otmvs_from_json(file) -> list[OTMV]:
    # It is so awful but it works !
    contents = json.loads(file.read())
    return [OTMV.from_json(json.dumps(d)) for d in contents] # type: ignore

def dump_planned_otmvs_to_json(file, planned_otmvs) -> None:
    file.write(PlannedOTMV.schema().dumps(planned_otmvs, many=True, indent=4)) # type: ignore

def load_planned_otmvs_from_json(file) -> dict[str, list[PlannedOTMV]]:
    # It is so awful but it works !
    contents = json.loads(file.read())
    planned_otmvs = [PlannedOTMV.from_json(json.dumps(d)) for d in contents] # type: ignore
    result = defaultdict(list)
    for planned_otmv in planned_otmvs:
        result[planned_otmv.traffic_volume].append(planned_otmv)
    return result
