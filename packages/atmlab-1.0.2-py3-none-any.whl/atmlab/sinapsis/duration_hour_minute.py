from datetime import datetime, timedelta

class DurationHourMinute:

    def __init__(self, hours: int = 0, minutes: int = 0, seconds: int = 0) -> None:
        """Initialize with seconds."""
        self._seconds = hours * 3600 + minutes * 60 + seconds

    @classmethod
    def from_datetime(cls, start: datetime, end: datetime) -> "DurationHourMinute":
        """Create from two datetime objects."""
        seconds = int((end - start).total_seconds())
        return cls(seconds = seconds)

    @classmethod
    def from_string(cls, duration_str: str) -> "DurationHourMinute":
        """Create from a string in 'HHMM' format."""
        hours = int(duration_str[:2])
        minutes = int(duration_str[2:4])
        return cls(hours = hours, minutes = minutes)

    @classmethod
    def from_timedelta(cls, delta: timedelta) -> "DurationHourMinute":
        """Create from a timedelta object."""
        return cls(seconds = int(delta.total_seconds()))

    def to_timedelta(self) -> timedelta:
        """Return as a timedelta object."""
        return timedelta(seconds=self._seconds)

    # def __eq__(self, other) -> bool:
    #     return isinstance(other, DurationHourMinute) and self._seconds == other._seconds

    # def __hash__(self) -> int:
    #     return hash(self._seconds)

    def __str__(self) -> str:
        hours, remainder = divmod(self._seconds, 3600)
        minutes = remainder // 60
        return f"{hours:02d}{minutes:02d}"

    def __repr__(self) -> str:
        hours, remainder = divmod(self._seconds, 3600)
        minutes = remainder // 60
        return f"DurationHourMinute(hours={hours}, minutes={minutes})"
