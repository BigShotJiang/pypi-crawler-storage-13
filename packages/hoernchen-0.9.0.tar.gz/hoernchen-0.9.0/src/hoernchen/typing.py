from typing import TypeVar, NewType, Literal, Union, Protocol, ClassVar, Any, Type
import dataclasses
from datetime import datetime
from decimal import Decimal

class Dataclass(Protocol):
    __dataclass_fields__: ClassVar[dict[str, dataclasses.Field[Any]]]

T = TypeVar("T", bound=Dataclass)

Q = TypeVar("Q")
V = TypeVar("V")
StoreID = NewType("StoreID", int)

JoinHow = Literal["inner", "left"]
Operator = Literal["<", "<=", "=", "!=", ">=", ">", "and", "or"]
Order = Literal["asc", "desc"]
