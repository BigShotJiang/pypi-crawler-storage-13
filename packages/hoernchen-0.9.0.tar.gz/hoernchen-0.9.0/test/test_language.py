import hoernchen.language
import dataclasses

@dataclasses.dataclass
class A:
    a: str
    b: int


def test_1():
    table = hoernchen.language.Table.from_dataclass_type(A)
    assert table.columns[0].type.handles is str
    assert table.columns[0].type.sqlite_type == "TEXT"
    assert table.columns[1].type.handles is int
    assert table.columns[1].type.sqlite_type == "INTEGER"
