import os
import json
from datetime import datetime

class AutoResume:
    """
    AutoResume: Crash-safe sequential model executor.
    Automatically resumes at the first unfinished model after a crash.
    """

    def __init__(self, name):
        self.name = name
        self.base = os.path.expanduser(f"~/.autoresume/{name}")
        os.makedirs(self.base, exist_ok=True)
        self.status_file = os.path.join(self.base, "status.json")
        self._load_status()

    def _load_status(self):
        if os.path.exists(self.status_file):
            with open(self.status_file, "r") as f:
                self.status = json.load(f)
        else:
            self.status = {"completed": []}
            self._save_status()

    def _save_status(self):
        with open(self.status_file, "w") as f:
            json.dump(self.status, f, indent=4)

    def run(self, models, train_fn):
        """
        models: list of models to run
        train_fn: function that trains a model and returns results
        """
        for idx, model in enumerate(models):
            if idx in self.status["completed"]:
                print(f"⏩ Skipping model {idx} (already completed)")
                continue

            print(f"🚀 Running model {idx}...")
            try:
                result = train_fn(model)

                # Save model result
                with open(os.path.join(self.base, f"model_{idx}_result.json"), "w") as f:
                    json.dump({"result": result}, f, indent=4)

                # Mark as completed
                self.status["completed"].append(idx)
                self._save_status()

                print(f"✅ Completed model {idx}")

            except Exception as e:
                print(f"❌ Crash on model {idx}: {e}")
                print("⚠️ Progress saved. Will resume here next time.")
                break

