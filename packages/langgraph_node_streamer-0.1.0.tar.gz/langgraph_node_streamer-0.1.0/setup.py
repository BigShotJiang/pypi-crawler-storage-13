"""Setup configuration for langgraph-node-streamer package."""

from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="langgraph-node-streamer",
    version="0.1.0",
    author="Md Rakibul Haque",
    author_email="remon.rakibul.star@gmail.com",
    description="Node-level streaming for LangGraph graphs",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/remon-rakibul/langgraph-node-streamer",
    packages=["langgraph_node_streamer"],
    package_dir={"langgraph_node_streamer": "."},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "langchain-core>=0.3.0",
        "langgraph>=0.2.0",
        "typing-extensions>=4.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
    },
)

