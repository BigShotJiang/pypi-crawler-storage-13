"""
LangGraph Node-Level Streamer

A Python package that enables node-level streaming in LangGraph graphs,
providing faster and more direct access to LLM output chunks compared to
graph-level streaming.
"""

from .node_streamer import create_streaming_node, StreamingNode

__version__ = "0.1.0"
__all__ = ["create_streaming_node", "StreamingNode"]

