"""
Core node-level streaming implementation for LangGraph.

This module provides a reusable async generator function that enables
node-level streaming in LangGraph graphs, allowing chunks to be yielded
directly from the LLM without waiting for graph-level event processing.
"""

from typing import AsyncGenerator, Any, Optional, List, Callable
from langchain_core.messages import AIMessage, AIMessageChunk
from langchain_core.runnables import RunnableConfig
import json
import uuid


def create_streaming_node(
    llm_chain: Any,
    tool_names: Optional[List[str]] = None,
    state_key: str = "messages"
) -> Callable[[dict, RunnableConfig], AsyncGenerator[Any, None]]:
    """
    Creates a streaming node function for LangGraph that yields chunks at the node level.
    
    This function returns an async generator function that can be used as a LangGraph node.
    It streams chunks directly from the LLM, providing lower latency compared to
    graph-level streaming.
    
    Args:
        llm_chain: The LangChain LLM chain or runnable that supports astream().
                  Should accept messages and config, and return async iterator of chunks.
        tool_names: Optional list of tool names for validation. If provided, tool calls
                   will only be processed if the tool name is in this list.
        state_key: The key in the state dictionary that contains the messages list.
                  Defaults to "messages".
    
    Returns:
        An async generator function that can be used as a LangGraph node.
        The function signature is: async def node(state, config) -> AsyncGenerator
        
    Example:
        >>> from langgraph_node_streamer import create_streaming_node
        >>> from langchain_openai import ChatOpenAI
        >>> 
        >>> llm = ChatOpenAI(model="gpt-4", streaming=True)
        >>> streaming_node = create_streaming_node(llm)
        >>> 
        >>> # Use in LangGraph
        >>> graph.add_node("llm", streaming_node)
    """
    
    async def streaming_node(state: dict, config: RunnableConfig) -> AsyncGenerator[Any, None]:
        """
        Streaming node that yields chunks directly from the LLM.
        
        This node:
        1. Streams chunks from the LLM as they arrive
        2. Yields each chunk immediately (node-level streaming)
        3. Collects full content and tool calls
        4. Yields final state updates with complete messages
        
        Args:
            state: The graph state dictionary
            config: RunnableConfig for the LLM invocation
            
        Yields:
            - Individual chunks as they arrive from the LLM
            - Final state updates with complete messages
        """
        messages = state.get(state_key, [])
        ai_message_chunks = []
        full_content = ''
        
        # Stream chunks from the LLM
        async for chunk in llm_chain.astream(messages, config):
            # Yield chunk immediately for node-level streaming
            yield chunk
            
            # Collect chunks for final message construction
            if isinstance(chunk, AIMessageChunk):
                if chunk.tool_calls or chunk.invalid_tool_calls:
                    ai_message_chunks.append(chunk)
                full_content += chunk.content
        
        # Yield final content message if there's content
        if full_content != '':
            response = AIMessage(content=full_content)
            yield {state_key: [response]}
        
        # Handle tool calls if present
        if ai_message_chunks and ai_message_chunks[0].tool_calls:
            tool_calls = [{"id": str(uuid.uuid4()), "type": "tool_call"}]
            args = ''
            
            for chunk in ai_message_chunks:
                try:
                    # Extract tool call information from chunk
                    tool_call_data = chunk.additional_kwargs.get('tool_calls', [])
                    if tool_call_data:
                        function_data = tool_call_data[0].get('function', {})
                        name = function_data.get('name')
                        
                        # Validate tool name if tool_names provided
                        if name and (tool_names is None or name in tool_names):
                            tool_calls[0]['name'] = name
                        
                        # Accumulate arguments (may be split across chunks)
                        args += function_data.get('arguments', '')
                except Exception as e:
                    # Log error but continue processing
                    print(f"Error extracting tool call: {e}")
            
            # Parse accumulated arguments
            try:
                tool_calls[0]['args'] = json.loads(args) if args else {}
            except json.JSONDecodeError as e:
                print(f"JSON decoding error: {e}")
                tool_calls[0]['args'] = {}
            
            # Create tool call message
            response = AIMessage(
                content="",
                tool_calls=tool_calls
            )
            yield {state_key: [response]}
    
    return streaming_node


class StreamingNode:
    """
    Class-based interface for creating streaming nodes.
    
    This provides an alternative to the functional approach, allowing
    you to configure the streaming node as a class instance.
    """
    
    def __init__(
        self,
        llm_chain: Any,
        tool_names: Optional[List[str]] = None,
        state_key: str = "messages"
    ):
        """
        Initialize a streaming node.
        
        Args:
            llm_chain: The LangChain LLM chain or runnable
            tool_names: Optional list of tool names for validation
            state_key: The key in state dictionary containing messages
        """
        self.llm_chain = llm_chain
        self.tool_names = tool_names
        self.state_key = state_key
        # Create the node function once during initialization
        self._node_func = create_streaming_node(
            self.llm_chain,
            self.tool_names,
            self.state_key
        )
    
    async def __call__(self, state: dict, config: RunnableConfig) -> AsyncGenerator[Any, None]:
        """
        Make the class callable as a LangGraph node.
        
        Args:
            state: The graph state dictionary
            config: RunnableConfig for the LLM invocation
            
        Yields:
            Chunks and state updates
        """
        async for item in self._node_func(state, config):
            yield item

