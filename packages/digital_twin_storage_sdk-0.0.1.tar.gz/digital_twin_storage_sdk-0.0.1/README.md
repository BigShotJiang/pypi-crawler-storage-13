# DTS SDK

Python-based Software Development Kit to fetch and push information to a Digital Twin Storage.

examples in [README.ipynb](README.ipynb)

# use in an other project

1 - build the package

```bash
python -m build
```

> creates a dist dir

2 - pip install

within the venv of the other package, run :

```bash
pip install <path_to_dts_sdk_dir>
```

Then

```python
from dts_sdk import DTSWriter
```

should work.
