from pydantic import BaseModel
from requests import Response


class DTSError(Exception):
    """Base class for all DTS SDK errors."""


class DTSConnectionError(DTSError):
    """Raised when a connection to the DTS server fails."""


class DTSResponseError(DTSError):
    """Raised when the DTS server returns an unexpected response (invalid JSON, missing fields, etc.)."""


class DTSOperationError(DTSError):
    """Raised when DTS reports an error in its operation, e.g., failed insert, validation error, or op_status != 'success'."""

    def __init__(self, message: str, payload: dict | None = None):
        super().__init__(message)
        self.payload = payload


class DTSHTTPErrorModel(BaseModel):
    status: int
    error: str
    message: str
    details: dict | None = None
    path: str
    method: str
    request_id: str


class DTSHTTPError(DTSError):
    def __init__(self, model: DTSHTTPErrorModel):
        self.model = model
        super().__init__(str(self))

    @classmethod
    def from_response(cls, response: Response):
        model = DTSHTTPErrorModel(**response.json())
        return cls(model)

    def __str__(self):
        m = self.model
        return f"{m.status} {m.error}: {m.message}\nfor request {m.method} {m.path}"
