from uuid import UUID

from connectors.dts_writer import DTSWriter
from models.dts_errors import DTSOperationError
from models.dts_payload import DTSPayload
from utils.log import log_w


class DTSSetup(DTSWriter):
    def __init__(self, url):
        super().__init__(url)

    @property
    def prefix(self) -> str:
        return "setup/v1"

    def create_channel(self, body: DTSPayload | dict):
        self._ensure_payload_id(body)
        return self.post(route="channels", body=body)

    def upsert_channel(self, body: DTSPayload | dict):
        self._ensure_payload_id(body)
        return self.put(route="channels", body=body)

    def update_channel(self, body: DTSPayload | dict):
        sensor_id = self._ensure_payload_id(body)
        return self.patch(route=f"channels/{sensor_id}", body=body)

    def delete_channel(self, id: UUID | str):
        channel: DTSPayload | None = self.get_channel(id)
        if not channel:
            raise DTSOperationError(f"No sensor found with id {id} on {self.url}")
        return self.delete(route=f"channels/{channel.sensor_id}")

    def delete_all_channels(self):
        here = "delete_all_channels"
        for channel_id in self.all_ids:
            try:
                self.delete_channel(channel_id)
                print(f"deleted channel {channel_id}")
            except Exception as e:
                log_w(here, f"Could not delete channel {channel_id}", e)

    def clone_channel(self, id: UUID | str, body: DTSPayload | dict | None):
        if not body:
            self.post(route=f"channels/{id}/clone")
        self.post(route=f"channels/{id}/clone", body=body)


if __name__ == "__main__":
    from utils.log import log_d

    here = "read DTS"
    log_d(here)
    dts_setup = DTSSetup("http://127.0.0.1:8000")
    [log_d(here, f"channel {channel.sensor_id}", channel) for channel in dts_setup.all_channels]
    log_d(here, "column types", dts_setup.column_types)
    chan_id, _ = dts_setup.get_channel_with_max_rows()
    if chan_id:
        log_d(here, "channel with max rows", chan_id)
