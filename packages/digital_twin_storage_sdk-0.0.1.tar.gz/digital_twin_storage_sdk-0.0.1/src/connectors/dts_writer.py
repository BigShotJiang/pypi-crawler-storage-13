# connectors/dts_writer.py
from typing import Any

from connectors.abc_connector import DTSConnector
from models.dts_payload import DTSPayload


class DTSWriter(DTSConnector):
    """
    SDK to push and read data on a Digital Twin Storage
    """

    def __init__(self, url):
        super().__init__(url)

    @property
    def prefix(self) -> str:
        return "data/v1"

    @property
    def column_types(self):
        return self.get(route="schemas/columns/types", strict=False)

    def insert_rows_and_upsert_channel(self, body: DTSPayload | dict):
        """Creates a new channel if it doesn't exist already and insert data rows"""
        self._ensure_payload_id(body)
        return self.post(route="channels", body=body)

    def add_row(self, body: DTSPayload | dict):
        """Creates a new channel if it doesn't exist already and insert data rows"""
        return self.insert_rows_and_upsert_channel(body)

    def insert_rows(self, id, rows: list[dict[str, Any]]):
        """Insert rows for an existing sensor"""
        payload = DTSPayload(sensor_id=id, rows=rows)
        return self.post(f"channels/{id}/rows", body=payload.model_dump())


if __name__ == "__main__":
    from utils.log import log_d

    here = "read DTS"
    log_d(here)
    dts_writer = DTSWriter("http://127.0.0.1:8000")
    [log_d(here, f"Channel {channel.sensor_id}", channel) for channel in dts_writer.all_channels]
    max_chan_id, _ = dts_writer.get_channel_with_max_rows()
    if max_chan_id:
        log_d(here, "channel with max rows", dts_writer.get_channel(max_chan_id))
        rows: list = dts_writer.get_rows_for_channel(max_chan_id, "dict")  # type:ignore
        for i, row in enumerate(rows):
            log_d(here, f"row {i}", row)
        log_d(here, "nb rows", len(rows))
