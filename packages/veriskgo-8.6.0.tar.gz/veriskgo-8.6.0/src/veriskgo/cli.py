
def main() -> None:
    print("Hello from veriskgo!")
    print("Thank you...")
