# devpy

**devpy** is a Devanagari-to-Python DSL that lets you write Python code using Hindi script. It supports plotting, data manipulation, and basic control flow — all in Devanagari.

## ✨ Features

- Write Python code using Devanagari keywords
- Supports pandas and matplotlib
- Unicode-friendly graphs with Hindi labels
- Easy to install and use

## 📦 Installation

```bash
pip install devpy

Example: 

from devpy import चलाओ

चलाओ("""
प्रिन्ट("नमस्ते दुनिया")
""")