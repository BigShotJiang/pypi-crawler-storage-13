from setuptools import setup, find_packages

setup(
    name='devanagari17-py',
    version='0.1',
    packages=find_packages(),
    description='Devanagari to Python DSL',
    author='Max',
    install_requires=['pandas', 'matplotlib'],
)