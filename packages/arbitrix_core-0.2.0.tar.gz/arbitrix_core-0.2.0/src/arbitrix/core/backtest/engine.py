from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd

import arbitrix.core.costs as costs
from arbitrix.core.strategies.base import BaseStrategy
from arbitrix.core.trading import Order, Signal, Trade, Position
from arbitrix.core.types import InstrumentConfig


@dataclass
class BTConfig:
    commission_per_lot: float = 3.0
    default_slippage_points: float = 0.5
    slippage_atr_multiplier: float = 0.0
    apply_spread_cost: bool = True
    apply_swap_cost: bool = True
    market_fill_price: str = "close"  # "open" or "close"
    exit_fill_price: str = "close"  # "open" or "close"
    intra_bar_model: str = "sl_first"  # "sl_first", "tp_first", "none"
    trailing_mode: str = "none"  # placeholder for future engine modes
    trailing_params: Dict[str, float] = field(default_factory=dict)


@dataclass
class BTResult:
    trades: List[Trade]
    daily_equity: pd.Series
    gross_equity: pd.Series
    equity_marked: pd.Series
    metrics: Dict[str, float]
    metadata: Dict[str, Any] = field(default_factory=dict)
    orders: List[Order] = field(default_factory=list)
    positions: List["Position"] = field(default_factory=list)


class Backtester:
    def __init__(self, cfg: BTConfig, instruments: Optional[Dict[str, InstrumentConfig]] = None):
        self.cfg = cfg
        self.instruments = instruments or {}
        self._order_id = 0
        costs.set_commission_per_lot(cfg.commission_per_lot)

    def _next_order_id(self) -> int:
        self._order_id += 1
        return self._order_id

    def run_single(
        self,
        df: pd.DataFrame,
        strategy: BaseStrategy,
        risk_perc: float,
        initial_equity: float,
        swap_override: Optional[dict] = None,
        *,
        cancel_callback: Optional[Callable[[], None]] = None,
        early_stop_conditions: Optional[Dict[str, Any]] = None,
    ) -> BTResult:
        def _maybe_cancel() -> None:
            if cancel_callback:
                cancel_callback()

        _maybe_cancel()
        if df.empty:
            raise ValueError("DataFrame is empty; cannot run backtest.")

        prepared = strategy.prepare(df)
        _maybe_cancel()

        raw_signals = strategy.generate_signals(prepared) or []
        if isinstance(raw_signals, Signal):
            signals = [raw_signals]
        else:
            signals = list(raw_signals)
        signals.sort(key=lambda s: pd.Timestamp(s.when))
        signal_iter = iter(signals)
        pending_signal: Optional[Signal] = None

        def _ensure_next_signal() -> None:
            nonlocal pending_signal
            if pending_signal is not None:
                return
            try:
                _maybe_cancel()
                next_sig = next(signal_iter)
            except StopIteration:
                pending_signal = None
                return
            when = pd.Timestamp(next_sig.when)
            pending_signal = next_sig
            pending_signal.when = when.tz_localize("UTC") if when.tzinfo is None else when.tz_convert("UTC")

        _ensure_next_signal()

        equity = float(initial_equity)
        gross_equity = float(initial_equity)
        symbol = strategy.symbol or "SYMBOL"
        open_trades: List[Trade] = []
        closed_trades: List[Trade] = []
        working_orders: List[Order] = []
        all_orders: List[Order] = []
        equity_by_day: Dict[pd.Timestamp, float] = {}
        equity_marked_by_day: Dict[pd.Timestamp, float] = {}
        gross_by_day: Dict[pd.Timestamp, float] = {}
        position_snapshots: List[Position] = []

        early_stop_enabled = bool(early_stop_conditions)
        max_dd_threshold = early_stop_conditions.get("max_drawdown") if early_stop_conditions else None
        min_trades_threshold = early_stop_conditions.get("min_trades") if early_stop_conditions else None
        check_interval = early_stop_conditions.get("check_interval", 50) if early_stop_conditions else 50
        bar_count = 0
        early_stopped = False
        early_stop_reason = None

        for raw_ts, row in prepared.iterrows():
            _maybe_cancel()
            bar_count += 1
            ts = raw_ts.tz_localize("UTC") if raw_ts.tzinfo is None else raw_ts.tz_convert("UTC")
            day = ts.normalize()

            # Apply swap, trailing, and exit logic for existing trades
            updated_trades: List[Trade] = []
            for trade in open_trades:
                swap_delta = self._apply_overnight_swap(symbol, trade, day, swap_override)
                if swap_delta:
                    equity += swap_delta
                new_stop = strategy.trailing_stop_points(trade, row)
                if new_stop > 0:
                    trade.stop_points = new_stop
                if strategy.should_exit_trade(trade, row):
                    equity, gross_equity, trade = self._close_trade(
                        symbol, trade, row, ts, equity, gross_equity, closed_trades, reason="conditional_exit"
                    )
                    continue
                equity, gross_equity, maybe_open = self._maybe_close_trade(
                    symbol, trade, row, ts, equity, gross_equity, closed_trades
                )
                if maybe_open:
                    updated_trades.append(maybe_open)
            open_trades = updated_trades

            # Consume signals for this timestamp
            while True:
                _maybe_cancel()
                if pending_signal is None:
                    _ensure_next_signal()
                if pending_signal is None or pending_signal.when > ts:
                    break
                next_sig = pending_signal
                pending_signal = None
                if next_sig.action == "exit":
                    exit_updates: List[Trade] = []
                    for trade in open_trades:
                        equity, gross_equity, _ = self._close_trade(
                            symbol, trade, row, ts, equity, gross_equity, closed_trades, reason="signal_exit"
                        )
                    for order in working_orders:
                        order.status = "cancelled"
                    working_orders = []
                    open_trades = exit_updates
                    continue

                order = self._create_order_from_signal(strategy, next_sig, row, risk_perc, equity)
                if order:
                    all_orders.append(order)
                    working_orders.append(order)

            # Drop expired orders
            still_working: List[Order] = []
            for order in working_orders:
                if order.valid_until is not None and ts > order.valid_until:
                    order.status = "expired"
                    continue
                still_working.append(order)
            working_orders = still_working

            # Attempt fills
            newly_filled: List[Trade] = []
            remaining_orders: List[Order] = []
            for order in working_orders:
                filled = self._try_fill_order(order, row)
                if filled is None:
                    remaining_orders.append(order)
                    continue
                trade, equity = self._open_trade_from_order(symbol, order, filled, row, equity)
                if trade:
                    newly_filled.append(trade)
            working_orders = remaining_orders
            open_trades.extend(newly_filled)

            # Record equity (realized and marked-to-market)
            equity_by_day[day] = equity
            gross_by_day[day] = gross_equity
            equity_marked_by_day[day] = equity + self._unrealized_pnl(symbol, open_trades, row)

            if early_stop_enabled and bar_count % check_interval == 0:
                if max_dd_threshold is not None and equity_by_day:
                    equity_series = pd.Series(equity_by_day).sort_index()
                    current_dd = self._max_drawdown(equity_series)
                    if abs(current_dd) > max_dd_threshold:
                        early_stopped = True
                        early_stop_reason = f"max_drawdown exceeded: {abs(current_dd):.4f} > {max_dd_threshold}"
                        break

                if min_trades_threshold is not None and bar_count > len(prepared) * 0.3:
                    if len(closed_trades) < min_trades_threshold:
                        early_stopped = True
                        early_stop_reason = f"insufficient trades: {len(closed_trades)} < {min_trades_threshold}"
                        break

        last_ts = prepared.index[-1].tz_localize("UTC") if prepared.index[-1].tzinfo is None else prepared.index[-1].tz_convert("UTC")
        last_row = prepared.iloc[-1]
        day = last_ts.normalize()
        if early_stopped:
            for trade in open_trades:
                equity, gross_equity, _ = self._close_trade(
                    symbol, trade, last_row, last_ts, equity, gross_equity, closed_trades, reason="early_stop"
                )
            equity_by_day[day] = equity
            equity_marked_by_day[day] = equity
        else:
            # Force close remaining trades at last bar
            for trade in list(open_trades):
                swap_delta = self._apply_overnight_swap(symbol, trade, day, swap_override)
                if swap_delta:
                    equity += swap_delta
                equity, gross_equity, _ = self._close_trade(
                    symbol, trade, last_row, last_ts, equity, gross_equity, closed_trades, reason="eod"
                )
            equity_by_day[day] = equity
            equity_marked_by_day[day] = equity

        daily_equity = pd.Series(equity_by_day).sort_index().ffill()
        gross_equity_series = pd.Series(gross_by_day).sort_index().ffill()
        if gross_equity_series.empty and not daily_equity.empty:
            gross_equity_series = daily_equity.copy()
        equity_marked_series = pd.Series(equity_marked_by_day).sort_index().ffill()

        _maybe_cancel()
        metrics = self._compute_metrics(daily_equity)
        total_commission = sum(t.commission_paid for t in closed_trades)
        total_spread = sum(t.spread_cost for t in closed_trades)
        total_slippage = sum(t.slippage_cost for t in closed_trades)
        total_swap = sum(t.swap_pnl for t in closed_trades)
        total_gross = sum(t.gross_pnl for t in closed_trades)
        total_net = sum(t.net_pnl for t in closed_trades)
        total_fees = total_commission + total_spread + total_slippage
        gross_abs = abs(total_gross)
        if gross_abs <= 1e-9:
            fees_to_gross = 1.0 if total_fees > 0 else 0.0
        else:
            fees_to_gross = float(total_fees) / gross_abs

        returns_series = daily_equity.pct_change().dropna()
        returns_count = int(len(returns_series))
        trade_count = int(len(closed_trades))

        (
            robust_score,
            score_components,
            disqualified,
            reasons,
            psr_guardrail,
        ) = self._evaluate_robust_score(
            metrics,
            fees_to_gross,
            returns_count=returns_count,
            trade_count=trade_count,
        )

        metrics.update(
            {
                "gross_pnl": float(total_gross),
                "net_pnl": float(total_net),
                "total_commission": float(total_commission),
                "total_spread_cost": float(total_spread),
                "total_slippage_cost": float(total_slippage),
                "total_swap_pnl": float(total_swap),
                "FeesToGross": float(fees_to_gross),
                "RobustScore": float(robust_score),
                "Qualified": 0.0 if disqualified else 1.0,
                "ReturnCount": float(returns_count),
                "TradeCount": float(trade_count),
            }
        )

        psr_min_returns = int(psr_guardrail["min_returns"]) if psr_guardrail else 45
        psr_min_trades = int(psr_guardrail["min_trades"]) if psr_guardrail else 10

        metadata = {
            "disqualified": disqualified,
            "disqualify_reasons": reasons,
            "robust_score_components": score_components,
            "robust_score_thresholds": {
                "drawdown": 0.55,
                "psr": 0.5,
                "psr_min_returns": psr_min_returns,
                "psr_min_trades": psr_min_trades,
                "fees_to_gross": 0.6,
                "turnover": 0.15,
                "sharpe": 3.0,
                "sortino": 4.0,
                "tail_ratio": 3.0,
            },
            "sample_counts": {
                "returns": returns_count,
                "trades": trade_count,
            },
        }
        if psr_guardrail:
            metadata["psr_guardrail"] = psr_guardrail
        if early_stopped:
            metadata.update(
                {
                    "disqualified": True,
                    "disqualify_reasons": [f"early_stop: {early_stop_reason}"],
                    "early_stopped": True,
                    "early_stop_reason": early_stop_reason,
                    "bars_processed": bar_count,
                }
            )

        return BTResult(
            trades=closed_trades,
            daily_equity=daily_equity,
            gross_equity=gross_equity_series,
            equity_marked=equity_marked_series,
            metrics=metrics,
            metadata=metadata,
            orders=all_orders,
            positions=self._final_positions(closed_trades),
        )

    def _unrealized_pnl(self, symbol: str, trades: List[Trade], row: pd.Series) -> float:
        pv = costs.get_point_value(symbol)
        if pv == 0:
            return 0.0
        pnl = 0.0
        for trade in trades:
            if trade.side == "long":
                pnl += (row["close"] - trade.entry_price) * pv * trade.volume
            else:
                pnl += (trade.entry_price - row["close"]) * pv * trade.volume
        return pnl

    def _create_order_from_signal(
        self,
        strategy: BaseStrategy,
        signal: Signal,
        row: pd.Series,
            risk_perc: float,
            equity: float,
        ) -> Optional[Order]:
        symbol = strategy.symbol or "SYMBOL"
        stop_points = float(strategy.stop_distance_points(row))
        if stop_points <= 0:
            return None
        take_points = float(strategy.take_distance_points(row))
        point_value = costs.get_point_value(symbol)
        if point_value <= 0:
            return None

        volume = signal.volume
        if volume is None:
            risk_dollars = equity * risk_perc
            volume = round(risk_dollars / (point_value * stop_points), 2)
        if volume <= 0:
            return None

        price: Optional[float] = None
        if signal.order_type == "limit":
            price = signal.limit_price if signal.limit_price is not None else signal.price
        elif signal.order_type == "stop":
            price = signal.stop_price if signal.stop_price is not None else signal.price

        valid_until = self._resolve_valid_until(strategy, signal)

        return Order(
            id=self._next_order_id(),
            symbol=symbol,
            side="buy" if signal.action == "buy" else "sell",
            type=signal.order_type,
            volume=float(volume),
            price=float(price) if price is not None else None,
            created_at=signal.when,
            stop_points=stop_points,
            take_points=take_points,
            valid_until=valid_until,
            tif=signal.tif,
        )

    def _try_fill_order(self, order: Order, row: pd.Series) -> Optional[float]:
        if order.type == "market":
            fill = row["open"] if self.cfg.market_fill_price == "open" else row["close"]
            order.status = "filled"
            return float(fill)

        if order.type == "limit":
            if order.side == "buy" and row["low"] <= float(order.price):
                order.status = "filled"
                return float(order.price)
            if order.side == "sell" and row["high"] >= float(order.price):
                order.status = "filled"
                return float(order.price)
            order.status = "working"
            return None

        if order.type == "stop":
            if order.side == "buy" and row["high"] >= float(order.price):
                order.status = "filled"
                return float(order.price)
            if order.side == "sell" and row["low"] <= float(order.price):
                order.status = "filled"
                return float(order.price)
            order.status = "working"
            return None
        return None

    def _open_trade_from_order(
        self,
        symbol: str,
        order: Order,
        fill_price: float,
        row: pd.Series,
        equity: float,
    ) -> tuple[Optional[Trade], float]:
        commission = costs.commission_one_side(symbol, float(fill_price), order.volume)
        spread_points = float(row.get("spread", 0.0)) if self.cfg.apply_spread_cost else 0.0
        spread_cost = costs.spread_cost(symbol, spread_points / 2.0, order.volume) if spread_points else 0.0
        slippage_points = self._slippage_points(symbol, row)
        slippage_cost_val = costs.slippage_cost(symbol, slippage_points, order.volume) if slippage_points else 0.0
        equity -= commission + spread_cost + slippage_cost_val

        trade = Trade(
            symbol=symbol,
            side="long" if order.side == "buy" else "short",
            entry_time=order.created_at,
            entry_price=float(fill_price),
            volume=float(order.volume),
            stop_points=float(order.stop_points),
            take_points=float(order.take_points),
            commission_paid=commission,
            spread_cost=spread_cost,
            slippage_cost=slippage_cost_val,
            order_id=order.id,
        )
        trade._last_swap_day = order.created_at.normalize() if order.created_at is not None else None
        return trade, equity

    def _maybe_close_trade(
        self,
        symbol: str,
        trade: Trade,
        row: pd.Series,
        ts: pd.Timestamp,
        equity: float,
        gross_equity: float,
        trades: List[Trade],
    ) -> tuple[float, float, Optional[Trade]]:
        pv = costs.get_point_value(symbol)
        if pv == 0:
            return equity, gross_equity, trade

        stop_hit = False
        take_hit = False
        if trade.side == "long":
            stop_price = trade.entry_price - trade.stop_points
            take_price = trade.entry_price + trade.take_points if trade.take_points > 0 else None
            stop_hit = row["low"] <= stop_price
            take_hit = take_price is not None and row["high"] >= take_price
        else:
            stop_price = trade.entry_price + trade.stop_points
            take_price = trade.entry_price - trade.take_points if trade.take_points > 0 else None
            stop_hit = row["high"] >= stop_price
            take_hit = take_price is not None and row["low"] <= take_price

        if not stop_hit and not take_hit:
            return equity, gross_equity, trade

        if stop_hit and take_hit:
            model = self.cfg.intra_bar_model
            if model == "tp_first":
                stop_hit = False
            elif model == "none":
                stop_hit = True
                take_hit = False
            else:
                take_hit = False

        if trade.side == "long":
            if stop_hit:
                fill = stop_price
                pnl = (fill - trade.entry_price) * pv * trade.volume
            else:
                fill = take_price if take_price is not None else row["close"]
                pnl = (fill - trade.entry_price) * pv * trade.volume
        else:
            if stop_hit:
                fill = stop_price
                pnl = (trade.entry_price - fill) * pv * trade.volume
            else:
                fill = take_price if take_price is not None else row["close"]
                pnl = (trade.entry_price - fill) * pv * trade.volume

        commission = costs.commission_one_side(symbol, float(fill), trade.volume)
        slippage_points = self._slippage_points(symbol, row)
        slippage_cost_val = costs.slippage_cost(symbol, slippage_points, trade.volume) if slippage_points else 0.0
        trade.exit_time = ts
        trade.exit_price = float(fill)
        trade.gross_pnl = pnl
        trade.commission_paid += commission
        trade.slippage_cost += slippage_cost_val
        trade.pnl = pnl - commission - slippage_cost_val
        total_costs = trade.commission_paid + trade.spread_cost + trade.slippage_cost
        trade.net_pnl = trade.gross_pnl - total_costs + trade.swap_pnl
        trade.notes["exit_stop"] = 1.0 if stop_hit else 0.0
        trade.notes["exit_take"] = 1.0 if take_hit else 0.0
        equity += trade.pnl
        gross_equity += trade.gross_pnl
        trades.append(trade)
        return equity, gross_equity, None

    def _close_trade(
        self,
        symbol: str,
        trade: Trade,
        row: pd.Series,
        ts: pd.Timestamp,
        equity: float,
        gross_equity: float,
        trades: List[Trade],
        reason: str = "force",
    ) -> tuple[float, float, Optional[Trade]]:
        pv = costs.get_point_value(symbol)
        if pv == 0:
            return equity, gross_equity, trade
        fill_price = row["open"] if self.cfg.exit_fill_price == "open" else row["close"]
        if trade.side == "long":
            pnl = (fill_price - trade.entry_price) * pv * trade.volume
        else:
            pnl = (trade.entry_price - fill_price) * pv * trade.volume
        commission = costs.commission_one_side(symbol, float(fill_price), trade.volume)
        slippage_points = self._slippage_points(symbol, row)
        slippage_cost_val = costs.slippage_cost(symbol, slippage_points, trade.volume) if slippage_points else 0.0
        trade.exit_time = ts
        trade.exit_price = float(fill_price)
        trade.gross_pnl = pnl
        trade.commission_paid += commission
        trade.slippage_cost += slippage_cost_val
        trade.pnl = pnl - commission - slippage_cost_val
        total_costs = trade.commission_paid + trade.spread_cost + trade.slippage_cost
        trade.net_pnl = trade.gross_pnl - total_costs + trade.swap_pnl
        trade.notes[f"exit_{reason}"] = 1.0
        equity += trade.pnl
        gross_equity += trade.gross_pnl
        trades.append(trade)
        return equity, gross_equity, None

    def _slippage_points(self, symbol: str, row: pd.Series) -> float:
        tick = self._tick_size(symbol)
        base = float(self.cfg.default_slippage_points) * tick
        if self.cfg.slippage_atr_multiplier > 0 and "atr" in row and not pd.isna(row["atr"]):
            base += float(row["atr"]) * self.cfg.slippage_atr_multiplier
        return base if base else 0.0

    def _tick_size(self, symbol: str) -> float:
        inst = self.instruments.get(symbol)
        if inst and inst.tick_size:
            return float(inst.tick_size)
        return 1.0

    def _apply_overnight_swap(
        self,
        symbol: str,
        trade: Trade,
        current_day: pd.Timestamp,
        swap_override: Optional[dict],
    ) -> float:
        if not self.cfg.apply_swap_cost:
            return 0.0
        if trade._last_swap_day is None:
            trade._last_swap_day = current_day
            return 0.0
        delta_total = 0.0
        while trade._last_swap_day < current_day:
            trade._last_swap_day += pd.Timedelta(days=1)
            direction = "long" if trade.side == "long" else "short"
            swap_delta = costs.swap_cost_per_day(symbol, trade.volume, direction, static_override=swap_override)
            trade.swap_pnl += swap_delta
            delta_total += swap_delta
        return delta_total

    def _final_positions(self, trades: List[Trade]) -> List[Position]:
        """Aggregate closed trades into position summaries (post-run snapshot)."""

        aggregates: Dict[tuple[str, str], Dict[str, float]] = {}
        buckets: Dict[tuple[str, str], List[Trade]] = {}
        for t in trades:
            key = (t.symbol, t.side)
            if key not in aggregates:
                aggregates[key] = {"volume": 0.0, "notional": 0.0}
                buckets[key] = []
            aggregates[key]["volume"] += float(t.volume)
            aggregates[key]["notional"] += float(t.entry_price * t.volume)
            buckets[key].append(t)

        positions: List[Position] = []
        for key, agg in aggregates.items():
            symbol, side = key
            volume = agg["volume"]
            avg_price = agg["notional"] / volume if volume else 0.0
            positions.append(Position(symbol=symbol, side=side, volume=volume, avg_price=avg_price, trades=buckets[key]))
        return positions

    def _resolve_valid_until(self, strategy: BaseStrategy, signal: Signal) -> Optional[pd.Timestamp]:
        if signal.valid_until is not None:
            ts = pd.Timestamp(signal.valid_until)
            return ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
        if signal.tif == "GTD":
            delta = self._timeframe_to_timedelta(getattr(strategy, "timeframe", ""))
            if delta is None:
                return None
            ts = pd.Timestamp(signal.when)
            ts = ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
            return ts + delta
        return None

    @staticmethod
    def _timeframe_to_timedelta(timeframe: str) -> Optional[pd.Timedelta]:
        if not timeframe:
            return None
        try:
            if isinstance(timeframe, (int, float)):
                return pd.Timedelta(minutes=int(timeframe))
        except Exception:
            pass
        tf_str = str(timeframe)
        match = re.match(r"^\s*([0-9]+)\s*([smhdwSMHDW])\s*$", tf_str)
        if not match:
            match = re.match(r"^\s*([smhdwSMHDW])\s*([0-9]+)\s*$", tf_str)
            if match:
                match = re.match(r"^\s*([smhdwSMHDW])\s*([0-9]+)\s*$", tf_str)
        if not match:
            return None
        if len(match.groups()) == 2 and match.group(1).isdigit():
            value = int(match.group(1))
            unit = match.group(2).lower()
        else:
            unit = match.group(1).lower()
            value = int(match.group(2))
        if unit == "s":
            return pd.Timedelta(seconds=value)
        if unit == "m":
            return pd.Timedelta(minutes=value)
        if unit == "h":
            return pd.Timedelta(hours=value)
        if unit == "d":
            return pd.Timedelta(days=value)
        if unit == "w":
            return pd.Timedelta(weeks=value)
        return None

    def _compute_metrics(self, daily_equity: pd.Series) -> Dict[str, float]:
        if daily_equity.empty or len(daily_equity) < 2:
            return {
                "CAGR": 0.0,
                "Sharpe": 0.0,
                "Sortino": 0.0,
                "MaxDD": 0.0,
                "PSR": 0.0,
                "DSR": 0.0,
                "Calmar": 0.0,
                "TailRatio": 0.0,
                "ExpectedShortfall": 0.0,
                "ReturnAutocorr": 0.0,
                "Stability": 0.0,
                "Turnover": 0.0,
            }

        eq = daily_equity.sort_index()
        returns = eq.pct_change().dropna()
        if returns.empty:
            return {
                "CAGR": 0.0,
                "Sharpe": 0.0,
                "Sortino": 0.0,
                "MaxDD": 0.0,
                "PSR": 0.0,
                "DSR": 0.0,
                "Calmar": 0.0,
                "TailRatio": 0.0,
                "ExpectedShortfall": 0.0,
                "ReturnAutocorr": 0.0,
                "Stability": 0.0,
                "Turnover": 0.0,
            }

        ann_factor = 252
        mu = returns.mean() * ann_factor
        sigma = returns.std(ddof=1) * math.sqrt(ann_factor)
        downside = returns[returns < 0].std(ddof=1) * math.sqrt(ann_factor)
        sharpe = mu / sigma if sigma > 0 else 0.0
        sortino = mu / downside if downside > 0 else 0.0
        max_dd = self._max_drawdown(eq)
        psr = self._probabilistic_sharpe(returns)
        dsr = self._deflated_sharpe(returns, sharpe)
        cagr = self._cagr(eq)
        calmar = cagr / abs(max_dd) if max_dd < 0 else 0.0
        tail_ratio = self._tail_ratio(returns)
        expected_shortfall = self._expected_shortfall(returns)
        autocorr = returns.autocorr(lag=1)
        if pd.isna(autocorr):
            autocorr = 0.0
        autocorr = float(autocorr)
        stability = max(0.0, min(1.0, 1.0 - abs(autocorr)))
        turnover = float(returns.abs().mean())

        return {
            "CAGR": cagr,
            "Sharpe": sharpe,
            "Sortino": sortino,
            "MaxDD": max_dd,
            "PSR": psr,
            "DSR": dsr,
            "Calmar": calmar,
            "TailRatio": tail_ratio,
            "ExpectedShortfall": expected_shortfall,
            "ReturnAutocorr": autocorr,
            "Stability": stability,
            "Turnover": turnover,
        }

    @staticmethod
    def _tail_ratio(returns: pd.Series) -> float:
        positive = returns[returns > 0]
        negative = returns[returns < 0]
        if positive.empty or negative.empty:
            return 0.0
        denom = abs(float(negative.mean()))
        if denom <= 0:
            return 0.0
        return float(positive.mean()) / denom

    @staticmethod
    def _expected_shortfall(returns: pd.Series, alpha: float = 0.05) -> float:
        if returns.empty:
            return 0.0
        threshold = returns.quantile(alpha)
        tail = returns[returns <= threshold]
        if tail.empty:
            return 0.0
        return float(-tail.mean())

    @staticmethod
    def _evaluate_robust_score(
        metrics: Dict[str, float],
        fees_to_gross: float,
        *,
        returns_count: int = 0,
        trade_count: int = 0,
    ) -> tuple[float, Dict[str, float], bool, List[str], Optional[Dict[str, Any]]]:
        sharpe = float(metrics.get("Sharpe") or 0.0)
        sortino = float(metrics.get("Sortino") or 0.0)
        max_dd = float(metrics.get("MaxDD") or 0.0)
        tail_ratio = float(metrics.get("TailRatio") or 0.0)
        stability = float(metrics.get("Stability") or 0.0)
        turnover = float(metrics.get("Turnover") or 0.0)
        psr = float(metrics.get("PSR") or 0.0)

        def _clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
            return max(lower, min(upper, value))

        def _normalize_positive(value: float, upper: float) -> float:
            if upper <= 0:
                return 0.0
            if value <= 0:
                return 0.0
            return _clamp(value / upper)

        drawdown_threshold = 0.5
        turnover_threshold = 0.15
        sharpe_score = _normalize_positive(sharpe, 3.0)
        sortino_score = _normalize_positive(sortino, 4.0)
        drawdown_penalty = _clamp(abs(max_dd) / drawdown_threshold) if drawdown_threshold > 0 else 1.0
        drawdown_score = _clamp(1.0 - drawdown_penalty)
        tail_score = _normalize_positive(tail_ratio, 3.0)
        stability_score = _clamp(stability)
        turnover_penalty = _clamp(turnover / turnover_threshold) if turnover_threshold > 0 else 1.0
        turnover_score = _clamp(1.0 - turnover_penalty)

        robust_score = (
            0.35 * sharpe_score
            + 0.15 * sortino_score
            + 0.15 * drawdown_score
            + 0.10 * tail_score
            + 0.10 * stability_score
            + 0.15 * turnover_score
        )
        robust_score = _clamp(robust_score)

        min_psr_returns = 45
        min_psr_trades = 10
        psr_guardrail: Optional[Dict[str, Any]] = {
            "eligible": bool(
                returns_count >= min_psr_returns and trade_count >= min_psr_trades
            ),
            "min_returns": int(min_psr_returns),
            "min_trades": int(min_psr_trades),
            "actual_returns": int(returns_count),
            "actual_trades": int(trade_count),
        }

        disqualify_reasons: List[str] = []
        if abs(max_dd) > 1e-9 and abs(max_dd) > 0.55:
            disqualify_reasons.append("drawdown")
        psr_eligible = bool(psr_guardrail and psr_guardrail["eligible"])
        if psr < 0.5 and psr_eligible:
            disqualify_reasons.append("psr")
        if fees_to_gross > 0.6:
            disqualify_reasons.append("fees")

        if psr_guardrail is not None and not psr_eligible and psr < 0.5:
            psr_guardrail["reason"] = "insufficient_samples"

        disqualified = bool(disqualify_reasons)
        if disqualified:
            robust_score = 0.0

        components = {
            "sharpe": sharpe_score,
            "sortino": sortino_score,
            "drawdown": drawdown_score,
            "tail_ratio": tail_score,
            "stability": stability_score,
            "turnover": turnover_score,
        }

        return robust_score, components, disqualified, disqualify_reasons, psr_guardrail

    @staticmethod
    def _cagr(eq: pd.Series) -> float:
        start = eq.iloc[0]
        end = eq.iloc[-1]
        days = (eq.index[-1] - eq.index[0]).days or 1
        years = days / 365.25
        if start <= 0 or years <= 0:
            return 0.0
        return float((end / start) ** (1 / years) - 1)

    @staticmethod
    def _max_drawdown(eq: pd.Series) -> float:
        running_max = eq.cummax()
        drawdown = (eq - running_max) / running_max.replace(0, np.nan)
        return float(drawdown.min())

    @staticmethod
    def _probabilistic_sharpe(returns: pd.Series, benchmark: float = 0.0) -> float:
        values = returns.values
        n = len(values)
        if n < 20:
            return 0.0
        mean = values.mean()
        sd = values.std(ddof=1)
        if sd <= 0:
            return 0.0
        sr_hat = (mean / sd) * math.sqrt(252)
        series = pd.Series(values)
        skew = series.skew()
        kurt = series.kurtosis()
        se = math.sqrt((1 + 0.5 * sr_hat**2 - skew * sr_hat + (kurt / 4) * sr_hat**2) / (n - 1))
        if se <= 0:
            return 0.0
        z = (sr_hat - benchmark) / se
        from math import erf, sqrt

        return 0.5 * (1 + erf(z / sqrt(2)))

    @staticmethod
    def _deflated_sharpe(returns: pd.Series, sharpe: float) -> float:
        values = returns.values
        n = len(values)
        if n < 20 or sharpe == 0:
            return 0.0
        series = pd.Series(values)
        skew = series.skew()
        kurt = series.kurtosis()
        term = math.sqrt(max(1e-9, 1 - skew * sharpe + (kurt - 1) * (sharpe ** 2) / 4))
        z = sharpe * math.sqrt(n - 1) / term
        from math import erf, sqrt

        return 0.5 * (1 + erf(z / sqrt(2)))
