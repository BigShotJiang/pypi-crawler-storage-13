from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import pandas as pd

from arbitrix.core.strategies.base import BaseStrategy
from arbitrix.core.trading import Signal, Trade
from arbitrix.core.utils.indicators import atr


@dataclass
class TrendFollowerConfig:
    symbol: str = field(
        default="",
        metadata={"group": "strategy", "description": "Trading symbol (e.g., EURUSD, IBUS500).", "optimizable": True},
    )
    timeframe: str = field(
        default="H1",
        metadata={"group": "strategy", "description": "Timeframe for execution (e.g., M5, M15, H1, D1).", "optimizable": True},
    )
    atr_period: int = field(
        default=14,
        metadata={"group": "strategy", "description": "Period used for ATR calculation.", "optimizable": True},
    )
    atr_stop_mult: float = field(
        default=2.0,
        metadata={"group": "strategy", "description": "ATR multiplier for initial stop loss distance.", "optimizable": True},
    )
    atr_trail_mult: float = field(
        default=1.0,
        metadata={"group": "strategy", "description": "ATR multiplier for trailing stop distance.", "optimizable": True},
    )
    ema_fast: int = field(
        default=20,
        metadata={"group": "strategy", "description": "Period for fast EMA.", "optimizable": True},
    )
    ema_slow: int = field(
        default=50,
        metadata={"group": "strategy", "description": "Period for slow EMA.", "optimizable": True},
    )
    max_pyramids: int = field(
        default=3,
        metadata={"group": "strategy", "description": "Maximum number of pyramid positions allowed.", "optimizable": True},
    )
    pyramid_gap_atr: float = field(
        default=1.0,
        metadata={"group": "strategy", "description": "ATR multiplier for gap between pyramid entries.", "optimizable": True},
    )
    breakeven_after_r: float = field(
        default=1.0,
        metadata={"group": "strategy", "description": "Move stop to breakeven after this R multiple.", "optimizable": True},
    )
    exit_ema_cross: bool = field(
        default=True,
        metadata={"group": "strategy", "description": "Exit trades when EMA cross occurs.", "optimizable": True},
    )


class TrendFollowerStrategy(BaseStrategy):
    """
    Momentum / trend-following strategy designed to exercise the richer order/trade
    model:
    - Pyramiding: adds new positions every `pyramid_gap_atr` of favorable move up to `max_pyramids`.
    - Stop placement: ATR-based initial stop, with GTD stop orders for breakout entries.
    - Trailing stops: trails by `atr_trail_mult` ATR once price moves in favor.
    - Conditional exits: EMA cross filter triggers per-trade exits.
    """

    name = "trend_follower"

    def __init__(self, cfg: TrendFollowerConfig) -> None:
        self.cfg = cfg
        self.symbol = cfg.symbol
        self.timeframe = cfg.timeframe

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        frame = df.copy()
        frame["atr"] = atr(frame, self.cfg.atr_period)
        frame["ema_fast"] = frame["close"].ewm(span=self.cfg.ema_fast, adjust=False).mean()
        frame["ema_slow"] = frame["close"].ewm(span=self.cfg.ema_slow, adjust=False).mean()
        frame.dropna(inplace=True)
        return frame

    def generate_signals(self, df: pd.DataFrame) -> List[Signal]:
        """Emit stop-entry breakout signals with GTD validity, enabling pyramiding."""
        signals: List[Signal] = []
        last_entry_price = None
        pyramids = 0
        for ts, row in df.iterrows():
            if row["ema_fast"] <= row["ema_slow"]:
                last_entry_price = None
                pyramids = 0
                continue

            # only add a new entry when we have room to pyramid and price advanced enough
            if pyramids >= self.cfg.max_pyramids:
                continue
            if last_entry_price is None or (row["close"] - last_entry_price) >= row["atr"] * self.cfg.pyramid_gap_atr:
                stop_price = float(row["high"])
                signals.append(
                    Signal(
                        when=ts,
                        action="buy",
                        price=float(row["close"]),
                        order_type="stop",
                        stop_price=stop_price,
                        tif="GTD",
                        reason="trend_breakout",
                    )
                )
                last_entry_price = float(row["close"])
                pyramids += 1
        return signals

    def stop_distance_points(self, row: pd.Series) -> float:  # type: ignore[override]
        return float(row["atr"] * self.cfg.atr_stop_mult) if row.get("atr") is not None else 0.0

    def take_distance_points(self, row: pd.Series) -> float:  # type: ignore[override]
        # Trend follower keeps open-ended targets; rely on trailing/conditional exits.
        return 0.0

    def trailing_stop_points(self, trade: Trade, row: pd.Series) -> float:  # type: ignore[override]
        if row.get("atr") is None:
            return trade.stop_points
        # Move to breakeven after defined R, then trail by atr_trail_mult.
        move = float(row["close"] - trade.entry_price) if trade.side == "long" else float(trade.entry_price - row["close"])
        if move <= 0:
            return trade.stop_points
        atr_val = float(row["atr"])
        if move >= self.cfg.breakeven_after_r * trade.stop_points:
            breakeven = 0.0
            trail = atr_val * self.cfg.atr_trail_mult
            return max(breakeven, trail)
        return trade.stop_points

    def should_exit_trade(self, trade: Trade, row: pd.Series) -> bool:  # type: ignore[override]
        if not self.cfg.exit_ema_cross:
            return False
        fast = float(row.get("ema_fast", 0.0))
        slow = float(row.get("ema_slow", 0.0))
        if trade.side == "long" and fast < slow:
            return True
        if trade.side == "short" and fast > slow:
            return True
        return False
