from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

import pandas as pd

from arbitrix.core.trading import Signal, Trade


class BaseStrategy:
    name: str
    symbol: str = ""
    timeframe: str = "M5"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:  # pragma: no cover - to override
        return df

    def generate_signals(self, df: pd.DataFrame) -> list[Signal]:  # pragma: no cover - to override
        return []

    def stop_distance_points(self, row: pd.Series) -> float:  # pragma: no cover - to override
        return 0.0

    def take_distance_points(self, row: pd.Series) -> float:
        return 0.0

    def trailing_stop_points(self, trade: Trade, row: pd.Series) -> float:
        """Optional hook allowing the strategy to update trailing stops."""

        return trade.stop_points

    def should_exit_trade(self, trade: Trade, row: pd.Series) -> bool:
        """Return True to close a trade based on custom conditions."""

        return False

    @classmethod
    def prepare_task(
        cls,
        *,
        provider: Any,
        config: Any,
        task: str,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
        as_of: Optional[datetime] = None,
        optimization_start: Optional[datetime] = None,
        strategy: Optional["BaseStrategy"] = None,
        strategy_config: Any = None,
        context: Optional[Dict[str, Any]] = None,
        **_: Any,
    ) -> None:  # pragma: no cover - default no-op
        """Hook executed before running backtests or optimizations."""

        return None
