from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd
from .base import BaseStrategy
from arbitrix.core.trading import Signal


@dataclass
class BodyBreakoutConfig:
    symbol: str = field(
        default="",
        metadata={"group": "strategy", "description": "Trading symbol (e.g. EURUSD, IBUS500).", "optimizable": True},
    )
    timeframe: str = field(
        default="M5",
        metadata={"group": "strategy", "description": "Execution timeframe (M5, M15, H1, ...).", "optimizable": True},
    )


class BodyBreakoutStrategy(BaseStrategy):
    """
    Simple breakout strategy.

    Generates a buy signal when the candle closes above the previous
    candle body (max(open, close)) and a sell signal when it closes below the
    prior body low (min(open, close)).
    """

    name = "body_breakout"

    def __init__(self, cfg: BodyBreakoutConfig) -> None:
        self.symbol = cfg.symbol
        self.timeframe = cfg.timeframe
        self.cfg = cfg

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare dataframe (no extra logic, just ensure datetime index)."""
        if df.empty:
            return df

        frame = df.copy()
        frame.index = pd.to_datetime(frame.index)
        return frame

    def generate_signals(self, df: pd.DataFrame) -> list[Signal]:
        """Generate pure body-breakout entry signals."""
        if len(df) < 2:
            return []

        signals: list[Signal] = []

        for i in range(1, len(df)):
            ts = df.index[i]
            current = df.iloc[i]
            prev = df.iloc[i - 1]

            # Previous candle body
            prev_body_high = max(float(prev["open"]), float(prev["close"]))
            prev_body_low = min(float(prev["open"]), float(prev["close"]))
            current_close = float(current["close"])

            # Entry signals
            if current_close > prev_body_high:
                signals.append(
                    Signal(
                        action="buy",
                        when=ts,
                        price=current_close,
                        reason="body_breakout_up",
                    )
                )
            elif current_close < prev_body_low:
                signals.append(
                    Signal(
                        action="sell",
                        when=ts,
                        price=current_close,
                        reason="body_breakout_down",
                    )
                )

        return signals

    def stop_distance_points(self, row: pd.Series) -> float:
        high = float(row.get("high", 0.0))
        low = float(row.get("low", 0.0))
        distance = abs(high - low)
        if distance <= 0:
            distance = max(abs(float(row.get("close", 0.0)) * 0.001), 1e-4)
        return distance

    def take_distance_points(self, row: pd.Series) -> float:
        return self.stop_distance_points(row) * 2.0
