from .base import BaseStrategy
from .body_breakout import BodyBreakoutStrategy, BodyBreakoutConfig
from .breakout_index import BreakoutIndexStrategy, BreakoutConfig
from .carry_trade import CarryTradeStrategy, CarryTradeConfig
from .meanrev_gold import MeanRevGoldStrategy, MeanRevGoldConfig
from .registry import STRATEGY_REGISTRY
from .VSS import VolatilitySqueezeStrategy, VolatilitySqueezeConfig
from .VWMS import VolumeWeightedMomentumStrategy as VWMSStrategy, VolumeWeightedMomentumConfig as VWMSConfig
from .trend_follower import TrendFollowerStrategy, TrendFollowerConfig
from arbitrix.core.trading import Signal

__all__ = [
    "BaseStrategy",
    "Signal",
    "BodyBreakoutStrategy",
    "BodyBreakoutConfig",
    "BreakoutIndexStrategy",
    "BreakoutConfig",
    "CarryTradeStrategy",
    "CarryTradeConfig",
    "MeanRevGoldStrategy",
    "MeanRevGoldConfig",
    "STRATEGY_REGISTRY",
    "VolatilitySqueezeStrategy",
    "VolatilitySqueezeConfig",
    "VWMSStrategy",
    "VWMSConfig",
    "TrendFollowerStrategy",
    "TrendFollowerConfig",
]
