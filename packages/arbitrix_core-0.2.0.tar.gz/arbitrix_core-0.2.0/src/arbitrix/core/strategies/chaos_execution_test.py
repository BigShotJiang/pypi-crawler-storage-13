"""
Chaos Execution Test Strategy

A high-frequency M1 strategy designed to exercise ALL execution layer features
in under 20 minutes. This strategy executes at EVERY candle with random behavior
to test:
- Market orders (immediate fills)
- Limit orders (pending orders above/below market)
- Stop orders (pending orders with stop trigger)
- Pyramiding (adding to positions)
- Partial closes (closing portions of positions)
- GTD/GTC/DAY time-in-force
- Expiration times
- Stop loss and take profit
- Multiple position management

This is NOT a production trading strategy - it's a test harness for live execution.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
import logging
from datetime import timedelta
from typing import List

import pandas as pd

logger = logging.getLogger(__name__)

from arbitrix.core.strategies.base import BaseStrategy, Signal


@dataclass
class ChaosSignal(Signal):
    """Extended signal with all execution parameters."""
    order_type: str = "market"  # 'market', 'limit', 'stop'
    limit_price: float | None = None
    stop_price: float | None = None
    tif: str = "GTC"  # 'GTC', 'GTD', 'DAY'
    valid_until: pd.Timestamp | None = None
    volume: float = 1.0
    is_pyramid: bool = False  # Add to existing position
    is_partial_close: bool = False  # Close partial position
    partial_ratio: float = 0.5  # Ratio to close (0.0-1.0)


class ChaosExecutionTestStrategy(BaseStrategy):
    """
    Generates random execution patterns every candle to test all execution features.
    
    Configuration:
    - chaos_seed: Random seed for reproducibility (default: None = random)
    - execution_probability: Chance to generate signal per candle (0.0-1.0, default: 0.8)
    - pyramid_probability: Chance to pyramid when in position (default: 0.3)
    - partial_close_probability: Chance to partially close position (default: 0.25)
    - pending_order_probability: Chance to use limit/stop vs market (default: 0.5)
    - gtd_probability: Chance to use GTD vs GTC (default: 0.3)
    - max_position_size: Maximum position size to simulate (default: 5.0)
    """
    
    name = "chaos-execution-test"
    timeframe = "1m"  # M1 for rapid testing
    
    def __init__(
        self,
        symbol: str,
        chaos_seed: int | None = None,
        execution_probability: float = 0.8,
        pyramid_probability: float = 0.3,
        partial_close_probability: float = 0.25,
        pending_order_probability: float = 0.5,
        gtd_probability: float = 0.3,
        max_position_size: float = 5.0,
    ):
        self.symbol = symbol
        self.chaos_seed = chaos_seed
        self.execution_probability = execution_probability
        self.pyramid_probability = pyramid_probability
        self.partial_close_probability = partial_close_probability
        self.pending_order_probability = pending_order_probability
        self.gtd_probability = gtd_probability
        self.max_position_size = max_position_size
        
        # Internal state tracking (simulated)
        self._simulated_position: float = 0.0  # Track position size
        self._simulated_side: str | None = None  # 'buy' or 'sell'
        self._rng = random.Random(chaos_seed)
        self._candle_count = 0
    
    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        """No indicators needed - pure chaos."""
        frame = df.copy()
        # Add ATR for realistic SL/TP distances
        frame['high_low'] = frame['high'] - frame['low']
        frame['atr'] = frame['high_low'].rolling(14).mean()
        frame['atr'] = frame['atr'].fillna(frame['high_low'])
        return frame
    
    def generate_signals(self, df: pd.DataFrame) -> List[ChaosSignal]:
        """
        Generate signals at EVERY candle with randomized execution features.
        Maximum 3 orders per candle.
        """
        return self._generate_signals_for_rows(df)

    def generate_signals_live(self, df: pd.DataFrame) -> List[ChaosSignal]:
        """Live path: only evaluate the latest candle to avoid replaying history."""
        if df.empty:
            return []
        logger.debug("generate_signals_live invoked on %d rows; using last candle ts=%s", len(df), df.index[-1])
        return self._generate_signals_for_rows(df.tail(1))

    def _generate_signals_for_rows(self, df: pd.DataFrame) -> List[ChaosSignal]:
        signals: List[ChaosSignal] = []

        if df.empty:
            return signals

        # Only process the most recent candle to avoid replaying history in live mode
        idx = len(df) - 1
        self._candle_count += 1
        row = df.iloc[idx]
        when = df.index[idx]
        close = float(row['close'])
        atr = float(row.get('atr', close * 0.001))

        # Decide if we should do something this candle
        if self._rng.random() > self.execution_probability:
            return signals

        candle_signals: List[ChaosSignal] = []
        max_signals_per_candle = 3

        in_position = abs(self._simulated_position) > 0.001

        if in_position:
            num_actions = self._rng.randint(1, max_signals_per_candle)
            for _ in range(num_actions):
                action = self._rng.choices(
                    ['pyramid', 'partial_close', 'full_exit', 'nothing'],
                    weights=[
                        self.pyramid_probability,
                        self.partial_close_probability,
                        0.2,  # Full exit
                        0.25,  # Do nothing
                    ]
                )[0]

                if action == 'pyramid' and abs(self._simulated_position) < self.max_position_size:
                    signal = self._create_pyramid_signal(when, close, atr)
                    if signal:
                        candle_signals.append(signal)
                        self._update_simulated_position(signal.action, signal.volume)

                elif action == 'partial_close':
                    signal = self._create_partial_close_signal(when, close, atr)
                    if signal:
                        candle_signals.append(signal)
                        close_vol = self._simulated_position * signal.partial_ratio
                        self._simulated_position -= close_vol

                elif action == 'full_exit':
                    signal = self._create_exit_signal(when, close)
                    if signal:
                        candle_signals.append(signal)
                        self._simulated_position = 0.0
                        self._simulated_side = None
                        break
        else:
            num_entries = self._rng.randint(1, max_signals_per_candle)
            for _ in range(num_entries):
                signal = self._create_entry_signal(when, close, atr)
                if signal:
                    candle_signals.append(signal)
                    self._update_simulated_position(signal.action, signal.volume)

        signals.extend(candle_signals)
        return signals
    
    def _create_entry_signal(
        self,
        when: pd.Timestamp,
        close: float,
        atr: float,
    ) -> ChaosSignal | None:
        """Create a new entry signal with randomized parameters."""
        # Random direction
        action = self._rng.choice(['buy', 'sell'])
        
        # Random order type
        use_pending = self._rng.random() < self.pending_order_probability
        if use_pending:
            order_type = self._rng.choice(['limit', 'stop'])
        else:
            order_type = 'market'
        
        # Set entry price based on order type
        limit_price = None
        stop_price = None
        
        if order_type == 'limit':
            # Limit buy below market, limit sell above market
            offset = atr * self._rng.uniform(0.5, 2.0)
            if action == 'buy':
                limit_price = close - offset
            else:
                limit_price = close + offset
        elif order_type == 'stop':
            # Stop buy above market, stop sell below market
            offset = atr * self._rng.uniform(0.5, 2.0)
            if action == 'buy':
                stop_price = close + offset
            else:
                stop_price = close - offset
        
        # Random TIF and expiration
        use_gtd = self._rng.random() < self.gtd_probability
        if use_gtd:
            tif = 'GTD'
            # Expire in 1-10 candles (minutes for M1)
            expire_minutes = self._rng.randint(1, 10)
            valid_until = when + pd.Timedelta(minutes=expire_minutes)
        else:
            tif = self._rng.choice(['GTC', 'DAY'])
            valid_until = None
        
        # Random volume (but reasonable)
        volume = self._rng.uniform(0.1, 1.0)
        
        # Calculate SL/TP (realistic but random)
        # Note: These are set as prices, not points
        sl_distance = atr * self._rng.uniform(1.0, 3.0)
        tp_distance = atr * self._rng.uniform(2.0, 5.0)
        
        reason = f"chaos_entry_{order_type}_{tif}_c{self._candle_count}"
        
        return ChaosSignal(
            when=when,
            action=action,
            price=close,  # Signal price is market price at signal time
            reason=reason,
            order_type=order_type,
            limit_price=limit_price,
            stop_price=stop_price,
            tif=tif,
            valid_until=valid_until,
            volume=volume,
            is_pyramid=False,
            is_partial_close=False,
        )
    
    def _create_pyramid_signal(
        self,
        when: pd.Timestamp,
        close: float,
        atr: float,
    ) -> ChaosSignal | None:
        """Add to existing position."""
        if self._simulated_side is None:
            return None
        
        action = self._simulated_side
        
        # Pyramiding often uses market orders for quick fills
        use_market = self._rng.random() < 0.7
        order_type = 'market' if use_market else self._rng.choice(['limit', 'stop'])
        
        limit_price = None
        stop_price = None
        
        if order_type == 'limit':
            offset = atr * self._rng.uniform(0.2, 1.0)
            if action == 'buy':
                limit_price = close - offset
            else:
                limit_price = close + offset
        elif order_type == 'stop':
            offset = atr * self._rng.uniform(0.2, 1.0)
            if action == 'buy':
                stop_price = close + offset
            else:
                stop_price = close - offset
        
        tif = 'GTC'  # Pyramiding usually GTC
        volume = self._rng.uniform(0.1, 0.5)
        
        reason = f"chaos_pyramid_{order_type}_c{self._candle_count}"
        
        return ChaosSignal(
            when=when,
            action=action,
            price=close,
            reason=reason,
            order_type=order_type,
            limit_price=limit_price,
            stop_price=stop_price,
            tif=tif,
            valid_until=None,
            volume=volume,
            is_pyramid=True,
            is_partial_close=False,
        )
    
    def _create_partial_close_signal(
        self,
        when: pd.Timestamp,
        close: float,
        atr: float,
    ) -> ChaosSignal | None:
        """Close part of the position."""
        if self._simulated_side is None:
            return None
        
        # Close signal is opposite of position
        action = 'sell' if self._simulated_side == 'buy' else 'buy'
        
        # Partial closes usually market orders
        order_type = 'market'
        
        # Random partial ratio (25% to 75%)
        partial_ratio = self._rng.uniform(0.25, 0.75)
        
        # Volume is the amount to close
        volume = abs(self._simulated_position) * partial_ratio
        
        reason = f"chaos_partial_close_{partial_ratio:.1%}_c{self._candle_count}"
        
        return ChaosSignal(
            when=when,
            action=action,
            price=close,
            reason=reason,
            order_type=order_type,
            limit_price=None,
            stop_price=None,
            tif='GTC',
            valid_until=None,
            volume=volume,
            is_pyramid=False,
            is_partial_close=True,
            partial_ratio=partial_ratio,
        )
    
    def _create_exit_signal(
        self,
        when: pd.Timestamp,
        close: float,
    ) -> ChaosSignal | None:
        """Exit entire position."""
        if self._simulated_side is None:
            return None
        
        # Exit is opposite of position
        action = 'sell' if self._simulated_side == 'buy' else 'buy'
        
        volume = abs(self._simulated_position)
        
        reason = f"chaos_full_exit_c{self._candle_count}"
        
        return ChaosSignal(
            when=when,
            action=action,
            price=close,
            reason=reason,
            order_type='market',
            limit_price=None,
            stop_price=None,
            tif='GTC',
            valid_until=None,
            volume=volume,
            is_pyramid=False,
            is_partial_close=False,
        )
    
    def _update_simulated_position(self, action: str, volume: float) -> None:
        """Update internal position tracking."""
        if action == 'buy':
            self._simulated_position += volume
            self._simulated_side = 'buy'
        else:
            self._simulated_position -= volume
            self._simulated_side = 'sell'
        
        # Handle position flip
        if self._simulated_position < -0.001:
            self._simulated_side = 'sell'
        elif self._simulated_position > 0.001:
            self._simulated_side = 'buy'
        else:
            self._simulated_position = 0.0
            self._simulated_side = None
    
    def stop_distance_points(self, row: pd.Series) -> float:
        """Stop loss distance in price points."""
        close = float(row.get('close', 1.0))
        atr = float(row.get('atr', close * 0.001))
        return atr * self._rng.uniform(1.0, 3.0)
    
    def take_distance_points(self, row: pd.Series) -> float:
        """Take profit distance in price points."""
        close = float(row.get('close', 1.0))
        atr = float(row.get('atr', close * 0.001))
        return atr * self._rng.uniform(2.0, 5.0)


@dataclass
class ChaosConfig:
    """Configuration for chaos execution test strategy."""
    symbol: str = field(
        default="EURUSD",
        metadata={"group": "strategy", "description": "Trading symbol for chaos testing.", "optimizable": True},
    )
    timeframe: str = field(
        default="1m",
        metadata={"group": "strategy", "description": "Timeframe (always M1 for rapid testing).", "optimizable": True},
    )
    chaos_seed: int | None = field(
        default=None,
        metadata={"group": "strategy", "description": "Random seed for reproducibility.", "optimizable": False},
    )
    execution_probability: float = field(
        default=0.8,
        metadata={"group": "strategy", "description": "Chance to generate signal per candle (0.0-1.0).", "optimizable": True},
    )
    pyramid_probability: float = field(
        default=0.3,
        metadata={"group": "strategy", "description": "Chance to pyramid when in position.", "optimizable": True},
    )
    partial_close_probability: float = field(
        default=0.25,
        metadata={"group": "strategy", "description": "Chance to partially close position.", "optimizable": True},
    )
    pending_order_probability: float = field(
        default=0.5,
        metadata={"group": "strategy", "description": "Chance to use limit/stop vs market orders.", "optimizable": True},
    )
    gtd_probability: float = field(
        default=0.3,
        metadata={"group": "strategy", "description": "Chance to use GTD vs GTC/DAY.", "optimizable": True},
    )
    max_position_size: float = field(
        default=5.0,
        metadata={"group": "strategy", "description": "Maximum cumulative position size.", "optimizable": True},
    )


class ChaosConfigDrivenStrategy(BaseStrategy):
    """Config-driven wrapper for chaos strategy."""
    
    def __init__(self, cfg: ChaosConfig):
        self.symbol = cfg.symbol
        self.timeframe = cfg.timeframe
        self.cfg = cfg
        self._strategy = ChaosExecutionTestStrategy(
            symbol=cfg.symbol,
            chaos_seed=cfg.chaos_seed,
            execution_probability=cfg.execution_probability,
            pyramid_probability=cfg.pyramid_probability,
            partial_close_probability=cfg.partial_close_probability,
            pending_order_probability=cfg.pending_order_probability,
            gtd_probability=cfg.gtd_probability,
            max_position_size=cfg.max_position_size,
        )
    
    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        return self._strategy.prepare(df)
    
    def generate_signals(self, df: pd.DataFrame) -> List[Signal]:
        return self._strategy.generate_signals(df)
    
    def stop_distance_points(self, row: pd.Series) -> float:
        return self._strategy.stop_distance_points(row)
    
    def take_distance_points(self, row: pd.Series) -> float:
        return self._strategy.take_distance_points(row)
