"""
SARA - Smart Automated Response Agent
A Python library for building AI assistants
"""

__version__ = "0.0.1"
__author__ = "Ujwal Mantri"
__email__ = "ujwalmantrifr@gmail.com"

def greet():
    """Basic greeting function to test the package"""
    return f"SARA v{__version__} online. How may I assist you today?"

__all__ = ['greet', '__version__']