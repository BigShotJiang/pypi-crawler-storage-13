from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="sara-ai",
    version="0.0.1",
    author="Ujwal Mantri",
    author_email="ujwalmantrifr@gmail.com",
    description="SARA - Smart Automated Response Agent",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ujwalmantri/sara",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[],
    keywords="sara ai assistant voice automation",
)