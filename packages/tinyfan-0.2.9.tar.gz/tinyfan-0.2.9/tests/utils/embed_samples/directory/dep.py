def sayhi():
    print("hi")
