print("embed singlefile")
