##############################################################################
#
# Copyright (c) 2010 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
##############################################################################

from setuptools import setup


def _read(fname):
    with open(fname) as fp:
        return fp.read()


setup(
    name='Products.Sessions',
    version='6.2',
    url='https://github.com/zopefoundation/Products.Sessions/',
    project_urls={
        'Issue Tracker': ('https://github.com/zopefoundation'
                          '/Products.Sessions/issues'),
        'Sources': 'https://github.com/zopefoundation/Products.Sessions',
    },
    license='ZPL-2.1',
    description="Zope session management.",
    author='Zope Foundation and Contributors',
    author_email='zope-dev@zope.dev',
    long_description=_read('README.rst') + '\n' + _read('CHANGES.rst'),
    long_description_content_type='text/x-rst',
    classifiers=[
        "Development Status :: 6 - Mature",
        "Environment :: Web Environment",
        "Framework :: Zope",
        "Framework :: Zope :: 4",
        "Framework :: Zope :: 5",
        "License :: OSI Approved :: Zope Public License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Programming Language :: Python :: Implementation :: CPython",
    ],
    keywords="Zope sessions management Transience product ZMI",
    python_requires='>=3.10',
    install_requires=[
        'AccessControl',
        'Acquisition',
        'persistent',
        'Persistence',
        'transaction',
        'ZODB',
        'Zope >= 4.0b5',
        'zope.interface',
        'zope.deferredimport',
    ],
    extras_require={
        'tests': ['Products.TemporaryFolder >= 6.2'],
    },
    include_package_data=True,
    entry_points="""
    [zope2.initialize]
    Products.Sessions = Products.Sessions:initialize
    Products.Transience = Products.Transience:initialize
    """,
)
