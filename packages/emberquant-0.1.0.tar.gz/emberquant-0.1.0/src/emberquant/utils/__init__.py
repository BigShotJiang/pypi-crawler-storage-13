"""Utility functions for EmberQuant."""
