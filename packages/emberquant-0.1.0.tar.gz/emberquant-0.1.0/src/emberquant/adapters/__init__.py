"""Data source adapters for connecting to accounting systems."""

from emberquant.adapters.base import BaseAdapter, ConnectionConfig
from emberquant.adapters.csv_adapter import CSVAdapter
from emberquant.adapters.quickbooks_adapter import QuickBooksAdapter
from emberquant.adapters.xero_adapter import XeroAdapter

__all__ = [
    "BaseAdapter",
    "ConnectionConfig",
    "CSVAdapter",
    "QuickBooksAdapter",
    "XeroAdapter",
]
