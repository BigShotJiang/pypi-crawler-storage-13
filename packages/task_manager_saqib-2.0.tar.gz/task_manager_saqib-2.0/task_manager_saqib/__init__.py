import hashlib

current_user = ""   


def signup():
    global name
    name=input("---Enter your name---: ")
    password=input("---set password---: ")
    sha_hash=hashlib.sha1()
    sha_hash.update(password.encode("ascii"))
     
    x=sha_hash.hexdigest()
    
    user1 = open(f"C:/Users/91788/Desktop/users/user{name}", "a")
    user1.write(f"{name}:{x}\n")
    user1.close()
    
    return x


def login():
    global current_user   

    name=input("--Enter your name--:  ")
    passcode=input("--Password--: ")

    sha_hash=hashlib.sha1()
    sha_hash.update(passcode.encode("ascii"))
    x_dash=sha_hash.hexdigest()

    with open(f"C:/Users/91788/Desktop/users/user{name}", "r") as userauthenticator:
        for line in userauthenticator:
            line=line.strip()
            stored_name,stored_hash=line.split(":")

            if stored_name == name:           
                if stored_hash == x_dash:
                    print("Login successful!")
                    current_user = name     
                    return True             
                else:
                    print("Wrong password!")
                    return False            

    print("user not found")
    return False
    



def start():
    logged_in = False   

    while True:
        print("1 : Signup---")
        print("2 : Login--- ")
        print("3 : Exit---")

        choice = int(input("---Enter a choice---: "))

        if choice == 1:
            signup()

        elif choice == 2:
            if login():        
                logged_in = True
                print("You can now enter Task Manager")
                break          

        elif choice == 3:
            if logged_in:      
                break
            else:
                print("You MUST login first!")
                continue

        else:
            print("Invalid choice")

    return logged_in





tasks = []

def Add():
    task = input("---Enter a task---: ")
    tasks.append(task)

    with open (f"C:/Users/91788/Desktop/users/user{current_user}", "a") as file:
        file.write(task + "\n")
         
    print("Task added successfully!")
    print(task)


def Remove():
    task = input("---Enter a task to remove---: ")

    with open (f"C:/Users/91788/Desktop/users/user{current_user}", "r") as file:
        content = file.readlines()

    if task + "\n" in content:
        content.remove(task + "\n")
        tasks.remove(task)

        with open (f"C:/Users/91788/Desktop/users/user{current_user}", "w") as file:
            file.writelines(content)

        print("---Task removed successfully!---")
    else:
        print("---Task not found---")


def Update():
    task = input("---Enter a task to Update---: ")

    with open (f"C:/Users/91788/Desktop/users/user{current_user}", "r") as file:
        content = file.readlines()

    if task + "\n" in content:
        content.remove(task + "\n")

        newtask = input("Enter Task again to update: ")
        tasks.append(newtask)
        content.append(newtask + "\n")

        with open (f"C:/Users/91788/Desktop/users/user{current_user}", "w") as file:
            file.writelines(content)

        print("Task updated successfully")
    else:
        print("---Task not found---")



def run_task_manager():
    print("---Task Manager---")

    while True:
        print("\n1:-- Enter into Task Manager--")
        print("2:-- Exit --")
        option = int(input("Enter any option: "))

        if option == 2:
            print("---Successfully Exited---")
            break

        elif option == 1:
             if start():    
                 while True:
                    print("\n1: --Add Task--")
                    print("2: --Remove Task--")
                    print("3: --Update Task--")
                    print("4: --View tasks--")
                    print("5: Exit")

                    choice = int(input("Enter a Choice: "))

                    if choice == 5:
                        print("--Exited Task Manager--")
                        break

                    elif choice == 1:
                        Add()

                    elif choice == 2:
                        Remove()

                    elif choice == 3:
                        Update()

                    elif choice == 4:
                        with open (f"C:/Users/91788/Desktop/users/user{current_user}", "r") as file:
                             for ch in file:
                                  print(f"{ch}")
                             print(f"Tasks are {tasks}\n")

                    else:
                        print("%%Invalid choice%%.")
             else:
                print("You must login first!")



