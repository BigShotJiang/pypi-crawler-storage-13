def main():
    print("Hello from dspy-community!")


if __name__ == "__main__":
    main()
