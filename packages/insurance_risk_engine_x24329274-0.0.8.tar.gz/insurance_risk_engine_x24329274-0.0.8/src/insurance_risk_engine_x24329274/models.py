from dataclasses import dataclass
from typing import Dict

@dataclass
class DriverProfile:
    """
    Basic driver information relevant for rating.
    """
    age: int
    years_licensed: int
    location_band: str      # "low", "medium", "high"
    no_claims_years: int
    prior_claims: int       # integer count


@dataclass
class VehicleProfile:
    """
    Basic vehicle information relevant for rating.
    """
    value: float            # vehicle value in EUR
    annual_mileage: int
    usage: str              # "social", "commute", "business"


@dataclass
class QuoteResult:
    """
    Result of a premium calculation.
    """
    base_premium: float
    final_premium: float
    risk_score: float       # 0–1 scale
    breakdown: Dict[str, float]