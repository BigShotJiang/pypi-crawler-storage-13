

class ClaimImpact:
    """
    Models the impact of a single claim on the driver's risk score.
    Used mainly by the claim validation Lambda.
    """

    @staticmethod
    def apply(previous_risk_score: float, claim_amount: float) -> float:
        """
        Increase risk depending on the size of the claim.

        Small claim  (< 1000)  -> +0.05
        Medium claim (1000-3000)-> +0.12
        Large claim  (> 3000)  -> +0.20

        Risk score is capped at 1.0.
        """
        if claim_amount < 1000:
            bump = 0.05
        elif claim_amount < 3000:
            bump = 0.12
        else:
            bump = 0.20

        new_score = previous_risk_score + bump
        return min(1.0, round(new_score, 3))


if __name__ == "__main__":
    prev = 0.4
    for amt in (500, 1500, 5000):
        new = ClaimImpact.apply(prev, amt)
        print(f"Previous: {prev}, claim: {amt}, new risk: {new}")
        prev = new
