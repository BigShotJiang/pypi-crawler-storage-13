Insurancde Risk Engine

Insurance-Risk-Engine is a lightweight Python library for calculating motor insurance premiums and modelling risk changes after a claim.
It has no external dependencies and is suitable for use in any Python 3.7+ application. This library was developed as part of a cloud-based insurance claims project, where it is used both:
1) Inside a Django web application to generate insurance quotes for users
2) Inside an AWS Lambda validation pipeline to calculate post-claim premium adjustments.