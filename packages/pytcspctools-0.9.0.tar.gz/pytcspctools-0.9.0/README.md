# pyTCSPCtools

`pyTCSPCtools` provides a way to process and analyze TCSPC data, focusing on data collected with our [TCSPC devices](https://brunoweberlab.pages.uzh.ch/tcspc/index.html).It uses [Cython](https://cython.org/) to compile python wrappers for C++ methods and classes, enabling efficient processing of the binary data collected by our devices. The package focuses on the two main data objects used in the TCSPC++ code: `TTTRData` and `HistData`, offering the python wrappers `PyTTTRData` and `PyHistData` respectively.

### PyTTTRData
As the name suggests, this object is used to store time-tagged time-resolved data, meaning it contains all of the relevant information about each tagged event in arrays. Measurements stored in this format (`.ttd`) contain all of the information received from the TCSPC hardware, meaning that the data can be used to perform any type of analysis.

It is also possible to load a `Buffer (.buf)` file into a `(Py)TTTRData` object. The `Buffer` file contains the raw data from the TCSPC hardware packed in a space-efficient byte array format, however, the byte format makes operations on the data cumbersome which is why when loaded it is converted into a `TTTRData` object for processing. Choosing whether to store the data in a `.ttd` or `.buf` format is, therefore, a trade-off between loading speed and storage space.

### PyHistData
On the other hand, this object contains already processed data, that is, histograms of the time-tagged data. For each pixel or point measurement, a histogram with the number of photons detected at each time bin is stored. 

We provide the option to store the HistData object directly in a binary file (`.his`), however, since this data is generally the end result of an experiment we also provide the option to save it as an `OME-TIFF` file that can be opened with other software.

### PyGlobalFitter
Finally, the package also provides a wrapper for the global fitting algorithm of FLIMfit which can be used to find a multi-exponential fit for the data stored in a `(Py)HistData` object.

## Installation

**Note:** Currently, the package is only available for Windows due to the compilation of TCSPC++. Pre-compiled versions for Python 3.9+ are provided. However, the package can potentially be compiled for other Python versions as well.

```bash
pip install pyTCSPCtools
```

## Usage

It is best practice to import only the functions/classes that are needed. For example:

```python
from pyTCSPCtools.data import PyTTTRData, PyHistData
from pyTCSPCtools.analysis import PyGlobalFitter
```

The `notebooks` folder of the repository includes some examples of how to use the different objects with the provided test data.

## Documentation

The `doc` folder contains the full documentation of the package in both html and pdf formats. The easiest way to keep a quick access to the documentation is adding a bookmark in your browser to the `index.html` file within the doc folder.


## Cloning from the Gitlab

To clone from the gitlab you need some kind of authentication. The two supported options in our Gitlab are SSH keys and access tolkens.
If you already have an ssh key in your machine, the only thing to do is add the public key:

#### Adding an existing SSH key to Gitlab
1. Click on the user icon (top left) -> Preferences -> SSH key -> Add new key
2. Copy the public key from your machine stored in the .pub file (usually found in $user_dir$/.ssh)
3. Paste in the key field on Gitlab and save

#### Generatin a new SSH key
If you need to generate a ssh key run the following command in a terminal:

```bash
ssh-keygen -t ed25519 -C "<comment>"
```
You can accept all defaults and leave an empty passphrase. The comment can be anything you want e.g. email used to sign up to gitlab.

See [Gitlab SSH help](https://gitlab.uzh.ch/help/user/ssh) for more info on generating ssh keys.


