#rom typing_extensions import runtime
from cProfile import run
from setuptools import Extension, setup
from Cython.Build import cythonize
from Cython.Compiler import Options
import os, shutil
import numpy as np
from pathlib import Path

from configparser import ConfigParser
from setuptools.command.build_py import build_py as _build_py
from setuptools.command.develop import develop as _develop

# Collect DLLs from top-level "bin" directory
DLL_SOURCES = list(Path("bin").glob("*.dll"))

def _copy_dlls_into(target_dir: str):
    os.makedirs(target_dir, exist_ok=True)
    for src in DLL_SOURCES:
        dst = os.path.join(target_dir, src.name)
        shutil.copy2(str(src), dst)  # copy file preserving mtime

class build_py(_build_py):
    """Copy vendor DLLs into build_lib/pyTCSPCtools so they install next to the .pyd."""
    def run(self):
        super().run()
        pkg_dir = os.path.join(self.build_lib, "pyTCSPCtools")
        _copy_dlls_into(pkg_dir)

class develop(_develop):
    """For editable installs, copy DLLs into the source package dir."""
    def run(self):
        super().run()
        pkg_src_dir = "pyTCSPCtools"
        _copy_dlls_into(pkg_src_dir)


# Returns a list of filepaths to the .lib files (without the .lib) inside the folder given in path
def get_libraries(path):
    onlyfiles = [os.path.join(path, f) for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
    return [f[:-4].split("\\")[-1] for f in onlyfiles if f.endswith(".lib")]

# Get current path
# base_dir = os.path.dirname(os.path.dirname(__file__))
abs_dir = os.path.dirname(__file__) #r"C:\Code\TCSPC"
base_dir = abs_dir #os.path.dirname(abs_dir)
print("----------------------------------------------------")
print(f"base dir: {base_dir}")
print(f"abs dir: {abs_dir}")


# --- HEADERS ---
# Look for directories with required .h files
include_paths = [np.get_include()]
header_dirs = ["include"]
for header_dir in header_dirs:
    header_path = os.path.join(base_dir,header_dir)
    if not os.path.isdir(header_path):
        raise FileNotFoundError(f"Directory containing .h files not found: {header_path}")
    include_paths.append(header_path)
print("----------------------------------------------------")
print("headers:")
print(include_paths)
print("----------------------------------------------------")

# --- LIBRARIES ---
# Folders containing the libraries to link
library_dirs = ["lib"]
full_lib_dirs = [os.path.join(base_dir,lib_dir) for lib_dir in library_dirs]

# Static library files (without .lib)
libs = []#[r"C:\Program Files (x86)\Windows Kits\10\Lib\10.0.17763.0\um\x64\WS2_32"] #Requires path to WS2_32
for lib_dir in full_lib_dirs:
    libs += get_libraries(lib_dir)
print("----------------------------------------------------")
print("libs:")
print(libs)
print("----------------------------------------------------")

# --- DLLs ---
# Folders containing the libraries to link
dll_dirs = ["bin"]

# Static library files (without .lib)
dlls = []#[r"C:\Program Files (x86)\Windows Kits\10\Lib\10.0.17763.0\um\x64\WS2_32"] #Requires path to WS2_32
for dll_dir in dll_dirs:
    dlls += [os.path.join(dll_dir,dll) for dll in os.listdir(dll_dir) if dll.endswith(".dll")]
print("----------------------------------------------------")
print("dlls:")
print(dlls)
print("----------------------------------------------------")


# --- SETUP ---
Options.docstrings = True
extensions = [Extension("*", ["pyTCSPCtools/*.pyx"], include_dirs=include_paths, libraries=libs, library_dirs=full_lib_dirs)]
setup(packages=['pyTCSPCtools'], 
        ext_package="pyTCSPCtools", 
        package_data={"pyTCSPCtools": ["*.dll"]},  # ensure wheels include the DLLs
        include_package_data=True,
        cmdclass={
            "build_py": build_py,
            "develop": develop,   # ensures `pip install -e .` works too
        },
    #   data_files=[('Library/bin', dlls)],
        ext_modules = cythonize(extensions, compiler_directives={'embedsignature': True},annotate=True))
