# distutils: language=c++
from libc.stdint cimport int16_t, int32_t, uint8_t, uint16_t, uint32_t, uint64_t, uint_fast32_t
from pyTCSPCtools.data cimport TTTRData
from pyTCSPCtools.SimConf cimport SimConf

cdef extern from "TCSPCsim\DataSimulator.h":
    cdef cppclass DataSimulator:
        # -- Serialized metadata --
        # Simulation configuration
        #  Global parameters
        uint32_t numMolecules
        uint32_t total_num_cells
        uint32_t N[3]
        uint32_t pixelSize_nm
        double perpendicularObservationRadius_nm
        double parallelObservationRadius_nm
        double fluorescence_lifetime_ns[2]
        # Local parameters (ignored when simulating a non-uniform image)
        double brightnessAtCenter[2]

        # Probabilities
        uint_fast32_t P_jump[2]
        uint_fast32_t P_change[2]
        # Time resolution
        double totalTime
        double safetyFactor
        double absTimeResolution
        double relTimeResolution
        double pulseLengthResolution
        uint32_t numRelTimeBins
        # Reaction
        uint8_t includeReaction
        double reaction_rate[2]
        # IRF
        double FWHM
        double mu
        # Image simulation
        uint8_t imageSimulation
        uint32_t pixelsPerFrame
        uint32_t pixelsPerLine
        uint32_t numFrames
        uint32_t tPixel
        uint32_t tLine
        uint32_t tFrame
        uint32_t tImage
        uint8_t randomizePixels
        uint8_t nonUniformImage
        # Non-uniform image
        char imageSimulationFilesDir[512]
        uint32_t frameRateHz
        uint32_t lineChangeTime
        uint32_t frameChangeTime

        # I/O
        char outName[512]
        char outDir[512]
        char inName[512]
        char inDir[512]
        uint8_t verbose
        char version[16]

        # Derived parameters
        uint32_t totalTimeInt # Final simulation time (in integer timesteps)
        uint8_t nStates # If 2 reaction between two states is allowed
        uint32_t estEvents # Estimated number of photon events

        # Number of non-photon events
        uint32_t nPixelChangeEvents
        uint32_t nLineChangeEvents
        uint32_t nFrameChangeEvents
        uint32_t nTimeOverflowEvents
        uint32_t nOverflowEvents

        # Non-photon event timesteps
        uint32_t tStepPixel
        uint32_t tStepLine
        uint32_t tStepFrame
        uint32_t tOverflow
        #-- Simulation variables --
        uint32_t counter # Counter for photon events

        # Emission
        uint_fast32_t* P_emission_A_uniform
        uint_fast32_t* P_emission_B_uniform
        double* irf # Discrete IRF for simulation
        double* CDF # CDF of the convolved emission decay and IRF 

        # -- Serialized data --
        # Buffers for photon events
        uint32_t *absTimePhotons
        uint32_t *relTimePhotons

        # Constructors
        DataSimulator()
        DataSimulator(SimConf &inConf, uint32_t imageNr)

        # Methods
        void loadConf(SimConf &inConf)
        void configureSimulation()
        void configureImage()
        void allocateMetadata()
        void allocatePhotonBuffers()

        void simulate()
        void simulateUniform()
        void simulateNonUniformImage(double** pxParams)

        void assembleTTTRData(TTTRData &dataObj)
        # void assembleBuffer(Buffer &buffer)

        void toBin()
        void toBin(const char *filepath)
        void toCsv()
        void toCsv(const char *filepath)
        void fromBin()
        void fromBin(SimConf &inConf)
        void fromBin(const char *filepath)