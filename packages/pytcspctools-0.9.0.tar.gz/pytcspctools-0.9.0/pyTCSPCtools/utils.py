
def useful_functions():
    """
    Placeholder helper used by tests/examples; simply returns ``True``.

    Returns
    -------
    bool
        Always ``True``.
    """
    return True
