# distutils: language=c++
from libc.stdint cimport uint32_t, uint_fast32_t

cdef extern from "TCSPCsim\SimConf.h":
    cdef cppclass SimConf:
        # Input
        char outDir[512]
        char outFileName[512]
        char inDir[512]
        char inFileName[512]
        int verbose

        # General simulation settings
        int numMolecules
        int N[3] # Number of cells in each direction
        int pixelSize_nm # Side-length of each cell [nm]
        uint32_t laser_rate_MHz # Laser repetition rate [MHz]
        double totalTime # Total time to simulate [s]
        int numRelTimeBins #Number of bins to split the time between pulses (absTimeResolution) for time delay of photons

        double DiffCoeff[2] # Diffusion constants for each state [m^2/s]
        double perpendicularObservationRadius_nm # Radius of the observation volume in the direction perpendicular (x,y) to the beam [nm]
        double parallelObservationRadius_nm # Radius of the observation volume in the direction parallel (z) to the beam [nm]
        double fluorescence_intensity[2]
        double fluorescence_lifetime_ns[2]
        double reaction_rate[2]
        int includeReaction

        double FWHM
        double mu
        
        # Image parameters
        int pixelsPerFrame
        int numFrames

        # Buffer config
        uint32_t FPGA_MHz
        uint32_t FPGAdelayChainSteps

        char TTTRformat[512]
        char XscanningType[512]

        uint32_t TTTRRelTimeRes
        uint32_t TTTRAbsTimeRes
        uint32_t TTTRPulseWidthRes

        uint32_t bytesPerPacket

        # Derived values
        int total_num_cells
        double P_jump[2]
        uint_fast32_t P_jump_int[2]
        uint_fast32_t P_change_int[2]
        double brightnessAtCenter[2]
        double absTimeResolution #Time between laser pulses
        double relTimeResolution #Time resolution for photon delay data
        double pulseLengthResolution

        SimConf()
        void toFile(const char *filePath)
        void fromFile(const char *filePath)
        void printConf()
        void calcDerivedValues()