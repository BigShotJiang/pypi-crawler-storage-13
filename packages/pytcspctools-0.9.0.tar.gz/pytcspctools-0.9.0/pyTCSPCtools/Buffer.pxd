# distutils: language=c++
from libc.stdint cimport int16_t, int32_t, uint16_t, uint32_t, uint64_t, uint8_t
from libcpp cimport bool
from libcpp.vector cimport vector

cdef extern from "TCSPCcore/Buffer.h":
    cdef struct BufferAnalysis:
        # vector<uint64_t> linestarts
        # vector<uint64_t> lineends
        # vector<uint64_t> framechanges
        # vector<double> linetimes
        # vector<double> frametimes
        double lineTimeMicroS
        double pxDwellTimeMicroS
        uint32_t overflows
        uint64_t totEvents
        uint64_t eventsDiscarded
        uint64_t laserEvents
        uint64_t photonEvents
        uint64_t specialEvents


    cdef cppclass Buffer:
        # Constructor/destructor
        Buffer()

        # Socket *FPGAsocket = nullptr    

        # # -- Non serialized metadata --
        uint32_t isDebug
        char inName[512]
        char outName[512] 
        char inDir[512]
        char outDir[512]
        int sockfd
        uint32_t readFromFile 
        uint64_t headerOffset
        uint32_t ignoreClocks
        bool useFloat
        uint32_t timeMarker
        # For filtering while filling data objects
        bool filter_isFirstPhoton
        bool stopSignal
        uint64_t filter_totPhotons
        uint64_t filter_prevAbsTime
        uint32_t filter_compensateLasJitter
        uint32_t filter_lasJitter
        uint32_t filter_removeRepeatedPulseArtifacts
        uint32_t filter_removeLongRelTimeArtifacts
        uint32_t filter_maxRelTime
        uint32_t filter_removeShortPulses
        uint32_t filter_shortPlThresh
        uint32_t filter_removeLongPulses
        uint32_t filter_longPlThresh
        uint32_t counter_removeRepeatedPulseArtifacts
        uint32_t counter_removeLongRelTimeArtifacts
        uint32_t counter_removeShortPulses
        uint32_t counter_removeLongPulses
        BufferAnalysis scanInfo

        uint32_t pt2Channel
        uint8_t shiftPT2las

        # # -- Serialized metadata --
        char version[16]
        # Format
        uint32_t PT3OVERFLOW
        uint32_t PT2OVERFLOW
        char dataTypeToCollect[512]
        char TTTRformat[512]
        char HistFormat[512]
        char XscanningType[512]
        # uint32_t bytesPerPacket
        # uint32_t eventsPerPacket
        uint32_t bytesPerEvent
        uint32_t bytesPerPixel
        # uint32_t pixelsPerPacket
        double FPGAtimeToNs
        uint32_t TTTRRelTimeRes
        uint32_t TTTRAbsTimeRes
        uint32_t TTTRPulseWidthRes
        double relTimeResNs
        double absTimeResNs
        double pulseLengthResNs
        double maxPulseLengthTimeNs
        # Experiment
        char runType[512] 
        char stopType[512]
        double time
        # uint64_t recvPackets
        uint64_t bufsize
        # uint64_t offsetPk
        uint32_t nRuns
        uint32_t nAvgs
        uint32_t discardPartialRuns
        # uint32_t packetsPerRun
        # uint32_t testPackets
        uint32_t nRelTimeBins
        uint32_t pixelsPerRun
        uint32_t pixelsPerLine
        uint32_t lasMHz
        uint64_t collectionTimeMs 

        # # -- Serialized data --
        uint32_t* runSizes
        uint32_t* runFirstEventOffset
        uint32_t* runLastEventOffset
        # uint32_t* runPackets
        vector[uint8_t] data

        # virtual void configure(int sockfd, const Conf &inConf) 
        # void configureForTTTRSimulation(const SimConf &inConf)
        
        void allocate()
        void deallocate()
        void allocateRunVecs()
        void deallocateRunVecs()
        void initToZero()
        void initRunVecsToZero()
        
        void fill()
        void checkPacketLoss()
        void resize()

        void toBin()
        void toBin(const char *filepath)

        # void toCsv()
        # void toCsv(const char *filepath)

        void printMetadata()
        void printTTTRbufferAnalysis()
        void printTTTRbufferAnalysis(const char *filepath)
        void processScanInfo()