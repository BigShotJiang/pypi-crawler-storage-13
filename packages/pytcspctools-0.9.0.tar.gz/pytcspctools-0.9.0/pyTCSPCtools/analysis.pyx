# distutils: language=c++
#cython: boundscheck=False, wraparound=False, nonecheck=False, language_level=3
from pyTCSPCtools.GlobalFitter cimport GlobalFitter
from pyTCSPCtools.data cimport PyHistData

from libc.stdint cimport uint8_t, uint16_t, uint32_t, uint64_t, int16_t, int32_t, int64_t

import numpy as np
cimport numpy as np

cdef class PyGlobalFitter:
    """PyGlobalFitter

    Lightweight Cython wrapper around the C++ :class:`GlobalFitter` used
    for FLIM fitting.

    Parameters
    ----------
    isDebug : bool, optional
        If True the underlying fitter will print debug information during
        construction and fitting. Default is False.

    Attributes
    ----------
    gf : GlobalFitter
        The underlying C++ GlobalFitter instance (exposed via Cython).
    encoding : str
        String encoding used when converting between Python strings and C++
        char*/std::string (defaults to 'UTF-8').

    Notes
    -----
    This is a cdef class implemented in Cython and intended to be used from
    Python. Many methods on this wrapper forward calls directly to the
    corresponding C++ methods; see each method's docstring for expected
    argument types and return values.

    Examples
    --------
    >>> from pyTCSPCtools.analysis import PyGlobalFitter
    >>> gf = PyGlobalFitter(isDebug=True)
    >>> # Configure, import data and run a fit
    >>> gf.setIRFData(t_irf, irf)
    >>> gf.importDataFromArray(data)
    >>> gf.configureFitParams({...})
    >>> gf.runFLIMfit()
    """
    cdef GlobalFitter gf
    encoding = 'UTF-8'

    def __init__(self, isDebug=False):
        """Create a PyGlobalFitter wrapper.

        Parameters
        ----------
        isDebug : bool, optional
            If True, enable debug printing from the underlying C++ fitter.
        """
        if isDebug: 
            print("PyGlobalFitter constructor called.")
            print(self.gf.t_rep)
        self.gf.isDebug = isDebug
        # self.gf = GlobalFitter()
        
    def setIRFData(self, t_irf, irf):
        """Set instrument response function (IRF) data.

        Parameters
        ----------
        t_irf : array_like
            1D array containing IRF time points (units should be picoseconds).
        irf : array_like
            1D array containing IRF amplitude values.

        Notes
        -----
        Inputs are converted to contiguous float arrays and forwarded to the
        C++ implementation.
        """
        cdef uint16_t n_irf  = len(irf)
        cdef float [:] irf_float = np.ascontiguousarray(irf, dtype='f')
        cdef float [:] t_irf_float = np.ascontiguousarray(t_irf, dtype='f')
        self.gf.setIRFData(&irf_float[0], &t_irf_float[0], n_irf)

    def importHistData(self, py_hist_data: PyHistData):
        """Import histogram data from a :class:`PyHistData` instance.

        Parameters
        ----------
        py_hist_data : PyHistData
            A PyHistData object wrapping histogram data; the underlying
            C++ HistData reference is forwarded to the fitter.
        """
        self.gf.importHistData(py_hist_data.hist_data)
    
    def importDataFromArray(self, data, t_rep_ns=12.5):
        """Import image/time-series data from a numpy array.

        Parameters
        ----------
        data : ndarray
            3D array (X, Y, T) or 4D array (S, X, Y, T) containing image time
            series data. The array will be flattened and forwarded to the
            C++ fitter as contiguous floats.
        t_rep_ns : float, optional
            Laser repetition period in nanoseconds (default 12.5 ns).

        Raises
        ------
        ValueError
            If `data` is not 3D or 4D.
        """
        if data.ndim==3:
            n_images_ = 1
            n_x_ = data.shape[0]
            n_y_ = data.shape[1]
            n_t_ = data.shape[2]
        elif data.ndim==4:
            n_images_ = data.shape[0]
            n_x_ = data.shape[1]
            n_y_ = data.shape[2]
            n_t_ = data.shape[3]
        else:
            raise ValueError("Data must be 3D (XYT) or 4D (SXYT) array")
        data_flat = np.ascontiguousarray(data.ravel(), dtype=np.float32)
        # print(f"Flattened data shape: {data_flat.shape}")
        cdef float [:] data_float = data_flat
        self.gf.importDataFromArray(&data_float[0], n_images_, n_x_, n_y_, n_t_,t_rep_ns)

    def deallocateData(self):
        """Release any data buffers allocated in the underlying fitter."""
        self.gf.deallocateData()
    
    def getFitParams(self):
        """Return a dictionary with the current fit parameters.

        Returns
        -------
        dict
            Dictionary containing keys such as ``n_exp``, ``estimate_taus``,
            ``fit_beta``, ``fit_IRF``, ``IRFOffsetPs``, tau guesses and bounds,
            and other configuration values used by the fitter.
        """
        fit_params = {}
        fit_params['n_exp'] = self.gf.n_exp
        fit_params['estimate_taus'] = self.gf.estimate_initial_tau
        fit_params['fit_beta'] = self.gf.fit_beta
        fit_params['fit_IRF'] = self.gf.fit_t0
        fit_params['IRFOffsetPs'] = self.gf.t0_guess
        fit_params['fitType'] = self.gf.global_mode
        fit_params['tau_guess'] = []
        fit_params['beta_init'] = []
        fit_params['tau_min'] = []
        fit_params['tau_max'] = []
        for i in range(self.gf.n_exp):
            fit_params['tau_guess'].append(self.gf.tau_guess[i])
            fit_params['beta_init'].append(self.gf.beta_init[i])
            fit_params['tau_min'].append(self.gf.tau_min[i])
            fit_params['tau_max'].append(self.gf.tau_max[i])
        fit_params['wrap_around'] = self.gf.pulsetrain_correction
        fit_params['fit_stray_light'] = self.gf.fit_offset
        fit_params['stray_light_guess'] = self.gf.offset_guess
        return fit_params
    
    def getFitParamsDescription(self):
        """Return a description of the expected keys for ``configureFitParams``.

        The returned dictionary maps parameter names to a small structure that
        describes the expected type and whether the parameter is required.
        """
        fit_params_description = {}
        fit_params_description['n_exp'] = {'type': 'int', 'description': 'Number of exponential components in the fit', 'required': True}
        fit_params_description['estimate_taus'] = {'type': 'int', 'description': 'Flag indicating whether to estimate the tau values', 'required': True}
        fit_params_description['fit_beta'] = {'type': 'int', 'description': 'Flag indicating whether to fit the beta values', 'required': True}
        fit_params_description['fit_IRF'] = {'type': 'int', 'description': 'Flag indicating whether to fit the IRF', 'required': True}
        fit_params_description['IRFOffsetPs'] = {'type': 'double', 'description': 'Timeshift of the IRF in picoseconds', 'required': True}
        fit_params_description['fitType'] = {'type': 'string', 'description': 'Type of fitting to be performed ("Pixel", "Image", or "Global")', 'required': False}
        fit_params_description['tau_guess'] = {'type': 'double*', 'description': 'Initial guess values for the tau parameters. Required if estimate_taus is 0', 'required': False}
        fit_params_description['beta_init'] = {'type': 'double*', 'description': 'Initial guess values for the beta parameters. If fit_beta is 0 these should be the fixed beta values', 'required': False}
        fit_params_description['tau_min'] = {'type': 'double*', 'description': 'Minimum bound for the taus', 'required': False}
        fit_params_description['tau_max'] = {'type': 'double*', 'description': 'Maximum bound for the taus', 'required': False}
        fit_params_description['wrap_around'] = {'type': 'int', 'description': 'Flag indicating whether to apply wrap-around correction. Defaults to true', 'required': False}
        return fit_params_description

    def configureFitParams(self, fit_params):
        """Configure fitting parameters for subsequent fits.

        Parameters
        ----------
        fit_params : dict
            Configuration dictionary. Required keys: ``n_exp``, ``estimate_taus``,
            ``fit_beta``, ``fit_IRF``, and ``IRFOffsetPs``. See
            :py:meth:`getFitParamsDescription` for a fuller description of
            supported keys.
        """
        # fit_params: dict with the following fields:
        # REQUIRED: int n_exp, int estimate_taus, int fit_beta, int fit_IRF, double IRFOffsetPs
        # OTHERS:   string fitType, double* tau_guess (required if estimate_taus is 0), 
        #           double* beta_init (required if fit_beta==2), int wrap_around
        #           double* min_taus, double* max_taus, int fit_stray_light, double stray_light_guess,
        
        self.gf.configureFitParams(fit_params['n_exp'], fit_params['fit_beta'], fit_params['fit_IRF'], fit_params['IRFOffsetPs'])

        # Set tau guesses if necessary
        if 'tau_guess' not in fit_params and fit_params['estimate_taus'] == 0:
                print("Error: No guess values were provided for the taus, enabling tau estimation")
                fit_params['estimate_taus'] = True
        self.gf.estimate_initial_tau = fit_params['estimate_taus']
        if not self.gf.estimate_initial_tau:
            self.setTauGuess(fit_params['tau_guess'])

        # Set beta guesses/ values
        if fit_params['fit_beta'] > 1 or fit_params['fit_beta'] == 0:
            if 'beta_init' not in fit_params:
                print("Error: no guess/fixed values were provided for the betas. using 1/n_exp")
            else: 
                self.setBetaGuess(fit_params['beta_init'])

        # Define type of fitting done
        if 'fitType' in fit_params:
            if fit_params['fitType'] == 'Pixel':
                self.gf.global_mode = 0
            elif fit_params['fitType'] == 'Global':
                self.gf.global_mode = 2
            else:
                self.gf.global_mode = 1
        # Set other optional parameters
        if 'background_value' in fit_params:
            self.gf.background_value = fit_params['background_value']
        if 'wrap_around' not in fit_params:
            fit_params['wrap_around'] = 1
        self.gf.pulsetrain_correction = fit_params['wrap_around']
        if 'min_taus' in fit_params:
            self.setMinTau(fit_params['min_taus'])
        if 'max_taus' in fit_params:
            self.setMaxTau(fit_params['max_taus'])
        if 'fit_stray_light' in fit_params:
            self.gf.fit_offset = fit_params['fit_stray_light']
        if 'stray_light_guess' in fit_params:
            self.gf.offset_guess = fit_params['stray_light_guess']
        if 'algorithm' in fit_params:
            self.gf.algorithm = fit_params['algorithm'] # 0: Levenberg-Marquardt, 1: Maximum likelihood
        if 'fit_stray_light' in fit_params:
            self.gf.fit_offset = fit_params['fit_stray_light']
        if 'stray_light_guess' in fit_params:
            self.gf.offset_guess = fit_params['stray_light_guess']

    def setTauGuess(self, taus):
        """Set initial guesses for the exponential lifetimes (taus) in picoseconds.

        Parameters
        ----------
        taus : sequence
            Sequence of length ``n_exp`` providing initial lifetime guesses.
        """
        if len(taus) > self.gf.n_exp:
            print(f"Error: First set the correct number of exponentials (nExp={len(taus)}) using the configureFitParams function.")
        for i,tau in enumerate(taus):
            self.gf.tau_guess[i] = tau
    
    def setMinTau(self, minTaus):
        """Set lower bounds for tau values.

        Parameters
        ----------
        minTaus : sequence
            Lower bounds for each tau parameter.
        """
        if len(minTaus) > self.gf.n_exp:
            print(f"Error: First set the correct number of exponentials (nExp={len(minTaus)}) using the configureFitParams function.")
        for i,tau in enumerate(minTaus):
            self.gf.tau_min[i] = tau

    def setMaxTau(self, maxTaus):
        """Set upper bounds for tau values.

        Parameters
        ----------
        maxTaus : sequence
            Upper bounds for each tau parameter.
        """
        if len(maxTaus) > self.gf.n_exp:
            print(f"Error: First set the correct number of exponentials (nExp={len(maxTaus)}) using the configureFitParams function.")
        for i,tau in enumerate(maxTaus):
            self.gf.tau_max[i] = tau
    
    def setBetaGuess(self, betas):
        """Set initial or fixed beta (contribution) values.

        Parameters
        ----------
        betas : sequence
            Sequence of beta values for each exponential component.
        """
        if len(betas) > self.gf.n_exp:
            print(f"Error: First set the correct number of exponentials (nExp={len(betas)}) using the configureFitParams function.")
        for i,beta in enumerate(betas):
            self.gf.beta_init[i] = beta
        
    def configureFLIMfit(self):
        """Prepare internal structures and configuration needed for FLIM fitting.

        Returns
        -------
        int
            Error code from the underlying C++ ``configureFLIMfit`` call. (0: success)
        """
        return self.gf.configureFLIMfit()
    
    def print_params(self):
        """Print current fitter parameters to stdout (delegates to C++)."""
        self.gf.print_params()
    
    def runFLIMfit(self):
        """Run the configured FLIM fit.

        Returns
        -------
        int
            Exit code returned by the underlying C++ ``runFLIMfit`` method. (0: success)
        """
        if self.gf.isDebug:
            print("Running FLIMfit")
            print(f"n_t: {self.gf.n_t}")
            print(f"n_x: {self.gf.n_x}")
            print(f"n_y: {self.gf.n_y}")
            print(f"n_images: {self.gf.n_images}")
            print(f"n_irf: {self.gf.n_irf}")
            print(f"n_exp: {self.gf.n_exp}")
        cdef int e = self.gf.runFLIMfit()
        if self.gf.isDebug:
            print(f"FLIMfit fitting exited with value {e}")
        return e
    
    def fetchFLIMfitResults(self):
        """Fetch fit results from the C++ fitter into its result buffers."""
        self.gf.fetchFLIMfitResults()
    
    def printFLIMfitResults(self):
        """Print the most recently fetched FLIM fit results to stdout."""
        self.gf.printFLIMfitResults()

    def getNumberOfRegions(self):
        """Return the total number of fitted regions."""
        return self.gf.n_regions_total
    
    def getRegionSizes(self):
        """Return a list with the pixel count for each region.

        Returns
        -------
        list of int
            Number of pixels in each region in the same order as the fitter
            result arrays.
        """
        region_sizes = []
        for i in range(self.gf.n_regions_total):
            region_sizes.append(self.gf.region_size[i])
        return region_sizes
    
    def getFLIMfitResults(self):
        """Return a dictionary with fit statistics for each reported parameter.

        The dictionary keys are parameter names (strings) and values are 1D
        numpy arrays containing the per-parameter statistics as produced by
        the C++ fitter.
        """
        #fit_results = np.zeros((self.gf.n_output_params*self.gf.n_regions_total,))
        fit_results = {}
        for i in range(self.gf.n_output_params):
            name = self.gf.names[i].decode(self.encoding)
            data = np.zeros(11)
            for j in range(11):
                data[j] = self.gf.stats[i*11+j]
            fit_results[name] = data
        return fit_results

    def getFLIMfitInfo(self):
        """Return per-region summary information produced by the fitter.

        Returns
        -------
        dict
            Dictionary with keys ``image``, ``regions``, ``region_size``,
            ``success`` and ``iterations``; each value is a list with one
            element per region.
        """
        fitInfo = {'image': [],
                   'regions': [],
                   'region_size': [],
                   'success': [],
                   'iterations': []}
        for i in range(self.gf.n_regions_total):
            fitInfo['image'].append(self.gf.image[i])
            fitInfo['regions'].append(self.gf.regions[i])
            fitInfo['region_size'].append(self.gf.region_size[i])
            fitInfo['success'].append(self.gf.success[i])
            fitInfo['iterations'].append(self.gf.iterations[i])
        return fitInfo

    
    def getFitParamImage(self, paramName):
        """Return a 1D numpy array with the requested parameter values for the
        image.

        Parameters
        ----------
        paramName : str
            Name of the parameter to retrieve (as reported in
            :py:meth:`getFLIMfitResults`).

        Returns
        -------
        ndarray
            1D float32 array containing parameter values (one per pixel) for
            the image.
        """
        nPixels = self.gf.region_size[0]
        paramImage = np.ascontiguousarray(np.zeros((nPixels,), dtype = np.float32))
        cdef float[:] paramImagePtr = paramImage # Memoryview of numpy array
        self.gf.getParameterImage(paramName.encode(self.encoding), &paramImagePtr[0])
        return paramImage

    def getFitParamRegion(self, paramName, regionNr):
        """Return a 1D numpy array with the requested parameter values for a
        specified region.

        Parameters
        ----------
        paramName : str
            Name of the parameter to retrieve.
        regionNr : int
            Index of the region to extract values for.

        Returns
        -------
        ndarray
            1D float32 array containing parameter values for the requested
            region.
        """
        nPixels = self.gf.region_size[regionNr]
        paramImage = np.ascontiguousarray(np.zeros((nPixels,), dtype = np.float32))
        cdef float[:] paramImagePtr = paramImage # Memoryview of numpy array
        self.gf.getParameterImage(paramName.encode(self.encoding), &paramImagePtr[0])
        return paramImage

# def _extractSubsetDataTTTR(tttr_obj: PyTTTRData, absTimeStartSec, absTimeEndSec):
#     new_tttr_obj:PyTTTRData = PyTTTRData()
#     new_tttr_obj.tttr_data.nEvents = tttr_obj.tttr_data.nEvents
#     new_tttr_obj.tttr_data.allocateData()
#     extractSubsetDataTTTR(new_tttr_obj.tttr_data, tttr_obj.tttr_data, absTimeStartSec, absTimeEndSec)
#     new_tttr_obj.updateMetadata()
#     return new_tttr_obj

# def _calculateDecayHistogram(tttr_obj: PyTTTRData, nBins):
#     # Calculate histogram data in C++
#     # Create numpy array of size nBins and get C-style pointer 
#     cdef np.ndarray npHistData = np.zeros((nBins,), dtype = np.uint32) # C-define a numpy array with the correct data type so we can fill it up directly in C++ by passing the pointer to the data of this object
#     cdef uint32_t* histData = <uint32_t *>npHistData.data # Get the pointer to the numpy array data
#     # Call C++ function to calculate the histogram
#     cdef double newRelTimeRes = 0
#     calculateDecayHistogram(tttr_obj.tttr_data.relTime, tttr_obj.tttr_data.relTimeResNs, tttr_obj.tttr_data.absTimeResNs, tttr_obj.tttr_data.nEvents, histData, <int>nBins, newRelTimeRes)
#     return npHistData.astype(int)

# cdef class PyDataSimulator:
#     cdef DataSimulator sim
#     cdef SimConf conf
#     cdef uint32_t imageNumber
#     self.encoding = 'UTF-8'
#     def __init__(self, config_path, imageNr=0):
#         self.imageNumber = imageNr
#         self.conf.fromFile(config_path.encode(self.encoding))
#         self.conf.printConf()
#         self.sim = DataSimulator(self.conf, self.imageNumber)
    
#     def getSimParameters(self):
#         parameters={'imageSimulation': self.sim.imageSimulation,
#                     'pixelsPerFrame': self.sim.pixelsPerFrame,
#                     'numFrames': self.sim.numFrames,
#                     'absTimeResNs': self.sim.absTimeResolution,
#                     'relTimeResNs': self.sim.relTimeResolution,
#                     'totalTime': self.sim.totalTime,
#                     'includeReaction':self.sim.includeReaction,
#                     'numMolecules': self.sim.numMolecules,
#                     'taus': [self.sim.fluorescence_lifetime_ns[0], self.sim.fluorescence_lifetime_ns[1]],
#                     'brightness':[self.sim.brightnessAtCenter[0],self.sim.brightnessAtCenter[1]]}
#         return parameters
    
#     def runSimulation(self, pixelBrightness=[]):
#         self.sim.configureSimulation()
#         cdef double** pixelBrightnessPtr
#         if len(pixelBrightness)>0:
#             nPixels = np.size(pixelBrightness,0)
#             nValues = np.size(pixelBrightness,1)
#             pixelBrightnessPtr = <double**>malloc(nPixels*sizeof(double*))
#             for i in range(nPixels):
#                 pixelBrightnessPtr[i] = <double*>malloc(nValues*sizeof(double))
#                 for j in range(nValues):
#                     pixelBrightnessPtr[i][j] = pixelBrightness[i][j]
#             self.sim.simulateNonUniformImage(pixelBrightnessPtr)
#         else:
#             self.sim.simulate()
#     def assembleTTTRData(self):
#         tttrData = PyTTTRData()
#         tttrData.tttr_data.isDebug = 1
#         tttrData.tttr_data.pulseLengthResNs = self.conf.pulseLengthResolution
#         tttrData.tttr_data.lasMHz = self.conf.laser_rate_MHz
#         strcpy(tttrData.tttr_data.TTTRformat, self.conf.TTTRformat)
#         tttrData.tttr_data.printMetadata()
#         self.sim.assembleTTTRData(tttrData.tttr_data)
#         return tttrData
    
#     def configureSimFromDict(self,opt_dict):
#         # Copy the options from the dictionary into the SimConf object
#         strcpy(self.conf.outDir, opt_dict['outDir'].encode(self.encoding))
#         strcpy(self.conf.outFileName, opt_dict['outFileName'].encode(self.encoding))
#         self.conf.numMolecules = opt_dict['numMolecules']
#         for i in range(3):
#             self.conf.N[i] = opt_dict['N'][i]
#         self.conf.pixelSize_nm = opt_dict['pixelSize_nm']
#         self.conf.totalTime = opt_dict['totalTime']
#         self.conf.laser_rate_MHz = opt_dict['laser_rate_MHz']
#         self.conf.numRelTimeBins = opt_dict['numRelTimeBins']

#         # Diffusion parameters
#         if opt_dict['includeReaction']:
#             self.conf.DiffCoeff[0] = opt_dict['DiffCoeff'][0]
#             self.conf.DiffCoeff[1] = opt_dict['DiffCoeff'][1]
#         else:
#             self.conf.DiffCoeff[0] = opt_dict['DiffCoeff']
#             self.conf.DiffCoeff[1] = 0

#         # Reaction parameters
#         if opt_dict['includeReaction']:
#             self.conf.reaction_rate[0] = opt_dict['reaction_rate'][0]
#             self.conf.reaction_rate[1] = opt_dict['reaction_rate'][1]
#         else:
#             self.conf.reaction_rate[0] = 0
#             self.conf.reaction_rate[1] = 1
#         self.conf.includeReaction = opt_dict['includeReaction']

#         # Photon emission parameters
#         self.conf.perpendicularObservationRadius_nm = opt_dict['perpendicularObservationRadius_nm']
#         self.conf.parallelObservationRadius_nm = opt_dict['parallelObservationRadius_nm']
#         if opt_dict['includeReaction']:
#             self.conf.fluorescence_intensity[0] = opt_dict['fluorescence_intensity'][0]
#             self.conf.fluorescence_intensity[1] = opt_dict['fluorescence_intensity'][1]
#             self.conf.fluorescence_lifetime_ns[0] = opt_dict['fluorescence_lifetime_ns'][0]
#             self.conf.fluorescence_lifetime_ns[1] = opt_dict['fluorescence_lifetime_ns'][1]
#         else:
#             self.conf.fluorescence_intensity[0] = opt_dict['fluorescence_intensity']
#             self.conf.fluorescence_intensity[1] = 0
#             self.conf.fluorescence_lifetime_ns[0] = opt_dict['fluorescence_lifetime_ns']
#             self.conf.fluorescence_lifetime_ns[1] = 0

#         # Gaussian IRF parameters
#         self.conf.FWHM = opt_dict['irfFWHM']
#         self.conf.mu = opt_dict['irfMu']

#         # Miscellaneous
#         self.conf.verbose = opt_dict['verbose']

#         # Calculate derived values
#         self.conf.calcDerivedValues()
#         self.conf.printConf()


