# distutils: language=c++
from libc.stdint cimport uint32_t, uint16_t
from pyTCSPCtools.data cimport HistData
from libcpp cimport bool
from libcpp.string cimport string

cdef extern from "TCSPCprocess\GlobalFitter.h":
    cdef cppclass GlobalFitter:
        bool isDebug
        # Fitting data
        double* irf
        double* t_irf
        uint16_t* image_data
        bool useFloat
        float* image_data_float

        #FLIMfit parameters
        int id
        int n_output_params
        int n_regions_total
        int n_regions
        int* image
        int* regions
        int* region_size
        float* success
        int* iterations
        float* stats
        const char** names

        # Fitter parameters
        int global_algorithm
        int image_irf
        int n_irf
        double pulse_pileup
        double *t0_image
        int n_exp
        int n_fix
        int n_decay_group
        int *decay_group
        double *tau_min
        double *tau_max
        int estimate_initial_tau
        double *tau_guess
        int fit_beta # Fit Contributions (GUI)
        double *beta_init
        int fit_t0 # Fit IRF Shift (GUI)
        double t0_guess # IRF Shift (GUI)
        
        # Stray light
        int fit_offset
        double offset_guess
        int fit_scatter 
        double scatter_guess
        int fit_tvb
        double tvb_guess
        double *tvb_profile
        # FRET
        int n_fret
        int n_fret_fix
        int inc_donor
        double *E_guess 
        # Advanced
        int pulsetrain_correction
        double t_rep
        int ref_reconvolution
        double ref_lifetime_guess
        int algorithm 
        int weighting 
        int calculate_errors
        double conf_interval
        int n_thread 
        int runAsync 
        int use_callback
        int (*callback)()

        # Data parameters
        int n_images
        int n_x
        int n_y
        int n_chan
        int n_t
        double *t
        double *t_int
        int t_skip 
        int data_type
        int use_im
        uint16_t *mask
        int merge_regions
        int threshold 
        int limit 
        double counts_per_photon
        int global_mode
        int smoothing_factor
        int use_autosampling
        float background_value

        # Constructors
        GlobalFitter()

        # Configuration
        void setIRFData(float *irf_float, float *t_irf_float, uint16_t n_irf_in)
        void importHistData(HistData &data)
        void importDataFromArray(float *data, int n_images, int n_x, int n_y, int n_t,double t_rep_ns)
        void deallocateData()
        void configureFitParams(int n_exp, int fit_beta, int fit_t0, double t0_guess)
        int configureFLIMfit()
        void print_params()

        # Fitting
        int runFLIMfit()

        # Results
        void allocateResultBuffers()
        void fetchFLIMfitResults()
        void printFLIMfitResults()
        void getParameterImage(string param, float *paramImage)
        void getParameterImage(string param, float *paramImage, int img_index)