# distutils: language=c++
from libc.stdint cimport uint32_t, int16_t

cdef extern from r"TCSPCprocess\functions\io.h":
    cdef struct TTTRDataStruct:
        char inName[512]
        char inDir[512]
        double relTimeResNs
        double absTimeResNs
        uint32_t nEvents

        uint32_t* absTime
        uint32_t* relTime
        int16_t* eventType
    void loadDataFromBinary(TTTRDataStruct *dataStruct)
