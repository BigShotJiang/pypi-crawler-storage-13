from ome_types import from_xml, to_xml, OME
from ome_types.model import Pixels, Image, Channel, TiffData, XMLAnnotation, StructuredAnnotations
from ome_types.model.simple_types import PixelType
from tifffile import imread, imwrite, TiffFile, TiffWriter
import numpy as np
import os

import warnings
warnings.filterwarnings('ignore', message='.*invalid AnnotationID', )


def read_ome_tiff(file_path, keep_tiff_axes=False, read_ome=True):
    '''
    Reads an OME-TIFF file and returns a dictionary with the OME metadata and the image data.
    It uses the tifffile library to read the OME-TIFF file and the ome_types library to parse the OME XML metadata.
    
    Parameters:
    ----------
    file_path: str
        The path to the OME-TIFF file
    keep_tiff_axes: bool, optional
        If True, the axis order of the image data is not changed (T is the first dimenson). 
        If False, the axis order is changed to our convention (XYT).

    Returns:
    -------
    dict
        A dictionary with the OME metadata and the image data
    '''
    ome_img = {}
    with TiffFile(file_path) as tif:
        # Read the image data
        ome_img['data'] = tif.asarray()
        if not keep_tiff_axes:
            try:
                t_axis = tif.series[0].axes.index('T')
                ome_img['data'] = np.moveaxis(ome_img['data'], t_axis, -1)
            except:
                Warning(f"Could not find the T axis in the OME-TIFF file, keeping the original axis order: {tif.series[0].axes}")
            
        if read_ome:
            # Read the OME metadata
            ome_data = from_xml(tif.ome_metadata)
    if read_ome:
        ome_img['annotations'] = parse_ome_annotations(ome_data.structured_annotations)
        ome_img['pixels'] = extract_pixels_info(ome_data.images[0].pixels)
    return ome_img

def write_ome_tiff(out_path, data, lasMHz, useFloat=False, annotations=None, keep_axis_order=False):
    '''
    Writes an OME-TIFF file with the given data and OME metadata dictionary.
    It uses the tifffile library to write the OME-TIFF file and the ome_types library to convert the OME metadata to XML.
    
    Parameters:
    -----------
    out_path: str
        The path to save the OME-TIFF file
    data: numpy.ndarray
        The image data to save
    lasMHz: float
        The laser frequency in MHz use to compute the lifetime time step
    useFloat: bool, optional
        If True, the pixel type will be FLOAT32, otherwise it will be UINT16
    annotations: dict, optional
        NOT YET IMPLEMENTED. A dictionary with the any additional OME metadata annotations (e.g. to store custom metadata)
    keep_axis_order: bool, optional
        If True, the axis order of the image data is not changed (use when T is already the first dimenson). 
        If False, the axis order is changed from our convention (XYT) to the TIFF standard (TYX).
    '''
    # Ensure the data has the right shape
    if len(data.shape) == 1: # Point decay
        data = data[np.newaxis, np.newaxis, :]
        data_dim = 1
    elif len(data.shape) == 2: # Single line
        data = data[:,np.newaxis,:]
        data_dim = 2
    else:
        data_dim = len(data.shape)
    
    shape = data.shape
    linesPerFrame = shape[0]
    pixelsPerLine = shape[1]
    nRelTimeBins = shape[-1]

    # Move the time dimension to the front
    data = np.moveaxis(data, -1, 0)
    
    # Create the OME metadata
    ome = create_OME_Metadata(pixelsPerLine, linesPerFrame, nRelTimeBins, lasMHz, useFloat)

    # Write the OME-TIFF file
    if out_path.endswith('.ome.tiff'):
        out_path = out_path[:-9]
    elif out_path.endswith('.ome.tif'):
        out_path = out_path[:-8]
    elif out_path.endswith('.tif'):
        out_path = out_path[:-4]
    dtype = np.float32 if useFloat else np.uint16
    data = data.astype(dtype)
    with TiffWriter(out_path+'.ome.tiff') as tif:
        if True:
            # Manually write the separate planes to ensure the T axis is preserved
            for i in range(nRelTimeBins):
                if i == 0:
                    tif.write(data[i], description=to_xml(ome), metadata={"axes": "TYX"}, contiguous=True)
                else:
                    tif.write(data[i], metadata={"axes": "TYX"}, contiguous=True)
        else: # Currently not working
            # Write the data as a single block
            tif.write(data, description=to_xml(ome), metadata={"axes": "TYX"}, contiguous=True)

def parse_ome_annotations(structured_annotations):
    '''
    Convert :class:`StructuredAnnotations` into a list of lightweight
    dictionaries for easier downstream consumption.

    Parameters
    ----------
    structured_annotations : StructuredAnnotations
        The parsed OME structured annotations block.

    Returns
    -------
    list of dict
        One dictionary per annotation, with the original namespace preserved
        where possible.
    '''
    if not isinstance(structured_annotations, StructuredAnnotations):
        raise TypeError("structured_annotations must be an instance of StructuredAnnotations")

    # Extract the annotations from the structured annotations
    annotations = []
    for key,list in structured_annotations.__dict__.items():
        try:
            if len(list) > 0:
                for item in list:
                    annotation = {'type':key}
                    if item.namespace == 'openmicroscopy.org/omero/dimension/modulo':
                        annotation.update(extract_modulo_info(item))
                    else:
                        annotation[item.namespace] = item.value
                    annotations.append(annotation)
        except:
            Warning(f"Could not convert {key} to dictionary")
            pass
    
    return annotations

def extract_modulo_info(modulo_annotation):
    '''
    Extracts the modulo information from the XMLAnnotation and returns it as a dictionary
    '''
    if not isinstance(modulo_annotation, XMLAnnotation):
        raise TypeError("modulo_annotation must be an instance of XMLAnnotation")
    return {modulo_annotation.value.any_elements[0].qname: modulo_annotation.value.any_elements[0].attributes}

def extract_pixels_info(pixels:Pixels):
    '''
    Extracts the pixels information from the Pixels object and returns it as a dictionary
    '''    
    return {key: value for key, value in pixels.__dict__.items() if key not in ['channels', 'bin_data_blocks', 'tiff_data_blocks','planes'] and value is not None}

def create_OME_Metadata(pixelsPerLine, linesPerFrame, nRelTimeBins, lasMHz, useFloat):
    '''
    Creates an OME-XML object with the given image dimensions and lifetime time step.

    Parameters:
    ----------
    pixelsPerLine: int
        The number of pixels per line
    linesPerFrame: int
        The number of lines per frame
    nRelTimeBins: int
        The number of relative time bins
    lasMHz: float
        The laser frequency in MHz use to compute the lifetime time step
    useFloat: bool
        If True, the pixel type will be FLOAT32, otherwise it will be UINT16

    Returns:
    -------
    OME object
        An OME-XML object with the given image parameters and lifetime moduloT information
    '''

    # Create an OME-XML object
    ome = OME()

    # Create a Pixels object
    pixels = Pixels(
        dimension_order='XYZCT',
        size_c=1,
        size_t=nRelTimeBins,
        size_x=pixelsPerLine,
        size_y=linesPerFrame,
        size_z=1,
        type=PixelType.UINT16 if not useFloat else PixelType.FLOAT,

    )
    # Add a Channel object to the Pixels object
    pixels.channels = [Channel(id='Channel:0:0', samples_per_pixel=1)]

    # Create a TiffData object
    tiff_data = [TiffData(
        first_c=0,
        first_t=i,
        first_z=0,
        plane_count=1,
        ifd=i,
    ) for i in range(nRelTimeBins)]

    # Add the TiffData object to the Pixels object
    pixels.tiff_data_blocks = tiff_data

    # Create an XML annotation object for the moduloT information
    lasPeriodNs = 1000/lasMHz
    tStep = lasPeriodNs/(nRelTimeBins-1)
    moduloT = XMLAnnotation(
        id='Annotation:1',
        namespace='openmicroscopy.org/omero/dimension/modulo',
        value=f'<ModuloAlongT xmlns="" Unit="ns" Start="0" Type="lifetime" Step="{tStep}" End="{lasPeriodNs}"/>'
    )

    # Create an Image object
    image = Image(id='Image:0',pixels=pixels, annotation_refs = [{'id': 'Annotation:1'}])

    # Add the Image object to the OME-XML object
    ome.images = [image]
    ome.structured_annotations = [moduloT]

    return ome
