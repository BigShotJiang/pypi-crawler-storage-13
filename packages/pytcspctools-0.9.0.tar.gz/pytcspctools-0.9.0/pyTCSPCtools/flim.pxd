# distutils: language=c++
from libc.stdint cimport uint32_t

cdef extern from r"TCSPCprocess\functions\flim.h":
    void calculateDecayHistogram(uint32_t* relTime, double relTimeResNs, double absTimeResNs, int nEvents, uint32_t* histData, int nBins)
    void calculateDecayHistogram(uint32_t* relTime, double relTimeResNs, double absTimeResNs, int nEvents, uint32_t* histData, int nBins, double &newRelTimeRes)
    #void fitHistData(uint32_t* histData, double histTimeResNs, int nBins, double irfFWHM, double irfMu, double tEndFit, float params[3])
