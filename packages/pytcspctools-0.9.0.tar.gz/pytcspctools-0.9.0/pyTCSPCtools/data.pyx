# distutils: language=c++
#cython: boundscheck=False, wraparound=False, nonecheck=False

from pyTCSPCtools.data cimport TTTRData, HistData
from pyTCSPCtools.PURELIGHT cimport computeStateHistogram, extendDeadTime, maskPhotonEvents, unmaskAllPhotonEvents, computeSCMWeights, applyLinearRTC, computeMultiPhotonMask, computeLaserPeriodDeadTimeMask
from pyTCSPCtools.Buffer cimport Buffer

from libc.string cimport strcpy, memcpy, strcmp
from libc.stddef cimport size_t
from libc.stdint cimport uint8_t, uint16_t, uint32_t, uint64_t, int16_t, int32_t, int64_t

import numpy as np
cimport numpy as np
import os
import warnings

# Try to import ome_tools
try:
    from pyTCSPCtools.ome_tools import read_ome_tiff, write_ome_tiff
    ome_tools_available = True
except ImportError:
    ome_tools_available = False



cdef class PyTTTRData:
    """
    A wrapper of the C++ TTTRData class. The C++ class is used to load and process TTTR (Time-tagged time-resolved) data.
    This class contains metadata relevant to the measurment as well as arrays that store the properties of all measured events.

    Attributes
    ----------
    tttr_data : TTTRData
        An instance of the C++ TTTRData class. This should only be accessed via the wrapper functions provided in this class.
    encoding : str
        Encoding used for string operations to and from C++, the default is 'UTF-8'.
    """

    encoding = 'UTF-8'
    N_CHANNELS = 7

    def __init__(self, py_tttr_data:PyTTTRData=None,isDebug=False):
        """
        Initialize an empty PyTTTRData object.
        Parameters
        ----------
        py_tttr_data : PyTTTRData, optional
            An existing PyTTTRData object to copy the data from (NOT WORKING). Default is None.
        isDebug : bool, optional
            Whether to enable debug (verbose) mode for the TTTR data. Default is False.
        """
        if py_tttr_data != None:
            # Use the copy constructor of the C++ class
            self.tttr_data = TTTRData(py_tttr_data.tttr_data)

            # These copy loops are needed as the serialized data is not being copied correctly by the C++ class
            self.tttr_data.allocateData()
            for i in range(self.tttr_data.nEvents):
                self.tttr_data.copyEvent(py_tttr_data.tttr_data,i,i)
            for i in range(self.N_CHANNELS):
                self.tttr_data.activeChannels[i] = py_tttr_data.tttr_data.activeChannels[i]
                self.tttr_data.channelOffset[i] = py_tttr_data.tttr_data.channelOffset[i]

        else:
            self.tttr_data = TTTRData()

        self.tttr_data.isDebug = isDebug

    def __copy__(self):
        """
        Copy the PyTTTRData object.

        Returns
        -------
        PyTTTRData
            A copy of the PyTTTRData object.
        """
        return PyTTTRData(self)
    cpdef getFilePath(self):
        """
        Get the file path of the TTTR data.

        Returns
        -------
        str
            The concatenated directory and file name.
        """
        return self.tttr_data.inDir+self.tttr_data.inName
    
    cpdef setFilePath(self, inDir, inName):
        """
        Set the directory and file name for the TTTR data.

        Parameters
        ----------
        inDir : str
            Directory path where the file is located.
        inName : str
            Name of the file.
        """
        strcpy(self.tttr_data.inDir, inDir.encode(self.encoding))
        strcpy(self.tttr_data.inName, inName.encode(self.encoding))
    
    cpdef loadDataFromBinary(self, dir=None, filename=None, overrideTTTRformat=None):
        """
        Load TTTR data from a binary TTTR file (.ttd). if the directory and filename were set before, they can be omitted.

        Parameters
        ----------
        dir : str, optional
            Directory path where the binary file is located. Default is None.
        filename : str, optional
            Name of the binary file including the file extension. Default is None.
        """
        if dir != None:
            strcpy(self.tttr_data.inDir,dir.encode(self.encoding))
        if filename != None:
            strcpy(self.tttr_data.inName,filename.encode(self.encoding))
        self.tttr_data.fromBin()  
        self.tttr_data.processChannelInfo()
        if overrideTTTRformat != None:
            strcpy(self.tttr_data.TTTRformat, overrideTTTRformat.encode(self.encoding))
    
    cpdef loadDataFromBuffer(self, dir, filename, lasMHz=None, filter_long_rel_times=False, remove_short_pulses=False,short_pulse_thresh_ns=0.5, remove_long_pulses=False, long_pulse_thresh_ns=6, channels=[1], pt2_mode=None, ignore_run_offsets=False):
        """
        Load TTTR data from a experiment buffer file (.buf). 
        The buffer file is a binary file that contains the byte stream received from the FPGA as well as some metadata relevant to the measurement.

        Parameters
        ----------
        dir : str
            Directory path where the buffer file is located.
        filename : str
            Name of the buffer file.
        lasMHz : float, optional
            Laser frequency in MHz (optional as the buffer file contains this information). Default is None.
        filter_long_rel_times : bool, optional
            Whether to filter photon events with relative times longer than the laser repetition rate (e.g. relative times over 12.5ns for an 80MHz laser), by default False.
        remove_short_pulses : bool, optional
            Only applies to data that includes the pulse width (currently: PT3_64, PT3_48X, PT3_64X). Whether to filter photon events with pulse widths shorter than a threshold, by default False.
        short_pulse_thresh_ns : float, optional
            Minimum pulse width in nanoseconds to keep the event, by default 0.5 ns. Only applies if remove_short_pulses is True.
        remove_long_pulses : bool, optional
            Only applies to data that includes the pulse width (currently: PT3_64, PT3_48X, PT3_64X). Whether to filter photon events with pulse widths longer than a threshold, by default False.
        long_pulse_thresh_ns : float, optional
            Maximum pulse width in nanoseconds to keep the event, by default 6 ns. Only applies if remove_long_pulses is True.
        channels : int, optional
            Relevant for debugging with the PT2 data format only (old format). Channel number to be used, by default 1.
            With all PT3 data formats all channels are included in the data. 
        """
        cdef Buffer buffer
        # Load data from buffer file
        strcpy(buffer.inDir,dir.encode(self.encoding))
        strcpy(buffer.inName,filename.encode(self.encoding))
        buffer.readFromFile = 1
        buffer.isDebug = self.tttr_data.isDebug
        buffer.fill()
        # print(f"Packets in buffer: {buffer.recvPackets}")
        # print(f"Packets in first frame: {buffer.runPackets[0]}")
        # print(f"Last packet offset for first run: {buffer.runLastPkOffset[0]}")
        
        # Modify buffer configuration parameters
        # buffer.pt2Channel = channel
        buffer.shiftPT2las = 0
        if filter_long_rel_times:
            buffer.filter_removeLongRelTimeArtifacts = 1
        else:
            buffer.filter_removeLongRelTimeArtifacts = 0
        if remove_short_pulses:
            buffer.filter_removeShortPulses = 1
            buffer.filter_shortPlThresh = short_pulse_thresh_ns/buffer.pulseLengthResNs
        else:
            buffer.filter_removeShortPulses = 0  
        if remove_long_pulses:
            buffer.filter_removeLongPulses = 1
            buffer.filter_longPlThresh = long_pulse_thresh_ns/buffer.pulseLengthResNs
        else:
            buffer.filter_removeLongPulses = 0
        if lasMHz != None:
            print(f"Setting lasMHz to {lasMHz}MHz")
            buffer.lasMHz = lasMHz
            buffer.filter_maxRelTime = (1000.0/lasMHz)/buffer.relTimeResNs; 
        if pt2_mode != None:
            strcpy(buffer.TTTRformat,pt2_mode.encode(self.encoding))

        # print(f"Time marker: {buffer.timeMarker}")

        # Compute relative times and image events (pixel, line, and frame changes )
        if (buffer.runType.decode(self.encoding) == 'Frame' or buffer.runType.decode(self.encoding) == 'Line'):
            buffer.processScanInfo()
        # print(f"Total events in buffer: {buffer.scanInfo.totEvents}")
        # print(f"Packets for first run: {buffer.runPackets[0]}")
        # print(f"Last packet offset for first run: {buffer.runLastPkOffset[0]}")

        if ignore_run_offsets:
            buffer.nRuns = 1
            buffer.nAvgs = 1
            buffer.runFirstEventOffset[0] = 0
            buffer.runLastEventOffset[0] = buffer.bufsize//buffer.bytesPerEvent-10
        
        # Use Buffer object to fill TTTRData object
        # print("Filling TTTRData object")
        # self.tttr_data.isDebug = 1
        self.tttr_data.fromTTTRBuffer(buffer)

        self.tttr_data.numActiveChannels = 0
        for ch in range(4):
            if ch+1 in channels:
                self.tttr_data.activeChannels[ch] = 1
                self.tttr_data.channelOffset[ch] = self.tttr_data.numActiveChannels
                self.tttr_data.numActiveChannels += 1
            else:
                self.tttr_data.activeChannels[ch] = 0
    
    cpdef loadDataFromPTU(self, dir, filename):
        """
        Load TTTR data from a PTU file (.ptu). PTU files also contain TTTR data but are stored in a different format (e.g. from Leica's Falcon).

        Parameters
        ----------
        dir : str
            Directory path where the PTU file is located.
        filename : str
            Name of the PTU file.
        """

        strcpy(self.tttr_data.inDir,dir.encode(self.encoding))
        strcpy(self.tttr_data.inName,filename.encode(self.encoding))

        self.tttr_data.fromPTU()
    
    cpdef saveDataToBinary(self, path):
        """
        Save the TTTR data to a binary file (.ttd).

        Parameters
        ----------
        path : str
            Path (without the file extension) to the file where the data will be saved.
        """        
        self.tttr_data.toBin(path.encode(self.encoding))
        
    cpdef getMetadata(self):
        """
        Get the metadata of the TTTR data.

        Returns
        -------
        dict
            Dictionary with the metadata of the TTTR data.
        """
        metadata = {}
        metadata['relTimeResNs'] = self.tttr_data.relTimeResNs
        metadata['absTimeResNs'] = self.tttr_data.absTimeResNs
        metadata['pulseLengthResNs'] = self.tttr_data.pulseLengthResNs
        metadata['lasMHz'] = self.tttr_data.lasMHz
        metadata['nEvents'] = self.tttr_data.nEvents
        metadata['time'] = self.tttr_data.time
        metadata['FPGAtimeToNs']   = self.tttr_data.FPGAtimeToNs
        metadata['TTTRFormat']   = str(self.tttr_data.TTTRformat, 'utf-8')
        metadata['runType']   = str(self.tttr_data.runType, 'utf-8')
        metadata['pixelsPerRun'] = self.tttr_data.pixelsPerRun
        metadata['pxDwellTimeMicroS'] = self.tttr_data.pxDwellTimeMicroS
        metadata['nRuns'] = self.tttr_data.nRuns
        metadata['numActiveChannels'] = self.tttr_data.numActiveChannels
        metadata[f'activeChannels'] = []
        metadata['channelOffset'] = []
        for i in range(4):
            metadata[f'activeChannels'].append(self.tttr_data.activeChannels[i])
            metadata[f'channelOffset'].append(self.tttr_data.channelOffset[i])
        
        return metadata
    
    cpdef getData(self):
        """
        Get the TTTR data as a dictionary with numpy arrays. Depending on the information collected during the measurement, some arrays may be filled with zeros.

        Returns
        -------
        dict
            Dictionary with the TTTR data as numpy arrays.
        """
        serializedData = {}

        cdef np.ndarray absTime_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.uint32)
        memcpy(absTime_buffer.data, self.tttr_data.absTime, sizeof(uint32_t)*self.tttr_data.nEvents)
        serializedData['absTime'] = absTime_buffer

        cdef np.ndarray relTime_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.uint32)
        memcpy(relTime_buffer.data, self.tttr_data.relTime, sizeof(uint32_t)*self.tttr_data.nEvents)
        # relTime_buffer = np.asarray(<np.uint32_t[:self.tttr_data.nEvents]> self.tttr_data.relTime)
        serializedData['relTime'] = relTime_buffer
        
        cdef np.ndarray event_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.int16)
        memcpy(event_buffer.data, self.tttr_data.eventType, sizeof(int16_t)*self.tttr_data.nEvents)
        serializedData['eventType'] = event_buffer

        cdef np.ndarray channel_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.int16)
        memcpy(channel_buffer.data, self.tttr_data.channel, sizeof(int16_t)*self.tttr_data.nEvents)
        serializedData['channel'] = channel_buffer

        cdef np.ndarray pixelNr_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.int32)
        memcpy(pixelNr_buffer.data, self.tttr_data.pixelNumber, sizeof(int32_t)*self.tttr_data.nEvents)
        serializedData['pixelNumber'] = pixelNr_buffer

        cdef np.ndarray pulseWidth_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.uint16)
        memcpy(pulseWidth_buffer.data, self.tttr_data.pulseLength, sizeof(uint16_t)*self.tttr_data.nEvents)
        serializedData['pulseWidth'] = pulseWidth_buffer

        cdef np.ndarray steepness_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.uint16)
        memcpy(steepness_buffer.data, self.tttr_data.steepness, sizeof(uint16_t)*self.tttr_data.nEvents)
        serializedData['steepness'] = steepness_buffer

        cdef np.ndarray maxValue_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.uint16)
        memcpy(maxValue_buffer.data, self.tttr_data.maxValue, sizeof(uint16_t)*self.tttr_data.nEvents)
        serializedData['maxValue'] = maxValue_buffer

        cdef np.ndarray weight_buffer = np.zeros((self.tttr_data.nEvents,), dtype = np.float32)
        memcpy(weight_buffer.data, self.tttr_data.weight, sizeof(float)*self.tttr_data.nEvents)
        serializedData['weight'] = weight_buffer

        return serializedData
    
    cpdef applyPURELIGHTcorrection(self, channels, correctionParams, globalWeights=False, averageRuns=True, copyData=False):
        """
        Apply the PURELIGHT correction to the TTTR data. 
        This correction shifts the relative time of the photon events and assigns weights to compensate the dead time.
        It is applied directly to the TTTR data object and a corrected decay is computed when converting to a HistData object with useFloat enabled.
        This correction is not reversible in the TTTR data object, if you want to keep the original data, set copyData to True and work with the new object.

        Parameters
        ----------
        channels : list or int
            List of channels to apply the correction to. (Photon channels start at 1)
        correctionParams: list or dict
            List of dictionaries (same length as the channels list) with the required correction parameters for each channel. 
            Each dictionary must contain the following keys:
            - 'dead_time_addition_ns': Dead time to add in nanoseconds.
            - 'rel_time_slope': Slope of the linear function to adjust the relative time.
            - 'rel_time_offset': Offset of the linear function to adjust the relative time.
            - 'rel_time_saturation_height': Maximum pulse height to consider for the adjustment.
        globalWeights : bool, optional
            Whether to use a single set of weights for all photon events in the data (e.g. for uniform images or steady point measurements). Default is False.
        averageRuns : bool, optional
            Whether to average all the runs before applying the correction. Default is true.
            Set this option to False if you want to analyze the individual runs within the measurement separately.
        copyData : bool, optional
            Whether to copy the TTTRdata object before applying the correction. Default is False. If True, the original data is kept unchanged and a new object is returned.
        """

        if type(channels) == int:
            channels = [channels]
        if type(correctionParams) == dict:
            correctionParams = [correctionParams]

        if copyData:
            copyObj = PyTTTRData(self)
            copyObj.applyPURELIGHTcorrection(channels, correctionParams,  globalWeights, averageRuns,copyData=False)
            return copyObj
        
        for ch, params in zip(channels, correctionParams):
            self.extendBlindTime(ch, params['dead_time_addition_ns'])
            applyLinearRTC(self.tttr_data, ch, params['rel_time_slope'], params['rel_time_offset'], params['rel_time_saturation_height'])
        
        computeSCMWeights(self.tttr_data, globalWeights, averageRuns)
        self.tttr_data.useFloat = True
    
    cpdef applyMultiPhotonMask(self, channels, correctionParams):
        '''
        Apply a mask to the TTTR data to remove all laser cycles with more than one photon event.
        Multi-photon events are events where the pulse width is longer than single_photon_max_pulse_length or
        events in the same channel that have identical absolute times (laser cycle number).
        The mask is applied to the photon events by setting their channel to -1*channel.
        Creating a HistData object from the TTTR data will ignore all masked events and result in a corrected decay.
        To remove the mask and restore the original data, use the unmaskPhotonEvents() function.

        Parameters
        ----------
         channels : list or int
            List of channels to apply the correction to. (Photon channels start at 1)
        correctionParams: list or dict
            List of dictionaries (same length as the channels list) with the required correction parameters for each channel. 
            Each dictionary must contain the following keys:
            - 'single_photon_max_pulse_length': Maximum pulse length in nanoseconds for an event to be considered a single photon event.
            - 'single_photon_min_pulse_length': Minimum pulse length in nanoseconds for an event to be considered a photon event. If None, it is set to half the maximum pulse length.
        '''
        if type(channels) == int:
            channels = [channels]
        if type(correctionParams) == dict:
            correctionParams = [correctionParams]
        
        ch_masks = []
        cdef uint8_t[:] mpfMask = np.ascontiguousarray(np.zeros((self.tttr_data.nEvents), dtype = np.uint8))
        for ch, params in zip(channels, correctionParams):
            if params['single_photon_min_pulse_length'] == None:
                params['single_photon_min_pulse_length'] = params['single_photon_max_pulse_length']*0.5
            if "n_cycles" not in params:
                params['n_cycles'] = 1
            # Compute the mask for multi-photon events based on the pulse width and absolute times
            mpfMask = np.ascontiguousarray(np.zeros((self.tttr_data.nEvents), dtype = np.uint8))
            computeMultiPhotonMask(self.tttr_data, ch, &mpfMask[0], params['single_photon_max_pulse_length'],params['single_photon_min_pulse_length'], params['n_cycles'])
            ch_masks.append(np.asarray(mpfMask))
            # print(f"Number of multi-photon events in ch {ch}: {np.sum(mpfMask)}")

            # Apply the mask to the photon events
            maskPhotonEvents(self.tttr_data, &mpfMask[0])
        return ch_masks
    
    cpdef applyLaserPeriodBlindTimeMask(self,channels):
        '''
        Apply a mask to the TTTR data to remove all photon events that arrive less than the laser period after the previous event.
        The mask is applied to the photon events by setting their channel to -1*channel.
        Creating a HistData object from the TTTR data will ignore all masked events and result in a corrected decay.
        To remove the mask and restore the original data, use the unmaskPhotonEvents() function.

        Parameters
        ----------
         channels : list or int
            List of channels to apply the correction to. (Photon channels start at 1)
        '''
        if type(channels) == int:
            channels = [channels]
        ch_masks = []
        cdef uint8_t[:] lpdtMask = np.ascontiguousarray(np.zeros((self.tttr_data.nEvents), dtype = np.uint8))
        for ch in channels:
            computeLaserPeriodDeadTimeMask(self.tttr_data, ch, &lpdtMask[0])
            maskPhotonEvents(self.tttr_data, &lpdtMask[0])
            ch_masks.append(np.asarray(lpdtMask))
        return ch_masks

    cpdef countCyclesPerPixel(self):
        """
        Count the number of laser cycles per pixel in the TTTR data.

        Returns
        -------
        np.ndarray
            Array with the number of excitation cycles per pixel.
        """
        cdef uint32_t tOverflow = self.tttr_data.PT3OVERFLOW
        cdef uint32_t px = 0
        cdef uint64_t t_start = 0
        cdef uint64_t t_end = 0
        cdef uint32_t nOverflows = 0

        cdef uint32_t[:] nCycles = np.zeros(self.tttr_data.pixelsPerRun,dtype=np.uint32)

        for i in range(self.tttr_data.nEvents):
            if (self.tttr_data.eventType[i] == 0): # Overflow event
                nOverflows +=1
            elif (self.tttr_data.eventType[i] == 1): # Line start
                t_start = self.tttr_data.absTime[i] + tOverflow*nOverflows
            elif (self.tttr_data.eventType[i] == 2 or self.tttr_data.eventType[i] == 4): # Line end or pixel change
                t_end = self.tttr_data.absTime[i] + tOverflow*nOverflows
                if (t_end>= t_start):
                    nCycles[px] += t_end - t_start
                    t_start = t_end
                px += 1
            elif (self.tttr_data.eventType[i] == 3): # Frame cjange
                px = 0
        return np.asarray(nCycles)

    cpdef countActiveCycles(self):
        '''
        Count the total number of laser pulses where we could detect photons during the whole measurement.
        If line starts and ends are available in the data we sum the number of laser pulses within each line.
        Otherwise we take the absolute time for the last event.

        Returns
        -------
        uint64_t
            Number of laser pulses where we could detect photons.
        '''
        cdef uint64_t nCycles = 0
        cdef uint64_t lineStart = 0
        cdef uint64_t lineEnd = 0
        cdef uint32_t nOverflows = 0
        cdef uint32_t tOverflow = self.tttr_data.PT3OVERFLOW
        # Set the correct overflow vaue
        if self.tttr_data.TTTRformat.decode(self.encoding) == 'PT2' or self.tttr_data.TTTRformat.decode(self.encoding) == 'PT2_64':
            tOverflow = self.tttr_data.PT2OVERFLOW
        
        # Loop over all events
        for i in range(self.tttr_data.nEvents):
            if (self.tttr_data.eventType[i] == 0):
                nOverflows +=1
            elif (self.tttr_data.eventType[i] == 1):
                lineStart = self.tttr_data.absTime[i]+ tOverflow*nOverflows
            elif (self.tttr_data.eventType[i] == 2):
                lineEnd = self.tttr_data.absTime[i]+ tOverflow*nOverflows
                nCycles += lineEnd - lineStart

        if nCycles == 0: # No line start and end information available
            nCycles = self.tttr_data.absTime[self.tttr_data.nEvents-1] + tOverflow*nOverflows

        # print(f"Number of cycles: {nCycles}")
        return nCycles
    
    cpdef setRelTimes(self, relTime):
        '''
        Set the relative times for the photon events in the TTTR data.

        Parameters
        ----------
        relTime : np.ndarray
            Array with the relative times for each photon event. The array must have the same length as the number of events in the TTTR data.
        '''
        for i in range(self.tttr_data.nEvents):
            self.tttr_data.relTime[i] = relTime[i]

    cpdef setWeights(self, weights):
        '''
        Set the weights for the photon events in the TTTR data.

        Parameters
        ----------
        weights : np.ndarray
            Array with the weights for each photon event. The array must have the same length as the number of events in the TTTR data.
        '''
        for i in range(self.tttr_data.nEvents):
            self.tttr_data.weight[i] = weights[i]

    cpdef shiftRelTimes(self,relTimeShift):
        '''
        Shift each relative time in the TTTR data by a given value.

        Parameters
        ----------
        relTimeShift : np.ndarray
            Array with the relative time shift (in relative time bins) for each photon event. The array must have the same length as the number of events in the TTTR data.
        '''
        cdef int nRelTimeBins = int(self.tttr_data.absTimeResNs/self.tttr_data.relTimeResNs)
        cdef int relTimeBuf = 0
        cdef int pulseWidthBuf = 0

        # Convert relTimeShift to a C array
        cdef int[:] relTimeShiftC = np.ascontiguousarray(relTimeShift,dtype=np.int32)

        for i in range(self.tttr_data.nEvents):
            if relTimeShiftC[i] == 0:
                continue
            relTimeBuf = self.tttr_data.relTime[i]
            pulseWidthBuf = self.tttr_data.pulseLength[i]
            relTimeBuf += relTimeShiftC[i]
            
            # Ensure that the relative time is within the range of the number of relative time bins (and adjust the absolute time accordingly)
            while relTimeBuf < 0:
                relTimeBuf += nRelTimeBins
                self.tttr_data.absTime[i] -= 1
            while relTimeBuf >= nRelTimeBins:
                relTimeBuf -= nRelTimeBins
                self.tttr_data.absTime[i] += 1

            # Update the relative time
            self.tttr_data.relTime[i] = relTimeBuf
            
            # Update the pulse width
            pulseWidthBuf = self.tttr_data.pulseLength[i]
            pulseWidthBuf -= relTimeShiftC[i]
            if pulseWidthBuf < 0: # Ensure that the pulse width is not negative
                pulseWidthBuf = 0
            self.tttr_data.pulseLength[i] = pulseWidthBuf

    cpdef computeStateHistogram(self):
        '''
        Compute the state histogram for the TTTR data. The state histogram is a 3D array with the number of active channels, pixels, and relative time bins.

        Returns
        -------
        np.ndarray
            3D array with the state histogram.
        np.ndarray
            Array with the number of cycles per pixel.
        '''
        # Compute necessary variables
        cdef uint32_t totalPixels = self.tttr_data.pixelsPerRun*self.tttr_data.nRuns
        cdef int nRelTimeBins = (int)(self.tttr_data.absTimeResNs/self.tttr_data.relTimeResNs)

        # Allocate memory for the state histogram and cycles per pixel
        cdef uint32_t[:] cyclesPerPixel = np.ascontiguousarray(np.zeros(totalPixels,dtype=np.uint32))
        cdef uint32_t[:] stateHist = np.ascontiguousarray(np.zeros((totalPixels*self.tttr_data.numActiveChannels*nRelTimeBins), dtype = np.uint32))

        # Compute the state histogram using the C++ function
        computeStateHistogram(self.tttr_data, &stateHist[0], &cyclesPerPixel[0])

        return np.reshape(stateHist,(self.tttr_data.numActiveChannels,totalPixels,nRelTimeBins)), np.asarray(cyclesPerPixel)
    
    cpdef extendBlindTime(self, channel=1, blind_time_addition_ns=0):
        '''
        Extend the dead time of the TTTR data for a specific channel. Extending the dead time increases the pulse width of the photon events and removes any events that overlap with the dead time of a previous event.

        Parameters
        ----------
        channel : int, optional
            Channel number to extend the dead time for. Default is 1.
        deadTimeAdditionNs : double
            Dead time to add in nanoseconds.
        Returns
        -------
        np.ndarray
            Array with a boolean mask indicating which events were kept.
        '''
        cdef uint8_t[:] keptMask = np.ascontiguousarray(np.zeros((self.tttr_data.nEvents,), dtype = np.uint8))
        extendDeadTime(self.tttr_data, channel, blind_time_addition_ns, &keptMask[0])
        if self.tttr_data.TTTRformat.decode(self.encoding) != 'PT3_64' and self.tttr_data.TTTRformat.decode(self.encoding) != 'PT3_48X' and self.tttr_data.TTTRformat.decode(self.encoding) != 'PT3_64X':
            strcpy(self.tttr_data.TTTRformat, 'PT3_64'.encode(self.encoding))

        return np.asarray(keptMask)
    
    cpdef applyEventMask(self, mask):
        '''
        Mask photon events in the TTTR data by setting their channel to -1*channel. 

        Parameters
        ----------
        mask : np.ndarray
            Boolean array with the same length as the number of events in the TTTR data.
            Events with a value of 1 get masked.
        '''
        cdef uint8_t[:] maskC = np.ascontiguousarray(mask, dtype = np.uint8)
        assert len(mask) == self.tttr_data.nEvents, f"The mask must have the same length as the number of events in the TTTR data. Received {len(mask)} and expected {self.tttr_data.nEvents}."
        maskPhotonEvents(self.tttr_data, &maskC[0])
    
    cpdef unmaskPhotonEvents(self):
        '''
        Unmask all photon events in the TTTR data by setting their channel to abs(channel).
        '''
        unmaskAllPhotonEvents(self.tttr_data)

    cpdef setUseFloat(self, useFloat):
        '''
        Set the useFloat flag in the TTTR data object. The useFloat flag is used when converting to a HistData object.
        It is necessary to use floats when the photon events have been weighted or when a single bin in the histogram has a value larger than 65535 (max value of a uint16_t). 

        Parameters
        ----------
        useFloat : bool
            Flag to determine whether to use floats or integers when converting to a HistData object.
        '''
        self.tttr_data.useFloat = useFloat
    
    cpdef applyLinearTimeCompPulseHeight(self, slope, offset, saturation_height=65535, channel=1):
        '''
        Apply a linear time compensation to the relative time of the photon events in the TTTR data.
        This is done to compensate the variable time-to-threshold of events with pile-up.
        The relative time is adjusted based on the pulse width:
        
        relTime = relTime + (min(pulseHeight,saturation_height) - offset) * slope

        Parameters
        ----------
        slope : double
            Slope of the linear function to adjust the relative time.
        offset : double
            Offset of the linear function to adjust the relative time.
        saturation_height : int, optional
            Maximum pulse height to consider for the adjustment. Default is 65535.
        channel : int, optional
            Channel number to apply the linear time compensation to. Default is 1.
        '''
        applyLinearRTC(self.tttr_data, channel, slope, offset, saturation_height)

    cpdef computeSCMWeights(self,global_weights=False,average_runs=True):
        '''
        Compute the SCM weights for the TTTR data. The SCM weights are used to compensate the dead time of the detector.
        The weights are computed based on the relative times of the photon events and the dead time of the detector.
        The weights are stored in the TTTR data object and are used when converting to a HistData object.

        Parameters
        ----------
        global_weights : bool, optional
            Whether to use a single set of weights for all photon events in the data (e.g. for uniform images or steady point measurements). Default is False.
        average_runs : bool, optional
            Whether to average all the runs before applying the correction. Default is true.
            Set this option to False if you want to analyze the individual runs within the measurement separately.
        '''
        computeSCMWeights(self.tttr_data, global_weights, average_runs)

cdef class PyHistData:
    ''' 
    Python wrapper for the HistData class. The HistData class is used to store and process histogram data from TTTR data.
    '''
    
    encoding = 'UTF-8'

    def __init__(self):
        """
        Initialize an empty :class:`PyHistData` wrapper with default metadata.

        The defaults mirror a single-pixel measurement with 256 time bins and
        an 80 MHz laser; callers typically overwrite these values by loading
        data or calling :meth:`setMetadata`.
        """
        # print("PyHistData constructor called")
        self.hist_data = HistData()

        self.hist_data.relTimeResNs = pow(2,0)*1000/(512*600)
        self.hist_data.absTimeResNs = 1E9/80E6
        self.hist_data.lasMHz = 80
        self.hist_data.nRelTimeBins = 256
        self.hist_data.pixelsPerRun = 1
        self.hist_data.pixelsPerLine = 1
        self.hist_data.nRuns = 1
        self.hist_data.nAvgs = 1
        self.hist_data.totPixels = 1

    def loadDataFromBin(self, path):
        '''
        Load histogram data from a binary file (.his). The binary file contains the histogram data already in the HistData format.

        Parameters
        ----------
        path : str
            Path to the binary file.
        '''
        self.hist_data.fromBin(path.encode(self.encoding))
        if self.hist_data.numActiveChannels<1:
            self.hist_data.numActiveChannels = 1
    def loadDataFromOMETiff(self, dir, filename, read_ome=True, lasMHz=None):
        '''
        Load histogram data from an OME-TIFF file (.ome.tiff). The OME-TIFF file contains a 3D tiff image with the histogram data and some additional metadata (hence the OME part).

        Parameters
        ----------
        dir : str
            Directory path where the OME-TIFF file is located.
        filename : str
            Name of the OME-TIFF file.
        '''
        if not ome_tools_available:
            Warning("OME-TIFF tools are not available. Ensure that ome_types>=0.5.1.post1 and tifffile>=2024.8.30 are installed.")
            print("Trying to load the OME-TIFF file with C++ library. This requires the C++ library to be compiled with OME-TIFF support which is disabled by default.")
            strcpy(self.hist_data.inDir,dir.encode(self.encoding))
            strcpy(self.hist_data.inName,filename.encode(self.encoding))
            self.hist_data.fromOMETiff()
            if self.hist_data.numActiveChannels<1:
                self.hist_data.numActiveChannels = 1
            return
        
        # Read the OME-TIFF file with the ome_tools function
        with warnings.catch_warnings(): # Suppress warnings regarding invalid AnnotationID
            warnings.simplefilter("ignore", UserWarning)
            ome_img = read_ome_tiff(os.path.join(dir, filename),read_ome=read_ome)
        # Check the data type
        if read_ome:
            use_float = ome_img['pixels']['type'].value == 'float'
        else:
            use_float = ome_img['data'].dtype == np.float32

        # Set the metadata
        metadata = self.getMetadata()
        if read_ome:
            lasMHz = None
            for annotation in ome_img['annotations']:
                for key in metadata.keys():
                    if key in annotation.keys():
                        metadata[key] = annotation[key]
                        continue
                if 'ModuloAlongT' in annotation.keys():
                    # Extract the laser period from the modulo annotation
                    period = float(annotation['ModuloAlongT']['End'])
                    if 'Unit' in annotation['ModuloAlongT'] and annotation['ModuloAlongT']['Unit'] == 'ns':
                        lasMHz = 1E3/period
            if lasMHz != None:
                # Ensure the laser period matches the OME-TIFF modulo annotation
                metadata['lasMHz'] = lasMHz
                metadata['absTimeResNs'] = 1000/lasMHz
        elif lasMHz != None:
            metadata['lasMHz'] = lasMHz
            metadata['absTimeResNs'] = 1000/lasMHz

        # Overwrite metadata that isnt relevant for OME-TIFF files
        metadata['nRuns'] = 1
        metadata['nAvgs'] = 1
        metadata['pixelsPerRun'] = ome_img['data'].shape[0]*ome_img['data'].shape[1]
        metadata['pixelsPerLine'] = ome_img['data'].shape[1]
        metadata['nRelTimeBins'] = ome_img['data'].shape[2]
        if use_float:
            metadata['useFloat'] = 1
        else:
            metadata['useFloat'] = 0

        # Prepare the HistData object
        self.setMetadata(metadata)
        self.hist_data.allocateData()

        # Copy the data to the HistData object
        if use_float:
            self.writeSerializedDataFloat(ome_img['data'])
        else:
            self.writeSerializedData(ome_img['data'])
        
    def loadDataFromTTTR(self, tttr_obj:PyTTTRData , type="FLIM", channels=[1], nBins=256, nAvgs=1, useFloat=None,nBinsFCS=100,nCascadesFCS=20, singleDecayPerRun =False, isDebug=0):
        '''
        Generate a (Py)HistData object from a PyTTTRData object.

        Parameters
        ----------
        tttr_obj : PyTTTRData
            PyTTTRData object with the TTTR data.
        type : str, optional
            Type of histogram data to generate. Options are "FLIM" (default) and "FCS" (currently not fully supported).
        channels : list, optional
            List with the channels to include in the histogram data. Default is [1].
        nBins : int, optional
            Number of relative time bins in the histogram. Default is 256.
        nAvgs : int, optional
            Number of runs to average together. Default is 1.
        useFloat : bool, optional
            Flag to determine whether to use floats or integers when converting to a HistData object. Default is None.
            If None, the value of the useFloat flag in the TTTR data object will be used.
        nBinsFCS : int, optional
            Number of bins in the FCS histogram. Default is 100. Only used when type is "FCS".
        nCascadesFCS : int, optional
            Number of cascades in the FCS histogram. Default is 20. Only used when type is "FCS".
        singleDecayPerRun : bool, optional
            Flag to determine whether to generate a single decay curve per run. Default is False.
        '''
        self.hist_data.isDebug = isDebug
        self.hist_data.nAvgs = nAvgs
        self.hist_data.numActiveChannels = 0
        for channel in range(7):
            if channel+1 in channels:
                self.hist_data.activeChannels[channel] = 1
                self.hist_data.channelOffset[channel] = self.hist_data.numActiveChannels
                self.hist_data.numActiveChannels += 1
            else:
                self.hist_data.activeChannels[channel] = 0
        
        if isDebug:
            print(f"Loading HistData from TTTR data with {tttr_obj.tttr_data.nEvents} events.")
            print(f"Active channels: {self.hist_data.numActiveChannels}")
            print(f"Channels: {channels}")
            
        self.hist_data.singleDecayPerRun = singleDecayPerRun
        if type == "FCS":
            self.hist_data.nBinsFCS = nBinsFCS
            self.hist_data.nCascadesFCS = nCascadesFCS
        if useFloat != None:
            tttr_obj.setUseFloat(useFloat)
        self.hist_data.fromTTTR(tttr_obj.tttr_data, type.encode(self.encoding), nBins)
        if self.hist_data.numActiveChannels<1:
            self.hist_data.numActiveChannels = 1
        # print(f"Use float: {self.hist_data.useFloat}")
    def loadDataFromTTTRBuffer(self, dir, filename, nTimeBins, channels=[1], lasMHz=None, filterLongRelTimes=False):
        '''
        Load histogram data from a TTTR buffer. The TTTR buffer is a binary file with the TTTR data in a specific format.

        Parameters
        ----------
        dir : str
            Directory path where the TTTR buffer is located.
        filename : str
            Name of the TTTR buffer file.
        nTimeBins : int
            Number of relative time bins in the histogram.
        channel : int, optional
            Channel number to include in the histogram data. Default is 1.
        lasMHz : int, optional
            Laser repetition rate in MHz. Default is None.
            If None, the value of the lasMHz flag in the HistData object will be used.
        filterLongRelTimes : bool, optional
            Flag to determine whether to filter out long relative times. Default is False.
        '''
        cdef Buffer buffer
        strcpy(buffer.inDir,dir.encode(self.encoding))
        strcpy(buffer.inName,filename.encode(self.encoding))
        buffer.readFromFile = 1
        buffer.pt2Channel = channels[0]
        buffer.shiftPT2las = 0
        
        buffer.fill()
        if filterLongRelTimes:
            buffer.filter_removeLongRelTimeArtifacts = 1
        else:
            buffer.filter_removeLongRelTimeArtifacts = 0
        if lasMHz != None:
            print(f"Setting lasMHz to {lasMHz}MHz")
            buffer.lasMHz = lasMHz
            buffer.filter_maxRelTime = (1000.0/lasMHz)/buffer.relTimeResNs; 
        buffer.processScanInfo()

        self.hist_data.numActiveChannels = 0
        for channel in channels:
            self.hist_data.activeChannels[channel-1] = 1
            self.hist_data.channelOffset[channel-1] = self.hist_data.numActiveChannels
            self.hist_data.numActiveChannels += 1

        self.hist_data.fromTTTRBuffer(buffer, nTimeBins)

        if self.hist_data.numActiveChannels<1:
            self.hist_data.numActiveChannels = 1

    def saveDataToCSV(self, path):
        '''
        Save the histogram data to a CSV file.

        Parameters
        ----------
        path : str
            Path to the CSV file (without the file extension).
        '''
        self.hist_data.toCsv(path.encode(self.encoding))
    
    def saveDataToOMETiff(self, path, nAvgs=-1):
        '''
        Save the histogram data to an OME-TIFF file. If the histogram data has multiple channels, each channel will be saved to a separate OME-TIFF file.
        
        Parameters
        ----------
        path : str
            Path to the OME-TIFF file (without the file extension).
        '''
        if not ome_tools_available:
            Warning("OME-TIFF tools are not available. Ensure that ome_types>=0.5.1.post1 and tifffile>=2024.8.30 are installed.")
            print("Trying to save the OME-TIFF file with C++ library. This requires the C++ library to be compiled with OME-TIFF support which is disabled by default.")
            self.hist_data.toOMETiff(path.encode(self.encoding))
            return

        data = self.getData(nAvgs=nAvgs)
        use_float = self.hist_data.useFloat
        lasMHz = self.hist_data.lasMHz
        if len(data.shape) <= 3:
            write_ome_tiff(path, self.getData(), lasMHz, use_float)
        else:
            if nAvgs == -1 or nAvgs == self.hist_data.nRuns:
                # All runs are summed together
                for i in range(data.shape[0]):
                    write_ome_tiff(f"{path}_ch{i+1}", data[i], lasMHz, use_float)
            elif len(data.shape)==5:
                # Each run is saved separately and we have multiple channels
                for i in range(data.shape[0]):
                    for j in range(data.shape[1]):
                        write_ome_tiff(f"{path}_ch{i+1}_{j}", data[i,j], lasMHz, use_float)
            else:
                # Each run is saved separately
                for i in range(data.shape[0]):
                    write_ome_tiff(f"{path}_{i}", data[i], lasMHz, use_float)
            
    def saveDataToIntensityTiff(self, path):
        '''
        Save the intensity image (sum of all historgram bins) to a tiff file.

        Parameters
        ----------
        path : str
            Path to the tiff file (without the file extension).
        '''
        self.hist_data.toIntensityTiff(path.encode(self.encoding))

    def saveDataToBin(self, path):
        '''
        Save the histogram data to a binary file (.his).

        Parameters
        ----------
        path : str
            Path to the binary file (without the file extension).
        '''
        self.hist_data.toBin(path.encode(self.encoding))
        
    def getMetadata(self):
        '''
        Get the metadata of the HistData object.

        Returns
        -------
        dict
            Dictionary with the metadata.
        '''
        metadata = {}
        metadata['useFloat']       = self.hist_data.useFloat
        metadata['relTimeResNs']   = self.hist_data.relTimeResNs
        metadata['absTimeResNs']   = self.hist_data.absTimeResNs
        metadata['lasMHz']         = self.hist_data.lasMHz
        metadata['nRelTimeBins']   = self.hist_data.nRelTimeBins
        metadata['pixelsPerRun']   = self.hist_data.pixelsPerRun
        metadata['pixelsPerLine']  = self.hist_data.pixelsPerLine
        metadata['nRuns']          = self.hist_data.nRuns
        metadata['nAvgs']          = self.hist_data.nAvgs
        metadata['totPixels']      = self.hist_data.totPixels
        metadata['FPGAtimeToNs']   = self.hist_data.FPGAtimeToNs
        metadata['relTimeBinNs']   = self.hist_data.relTimeBinNs
        metadata['numActiveChannels'] = self.hist_data.numActiveChannels
        metadata[f'activeChannels'] = []
        metadata[f'channelOffset'] = []
        for i in range(7):
            metadata[f'activeChannels'].append(self.hist_data.activeChannels[i])
            metadata[f'channelOffset'].append(self.hist_data.channelOffset[i])
        

        return metadata
    
    def setMetadata(self, metadata):
        '''
        Set the metadata of the HistData object.

        Parameters
        ----------

        metadata : dict
            Dictionary with the metadata to set. The easiest way to generate a valid dictionary is to use the getMetadata function and modify the values.
            Requires the following keys:
            - useFloat (bool)
            - relTimeResNs (double)
            - absTimeResNs (double)
            - lasMHz (int)
            - nRelTimeBins (int)
            - pixelsPerRun (int)
            - pixelsPerLine (int)
            - nRuns (int)
            - nAvgs (int)
            - numActiveChannels (int)
            Optional keys:
            - activeChannels (list of 4 ints)
            - channelOffset (list of 4 ints)
        '''
        self.hist_data.useFloat     = metadata['useFloat']
        self.hist_data.relTimeResNs = metadata['relTimeResNs']
        self.hist_data.absTimeResNs = metadata['absTimeResNs']
        self.hist_data.lasMHz       = metadata['lasMHz']
        self.hist_data.nRelTimeBins = metadata['nRelTimeBins'] 
        self.hist_data.pixelsPerRun = metadata['pixelsPerRun']
        self.hist_data.pixelsPerLine = metadata['pixelsPerLine']
        self.hist_data.nRuns        = metadata['nRuns']
        if metadata['nAvgs'] == 0 or metadata['nRuns']%metadata['nAvgs'] != 0:
            print(f"The total number of runs ({metadata['nRuns']}) is not divisible by the number of runs to be averaged together ({metadata['nAvgs']})!")
            print("The number of runs to be averaged together will be set to 1")
            metadata['nAvgs'] = 1
        self.hist_data.nAvgs = metadata['nAvgs']
        self.hist_data.totPixels = int((metadata['nRuns']/metadata['nAvgs'])*metadata['pixelsPerRun'])
        self.hist_data.numActiveChannels = metadata['numActiveChannels']

        if 'activeChannels' in metadata:
            for i in range(7):
                self.hist_data.activeChannels[i] = metadata[f'activeChannels'][i]
                self.hist_data.channelOffset[i] = metadata[f'channelOffset'][i]

    def getDataOld(self, nAvgs=-1):
        '''
        Get the decay data as a numpy array. This can be a 3-5D array depending on the data collected during the measurement and the number of runs to average together.
        If the data is multichannel the first dimension is the channel number.
        If nAvgs is set to -1 or is equal to the total number of runs, all runs are summed together. Otherwise the next dimension is the number of runs.
        In all cases the last dimensions are: (Y, X, relative time).

        Parameters
        ----------
        nAvgs : int, optional
            Number of runs to sum together, if -1, all runs are summed together. Default is -1.

        Returns
        -------
        np.ndarray
            Array with the decay data. The shape of the array is (numActiveChannels, nPixelsPerRun, nRelTimeBins).
        '''

        # Compute the total number of decays we need to copy
        cdef uint32_t totalPixelsAllCh = self.hist_data.totPixels*self.hist_data.numActiveChannels
        
        # Copy the decay data to a numpy array keeping the original shape from the HistData object (ch+px,bin)
        cdef np.ndarray npHistData = np.zeros((totalPixelsAllCh,self.hist_data.nRelTimeBins), dtype = np.uint16)
        cdef np.ndarray npHistDataFloat = np.zeros((totalPixelsAllCh,self.hist_data.nRelTimeBins), dtype = np.float32)
        cdef uint16_t[:] decayData
        cdef float[:] decayDataFloat
        for i in range(totalPixelsAllCh):
            px = i
            if self.hist_data.useFloat:
                decayDataFloat = <float [:self.hist_data.nRelTimeBins]> self.hist_data.dataFloat[i]
                npHistDataFloat[px,:] += np.asarray(decayDataFloat)
            else:
                decayData = <uint16_t [:self.hist_data.nRelTimeBins]> self.hist_data.data[i]
                npHistData[px,:] += np.asarray(decayData)

        data = npHistData if not self.hist_data.useFloat else npHistDataFloat
        # Determined the desired shape of the data
        # Start by reshaping the data to the 5D equivalent of the HistData object (Ch, run, y, x, bin)
        nRuns = self.hist_data.totPixels//self.hist_data.pixelsPerRun
        lines_per_run = int(self.hist_data.pixelsPerRun//self.hist_data.pixelsPerLine)
        data = np.reshape(data,(self.hist_data.numActiveChannels,nRuns,lines_per_run,self.hist_data.pixelsPerLine,self.hist_data.nRelTimeBins))

        if nAvgs == -1 or nAvgs == self.hist_data.nRuns:
            # Sum all runs together
            data = np.sum(data, axis=1)
        elif nAvgs == 1:
            # Return the data as is
            pass
        elif nRuns%nAvgs == 0:
            # Sum nAvgs runs together
            nRunsNew = nRuns//nAvgs
            data = np.reshape(data,(self.hist_data.numActiveChannels,nRunsNew,nAvgs,lines_per_run,self.hist_data.pixelsPerLine,self.hist_data.nRelTimeBins))
            data = np.sum(data, axis=2)
        else:
            Warning(f"The total number of runs ({self.hist_data.nRuns}) is not divisible by the number of runs to be averaged together ({nAvgs})!\n The data will be returned without summing.")
            pass
        
        if self.hist_data.numActiveChannels == 1:
            # Remove the channel dimension if there is only one channel
            data = np.squeeze(data, axis=0)
        return data

    def getData(self, nAvgs=-1):
        '''
        Get the decay data as a numpy array. This can be a 3-5D array depending on the data collected during the measurement and the number of runs to average together.
        If the data is multichannel the first dimension is the channel number.
        If nAvgs is set to -1 or is equal to the total number of runs, all runs are summed together. Otherwise the next dimension is the number of runs.
        In all cases the last dimensions are: (Y, X, relative time).

        Parameters
        ----------
        nAvgs : int, optional
            Number of runs to sum together, if -1, all runs are summed together. Default is -1.

        Returns
        -------
        np.ndarray
            Array with the decay data. The shape of the array is (numActiveChannels, nPixelsPerRun, nRelTimeBins).
        '''

        # Compute the total number of decays we need to copy
        cdef uint32_t totalPixelsAllCh = self.hist_data.totPixels*self.hist_data.numActiveChannels
        
        # Copy the decay data to a numpy array keeping the original shape from the HistData object (ch+px,bin)
        npHistData = np.zeros((totalPixelsAllCh,self.hist_data.nRelTimeBins), dtype = np.uint16)
        npHistDataFloat = np.zeros((totalPixelsAllCh,self.hist_data.nRelTimeBins), dtype = np.float32)
        # Fast memcpy-based copy from C++ buffers into the contiguous numpy arrays
        # Avoid creating temporary numpy arrays for each row which is slow.
        cdef Py_ssize_t row_bytes_f = <Py_ssize_t>(self.hist_data.nRelTimeBins * sizeof(float))
        cdef Py_ssize_t row_bytes_u16 = <Py_ssize_t>(self.hist_data.nRelTimeBins * sizeof(uint16_t))
        # Create typed memoryviews (contiguous arrays guaranteed by np.zeros)
        cdef float[:, :] mvf = npHistDataFloat
        cdef uint16_t[:, :] mvu16 = npHistData
        for i in range(totalPixelsAllCh):
            if self.hist_data.useFloat:
                # copy float row
                # src_ptr = <void*> self.hist_data.dataFloat[i]
                # dest_char = <char*> npHistDataFloat.data + i * row_bytes_f
                memcpy(<void*> &mvf[i, 0], <void*> self.hist_data.dataFloat[i], row_bytes_f)
            else:
                # copy uint16_t row
                src_ptr = <void*> self.hist_data.data[i]
                # dest_char = <char*> npHistData.data + i * row_bytes_u16
                memcpy(<void*> &mvu16[i, 0], src_ptr, row_bytes_u16)

        data = npHistData if not self.hist_data.useFloat else npHistDataFloat
        # Determined the desired shape of the data
        # Start by reshaping the data to the 5D equivalent of the HistData object (Ch, run, y, x, bin)
        nRuns = self.hist_data.totPixels//self.hist_data.pixelsPerRun
        lines_per_run = int(self.hist_data.pixelsPerRun//self.hist_data.pixelsPerLine)
        data = np.reshape(data,(self.hist_data.numActiveChannels,nRuns,lines_per_run,self.hist_data.pixelsPerLine,self.hist_data.nRelTimeBins))

        if nAvgs == -1 or nAvgs == self.hist_data.nRuns:
            # Sum all runs together
            data = np.sum(data, axis=1)
        elif nAvgs == 1:
            # Return the data as is
            pass
        elif nRuns%nAvgs == 0:
            # Sum nAvgs runs together
            nRunsNew = nRuns//nAvgs
            data = np.reshape(data,(self.hist_data.numActiveChannels,nRunsNew,nAvgs,lines_per_run,self.hist_data.pixelsPerLine,self.hist_data.nRelTimeBins))
            data = np.sum(data, axis=2)
        else:
            Warning(f"The total number of runs ({self.hist_data.nRuns}) is not divisible by the number of runs to be averaged together ({nAvgs})!\n The data will be returned without summing.")
            pass
        
        if self.hist_data.numActiveChannels == 1:
            # Remove the channel dimension if there is only one channel
            data = np.squeeze(data, axis=0)
        return data
            
    def allocateData(self):
        '''
        Allocate memory for the decay data in the HistData object.
        '''
        self.hist_data.allocateData()
    
    def deallocateData(self):
        """
        Free any decay buffers currently held by the underlying HistData.
        """
        self.hist_data.deallocateData()

    def setDataOld(self, data, useFloat=None):
        '''
        Set the decay (histogram) data in the HistData object.
        
        Parameters
        ----------
        data : np.ndarray
            Array with the decay data. This can be:
                - 1D (nRelTimeBins): Single decay, point measurement. 
                - 2D (nPoints,nRelTimeBins): Line measurement.
                - 3D (nLines,nPxPerLine,nRelTimeBins): Frame measurement.
                - 4D (nFrames,nLines,nPxPerLine,nRelTimeBins): Sequence of frames.
        useFloat : bool, optional
            Flag to determine whether to use floats or integers when converting to a HistData object. Default is None.
            If None, the value of the useFloat flag in the HistData object will be used.
        '''

        # Delete any data in the object
        self.hist_data.deallocateData()

        # Update metadata to match the dimensions of the data array
        metadata = self.getMetadata()
        dims = np.shape(data)
        runType = 'Frame'
        if useFloat == None:
            useFloat = metadata['useFloat']
        else :
            metadata['useFloat'] = useFloat
        
        # Prevent overflow by switching to float if there are values higher than the maximum value of uint16t
        max_val = np.amax(data)
        if max_val >= pow(2,16) and not metadata['useFloat']:
            metadata['useFloat'] = True
            Warning(f"Warning: Switched to float to prevent data overflow using uint16.")

        if len(dims)>3: # Sequence of frames
            runType = 'Sequence'
            metadata['nRuns'] = dims[0]
            metadata['pixelsPerRun'] = dims[1]*dims[2]
            metadata['pixelsPerLine'] = dims[2]

            if metadata['nRelTimeBins'] != dims[3]:
                metadata['nRelTimeBins'] = dims[3]
                # print(f"Setting number of bins to {dims[3]}")

        elif len(dims)==3: # Single frame
            metadata['nRuns'] = 1
            metadata['pixelsPerRun'] = dims[0]*dims[1]
            metadata['pixelsPerLine'] = dims[1]
            # print(f"Setting image size to {dims[0]}x{dims[1]}")

            if metadata['nRelTimeBins'] != dims[2]:
                metadata['nRelTimeBins'] = dims[2]
                # print(f"Setting number of bins to {dims[2]}")

        elif len(dims)==2: # Line
            runType = 'Line'
            metadata['nRuns'] = 1
            metadata['pixelsPerRun'] = dims[0]
            metadata['pixelsPerLine'] = dims[0]
            # print(f"Setting image size to 1x{dims[0]}")
            if metadata['nRelTimeBins'] != dims[1]:
                metadata['nRelTimeBins'] = dims[1]
                # print(f"Setting number of bins to {dims[1]}")
        else: # Point
            # print("Warning input data has only 1 dimension, point image assumed")
            runType = 'Point'
            metadata['nRuns'] = 1
            metadata['pixelsPerRun'] = 1
            metadata['pixelsPerLine'] = 1
            if metadata['nRelTimeBins'] != dims[0]:
                metadata['nRelTimeBins'] = dims[0]
                # print(f"Setting number of bins to {dims[0]}")
 
        # Write metadata
        self.setMetadata(metadata)
        
        # Allocate arrays for serialized data
        self.hist_data.allocateData()

        # Write serialized data
        if metadata['useFloat']:
            self.writeSerializedDataFloatOld(data, runType, dims)
            # self.writeSerializedDataFloatFast(data)
        else:
            self.writeSerializedDataOld(data, runType, dims)
            # self.writeSerializedDataFast(data)

        # Print result
        # print(f"{self.hist_data.totPixels} pixels allocated with {self.hist_data.nRelTimeBins} timebins each.")

    def setData(self, data, useFloat=None):
        '''
        Set the decay (histogram) data in the HistData object.
        
        Parameters
        ----------
        data : np.ndarray
            Array with the decay data. This can be:
                - 1D (nRelTimeBins): Single decay, point measurement. 
                - 2D (nPoints,nRelTimeBins): Line measurement.
                - 3D (nLines,nPxPerLine,nRelTimeBins): Frame measurement.
                - 4D (nFrames,nLines,nPxPerLine,nRelTimeBins): Sequence of frames.
        useFloat : bool, optional
            Flag to determine whether to use floats or integers when converting to a HistData object. Default is None.
            If None, the value of the useFloat flag in the HistData object will be used.
        '''

        # Delete any data in the object
        self.hist_data.deallocateData()

        # Update metadata to match the dimensions of the data array
        metadata = self.getMetadata()
        dims = np.shape(data)
        runType = 'Frame'
        if useFloat == None:
            useFloat = metadata['useFloat']
        else :
            metadata['useFloat'] = useFloat
        
        # Prevent overflow by switching to float if there are values higher than the maximum value of uint16t
        max_val = np.amax(data)
        if max_val >= pow(2,16) and not metadata['useFloat']:
            metadata['useFloat'] = True
            Warning(f"Warning: Switched to float to prevent data overflow using uint16.")

        if len(dims)>3: # Sequence of frames
            runType = 'Sequence'
            metadata['nRuns'] = dims[0]
            metadata['pixelsPerRun'] = dims[1]*dims[2]
            metadata['pixelsPerLine'] = dims[2]

            if metadata['nRelTimeBins'] != dims[3]:
                metadata['nRelTimeBins'] = dims[3]
                # print(f"Setting number of bins to {dims[3]}")

        elif len(dims)==3: # Single frame
            metadata['nRuns'] = 1
            metadata['pixelsPerRun'] = dims[0]*dims[1]
            metadata['pixelsPerLine'] = dims[1]
            # print(f"Setting image size to {dims[0]}x{dims[1]}")

            if metadata['nRelTimeBins'] != dims[2]:
                metadata['nRelTimeBins'] = dims[2]
                # print(f"Setting number of bins to {dims[2]}")

        elif len(dims)==2: # Line
            runType = 'Line'
            metadata['nRuns'] = 1
            metadata['pixelsPerRun'] = dims[0]
            metadata['pixelsPerLine'] = dims[0]
            # print(f"Setting image size to 1x{dims[0]}")
            if metadata['nRelTimeBins'] != dims[1]:
                metadata['nRelTimeBins'] = dims[1]
                # print(f"Setting number of bins to {dims[1]}")
        else: # Point
            # print("Warning input data has only 1 dimension, point image assumed")
            runType = 'Point'
            metadata['nRuns'] = 1
            metadata['pixelsPerRun'] = 1
            metadata['pixelsPerLine'] = 1
            if metadata['nRelTimeBins'] != dims[0]:
                metadata['nRelTimeBins'] = dims[0]
                # print(f"Setting number of bins to {dims[0]}")
 
        # Write metadata
        self.setMetadata(metadata)
        
        # Allocate arrays for serialized data
        self.hist_data.allocateData()

        # Write serialized data
        if metadata['useFloat']:
            self.writeSerializedDataFloat(data)
        else:
            self.writeSerializedData(data)

    cdef writeSerializedDataOld(self, data, runType, dims):
        """
        Serialize numpy decay data into the C++ uint16_t buffer, preserving
        the expected run/pixel ordering.
        """
        for i in range(self.hist_data.totPixels):
            for binNr in range(self.hist_data.nRelTimeBins):
                if runType=='Sequence':
                    frameNr = int(i/self.hist_data.pixelsPerRun)
                    pixelInframe = i - frameNr*self.hist_data.pixelsPerRun
                    row = int(pixelInframe/self.hist_data.pixelsPerLine)
                    col = pixelInframe%self.hist_data.pixelsPerLine
                    self.hist_data.data[i][binNr] = int(data[frameNr][row][col][binNr])
                elif runType=='Frame':
                    row = int(i/self.hist_data.pixelsPerLine)
                    col = i%self.hist_data.pixelsPerLine
                    if row >= dims[0]:
                        print(f"Warning index out of bounds: {row} {col}")
                    self.hist_data.data[i][binNr] = int(data[row][col][binNr])
                elif runType=='Line':
                    self.hist_data.data[i][binNr] = int(data[i][binNr])
                else:
                    self.hist_data.data[i][binNr] = int(data[binNr])

    cdef writeSerializedData(self, data):
        """
        Fast memcpy-based serialization of uint16 histogram data into the
        contiguous C++ buffers.
        Requires the totalPixels and nRelTimeBins to be set correctly and the data
        to be in the shape (totalPixels, nRelTimeBins).
        """
        data = np.reshape(data, (self.hist_data.totPixels, self.hist_data.nRelTimeBins))
        data = np.ascontiguousarray(data, dtype = np.uint16)
        cdef uint16_t [:, :] dataPtr = data
        cdef size_t row_bytes_u16 = <size_t>(self.hist_data.nRelTimeBins * sizeof(uint16_t))
        for i in range(self.hist_data.totPixels):
            memcpy(<void*> self.hist_data.data[i], <void*> &dataPtr[i, 0], row_bytes_u16)

    cdef writeSerializedDataFloat(self, data):
        """
        Fast memcpy-based serialization of float histogram data into the
        contiguous C++ buffers.
        Requires the totalPixels and nRelTimeBins to be set correctly and the data
        to be in the shape (totalPixels, nRelTimeBins).
        """
        data = np.reshape(data, (self.hist_data.totPixels, self.hist_data.nRelTimeBins))
        data = np.ascontiguousarray(data, dtype = np.float32)
        cdef float [:, :] dataPtr = data
        cdef size_t row_bytes_f = <size_t>(self.hist_data.nRelTimeBins * sizeof(float))
        for i in range(self.hist_data.totPixels):
            memcpy(<void*> self.hist_data.dataFloat[i], <void*> &dataPtr[i, 0], row_bytes_f)
        
    cdef writeSerializedDataFloatOld(self, data, runType, dims):
        """
        Serialize numpy decay data into the C++ float buffer while matching
        the input run type (Point/Line/Frame/Sequence) layout.
        """
        for i in range(self.hist_data.totPixels):
            for binNr in range(self.hist_data.nRelTimeBins):
                if runType=='Sequence':
                    frameNr = int(i/self.hist_data.pixelsPerRun)
                    pixelInframe = i - frameNr*self.hist_data.pixelsPerRun
                    row = int(pixelInframe/self.hist_data.pixelsPerLine)
                    col = pixelInframe%self.hist_data.pixelsPerLine
                    self.hist_data.dataFloat[i][binNr] = float(data[frameNr][row][col][binNr])
                elif runType=='Frame':
                    row = int(i/self.hist_data.pixelsPerLine)
                    col = i%self.hist_data.pixelsPerLine
                    if row >= dims[0]:
                        print(f"Warning index out of bounds: {row} {col}")
                    self.hist_data.dataFloat[i][binNr] = float(data[row][col][binNr])
                elif runType=='Line':
                    self.hist_data.dataFloat[i][binNr] = float(data[i][binNr])
                else:
                    self.hist_data.dataFloat[i][binNr] = float(data[binNr])
           
    def generateFCSTimes(self):
        '''
        Generate the times for the FCS histogram data. Not fully implemented yet.
        '''

        nTimes = self.hist_data.nBinsFCS*self.hist_data.nCascadesFCS+1
        times = np.ascontiguousarray(np.zeros((nTimes,), dtype = np.double))
        cdef double[:] timesPtr = times # Memoryview of numpy array
        self.hist_data.generateFCSTimes(&timesPtr[0])
        return times
