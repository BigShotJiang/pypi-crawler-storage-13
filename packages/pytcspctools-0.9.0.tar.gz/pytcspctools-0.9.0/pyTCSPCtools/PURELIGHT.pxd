# distutils: language=c++
from libc.stdint cimport uint8_t, uint16_t, uint32_t, int16_t, int64_t
from pyTCSPCtools.data cimport HistData, TTTRData
from libcpp cimport bool

cdef extern from r"TCSPCprocess\functions\PURELIGHT.h":
    void computeStateHistogram(TTTRData &tttr_data, uint32_t* stateHists, uint32_t* cyclesPerPixel)
    void extendDeadTime(TTTRData &tttr_data, int16_t channel, double addedDeadTimeNs, uint8_t* keptMask)
    void maskPhotonEvents(TTTRData &tttr_data, uint8_t* mask)
    void unmaskAllPhotonEvents(TTTRData &tttr_data)
    void computeSCMWeights(TTTRData &tttr_data, bool globalWeights, bool averageRuns)
    void applyLinearRTC(TTTRData &tttr_data, int16_t channel, double rtcSlope, double rtcOffset, uint16_t rtcSatThreshold)
    void computeMultiPhotonMask(TTTRData &tttr_data, int16_t channel, uint8_t* mask, double singlePhotonMaxPulseLength, double singlePhotonMinPulseLength, int16_t n_cycles)
    void computeLaserPeriodDeadTimeMask(TTTRData &tttr_data, int16_t channel, uint8_t* mask)