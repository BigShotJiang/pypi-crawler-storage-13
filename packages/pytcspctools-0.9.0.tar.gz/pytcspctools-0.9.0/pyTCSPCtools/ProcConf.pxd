# distutils: language=c++
from libc.stdint cimport uint32_t

cdef extern from "TCSPCprocess\ProcConf.h":
    cdef cppclass ProcConf:
        # Input
        char outDir[512]
        char outFileName[512]
        char inDir[512]
        char inFileName[512]

        # Derived values
        uint32_t importHistFromBin
        uint32_t importTTTRfromBin
        uint32_t importFromPTU
        uint32_t importFromOMETiff

        ProcConf()
        ProcConf(const ProcConf &other)
        ProcConf& operator=(ProcConf other)
        ProcConf(ProcConf &&other)
