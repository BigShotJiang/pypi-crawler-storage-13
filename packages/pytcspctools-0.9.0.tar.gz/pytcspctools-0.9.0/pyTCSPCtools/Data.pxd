# distutils: language=c++
# cython: language_level=3
from libc.stdint cimport int16_t, int32_t, uint8_t, uint16_t, uint32_t, uint64_t
from libcpp cimport bool
from pyTCSPCtools.Buffer cimport Buffer

cdef extern from "TCSPCcore\Data.h":
    cdef cppclass TTTRData:
        int isDebug
        char outName[512]
        char outDir[512]
        char inName[512]
        char inDir[512]

        int16_t lineStartPTU
        int16_t lineEndPTU
        int16_t frameChangePTU

        uint8_t activeChannels[4]
        uint8_t channelOffset[4]
        uint8_t numActiveChannels

        # -- Serialized metadata --
        char version[16]
        bool useFloat
        bool useBidi
        # Format
        char TTTRformat[512]
        uint32_t PT3OVERFLOW
        uint32_t PT2OVERFLOW 
        double relTimeResNs
        double absTimeResNs 
        double pulseLengthResNs 
        double maxPulseLengthTimeNs 
        double FPGAtimeToNs  
        uint32_t lasMHz
        # Experiment
        char runType[512]
        uint64_t bufferCollectionTimeMs 
        double time 
        uint32_t nRuns 
        uint32_t pixelsPerRun 
        uint32_t nEvents 
        double pxDwellTimeMicroS 
    
        # -- Serialized data --
        uint32_t* absTime
        uint32_t* relTime
        int16_t* eventType
        int16_t* channel
        int32_t* pixelNumber
        uint16_t* pulseLength
        uint16_t* steepness
        uint16_t* maxValue
        float* weight

        # Constructors
        TTTRData()
        TTTRData(TTTRData &other)
        # TTTRData& operator=(TTTRData other)
        void swap(TTTRData &obj, TTTRData &other)

        void allocateData()
        void allocateNsData()
        void deallocateData()
        void deallocateNsData()
        void initDataToZero()
        void initDebugToZero()

        void copyEvent(TTTRData &other, uint32_t ind_this, uint32_t ind_other)
        # void extendDeadTime(double deadTimeAdditionNs)
        void processChannelInfo();

        void toCsv()
        void toCsv(const char *filepath)
        void toPTU()
        void toPTU(const char *filepath)
        void toBin()
        void toBin(const char *filepath)
        void fromBin()
        void fromBin(const char *filepath)
        void fromPTU()
        void fromPTU(const char *filepath)
        void printMetadata()

        void fromTTTRBuffer(Buffer &buffer)

    cdef cppclass HistData:
        # -- Non serialized metadata --
        int isDebug 
        char outName[512]
        char outDir[512]
        char inName[512]
        char inDir[512]

        # -- Serialized metadata --
        bool useFloat
        char version[16]
        # Format
        double relTimeResNs
        double absTimeResNs
        double pulseLengthResNs
        double relTimeBinNs
        double pulseLengthBinNs
        double FPGAtimeToNs 
        uint32_t lasMHz
        # Experiment
        char runType[512]
        char histType[512]
        uint64_t bufferCollectionTimeMs
        double time
        uint32_t nRuns
        uint32_t nAvgs
        uint32_t singleDecayPerRun
        uint32_t groupSingleDecayFiles
        uint32_t pixelsPerRun
        uint32_t pixelsPerLine
        uint32_t totPixels
        double pxDwellTimeMicroS
        uint32_t nRelTimeBins
        # -- Fluorescence Correlation Spectroscopy --
        uint32_t nBinsFCS
        uint32_t nCascadesFCS

        # Multichannel acquisition
        uint8_t activeChannels[4]
        uint8_t channelOffset[4]
        uint8_t numActiveChannels
    
        # -- Serialized data --
        uint16_t** data
        float** dataFloat
        uint32_t* syncPulses
        uint32_t* detectedPhotons
        double* avgRelTime
        double* avgPulseLength
        double* photonsPerMicroSec
        uint32_t* pulseLengthHist

        HistData()
        HistData(const HistData &other)
        void init()
        void swap(HistData &obj, HistData &other)

        void allocateData()
        void deallocateData()
        void initDataToZero()

        void toCsv()
        void toCsv(const char *filepath)
        void toBin()
        void toBin(const char *filepath)
        void toOMETiff()
        void toOMETiff(const char *filepath)
        void toIntensityTiff()
        void toIntensityTiff(const char *filepath)
        void fromBin()
        void fromBin(const char *filepath)
        void fromOMETiff()
        void fromOMETiff(const char *filepath)
        void fromTTTR(TTTRData &tttr, const char *histType, uint32_t nTimeBins)
        void fromTTTRBuffer(Buffer &buffer, uint32_t nTimeBins)
        void TTTRtoFLIM(TTTRData &tttr, uint32_t nTimeBins)
        void TTTRtoFCS(TTTRData &tttr, uint32_t nTimeBins) 
        void generateFCSTimes(double* times)
        void printMetadata()

cdef class PyTTTRData:

    cdef TTTRData tttr_data

    
    cpdef getFilePath(self)
    
    cpdef setFilePath(self, inDir, inName)
    cpdef loadDataFromBinary(self, dir=*, filename=*, overrideTTTRformat=*)
    cpdef loadDataFromBuffer(self, dir, filename, lasMHz=*, filter_long_rel_times=*, remove_short_pulses=*,short_pulse_thresh_ns=*, remove_long_pulses=*, long_pulse_thresh_ns=*, channels=*, pt2_mode=*, ignore_run_offsets=*)
    cpdef loadDataFromPTU(self, dir, filename)
    cpdef saveDataToBinary(self, path)
    cpdef getMetadata(self)
    cpdef getData(self)
    cpdef applyPURELIGHTcorrection(self, channels, correctionParams, globalWeights=*, averageRuns=*, copyData=*)
    cpdef applyMultiPhotonMask(self, channels, correctionParams)
    cpdef applyLaserPeriodBlindTimeMask(self,channels)
    cpdef countCyclesPerPixel(self)
    cpdef countActiveCycles(self)
    cpdef setRelTimes(self, relTime)
    cpdef setWeights(self, weights)
    cpdef shiftRelTimes(self, relTimeShift)
    cpdef computeStateHistogram(self)
    cpdef extendBlindTime(self, channel=*, blind_time_addition_ns=*)
    cpdef applyEventMask(self, mask)
    cpdef unmaskPhotonEvents(self)
    cpdef setUseFloat(self, useFloat)
    cpdef applyLinearTimeCompPulseHeight(self, slope, offset, saturation_height=*, channel=*)
    cpdef computeSCMWeights(self, global_weights=*, average_runs=*)


cdef class PyHistData:
    cdef HistData hist_data

    cdef writeSerializedDataOld(self, data, runType, dims)
    cdef writeSerializedData(self, data)
    cdef writeSerializedDataFloat(self, data)
    cdef writeSerializedDataFloatOld(self, data, runType, dims)
