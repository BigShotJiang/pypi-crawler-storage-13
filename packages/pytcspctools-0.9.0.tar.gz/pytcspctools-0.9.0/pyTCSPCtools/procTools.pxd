# distutils: language=c++
from libcpp.string cimport string
from pyTCSPCtools.ProcConf cimport ProcConf
from libc.stdint cimport uint16_t
from pyTCSPCtools.data cimport TTTRData, HistData

ctypedef fused T:
    uint16_t
    float

cdef extern from r"TCSPCprocess\tools\procTools.h":
    void extractSubsetDataTTTR(TTTRData &tttr_dest, TTTRData &tttr_source, double absTimeStartSec, double absTimeEndSec)
    void convertHistDataToContiguousArray(HistData &histData, float* image_data)
    void convertHistDataToContiguousArray(HistData &histData, uint16_t* image_data)
    void convertMatrixToContiguousArray(T** matrix, T* array, int rows, int cols)
    void convertContiguousArrayToMatrix(T* array, T** matrix, int rows, int cols)
    void printMessage(string msg)
    void printConf(ProcConf conf)
