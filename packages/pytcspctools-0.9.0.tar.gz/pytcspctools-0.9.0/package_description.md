# pyTCSPCtools

`pyTCSPCtools` provides a way to process and analyze TCSPC data, focusing on data collected with our [TCSPC devices](https://brunoweberlab.pages.uzh.ch/tcspc/index.html). It uses [Cython](https://cython.org/) to compile Python wrappers for C++ methods and classes, enabling efficient processing of the binary data collected by our devices. The package focuses on the two main data objects used in the TCSPC++ code: `TTTRData` and `HistData`, offering the Python wrappers `PyTTTRData` and `PyHistData` respectively. Additionally, a wrapper for the global fitting algorithm of FLIMfit is provided in the `PyGlobalFitter` class.

## Installation

> **Note:** Currently, the package is only available for Windows (Python 3.9+) due to the compilation of TCSPC++ (and FLIMfit).

```bash
pip install pyTCSPCtools
```

## Documentation

The documentation for this package can be found [here](https://brunoweberlab.pages.uzh.ch/pytcspcapi/index.html).
