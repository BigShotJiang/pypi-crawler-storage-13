"""Entry point for python -m cc_check."""
import sys
from cc_check import check

def main():
    commit_file = sys.argv[1] if len(sys.argv) > 1 else None
    success, stdout, stderr = check(commit_file)
    if stdout:
        print(stdout)
    if stderr:
        print(stderr, file=sys.stderr)
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()
