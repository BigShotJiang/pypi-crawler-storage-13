__author__ = "Kapil Sachdeva"
__application__ = "adk-rag"
__version__ = "0.0.1"
