# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListRunningTaskResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total': 'int',
        'tasks': 'list[RunningTasks]'
    }

    attribute_map = {
        'total': 'total',
        'tasks': 'tasks'
    }

    def __init__(self, total=None, tasks=None):
        r"""ListRunningTaskResponse

        The model defined in huaweicloud sdk

        :param total: 正在处理的任务总数。
        :type total: int
        :param tasks: 正在处理的任务列表。
        :type tasks: list[:class:`huaweicloudsdkkps.v3.RunningTasks`]
        """
        
        super().__init__()

        self._total = None
        self._tasks = None
        self.discriminator = None

        if total is not None:
            self.total = total
        if tasks is not None:
            self.tasks = tasks

    @property
    def total(self):
        r"""Gets the total of this ListRunningTaskResponse.

        正在处理的任务总数。

        :return: The total of this ListRunningTaskResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListRunningTaskResponse.

        正在处理的任务总数。

        :param total: The total of this ListRunningTaskResponse.
        :type total: int
        """
        self._total = total

    @property
    def tasks(self):
        r"""Gets the tasks of this ListRunningTaskResponse.

        正在处理的任务列表。

        :return: The tasks of this ListRunningTaskResponse.
        :rtype: list[:class:`huaweicloudsdkkps.v3.RunningTasks`]
        """
        return self._tasks

    @tasks.setter
    def tasks(self, tasks):
        r"""Sets the tasks of this ListRunningTaskResponse.

        正在处理的任务列表。

        :param tasks: The tasks of this ListRunningTaskResponse.
        :type tasks: list[:class:`huaweicloudsdkkps.v3.RunningTasks`]
        """
        self._tasks = tasks

    def to_dict(self):
        import warnings
        warnings.warn("ListRunningTaskResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListRunningTaskResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
