from kgnode.core.sparql_query import execute_sparql_query
from kgnode.core.kg_config import KGConfig
from typing import List, Dict, Optional

def search_entities_by_keywords(
    keywords: list,
    limit: int = 10,
    config: Optional[KGConfig] = None
):
    """
    Search for entities in the knowledge graph based on keywords.

    Args:
        keywords (list): List of keyword strings to search for in entity labels.
        limit (int): Maximum number of results to return. Default is 10.
        config: Optional KGConfig instance for configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.

    Returns:
        List[Dict]: Query results with 'entity' and 'label' keys.
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    if not keywords:
        return []

    # Build FILTER conditions for each keyword
    filter_conditions = []
    for keyword in keywords:
        # Escape special characters and convert to lowercase for case-insensitive search
        escaped_keyword = keyword.replace("\\", "\\\\").replace('"', '\\"')
        filter_conditions.append(f'CONTAINS(LCASE(STR(?label)), "{escaped_keyword.lower()}")')

    # Combine all conditions with OR
    filter_clause = " || ".join(filter_conditions)

    # Construct the SPARQL query
    sparql_query = f"""
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

    SELECT DISTINCT ?entity ?label
    WHERE {{
      ?entity rdfs:label ?label .
      FILTER({filter_clause})
    }}
    LIMIT {limit}
    """

    return execute_sparql_query(sparql_query, config=config)

if __name__ == "__main__":
    print(search_entities_by_keywords(["publication", "author"]))
