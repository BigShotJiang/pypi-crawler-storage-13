from typing import Optional
from SPARQLWrapper import SPARQLWrapper, JSON
from kgnode.core.kg_config import KGConfig


def execute_sparql_query(sparql_query: str, config: Optional[KGConfig] = None):
    """
    Query a running Oxigraph SPARQL endpoint and return results as a list of dictionaries.

    Args:
        sparql_query (str): The SPARQL query string.
        config: Optional KGConfig instance for endpoint configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.

    Returns:
        List[Dict]: Query results. Each dict maps variable names to their values.
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    endpoint_url = config.sparql_endpoint
    sparql = SPARQLWrapper(endpoint_url)
    sparql.setQuery(sparql_query)
    sparql.setReturnFormat(JSON)

    sparql_results = sparql.query().convert()

    # Convert results to list of dicts for easier processing
    output = []
    for result in sparql_results["results"]["bindings"]:
        row = {var: result[var]["value"] for var in result}
        output.append(row)

    return output


# Example usage
if __name__ == "__main__":
    # query = """
    # PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    # PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    # SELECT * WHERE {
    #     ?sub ?pred ?obj .
    # } LIMIT 10
    # """
    #
    # query = """
    # PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    # PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    # SELECT ?predicate ?object
    # WHERE {{
    #     <https://dblp.org/rdf/schema#Publication> ?predicate ?object .
    # }}
    # """
    keyword_query = """
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    SELECT DISTINCT ?entity ?label
    WHERE {
      ?entity rdfs:label ?label .
      FILTER(CONTAINS(LCASE(STR(?label)), "publication") || CONTAINS(LCASE(STR(?label)), "author"))
    }
    LIMIT 10
    """
    #
    # # Option A: Use default config (recommended)
    results = execute_sparql_query(keyword_query)
    #
    # # Option B: Use custom config
    # # from kgnode.core.kg_config import KGConfig
    # # config = KGConfig.default()  # or KGConfig(sparql_endpoint="http://custom:8080/query")
    # # results = execute_sparql_query(keyword_query, config=config)
    #
    # print(results)
    # for r in results:
    #     print(r)
