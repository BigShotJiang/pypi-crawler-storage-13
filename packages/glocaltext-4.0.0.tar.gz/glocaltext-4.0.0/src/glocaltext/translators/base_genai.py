"""Defines a base class for GenAI-based translators (Gemini, Gemma)."""

import json
import logging
from abc import ABC, abstractmethod

from google import genai
from google.api_core import exceptions as api_core_exceptions
from google.genai import types
from pydantic import BaseModel, Field

from glocaltext.config import ProviderSettings

from .base import BaseTranslator, TranslationResult

logger = logging.getLogger(__name__)


# --- Pydantic Schema for Structured Output ---
class TranslationList(BaseModel):
    """Defines the expected JSON structure for the list of translations."""

    translations: list[str] = Field(description="A list of translated strings.")


# --- Constants ---
PROMPT_TEMPLATE = """
You are a professional translation engine. Your task is to translate a list of texts from {source_lang} to {target_lang}.

You MUST return a JSON object with a single key "translations" that contains a list of the translated strings.
The list of translated strings must have the same number of items as the input list.
If a translation is not possible, return the original text for that item. Do not add explanations.

Translate the following texts:
{texts_json_array}
"""


class BaseGenAITranslator(BaseTranslator, ABC):
    """
    An abstract base class for Google's Generative AI models (e.g., Gemini, Gemma).

    This class extracts the common logic for initializing the client, counting tokens,
    and handling the translation workflow. Subclasses are required to implement
    the response parsing and define model-specific configurations.
    """

    def __init__(self, settings: ProviderSettings) -> None:
        """
        Initialize the GenAI Translator.

        Args:
            settings: A Pydantic model containing provider-specific configurations
                      such as the API key and model name.

        Raises:
            ValueError: If the API key is missing from the settings.
            ConnectionError: If the GenAI client fails to initialize.

        """
        super().__init__(settings)
        if not self.settings:
            msg = f"ProviderSettings are required for {self.__class__.__name__} but were not provided."
            raise ValueError(msg)

        if not self.settings.api_key:
            msg = f"API key for {self.__class__.__name__} is missing in the provider settings."
            raise ValueError(msg)

        try:
            # Using the Client API for consistency with the new SDK guidelines.
            self.client = genai.Client(api_key=self.settings.api_key)
            self.model_name = self.settings.model or self._default_model_name()
        except (ValueError, api_core_exceptions.GoogleAPICallError) as e:
            msg = f"Failed to initialize GenAI client: {e}"
            raise ConnectionError(msg) from e

    @abstractmethod
    def _default_model_name(self) -> str:
        """Return the default model name to use if not specified in settings."""
        raise NotImplementedError

    def _get_generation_config(self) -> types.GenerateContentConfig | None:
        """
        Return the generation configuration for the API call.

        Subclasses can override this to provide model-specific configurations.
        By default, no specific config is sent.
        """
        return None

    def _get_prompt_template(self) -> str:
        """
        Return the prompt template for the translation task.

        Subclasses can override this to provide model-specific prompt structures.
        """
        return PROMPT_TEMPLATE

    @abstractmethod
    def _parse_response(self, response_text: str, original_texts: list[str]) -> list[str]:
        """
        Parse and validate the JSON response from the API.

        Args:
            response_text: The raw text from the API response.
            original_texts: The original list of texts for validation.

        Returns:
            A list of translated strings.

        """
        raise NotImplementedError

    def translate(
        self,
        texts: list[str],
        target_language: str,
        source_language: str | None = None,
        *,
        debug: bool = False,
        prompts: dict[str, str] | None = None,
    ) -> list[TranslationResult]:
        """
        Translate a list of texts using a Google GenAI model.

        Returns:
            A list of TranslationResult objects.

        Raises:
            ValueError: If the API response is invalid or cannot be processed.
            ConnectionError: If there's an issue communicating with the API.

        """
        if not texts:
            return []

        template = (prompts or {}).get("user", self._get_prompt_template())

        prompt = template.format(
            source_lang=source_language or "the original language",
            target_lang=target_language,
            texts_json_array=json.dumps(texts, ensure_ascii=False),
        )

        if debug:
            logger.debug(
                "%s Request:\n- Model: %s\n- Prompt Body (first 300 chars): %s...",
                self.__class__.__name__,
                self.model_name,
                prompt[:300],
            )

        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=self._get_generation_config(),
            )
        except api_core_exceptions.GoogleAPICallError as e:
            logger.exception("A Google API error occurred during translation.")
            msg = f"A Google API error occurred: {e}"
            raise ConnectionError(msg) from e

        response_text = response.text
        if not response_text:
            msg = "Failed to process API response: response text is empty."
            raise ValueError(msg)

        try:
            translated_texts = self._parse_response(response_text, texts)

            total_tokens = 0
            if response.usage_metadata:
                total_tokens = response.usage_metadata.total_token_count or 0

            tokens_per_text = total_tokens // len(texts) if texts else 0
            results = [TranslationResult(translated_text=text, tokens_used=tokens_per_text) for text in translated_texts]

            if texts and results and total_tokens > 0:
                remainder = total_tokens % len(texts)
                if results[-1].tokens_used is not None:
                    results[-1].tokens_used += remainder
        except ValueError as e:
            raw_response_text = getattr(response, "text", "[NO TEXT IN RESPONSE]")
            logger.exception(
                "Failed to parse, validate, or read API response: %s",
                raw_response_text,
            )
            msg = f"Failed to process API response. Details: {e}"
            raise ValueError(msg) from e
        else:
            return results

    def count_tokens(self, texts: list[str], prompts: dict[str, str] | None = None) -> int:
        """Calculate the token count by calling the API."""
        if not texts:
            return 0

        template = (prompts or {}).get("user", self._get_prompt_template())
        prompt = template.format(
            source_lang="en",  # lang doesn't matter for token count
            target_lang="fr",
            texts_json_array=json.dumps(texts, ensure_ascii=False),
        )
        try:
            # Using the client API to count tokens
            response = self.client.models.count_tokens(model=self.model_name, contents=prompt)
        except api_core_exceptions.GoogleAPICallError:
            logger.exception("Token counting via API failed for %s. Returning 0.", self.__class__.__name__)
            return 0

        return response.total_tokens or 0
