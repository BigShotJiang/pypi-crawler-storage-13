# Citadel Grid Simulator

A pandapower-based electrical distribution grid simulator with SCADA protocol interfaces (DNP3 and Modbus). Designed for cybersecurity research, zero-trust policy testing, and grid control experimentation.

## Overview

The Citadel Grid Simulator provides a realistic electrical distribution network simulation with:

- **Flexible Grid Models**: Support for multiple network topologies including Dickert LV distribution networks
- **Real-time Simulation**: 1-second timestep power flow calculations
- **SCADA Protocols**: DNP3 outstation and Modbus server interfaces
- **Time-Series Data**: Realistic load, solar PV, and wind generation profiles
- **Control Points**: Breakers, loads, and DER setpoints for policy enforcement testing
- **Thread-Safe**: Concurrent operation with command queue and state callbacks

## Key Features

- **Realistic Grid Physics**: Pandapower-based AC power flow simulation
- **DER Integration**: Solar PV, wind generation, and energy storage
- **SCADA Interfaces**: Industry-standard DNP3 and Modbus protocols
- **Time-Series Profiles**: Stochastic load and generation patterns
- **Control Operations**: Breaker switching, load adjustment, DER dispatch
- **State History**: Configurable history buffer for analysis
- **Web API**: Optional REST API for monitoring and control

## Architecture

```
External SCADA Client
        │
        │ (Modbus/DNP3)
        ▼
┌─────────────────────────────────┐
│  Grid Simulator (Substation)   │
│                                 │
│  ┌───────────────────────────┐ │
│  │ SCADA Protocol Servers    │ │
│  │ - DNP3 Outstation         │ │
│  │ - Modbus Server           │ │
│  └──────────┬────────────────┘ │
│             │                   │
│             ▼                   │
│  ┌───────────────────────────┐ │
│  │  GridSimulator (1s loop)  │ │
│  │  - Command Queue          │ │
│  │  - Pandapower Solver      │ │
│  │  - State Capture          │ │
│  │  - Update Protocol Points │ │
│  └───────────────────────────┘ │
└─────────────────────────────────┘
```

## Project Structure

```
citadel-simulator/
├── README.md                      # This file
├── LICENSE                        # License file
├── environment.yml                # Conda environment
├── pyproject.toml                 # Python package configuration
├── setup.py                       # Package setup
├── Makefile                       # Build automation
├── docs/                          # Documentation
│   └── GITHUB_EXPORT.txt          # Release process
├── examples/                      # Usage examples
│   ├── basic_engine_usage.py
│   ├── factory_usage.py
│   └── README.md
└── src/
    ├── __init__.py
    ├── main.py                    # Entry point
    ├── simulator.py               # GridSimulator (1s loop)
    ├── web_api.py                 # Optional REST API
    ├── settings.py                # Configuration
    ├── settingslocal.py.example   # Local config template
    ├── engines/
    │   ├── __init__.py
    │   ├── base.py                # Engine interface
    │   └── pandapower_engine.py   # Pandapower implementation
    ├── models/
    │   ├── __init__.py
    │   ├── dickert_lv.py          # Dickert LV model with DERs
    │   └── factory.py             # Model factory
    ├── protocols/
    │   ├── __init__.py
    │   ├── base.py                # Protocol interface
    │   ├── dnp3_outstation.py     # DNP3 outstation (RTU)
    │   └── modbus_server.py       # Modbus server (RTU)
    ├── schemas/
    │   ├── __init__.py
    │   ├── commands.py            # Command schemas
    │   ├── common.py              # Common types
    │   ├── results.py             # Result schemas
    │   ├── state.py               # State schemas
    │   └── topology.py            # Topology schemas
    ├── timeseries/
    │   ├── __init__.py
    │   ├── load_profiles.py       # Load profile generator
    │   ├── solar_profiles.py      # Solar PV profile generator
    │   └── wind_profiles.py       # Wind profile generator
    ├── grid_stix_integration/
    │   ├── __init__.py
    │   ├── annotator.py           # STIX annotation
    │   ├── exporter.py            # STIX export
    │   └── telemetry.py           # Telemetry collection
    └── static/
        ├── index.html             # Web UI
        ├── app.js                 # Web UI logic
        └── style.css              # Web UI styles
```

## Quick Start

### Installation

```bash
# Using micromamba (recommended)
micromamba env create -f environment.yml
micromamba activate grid-simulator

# Or using conda
conda env create -f environment.yml
conda activate grid-simulator
```

### Configuration

```bash
# Copy example config
cp src/settingslocal.py.example src/settingslocal.py

# Edit configuration
nano src/settingslocal.py
```

### Running the Simulator

```bash
# Using Makefile
make run

# Or directly
cd src && python -m main
```

### Running Tests

```bash
make test
```

## Grid Models

The simulator supports multiple grid network models for different research scenarios.

### Dickert LV Network (Default)

The default model is the Dickert LV distribution network, designed for DER research:

- **DER-focused**: Designed for distribution-level DER integration studies
- **Modern architecture**: Reflects current grids with high DER penetration
- **Realistic topology**: Includes residential/commercial loads, solar PV, storage
- **Manageable scale**: Rapid iteration for control and cybersecurity experiments
- **Well-documented**: Published benchmark network with clear specifications

**Network Classes**:
- **Class 1**: Smallest network (default) - ideal for testing
- **Class 2-5**: Increasing size and complexity

### Custom Models

The simulator architecture supports custom grid models. Additional network topologies can be added by implementing the model interface in `src/models/`.

## Time-Series Data Generation

The simulator includes comprehensive time-series generators for realistic load and generation profiles.

### Load Profiles

**Residential**:
- Morning peak: 6-9 AM
- Evening peak: 5-10 PM
- Overnight minimum: 11 PM - 5 AM
- Seasonal variations (summer AC, winter heating)
- Weekday/weekend differences
- Stochastic noise (15%)

**Commercial**:
- Office: 8 AM - 6 PM weekdays
- Retail: 9 AM - 9 PM daily
- Industrial: 24/7 operation
- Stochastic noise (10%)

### Solar PV Profiles

- Cosine irradiance curve (sunrise to sunset)
- Seasonal sun angle variations
- Cloud effects: clear, partly cloudy, cloudy
- Inverter efficiency (96% default)
- Day-to-day variability

### Wind Profiles

- Power curve: cut-in 3 m/s, rated 12 m/s, cut-out 25 m/s
- AR(1) process for temporal correlation
- Cubic power relationship
- Stochastic variations

### Example Usage

```python
from timeseries import LoadProfileGenerator, SolarProfileGenerator

# Generate load profiles
load_gen = LoadProfileGenerator(random_seed=42)
loads = load_gen.generate_multiple_loads(
    num_residential=5,
    num_commercial=2,
    num_days=7,
    season='summer'
)

# Generate solar profiles
solar_gen = SolarProfileGenerator(random_seed=42)
solar = solar_gen.generate_with_variability(
    num_days=7,
    rated_capacity_kw=10.0,
    season='summer'
)

# Convert to pandapower format
load_pp = load_gen.to_pandapower_format(loads, load_indices)
solar_pp = solar_gen.to_pandapower_format(solar, sgen_indices)
```

## SCADA Protocols

### DNP3 Outstation

**Port**: 20000 (configurable)

**Point Mapping**:
- Analog Inputs 0-N: Bus voltages (per unit)
- Analog Inputs 100+: Line power flows (MW)
- Analog Inputs 200+: DER generation (MW)
- Binary Inputs 0-N: Breaker status (open/closed)
- Binary Outputs 0-N: Breaker controls

**Features**:
- Integrity polls
- Event reporting
- Control operations
- Quality flags
- Timestamps

### Modbus Server

**Port**: 502 (configurable)

**Register Mapping**:
- Holding Registers 0-999: Bus voltages (scaled)
- Holding Registers 1000-1999: Line flows (scaled)
- Holding Registers 2000-2999: DER generation (scaled)
- Coils 0-999: Breaker status
- Coils 1000-1999: Breaker controls

**Features**:
- Function codes: 1, 2, 3, 4, 5, 6, 15, 16
- Exception handling
- Multiple client support

## SCADA Commands

The simulator supports the following control commands:

- `OPEN_BREAKER` - Open a line breaker
- `CLOSE_BREAKER` - Close a line breaker
- `SET_DER_SETPOINT` - Adjust DER power output
- `ADJUST_LOAD` - Modify load demand
- `SET_STORAGE_POWER` - Control energy storage (charge/discharge)

## Configuration

### Environment Variables

```bash
# Simulation
SIMULATION_TIMESTEP=1.0          # seconds
NETWORK_CLASS=1                  # Dickert LV network class (1-5)
NUM_TRANSFORMERS=1               # Number of transformers (1-2)

# DNP3
DNP3_ENABLED=true
DNP3_PORT=20000
DNP3_LOCAL_ADDRESS=1
DNP3_REMOTE_ADDRESS=10

# Modbus
MODBUS_ENABLED=true
MODBUS_PORT=502
MODBUS_UNIT_ID=1

# Web API
WEB_API_ENABLED=false
WEB_API_PORT=8000

# Logging
LOG_LEVEL=INFO
LOG_FILE=grid_simulator.log
```

### Settings File

See `src/settingslocal.py.example` for all configuration options.

## Development

### Makefile Commands

```bash
make help      # Show available commands
make install   # Create conda environment
make test      # Run tests
make run       # Run simulator
make clean     # Remove generated files
make lint      # Run linting
make format    # Format code
```

### Adding Custom Profiles

```python
# In your code
from timeseries import LoadProfileGenerator

class CustomLoadGenerator(LoadProfileGenerator):
    def generate_custom_profile(self, **kwargs):
        # Your custom logic here
        pass
```

### Extending Protocol Support

```python
# In src/protocols/
from protocols.base import ProtocolServer

class CustomProtocolServer(ProtocolServer):
    def __init__(self, simulator, port):
        self.simulator = simulator
        self.port = port
    
    def update_measurements(self, state):
        # Map state to protocol points
        pass
    
    def handle_control(self, command):
        # Process control commands
        pass
```

## Testing

### Unit Tests

```bash
# Run all tests
make test

# Run specific test file
python -m pytest tests/test_basic.py -v

# Run with coverage
python -m pytest --cov=src tests/
```

### Integration Tests

```bash
# Test DNP3 protocol
python -m pytest tests/test_dnp3.py -v

# Test Modbus protocol
python -m pytest tests/test_modbus.py -v
```

### SCADA Client Testing

```bash
# Test with Modbus client
mbpoll -a 1 -r 0 -c 10 localhost

# Test with DNP3 client
# (Use dnp3demo or similar DNP3 master tool)
```

## Deployment

### Docker

```bash
# Build image
docker build -t citadel-simulator .

# Run container
docker run -p 20000:20000 -p 502:502 citadel-simulator
```

### Docker Compose

```yaml
version: '3.8'
services:
  grid-simulator:
    build: .
    ports:
      - "20000:20000"  # DNP3
      - "502:502"      # Modbus
      - "8000:8000"    # Web API (optional)
    environment:
      - SIMULATION_TIMESTEP=1.0
      - DNP3_ENABLED=true
      - MODBUS_ENABLED=true
      - WEB_API_ENABLED=true
    volumes:
      - ./logs:/app/logs
```

## Performance

- **Timestep**: 1 second (configurable)
- **State history**: 3600 steps (1 hour at 1s timestep)
- **Protocol updates**: On every timestep
- **Typical CPU**: <5% for Class 1 network
- **Memory**: ~100MB for Class 1 network

## Troubleshooting

### Common Issues

**Power flow doesn't converge**:
- Check load/generation balance
- Verify network connectivity
- Review voltage limits

**DNP3 connection fails**:
- Check port 20000 is not in use
- Verify firewall settings
- Check DNP3 addresses match

**Modbus connection fails**:
- Check port 502 is not in use (may need sudo)
- Verify unit ID matches
- Check register addresses

### Debug Mode

```bash
# Enable debug logging
export LOG_LEVEL=DEBUG
python -m src.main
```

## Use Cases

### Cybersecurity Research

- Test SCADA protocol vulnerabilities
- Evaluate intrusion detection systems
- Simulate attack scenarios (e.g., false data injection)
- Validate security controls

### Zero-Trust Policy Testing

- Implement fine-grained access controls
- Test policy enforcement on grid operations
- Validate least-privilege principles
- Monitor policy violations

### Grid Control Experiments

- Test DER coordination algorithms
- Evaluate voltage regulation strategies
- Simulate demand response programs
- Validate grid stability controls

### Education and Training

- Teach SCADA protocols
- Demonstrate grid operations
- Practice incident response
- Learn power systems fundamentals

## API Reference

### Python API

```python
from simulator import GridSimulator
from models.factory import create_model

# Create grid model
model = create_model(network_class=1, num_transformers=1)

# Initialize simulator
sim = GridSimulator(
    model=model,
    timestep=1.0,
    enable_dnp3=True,
    enable_modbus=True
)

# Start simulation
sim.start()

# Send command
sim.send_command({
    'type': 'OPEN_BREAKER',
    'line_id': 5
})

# Get current state
state = sim.get_state()

# Stop simulation
sim.stop()
```

### REST API (Optional)

```bash
# Get current state
curl http://localhost:8000/api/state

# Send command
curl -X POST http://localhost:8000/api/command \
  -H "Content-Type: application/json" \
  -d '{"type": "OPEN_BREAKER", "line_id": 5}'

# Get topology
curl http://localhost:8000/api/topology
```

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## License

See [LICENSE](LICENSE) file for details.

## References

- [Pandapower Documentation](https://pandapower.readthedocs.io/)
- [DNP3 Protocol](https://www.dnp.org/)
- [Modbus Protocol](https://modbus.org/)

## Support

For questions, issues, or feature requests, please open an issue on GitHub.

## Acknowledgments

This simulator was developed for cybersecurity and grid control research. It builds upon:

- Pandapower for power flow simulation
- PyDNP3 for DNP3 protocol support
- PyModbus for Modbus protocol support
- The Dickert LV benchmark networks