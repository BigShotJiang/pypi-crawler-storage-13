from reference_renamer.core.file_processor import FileProcessor

processor = FileProcessor(".")
for path in processor.scan_directory():
    print(path)
