from pathlib import Path
from reference_renamer.core.change_logger import ChangeLogger, ArticleMetadata

logger = ChangeLogger(Path("logs"))
metadata = ArticleMetadata(
    authors=["Doe"],
    year=2024,
    title="Test",
    doi=None,
    abstract=None,
    keywords=[],
)
logger.log_change(Path("old.txt"), Path("new.txt"), metadata)
print(logger.get_recent_changes())
