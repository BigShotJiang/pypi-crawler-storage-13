from pathlib import Path
from reference_renamer.utils.citations import write_bibtex

write_bibtex(
    [
        {
            "citation_key": "Demo_2024",
            "title": "Demo Title",
            "authors": ["Tester"],
            "year": 2024,
        }
    ],
    Path("citations.bib"),
)
