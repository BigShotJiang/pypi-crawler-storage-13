from reference_renamer.core.filename_generator import FilenameGenerator
from reference_renamer.core.metadata_enricher import ArticleMetadata

metadata = ArticleMetadata(
    authors=["Doe, Jane"],
    year=2024,
    title="Sample Research Paper",
    doi=None,
    abstract=None,
    keywords=[],
)

generator = FilenameGenerator()
print(generator.generate_filename(metadata, ".pdf"))
