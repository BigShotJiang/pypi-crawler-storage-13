import asyncio
from reference_renamer.api.semantic_scholar import SemanticScholarAPI


async def main():
    api = SemanticScholarAPI()
    results = await api.search_paper("machine learning", limit=1)
    print(results[0] if results else "none")


asyncio.run(main())
