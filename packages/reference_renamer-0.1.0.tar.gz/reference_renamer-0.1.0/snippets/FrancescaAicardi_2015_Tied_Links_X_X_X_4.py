import asyncio
from reference_renamer.api.arxiv import ArxivAPI


async def main():
    api = ArxivAPI()
    papers = await api.search_papers("quantum")
    print(papers[0] if papers else "none")


asyncio.run(main())
