import asyncio
from reference_renamer.api.ollama import OllamaAPI


async def main():
    api = OllamaAPI()
    data = await api.extract_metadata("Some text")
    print(data)


asyncio.run(main())
