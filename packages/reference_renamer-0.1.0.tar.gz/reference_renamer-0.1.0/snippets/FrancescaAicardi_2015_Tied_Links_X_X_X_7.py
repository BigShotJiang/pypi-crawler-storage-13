from pathlib import Path
from reference_renamer.core.content_extractor import ContentExtractor

extractor = ContentExtractor()
data = extractor.extract_content(Path("README.md"))
print(data.get("text", "")[:60])
