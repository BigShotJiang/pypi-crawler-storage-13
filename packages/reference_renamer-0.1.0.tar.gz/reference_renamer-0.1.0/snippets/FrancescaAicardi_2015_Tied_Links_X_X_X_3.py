from reference_renamer.core.metadata_enricher import ArticleMetadata

metadata = ArticleMetadata.from_dict(
    {"title": "Example", "authors": ["A"], "year": 2023, "keywords": []}
)
print(metadata.to_dict())
