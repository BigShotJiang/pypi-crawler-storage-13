#!/usr/bin/env python3
"""
downloader.py — VPS download-only helpers for yt-dlp (no transcoding here).

Goals:
- Prefer exact 1080p H.264 (avc1) + AAC in MP4 (no re-encode) when possible.
- If that doesn't exist, still grab exact 1080p in ANY codec/container (VP9/AV1/WebM/MKV/MP4).
- Only if 1080p truly doesn't exist do we fall back to best <=1080p.
- Audio-only (mp3) supported.
- Optional *dynamic* proxy hook via YTPDL_PROXY_CMD.

Proxy model (no hardcoded list):
- If YTPDL_PROXY_CMD is *unset* => direct DO IP, no proxy.
- If YTPDL_PROXY_CMD is set, downloader will:
    - Run the command as a shell command.
    - Read stdout, strip it, and if non-empty, pass it to yt-dlp as:
        yt-dlp --proxy "<that value>" ...
  The command can do anything you want (call Mullvad API, your own HTTP service, etc.).
  We do NOT support YTPDL_PROXY_LIST anymore.

Env:
- YTPDL_VENV        (default: /opt/yt-dlp-mullvad/venv)   # where yt-dlp is installed
- YTPDL_USER_AGENT  (override UA; optional)
- YTPDL_PROXY_CMD   (optional; shell command that prints a proxy URL for this job)
"""

from __future__ import annotations
import os
import shlex
import subprocess
from typing import Optional, List

# =========================
# Config / constants
# =========================
VENV_PATH = os.environ.get("YTPDL_VENV", "/opt/yt-dlp-mullvad/venv")
YTDLP_BIN = os.path.join(VENV_PATH, "bin", "yt-dlp")

MODERN_UA = os.environ.get(
    "YTPDL_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

PROXY_CMD = os.environ.get("YTPDL_PROXY_CMD", "").strip()

# =========================
# Shell helpers
# =========================
def _run_argv(argv: List[str], check: bool = True) -> str:
    """Run a command and return stdout; raise RuntimeError if check=True and rc!=0."""
    res = subprocess.run(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if check and res.returncode != 0:
        cmd = " ".join(shlex.quote(p) for p in argv)
        raise RuntimeError(f"Command failed: {cmd}\n{res.stdout}")
    return res.stdout or ""

def _get_proxy_from_cmd() -> Optional[str]:
    """
    If YTPDL_PROXY_CMD is set, run it as a shell command and use its stdout as proxy URL.

    Contract:
        - If the command prints a non-empty line (e.g. "socks5://user:pass@host:1080"),
          we pass that to yt-dlp via --proxy.
        - If it's empty or errors, we fall back to direct connection (no proxy).
    """
    cmd = PROXY_CMD
    if not cmd:
        return None
    try:
        res = subprocess.run(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
        )
        proxy = (res.stdout or "").strip()
        return proxy or None
    except Exception:
        return None

# =========================
# Environment / yt-dlp
# =========================
def validate_environment() -> None:
    """Ensure the virtualenv and yt-dlp binary exist."""
    if not os.path.isdir(VENV_PATH):
        raise RuntimeError(
            "Virtualenv missing. Create and install yt-dlp:\n"
            f"  python3 -m venv {VENV_PATH}\n"
            f"  source {VENV_PATH}/bin/activate\n"
            "  pip install -U yt-dlp"
        )
    if not os.path.exists(YTDLP_BIN):
        raise RuntimeError(f"yt-dlp not found at {YTDLP_BIN}. Install inside the venv.")

# =========================
# yt-dlp helpers
# =========================
def _extract_downloaded_filename(stdout: str) -> Optional[str]:
    """
    Parse yt-dlp output to find the final filename.

    We look for lines starting with [download] and either:
      - 'Destination: <path>'
      - '<file> has already been downloaded'
    """
    name = None
    for line in (stdout or "").splitlines():
        line = line.strip()
        if not line.startswith("[download]"):
            continue
        if "Destination:" in line:
            name = line.split("Destination:", 1)[1].strip()
        elif " has already been downloaded" in line and "] " in line:
            start = line.find("] ") + 2
            end = line.rfind(" has already been downloaded")
            if end > start:
                name = line[start:end].strip().strip("'")
        if name:
            break
    return name

def _common_flags_list() -> List[str]:
    return [
        "--retries", "6",
        "--fragment-retries", "6",
        "--retry-sleep", "2",
        "--user-agent", MODERN_UA,
        "--no-cache-dir",
        "--ignore-config",
        "--embed-metadata",
    ]

def _build_yt_dlp_argv(
    url: str,
    out_tpl: str,
    fmt: Optional[str] = None,
    sort: Optional[str] = None,
    merge_to_mp4: bool = False,
    extra: Optional[List[str]] = None,
) -> List[str]:
    """
    Build yt-dlp argv including:
    - format / sort selectors
    - common flags
    - optional proxy
    - output template
    """
    argv: List[str] = [YTDLP_BIN]
    if fmt:
        argv += ["-f", fmt]
    if sort:
        argv += ["-S", sort]

    argv += _common_flags_list()

    proxy = _get_proxy_from_cmd()
    if proxy:
        argv += ["--proxy", proxy]

    if merge_to_mp4:
        argv += ["--merge-output-format", "mp4"]

    if extra:
        argv += extra

    argv += ["--output", out_tpl, url]
    return argv

def _try_fmt(
    url: str,
    out_tpl: str,
    fmt: str,
    sort: Optional[str],
    merge_to_mp4: bool,
) -> Optional[str]:
    argv = _build_yt_dlp_argv(
        url=url,
        out_tpl=out_tpl,
        fmt=fmt,
        sort=sort,
        merge_to_mp4=merge_to_mp4,
    )
    out = _run_argv(argv, check=False)
    path = _extract_downloaded_filename(out)
    return path if (path and os.path.exists(path)) else None

# =========================
# Public API
# =========================
def download_video(
    url: str,
    resolution: int | None = 1080,
    extension: Optional[str] = None,
    out_dir: str = "/root",
) -> str:
    """
    Download media using yt-dlp with no transcoding.

    Args:
        url: Source URL.
        resolution: Target height cap; we try EXACT 1080p first, then best <=1080p.
        extension: "mp3" => extract audio; otherwise treat as video.
        out_dir: Target directory.

    Returns:
        Absolute path to the downloaded file.

    Raises:
        RuntimeError on errors.
    """
    if not url:
        raise RuntimeError("Missing URL.")

    os.makedirs(out_dir, exist_ok=True)
    validate_environment()

    # ---------- Audio-only ----------
    if extension and extension.lower() == "mp3":
        out_tpl = os.path.join(out_dir, "%(title)s.%(ext)s")
        argv = _build_yt_dlp_argv(
            url=url,
            out_tpl=out_tpl,
            extra=["-x", "--audio-format", "mp3"],
        )
        out = _run_argv(argv, check=True)
        path = _extract_downloaded_filename(out)
        if not path or not os.path.exists(path):
            raise RuntimeError("Audio download finished but file not found.")
        return os.path.abspath(path)

    # ---------- Video ----------
    cap = int(resolution or 1080)
    out_tpl = os.path.join(out_dir, "%(title)s.%(ext)s")

    # A) EXACT 1080p, H.264 (avc1) + AAC in MP4 (no re-encode merges)
    fmt_h264_1080 = (
        "bv*[height=1080][vcodec~='^(?:avc1|h264)'][ext=mp4]"
        "+ba[acodec~='^mp4a'][ext=m4a]/"
        "b[height=1080][vcodec~='^(?:avc1|h264)'][ext=mp4]"
    )
    sort_h264_1080 = "codec:h264,res,fps,br,filesize"
    path = _try_fmt(url, out_tpl, fmt_h264_1080, sort_h264_1080, merge_to_mp4=True)
    if path:
        return os.path.abspath(path)

    # B) EXACT 1080p, ANY codec/container (no forced MP4 merge)
    fmt_any_1080 = "bv*[height=1080]+ba/b[height=1080]"
    sort_any_1080 = "res,fps,br,filesize"
    path = _try_fmt(url, out_tpl, fmt_any_1080, sort_any_1080, merge_to_mp4=False)
    if path:
        return os.path.abspath(path)

    # C) If 1080p truly not present, take best <=cap (ANY codec/container)
    fmt_best_upto = f"bv*[height<={cap}]+ba/b[height<={cap}]"
    sort_best_upto = "res,fps,br,filesize"
    path = _try_fmt(url, out_tpl, fmt_best_upto, sort_best_upto, merge_to_mp4=False)
    if not path or not os.path.exists(path):
        raise RuntimeError("Video download finished but file not found.")
    return os.path.abspath(path)
