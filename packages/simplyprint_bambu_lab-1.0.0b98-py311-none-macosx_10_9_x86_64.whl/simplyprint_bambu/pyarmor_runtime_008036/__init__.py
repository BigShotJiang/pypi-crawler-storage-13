# Pyarmor 9.0.8 (ci), 008036, 2025-11-23T19:39:08.936666
from .pyarmor_runtime import __pyarmor__
