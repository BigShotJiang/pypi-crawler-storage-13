"""
多机多卡 DDP 训练脚本
适用场景：2 台服务器，每台 1 张 GPU（总共 2 个进程）

启动方法：
=========
在主节点（服务器1）上运行：
torchrun --nnodes=2 --nproc_per_node=1 --node_rank=0 \
         --master_addr=<主节点IP> --master_port=29500 \
         tongWnB01_MultiNode_DDP.py

在从节点（服务器2）上运行：
torchrun --nnodes=2 --nproc_per_node=1 --node_rank=1 \
         --master_addr=<主节点IP> --master_port=29500 \
         tongWnB01_MultiNode_DDP.py

参数说明：
- --nnodes=2: 总共 2 个节点（服务器）
- --nproc_per_node=1: 每个节点 1 个进程（1 张 GPU）
- --node_rank: 节点编号，主节点=0，从节点=1
- --master_addr: 主节点的 IP 地址
- --master_port: 通信端口（默认 29500）
"""

import os
import socket
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from transformers import GPT2Tokenizer, GPT2LMHeadModel
from transformers import Trainer, TrainingArguments
from datasets import load_dataset
import tongWnB
import time


def generate_random_float(min_value: float = 0.0, max_value: float = 1.0) -> float:
    """生成指定范围内的随机浮点数

    Args:
        min_value (float): 最小值，包含。默认为 0.0。
        max_value (float): 最大值，包含。默认为 1.0。

    Returns:
        float: 随机浮点数
    """
    import random
    return random.uniform(min_value, max_value)


def group_random_test(modelType: str):
    # 随机生成分组数据
    random_strs = [
        "a1B", "x9z", "Qw2", "LmN", "8pQ", "rT3", "b7K", "Zx1", "cD4",
        "eF5", "gH6", "jK7", "mN8", "pQ9", "sT0", "uV1", "wX2", "yZ3"
    ]

    for i in range(10):
        try:
            # 使用新的groupName对应多个指标的传入方式
            tongWnB.log({
                # 训练指标组 - 核心训练指标
                "self_training_metrics": {
                    "self_loss": generate_random_float(0, 100),
                    "self_acc": generate_random_float(0, 100),
                },
                # 性能指标组 - 模型性能相关指标
                modelType: {
                    random_strs[0]: generate_random_float(0, 100),
                    random_strs[1]: generate_random_float(0, 100),
                },
            })
            print(f"第 {i + 1} 次数据上传成功")
            # 添加请求间隔，避免并发请求过多
            time.sleep(0.5)
        except Exception as e:
            print(f"第 {i + 1} 次数据上传失败: {e}")
            # 如果失败，等待更长时间再继续
            time.sleep(2)


def print_banner(message, char="="):
    """打印醒目的横幅"""
    length = 60
    print("\n" + char * length)
    print(message.center(length))
    print(char * length + "\n")


def get_node_info():
    """获取当前节点信息"""
    hostname = socket.gethostname()
    ip = socket.gethostbyname(hostname)
    return hostname, ip


def setup_ddp():
    """
    【显式 DDP 初始化】
    初始化分布式训练环境
    
    环境变量（由 torchrun 自动设置）：
    - RANK: 全局进程编号（0 到 world_size-1）
    - WORLD_SIZE: 总进程数
    - LOCAL_RANK: 本地进程编号（每台机器上从 0 开始）
    - MASTER_ADDR: 主节点地址
    - MASTER_PORT: 通信端口
    """
    print_banner("【步骤 2】初始化 DDP 环境", "=")
    
    # 检查必要的环境变量
    required_env_vars = ['RANK', 'WORLD_SIZE', 'LOCAL_RANK', 'MASTER_ADDR', 'MASTER_PORT']
    missing_vars = [var for var in required_env_vars if var not in os.environ]
    
    if missing_vars:
        print("❌ 错误：缺少必要的环境变量！")
        print(f"缺少: {', '.join(missing_vars)}")
        print("\n请使用 torchrun 启动脚本，例如：")
        print("torchrun --nnodes=2 --nproc_per_node=1 --node_rank=0 \\")
        print("         --master_addr=<主节点IP> --master_port=29500 \\")
        print("         tongWnB01_MultiNode_DDP.py")
        raise RuntimeError("请使用 torchrun 启动脚本")
    
    # 获取分布式参数
    rank = int(os.environ['RANK'])
    world_size = int(os.environ['WORLD_SIZE'])
    local_rank = int(os.environ['LOCAL_RANK'])
    master_addr = os.environ['MASTER_ADDR']
    master_port = os.environ['MASTER_PORT']
    
    # 获取节点信息
    hostname, ip = get_node_info()
    
    # 打印配置信息
    print(f"✓ 节点信息:")
    print(f"  - Hostname: {hostname}")
    print(f"  - IP: {ip}")
    print(f"\n✓ DDP 配置:")
    print(f"  - RANK (全局进程编号): {rank}")
    print(f"  - WORLD_SIZE (总进程数): {world_size}")
    print(f"  - LOCAL_RANK (本地 GPU 编号): {local_rank}")
    print(f"  - MASTER_ADDR: {master_addr}")
    print(f"  - MASTER_PORT: {master_port}")
    
    # 【关键步骤 1】初始化分布式进程组
    print(f"\n>>> 正在初始化分布式进程组...")
    print(f"    Backend: nccl (NVIDIA GPU 专用)")
    dist.init_process_group(
        backend='nccl',  # 使用 NCCL 后端（GPU 通信）
        init_method='env://',  # 从环境变量读取配置
    )
    print(f"✓ 分布式进程组初始化成功！")
    
    # 【关键步骤 2】设置当前进程使用的 GPU
    torch.cuda.set_device(local_rank)
    print(f"✓ 当前进程绑定到 GPU: cuda:{local_rank}")
    
    # 验证 DDP 是否正确初始化
    if dist.is_initialized():
        print(f"\n🎉 DDP 初始化成功！")
        print(f"   当前节点是: {'【主节点】' if rank == 0 else '【从节点】'}")
        print(f"   这是全局第 {rank + 1}/{world_size} 个进程")
    else:
        raise RuntimeError("DDP 初始化失败！")
    
    return rank, world_size, local_rank


def cleanup_ddp():
    """清理分布式环境"""
    if dist.is_initialized():
        print("\n>>> 清理分布式环境...")
        dist.destroy_process_group()
        print("✓ 分布式环境已清理")


def load_wikitext_dataset_from_local(rank, local_dataset_path=None):
    """
    从本地 Arrow 文件加载 Wikitext 数据集
    
    Args:
        rank (int): 当前进程的全局编号
        local_dataset_path (str, optional): 本地数据集路径。
            如果为 None，使用默认缓存路径
    
    Returns:
        DatasetDict: 包含 train/validation/test 的数据集字典
    
    Raises:
        Exception: 如果加载失败，会回退到默认方式
    """
    from datasets import Dataset, DatasetDict
    
    print(f"\n>>> Rank {rank}: 加载 wikitext 数据集...")
    
    # 默认缓存路径
    if local_dataset_path is None:
        local_dataset_path = "/root/.cache/huggingface/datasets/wikitext/wikitext-2-raw-v1/0.0.0/b08601e04326c79dfdd32d625aee71d232d685c3"
    
    # Arrow 文件路径
    train_arrow = os.path.join(local_dataset_path, "wikitext-train.arrow")
    validation_arrow = os.path.join(local_dataset_path, "wikitext-validation.arrow")
    test_arrow = os.path.join(local_dataset_path, "wikitext-test.arrow")
    
    # 检查 Arrow 文件是否存在
    if os.path.exists(train_arrow) and os.path.exists(validation_arrow) and os.path.exists(test_arrow):
        print(f"✓ Rank {rank}: 发现本地 Arrow 文件，直接加载")
        print(f"  数据集路径: {local_dataset_path}")
        
        try:
            # 直接从 Arrow 文件加载数据集
            print(f"  正在加载训练集...")
            train_dataset = Dataset.from_file(train_arrow)
            
            print(f"  正在加载验证集...")
            validation_dataset = Dataset.from_file(validation_arrow)
            
            print(f"  正在加载测试集...")
            test_dataset = Dataset.from_file(test_arrow)
            
            # 构建 DatasetDict
            dataset = DatasetDict({
                'train': train_dataset,
                'validation': validation_dataset,
                'test': test_dataset
            })
            
            print(f"✓ Rank {rank}: 从本地 Arrow 文件加载成功！")
            print(f"  训练集大小: {len(dataset['train'])}")
            print(f"  验证集大小: {len(dataset['validation'])}")
            print(f"  测试集大小: {len(dataset['test'])}")
            
            return dataset
            
        except Exception as e:
            print(f"❌ Rank {rank}: Arrow 文件加载失败: {e}")
            print(f"  错误类型: {type(e).__name__}")
            print(f"  回退到默认方式...")
            
            # 回退到默认方式
            dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')
            print(f"✓ Rank {rank}: 默认方式加载完成")
            return dataset
    else:
        print(f"⚠️ Rank {rank}: Arrow 文件不完整")
        print(f"  train: {os.path.exists(train_arrow)}")
        print(f"  validation: {os.path.exists(validation_arrow)}")
        print(f"  test: {os.path.exists(test_arrow)}")
        print(f"  使用默认方式加载...")
        
        dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')
        print(f"✓ Rank {rank}: 默认方式加载完成")
        return dataset


def main():
    print_banner("多机多卡 DDP 训练 - GPT2 模型", "█")

     # 【步骤 1】初始化 TongWnB
    print_banner("【步骤 1】初始化 TongWnB", "=")
    tongWnB.init(
        labHost="http://10.10.1.84:30800",
        gpus=[0],
        company="tong_company",
        projectName="gpt2-test",
        experimentName="training_multinode_ddp1",
        apiKey="z8VQjK4NTlTZJfL",
        experimentConfig={
            "model": "GPT2",
            "dataset": "wikitext-2",
            "parallel_strategy": "DDP",
            "num_nodes": 2,
            "gpus_per_node": 1,
        }
    )
    print(f"\n🎉 TongWnB初始化完成")
    
    # 【步骤 2】初始化 DDP
    rank, world_size, local_rank = setup_ddp()
    
    # 【步骤 2.1】同步所有进程
    print_banner("【步骤 2.1】同步所有进程", "=")
    dist.barrier()
    
    # 【步骤 3】加载模型和数据
    print_banner("【步骤 3】加载模型和数据", "=")
    print(f">>> Rank {rank}: 加载 GPT2 tokenizer...")
    tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
    tokenizer.pad_token = tokenizer.eos_token
    print(f"✓ Rank {rank}: Tokenizer 加载完成")
    
    print(f"\n>>> Rank {rank}: 加载 GPT2 模型...")
    model = GPT2LMHeadModel.from_pretrained('gpt2')
    print(f"✓ Rank {rank}: 模型加载完成")
    
    # 【关键步骤 3】将模型移到对应的 GPU
    device = torch.device(f'cuda:{local_rank}')
    model = model.to(device)
    print(f"✓ Rank {rank}: 模型已移动到 {device}")
    
    # 【关键步骤 4】显式用 DDP 包装模型（让你清楚地看到 DDP 的使用！）
    print(f"\n>>> Rank {rank}: 【显式】使用 DistributedDataParallel 包装模型...")
    print(f"    这是 DDP 的核心步骤！")
    model = DDP(
        model,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=False,  # 如果模型所有参数都参与训练，设为 False 可以提高性能
    )
    print(f"✓ Rank {rank}: 【✅ DDP 模型创建成功！】")
    print(f"  ┌─ 包装前模型类型: GPT2LMHeadModel")
    print(f"  └─ 包装后模型类型: {type(model).__name__} 👈 看！这就是 DDP！")
    print(f"  原始模型访问方式: model.module")
    print(f"  DDP 配置: device_ids=[{local_rank}], find_unused_parameters=False")
    
    # 【步骤 3.2】加载数据集（调用封装的函数）
    dataset = load_wikitext_dataset_from_local(rank)
    
    # print(f"\n>>> Rank {rank}: 加载 wikitext 数据集...")
    # dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')
    # print(f"✓ Rank {rank}: 数据集加载完成")
    
    def tokenize_function(examples):
        tokenized_output = tokenizer(
            examples['text'],
            truncation=True,
            padding='max_length',
            max_length=512
        )
        tokenized_output["labels"] = tokenized_output["input_ids"].copy()
        return tokenized_output
    
    print(f"\n>>> Rank {rank}: 预处理数据集...")
    tokenized_dataset = dataset.map(
        tokenize_function,
        batched=True,
        remove_columns=["text"]
    )
    print(f"✓ Rank {rank}: 数据集预处理完成")
    
    # 同步所有进程
    dist.barrier()
    
    # 【步骤 4】配置训练参数
    print_banner("【步骤 4】配置训练参数", "=")
    training_args = TrainingArguments(
        output_dir='./results_multinode_ddp',
        overwrite_output_dir=True,
        num_train_epochs=1,
        per_device_train_batch_size=2,  # 每个 GPU 的 batch size
        save_steps=500,
        save_total_limit=2,
        logging_dir='./logs_multinode_ddp',
        logging_steps=10,
        eval_strategy="steps",  # 使用新的参数名
        eval_steps=500,
        # 【修复】去掉 load_best_model_at_end，避免 metric_for_best_model 错误
        # load_best_model_at_end=True,  # 注释掉，因为会导致 eval_loss 找不到的错误
        # metric_for_best_model="loss",  # 注释掉
        report_to="tongWnB",
        # 【关键修复】手动 DDP 包装时必须设置此参数
        remove_unused_columns=False,  # 🔥 防止 Trainer 删除必要的列
        # DDP 相关参数
        ddp_find_unused_parameters=False,
        local_rank=local_rank,
        # 确保只在主进程保存模型
        save_on_each_node=False,
    )
    
    if rank == 0:
        print("✓ 训练参数配置完成:")
        print(f"  - 总节点数: {world_size}")
        print(f"  - 每 GPU batch size: {training_args.per_device_train_batch_size}")
        print(f"  - 有效 batch size: {training_args.per_device_train_batch_size * world_size}")
        print(f"  - 输出目录: {training_args.output_dir}")
        print(f"  - 🔥 remove_unused_columns: {training_args.remove_unused_columns} (手动 DDP 时必须为 False)")
    
    # 【步骤 5】创建 Trainer
    print_banner("【步骤 5】创建 Trainer", "=")
    print(f">>> Rank {rank}: 创建 Trainer（传入已 DDP 包装的模型）...")
    trainer = Trainer(
        model=model,  # 传入已经 DDP 包装的模型
        args=training_args,
        train_dataset=tokenized_dataset['train'],
        eval_dataset=tokenized_dataset['validation'],
    )
    
    if rank == 0:
        print("✓ Trainer 创建成功")
        print(f"  - Trainer 接收的模型类型: {type(trainer.model).__name__}")
        print(f"  - 是否为 DDP 模型: {'✅ 是' if isinstance(trainer.model, DDP) else '❌ 否'}")
        if hasattr(trainer.model, 'module'):
            print(f"  - 底层原始模型: {type(trainer.model.module).__name__}")
        print("\n  Trainer 会自动处理:")
        print("  - ✓ DistributedSampler（数据自动分片到各进程）")
        print("  - ✓ 梯度同步（DDP 在反向传播时自动同步）")
        print("  - ✓ 进程间通信（NCCL 后端）")
    
    # 同步所有进程
    dist.barrier()

    # print("\n>>> 执行自定义数据测试...")
    # group_random_test("DDP")
    # print("✓ 自定义数据测试完成\n")

    # 【步骤 6】开始训练
    print_banner("【步骤 6】开始 DDP 训练", "=")
    if rank == 0:
        print("🚀 开始多机多卡分布式训练...")
        print(f"   节点数: {world_size}")
        print(f"   训练数据将自动分片到各个进程")
        print(f"   梯度将自动在进程间同步")
    
    print(f"\n>>> Rank {rank}: 开始训练...")
    
    try:
        trainer.train()
        
        if rank == 0:
            print_banner("训练完成！", "🎉")
            print("✓ 模型已保存到:", training_args.output_dir)
    
    except Exception as e:
        print(f"\n❌ Rank {rank}: 训练过程中出现错误: {e}")
        raise
    
    finally:
        # 清理 DDP 环境
        cleanup_ddp()
    
    if rank == 0:
        print("\n✅ 多机多卡 DDP 训练完成！")
        print("   所有进程已成功完成训练")

if __name__ == "__main__":
    main()

