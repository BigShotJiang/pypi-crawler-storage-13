#!/bin/bash

# XTrace-Catch 采集间隔调整工具
# 用法: ./quick_switch.sh <间隔毫秒数>

CONTAINER_NAME="xtrace-catch-ibs8f0"
IMAGE="registry.tong.com:5000/xtrace-catch:0.0.5.1"
INTERFACE="ibs8f0"
VM_URL="http://10.10.1.84:30428/api/v1/write"
COLLECT_AGG="demo"

# 颜色
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 隐藏Docker操作的包装函数
stop_service() {
    docker stop "$CONTAINER_NAME" 2>/dev/null || true
}

remove_service() {
    docker rm "$CONTAINER_NAME" 2>/dev/null || true
}

start_service() {
    docker run -d \
        --name "$CONTAINER_NAME" \
        --privileged \
        --network host \
        -v /sys/fs/bpf:/sys/fs/bpf:rw \
        -e VICTORIAMETRICS_ENABLED=true \
        -e VICTORIAMETRICS_REMOTE_WRITE="$VM_URL" \
        -e COLLECT_AGG="$COLLECT_AGG" \
        "$IMAGE" -i "$INTERFACE" -t "$INTERVAL" --exclude-dns
}

view_logs() {
    docker logs -f --tail "$TAIL_LINES" "$CONTAINER_NAME"
}

if [ $# -eq 0 ]; then
echo "用法: $0 <间隔毫秒数> [-f] [--tail <行数>]"
echo "      $0 stop           # 停止服务"
echo "      $0 start <间隔>   # 启动服务并设置采集间隔"
echo ""
echo "示例: $0 1000           # 调整采集间隔到1000毫秒(1秒)"
echo "      $0 5000           # 调整采集间隔到5000毫秒(5秒)"
echo "      $0 1000 -f        # 调整间隔并实时查看日志(默认100行)"
echo "      $0 -f             # 仅查看服务日志(不调整间隔，默认100行)"
echo "      $0 1000 -f --tail 50   # 调整间隔并查看最近50行日志"
echo "      $0 -f --tail 200      # 仅查看最近200行服务日志"
echo "      $0 stop           # 停止服务"
echo "      $0 start 1000     # 启动服务并设置间隔为1000毫秒"
    exit 1
fi

# 检查是否是 stop 命令
if [ "$1" = "stop" ]; then
    echo -e "${YELLOW}正在停止服务...${NC}"
    stop_service
    echo -e "${GREEN}✅ 服务已停止${NC}"
    exit 0
fi

# 检查是否是 start 命令
if [ "$1" = "start" ]; then
    if [ $# -lt 2 ]; then
        echo "错误: start 命令需要指定采集间隔毫秒数"
        echo "用法: $0 start <间隔毫秒数>"
        exit 1
    fi
    INTERVAL="$2"
    echo -e "${YELLOW}正在启动服务(采集间隔: ${INTERVAL}ms)...${NC}"
    # 先停止现有服务（如果存在）
    stop_service
    # 启动服务（如果容器已存在则启动，否则创建新容器）
    if docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        docker start "$CONTAINER_NAME"
    else
        start_service
    fi
    echo -e "${GREEN}✅ 服务已启动，采集间隔为 ${INTERVAL}ms${NC}"
    exit 0
fi

# 检查参数
FOLLOW_LOGS=false
INTERVAL=""
TAIL_LINES=100

# 解析参数
i=1
while [ $i -le $# ]; do
    eval "arg=\$$i"
    if [ "$arg" = "-f" ]; then
        FOLLOW_LOGS=true
    elif [ "$arg" = "--tail" ]; then
        # 检查下一个参数是否为数字
        if [ $((i+1)) -le $# ]; then
            eval "next_arg=\$$((i+1))"
            if [[ "$next_arg" =~ ^[0-9]+$ ]]; then
                TAIL_LINES="$next_arg"
                i=$((i+1))  # 跳过下一个参数
            else
                echo "错误: --tail 后面必须是数字"
                exit 1
            fi
        else
            echo "错误: --tail 后面缺少行数参数"
            exit 1
        fi
    elif [[ "$arg" =~ ^[0-9]+$ ]]; then
        INTERVAL="$arg"
    fi
    i=$((i+1))
done

# 如果只指定了 -f 参数，仅查看日志
if [ "$FOLLOW_LOGS" = true ] && [ -z "$INTERVAL" ]; then
    echo -e "${YELLOW}查看服务日志(最近${TAIL_LINES}行)...${NC}"
    view_logs
    exit 0
fi

# 如果没有指定间隔且没有指定 -f，显示错误
if [ -z "$INTERVAL" ] && [ "$FOLLOW_LOGS" = false ]; then
    echo "错误: 请指定采集间隔毫秒数"
    echo "用法: $0 <间隔毫秒数> [-f] [--tail <行数>]"
    exit 1
fi

echo -e "${YELLOW}正在调整采集间隔到 ${INTERVAL}ms...${NC}"

# 停止并删除现有服务
stop_service
remove_service

# 启动新服务
start_service

echo -e "${GREEN}✅ 采集间隔已调整为 ${INTERVAL}ms${NC}"

# 如果指定了 -f 参数，自动查看日志
if [ "$FOLLOW_LOGS" = true ]; then
    echo -e "${YELLOW}实时查看服务日志(最近${TAIL_LINES}行)...${NC}"
    view_logs
else
    echo "查看日志: $0 -f --tail $TAIL_LINES"
fi
