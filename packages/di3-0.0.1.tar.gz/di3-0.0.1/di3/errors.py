class DependencyInjectionError(Exception):
    pass
