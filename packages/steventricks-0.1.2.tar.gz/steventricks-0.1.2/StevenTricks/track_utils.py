import os
import pandas as pd
# 導入自定義的 pickle 存取工具
from StevenTricks.file_utils import picklesave, pickleload

# 導入自定義的基本隨機編碼產生函式
from StevenTricks.code_utils import basic_code

# 導入自定義的檔案整理函式（含目錄走訪與欄位解析）
from StevenTricks.file_utils import PathWalk_df

# 標準函式庫，用來處理目錄清空與重新建立
import shutil
from pathlib import Path


def cache_name(data_list, cache_dir, namelog_path, code_length=4, avoid_mode="fuzzy"):
    """
    根據 data_list 和現有的 cachename_log 進行同步更新：
    - 清除失效的 code（在 cache 資料夾中找不到的）
    - 新增 data_list 中的新項目
    - 保留有效的 code

    參數說明：
    - data_list: 使用者關心的資料標籤列表
    - cache_dir: 快取資料儲存的資料夾路徑
    - namelog_path: 用來儲存 log.pkl 的路徑，內容是每筆資料對應的 code
    - code_length: 每個 code 預設長度（隨機編碼 + 數字編碼）
    - avoid_mode: 避免重複的比對方式，"fuzzy"（模糊比對）或 "exact"（完全相同）
    """

    # 將傳入的路徑字串轉為 Path 物件以利後續操作
    cache_dir = Path(cache_dir)
    namelog_path = Path(namelog_path)

    # 🔸 如果 namelog 已存在，代表已有歷史對應記錄，要比對與更新
    if namelog_path.exists():
        log_df = {}  # 最終更新的對應表
        log_df_old = pickleload(namelog_path)  # 讀入歷史記錄

        # 🔸 使用 PathWalk_df 取得所有快取檔案對應欄位（包含 code 欄）
        cache_walk = PathWalk_df(
            cache_dir,
            fileinclude=[".pkl"],
            name_format="code_time_order.ext"  # 命名格式協助解析出 code 欄
        )

        # 🔸 抓出目前 cache 裡面所有有效的 code 列表（避免重複使用）
        avoid_list = cache_walk["code"].unique().tolist()

        # 🔸 對每一筆歷史記錄檢查是否還有效
        for key, code in log_df_old.items():
            if code in avoid_list:
                # ✅ 此 code 在 cache 中仍然有效，保留
                log_df[key] = code
            else:
                # 🔸 使用 basic_code 建立新的唯一 code，並避免與現有重複
                code = basic_code(length=code_length, match_mode=avoid_mode, avoid_list=[code])
                log_df[key] = code

            # ❌ 刪除失效的 code
            for filepath in cache_walk[~cache_walk["code"].isin(log_df.keys())]["path"]:
                p = Path(filepath)
                if p.exists():
                    p.unlink()  # 刪除該檔案
    else:
        # 🔸 若 namelog 不存在，代表首次建立，需清空資料夾重建快取目錄
        shutil.rmtree(cache_dir)  # 移除整個資料夾（若存在）
        cache_dir.mkdir(parents=True, exist_ok=True)  # 建立新的空資料夾

        # 🔸 為每個資料項目產生一組不重複 code
        code = basic_code(length=code_length, match_mode=avoid_mode, count=len(data_list))

        # 🔸 建立名稱與 code 的對應字典
        log_df = dict(zip(data_list, code))

    # 🔸 將更新後的 code 對應表儲存為 pickle
    picklesave(log_df, namelog_path)

    # ✅ 回傳最後的對應表結果
    return log_df


class DataHistoryManager:
    """
    DataHistoryManager
    -------------------
    管理資料儲存與載入的工具類別，支援兩種模式：

    1. log 模式（持續記錄）：
        - 使用固定檔名，例如 "industry_log.pkl"
        - 每次 `save()` 都會覆蓋原檔案
        - 可透過 `append_to_log()` 不斷延伸紀錄內容

    2. cache 模式（版本快取）：
        - 根據查詢名稱（name）自動建立帶時間戳與版本編號的檔案
        - 每次 `save()` 可選擇是否刪除舊快取檔案
        - `load()` 自動載入最新版本的 cache

    使用說明：
    -----------
     manager = DataHistoryManager(mode="cache", directory="./cache", name="industryflow")
     df = manager.df  # 取得目前 dataframe（若不存在則為空）
     manager.df = new_df  # 設定處理後的 dataframe
     manager.save()  # 儲存快取，可選擇是否保留歷史版本

     log_mgr = DataHistoryManager(mode="log", directory="./log", name="industryflow_log")
     log_mgr.append_to_log(new_data)  # 附加資料並自動儲存

    參數：
    - mode: 'log' 或 'cache'
    - directory: 檔案儲存的資料夾路徑（自動建立）
    - name: log 模式為檔案名稱；cache 模式為查詢名稱
    - default_df: 若找不到檔案，預設使用的 dataframe（預設為 None）
    """

    def __init__(self, mode: str, directory: str, name: str, default_df=None):
        if mode not in ["log", "cache"]:
            raise ValueError("mode 必須是 'log' 或 'cache'")
        if not directory:
            raise ValueError("directory 為必要參數")
        if not name:
            raise ValueError("name 為必要參數")

        self.mode = mode
        self.directory = directory
        self.name = name
        self.default_df = default_df

        os.makedirs(self.directory, exist_ok=True)

        self.df, self.filepath, self.exists, self.previous_versions = self.load()

    def load(self):
        """
        載入現有檔案資料（若存在），否則回傳預設值。
        - log 模式：讀取固定檔案名
        - cache 模式：讀取最新一筆版本的快取檔案
        """
        if self.mode == "log":
            filename = f"{self.name}.pkl"
            filepath = os.path.join(self.directory, filename)
            loaded = pickleload(filepath)
            if loaded is not None:
                return loaded, filepath, True, []
            else:
                df = self.default_df if self.default_df is not None else pd.DataFrame()
                return df, filepath, False, []

        elif self.mode == "cache":
            prefix = f"py_{self.name}_"
            all_matches = sorted([f for f in os.listdir(self.directory)
                                  if f.startswith(prefix) and f.endswith(".pkl")])
            if all_matches:
                latest_file = os.path.join(self.directory, all_matches[-1])
                loaded = pickleload(latest_file)
                if loaded is not None:
                    return loaded, latest_file, True, all_matches[:-1]
            filepath_path, _ = filename_flow(self.name, self.directory)
            df = self.default_df if self.default_df is not None else pd.DataFrame()
            return df, str(filepath_path), False, []

    def save(self, delete_previous_cache=True):
        """
        儲存目前的 dataframe：
        - log 模式：覆蓋寫入
        - cache 模式：可選是否刪除先前的相同類型快取
        """
        if self.df is None:
            raise ValueError("df 為 None，無法儲存")

        if self.mode == "cache":
            prefix = f"py_{self.name}_"
            if delete_previous_cache:
                for f in os.listdir(self.directory):
                    if f.startswith(prefix) and f.endswith(".pkl") and f != os.path.basename(self.filepath):
                        os.remove(os.path.join(self.directory, f))
            picklesave(self.df, self.filepath)

        elif self.mode == "log":
            picklesave(self.df, self.filepath)

    def append_to_log(self, new_df: pd.DataFrame):
        """
        僅在 log 模式下使用：
        將新的 dataframe 附加至目前日誌資料中並儲存。
        """
        if self.mode != "log":
            raise ValueError("append_to_log can only be used in 'log' mode")
        self.df = pd.concat([self.df, new_df], ignore_index=True)
        self.save()


    def get_previous_versions(self):
        """
        回傳相同類型快取檔的歷史版本清單
        """
        return self.previous_versions
