# -*- coding: utf-8 -*-
"""
Driver Tree 工具
================

用途：
    - 對「某個 segment 的月變動」做多層次拆解（A1 裡 B1，再往下是 C1...）
    - 自動找出在當前節點「解釋力最好」的欄位，往下繼續 drill-down

典型情境：
    - df 裡有欄位：Month, A, B, C, D, E, Funding_Amt
    - 想解釋：A='A1'、某個月份的 Funding_Amt 為什麼下降（或上升）
    - 用 B / C / D / E 這幾個維度，系統化找出：
        A1 → B1 → C1 ... 這種「人眼會找但很花時間」的路徑
"""

from .convert_utils import stringtodate

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional

import math

# ---------------------------------------------------------------------------
# 1. 基礎工具：R²＋最佳切割欄位
# ---------------------------------------------------------------------------

def r2_by_group(df: pd.DataFrame, y_col: str, group_col: str) -> float:
    """
    以 group_col 分群，解釋 y_col 的變異度，回傳群間變異 / 總變異 = R²。

    直覺解讀：
        - R² 越高表示「用這個欄位切」可以把 y 切出越明顯的差異。
        - 只在當前節點的資料 df 上計算，配合 driver tree 使用。
    """
    y = df[y_col]
    if len(y) == 0:
        return float("nan")

    overall_mean = y.mean()
    sst = ((y - overall_mean) ** 2).sum()   # 總變異

    if sst == 0:
        # 完全沒有變動就沒什麼好解釋的
        return 0.0

    group_means = df.groupby(group_col)[y_col].transform("mean")
    sse_within = ((y - group_means) ** 2).sum()  # 群內變異
    ssb = sst - sse_within                       # 群間變異

    return float(ssb / sst)


def find_best_split(df: pd.DataFrame, y_col: str, group_cols: List[str]):
    """
    在 group_cols 裡找一個「對 y_col 解釋力（R²）最高」的欄位。
    回傳 (best_var, best_r2)。
    """
    best_var: Optional[str] = None
    best_r2: float = 0.0

    for col in group_cols:
        r2 = r2_by_group(df, y_col, col)
        if r2 > best_r2:
            best_r2 = r2
            best_var = col

    return best_var, best_r2


# ---------------------------------------------------------------------------
# 2. Driver Tree：在已算好 MoM 的 slice 上做多層拆解
# ---------------------------------------------------------------------------
def build_driver_tree(
    df: pd.DataFrame,
    y_col: str,
    group_cols: List[str],
    node_filter: Optional[Dict[str, Any]] = None,
    depth: int = 0,
    max_depth: int = 3,
    min_r2: float = 0.05,
    min_share: float = 0.1,
    curr_col: Optional[str] = None,
    prev_col: Optional[str] = None,
):
    """
    在「已經算好 y_col（例如 Funding_Amt_mom）」的 df 上，建立 driver tree。

    新增功能：
        若提供 curr_col / prev_col，則每個節點會多帶：
            - 'curr_value': 子群當期總額
            - 'prev_value': 子群上期總額

    參數說明略，同前版本。
    """
    if node_filter is None:
        node_filter = {}

    # 1) 套用目前路徑條件（例如 B='B1', C='C1'）
    sub = df.copy()
    for k, v in node_filter.items():
        sub = sub[sub[k] == v]

    node_total = sub[y_col].sum()
    result: List[Dict[str, Any]] = []

    # 停止條件：深度到底 / 沒欄位可以切 / 沒資料
    if depth >= max_depth or len(group_cols) == 0 or len(sub) == 0:
        return result

    # 2) 在這個節點找最佳切割欄位
    best_var, best_r2 = find_best_split(sub, y_col, group_cols)
    if best_var is None or best_r2 < min_r2:
        # 這層切不出有意義的差異
        return result

    # 3) 以 best_var 分群，計算：
    #    - delta: 子群 y_col 合計（MoM 金額）
    #    - curr / prev: 子群當期與上期總額（若有提供欄位）
    gb = sub.groupby(best_var)

    contrib = (
        gb[y_col]
        .sum()
        .rename("delta")
        .reset_index()
    )

    if curr_col is not None and prev_col is not None and curr_col in sub.columns and prev_col in sub.columns:
        stat_vals = (
            gb[[curr_col, prev_col]]
            .sum()
            .reset_index()
        )
        contrib = contrib.merge(stat_vals, on=best_var, how="left")
    else:
        # 若沒提供 curr/prev 欄位，就不要掛在 node 上
        curr_col = None
        prev_col = None

    contrib["share_of_parent"] = (
        contrib["delta"] / node_total if node_total != 0 else np.nan
    )

    # 依 delta 排序（通常會先看跌最多的）
    contrib = contrib.sort_values("delta")

    # 4) 建立節點，並遞迴往下
    for _, row in contrib.iterrows():
        # 若此子群貢獻太小，就略過，不往下鑽
        if node_total != 0 and abs(row["share_of_parent"]) < min_share:
            continue

        value = row[best_var]
        new_filter = node_filter.copy()
        new_filter[best_var] = value

        node_info: Dict[str, Any] = {
            "depth": depth,
            "split_var": best_var,
            "split_value": value,
            "delta": float(row["delta"]),               # 這個子群的變動金額
            "share_of_parent": float(row["share_of_parent"]),  # 相對父節點的比例
            "r2_at_node": float(best_r2),               # 在父節點用 best_var 分群的 R²
            "path": new_filter.copy(),                  # 從 root 到這裡的條件
        }

        # 若有 curr/prev 欄位，就一起寫進節點
        if curr_col is not None and prev_col is not None:
            node_info["curr_value"] = float(row[curr_col])
            node_info["prev_value"] = float(row[prev_col])

        result.append(node_info)

        # 往下遞迴：此子群再用剩下的欄位繼續切
        child_group_cols = [c for c in group_cols if c != best_var]
        children = build_driver_tree(
            df=df,
            y_col=y_col,
            group_cols=child_group_cols,
            node_filter=new_filter,
            depth=depth + 1,
            max_depth=max_depth,
            min_r2=min_r2,
            min_share=min_share,
            curr_col=curr_col,
            prev_col=prev_col,
        )
        result.extend(children)

    return result



# ---------------------------------------------------------------------------
# 3. 高階封裝：直接從明細 df 建出「某 segment 的 MoM driver tree」
# ---------------------------------------------------------------------------

def compute_segment_mom(
    df: pd.DataFrame,
    month_col: str,
    dims: List[str],
    value_col: str,
) -> pd.DataFrame:
    """
    將明細 df 聚到 [month_col] + dims 層級，並計算每個 segment 的月變動 (MoM)。

    例：
        df:      明細（每筆貸放一列）
        month_col='Month'
        dims     =['A','B','C','D','E']
        value_col='Funding_Amt'

    回傳欄位：
        - month_col
        - dims...
        - value_col           : 當月總額
        - f"{value_col}_lag"  : 上月總額
        - f"{value_col}_mom"  : 差額 (本月 - 上月)
        - f"{value_col}_mom_pct": 百分比差異
    """
    group_keys = [month_col] + dims
    agg = (
        df.groupby(group_keys, as_index=False)[value_col]
          .sum()
          .sort_values(dims + [month_col])
    )

    lag_name = f"{value_col}_lag"
    mom_name = f"{value_col}_mom"
    mom_pct_name = f"{value_col}_mom_pct"

    agg[lag_name] = (
        agg.groupby(dims)[value_col]
           .shift(1)
    )
    agg[mom_name] = agg[value_col] - agg[lag_name]
    agg[mom_pct_name] = agg[mom_name] / agg[lag_name]

    return agg

def build_mom_driver_tree(
    df: pd.DataFrame,
    month_col: str,
    value_col: str,
    dims: List[str],
    segment_filter: Dict[str, Any],
    target_month,
    max_depth: int = 3,
    min_r2: float = 0.05,
    min_share: float = 0.1,
    *,
    date_col: Optional[str] = None,   # 原始日期欄位名稱（可選）
    date_mode: int = 4,               # 丟給 stringtodate 的 mode（看你 convert_utils 裡怎麼定義）
    use_cols: Optional[list[str]] = None,  # 大表只保留這些欄位來分析（可選）
):
    """
    高階封裝：從「原始明細」到「指定 segment 的 driver tree」一條龍。

    新增功能：
    - date_col：指定原始日期欄位，會先用 stringtodate + to_datetime 清成 datetime，
                若 df 中沒有 month_col，會用 date_col 自動生出「月份欄」。
    - use_cols：如果 df 很大，可以指定只保留哪些欄位參與分析（其餘欄位會被丟掉）。
    """

    # 0. 先 copy 一份，避免就地污染呼叫端 df
    df = df.copy()

    # === (A) 只保留需要的欄位，避免大表拖累記憶體 ===
    if use_cols is not None:
        # 強制把 driver tree 一定會用到的欄位也加進去
        needed = set(use_cols) | {month_col, value_col}
        if date_col is not None:
            needed.add(date_col)
        if segment_filter:
            needed |= set(segment_filter.keys())

        missing = needed - set(df.columns)
        if missing:
            raise KeyError(
                f"build_mom_driver_tree：df 缺少必要欄位：{sorted(missing)}"
            )

        df = df[list(needed)]

    # === (B) 處理日期欄位：轉成 datetime，必要時生出 month_col ===
    if date_col is not None:
        if date_col not in df.columns:
            raise KeyError(
                f"build_mom_driver_tree：找不到指定的 date_col='{date_col}'"
            )

        # 1) 用你的 stringtodate 先清理（ROC / 壓縮日期等）
        df = stringtodate(df, datecol=[date_col], mode=date_mode)

        # 2) 保險一層：若還不是 datetime，就再 to_datetime 一次
        if not pd.api.types.is_datetime64_any_dtype(df[date_col]):
            df[date_col] = pd.to_datetime(df[date_col], errors="coerce")

        # 3) 若 df 中沒有 month_col，就用 date_col 生一個「月份欄」
        if month_col not in df.columns:
            # 用每月第一天代表該月：2025-09-01、2025-10-01…
            df[month_col] = (
                df[date_col]
                .dt.to_period("M")
                .dt.to_timestamp()  # Timestamp('YYYY-MM-01')
            )
        else:
            # month_col 已存在，但你可能原本是字串，把它轉成 datetime 比較安全
            if not pd.api.types.is_datetime64_any_dtype(df[month_col]):
                df[month_col] = pd.to_datetime(df[month_col], errors="coerce")

    # === (C) 原本的流程從這裡開始：算所有 segment 的 MoM ===
    agg = compute_segment_mom(
        df=df,
        month_col=month_col,
        dims=dims,
        value_col=value_col,
    )

    # 2. 抓出目標月份
    if np.issubdtype(agg[month_col].dtype, np.datetime64):
        tm = pd.to_datetime(target_month)
    else:
        tm = target_month

    slice_df = agg[agg[month_col] == tm].copy()

    # 3. 套用 segment_filter（例如 A='A1'）
    for k, v in segment_filter.items():
        if k in slice_df.columns:
            slice_df = slice_df[slice_df[k] == v]

    lag_name = f"{value_col}_lag"
    mom_name = f"{value_col}_mom"

    # 沒有上月資料的先踢掉
    slice_df = slice_df[slice_df[lag_name].notna()].copy()
    if slice_df.empty:
        return []

    # 4. 在這個 slice 上跑 driver tree，
    #    不再把已固定的維度拿來切（例如 A 已指定 A1，就只用 B/C/D/E）
    remaining_dims = [c for c in dims if c not in segment_filter]

    tree = build_driver_tree(
        df=slice_df,
        y_col=mom_name,
        group_cols=remaining_dims,
        node_filter={},
        depth=0,
        max_depth=max_depth,
        min_r2=min_r2,
        min_share=min_share,
        curr_col=value_col,     # 當期金額欄位
        prev_col=lag_name,      # 上期金額欄位
    )

    return tree


def _infer_total_delta_from_tree(tree: List[Dict[str, Any]]) -> float:
    """
    從 driver tree 結果反推出「整體變動量」（例如 A1 整體 Δ）。

    對於 depth=0 的節點：
        share_of_parent = delta / total_delta
        => total_delta = delta / share_of_parent

    只要任一個 depth=0 節點有非零 share_of_parent，就能反推 total_delta。
    """
    # 先試用 share_of_parent 反推
    for node in tree:
        if node.get("depth", None) == 0:
            share = node.get("share_of_parent", None)
            delta = node.get("delta", None)
            if share is None or delta is None:
                continue
            try:
                share_f = float(share)
                delta_f = float(delta)
            except Exception:
                continue
            if share_f != 0 and not math.isnan(share_f):
                return delta_f / share_f

    # 萬一上述失敗，就退而求其次：把 depth=0 的 delta 相加
    total = 0.0
    for node in tree:
        if node.get("depth", None) == 0:
            try:
                total += float(node.get("delta", 0.0))
            except Exception:
                continue
    return total

def format_driver_story(
    tree: List[Dict[str, Any]],
    segment_name: Optional[str] = None,
    target_month: Optional[str] = None,
    metric_name: str = "Funding_Amt_mom",
    unit: str = "元",
    max_depth_for_text: int = 2,
    top_k_level0: int = 3,
    top_k_children: int = 3,
) -> str:
    """
    完整版中文說明：
        - 每個金額：標註 (當期總額 − 上期總額)
        - 每個百分比：標註 (Δ子群 ÷ Δ整體(XXX)) 或 (Δ子群 ÷ Δ父節點(XXX))
    """
    if not tree:
        return "本期沒有可用的 driver 分析結果（變動太小或資料不足）。"

    total_delta = _infer_total_delta_from_tree(tree)

    # 決定「整體(XXX)」裡面的 XXX 要顯示什麼
    seg_label = (segment_name or "").strip()
    if seg_label:
        # 例：segment_name="A=A1"，metric_name="Funding_Amt_mom"
        # 整體(A=A1 的 Funding_Amt_mom)
        overall_label = f"{seg_label} 的 {metric_name}"
    else:
        # 沒有特別的 segment，就直接用欄位名稱
        # 整體(Funding_Amt_mom)
        overall_label = metric_name

    # 總方向文字
    if total_delta > 0:
        total_dir = "增加"
    elif total_delta < 0:
        total_dir = "減少"
    else:
        total_dir = "持平"

    # 標題敘述：把「整體」改成「整體(XXX)」
    if target_month:
        header = (
            f"{target_month}，整體({overall_label}) 相較前一期"
            f"{total_dir}{abs(total_delta):,.0f}{unit}。"
        )
    else:
        header = (
            f"本期，整體({overall_label}) 相較前一期"
            f"{total_dir}{abs(total_delta):,.0f}{unit}。"
        )

    if total_delta == 0:
        # 也把這裡的「整體」說清楚
        return header + f" 整體({overall_label}) 變動為 0，未檢測到明顯的上升或下滑來源。"

    # 第一層節點
    level0_nodes = [n for n in tree if n.get("depth", None) == 0]
    if not level0_nodes:
        return header + " 但 driver tree 未產生任何第一層切分節點。"

    first_split_var = level0_nodes[0].get("split_var", None)

    def _abs_share(node):
        s = node.get("share_of_parent", 0.0)
        try:
            return abs(float(s))
        except Exception:
            return 0.0

    level0_sorted = sorted(level0_nodes, key=_abs_share, reverse=True)
    level0_top = level0_sorted[:top_k_level0]

    lines = [header]

    if first_split_var:
        lines.append(f"從 {first_split_var} 這個維度來看：")
    else:
        lines.append("從第一層切分結果來看：")

    # 第一層說明
    for node in level0_top:
        var = node.get("split_var")
        val = node.get("split_value")
        delta = float(node.get("delta", 0.0))
        curr = node.get("curr_value", None)
        prev = node.get("prev_value", None)

        if delta > 0:
            dword = "增加"
        elif delta < 0:
            dword = "減少"
        else:
            dword = "持平"

        share_pct = delta / total_delta * 100.0 if total_delta != 0 else 0.0

        # 金額部分：若有 curr/prev，就顯示 (curr − prev)
        if curr is not None and prev is not None:
            # 這裡的 delta = curr - prev
            amount_part = (
                f"{abs(delta):,.0f}{unit}（= {curr:,.0f} − {prev:,.0f}）"
            )
        else:
            amount_part = f"{abs(delta):,.0f}{unit}（= 子群當期總額 − 上期總額）"

        # 這裡把「整體變動」改成「整體(XXX)變動」，並清楚標註分子分母
        lines.append(
            f"- {var} = {val} 子群{dword}{amount_part}，"
            f"約佔整體({overall_label}) 變動的 {abs(share_pct):.1f}%"
            f"（= 子群 {metric_name} 變動 {delta:,.0f} ÷ "
            f"整體({overall_label}) 變動 {total_delta:,.0f}）。"
        )

    if max_depth_for_text <= 1:
        return "\n".join(lines)

    # 選一個主要子群往下看第二層
    def _same_dir_as_total(node):
        d = float(node.get("delta", 0.0))
        if total_delta > 0:
            return d > 0
        elif total_delta < 0:
            return d < 0
        else:
            return False

    level0_same_dir = [n for n in level0_sorted if _same_dir_as_total(n)]
    if level0_same_dir:
        main_parent = level0_same_dir[0]
    else:
        main_parent = level0_sorted[0]

    parent_var = main_parent.get("split_var")
    parent_val = main_parent.get("split_value")
    parent_delta = float(main_parent.get("delta", 0.0))
    parent_path = main_parent.get("path", {}) or {}

    def _is_child_of(node, parent_path: Dict[str, Any]) -> bool:
        path = node.get("path", {}) or {}
        for k, v in parent_path.items():
            if path.get(k) != v:
                return False
        return True

    child_nodes = [
        n for n in tree
        if n.get("depth", 0) == 1 and _is_child_of(n, parent_path)
    ]

    if child_nodes:
        lines.append(f"\n進一步在 {parent_var} = {parent_val} 子群中觀察：")

        child_sorted = sorted(
            child_nodes,
            key=lambda n: abs(float(n.get("share_of_parent", 0.0))),
            reverse=True,
        )
        child_top = child_sorted[:top_k_children]

        for node in child_top:
            var = node.get("split_var")
            val = node.get("split_value")
            delta = float(node.get("delta", 0.0))
            curr = node.get("curr_value", None)
            prev = node.get("prev_value", None)
            share_parent = float(node.get("share_of_parent", 0.0))

            if delta > 0:
                dword = "增加"
            elif delta < 0:
                dword = "減少"
            else:
                dword = "持平"

            share_pct = delta / parent_delta * 100.0 if parent_delta != 0 else 0.0

            if curr is not None and prev is not None:
                amount_part = (
                    f"{abs(delta):,.0f}{unit}（= {curr:,.0f} − {prev:,.0f}）"
                )
            else:
                amount_part = f"{abs(delta):,.0f}{unit}（= 子群當期總額 − 上期總額）"

            # 第二層維持原本邏輯，只是把分母講清楚是「父節點(XXX)變動」
            lines.append(
                f"- {var} = {val} 子群{dword}{amount_part}，"
                f"約佔 {parent_var} = {parent_val} 子群的 {metric_name} 變動"
                f" 的 {abs(share_pct):.1f}%（= 子群 {metric_name} 變動 {delta:,.0f} "
                f"÷ {parent_var} = {parent_val} 子群的 {metric_name} 變動 {parent_delta:,.0f}）。"
            )

    return "\n".join(lines)


if __name__ == "__main__":
    print("driver_tree 模組匯入成功，請在外部程式呼叫 build_mom_driver_tree() 測試。")
