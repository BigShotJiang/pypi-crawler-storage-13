from collections.abc import Callable

from wkmigrate.datasets.mixins import DeclarativePipelinesSource, DeclarativePipelinesSink
from wkmigrate.datasets import parsers


class CSVDataset(DeclarativePipelinesSource):
    type: str = "avro"

    @property
    def secrets(self) -> list[str]:
        return ["storage_account_key"]

    @property
    def options(self) -> list[str]:
        return ["header", "sep", "lineSep", "quote", "quoteAll", "escape", "nullValue", "compression", "encoding"]

    @property
    def dataset_parser(self) -> Callable[dict, dict]:
        return parsers.parse_delimited_file_dataset

    @property
    def property_parser(self) -> Callable[dict, dict]:
        return parsers.parse_delimited_file_properties


class JSONDataset(DeclarativePipelinesSource):
    type: str = "json"

    @property
    def secrets(self) -> list[str]:
        return ["storage_account_key"]

    @property
    def options(self) -> list[str]:
        return ["encoding", "compression"]

    @property
    def dataset_parser(self) -> Callable[dict, dict]:
        return parsers.parse_json_file_dataset

    @property
    def property_parser(self) -> Callable[dict, dict]:
        return parsers.parse_json_file_properties


class ORCDataset(DeclarativePipelinesSource):
    type: str = "orc"

    @property
    def secrets(self) -> list[str]:
        return ["storage_account_key"]

    @property
    def options(self) -> list[str]:
        return ["compression"]

    @property
    def dataset_parser(self) -> Callable[dict, dict]:
        return parsers.parse_orc_file_dataset

    @property
    def property_parser(self) -> Callable[dict, dict]:
        return parsers.parse_orc_file_properties


class ParquetDataset(DeclarativePipelinesSource):
    type: str = "parquet"

    @property
    def secrets(self) -> list[str]:
        return ["storage_account_key"]

    @property
    def options(self) -> list[str]:
        return ["compression"]

    @property
    def dataset_parser(self) -> Callable[dict, dict]:
        return parsers.parse_parquet_file_dataset

    @property
    def property_parser(self) -> Callable[dict, dict]:
        return parsers.parse_parquet_file_properties


class SqlServerDataset(DeclarativePipelinesSource):
    type: str = "sqlserver"

    @property
    def secrets(self) -> list[str]:
        return ["host", "database", "user_name", "password"]

    @property
    def options(self) -> list[str]:
        return ["host", "database", "user_name", "password"]

    @property
    def dataset_parser(self) -> Callable[dict, dict]:
        return parsers.parse_sql_server_dataset

    @property
    def property_parser(self) -> Callable[dict, dict]:
        return parsers.parse_sql_server_properties



