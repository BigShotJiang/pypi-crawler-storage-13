from abc import ABC, abstractmethod
from collections.abc import Callable


class DatasetMixin(ABC):
    """
    Implements methods for parsing properties from ADF datasets used in Copy Data activities.
    """
    @property
    @abstractmethod
    def secrets(self) -> list[str]:
        """
        Returns secret keys to be stored in a Databricks secret scope for the specified dataset.

        Returns:
            A list of secret keys to be stored in a Databricks secret scope
        """
        raise NotImplementedError(f"Class '{self.__class__.__name__}' does not implement method 'secrets'")

    @property
    @abstractmethod
    def options(self) -> list[str]:
        """
        Returns option keys to be set when creating a Spark data source for the specified dataset.

        Returns:
            A list of secret option keys to be set when creating the Spark data source
        """
        raise NotImplementedError(f"Class '{self.__class__.__name__}' does not implement method 'options'")

    @property
    @abstractmethod
    def dataset_parser(self) -> Callable[dict, dict]:
        """
        Returns a function to parse a dataset from the ADF definition.

        Returns:
            A function to parse a dataset from the ADF definition
        """
        raise NotImplementedError(f"Class '{self.__class__.__name__}' does not implement method 'property_parser'")

    @property
    @abstractmethod
    def property_parser(self) -> Callable[dict, dict]:
        """
        Returns a function to parse dataset properties from the ADF dataset definition.

        Returns:
            A function to parse properties from the ADF dataset definition
        """
        raise NotImplementedError(f"Class '{self.__class__.__name__}' does not implement method 'property_parser'")

    @property
    @abstractmethod
    def is_declarative_pipelines_source(self) -> bool:
        """
        Indicates that the dataset can be read from as a source in Spark Declarative Pipelines.

        Returns:
            A boolean indicating if the dataset can be read from as a source in Spark Declarative Pipelines
        """
        raise NotImplementedError(
            f"Class '{self.__class__.__name__}' does not implement method 'is_sdp_supported_source'"
        )

    @property
    @abstractmethod
    def is_declarative_pipelines_sink(self) -> bool:
        """
        Indicates that the dataset can be written to as a sink in Spark Declarative Pipelines.

        Returns:
            A boolean indicating if the dataset can be written to as a sink in Spark Declarative Pipelines
        """
        return False


class DeclarativePipelinesSource(ABC, DatasetMixin):
    @property
    @abstractmethod
    def is_declarative_pipelines_source(self) -> bool:
        """
        Indicates that the dataset can be read from as a source in Spark Declarative Pipelines.

        Returns:
            A boolean indicating if the dataset can be read from as a source in Spark Declarative Pipelines
        """
        return True


class DeclarativePipelinesSink(ABC, DatasetMixin):
    @property
    @abstractmethod
    def is_declarative_pipelines_source(self) -> bool:
        """
        Indicates that the dataset can be read from as a source in Spark Declarative Pipelines.

        Returns:
            A boolean indicating if the dataset can be read from as a source in Spark Declarative Pipelines
        """
        return True
