# Loki MCP Server

[![CI](https://github.com/elad12390/loki-mcp/workflows/CI/badge.svg)](https://github.com/elad12390/loki-mcp/actions/workflows/ci.yml)

A Go-based server implementation for the Model Context Protocol (MCP) with Grafana Loki integration.

## Quick Start (Recommended)

Run the server directly with a single command using `uvx` or `pipx`. No manual build or Docker required (requires Go 1.24+).

```bash
# Using uvx
uvx elad12390-loki-mcp

# Using pipx
pipx run elad12390-loki-mcp
```

This will automatically download, compile, and run the server.

## Configuration

The server is configured via environment variables. You can pass these when running the command:

- `LOKI_URL`: Loki server URL (default: `http://localhost:3100`)
- `LOKI_ORG_ID`: Default organization ID (X-Scope-OrgID)
- `LOKI_USERNAME`: Basic auth username
- `LOKI_PASSWORD`: Basic auth password
- `LOKI_TOKEN`: Bearer token

**Example with Claude Desktop config:**

```json
{
  "mcpServers": {
    "loki": {
      "command": "uvx",
      "args": ["elad12390-loki-mcp"],
      "env": {
        "LOKI_URL": "https://logs-prod-us-central1.grafana.net",
        "LOKI_USERNAME": "your-username",
        "LOKI_PASSWORD": "your-password"
      }
    }
  }
}
```

## Features

The `loki_query` tool allows you to query Grafana Loki log data:

- **Query**: LogQL query string (required)
- **Time Range**: `start` and `end` times (default: last 1 hour)
- **Limit**: Max entries (default: 100)
- **Org ID**: Multi-tenant organization support

**Example Queries:**
- "Find error logs from the last hour in Loki using query {job=\"varlogs\"} |= \"ERROR\""
- "Show me the most recent 50 logs from Loki with job=varlogs"
- "Query Loki for logs with org 'tenant-123' using query {job=\"varlogs\"}"

## Development

If you want to contribute or build manually:

```bash
# Build
go build -o loki-mcp-server ./cmd/server

# Run
./loki-mcp-server
```

### Docker

```bash
docker build -t loki-mcp-server .
docker run --rm -i loki-mcp-server
```

## License

MIT License
